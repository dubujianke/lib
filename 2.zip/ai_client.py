# -*- coding: utf-8 -*-
"""AI 客户端封装 - 调 OpenAI 兼容接口"""

import httpx
import json
import os
import re
import sys
from dataclasses import dataclass
from typing import Optional


# 全局日志目录（记录每次 LLM 输入输出）
LOG_DIR = os.environ.get("LLM_LOG_DIR", "")
_LOG_SEQ = 0


@dataclass
class AIConfig:
    api_key: str = ""
    base_url: str = ""
    model: str = ""
    temperature: float = 1.0
    timeout: int = 300
    concurrency: int = 1

    def __post_init__(self):
        cfg = self._load_config_file()
        self.api_key = self.api_key or cfg.get("api_key", "") or os.environ.get("LLM_API_KEY", "")
        self.base_url = self.base_url or cfg.get("base_url", "") or "https://api.deepseek.com/v1"
        self.model = self.model or cfg.get("model", "") or "deepseek-chat"
        self.concurrency = self.concurrency if self.concurrency != 1 else cfg.get("concurrency", 1)
        if not self.api_key:
            print("⚠ 未设置 API Key！请在 llm_config.json 中配置或设置环境变量 LLM_API_KEY")

    @staticmethod
    def _load_config_file():
        for d in [os.path.dirname(os.path.abspath(__file__)),
                  os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                  "."]:
            path = os.path.join(d, "llm_config.json")
            if os.path.exists(path):
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    if isinstance(data, list):
                        # 取第一个 enable=1 的
                        for item in data:
                            if item.get("enable", 0) == 1:
                                return item
                        # 都没有就用第一个
                        if data:
                            return data[0]
                    return data
                except Exception:
                    pass
        return {}


class AIClient:
    """封装 LLM 调用，支持 chat + 流式，自动记录输入输出到日志"""

    def __init__(self, config: Optional[AIConfig] = None, log_dir: str = None,
                 devtools_dir: str = None):
        self.config = config or AIConfig()
        # verify=False 跳过 SSL 证书校验（bboluo.com 证书不匹配）
        self._client = httpx.Client(http2=True, timeout=self.config.timeout, verify=False)
        self.log_dir = log_dir or LOG_DIR
        # AI SDK DevTools 追踪器（可选）
        self._tracker = None
        if devtools_dir:
            try:
                sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
                from novel_writer.devtools_tracker import DevToolsTracker
                self._tracker = DevToolsTracker(devtools_dir)
            except Exception as e:
                print(f"[DevTools] tracker 初始化失败: {e}", flush=True)
                self._tracker = None

    def _log(self, category: str, system: str, user: str, result: str):
        """记录一次 LLM 调用的输入输出到文件"""
        if not self.log_dir:
            return
        global _LOG_SEQ
        _LOG_SEQ += 1
        os.makedirs(self.log_dir, exist_ok=True)
        seq = _LOG_SEQ
        try:
            # 输入
            with open(os.path.join(self.log_dir, f"{seq:04d}_{category}_input.txt"), "w", encoding="utf-8") as f:
                f.write(f"=== SYSTEM ===\n{system}\n\n=== USER ===\n{user}")
            # 输出
            with open(os.path.join(self.log_dir, f"{seq:04d}_{category}_output.txt"), "w", encoding="utf-8") as f:
                f.write(result)
        except Exception:
            pass

    def chat_with_tools(self, system: str, user: str, tools: list,
                        category: str = "chat", max_rounds: int = 100,
                        messages: list = None, max_tokens: int = None,
                        assistant: str = None) -> str:
        """调大模型，支持 Function Calling（对标 Toonflow tool-based agent）

        tools: [{"type":"function","function":{...}}]
        messages: 已有的对话历史（对标 Toonflow memoryKey 跨轮记忆）
        returns: 最终模型文本回复
        """
        import time
        url = f"{self.config.base_url}/chat/completions"
        msgs = [{"role": "system", "content": system}]
        # 对标 Toonflow assistant 消息
        if assistant:
            msgs.append({"role": "assistant", "content": assistant})
        # memoryKey: 历史消息插入 system/assistant 和 user 之间
        if messages:
            msgs = [msgs[0]] + messages + msgs[1:]
        msgs.append({"role": "user", "content": user})
        total_len = sum(len(m.get('content','')) for m in msgs)
        print(f"=== HTTP REQUEST [{category}] msgs={len(msgs)} total={total_len} URL={url} ===", flush=True)

        for _ in range(max_rounds):
            payload = {
                "model": self.config.model,
                "messages": msgs,
                "temperature": self.config.temperature,
                "max_tokens": max_tokens or 16384,
            }
            if tools:
                payload["tools"] = tools
                payload["tool_choice"] = "auto"

            headers = {
                "Authorization": f"Bearer {self.config.api_key}",
                "Content-Type": "application/json",
            }
            # 失败重试（524/5xx 等，最多3次）
            resp = None
            for attempt in range(3):
                try:
                    total_len = sum(len(m.get('content','')) for m in msgs)
                    print(f"[AI-IN] {category}_tool round={len(msgs)}msgs total={total_len}", flush=True)
                    resp = self._client.post(url, json=payload, headers=headers)
                    if resp.status_code == 200:
                        break
                    # 429 限流或 5xx 服务错误，重试
                    print(f"[AI] {category} 重试 {attempt+1}/3 status={resp.status_code}", flush=True)
                    time.sleep(2 * (attempt + 1))
                except Exception as e:
                    print(f"[AI] {category} 重试 {attempt+1}/3 error={e}", flush=True)
                    time.sleep(2 * (attempt + 1))
            if resp is None or resp.status_code != 200:
                raise RuntimeError(f"API 错误 {resp.status_code if resp else '无响应'}: {resp.text if resp else ''}")

            data = resp.json()
            choice = data["choices"][0]
            msg = choice.get("message", {})

            # 检查是否有 tool calls（JSON 或 XML 格式）
            tool_calls = msg.get("tool_calls")
            if not tool_calls:
                # 兼容 XML 格式: <tool_calls><invoke name="xxx"><parameter>...</parameter></invoke></tool_calls>
                content = msg.get("content", "")
                xml_invokes = re.findall(r'<invoke\s+name="([^"]+)"[^>]*>(.*?)</invoke>', content, re.DOTALL)
                if xml_invokes:
                    tool_calls = []
                    for fn_name, params_text in xml_invokes:
                        args = {}
                        for pm in re.findall(r'<parameter\s+name="([^"]+)"[^>]*>(.*?)</parameter>', params_text, re.DOTALL):
                            args[pm[0]] = pm[1].strip()
                        tool_calls.append({"id": f"xml_{fn_name}", "function": {"name": fn_name, "arguments": json.dumps(args)}})
            if tool_calls:
                print(f"[AI] {category} 工具调用: {[tc['function']['name'] for tc in tool_calls]}", flush=True)
                msgs.append(msg)

                for tc in tool_calls:
                    fn_name = tc["function"]["name"]
                    fn_args = json.loads(tc["function"]["arguments"])
                    fn_result = self._execute_tool(fn_name, fn_args)
                    msgs.append({
                        "role": "tool",
                        "tool_call_id": tc["id"],
                        "content": fn_result,
                    })
                continue  # 继续下一轮

            # 正常文本回复
            result = msg.get("content", "")
            finish = data["choices"][0].get("finish_reason", "?")
            print(f"=== HTTP RESPONSE [{category}] final round len={len(result)} finish={finish} ===", flush=True)
            print(f"{result[:3000]}", flush=True)
            print(f"=== END RESPONSE ===", flush=True)
            self._log(category, system, user, result)
            return result

        raise RuntimeError("Function calling 超过最大轮数")

    def _execute_tool(self, name: str, args: dict) -> str:
        """执行工具调用。在 script_generator 中通过 _tool_handlers 注册"""
        handler = getattr(self, "_tool_handlers", {}).get(name)
        if handler:
            return handler(args)
        return json.dumps({"error": f"未知工具: {name}"})

    def set_tools(self, handlers: dict):
        """注册工具处理器"""
        self._tool_handlers = handlers

    def _log_usage(self, category: str, data: dict):
        """仅在第一次打印模型信息"""
        pass  # 不打印，在 chat 中用简化格式

    def chat(self, system: str, user: str, stream: bool = False, category: str = "chat", max_tokens: int = None) -> str:
        """调大模型，返回文本"""
        print(f"[AI] {category} 请求中...", flush=True)
        url = f"{self.config.base_url}/chat/completions"
        payload = {
            "model": self.config.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "stream": stream,
            "temperature": self.config.temperature,
            "max_tokens": max_tokens or 16384,
        }
        headers = {
            "Authorization": f"Bearer {self.config.api_key}",
            "Content-Type": "application/json",
        }
        import time
        start_ts = time.time()
        run_id = None
        if self._tracker:
            run_id = self._tracker.start_run(provider=category)

        print(f"=== HTTP REQUEST [{category}] ===", flush=True)
        print(f"URL: {url}", flush=True)
        print(f"BODY({len(user)}字): {json.dumps(payload, ensure_ascii=False)[:8000]}", flush=True)
        print(f"=== END REQUEST ===", flush=True)
        resp = None
        for attempt in range(3):
            try:
                resp = self._client.post(url, json=payload, headers=headers)
                if resp.status_code == 200:
                    break
                print(f"[AI] {category} 重试 {attempt+1}/3 status={resp.status_code}", flush=True)
                time.sleep(2 * (attempt + 1))
            except Exception as e:
                print(f"[AI] {category} 重试 {attempt+1}/3 error={e}", flush=True)
                time.sleep(2 * (attempt + 1))
        if resp is None or resp.status_code != 200:
            err = f"API 错误 {resp.status_code if resp else '无响应'}: {resp.text if resp else ''}"
            if self._tracker and run_id:
                self._tracker.add_step(
                    run_id, 1, model_id=self.config.model, provider=category,
                    messages=payload["messages"], temperature=self.config.temperature,
                    max_output_tokens=max_tokens or 16384,
                    error=err, duration_ms=(time.time() - start_ts) * 1000,
                    raw_request={"url": url, "body": payload},
                )
            raise RuntimeError(err)
        data = resp.json()
        result = data["choices"][0]["message"]["content"]
        usage = data.get("usage", {})
        if self._tracker and run_id:
            self._tracker.add_step(
                run_id, 1, model_id=self.config.model, provider=category,
                messages=payload["messages"], temperature=self.config.temperature,
                max_output_tokens=max_tokens or 16384,
                output_text=result, finish_reason="stop",
                input_tokens=usage.get("prompt_tokens"), output_tokens=usage.get("completion_tokens"),
                duration_ms=(time.time() - start_ts) * 1000,
                raw_request={"url": url, "body": payload},
                raw_response=data,
            )
        print(f"=== HTTP RESPONSE [{category}] status={resp.status_code} len={len(result)} ===", flush=True)
        print(f"{result[:3000]}", flush=True)
        print(f"=== END RESPONSE ===", flush=True)
        self._log(category, system, user, result)
        return result

    def close(self):
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
