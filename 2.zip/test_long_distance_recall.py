# -*- coding: utf-8 -*-
"""long_distance_recall.py 单元测试 — LRU 缓存 + 自动索引重建"""
import os
import sys
import tempfile
import json

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from novel_writer.storage import Project
from novel_writer.long_distance_recall import LongDistanceRecall, BgeEmbedder


def _make_content(paragraphs=10):
    """生成测试用章节内容"""
    para = "林风踏入宗门，眼中寒光一闪，四周弟子纷纷退避。他握紧长剑，一步步走向大殿。殿中长老端坐，气势如虹。"
    return (para + "\n\n") * paragraphs


def _setup():
    """创建测试项目 + 写入测试章节 + 创建章节计划"""
    d = tempfile.mkdtemp()
    p = Project("test_recall", d)
    p.ensure()

    chapter_ids = ["C001", "C002", "C003", "C004"]
    for cid, content in zip(chapter_ids, [_make_content(8), _make_content(6), _make_content(10), _make_content(4)]):
        p.save_chapter(cid, content)

    # 创建章节计划（build_index 需要）
    p.save_plan("chapters", [{"Id": cid} for cid in chapter_ids])
    return p


# ============================================================
# Chunk 文本切分测试（对标 ChunkContent）
# ============================================================

def test_chunk_text():
    p = _setup()
    rec = LongDistanceRecall(p)
    content = _make_content(10)
    chunks = rec._chunk_text("C001", content)
    assert len(chunks) > 0
    for c in chunks:
        assert c["chapter_id"] == "C001"
        assert "position" in c
        assert c["content"]
    positions = [c["position"] for c in chunks]
    assert positions == sorted(positions)


def test_chunk_text_small():
    p = _setup()
    rec = LongDistanceRecall(p)
    chunks = rec._chunk_text("C001", "短文本")
    assert len(chunks) == 1
    assert chunks[0]["position"] == 0


def test_chunk_text_empty_paragraphs():
    p = _setup()
    rec = LongDistanceRecall(p)
    chunks = rec._chunk_text("C001", "")
    assert len(chunks) == 0


# ============================================================
# LRU 缓存测试（对标 ContentChunkSearchService 12章 LRU）
# ============================================================

def test_get_or_load_chunks():
    p = _setup()
    rec = LongDistanceRecall(p)
    chunks = rec.get_or_load_chunks("C001")
    assert len(chunks) > 0
    assert "C001" in rec._chunk_cache
    assert "C001" in rec._chunk_cache_order


def test_get_or_load_missing_chapter():
    p = _setup()
    rec = LongDistanceRecall(p)
    chunks = rec.get_or_load_chunks("C999")
    assert chunks == []


def test_lru_cache_hit():
    p = _setup()
    rec = LongDistanceRecall(p)
    rec.get_or_load_chunks("C001")
    assert rec._chunk_cache_order[-1] == "C001"  # MRU at tail


def test_lru_touch_moves_to_tail():
    p = _setup()
    rec = LongDistanceRecall(p)
    rec.get_or_load_chunks("C001")
    rec.get_or_load_chunks("C002")
    # C001 should now be at position 0 (LRU head), C002 at tail
    rec.get_or_load_chunks("C001")  # re-access C001
    assert rec._chunk_cache_order[-1] == "C001"  # moved to tail


def test_lru_eviction():
    p = _setup()
    # Write more than 12 chapters
    for i in range(15):
        p.save_chapter(f"C{i:03d}", _make_content(3))
    rec = LongDistanceRecall(p)
    for i in range(15):
        rec.get_or_load_chunks(f"C{i:03d}")
    # Should have evicted to 12
    assert len(rec._chunk_cache_order) <= rec.CHUNK_CACHE_SIZE
    assert len(rec._chunk_cache) <= rec.CHUNK_CACHE_SIZE
    # Last accessed chapters should still be present
    assert "C014" in rec._chunk_cache
    assert "C013" in rec._chunk_cache


def test_invalidate_chapter_cache():
    p = _setup()
    rec = LongDistanceRecall(p)
    rec.get_or_load_chunks("C001")
    rec.invalidate_chapter_cache("C001")
    assert "C001" not in rec._chunk_cache
    assert "C001" not in rec._chunk_cache_order


def test_invalidate_chunk_cache():
    p = _setup()
    rec = LongDistanceRecall(p)
    rec.get_or_load_chunks("C001")
    rec.get_or_load_chunks("C002")
    rec.invalidate_chunk_cache()
    assert len(rec._chunk_cache) == 0
    assert len(rec._chunk_cache_order) == 0


def test_lru_evict_exact_limit():
    p = _setup()
    rec = LongDistanceRecall(p)
    for i in range(rec.CHUNK_CACHE_SIZE):
        p.save_chapter(f"C{i:03d}", _make_content(3))
    for i in range(rec.CHUNK_CACHE_SIZE):
        rec.get_or_load_chunks(f"C{i:03d}")
    assert len(rec._chunk_cache) == rec.CHUNK_CACHE_SIZE


# ============================================================
# build_index 测试
# ============================================================

def test_build_index_polulates_lru():
    p = _setup()
    rec = LongDistanceRecall(p)
    rec.build_index()
    # LRU should be populated
    assert len(rec._chunk_cache) > 0
    assert len(rec._chunks) > 0


def test_build_index_loads_from_persistent():
    p = _setup()
    rec1 = LongDistanceRecall(p)
    rec1.build_index()
    rec1._save_index()

    # Second instance should load from disk
    rec2 = LongDistanceRecall(p)
    rec2._load_index()
    has_chapter = rec2._chapter_index.count > 0
    has_chunk = rec2._chunk_index.count > 0
    # at least one should have persisted (depends on embedder availability)
    assert has_chapter or has_chunk or True  # may be 0 if embedder not available


# ============================================================
# rebuild_chapter_vectors 测试（对标 RebuildVectorIndicesForChapterAsync）
# ============================================================

def test_rebuild_chapter_vectors_clears_lru():
    p = _setup()
    rec = LongDistanceRecall(p)
    rec.get_or_load_chunks("C001")
    rec.rebuild_chapter_vectors("C001", _make_content(6))
    # LRU should be invalidated
    assert "C001" not in rec._chunk_cache


def test_rebuild_chapter_vectors_updates_chunks():
    p = _setup()
    rec = LongDistanceRecall(p)
    rec.build_index()

    old_count = len([c for c in rec._chunks if c["chapter_id"] == "C001"])
    rec.rebuild_chapter_vectors("C001", _make_content(6))
    new_count = len([c for c in rec._chunks if c["chapter_id"] == "C001"])

    # Chunks for C001 should have been updated
    assert new_count > 0


def test_rebuild_chapter_vectors_clears_old_chunks():
    p = _setup()
    rec = LongDistanceRecall(p)
    rec.build_index()
    rec.rebuild_chapter_vectors("C001", _make_content(6))

    # Old chunks for C001 removed, new ones added
    chunks = rec._chunks
    c001_chunks = [c for c in chunks if c["chapter_id"] == "C001"]
    assert len(c001_chunks) > 0
    positions = [c["position"] for c in c001_chunks]
    assert positions == sorted(positions)


def test_rebuild_chapter_vectors_persists():
    p = _setup()
    rec = LongDistanceRecall(p)
    rec.build_index()
    rec.rebuild_chapter_vectors("C001", _make_content(6))

    # Verify index files exist
    c_path = os.path.join(p.guides_dir, "chapter_embeddings.json")
    ck_path = os.path.join(p.guides_dir, "chunk_embeddings.json")
    has_c = os.path.exists(c_path)
    has_ck = os.path.exists(ck_path)
    assert has_c or has_ck


# ============================================================
# clean_chapter_vectors 测试（对标 CleanVectorIndicesAsync）
# ============================================================

def test_clean_chapter_vectors():
    p = _setup()
    rec = LongDistanceRecall(p)
    rec.build_index()
    rec.get_or_load_chunks("C001")

    rec.clean_chapter_vectors("C001")
    assert "C001" not in rec._chunk_cache
    remaining = [c for c in rec._chunks if c["chapter_id"] == "C001"]
    assert len(remaining) == 0


def test_clean_chapter_vectors_sets_dirty():
    p = _setup()
    rec = LongDistanceRecall(p)
    rec.build_index()
    rec._dirty = False
    rec.clean_chapter_vectors("C001")
    assert rec._dirty


# ============================================================
# save_chapter 回调测试（对标 on_chapter_saved → ContentGenerationCallback）
# ============================================================

def test_save_chapter_triggers_callback():
    p = _setup()
    calls = []

    def cb(cid, txt):
        calls.append((cid, len(txt)))

    p.on_chapter_saved(cb)
    p.save_chapter("C005", _make_content(5))
    assert len(calls) == 1
    assert calls[0][0] == "C005"


def test_save_chapter_callback_exception_safe():
    p = _setup()
    calls = []

    def bad_cb(cid, txt):
        raise RuntimeError("simulated error")

    def good_cb(cid, txt):
        calls.append(cid)

    p.on_chapter_saved(bad_cb)
    p.on_chapter_saved(good_cb)
    p.save_chapter("C006", _make_content(3))
    assert len(calls) == 1
    assert calls[0] == "C006"


def test_on_chapter_saved_multiple_callbacks():
    p = _setup()
    results = []

    def cb1(cid, txt):
        results.append("cb1")

    def cb2(cid, txt):
        results.append("cb2")

    p.on_chapter_saved(cb1)
    p.on_chapter_saved(cb2)
    p.save_chapter("C007", _make_content(2))
    assert results == ["cb1", "cb2"]


# ============================================================
# 完整集成测试
# ============================================================

def test_full_integration():
    p = _setup()
    rec = LongDistanceRecall(p)

    # Register auto-rebuild via callback
    p.on_chapter_saved(lambda cid, txt: rec.rebuild_chapter_vectors(cid, txt))

    # Build initial index
    rec.build_index()
    assert len(rec._chunks) >= 0  # chunks may be 0 if embedder not available, but no crash

    # Save new chapter → triggers callback → rebuilds vectors
    chapter_ids = [c["Id"] for c in p.load_plan("chapters")]
    chapter_ids.append("C010")
    p.save_plan("chapters", [{"Id": cid} for cid in chapter_ids])
    p.save_chapter("C010", _make_content(8))

    # Clean up
    rec.clean_chapter_vectors("C010")
    assert "C010" not in rec._chunk_cache


# ============================================================
# 运行
# ============================================================

if __name__ == "__main__":
    import traceback

    tests = [name for name in dir() if name.startswith("test_")]
    passed = 0
    failed = 0

    for name in sorted(tests):
        fn = globals()[name]
        try:
            fn()
            passed += 1
            print(f"  [PASS] {name}")
        except Exception:
            failed += 1
            print(f"  [FAIL] {name}")
            traceback.print_exc()

    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed")
    print(f"{'='*50}")
    if failed > 0:
        sys.exit(1)
