from openai import OpenAI

client = OpenAI(
    api_key="sk-4jABujIbxgIkkBUVKQFKfPBui3zw9MOAE7uk5bZDcvsmaG77",
    base_url="https://llm.xinlicloud.top/v1"
)

response = client.chat.completions.create(
    model="glm-5.2",
    messages=[
        {"role": "system", "content": "你是一个有用的助手"},
        {"role": "user", "content": "你好，请介绍一下你自己"}
    ]
)
print(response.choices[0].message.content)
