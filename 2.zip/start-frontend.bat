@echo off
cd /d D:\study\cartoon\Toonflow-web-master
if not exist "D:\study\cartoon\logs" mkdir "D:\study\cartoon\logs"
for /f "tokens=5" %%i in ('netstat -ano ^| findstr /r /c:":50188.*LISTENING"') do (
    echo [frontend] already running, PID %%i
    pause
    exit /b 0
)
start "toonflow-frontend" /min cmd /c "cd /d D:\study\cartoon\Toonflow-web-master && yarn dev > D:\study\cartoon\logs\frontend.log 2>&1"
echo [frontend] starting... log: D:\study\cartoon\logs\frontend.log
pause
