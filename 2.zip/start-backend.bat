@echo off
cd /d D:\study\cartoon\Toonflow-app-master
if not exist "D:\study\cartoon\logs" mkdir "D:\study\cartoon\logs"
for /f "tokens=5" %%i in ('netstat -ano ^| findstr /r /c:":10588.*LISTENING"') do (
    echo [backend] already running, PID %%i
    pause
    exit /b 0
)
start "toonflow-backend" /min cmd /c "cd /d D:\study\cartoon\Toonflow-app-master && yarn dev > D:\study\cartoon\logs\backend.log 2>&1"
echo [backend] starting... log: D:\study\cartoon\logs\backend.log
pause
