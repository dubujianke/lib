@echo off
chcp 65001 >nul
for /f "tokens=5" %%a in ('netstat -ano ^| findstr 4984') do taskkill /f /pid %%a 2>nul
cd /d D:\study\cartoon\Toonflow-app-master
echo 读取: D:\study\cartoon\Toonflow-app-master\.devtools\generations.json
echo 打开: http://localhost:4984
node D:\study\cartoon\Toonflow-app-master\node_modules\@ai-sdk\devtools\bin\cli.js
