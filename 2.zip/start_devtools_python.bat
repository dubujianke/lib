@echo off
chcp 65001 >nul
for /f "tokens=5" %%a in ('netstat -ano ^| findstr 4983') do taskkill /f /pid %%a 2>nul
cd /d D:\stock\novel\novel_to_script
echo 读取: D:\stock\novel\novel_to_script\.devtools\generations.json
echo 打开: http://localhost:4983
node D:\study\cartoon\Toonflow-app-master\node_modules\@ai-sdk\devtools\bin\cli.js
