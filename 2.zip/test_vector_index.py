# -*- coding: utf-8 -*-
"""vector_index.py 单元测试 — 对标 4.1.1 持久化层"""
import os
import sys
import tempfile
import json
import math

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from novel_writer.vector_index import (
    _quantize_int8,
    _dequantize_int8,
    _dot_product,
    _l2_norm,
    _l2_normalize,
    _l2_normalize_in_place,
    FileBasedVectorIndex,
    ChapterEmbeddingIndex,
    ChunkEmbeddingIndex,
    VectorSearchHit,
)


# ============================================================
# VectorMath 测试
# ============================================================

def test_quantize_int8_round_trip():
    vec = [0.1, -0.5, 0.8, -0.2, 0.0, 0.3, -0.7, 0.9, -0.05, 0.15]
    q, scale = _quantize_int8(vec)
    assert len(q) == len(vec)
    assert scale > 0
    assert all(-127 <= x <= 127 for x in q)
    recovered = _dequantize_int8(q, scale)
    assert len(recovered) == len(vec)
    for orig, rec in zip(vec, recovered):
        err = abs(orig - rec)
        assert err < abs(orig) * 0.05 + 0.02, f"quant error: orig={orig:.4f} rec={rec:.4f} err={err:.4f}"


def test_quantize_zero_vector():
    vec = [0.0, 0.0, 0.0]
    q, scale = _quantize_int8(vec)
    assert scale == 0.0
    assert all(x == 0 for x in q)
    recovered = _dequantize_int8(q, scale)
    assert all(abs(x) < 1e-10 for x in recovered)


def test_quantize_empty():
    q, scale = _quantize_int8([])
    assert q == []
    assert scale == 0.0


def test_quantize_clamp():
    vec = [100.0, -200.0, 0.5]
    q, scale = _quantize_int8(vec)
    assert all(-127 <= x <= 127 for x in q)


def test_dot_product():
    a = [1.0, 2.0, 3.0]
    b = [4.0, 5.0, 6.0]
    assert abs(_dot_product(a, b) - 32.0) < 1e-10


def test_dot_product_orthogonal():
    assert abs(_dot_product([1.0, 0.0], [0.0, 1.0])) < 1e-10


def test_l2_norm():
    assert abs(_l2_norm([3.0, 4.0]) - 5.0) < 1e-10


def test_l2_normalize():
    v = [3.0, 4.0]
    n = _l2_normalize(v)
    assert abs(_dot_product(n, n) - 1.0) < 1e-10
    assert abs(n[0] - 0.6) < 1e-10
    assert abs(n[1] - 0.8) < 1e-10


def test_l2_normalize_returns_copy():
    v = [3.0, 4.0]
    n = _l2_normalize(v)
    assert v == [3.0, 4.0]  # original unchanged
    assert n != v


def test_l2_normalize_in_place():
    v = [3.0, 4.0]
    assert _l2_normalize_in_place(v)
    assert abs(v[0] - 0.6) < 1e-10


def test_l2_normalize_zero():
    assert not _l2_normalize_in_place([0.0, 0.0])


# ============================================================
# FileBasedVectorIndex 测试
# ============================================================

def _make_vec(*vals):
    return list(vals)


def _new_index(subdir="") -> FileBasedVectorIndex:
    d = tempfile.mkdtemp()
    if subdir:
        d = os.path.join(d, subdir)
    path = os.path.join(d, "test_index.json")
    return FileBasedVectorIndex("Test", path)


def test_upsert():
    idx = _new_index()
    assert idx.upsert("a", _make_vec(0.1, 0.2))
    assert idx.count == 1
    assert idx.exists("a")
    assert idx.upsert("a", _make_vec(0.3, 0.4))
    assert idx.count == 1  # same key overwrites


def test_upsert_rejects_bad_input():
    idx = _new_index()
    assert not idx.upsert("", [0.1, 0.2])
    assert not idx.upsert(None, [0.1, 0.2])
    assert not idx.upsert("a", [])
    assert idx.count == 0


def test_upsert_dimension_mismatch():
    idx = _new_index()
    idx.upsert("a", _make_vec(0.1, 0.2, 0.3))
    assert not idx.upsert("b", _make_vec(0.1, 0.2))
    assert idx.count == 1


def test_upsert_batch():
    idx = _new_index()
    items = [("a", _make_vec(0.1, 0.2)), ("b", _make_vec(0.3, 0.4))]
    idx.upsert_batch(items)
    assert idx.count == 2


def test_remove():
    idx = _new_index()
    idx.upsert("a", _make_vec(0.1, 0.2))
    assert idx.remove("a")
    assert idx.count == 0
    assert not idx.exists("a")
    assert not idx.remove("a")


def test_get_all_keys():
    idx = _new_index()
    idx.upsert("a", _make_vec(0.1, 0.2))
    idx.upsert("b", _make_vec(0.3, 0.4))
    keys = idx.get_all_keys()
    assert set(keys) == {"a", "b"}


def test_search():
    idx = _new_index()
    idx.upsert("a", _make_vec(1.0, 0.0, 0.0))
    idx.upsert("b", _make_vec(0.0, 1.0, 0.0))
    idx.upsert("c", _make_vec(0.5, 0.5, 0.0))
    hits = idx.search(_make_vec(1.0, 0.0, 0.0), top_k=2)
    assert len(hits) == 2
    assert hits[0].key == "a"
    assert hits[0].score > hits[1].score


def test_search_empty():
    idx = _new_index()
    hits = idx.search([0.1, 0.2], top_k=5)
    assert hits == []


def test_search_zero_topk():
    idx = _new_index()
    idx.upsert("a", _make_vec(0.1, 0.2))
    assert idx.search([0.1, 0.2], top_k=0) == []


def test_try_get_vector():
    idx = _new_index()
    idx.upsert("a", _make_vec(0.1, 0.2))
    v = idx.try_get_vector("a")
    assert v == [0.1, 0.2]
    assert idx.try_get_vector("b") is None


def test_remove_many_by_predicate():
    idx = _new_index()
    idx.upsert("ch1#0", _make_vec(0.1, 0.2))
    idx.upsert("ch1#1", _make_vec(0.3, 0.4))
    idx.upsert("ch2#0", _make_vec(0.5, 0.6))
    r = idx.remove_many_by_predicate(lambda k: k.startswith("ch1#"))
    assert r == 2
    assert idx.count == 1
    assert idx.exists("ch2#0")


def test_invalidate_cache():
    idx = _new_index()
    idx.upsert("a", _make_vec(0.1, 0.2))
    idx.invalidate_cache()
    assert idx.count == 0


def test_save_load_round_trip():
    idx = _new_index()
    idx.upsert("a", _make_vec(0.5, 0.5, 0.5))
    idx.upsert("b", _make_vec(-0.2, 0.8, -0.2))
    idx.save()

    idx2 = FileBasedVectorIndex("Test", idx.file_path)
    idx2.load()
    assert idx2.count == 2
    assert idx2.exists("a")
    assert idx2.exists("b")

    # Verify vector approximate integrity after quantize→dequantize→normalize
    v = idx2.try_get_vector("a")
    assert v is not None
    # Normalized: each component should be ~1/sqrt(3) = 0.577
    assert abs(abs(v[0]) - 1.0 / math.sqrt(3)) < 0.05


def test_save_load_empty():
    idx = _new_index()
    idx.save()
    idx2 = FileBasedVectorIndex("Test", idx.file_path)
    idx2.load()
    assert idx2.count == 0


def test_save_load_bak_fallback():
    idx = _new_index()
    idx.upsert("a", _make_vec(0.1, 0.2))
    idx.save()
    # Second save to create .bak
    idx.upsert("b", _make_vec(0.3, 0.4))
    idx.save()

    # Corrupt the main file, ensure .bak fallback works
    with open(idx.file_path, "w") as f:
        f.write("not valid json")

    idx2 = FileBasedVectorIndex("Test", idx.file_path)
    idx2.load()
    # .bak should have entries from the first save (only "a")
    assert idx2.count == 1
    assert idx2.exists("a")


# ============================================================
# ChapterEmbeddingIndex 测试
# ============================================================

def test_chapter_embedding_index():
    d = tempfile.mkdtemp()
    idx = ChapterEmbeddingIndex(d)
    assert idx.file_path.endswith("chapter_embeddings.json")
    idx.upsert("C001", _make_vec(0.1, 0.2))
    idx.upsert("C002", _make_vec(0.3, 0.4))
    idx.save()
    assert os.path.exists(idx.file_path)

    idx2 = ChapterEmbeddingIndex(d)
    idx2.load()
    assert idx2.count == 2


# ============================================================
# ChunkEmbeddingIndex 测试
# ============================================================

def test_chunk_key_format_parse():
    assert ChunkEmbeddingIndex._format_chunk_key("C001", 5) == "C001#5"
    cid, pos = ChunkEmbeddingIndex._parse_chunk_key("C001#5")
    assert cid == "C001"
    assert pos == 5


def test_chunk_key_parse_invalid():
    assert ChunkEmbeddingIndex._parse_chunk_key("") == ("", -1)
    assert ChunkEmbeddingIndex._parse_chunk_key("abc") == ("", -1)
    assert ChunkEmbeddingIndex._parse_chunk_key("#5") == ("", -1)
    assert ChunkEmbeddingIndex._parse_chunk_key("C001#") == ("", -1)
    assert ChunkEmbeddingIndex._parse_chunk_key("C001#-1") == ("", -1)


def test_chunk_index_upsert_and_get_by_chapter():
    d = tempfile.mkdtemp()
    idx = ChunkEmbeddingIndex(d)
    k0 = idx._format_chunk_key("C001", 0)
    k1 = idx._format_chunk_key("C001", 1)
    k2 = idx._format_chunk_key("C002", 0)
    idx.upsert(k0, _make_vec(0.1, 0.2))
    idx.upsert(k1, _make_vec(0.3, 0.4))
    idx.upsert(k2, _make_vec(0.5, 0.6))
    assert idx.count == 3

    ch1 = idx.get_by_chapter("C001")
    assert len(ch1) == 2
    assert ch1[0][1] == 0  # position sorted
    assert ch1[1][1] == 1

    ch2 = idx.get_by_chapter("C002")
    assert len(ch2) == 1

    assert idx.get_by_chapter("C999") == []


def test_chunk_index_remove_by_chapter():
    d = tempfile.mkdtemp()
    idx = ChunkEmbeddingIndex(d)
    idx.upsert(idx._format_chunk_key("C001", 0), _make_vec(0.1, 0.2))
    idx.upsert(idx._format_chunk_key("C001", 1), _make_vec(0.3, 0.4))
    idx.upsert(idx._format_chunk_key("C002", 0), _make_vec(0.5, 0.6))

    removed = idx.remove_by_chapter("C001")
    assert removed == 2
    assert idx.count == 1
    assert idx.get_by_chapter("C001") == []


def test_chunk_index_search_within_chapters():
    d = tempfile.mkdtemp()
    idx = ChunkEmbeddingIndex(d)
    idx.upsert(idx._format_chunk_key("C001", 0), _make_vec(1.0, 0.0, 0.0))
    idx.upsert(idx._format_chunk_key("C001", 1), _make_vec(0.0, 1.0, 0.0))
    idx.upsert(idx._format_chunk_key("C002", 0), _make_vec(0.0, 0.0, 1.0))

    hits = idx.search_within_chapters(
        _make_vec(1.0, 0.0, 0.0),
        chapter_ids=["C001"],
        top_k=2,
    )
    assert len(hits) == 2
    assert hits[0].key == idx._format_chunk_key("C001", 0)

    # Search across chapters
    hits2 = idx.search_within_chapters(
        _make_vec(0.0, 0.0, 1.0),
        chapter_ids=["C001", "C002"],
        top_k=1,
    )
    assert len(hits2) == 1
    assert "C002" in hits2[0].key


def test_chunk_index_save_load_preserves_chapter_keys():
    d = tempfile.mkdtemp()
    idx = ChunkEmbeddingIndex(d)
    idx.upsert(idx._format_chunk_key("C001", 0), _make_vec(0.1, 0.2))
    idx.upsert(idx._format_chunk_key("C001", 1), _make_vec(0.3, 0.4))
    idx.save()

    idx2 = ChunkEmbeddingIndex(d)
    idx2.load()
    assert idx2.count == 2
    ch1 = idx2.get_by_chapter("C001")
    assert len(ch1) == 2


def test_chunk_index_invalidate_clears_chapter_keys():
    d = tempfile.mkdtemp()
    idx = ChunkEmbeddingIndex(d)
    idx.upsert(idx._format_chunk_key("C001", 0), _make_vec(0.1, 0.2))
    idx.invalidate_cache()
    assert idx.count == 0
    assert idx.get_by_chapter("C001") == []


# ============================================================
# JSON format compliance test
# ============================================================

def test_json_format_compliance():
    idx = _new_index()
    idx.upsert("test_key", _make_vec(0.1, 0.2, 0.3))
    idx.save()

    with open(idx.file_path, "r", encoding="utf-8") as f:
        dto = json.load(f)

    assert dto["version"] == 1
    assert dto["dimension"] == 3
    assert dto["quantization"] == "int8_symmetric"
    assert len(dto["entries"]) == 1
    entry = dto["entries"][0]
    assert entry["key"] == "test_key"
    assert "vector_b64" in entry
    assert "scale" in entry
    assert "updated_at" in entry


if __name__ == "__main__":
    import traceback

    tests = [name for name in dir() if name.startswith("test_")]
    passed = 0
    failed = 0

    for name in sorted(tests):
        fn = globals()[name]
        try:
            fn()
            passed += 1
            print(f"  [PASS] {name}")
        except Exception:
            failed += 1
            print(f"  [FAIL] {name}")
            traceback.print_exc()

    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed")
    print(f"{'='*50}")
    if failed > 0:
        sys.exit(1)
