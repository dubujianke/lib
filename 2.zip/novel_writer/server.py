# -*- coding: utf-8 -*-
"""FastAPI 后端 — 暴露创作管线 API + SSE 进度推送"""
import json
import os
import re
import sys
import time
import threading
from typing import Optional

from fastapi import FastAPI, Query, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ai_client import AIClient
from novel_writer.ai_service import AIService
from novel_writer.prompt_library import PromptLibrary
from novel_writer.pipeline import NovelPipeline
from novel_writer.storage import Project, create_project, get_projects
from novel_writer.unified_validation import UnifiedValidation
from novel_writer.book_pipeline_v4 import ChaishuPipeline4, DATA_ROOT, OUTPUT_ROOT
from novel_writer.config_loader import load_config, build_creative_spec

app = FastAPI(title="天命 AI 网文创作引擎", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

import logging
logging.basicConfig(level=logging.INFO, format="[%(asctime)s] %(message)s", datefmt="%H:%M:%S")
_log = logging.getLogger("server")

@app.middleware("http")
async def log_requests(request, call_next):
    if "/api/" in str(request.url):
        print(f"[请求] {request.method} {request.url.path}", flush=True)
    return await call_next(request)

_ai = AIService()
_lib = PromptLibrary()
_projects: dict = {}

# AI 调用日志目录
import os as _os

def _init_devtools_tracker():
    try:
        from .devtools_tracker import DevToolsTracker
        return DevToolsTracker(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
    except Exception as e:
        print(f"[启动] DevTools tracker 不可用: {e}", flush=True)
        return None

_ai.client.log_dir = _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), "ai_logs")
_os.makedirs(_ai.client.log_dir, exist_ok=True)

# AI SDK DevTools 追踪（生成 .devtools/generations.json）
_ai.client._tracker = _init_devtools_tracker()

# 启动日志
print(f"[启动] model={_ai.client.config.model} url={_ai.client.config.base_url} log={_ai.client.log_dir}", flush=True)

# ============ 进度事件支持 ============

_progress_queues: dict = {}  # task_id -> list[dict]
_progress_lock = threading.Lock()

# ============ 全局日志推送（前端实时可见） ============

_log_queue: list = []
_log_lock = threading.Lock()
_MAX_LOG = 200


def _blog(msg: str):
    """全局日志：后端 print + 前端 SSE 广播"""
    import datetime
    ts = datetime.datetime.now().strftime("%H:%M:%S")
    print(f"[{ts}] {msg}", flush=True)
    with _log_lock:
        _log_queue.append({"time": ts, "msg": msg})
        if len(_log_queue) > _MAX_LOG:
            _log_queue.pop(0)

    # 也推送到进度队列让各任务的 SSE 能收到
    with _progress_lock:
        for task_id in _progress_queues:
            _progress_queues[task_id].append({"event": "log", "data": {"msg": msg}})


@app.get("/api/logs/stream")
def logs_stream():
    """全局日志 SSE 流"""
    def _stream():
        last = 0
        while True:
            with _log_lock:
                new = _log_queue[last:]
                last = len(_log_queue)
            for item in new:
                yield f"data: {json.dumps(item, ensure_ascii=False)}\n\n"
            time.sleep(0.5)
    return StreamingResponse(_stream(), media_type="text/event-stream")


def _emit(task_id: str, event: str, data: dict):
    with _progress_lock:
        q = _progress_queues.setdefault(task_id, [])
        q.append({"event": event, "data": data})


def _get_project(name: str = "novel_output") -> Project:
    if name not in _projects:
        _projects[name] = create_project(name)
    return _projects[name]


# ============ API 模型 ============

class BookAnalysisRequest(BaseModel):
    book_id: str = "1"

class DesignRequest(BaseModel):
    project_name: str = "novel_output"
    genre: str = "玄幻"
    concept: str = ""
    total_volumes: int = 3
    total_chapters: int = 30
    char_count: int = 3

class PlanRequest(BaseModel):
    project_name: str = "novel_output"
    genre: str = "玄幻"
    total_chapters: int = 30

class ChapterRequest(BaseModel):
    project_name: str = "novel_output"
    genre: str = "玄幻"
    word_count: int = 3000
    start_chapter: int = 1
    count: int = 5

class ProjectCreateRequest(BaseModel):
    name: str


# ============ 拆书相关 ============

@app.get("/api/books")
def list_books():
    """列出可拆的小说"""
    books = []
    if os.path.isdir(DATA_ROOT):
        for d in sorted(os.listdir(DATA_ROOT)):
            dpath = os.path.join(DATA_ROOT, d)
            if not os.path.isdir(dpath):
                continue
            info_path = os.path.join(dpath, "book_info.json")
            info = {}
            if os.path.exists(info_path):
                try:
                    with open(info_path, "r", encoding="utf-8") as f:
                        info = json.load(f)
                except Exception:
                    pass
            chapter_files = [f for f in os.listdir(dpath) if f.endswith(".txt") and f[0].isdigit()]
            books.append({
                "id": d,
                "title": info.get("title", d),
                "author": info.get("author", ""),
                "category": info.get("category", ""),
                "chapters": len(chapter_files),
            })
    return books


@app.post("/api/book/analyze")
def analyze_book(req: BookAnalysisRequest):
    """拆书分析（异步，通过SSE返回进度）"""
    task_id = f"chaishu_{req.book_id}_{int(time.time())}"

    def _run():
        print(f"[拆书] 开始 book_id={req.book_id}", flush=True)
        try:
            _emit(task_id, "start", {"book_id": req.book_id})
            p = ChaishuPipeline4(req.book_id)

            _emit(task_id, "essence", {"total": p.total})
            p.select_essence(10)
            _emit(task_id, "essence_done", {})

            _emit(task_id, "excerpt", {})
            p.build_excerpt()
            _emit(task_id, "excerpt_done", {})

            _emit(task_id, "analysis", {})
            analysis = p.analyze_book()
            _emit(task_id, "analysis_done", {"fields": len([k for k in analysis if k != "error" and analysis[k]])})

            _emit(task_id, "refine", {})
            refined = p.refine_all()
            _emit(task_id, "refine_done", {"modules": len(refined)})

            _emit(task_id, "materials", {})
            mats = p.generate_materials()
            _emit(task_id, "materials_done", {"synopsis": mats.get("NovelSynopsis", "")[:80]})

            # 导出 novel_config
            config_path = os.path.join(os.path.dirname(OUTPUT_ROOT), f"novel_config_{req.book_id}.json")
            p.export_to_novel_config(config_path)
            _emit(task_id, "config", {"path": config_path})

            _emit(task_id, "done", {
                "output": p.out,
                "book_title": p.book_title,
                "config_path": config_path,
            })
        except Exception as e:
            _emit(task_id, "error", {"message": str(e)})

    threading.Thread(target=_run, daemon=True).start()
    return {"task_id": task_id}


@app.get("/api/book/progress/{task_id}")
def book_progress(task_id: str):
    """SSE 进度推送"""
    def _stream():
        last_idx = 0
        while True:
            with _progress_lock:
                q = _progress_queues.get(task_id, [])
                new = q[last_idx:]
                last_idx = len(q)
            for item in new:
                yield f"event: {item['event']}\ndata: {json.dumps(item['data'], ensure_ascii=False)}\n\n"
                if item["event"] in ("done", "error"):
                    with _progress_lock:
                        _progress_queues.pop(task_id, None)
                    return
            time.sleep(0.5)
    return StreamingResponse(_stream(), media_type="text/event-stream")


@app.get("/api/book/analysis/{book_id}")
def get_analysis(book_id: str):
    """获取已有的拆书分析数据"""
    out = os.path.join(OUTPUT_ROOT, "CrawledBooks", book_id)
    result = {"book_id": book_id}
    for fname in ["essence_chapters.json", "analysis.json", "materials.json",
                  "refined_worldrules.json", "refined_characters.json", "refined_factions.json",
                  "refined_locations.json", "refined_plotrules.json"]:
        path = os.path.join(out, fname)
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    result[fname.replace(".json", "")] = json.load(f)
            except Exception:
                result[fname.replace(".json", "")] = None
    # novel_config
    config_path = os.path.join(os.path.dirname(OUTPUT_ROOT), f"novel_config_{book_id}.json")
    if os.path.exists(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                result["novel_config"] = json.load(f)
        except Exception:
            result["novel_config"] = None
    return result


# ============ 五维设计 ============

@app.post("/api/design/generate")
def generate_design(req: DesignRequest):
    """AI 生成五维设计"""
    project = _get_project(req.project_name)
    pipeline = NovelPipeline(project, _ai, _lib)
    result = pipeline.generate_design(req.genre, req.concept, req.total_volumes, req.total_chapters, req.char_count)
    return {
        "success": True,
        "world": result["world"].to_dict(),
        "characters": [c.to_dict() for c in result["characters"]],
        "factions": [f.to_dict() for f in result["factions"]],
        "locations": [l.to_dict() for l in result["locations"]],
        "plot": result["plot"].to_dict(),
    }


@app.post("/api/design/import")
def import_design(req: BookAnalysisRequest):
    """从拆书数据导入设计"""
    p = ChaishuPipeline4(req.book_id)
    project = _get_project("novel_output")
    from novel_writer.models.common import short_id

    module_map = {
        "worldrules": ("world", ["Name", "OneLineSummary", "PowerSystem", "Cosmology", "SpecialLaws",
                                  "HardRules", "SoftRules", "AncientEra", "KeyEvents", "ModernHistory", "StatusQuo"]),
        "characters": ("characters", ["Name", "CharacterType", "Gender", "Age", "Identity", "Race",
                                       "Appearance", "Personality", "Want", "Need", "FlawBelief",
                                       "GrowthPath", "CombatSkills", "SpecialAbilities", "SignatureItems"]),
        "factions": ("factions", ["Name", "FactionType", "Goal", "StrengthTerritory", "Leader",
                                   "CoreMembers", "MemberTraits", "Allies", "Enemies", "NeutralCompetitors"]),
        "locations": ("locations", ["Name", "LocationType", "Description", "Scale", "Terrain",
                                     "Climate", "Landmarks", "Resources", "HistoricalSignificance", "Dangers"]),
        "plotrules": ("plot", ["Name", "TargetVolume", "OneLineSummary", "EventType", "StoryPhase",
                                "MainCharacters", "KeyNpcs", "Goal", "Conflict", "Result", "EmotionCurve"]),
    }

    total = 0
    for module, (entity, fields) in module_map.items():
        path = os.path.join(p.out, f"refined_{module}.json")
        if not os.path.exists(path):
            continue
        with open(path, "r", encoding="utf-8") as f:
            items = json.load(f)
        if not items:
            continue
        id_prefix = {"world": "W", "characters": "C", "factions": "F", "locations": "L", "plot": "P"}.get(entity, "D")
        for item in items:
            item["Id"] = short_id(id_prefix)
            item["IsEnabled"] = True
        project.save_design(entity, {"items": items})
        total += len(items)

    return {"success": True, "imported": total}


# ============ 四层规划 ============

@app.post("/api/plan/generate")
def generate_plan(req: PlanRequest):
    """AI 生成四层规划"""
    project = _get_project(req.project_name)
    pipeline = NovelPipeline(project, _ai, _lib)
    plan = pipeline.generate_plan(req.genre, req.total_chapters)
    vols = plan.get("volumes", [])
    chs = plan.get("chapters", [])
    return {
        "success": True,
        "volumes": len(vols),
        "chapters": len(chs),
        "volume_list": [v.to_dict() if hasattr(v, 'to_dict') else v for v in vols[:5]],
        "chapter_list": [c.to_dict() if hasattr(c, 'to_dict') else c for c in chs[:10]],
    }


# ============ 章节生成 ============

@app.post("/api/chapter/generate")
def generate_chapters(req: ChapterRequest):
    """生成章节（异步SSE）"""
    task_id = f"write_{req.project_name}_{int(time.time())}"

    def _run():
        try:
            project = _get_project(req.project_name)
            pipeline = NovelPipeline(project, _ai, _lib)

            _emit(task_id, "start", {"total": req.count, "word_count": req.word_count})

            results = pipeline.generate_all_chapters(
                req.genre, req.start_chapter, None, word_count=req.word_count)

            for i, r in enumerate(results):
                _emit(task_id, "chapter", {
                    "index": i + 1,
                    "chapter": req.start_chapter + i,
                    "title": r.get("title", f"第{req.start_chapter + i}章"),
                    "word_count": len(r.get("content", "")),
                })

            _emit(task_id, "done", {"generated": len(results)})
        except Exception as e:
            _emit(task_id, "error", {"message": str(e)})

    threading.Thread(target=_run, daemon=True).start()
    return {"task_id": task_id}


# ============ 统一校验 ============

@app.get("/api/validate/{project_name}")
def validate(project_name: str):
    """全书校验"""
    project = _get_project(project_name)
    uv = UnifiedValidation(project, _ai)
    report = uv.validate_all()
    return report


# ============ 项目管理 ============

@app.get("/api/projects")
def list_projects():
    names = get_projects()
    result = []
    for name in names:
        p = Project(name)
        design_count = sum(1 for f in ["world", "characters", "factions", "locations", "plot"]
                          if os.path.exists(p.design_path(f)))
        chapter_count = len([f for f in os.listdir(p.generated_dir)
                             if f.endswith(".md")]) if os.path.exists(p.generated_dir) else 0
        result.append({
            "name": name,
            "designs": design_count,
            "chapters": chapter_count,
        })
    return result


@app.post("/api/projects")
def create_project_handler(req: ProjectCreateRequest):
    p = create_project(req.name)
    _projects[req.name] = p
    return {"success": True, "name": req.name}


@app.get("/api/projects/{name}")
def get_project_detail(name: str):
    p = _get_project(name)
    designs = {}
    for entity in ["world", "characters", "factions", "locations", "plot"]:
        data = p.load_design(entity)
        if isinstance(data, dict) and "items" in data:
            designs[entity] = data["items"]
        elif isinstance(data, list):
            designs[entity] = data
    chapters = []
    if os.path.exists(p.generated_dir):
        for f in sorted(os.listdir(p.generated_dir)):
            if f.endswith(".md"):
                path = os.path.join(p.generated_dir, f)
                chapters.append({
                    "filename": f,
                    "size": os.path.getsize(path),
                    "preview": open(path, "r", encoding="utf-8").read()[:200] if os.path.getsize(path) > 0 else "",
                })
    return {"name": name, "designs": designs, "chapters": chapters}


@app.post("/api/projects/{name}/novel_config")
def export_novel_config(name: str, book_id: str = "1"):
    """从拆书数据导出 novel_config"""
    p = ChaishuPipeline4(book_id)
    config_path = os.path.join(os.path.dirname(OUTPUT_ROOT), f"novel_config_{book_id}.json")
    config = p.export_to_novel_config(config_path)
    return {"success": True, "path": config_path, "config": config}


# ============ 情节提取（对标 Toonflow） ============

from novel_writer.plot_extraction import EventExtractor, StorySkeleton, ScriptGenerator
from novel_writer.book_reader import BookReader
from novel_writer.book_pipeline_v4 import DATA_ROOT, OUTPUT_ROOT as BOOKS_OUT

# 情节提取独立输出目录（对标 Toonflow）
PLOT_OUT = os.path.join(BOOKS_OUT, "plot_extraction")

# 跨轮记忆缓存（对标 memoryKey）
_skeleton_cache: dict = {}  # book_id -> StorySkeleton 实例

# 骨架生成默认配置
import os as _os
_PLOT_CONFIG_PATH = _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), "plot_config.json")
_PLOT_DEFAULTS = {"genre": "玄幻", "total_episodes": 10, "episode_seconds": 120, "free_episodes": 3, "aspect_ratio": "9:16"}

def _load_plot_config() -> dict:
    """读取 plot_config.json，合并默认值"""
    cfg = dict(_PLOT_DEFAULTS)
    if _os.path.exists(_PLOT_CONFIG_PATH):
        try:
            with open(_PLOT_CONFIG_PATH, "r", encoding="utf-8") as f:
                cfg.update(json.load(f))
        except Exception:
            pass
    return cfg



@app.post("/api/plot/events/extract")
def extract_events(book_id: str = "1", start: int = 1, end: int = 0):
    """逐章事件提取（异步SSE）"""
    task_id = f"events_{book_id}_{int(time.time())}"
    print(f"[事件提取] 请求 book_id={book_id} start={start} end={end}", flush=True)
    book_path = os.path.join(DATA_ROOT, book_id)
    out_dir = os.path.join(PLOT_OUT, book_id)

    def _run():
        try:
            print(f"[事件提取] 开始 book_id={book_id} start={start} end={end}", flush=True)
            reader = BookReader(DATA_ROOT)
            chapters = reader.get_chapters(book_path)
            print(f"[事件提取] 共 {len(chapters)} 章", flush=True)
            ext = EventExtractor(_ai.client, book_path, chapters, out_dir)
            total = end if end > 0 else ext.total
            _emit(task_id, "start", {"total": total})

            def on_progress(current, total_):
                _emit(task_id, "progress", {"current": current, "total": total_})
                if current % 10 == 0 or current == total_:
                    print(f"[事件提取] 进度 {current}/{total_}", flush=True)

            events = ext.extract(start=start, end=end, progress_callback=on_progress)

            _emit(task_id, "done", {
                "count": len(events),
                "path": os.path.join(out_dir, "chapter_events.json"),
                "events": [e.to_dict() for e in events[:10]],
            })
        except Exception as e:
            _emit(task_id, "error", {"message": str(e)})

    threading.Thread(target=_run, daemon=True).start()
    return {"task_id": task_id}


@app.post("/api/plot/skeleton/build")
def build_skeleton(book_id: str = "1", total_episodes: int = None,
                     episode_seconds: int = None, genre: str = None,
                     free_episodes: int = None, aspect_ratio: str = None):
    """构建故事骨架（异步SSE）。参数可覆盖 plot_config.json 默认值"""
    cfg = _load_plot_config()
    total_episodes = total_episodes if total_episodes is not None else cfg["total_episodes"]
    episode_seconds = episode_seconds if episode_seconds is not None else cfg["episode_seconds"]
    genre = genre or cfg["genre"]
    free_episodes = free_episodes if free_episodes is not None else cfg["free_episodes"]
    aspect_ratio = aspect_ratio or cfg["aspect_ratio"]
    task_id = f"skeleton_{book_id}_{int(time.time())}"
    print(f"[骨架构建] 请求 book_id={book_id} 集数={total_episodes} 时长={episode_seconds}s 题材={genre}", flush=True)
    out_dir = os.path.join(PLOT_OUT, book_id)

    def _run():
        try:
            # 加载事件数据
            events_path = os.path.join(out_dir, "chapter_events.json")
            if not os.path.exists(events_path):
                _emit(task_id, "error", {"message": "请先运行事件提取"})
                return

            with open(events_path, "r", encoding="utf-8") as f:
                events = json.load(f)

            _emit(task_id, "start", {"event_count": len(events)})

            # 复用或创建实例（对标 memoryKey 保持跨轮记忆）
            cache_key = book_id
            if cache_key not in _skeleton_cache:
                _skeleton_cache[cache_key] = StorySkeleton(
                    _ai.client, events, out_dir,
                    total_episodes=total_episodes,
                    episode_seconds=episode_seconds,
                    genre=genre, free_episodes=free_episodes,
                    aspect_ratio=aspect_ratio)
            sk = _skeleton_cache[cache_key]
            # 更新参数
            sk.total_episodes = total_episodes
            sk.episode_seconds = episode_seconds
            sk.genre = genre
            data = sk.build()

            if data:
                _emit(task_id, "done", {
                    "storyCore": data.get("storyCore", {}),
                    "characterCount": len(data.get("characters", [])),
                    "chapterCount": len(data.get("chapters", [])),
                    "acts": len(data.get("threeActs", [])),
                })
            else:
                _emit(task_id, "error", {"message": "骨架构建失败"})
        except Exception as e:
            _emit(task_id, "error", {"message": str(e)})

    threading.Thread(target=_run, daemon=True).start()
    return {"task_id": task_id}


@app.get("/api/plot/events/{book_id}")
def get_events(book_id: str):
    """获取事件数据"""
    path = os.path.join(PLOT_OUT, book_id, "chapter_events.json")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return []


@app.post("/api/plot/skeleton/verify")
def verify_skeleton(book_id: str = "1"):
    """监督层审核骨架"""
    out_dir = os.path.join(PLOT_OUT, book_id)
    events_path = os.path.join(out_dir, "chapter_events.json")
    if not os.path.exists(events_path):
        return {"error": "请先提取事件"}
    with open(events_path, "r", encoding="utf-8") as f:
        events = json.load(f)
    if book_id in _skeleton_cache:
        sk = _skeleton_cache[book_id]
    else:
        sk = StorySkeleton(_ai.client, events, out_dir)
        _skeleton_cache[book_id] = sk
    sk.data = sk.load()
    return sk.verify()

@app.post("/api/plot/skeleton/repair")
def repair_skeleton(book_id: str = "1", instructions: str = ""):
    """基于审核意见修复骨架（对标 Toonflow 第二轮修复）"""
    out_dir = os.path.join(PLOT_OUT, book_id)
    events_path = os.path.join(out_dir, "chapter_events.json")
    sk_path = os.path.join(out_dir, "story_skeleton.json")
    
    if not os.path.exists(events_path):
        return {"error": "请先提取事件"}
    if not os.path.exists(sk_path):
        return {"error": "请先构建骨架"}
    
    with open(events_path, "r", encoding="utf-8") as f:
        events = json.load(f)
    
    # 使用缓存实例（对标 memoryKey 保持跨轮记忆）
    if book_id in _skeleton_cache:
        sk = _skeleton_cache[book_id]
    else:
        sk = StorySkeleton(_ai.client, events, out_dir)
        _skeleton_cache[book_id] = sk
    sk.data = sk.load()
    existing_skeleton = sk.data.get("markdown", "")
    review = sk.data.get("review", "")
    
    # 对标 Toonflow: AI 通过 get_planData 自己取旧骨架和审核
    repair_prompt = (
        f"请基于审核意见优化故事骨架：{instructions}\n\n"
        f"请先调用 get_planData 获取现有骨架和审核报告，"
        f"再调用 get_novel_events 获取事件数据，"
        f"然后输出修复后的 <storySkeleton> XML 骨架。"
    )
    
    # 重新生成（AI 会看到之前的骨架和审核意见）
    result = sk.build(prompt=repair_prompt)
    if result:
        sk.data["repair_round"] = sk.data.get("repair_round", 0) + 1
        sk._save()
    return {"success": True, "result": result}


@app.get("/api/plot/skeleton/{book_id}")
def get_skeleton(book_id: str):
    """获取故事骨架"""
    path = os.path.join(PLOT_OUT, book_id, "story_skeleton.json")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


@app.post("/api/plot/scripts/generate")
def generate_scripts(book_id: str = "1", total_episodes: int = 0, episode_seconds: int = 90):
    """剧本生成（异步SSE）"""
    task_id = f"script_{book_id}_{int(time.time())}"
    print(f"[剧本生成] 请求 book_id={book_id} total_episodes={total_episodes} episode_seconds={episode_seconds}", flush=True)
    out_dir = os.path.join(PLOT_OUT, book_id)

    def _run():
        try:
            events_path = os.path.join(out_dir, "chapter_events.json")
            sk_path = os.path.join(out_dir, "story_skeleton.json")
            if not os.path.exists(events_path):
                _emit(task_id, "error", {"message": "请先提取事件"})
                return
            if not os.path.exists(sk_path):
                _emit(task_id, "error", {"message": "请先构建骨架"})
                return

            with open(events_path, "r", encoding="utf-8") as f:
                events = json.load(f)
            with open(sk_path, "r", encoding="utf-8") as f:
                skeleton = json.load(f)

            # 原文读取器（对标 get_novel_text）
            def get_chapter_text(chapter_range: str) -> str:
                parts = []
                for part in chapter_range.replace("，", ",").split(","):
                    m = re.search(r"(\d+)", part)
                    if m:
                        n = int(m.group(1))
                        fpath = os.path.join(DATA_ROOT, book_id, f"{n}.txt")
                        if os.path.exists(fpath):
                            with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                                parts.append(f.read()[:3000])
                return "\n\n".join(parts)

            sg = ScriptGenerator(_ai.client, events, skeleton, out_dir,
                                  novel_text_getter=get_chapter_text,
                                  total_episodes=total_episodes, episode_seconds=episode_seconds)
            total = total_episodes if total_episodes > 0 else len(skeleton.get("chapters", events))
            _emit(task_id, "start", {"total": total})

            for i in range(1, total + 1):
                ep_info = {}
                for item in skeleton.get("chapters", []):
                    if item.get("episode") == i:
                        ep_info = item
                        break
                script = sg.generate_episode(i, ep_info)
                if script:
                    _emit(task_id, "episode", script)

            scripts = sg.generate_all(target_episodes) if target_episodes <= 0 else sg.load()
            _emit(task_id, "done", {"count": len(scripts)})
        except Exception as e:
            _emit(task_id, "error", {"message": str(e)})

    threading.Thread(target=_run, daemon=True).start()
    return {"task_id": task_id}


@app.get("/api/plot/scripts/{book_id}")
def get_scripts(book_id: str):
    path = os.path.join(PLOT_OUT, book_id, "scripts.json")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return []


# ============ 启动 ============

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8777)
