# -*- coding: utf-8 -*-
"""对标 4.1.1 FactSnapshotExtractor: 15维快照 — 并行抽取 + 注入上限 + 活跃角色补充"""
import concurrent.futures
import re
from typing import List

from .models import (
    FactSnapshot, CharacterStateEntry, ConflictProgressEntry, ForeshadowingEntry,
    PlotPointEntry, LocationStateEntry, FactionStateEntry, TimeEntry,
    CharacterLocationEntry, ItemStateEntry, SecretEntry, PledgeEntry, DeadlineEntry,
    WorldRuleConstraint, CharacterDescription, LocationDescription,
)


class SnapshotExtractor:
    def __init__(self, project):
        self.project = project
        self._design_cache = {}
        self._guides_cache = {}

    def _design(self, entity: str) -> dict:
        if entity not in self._design_cache:
            self._design_cache[entity] = self.project.load_design(entity)
        return self._design_cache[entity]

    def _guide(self, name: str) -> dict:
        if name not in self._guides_cache:
            self._guides_cache[name] = self.project.guide(name).data()
        return self._guides_cache[name]

    def _tracking(self, name: str) -> dict:
        if name not in self._guides_cache:
            self._guides_cache[name] = self.project.tracking(name).data()
        return self._guides_cache[name]

    def extract(self, chapter_id: str, chapter_number: int) -> FactSnapshot:
        """对标 ExtractSnapshotAsync: 15维并行抽取"""
        # 注入上限（对标 LayeredContextConfig）
        limits = {"char": 30, "conflict": 15, "foreshadow": 20, "location": 15,
                  "faction": 15, "item": 15, "secret": 10, "pledge": 10, "deadline": 10}
        snapshot = FactSnapshot()

        # 15维并行抽取
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            futures = {
                "chars": pool.submit(self._extract_characters, chapter_number),
                "conflicts": pool.submit(self._extract_conflicts),
                "foreshadowings": pool.submit(self._extract_foreshadowings),
                "plot_points": pool.submit(self._extract_plot_points),
                "char_descs": pool.submit(self._extract_character_descriptions),
                "loc_descs": pool.submit(self._extract_location_descriptions),
                "world_rules": pool.submit(self._extract_world_constraints),
                "loc_states": pool.submit(self._extract_location_states),
                "fac_states": pool.submit(self._extract_faction_states),
                "timeline": pool.submit(self._extract_timeline),
                "char_locs": pool.submit(self._extract_character_locations),
                "items": pool.submit(self._extract_items),
                "secrets": pool.submit(self._extract_secrets),
                "pledges": pool.submit(self._extract_pledges),
                "deadlines": pool.submit(self._extract_deadlines),
            }

            snapshot.CharacterStates = self._limit(futures["chars"].result(), limits["char"])
            snapshot.ConflictProgress = self._limit(futures["conflicts"].result(), limits["conflict"])
            snapshot.ForeshadowingStatus = self._limit(futures["foreshadowings"].result(), limits["foreshadow"])
            snapshot.PlotPoints = futures["plot_points"].result()
            snapshot.CharacterDescriptions = futures["char_descs"].result()
            snapshot.LocationDescriptions = futures["loc_descs"].result()
            snapshot.WorldRuleConstraints = futures["world_rules"].result()
            snapshot.LocationStates = self._limit(futures["loc_states"].result(), limits["location"])
            snapshot.FactionStates = futures["fac_states"].result()
            snapshot.Timeline = futures["timeline"].result()
            snapshot.CharacterLocations = futures["char_locs"].result()
            snapshot.ItemStates = self._limit(futures["items"].result(), limits["item"])
            snapshot.SecretStates = self._limit(futures["secrets"].result(), limits["secret"])
            snapshot.PledgeStates = self._limit(futures["pledges"].result(), limits["pledge"])
            snapshot.DeadlineStates = self._limit(futures["deadlines"].result(), limits["deadline"])

        # 对标: 活跃角色补充描述
        self._inject_active_char_descriptions(snapshot)

        # 对标 ApplyRelevanceLimit: 相关性排序（逾期优先、关联角色优先、最近章节优先）
        self._apply_relevance_limit(snapshot)

        return snapshot

    def _apply_relevance_limit(self, snapshot: FactSnapshot):
        """对标 ApplyRelevanceLimit: 逾期优先、关联角色优先、最近章节优先"""
        # 伏笔：逾期优先
        if snapshot.ForeshadowingStatus:
            snapshot.ForeshadowingStatus.sort(
                key=lambda f: (not f.IsOverdue, not f.IsSetup, f.IsResolved))
        # 冲突：最近章节优先
        if snapshot.ConflictProgress:
            snapshot.ConflictProgress.sort(key=lambda c: -c.LastChapter)
        # 角色：最近活跃优先
        if snapshot.CharacterStates:
            snapshot.CharacterStates.sort(key=lambda c: -c.LastChapter)

        # 对标 ApplyRelevanceLimit<T>: 秘密/誓约/倒计时 — 3层排序注入上限
        active_char_ids = {c.CharacterId for c in snapshot.CharacterStates}
        snapshot.SecretStates = self._apply_limit_3tier(
            snapshot.SecretStates, max_inject=8, priority_ids=active_char_ids,
            party_accessor=lambda s: (s.KnowerIds or []),
            chapter_accessor=lambda s: s.LastChapter)
        snapshot.PledgeStates = self._apply_limit_3tier(
            snapshot.PledgeStates, max_inject=8, priority_ids=active_char_ids,
            party_accessor=lambda p: (p.PartyIds or []),
            chapter_accessor=lambda p: p.LastChapter,
            overdue_accessor=lambda p: getattr(p, 'IsOverdue', False))
        snapshot.DeadlineStates = self._apply_limit_3tier(
            snapshot.DeadlineStates, max_inject=8, priority_ids=active_char_ids,
            party_accessor=lambda d: (d.PartyIds or []),
            chapter_accessor=lambda d: d.LastChapter,
            overdue_accessor=lambda d: getattr(d, 'IsOverdue', False))

    @staticmethod
    def _apply_limit_3tier(source, max_inject: int, priority_ids: set,
                           party_accessor, chapter_accessor, overdue_accessor=None):
        """对标 ApplyRelevanceLimit<T>: 3层优先级排序 + 截断"""
        if not source or len(source) <= max_inject:
            return source
        # 1. 逾期优先 → 2. 关联角色(partyIds ∩ priorityIds) → 3. 最近章节
        has_party = lambda item: any(
            pid and pid in priority_ids
            for pid in party_accessor(item)) if party_accessor(item) else False
        return sorted(source, key=lambda s: (
            0 if (overdue_accessor and overdue_accessor(s)) else 1,  # 逾期=0 优先
            0 if has_party(s) else 1,                                 # 关联=0 优先
            -(chapter_accessor(s) or 0),                               # 章节号大优先
        ))[:max_inject]

    def _inject_active_char_descriptions(self, snapshot: FactSnapshot):
        """对标 ExtractSnapshotAsync 第88-103行: 补充活跃角色描述"""
        existing_ids = {cd.CharacterId for cd in snapshot.CharacterDescriptions}
        active_ids = {cse.CharacterId for cse in snapshot.CharacterStates}
        missing = active_ids - existing_ids
        if missing:
            design = self._design("characters")
            items = design.get("items", []) if isinstance(design, dict) else (design or [])
            for c in items:
                cid = c.get("Id", "")
                if cid in missing:
                    app = c.get("Appearance", "")
                    hair = self._extract_hair(app)
                    tags = [t.strip() for t in re.split(r"[，,、]", c.get("Personality", "") + "," + c.get("Identity", "")) if t.strip()]
                    snapshot.CharacterDescriptions.append(
                        CharacterDescription(CharacterId=cid, Name=c.get("Name", ""),
                                             HairColor=hair, Appearance=app, PersonalityTags=tags))

    @staticmethod
    def _extract_hair(appearance: str) -> str:
        """对标 ExtractHairColor + HairColorConstants"""
        for kw in ["黑发", "金发", "白发", "红发", "蓝发", "紫发", "银发", "棕发", "青发",
                    "黑", "金", "白", "红", "蓝", "紫", "银", "灰", "棕"]:
            if kw in appearance:
                return kw if len(kw) >= 2 else kw + "发"
        return ""

    @staticmethod
    def _limit(items, max_count):
        return items[:max_count] if len(items) > max_count else items

    def _extract_characters(self, chapter_number: int) -> List[CharacterStateEntry]:
        guide = self._tracking("character_state")
        entries = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict): continue
                entries.append(CharacterStateEntry(
                    CharacterId=k, Name=v.get("Name", k), Level=v.get("Level", ""),
                    Phase=v.get("Phase", ""), Abilities=v.get("Abilities", []),
                    LostAbilities=v.get("LostAbilities", []), MentalState=v.get("MentalState", ""),
                    KeyEvent=v.get("KeyEvent", ""), LastChapter=int(v.get("LastChapter", 0) or 0),
                    Importance=int(v.get("Importance", 0) or 0), Relationships=v.get("Relationships", {})))
        if not entries:
            design = self._design("characters")
            items = design.get("items", []) if isinstance(design, dict) else (design or [])
            for c in items:
                entries.append(CharacterStateEntry(
                    CharacterId=c.get("Id", ""), Name=c.get("Name", ""),
                    Level="", Phase="", Abilities=c.get("SpecialAbilities", []),
                    MentalState="", Importance=3 if c.get("IsPov") else 2, Relationships={}))
        return entries

    def _extract_conflicts(self) -> List[ConflictProgressEntry]:
        """对标 ExtractConflictProgressAsync: 取最近 10 条进展"""
        guide = self._tracking("conflict_progress")
        out = []
        if guide:
            items = []
            for k, v in guide.items():
                if not isinstance(v, dict): continue
                items.append(ConflictProgressEntry(
                    ConflictId=k, Name=v.get("Name", k), Type=v.get("Type", ""),
                    Tier=v.get("Tier", ""), Status=v.get("Status", ""), LastEvent=v.get("LastEvent", ""),
                    LastChapter=int(v.get("LastChapter", 0) or 0), InvolvedCharacters=v.get("InvolvedCharacters", [])))
            items.sort(key=lambda x: -x.LastChapter)
            out = items[:10]
        return out

    def _extract_foreshadowings(self) -> List[ForeshadowingEntry]:
        guide = self._tracking("foreshadowing")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict): continue
                out.append(ForeshadowingEntry(
                    ForeshadowId=k, Name=v.get("Name", k), Tier=v.get("Tier", ""),
                    IsSetup=bool(v.get("IsSetup", False)), IsResolved=bool(v.get("IsResolved", False)),
                    IsOverdue=bool(v.get("IsOverdue", False)),
                    ExpectedSetupChapter=int(v.get("ExpectedSetupChapter", 0) or 0),
                    ExpectedPayoffChapter=int(v.get("ExpectedPayoffChapter", 0) or 0),
                    ActualSetupChapter=int(v.get("ActualSetupChapter", 0) or 0),
                    ActualPayoffChapter=int(v.get("ActualPayoffChapter", 0) or 0)))
        return out

    def _extract_plot_points(self) -> List[PlotPointEntry]:
        guide = self._tracking("plot_points")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict): continue
                out.append(PlotPointEntry(
                    PlotPointId=k, Keywords=v.get("Keywords", []), Context=v.get("Context", ""),
                    InvolvedCharacters=v.get("InvolvedCharacters", []), Storyline=v.get("Storyline", ""),
                    Chapter=int(v.get("Chapter", 0) or 0), Importance=int(v.get("Importance", 0) or 0)))
        return out

    def _extract_character_descriptions(self) -> List[CharacterDescription]:
        design = self._design("characters")
        items = design.get("items", []) if isinstance(design, dict) else (design or [])
        out = []
        for c in items:
            app = c.get("Appearance", "")
            hair = self._extract_hair(app)
            tags = [t.strip() for t in re.split(r"[，,、]", c.get("Personality", "")) if t.strip()]
            out.append(CharacterDescription(
                CharacterId=c.get("Id", ""), Name=c.get("Name", ""),
                HairColor=hair, EyeColor="", PersonalityTags=tags, Appearance=app))
        return out

    def _extract_location_descriptions(self) -> List[LocationDescription]:
        design = self._design("locations")
        items = design.get("items", []) if isinstance(design, dict) else (design or [])
        out = []
        for loc in items:
            features = loc.get("Landmarks", []) or []
            if isinstance(features, str): features = [features]
            out.append(LocationDescription(
                LocationId=loc.get("Id", ""), Name=loc.get("Name", ""),
                Features=[str(x) for x in features], Description=loc.get("Description", "")))
        return out

    def _extract_world_constraints(self) -> List[WorldRuleConstraint]:
        design = self._design("world")
        items = design.get("items", []) if isinstance(design, dict) else (design or [])
        out = []
        for rule in items:
            for hr in (rule.get("HardRules", []) or []):
                if hr:
                    out.append(WorldRuleConstraint(RuleId=rule.get("Id", "R"), Content=str(hr), IsHardConstraint=True))
        return out

    def _extract_location_states(self) -> List[LocationStateEntry]:
        guide = self._tracking("location_state")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict): continue
                out.append(LocationStateEntry(
                    LocationId=k, Name=v.get("Name", k), CurrentStatus=v.get("CurrentStatus", "正常"),
                    Description=v.get("Description", ""), LastEvent=v.get("LastEvent", ""),
                    LastChapter=int(v.get("LastChapter", 0) or 0)))
        return out

    def _extract_faction_states(self) -> List[FactionStateEntry]:
        guide = self._tracking("faction_state")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict): continue
                out.append(FactionStateEntry(
                    FactionId=k, Name=v.get("Name", k), CurrentStatus=v.get("CurrentStatus", "正常"),
                    LastEvent=v.get("LastEvent", ""), LastChapter=int(v.get("LastChapter", 0) or 0)))
        return out

    def _extract_timeline(self) -> List[TimeEntry]:
        guide = self._tracking("timeline")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict): continue
                out.append(TimeEntry(
                    TimePeriod=v.get("TimePeriod", ""), ElapsedTime=v.get("ElapsedTime", ""),
                    KeyTimeEvent=v.get("KeyTimeEvent", ""), Chapter=int(v.get("Chapter", 0) or 0)))
        return out

    def _extract_character_locations(self) -> List[CharacterLocationEntry]:
        guide = self._tracking("character_location")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict): continue
                out.append(CharacterLocationEntry(
                    CharacterId=k, Name=v.get("Name", k), CurrentLocation=v.get("CurrentLocation", ""),
                    LastUpdatedChapter=int(v.get("LastUpdatedChapter", 0) or 0)))
        return out

    def _extract_items(self) -> List[ItemStateEntry]:
        guide = self._tracking("item_state")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict): continue
                out.append(ItemStateEntry(
                    ItemId=k, Name=v.get("Name", k), CurrentHolder=v.get("CurrentHolder", ""),
                    CurrentStatus=v.get("CurrentStatus", "active"), Description=v.get("Description", ""),
                    LastEvent=v.get("LastEvent", ""), LastChapter=int(v.get("LastChapter", 0) or 0)))
        return out

    def _extract_secrets(self) -> List[SecretEntry]:
        guide = self._tracking("secret")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict): continue
                out.append(SecretEntry(
                    SecretId=k, Name=v.get("Name", k), KnowerIds=v.get("KnowerIds", []),
                    CurrentStatus=v.get("CurrentStatus", "hidden"), LastChapter=int(v.get("LastChapter", 0) or 0)))
        return out

    def _extract_pledges(self) -> List[PledgeEntry]:
        guide = self._tracking("pledge")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict): continue
                out.append(PledgeEntry(
                    PledgeId=k, Name=v.get("Name", k), Type=v.get("Type", ""),
                    CurrentStatus=v.get("CurrentStatus", "active"), PartyIds=v.get("PartyIds", []),
                    Condition=v.get("Condition", ""), Consequence=v.get("Consequence", ""),
                    LastChapter=int(v.get("LastChapter", 0) or 0)))
        return out

    def _extract_deadlines(self) -> List[DeadlineEntry]:
        guide = self._tracking("deadline")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict): continue
                out.append(DeadlineEntry(
                    DeadlineId=k, Name=v.get("Name", k), Type=v.get("Type", ""),
                    CurrentStatus=v.get("CurrentStatus", "active"), Deadline=v.get("Deadline", ""),
                    TriggerCondition=v.get("TriggerCondition", ""), Consequence=v.get("Consequence", ""),
                    PartyIds=v.get("PartyIds", []), LastChapter=int(v.get("LastChapter", 0) or 0)))
        return out

    # ====== 对标 ExtractVolumeEndSnapshotAsync: 卷末全量快照持久化 ======

    def extract_volume_end(self, volume_number: int) -> FactSnapshot:
        """对标 ExtractVolumeEndSnapshotAsync: 卷末完整快照（allVolumes=true，无截断）"""
        snapshot = FactSnapshot()

        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            futures = {
                "chars": pool.submit(self._extract_characters, 0),
                "conflicts": pool.submit(self._extract_conflicts),
                "foreshadowings": pool.submit(self._extract_foreshadowings),
                "loc_states": pool.submit(self._extract_location_states),
                "fac_states": pool.submit(self._extract_faction_states),
                "items": pool.submit(self._extract_items),
                "secrets": pool.submit(self._extract_secrets),
                "pledges": pool.submit(self._extract_pledges),
                "deadlines": pool.submit(self._extract_deadlines),
            }

            snapshot.CharacterStates = futures["chars"].result()
            snapshot.ConflictProgress = futures["conflicts"].result()
            snapshot.ForeshadowingStatus = futures["foreshadowings"].result()
            snapshot.LocationStates = futures["loc_states"].result()
            snapshot.FactionStates = futures["fac_states"].result()
            snapshot.ItemStates = futures["items"].result()
            snapshot.SecretStates = futures["secrets"].result()
            snapshot.PledgeStates = futures["pledges"].result()
            snapshot.DeadlineStates = futures["deadlines"].result()

        # 卷末不应用 relevance limit（无截断）
        return snapshot

    def save_volume_snapshot(self, volume_number: int):
        """对标 VolumeFactArchiveStore.ArchiveVolumeAsync: 持久化卷末快照"""
        snapshot = self.extract_volume_end(volume_number)
        data = snapshot.to_dict()
        self.project.save_design(f"vol{volume_number}_archive", data)
        return snapshot
