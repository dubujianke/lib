# -*- coding: utf-8 -*-
"""CHANGES 协议（12 类变更声明）与 15 维事实快照"""

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Dict, Optional
from .common import JsonModel

# --- 状态机枚举（对标原版枚举） ---
class ConflictStatus(Enum):
    PENDING = "pending"
    ACTIVE = "active"
    CLIMAX = "climax"
    RESOLVED = "resolved"

class ForeshadowAction(Enum):
    SETUP = "setup"
    PAYOFF = "payoff"

class Importance(Enum):
    NORMAL = "normal"
    IMPORTANT = "important"
    CRITICAL = "critical"

class ItemStatus(Enum):
    ACTIVE = "active"
    LOST = "lost"
    DESTROYED = "destroyed"
    SEALED = "sealed"

class SecretStatus(Enum):
    HIDDEN = "hidden"
    REVEALED = "revealed"

class PledgeAction(Enum):
    CREATE = "create"
    FULFILL = "fulfill"
    BREAK = "break"
    UPDATE = "update"
    EXPIRE = "expire"

class DeadlineAction(Enum):
    CREATE = "create"
    TRIGGER = "trigger"
    EXPIRE = "expire"
    CANCEL = "cancel"
    UPDATE = "update"

class PledgeType(Enum):
    PLEDGE = "pledge"
    CONTRACT = "contract"
    OATH = "oath"

class DeadlineType(Enum):
    COUNTDOWN = "countdown"
    CURSE = "curse"
    THREAT = "threat"
    EVENT = "event"

class RecallCategory(Enum):
    GENERAL = "General"
    CHARACTER = "Character"
    FORESHADOWING = "Foreshadowing"

# --- CHANGES 分隔符 ---
CHANGES_SEPARATOR = "---CHANGES---"
CHANGES_XML_OPEN = "<chapter_changes>"
CHANGES_XML_CLOSE = "</chapter_changes>"

# 12 个顶级字段
TOP_LEVEL_FIELDS = [
    "CharacterStateChanges", "ConflictProgress", "NewPlotPoints", "ForeshadowingActions",
    "LocationStateChanges", "FactionStateChanges", "TimeProgression", "CharacterMovements",
    "ItemTransfers", "SecretRevealChanges", "PledgeConstraintChanges", "DeadlineConstraintChanges",
]

# 中文↔英文字段名映射（CHANGES 修复用，完整版见 json_repair.py）
CHINESE_FIELD_MAP = {
    "角色状态变化": "CharacterStateChanges", "角色ID": "CharacterId", "角色": "CharacterId",
    "新境界": "NewLevel", "境界": "NewLevel", "新能力": "NewAbilities",
    "失去能力": "LostAbilities", "关系变化": "RelationshipChanges", "新心理状态": "NewMentalState",
    "心理状态": "NewMentalState", "关键事件": "KeyEvent", "事件": "KeyEvent",
    "重要性": "Importance", "因果": "CausedBy",
    "冲突进度": "ConflictProgress", "冲突ID": "ConflictId", "新状态": "NewStatus",
    "新剧情节点": "NewPlotPoints", "关键词": "Keywords", "上下文": "Context",
    "涉及角色": "InvolvedCharacters", "故事线": "Storyline",
    "伏笔动作": "ForeshadowingActions", "伏笔ID": "ForeshadowId", "动作": "Action",
    "地点状态变化": "LocationStateChanges", "地点ID": "LocationId", "地点名称": "LocationName",
    "势力状态变化": "FactionStateChanges", "势力ID": "FactionId",
    "时间推进": "TimeProgression", "当前时段": "TimePeriod", "经过时间": "ElapsedTime",
    "时间事件": "KeyTimeEvent",
    "角色移动": "CharacterMovements", "出发地": "FromLocation", "目的地": "ToLocation",
    "目的地点名": "ToLocationName",
    "物品流转": "ItemTransfers", "物品ID": "ItemId", "物品名称": "ItemName",
    "原持有者": "FromHolder", "新持有者": "ToHolder",
    "秘密揭示": "SecretRevealChanges", "秘密ID": "SecretId", "秘密名称": "SecretName",
    "新知情人": "NewKnowerIds", "揭示方式": "Method",
    "誓约约束变化": "PledgeConstraintChanges", "誓约ID": "PledgeId", "誓约名称": "PledgeName",
    "类型": "Type", "当事人": "PartyIds", "条件": "Condition", "后果": "Consequence",
    "截止约束变化": "DeadlineConstraintChanges", "截止ID": "DeadlineId", "截止名称": "DeadlineName",
    "截止时间": "Deadline", "触发条件": "TriggerCondition",
}


# ---- 12 类变更声明元素 ----
@dataclass
class RelationshipChange(JsonModel):
    Relation: str = ""
    TrustDelta: int = 0
    EmotionPhase: str = ""


@dataclass
class CharacterStateChange(JsonModel):
    CharacterId: str = ""
    NewLevel: str = ""
    NewAbilities: List[str] = field(default_factory=list)
    LostAbilities: List[str] = field(default_factory=list)
    RelationshipChanges: Dict[str, RelationshipChange] = field(default_factory=dict)
    NewMentalState: str = ""
    KeyEvent: str = ""
    Importance: str = ""
    CausedBy: str = ""


@dataclass
class ConflictProgressChange(JsonModel):
    ConflictId: str = ""
    NewStatus: str = ""
    Event: str = ""
    Importance: str = ""
    CausedBy: str = ""


@dataclass
class PlotPointChange(JsonModel):
    Keywords: List[str] = field(default_factory=list)
    Context: str = ""
    InvolvedCharacters: List[str] = field(default_factory=list)
    Importance: str = ""
    Storyline: str = ""
    CausedBy: str = ""


@dataclass
class ForeshadowingAction(JsonModel):
    ForeshadowId: str = ""
    Action: str = ""     # setup / payoff


@dataclass
class LocationStateChange(JsonModel):
    LocationId: str = ""
    LocationName: str = ""
    NewStatus: str = ""
    Event: str = ""
    Importance: str = ""


@dataclass
class FactionStateChange(JsonModel):
    FactionId: str = ""
    NewStatus: str = ""
    Event: str = ""
    Importance: str = ""
    CausedBy: str = ""


@dataclass
class TimeProgressionChange(JsonModel):
    TimePeriod: str = ""
    ElapsedTime: str = ""
    KeyTimeEvent: str = ""
    Importance: str = ""


@dataclass
class CharacterMovementChange(JsonModel):
    CharacterId: str = ""
    FromLocation: str = ""
    ToLocation: str = ""
    ToLocationName: str = ""
    Importance: str = ""


@dataclass
class ItemTransferChange(JsonModel):
    ItemId: str = ""
    ItemName: str = ""
    FromHolder: str = ""
    ToHolder: str = ""
    NewStatus: str = ""    # active/lost/destroyed/sealed
    Event: str = ""
    Importance: str = ""
    CausedBy: str = ""


@dataclass
class SecretRevealChange(JsonModel):
    SecretId: str = ""
    SecretName: str = ""
    NewKnowerIds: List[str] = field(default_factory=list)
    Method: str = ""       # told/overheard/deduced/discovered/other
    KeyEvent: str = ""
    Importance: str = ""
    CausedBy: str = ""


@dataclass
class PledgeConstraintChange(JsonModel):
    PledgeId: str = ""
    PledgeName: str = ""
    Action: str = ""       # create/fulfill/break/update
    Type: str = ""         # pledge/contract/oath
    PartyIds: List[str] = field(default_factory=list)
    Condition: str = ""
    Consequence: str = ""
    KeyEvent: str = ""
    Importance: str = ""


@dataclass
class DeadlineConstraintChange(JsonModel):
    DeadlineId: str = ""
    DeadlineName: str = ""
    Action: str = ""       # create/trigger/expire/cancel/update
    Type: str = ""         # countdown/curse/threat/event
    Deadline: str = ""
    TriggerCondition: str = ""
    Consequence: str = ""
    PartyIds: List[str] = field(default_factory=list)
    KeyEvent: str = ""
    Importance: str = ""


@dataclass
class ChapterChanges(JsonModel):
    """AI 每章交付的 12 类变更声明"""
    CharacterStateChanges: List[CharacterStateChange] = field(default_factory=list)
    ConflictProgress: List[ConflictProgressChange] = field(default_factory=list)
    NewPlotPoints: List[PlotPointChange] = field(default_factory=list)
    ForeshadowingActions: List[ForeshadowingAction] = field(default_factory=list)
    LocationStateChanges: List[LocationStateChange] = field(default_factory=list)
    FactionStateChanges: List[FactionStateChange] = field(default_factory=list)
    TimeProgression: List[TimeProgressionChange] = field(default_factory=list)
    CharacterMovements: List[CharacterMovementChange] = field(default_factory=list)
    ItemTransfers: List[ItemTransferChange] = field(default_factory=list)
    SecretRevealChanges: List[SecretRevealChange] = field(default_factory=list)
    PledgeConstraintChanges: List[PledgeConstraintChange] = field(default_factory=list)
    DeadlineConstraintChanges: List[DeadlineConstraintChange] = field(default_factory=list)

    def has_any_change(self) -> bool:
        return any(getattr(self, f) for f in TOP_LEVEL_FIELDS)

    def to_prompt_dict(self) -> dict:
        """转成给 AI 看的预填 JSON 结构"""
        d = self.to_dict()
        return d


# ---- 15 维事实快照 ----
@dataclass
class CharacterStateEntry(JsonModel):
    CharacterId: str = ""
    Name: str = ""
    Level: str = ""
    Phase: str = ""
    Abilities: List[str] = field(default_factory=list)
    LostAbilities: List[str] = field(default_factory=list)
    MentalState: str = ""
    KeyEvent: str = ""
    LastChapter: int = 0
    Importance: int = 0
    # 关系: {CharacterId: RelationshipState}
    Relationships: Dict[str, dict] = field(default_factory=dict)


@dataclass
class ConflictProgressEntry(JsonModel):
    ConflictId: str = ""
    Name: str = ""
    Type: str = ""
    Tier: str = ""
    Status: str = ""
    LastEvent: str = ""
    LastChapter: int = 0
    InvolvedCharacters: List[str] = field(default_factory=list)


@dataclass
class ForeshadowingEntry(JsonModel):
    ForeshadowId: str = ""
    Name: str = ""
    Tier: str = ""
    IsSetup: bool = False
    IsResolved: bool = False
    IsOverdue: bool = False
    ExpectedSetupChapter: int = 0
    ExpectedPayoffChapter: int = 0
    ActualSetupChapter: int = 0
    ActualPayoffChapter: int = 0


@dataclass
class PlotPointEntry(JsonModel):
    PlotPointId: str = ""
    Keywords: List[str] = field(default_factory=list)
    Context: str = ""
    InvolvedCharacters: List[str] = field(default_factory=list)
    Storyline: str = ""
    Chapter: int = 0
    Importance: int = 0


@dataclass
class LocationStateEntry(JsonModel):
    LocationId: str = ""
    Name: str = ""
    CurrentStatus: str = ""
    Description: str = ""
    LastEvent: str = ""
    LastChapter: int = 0


@dataclass
class FactionStateEntry(JsonModel):
    FactionId: str = ""
    Name: str = ""
    CurrentStatus: str = ""
    LastEvent: str = ""
    LastChapter: int = 0


@dataclass
class TimeEntry(JsonModel):
    TimePeriod: str = ""
    ElapsedTime: str = ""
    KeyTimeEvent: str = ""
    Chapter: int = 0


@dataclass
class CharacterLocationEntry(JsonModel):
    CharacterId: str = ""
    Name: str = ""
    CurrentLocation: str = ""
    LastUpdatedChapter: int = 0


@dataclass
class ItemStateEntry(JsonModel):
    ItemId: str = ""
    Name: str = ""
    CurrentHolder: str = ""
    CurrentStatus: str = ""
    Description: str = ""
    LastEvent: str = ""
    LastChapter: int = 0


@dataclass
class SecretEntry(JsonModel):
    SecretId: str = ""
    Name: str = ""
    KnowerIds: List[str] = field(default_factory=list)
    CurrentStatus: str = ""
    LastChapter: int = 0


@dataclass
class PledgeEntry(JsonModel):
    PledgeId: str = ""
    Name: str = ""
    Type: str = ""
    CurrentStatus: str = ""
    PartyIds: List[str] = field(default_factory=list)
    Condition: str = ""
    Consequence: str = ""
    LastChapter: int = 0


@dataclass
class DeadlineEntry(JsonModel):
    DeadlineId: str = ""
    Name: str = ""
    Type: str = ""
    CurrentStatus: str = ""
    Deadline: str = ""
    TriggerCondition: str = ""
    Consequence: str = ""
    PartyIds: List[str] = field(default_factory=list)
    LastChapter: int = 0


@dataclass
class WorldRuleConstraint(JsonModel):
    RuleId: str = ""
    Content: str = ""
    IsHardConstraint: bool = True


@dataclass
class CharacterDescription(JsonModel):
    CharacterId: str = ""
    Name: str = ""
    HairColor: str = ""
    EyeColor: str = ""
    PersonalityTags: List[str] = field(default_factory=list)
    Appearance: str = ""


@dataclass
class LocationDescription(JsonModel):
    LocationId: str = ""
    Name: str = ""
    Features: List[str] = field(default_factory=list)
    Description: str = ""


@dataclass
class FactSnapshot(JsonModel):
    """15 维事实快照（写前读取，供 AI 阅读的账本）"""
    CharacterStates: List[CharacterStateEntry] = field(default_factory=list)
    ConflictProgress: List[ConflictProgressEntry] = field(default_factory=list)
    ForeshadowingStatus: List[ForeshadowingEntry] = field(default_factory=list)
    PlotPoints: List[PlotPointEntry] = field(default_factory=list)
    CharacterDescriptions: List[CharacterDescription] = field(default_factory=list)
    LocationDescriptions: List[LocationDescription] = field(default_factory=list)
    WorldRuleConstraints: List[WorldRuleConstraint] = field(default_factory=list)
    LocationStates: List[LocationStateEntry] = field(default_factory=list)
    FactionStates: List[FactionStateEntry] = field(default_factory=list)
    Timeline: List[TimeEntry] = field(default_factory=list)
    CharacterLocations: List[CharacterLocationEntry] = field(default_factory=list)
    ItemStates: List[ItemStateEntry] = field(default_factory=list)
    SecretStates: List[SecretEntry] = field(default_factory=list)
    PledgeStates: List[PledgeEntry] = field(default_factory=list)
    DeadlineStates: List[DeadlineEntry] = field(default_factory=list)
