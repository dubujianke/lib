# -*- coding: utf-8 -*-
"""六道门禁 — 严格对标 4.1.1 GenerationGate.ValidateAsync"""
import re
from dataclasses import dataclass, field
from typing import List, Optional, Dict

from .models import ChapterChanges, FactSnapshot, TOP_LEVEL_FIELDS, is_likely_id
from .changes_parser import ChapterChangesParser, ChapterChangesCanonicalizer
from .prompt_builder import split_content_and_changes


@dataclass
class GateFailure:
    Type: str
    Errors: List[str] = field(default_factory=list)
    def __str__(self): return f"[{self.Type}] " + "; ".join(self.Errors[:3])
    def to_dict(self): return {"Type": self.Type, "Errors": self.Errors}


@dataclass
class GateResult:
    Success: bool = True
    Failures: List[GateFailure] = field(default_factory=list)
    ParsedChanges: Optional[ChapterChanges] = None
    ContentWithoutChanges: str = ""
    NewEntities: List = field(default_factory=list)

    def add_failure(self, ftype: str, errors: List[str]):
        self.Success = False
        self.Failures.append(GateFailure(ftype, errors))


# ==== 常量 ====
HAIR_COLORS = ["黑发", "金发", "白发", "红发", "蓝发", "紫发", "银发", "棕发", "青发", "绿发", "灰发"]
EYE_COLORS = ["黑眼", "蓝眼", "红眼", "金眼", "绿眼", "紫眼", "灰眼"]

# 对标 AntonymPairs: 多对多反义词（发色/瞳色/性格）
ANTONYM_PAIRS = {
    "沉默寡言": ["滔滔不绝", "话多", "健谈", "喋喋不休"],
    "内向": ["外向", "开朗", "活泼"],
    "冷漠": ["热情", "温暖", "友善"],
    "温柔": ["冷酷", "暴躁", "粗暴", "残忍"],
    "沉稳": ["冲动", "莽撞", "浮躁", "急躁"],
    "冷静": ["冲动", "慌乱", "失控", "暴躁"],
    "谨慎": ["鲁莽", "冒进", "大意", "草率"],
    "勇敢": ["胆小", "懦弱", "怯懦"],
    "坚强": ["软弱", "脆弱", "怯弱"],
    "正直": ["狡诈", "阴险", "卑鄙", "虚伪"],
    "善良": ["邪恶", "残忍", "冷酷"],
    "忠诚": ["背叛", "叛变", "反叛"],
    "聪明": ["愚蠢", "笨拙", "迟钝"],
    "黑发": ["金发", "白发", "红发", "银发", "棕发", "蓝发", "紫发", "绿发", "灰发"],
    "金发": ["黑发", "白发", "红发", "银发", "棕发", "蓝发", "紫发", "绿发", "灰发"],
    "白发": ["黑发", "金发", "红发", "棕发", "蓝发", "紫发", "绿发", "灰发"],
    "银发": ["黑发", "金发", "红发", "棕发", "蓝发", "紫发", "绿发", "灰发"],
    "红发": ["黑发", "金发", "白发", "银发", "棕发", "蓝发", "紫发", "绿发", "灰发"],
    "蓝眼": ["黑眼", "红眼", "金眼", "绿眼", "紫眼", "灰眼"],
    "黑眼": ["蓝眼", "红眼", "金眼", "绿眼", "紫眼", "灰眼"],
    "红眼": ["黑眼", "蓝眼", "金眼", "绿眼", "紫眼", "灰眼"],
    "金眼": ["黑眼", "蓝眼", "红眼", "绿眼", "紫眼", "灰眼"],
    "绿眼": ["黑眼", "蓝眼", "红眼", "金眼", "紫眼", "灰眼"],
}
CONFLICT_ORDER = {"pending": 0, "active": 1, "climax": 2, "resolved": 3,
                  "未开始": 0, "进行中": 1, "高潮": 2, "已解决": 3,
                  "待触发": 0, "激化中": 1, "白热化": 2, "已结束": 3}
STOP_WORDS = {
    "什么", "怎么", "为什么", "这个", "那个", "他们", "我们", "你们",
    "是的", "不是", "好的", "可以", "没有", "知道", "应该", "可能",
    "不要", "不行", "别怕", "等等", "快走", "住手", "小心", "闭嘴",
    "是谁", "哪里", "如今", "现在", "以后", "罢了", "够了", "真的",
    "假的", "原来", "如此", "当然", "不必", "不许", "不能", "为何",
}


class GenerationGate:
    """对标 4.1.1: 6关串行 + 2关后置"""

    def __init__(self):
        self.parser = ChapterChangesParser()

    def validate(self, raw: str, snapshot: FactSnapshot,
                 design_names: Dict[str, List[str]] = None,
                 context_ids: dict = None, chapter_id: str = "") -> GateResult:
        """对标 ValidateAsync 完整流程"""
        result = GateResult()

        # ======== Gate 1: 协议解析（对标 4.1.1 ValidateChangesProtocol） ========
        from .json_repair import repair_changes_json
        from .ai_service import extract_json

        # Step 1: IdentifyChangesRegion（6 种格式优先级链）
        content, changes_part, fmt = split_content_and_changes(raw)
        if not changes_part:
            result.add_failure("协议解析", [
                "未识别到CHANGES区域（首选格式：<chapter_changes>...</chapter_changes>；兼容分隔符、Markdown 标题和末尾 JSON）"])
            return result
        result.ContentWithoutChanges = content

        # Step 2: ParseChangesContent — 从 CHANGES 段提取 JSON → 解析 ChapterChanges
        changes = None
        # 2a. ExtractJsonFromChangesSection（对标：去 markdown 代码块，提取最外层 {..}）
        json_str = _extract_json_from_changes_section(changes_part)
        if json_str:
            # 2b. TryParseJsonChanges：先直接解析
            data = extract_json(json_str)
            if isinstance(data, dict):
                changes = _dict_to_chapter_changes(data)
            # 2c. 解析失败 → RepairChangesJson 修复后重试
            if changes is None:
                repaired_json = repair_changes_json(json_str)
                if repaired_json != json_str:
                    data = extract_json(repaired_json)
                    if isinstance(data, dict):
                        changes = _dict_to_chapter_changes(data)

        if changes is None:
            result.add_failure("协议解析",
                ["CHANGES解析失败：请检查 JSON 语法（括号、逗号、引号），或确认正文末尾输出了包含顶级字段的 JSON 对象。"])
            return result

        # Step 3: ValidateRequiredFields — 12 个顶级字段
        missing = [f for f in TOP_LEVEL_FIELDS if getattr(changes, f, None) is None]
        if missing:
            result.add_failure("协议解析", [f"CHANGES缺失必需字段: {', '.join(missing[:5])}（必须显式声明，即使为空数组）"])
            return result

        # Step 4: 归一化（Canonicalize: ID 解析 + 自动创建 + 状态机防护）
        canon = ChapterChangesCanonicalizer(snapshot)
        changes = canon.canonicalize(changes)
        result.ParsedChanges = changes
        result.NewEntities = canon.new_entities

        # Step 5: 伪造 ID 检测（对标 CountForgedIds: >=5 且 >=80%）
        if canon.is_forged():
            result.add_failure("协议解析", [
                f"模型大面积伪造实体ID（{canon.forged_count}/{canon.total_attempted}），请严格使用账本中已存在的实体名称或 ShortId，禁止自造不存在的ID"])
            return result

        # Step 6: ValidateShortIdFields — ID 格式校验
        _, raw_changes, _fmt = split_content_and_changes(raw)
        if raw_changes:
            from .json_repair import validate_shortid_fields
            id_errors = validate_shortid_fields(raw_changes)
            if id_errors:
                result.add_failure("协议解析", [f"CHANGES协议违规：ID格式非法 - {', '.join(id_errors[:3])}"])
                return result

        # ======== Gate 2: ShortId 引用校验 ========
        ref_errors = self._validate_shortid_refs(changes, snapshot, result.NewEntities)
        if ref_errors:
            result.add_failure("引用校验", ref_errors)
            return result

        # ======== Gate 3: 一致性校验 ========
        cons_errors = self._consistency_check(changes, snapshot)
        if cons_errors:
            result.add_failure("一致性校验", cons_errors)
            return result

        # ======== Gate 4: 未知实体 ========
        entity_errors = self._unknown_entity_check(content, changes, snapshot)
        if entity_errors:
            result.add_failure("未知实体", entity_errors)
            return result

        # ======== Gate 5: 描写一致性 ========
        desc_errors = self._description_check(content, snapshot)
        if desc_errors:
            result.add_failure("描写一致性", desc_errors)
            return result

        # ======== Gate 6: 世界观约束 ========
        world_errors = self._world_rule_check(content, snapshot)
        if world_errors:
            result.add_failure("世界观约束", world_errors)
            return result

        # ======== Post-gate: 设计出场 ========
        if design_names:
            bp_errors = self._design_presence_check(content, design_names)
            if bp_errors:
                result.add_failure("设计出场", bp_errors)
                return result

        # ======== Post-gate: 漏报检测 ========
        omission_errors = self._omission_check(content, changes, snapshot)
        if omission_errors:
            result.add_failure("漏报检测", omission_errors)
            return result

        result.Success = True
        return result

    # ====== Gate 2: ShortId References（对标 4.1.1 ValidateShortIdReferences） ======

    # ---- ShortId 实体类型（对标 ShortIdEntityType） ----
    _SHORTID_ENTITY_TYPES = {
        "Character":  "Character",
        "Location":   "Location",
        "Conflict":   "Conflict",
        "Foreshadowing": "Foreshadowing",
        "Faction":    "Faction",
        "Item":       "Item",
        "Secret":     "Secret",
        "Pledge":     "Pledge",
        "Deadline":   "Deadline",
    }
    # 可自动创建类型: 在 CHANGES 中声明了 Name 即可用新 ID（对标 creatableTypes）
    _CREATABLE_TYPES = {"Item", "Secret", "Pledge", "Deadline", "Location"}

    # ---- 字段 → 实体类型 + 中文名（对标 ShortIdFieldRegistry） ----
    _SHORTID_FIELD_REGISTRY = {
        # CharacterStateChanges
        "CharacterStateCharacterId": ("Character", "角色ID"),
        "CharacterStateRelationshipKey": ("Character", "关系目标角色ID"),
        # ConflictProgress
        "ConflictConflictId": ("Conflict", "冲突ID"),
        # ForeshadowingActions
        "ForeshadowForeshadowId": ("Foreshadowing", "伏笔ID"),
        # LocationStateChanges
        "LocationLocationId": ("Location", "地点ID"),
        # FactionStateChanges
        "FactionFactionId": ("Faction", "势力ID"),
        # CharacterMovements
        "MovementCharacterId": ("Character", "角色移动-角色ID"),
        "MovementFromLocation": ("Location", "角色移动-出发地ID"),
        "MovementToLocation": ("Location", "角色移动-目的地ID"),
        # ItemTransfers
        "ItemTransferItemId": ("Item", "物品ID"),
        "ItemTransferFromHolder": ("Character", "物品原持有者ID"),
        "ItemTransferToHolder": ("Character", "物品新持有者ID"),
        # SecretRevealChanges
        "SecretSecretId": ("Secret", "秘密ID"),
        "SecretNewKnowerId": ("Character", "秘密新知情人ID"),
        # NewPlotPoints
        "PlotInvolvedCharacter": ("Character", "剧情涉及角色ID"),
        # PledgeConstraintChanges
        "PledgePledgeId": ("Pledge", "誓约/承诺ID"),
        "PledgePartyId": ("Character", "誓约当事方ID"),
        # DeadlineConstraintChanges
        "DeadlineDeadlineId": ("Deadline", "倒计时ID"),
        "DeadlinePartyId": ("Character", "倒计时当事方ID"),
    }

    def _get_entity_type(self, field_key: str):
        entry = self._SHORTID_FIELD_REGISTRY.get(field_key)
        if entry:
            return entry[0]
        return None

    def _get_field_cn_name(self, field_key: str) -> str:
        entry = self._SHORTID_FIELD_REGISTRY.get(field_key)
        if entry:
            return entry[1]
        return field_key

    def _validate_shortid_refs(self, changes: ChapterChanges, snapshot: FactSnapshot,
                                new_entities: List = None) -> List[str]:
        """对标 4.1.1 ValidateShortIdReferences: 完整移植"""
        errors = []

        def _build_set(values) -> set:
            return {v.strip() for v in values if v and v.strip()}

        # ---- 构建各实体类型的合法 ID 集合（对标 BuildSet + AllowedFor） ----
        # Character: CharacterStates.Id + CharacterDescriptions.CharacterId + CharacterLocations.CharacterId
        allowed_char = _build_set(c.CharacterId for c in snapshot.CharacterStates)
        allowed_char |= _build_set(cd.CharacterId for cd in snapshot.CharacterDescriptions)
        allowed_char |= _build_set(cl.CharacterId for cl in snapshot.CharacterLocations)

        # Location: LocationStates.LocationId + LocationDescriptions.LocationId + CharacterLocations.CurrentLocation
        allowed_loc = _build_set(l.LocationId for l in snapshot.LocationStates)
        allowed_loc |= _build_set(ld.LocationId for ld in snapshot.LocationDescriptions)
        allowed_loc |= _build_set(cl.CurrentLocation for cl in snapshot.CharacterLocations)

        allowed_fac = _build_set(f.FactionId for f in snapshot.FactionStates)
        allowed_conf = _build_set(c.ConflictId for c in snapshot.ConflictProgress)
        allowed_fs = _build_set(f.ForeshadowId for f in snapshot.ForeshadowingStatus)
        allowed_item = _build_set(i.ItemId for i in snapshot.ItemStates)
        allowed_secret = _build_set(s.SecretId for s in snapshot.SecretStates)
        allowed_pledge = _build_set(p.PledgeId for p in snapshot.PledgeStates)
        allowed_deadline = _build_set(d.DeadlineId for d in snapshot.DeadlineStates)

        # 注入 contextIds 扩展合法 ID 范围（对标 ContextIdCollection）
        context_ids = self._current_context_ids if hasattr(self, "_current_context_ids") else None
        if context_ids:
            for cid in context_ids.get("characters", []) or []:
                if cid: allowed_char.add(cid)
            for lid in context_ids.get("locations", []) or []:
                if lid: allowed_loc.add(lid)
            for fid in context_ids.get("factions", []) or []:
                if fid: allowed_fac.add(fid)
            for cid in context_ids.get("conflicts", []) or []:
                if cid: allowed_conf.add(cid)
            for fid in context_ids.get("foreshadow_setups", []) or []:
                if fid: allowed_fs.add(fid)
            for fid in context_ids.get("foreshadow_payoffs", []) or []:
                if fid: allowed_fs.add(fid)

        def _allowed_for(entity_type: str) -> set:
            return {
                "Character": allowed_char,
                "Location": allowed_loc,
                "Conflict": allowed_conf,
                "Foreshadowing": allowed_fs,
                "Faction": allowed_fac,
                "Item": allowed_item,
                "Secret": allowed_secret,
                "Pledge": allowed_pledge,
                "Deadline": allowed_deadline,
            }.get(entity_type, set())

        # ---- 对标 RequireIn: 逐字段校验 ----
        def _require_in(field_key: str, value):
            if not value or not is_likely_id(str(value).strip()):
                return
            val = str(value).strip()
            entity_type = self._get_entity_type(field_key)
            if entity_type is None:
                return
            allowed = _allowed_for(entity_type)

            if not allowed:
                # 账本无记录
                if entity_type not in self._CREATABLE_TYPES:
                    cn_name = self._get_field_cn_name(field_key)
                    errors.append(
                        f"CHANGES协议违规：{cn_name} 账本无追踪记录，字段 {field_key} 应留空，收到非法值'{val}'")
                # 可创建类型: 允许通过（自动创建由 Canonicalizer 处理）
                return

            if val in allowed:
                return

            cn_name = self._get_field_cn_name(field_key)
            errors.append(
                f"CHANGES协议违规：{cn_name} 必须为 ShortId（必须来自事实账本），收到非法值'{val}'")

        # ---- 遍历所有 CHANGES 字段（对标 C# foreach） ----

        # CharacterStateChanges: CharacterId + RelationshipChanges keys
        for ch in changes.CharacterStateChanges or []:
            _require_in("CharacterStateCharacterId", ch.CharacterId)
            for rel_key in (ch.RelationshipChanges or {}).keys():
                _require_in("CharacterStateRelationshipKey", rel_key)

        # ConflictProgress: ConflictId
        for cp in changes.ConflictProgress or []:
            _require_in("ConflictConflictId", cp.ConflictId)

        # ForeshadowingActions: ForeshadowId
        for fa in changes.ForeshadowingActions or []:
            _require_in("ForeshadowForeshadowId", fa.ForeshadowId)

        # LocationStateChanges: LocationId（对标: 空账本 + 有LocationName 允许创建）
        created_loc_ids = set()
        for lc in changes.LocationStateChanges or []:
            if lc.LocationName and lc.LocationId:
                created_loc_ids.add(str(lc.LocationId).strip())
        for m in changes.CharacterMovements or []:
            if m.ToLocationName and m.ToLocation:
                created_loc_ids.add(str(m.ToLocation).strip())
        allowed_loc |= created_loc_ids

        for lc in changes.LocationStateChanges or []:
            if lc.LocationId:
                if not allowed_loc:
                    if not lc.LocationName:
                        cn_name = self._get_field_cn_name("LocationLocationId")
                        errors.append(
                            f"CHANGES协议违规：{cn_name} 必须为 ShortId（必须来自事实账本或提供LocationName以创建新地点），收到非法值'{lc.LocationId}'")
                elif lc.LocationId in allowed_loc or not lc.LocationName:
                    _require_in("LocationLocationId", lc.LocationId)

        # FactionStateChanges: FactionId
        for fa in changes.FactionStateChanges or []:
            _require_in("FactionFactionId", fa.FactionId)

        # CharacterMovements: CharacterId + FromLocation + ToLocation
        for m in changes.CharacterMovements or []:
            _require_in("MovementCharacterId", m.CharacterId)
            if m.FromLocation and str(m.FromLocation).strip() not in created_loc_ids:
                _require_in("MovementFromLocation", m.FromLocation)
            if m.ToLocation:
                if not allowed_loc:
                    if not m.ToLocationName:
                        cn_name = self._get_field_cn_name("MovementToLocation")
                        errors.append(
                            f"CHANGES协议违规：{cn_name} 必须为 ShortId（必须来自事实账本或提供ToLocationName以创建新地点），收到非法值'{m.ToLocation}'")
                elif m.ToLocation in allowed_loc or not m.ToLocationName:
                    _require_in("MovementToLocation", m.ToLocation)

        # ItemTransfers: ItemId + FromHolder + ToHolder（对标: 账本空 + 有 ItemName 允许新物品）
        for it in changes.ItemTransfers or []:
            if it.ItemId:
                if not allowed_item:
                    if not it.ItemName:
                        cn_name = self._get_field_cn_name("ItemTransferItemId")
                        errors.append(
                            f"CHANGES协议违规：{cn_name} 必须为 ShortId（必须来自事实账本或提供ItemName以创建新物品），收到非法值'{it.ItemId}'")
                elif it.ItemId in allowed_item or not it.ItemName:
                    _require_in("ItemTransferItemId", it.ItemId)
            _require_in("ItemTransferFromHolder", it.FromHolder)
            _require_in("ItemTransferToHolder", it.ToHolder)

        # SecretRevealChanges: SecretId + NewKnowerIds（对标: 账本空 + 有 SecretName 允许）
        for s in changes.SecretRevealChanges or []:
            if s.SecretId:
                if not allowed_secret:
                    if not s.SecretName:
                        cn_name = self._get_field_cn_name("SecretSecretId")
                        errors.append(
                            f"CHANGES协议违规：{cn_name} 必须为 ShortId（必须来自事实账本或提供SecretName以创建新秘密），收到非法值'{s.SecretId}'")
                elif s.SecretId in allowed_secret or not s.SecretName:
                    _require_in("SecretSecretId", s.SecretId)
            for knower_id in (s.NewKnowerIds or []):
                _require_in("SecretNewKnowerId", knower_id)

        # NewPlotPoints: InvolvedCharacters
        for pp in changes.NewPlotPoints or []:
            for ic in (pp.InvolvedCharacters or []):
                _require_in("PlotInvolvedCharacter", ic)

        # PledgeConstraintChanges: PledgeId（对标: create + PledgeName 允许）+ PartyIds
        for pc in changes.PledgeConstraintChanges or []:
            if pc.PledgeId:
                is_create = str(pc.Action or "").lower() == "create"
                if not allowed_pledge:
                    if not is_create or not pc.PledgeName:
                        cn_name = self._get_field_cn_name("PledgePledgeId")
                        errors.append(
                            f"CHANGES协议违规：{cn_name} 必须为 ShortId（必须来自事实账本或提供Action=create+PledgeName以创建新承诺），收到非法值'{pc.PledgeId}'（Action='{pc.Action}'）")
                elif is_create and pc.PledgeId not in allowed_pledge and pc.PledgeName:
                    pass  # 创建新承诺，允许新 ID
                else:
                    _require_in("PledgePledgeId", pc.PledgeId)
            for pid in (pc.PartyIds or []):
                _require_in("PledgePartyId", pid)

        # DeadlineConstraintChanges: DeadlineId（对标: create + DeadlineName 允许）+ PartyIds
        for dc in changes.DeadlineConstraintChanges or []:
            if dc.DeadlineId:
                is_create = str(dc.Action or "").lower() == "create"
                if not allowed_deadline:
                    if not is_create or not dc.DeadlineName:
                        cn_name = self._get_field_cn_name("DeadlineDeadlineId")
                        errors.append(
                            f"CHANGES协议违规：{cn_name} 必须为 ShortId（必须来自事实账本或提供Action=create+DeadlineName以创建新倒计时），收到非法值'{dc.DeadlineId}'（Action='{dc.Action}'）")
                elif is_create and dc.DeadlineId not in allowed_deadline and dc.DeadlineName:
                    pass  # 创建新倒计时，允许新 ID
                else:
                    _require_in("DeadlineDeadlineId", dc.DeadlineId)
            for pid in (dc.PartyIds or []):
                _require_in("DeadlinePartyId", pid)

        return errors

    # ====== Gate 3: Consistency ======
    def _consistency_check(self, changes: ChapterChanges, snapshot: FactSnapshot) -> List[str]:
        """对标 LedgerConsistencyChecker: V1-V8"""
        errors = []
        fs_by_id = {f.ForeshadowId: f for f in snapshot.ForeshadowingStatus}
        conf_by_id = {c.ConflictId: c for c in snapshot.ConflictProgress}
        char_by_id = {c.CharacterId: c for c in snapshot.CharacterStates}
        loc_by_id = {c.CharacterId: c for c in snapshot.CharacterLocations}
        item_by_id = {i.ItemId: i for i in snapshot.ItemStates}

        # V1 伏笔
        for f in changes.ForeshadowingActions:
            entry = fs_by_id.get(f.ForeshadowId)
            if entry:
                if f.Action == "setup" and entry.IsResolved:
                    errors.append(f"伏笔[{entry.Name}]已揭示状态不可回退为setup")
                if f.Action == "payoff" and not entry.IsSetup:
                    errors.append(f"伏笔[{entry.Name}]未埋设不可payoff")

        # V2 冲突状态序
        for c in changes.ConflictProgress:
            entry = conf_by_id.get(c.ConflictId)
            if entry and c.NewStatus:
                old = _normalize_conflict_status(entry.Status)
                new = _normalize_conflict_status(c.NewStatus)
                if old and new and old != new:
                    seq = ["pending", "active", "climax", "resolved"]
                    oi = seq.index(old) if old in seq else 1
                    ni = seq.index(new) if new in seq else 1
                    if ni < oi:
                        errors.append(f"冲突[{entry.Name}]状态回退: {entry.Status}→{c.NewStatus}")

        # V3 角色: CharacterNotInvolved + LevelRegression + AbilityLoss + TrustDelta
        involved_ids = set()
        for c in snapshot.CharacterStates:
            if c.CharacterId: involved_ids.add(c.CharacterId)
        for cd in snapshot.CharacterDescriptions:
            if cd.CharacterId: involved_ids.add(cd.CharacterId)

        char_by_id = {c.CharacterId: c for c in snapshot.CharacterStates}
        for c in changes.CharacterStateChanges:
            cid = c.CharacterId
            if not cid: continue

            # 对标 CharacterNotInvolved
            if involved_ids and cid not in involved_ids:
                name = char_by_id.get(cid, None)
                errors.append(f"角色不涉及: {name.Name if name else cid} 不在本章追踪角色中")

            entry = char_by_id.get(cid)
            if not entry: continue

            # 对标 LevelRegression
            if c.NewLevel and entry.Level:
                old_lv = _parse_level(entry.Level)
                new_lv = _parse_level(c.NewLevel)
                if old_lv >= 0 and new_lv >= 0 and new_lv < old_lv:
                    loss_kw = ["失去", "废除", "散功", "自废", "碎裂", "崩毁", "献祭", "剥夺", "吞噬", "陨落"]
                    has_loss = c.KeyEvent and any(k in (c.KeyEvent or "") for k in loss_kw)
                    if not has_loss:
                        errors.append(f"角色[{entry.Name}]境界回退: {entry.Level}→{c.NewLevel}（无失去事件）")

            # 对标 AbilityLossWithoutEvent
            if c.LostAbilities:
                loss_kw = ["失去", "废除", "散功", "自废", "碎裂", "崩毁", "献祭", "剥夺", "吞噬", "陨落",
                           "封印", "压制", "反噬", "重伤", "濒死", "断臂", "经脉", "修为尽失"]
                has_loss = c.KeyEvent and any(k in (c.KeyEvent or "") for k in loss_kw)
                if not has_loss:
                    errors.append(f"角色[{entry.Name}]失去能力需KeyEvent说明: {c.LostAbilities[:3]}")

            # 对标 TrustDeltaExceedsLimit
            for rid, rel in (c.RelationshipChanges or {}).items():
                td = abs(rel.TrustDelta) if isinstance(rel.TrustDelta, int) else 0
                if td > 30:
                    errors.append(f"角色[{entry.Name}]→{rid} 信任变化 {rel.TrustDelta} 超限(±30)")

        # V4 移动: 同章多点链连续性 + 账本匹配 + 地点容错
        move_by_char = {}
        for m in changes.CharacterMovements:
            if m.CharacterId:
                move_by_char.setdefault(m.CharacterId, []).append(m)
        for m_list in move_by_char.values():
            for i in range(1, len(m_list)):
                prev_to = m_list[i - 1].ToLocation
                curr_from = m_list[i].FromLocation
                if prev_to and curr_from and prev_to != curr_from:
                    cid = m_list[i].CharacterId
                    entry = char_by_id.get(cid)
                    errors.append(f"角色[{entry.Name if entry else cid}]移动链断裂: {prev_to}→{curr_from}")

        loc_by_char = {}
        for cl in snapshot.CharacterLocations:
            if cl.CharacterId and cl.CurrentLocation:
                loc_by_char[cl.CharacterId] = cl.CurrentLocation
        # 构建可用的地点ID集合（容错）
        chapter_locs = set()
        for ls in snapshot.LocationStates:
            if ls.LocationId: chapter_locs.add(ls.LocationId)
        for ld in snapshot.LocationDescriptions:
            if ld.LocationId: chapter_locs.add(ld.LocationId)

        for m in changes.CharacterMovements:
            if not m.FromLocation or not m.CharacterId: continue
            known = loc_by_char.get(m.CharacterId)
            if known and m.FromLocation != known:
                if m.FromLocation not in chapter_locs:
                    errors.append(f"角色移动出发地不匹配: 账本[{known}] vs [{m.FromLocation}]")
            if m.ToLocation:
                loc_by_char[m.CharacterId] = m.ToLocation

        # V5 物品: rolling holder map + 角色容错
        rolling_item = {}
        for is_ in snapshot.ItemStates:
            if is_.ItemId and is_.CurrentHolder:
                rolling_item[is_.ItemId] = is_.CurrentHolder
        chapter_chars = set()
        for c in snapshot.CharacterStates:
            if c.CharacterId: chapter_chars.add(c.CharacterId)

        for t in changes.ItemTransfers:
            if not t.FromHolder or not t.ItemId: continue
            known = rolling_item.get(t.ItemId)
            if known and t.FromHolder != known:
                if t.FromHolder not in chapter_chars:
                    errors.append(f"物品[{t.ItemName or t.ItemId}]持有者不匹配: 账本[{known}] vs [{t.FromHolder}]")
            rolling_item[t.ItemId] = t.ToHolder or ""

        # V6 关系: ally+enemy 双向对检测
        ally_pairs = set()
        enemy_pairs = set()
        for c in changes.CharacterStateChanges:
            if not c.CharacterId: continue
            for rid, rel in (c.RelationshipChanges or {}).items():
                if not rid: continue
                pair = (c.CharacterId, rid) if c.CharacterId <= rid else (rid, c.CharacterId)
                rtype = rel.Relation or ""
                if _is_ally(rtype): ally_pairs.add(pair)
                if _is_enemy(rtype): enemy_pairs.add(pair)
        both = ally_pairs & enemy_pairs
        for p in both:
            errors.append(f"角色 {p[0]} 与 {p[1]} 同时声明盟友和仇敌（关系矛盾）")

        # V7 誓约: duplicate create + 同章多终止
        pled_active = {p.PledgeId for p in snapshot.PledgeStates if p.PledgeId}
        pled_term = {}
        for p in changes.PledgeConstraintChanges:
            if not p.PledgeId: continue
            act = (p.Action or "").lower()
            if act == "create" and p.PledgeId in pled_active:
                errors.append(f"誓约[{p.PledgeId}]重复create")
            if act in ("fulfill", "break"):
                pled_term.setdefault(p.PledgeId, []).append(act)
        for pid, acts in pled_term.items():
            if len(acts) > 1:
                errors.append(f"誓约[{pid}]同章多个终止动作: {acts}")

        # V8 倒计时: duplicate create + 同章多终止
        ddl_active = {d.DeadlineId for d in snapshot.DeadlineStates if d.DeadlineId}
        ddl_term = {}
        for d in changes.DeadlineConstraintChanges:
            if not d.DeadlineId: continue
            act = (d.Action or "").lower()
            if act == "create" and d.DeadlineId in ddl_active:
                errors.append(f"倒计时[{d.DeadlineId}]重复create")
            if act in ("trigger", "expire", "cancel"):
                ddl_term.setdefault(d.DeadlineId, []).append(act)
        for did, acts in ddl_term.items():
            if len(acts) > 1:
                errors.append(f"倒计时[{did}]同章多个终止动作: {acts}")

        return errors

    @staticmethod
    def _level_value(level: str) -> float:
        m = re.search(r"(\d+)", str(level))
        if m: return float(m.group(1))
        seq = ["炼气", "筑基", "金丹", "元婴", "化神", "炼虚", "合体", "大乘", "渡劫",
               "凡", "武", "师", "宗", "尊", "帝", "仙", "圣", "神",
               "引气", "凝液", "结丹", "出窍", "分神"]
        for i, k in enumerate(seq):
            if k in str(level): return i + 10
        return 5

    # ====== Gate 4: Unknown Entities ======
    def _unknown_entity_check(self, content: str, changes: ChapterChanges, snapshot: FactSnapshot) -> List[str]:
        """对标 ContentEntityExtractor: 功能性 vs 龙套"""
        known = set()
        for c in snapshot.CharacterStates:
            if c.Name: known.add(c.Name)
        for l in snapshot.LocationStates:
            if l.Name: known.add(l.Name)
        for ld in snapshot.LocationDescriptions:
            if ld.Name: known.add(ld.Name)
        for cd in snapshot.CharacterDescriptions:
            if cd.Name: known.add(cd.Name)
        for f in snapshot.FactionStates:
            if f.Name: known.add(f.Name)

        # 对标 QuotedDialogueRegex: ["](1-10字)["](说|道|问|答|笑|喊|叫|骂)
        dialogue_names = re.findall(r'[“\"]([^”\"\n]{1,10}?)[”\"](?:说|道|问|答|笑|喊|叫|骂)', content)
        all_found = []
        for name in dialogue_names:
            name = name.strip()
            if not name or name in known or name in STOP_WORDS: continue
            if len(name) < 2 or len(name) > 6: continue
            if any(ch in '，。！？、；：""''（）【】' or ch.isdigit() for ch in name): continue
            all_found.append(name)

        # 分类：对标 IsEntityInChanges 分字段搜索
        functional_entities = [n for n in all_found if _is_entity_in_changes(n, changes)]
        background_entities = [n for n in all_found if n not in functional_entities]
        total = len(set(all_found))
        bg_count = len(set(background_entities))

        if total > 5 or bg_count > 3:
            return [f"正文引入未登记实体（功能{len(functional_entities)}个/龙套{bg_count}个）: {'、'.join(set(all_found)[:8])}"]
        return []

    @staticmethod
    def _in_changes_name(name: str, changes: ChapterChanges) -> bool:
        """[deprecated] 保留兼容，实际使用 _is_entity_in_changes"""
        return _is_entity_in_changes(name, changes)

    # ====== Gate 5: Description Consistency（对标 ContentDescriptionValidator） ======
    def _description_check(self, content: str, snapshot: FactSnapshot) -> List[str]:
        """对标 ContentDescriptionValidator: 角色描述 + 地点描述"""
        errors = []

        # ---- 角色描述校验（对标 ValidateCharacterDescriptions） ----
        for cd in snapshot.CharacterDescriptions:
            if not cd.Name:
                continue

            # 发色矛盾检测
            if cd.HairColor:
                contradiction = _find_hair_color_contradiction(content, cd.Name, cd.HairColor)
                if contradiction:
                    errors.append(f"角色 {cd.Name} 发色矛盾: 设定={cd.HairColor}，正文出现={contradiction}")

            # 性格标签矛盾检测
            if cd.PersonalityTags:
                for tag in cd.PersonalityTags:
                    antonyms = _get_antonyms(tag)
                    for antonym in antonyms:
                        if _content_contains_near(content, cd.Name, antonym, 50):
                            errors.append(f"角色 {cd.Name} 性格矛盾: 设定={tag}，正文出现={antonym}")

        # ---- 地点描述校验（对标 ValidateLocationDescriptions） ----
        for ld in snapshot.LocationDescriptions:
            if not ld.Name or not ld.Features:
                continue
            for feature in ld.Features:
                antonyms = _get_antonyms(feature)
                for antonym in antonyms:
                    if _content_contains_near(content, ld.Name, antonym, 100):
                        errors.append(f"地点 {ld.Name} 特征矛盾: 设定={feature}，正文出现={antonym}")

        return errors

    # ====== Gate 6: World Rule Constraints（对标 ValidateWorldRuleConstraints） ======
    def _world_rule_check(self, content: str, snapshot: FactSnapshot) -> List[str]:
        """对标 ValidateWorldRuleConstraints: 硬约束否定词检测"""
        violations = []
        for wr in snapshot.WorldRuleConstraints:
            if not wr.Content or not wr.IsHardConstraint:
                continue
            violation = _check_constraint_violation(content, wr.Content)
            if violation:
                violations.append(f"世界观硬约束违反 [{wr.RuleId or wr.Content[:40]}]: {violation}")
        return violations

    # ====== Post-gate: Design Element Presence（对标 ValidateDesignElementPresence） ======
    def _design_presence_check(self, content: str, design_names: Dict[str, List[str]]) -> List[str]:
        """对标 ValidateDesignElementPresence: 阈值 max(3, total/3) + 变体名匹配 + qualityWarnings"""
        errors = []

        def _count_name(text: str, full_name: str) -> int:
            """对标 CountNameInContent: 变体名匹配（括号别名 + 去注释主名）"""
            if not text or not full_name:
                return 0
            variants = []
            def _add_variant(s):
                s = s.strip()
                if len(s) >= 2 and s not in variants:
                    variants.append(s)
            _add_variant(full_name)
            # 去括号注释提取主名
            primary = _strip_bracket_annotation(full_name)
            if primary and primary != full_name:
                _add_variant(primary)
            # 提取括号中的别名
            for m in re.finditer(r'[（(](.+?)[）)]', full_name):
                _add_variant(m.group(1))
            max_count = 0
            for v in variants:
                cnt = content.count(v)
                if cnt > max_count:
                    max_count = cnt
            return max_count

        absent = []
        total_elements = 0
        for kind, names in design_names.items():
            for name in names:
                if not name:
                    continue
                total_elements += 1
                count = _count_name(content, name)
                if count == 0:
                    if kind == "视角角色":
                        continue  # POV缺席仅warn，不拦截
                    absent.append(f"{kind}:{name}")

        if absent:
            threshold = max(3, total_elements // 3)
            if len(absent) > threshold:
                errors.append(f"设计指定实体缺席（{len(absent)}/{total_elements}, 阈值{threshold}）: {'、'.join(absent[:6])}")
        return errors

    # ====== Post-gate: Omission Detection（对标 EntityOmissionDetector + AutoPatch） ======
    def _omission_check(self, content: str, changes: ChapterChanges, snapshot: FactSnapshot) -> List[str]:
        """对标 OmissionDetector: 正文出现但CHANGES未申报 → 按维度自动补录"""
        from .models import CharacterStateChange

        # 角色漏报检测
        char_names = {c.Name for c in snapshot.CharacterStates if c.Name and len(c.Name) >= 2}
        for name in char_names:
            if name not in content:
                continue
            if _is_entity_in_changes(name, changes):
                continue
            # 自动补录（对标 AutoPatch）
            changes.CharacterStateChanges.append(CharacterStateChange(
                CharacterId=name, Importance="normal",
                KeyEvent=f"在本章出场（系统自动补录）"))

        # 地点漏报检测
        loc_names = {l.Name for l in snapshot.LocationStates if l.Name and len(l.Name) >= 2}
        for name in loc_names:
            if name not in content:
                continue
            if _is_entity_in_changes(name, changes):
                continue
            from .models import LocationStateChange
            changes.LocationStateChanges.append(LocationStateChange(
                LocationId=name, LocationName=name, Importance="normal",
                Event=f"在本章出现（系统自动补录）"))

        # 势力漏报检测
        fac_names = {f.Name for f in snapshot.FactionStates if f.Name and len(f.Name) >= 2}
        for name in fac_names:
            if name not in content:
                continue
            if _is_entity_in_changes(name, changes):
                continue
            from .models import FactionStateChange
            changes.FactionStateChanges.append(FactionStateChange(
                FactionId=name, Importance="normal",
                Event=f"在本章出现（系统自动补录）"))

        return []


# ====== 对标 ParseLevelNumber: tier/阿拉伯/罗马/中文/字母等级 ======
_LEVEL_SEQ = ["炼气", "筑基", "金丹", "元婴", "化神", "炼虚", "合体", "大乘", "渡劫",
              "凡", "武", "师", "宗", "尊", "帝", "仙", "圣", "神",
              "引气", "凝液", "结丹", "出窍", "分神", "融合"]


def _parse_level(level: str) -> int:
    """对标 LedgerConsistencyChecker.ParseLevelNumber"""
    if not level or not level.strip():
        return -1
    text = level.strip()
    m = re.search(r"tier\s*[-_]?\s*(\d+)", text, re.I)
    if m: return int(m.group(1))
    m = re.search(r"\b[IVXLCDM]+\b", text, re.I)
    if m:
        v = _parse_roman(m.group(0))
        if v > 0: return v
    m = re.search(r"[零一二三四五六七八九十百千万两]+", text)
    if m:
        v = _parse_chinese_num(m.group(0))
        if v > 0: return v
    m = re.search(r"\b(SSS|SS|S|A|B|C|D|E|F)\b", text, re.I)
    if m:
        gv = {"SSS": 7, "SS": 6, "S": 5, "A": 4, "B": 3, "C": 2, "D": 1, "E": 0, "F": -1}
        return gv.get(m.group(1).upper(), -1)
    m = re.search(r"\d+", text)
    if m: return int(m.group(0))
    for i, k in enumerate(_LEVEL_SEQ):
        if k in text: return i + 10
    return -1


def _parse_roman(s: str) -> int:
    vals = {"I": 1, "V": 5, "X": 10, "L": 50, "C": 100, "D": 500, "M": 1000}
    total, prev = 0, 0
    for c in s.upper():
        if c not in vals: return 0
        cur = vals[c]
        total += cur - 2 * prev if cur > prev else cur
        prev = cur
    return total


def _parse_chinese_num(s: str) -> int:
    d = {"零": 0, "一": 1, "二": 2, "两": 2, "三": 3, "四": 4,
         "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}
    r, sec, n = 0, 0, 0
    for c in s:
        if c in d:
            n = d[c]
            continue
        if c == "十": u = 10
        elif c == "百": u = 100
        elif c == "千": u = 1000
        elif c == "万":
            sec += n; r += sec * 10000; sec, n = 0, 0
            continue
        else: return 0
        sec += (n or 1) * u; n = 0
    return r + sec + n


def _normalize_conflict_status(status: str) -> str:
    """对标 NormalizeConflictStatus: 30+中英同义词"""
    if not status or not status.strip():
        return ""
    s = status.strip()
    lo = s.lower()
    if lo in ("pending", "todo", "new", "open"): return "pending"
    if lo in ("active", "ongoing", "running", "inprogress", "in_progress"): return "active"
    if lo in ("climax", "peak", "burst", "explosion"): return "climax"
    if lo in ("resolved", "done", "closed", "finished", "complete", "completed"): return "resolved"
    if any(k in s for k in ("未",)) and any(k in s for k in ("开始", "触发", "启动", "发生", "激活")):
        return "pending"
    if any(k in s for k in ("进行", "推进", "发展", "展开", "激活", "开启", "进展", "持续", "继续", "升级", "恶化")):
        return "active"
    if any(k in s for k in ("高潮", "爆发", "决战", "决裂", "临界", "白热化", "最高点", "紧要关头", "危急", "巅峰")):
        return "climax"
    if any(k in s for k in ("解决", "结束", "完结", "收束", "已结", "闭环", "落幕", "告终", "平息", "化解", "消弭", "了结")):
        return "resolved"
    return lo


# ====== 对标 IsAllyRelation / IsEnemyRelation ======
_ALLY_KW = ["盟友", "同盟", "结盟", "挚友", "知己", "朋友", "好友", "友人", "亲友",
            "兄弟", "姐妹", "手足", "恋人", "爱人", "夫妻", "伙伴", "同伴", "战友",
            "心腹", "亲信", "ally", "friend"]
_ENEMY_KW = ["仇敌", "敌对", "宿敌", "敌人", "死敌", "仇人", "对头", "政敌", "寇仇",
             "冤家", "反目", "决裂", "enemy", "hostile"]


def _is_ally(relation: str) -> bool:
    if not relation: return False
    r = relation.lower()
    return any(k in r for k in _ALLY_KW)


def _is_enemy(relation: str) -> bool:
    if not relation: return False
    r = relation.lower()
    return any(k in r for k in _ENEMY_KW)


# ==== Gate 4 辅助: 对标 IsEntityInChanges 分字段搜索 ====

def _contains_name(text, entity_name: str) -> bool:
    """对标 ContainsEntityName"""
    if not text or not entity_name:
        return False
    return entity_name in str(text)


def _is_entity_in_changes(entity_name: str, changes) -> bool:
    """对标 IsEntityInChanges: 按字段类型逐字段搜索实���名"""
    name = entity_name.strip()

    for c in changes.CharacterStateChanges or []:
        if _contains_name(c.CharacterId, name) or _contains_name(c.KeyEvent, name):
            return True

    for c in changes.ConflictProgress or []:
        if _contains_name(c.ConflictId, name) or _contains_name(c.Event, name):
            return True

    for f in changes.ForeshadowingActions or []:
        if _contains_name(f.ForeshadowId, name):
            return True

    for p in changes.NewPlotPoints or []:
        if _contains_name(p.Context, name):
            return True
        for ic in (p.InvolvedCharacters or []):
            if _contains_name(ic, name):
                return True

    for l in changes.LocationStateChanges or []:
        if _contains_name(l.LocationId, name) or _contains_name(l.LocationName, name) or _contains_name(l.Event, name):
            return True

    for fa in changes.FactionStateChanges or []:
        if _contains_name(fa.FactionId, name) or _contains_name(fa.Event, name):
            return True

    for m in changes.CharacterMovements or []:
        if _contains_name(m.CharacterId, name) or _contains_name(m.ToLocationName, name) or _contains_name(m.ToLocation, name) or _contains_name(m.FromLocation, name):
            return True

    for it in changes.ItemTransfers or []:
        if _contains_name(it.ItemName, name) or _contains_name(it.Event, name):
            return True

    return False


# ==== Gate 1 辅助: 对标 ExtractJsonFromChangesSection + dict→ChapterChanges ====

def _extract_json_from_changes_section(changes_section: str) -> str:
    """对标 ExtractJsonFromChangesSection: 从CHANGES段提取纯JSON"""
    content = changes_section.strip()
    if not content:
        return ""
    # 去掉 markdown 代码块包裹
    if content.startswith("```"):
        first_nl = content.find("\n")
        if first_nl > 0:
            content = content[first_nl + 1:]
        last_backticks = content.rfind("```")
        if last_backticks > 0:
            content = content[:last_backticks]
    content = content.strip()

    json_start = content.find("{")
    if json_start < 0:
        return content

    import json as _json
    best = ""
    end = content.find("}", json_start + 1)
    while end > json_start:
        candidate = content[json_start : end + 1]
        try:
            doc = _json.loads(candidate)
            if isinstance(doc, dict):
                return candidate
        except _json.JSONDecodeError:
            best = candidate
        end = content.find("}", end + 1)

    return best if best else content[json_start:]


def _dict_to_chapter_changes(data: dict):
    """对标 ParseChangesContent: dict → ChapterChanges"""
    from .models import (
        ChapterChanges, CharacterStateChange, ConflictProgressChange,
        PlotPointChange, ForeshadowingAction, LocationStateChange,
        FactionStateChange, TimeProgressionChange, CharacterMovementChange,
        ItemTransferChange, SecretRevealChange, PledgeConstraintChange,
        DeadlineConstraintChange,
    )
    cc = ChapterChanges()
    cc.CharacterStateChanges = [CharacterStateChange.from_dict(d) for d in data.get("CharacterStateChanges", []) or [] if isinstance(d, dict)]
    cc.ConflictProgress = [ConflictProgressChange.from_dict(d) for d in data.get("ConflictProgress", []) or [] if isinstance(d, dict)]
    cc.NewPlotPoints = [PlotPointChange.from_dict(d) for d in data.get("NewPlotPoints", []) or [] if isinstance(d, dict)]
    cc.ForeshadowingActions = [ForeshadowingAction.from_dict(d) for d in data.get("ForeshadowingActions", []) or [] if isinstance(d, dict)]
    cc.LocationStateChanges = [LocationStateChange.from_dict(d) for d in data.get("LocationStateChanges", []) or [] if isinstance(d, dict)]
    cc.FactionStateChanges = [FactionStateChange.from_dict(d) for d in data.get("FactionStateChanges", []) or [] if isinstance(d, dict)]
    cc.TimeProgression = [TimeProgressionChange.from_dict(d) for d in data.get("TimeProgression", []) or [] if isinstance(d, dict)]
    cc.CharacterMovements = [CharacterMovementChange.from_dict(d) for d in data.get("CharacterMovements", []) or [] if isinstance(d, dict)]
    cc.ItemTransfers = [ItemTransferChange.from_dict(d) for d in data.get("ItemTransfers", []) or [] if isinstance(d, dict)]
    cc.SecretRevealChanges = [SecretRevealChange.from_dict(d) for d in data.get("SecretRevealChanges", []) or [] if isinstance(d, dict)]
    cc.PledgeConstraintChanges = [PledgeConstraintChange.from_dict(d) for d in data.get("PledgeConstraintChanges", []) or [] if isinstance(d, dict)]
    cc.DeadlineConstraintChanges = [DeadlineConstraintChange.from_dict(d) for d in data.get("DeadlineConstraintChanges", []) or [] if isinstance(d, dict)]
    return cc


# ==== Gate 5 辅助: 对标 ContentDescriptionValidator helpers ====

def _content_contains_near(content: str, anchor: str, target: str, max_distance: int) -> bool:
    """对标 ContentContainsNear: 锚点词附近 max_distance 字符内是否包含目标词"""
    if not content or not anchor or not target:
        return False
    idx = content.find(anchor)
    if idx < 0:
        return False
    search_start = max(0, idx - max_distance)
    search_end = min(len(content), idx + len(anchor) + max_distance)
    return target in content[search_start:search_end]


def _find_hair_color_contradiction(content: str, character_name: str, expected_color: str) -> str:
    """对标 FindHairColorContradiction"""
    other_colors = [c for c in HAIR_COLORS if c != expected_color and expected_color not in c and c not in expected_color]
    for color in other_colors:
        if _content_contains_near(content, character_name, color, 30):
            return color
    return ""


def _get_antonyms(tag: str) -> list:
    """对标 GetAntonyms"""
    return ANTONYM_PAIRS.get(tag, [])


# ==== Gate 6 辅助: 对标 ValidateWorldRuleConstraints helpers ====

_NEGATION_PATTERNS = [
    "不能", "不可", "禁止", "严禁", "不得", "不准", "不许",
    "不应", "无法", "不会", "绝不可", "绝不能", "绝不允许",
]

_NEGATION_PREFIXES = [
    "不能", "不可", "禁止", "严禁", "无法", "不得", "不准", "不许",
    "不应", "不会", "别", "莫", "勿", "休要", "切勿", "切不可",
    "未曾", "从未", "并未", "没有", "绝不", "绝无", "岂能", "怎能", "哪能", "焉能",
]


def _strip_bracket_annotation(name: str) -> str:
    """对标 EntityNameNormalizeHelper.StripBracketAnnotation: 去掉括号注释"""
    if not name:
        return ""
    m = re.match(r'^(.+?)[（(].*[）)]$', name.strip())
    if m:
        return m.group(1).strip()
    return name.strip()


def _check_constraint_violation(content: str, constraint: str) -> str:
    """对标 CheckConstraintViolation"""
    for negation in _NEGATION_PATTERNS:
        idx = constraint.find(negation)
        if idx >= 0:
            action_start = idx + len(negation)
            action_length = min(10, len(constraint) - action_start)
            if action_length > 0:
                forbidden_action = constraint[action_start : action_start + action_length].strip()
                forbidden_action = forbidden_action.rstrip("，。、；")
                if len(forbidden_action) >= 2:
                    if _has_violating_occurrence(content, forbidden_action):
                        return f"正文出现被禁止的内容「{forbidden_action}」（约束：{constraint}）"
    return ""


def _has_violating_occurrence(content: str, forbidden_action: str) -> bool:
    """对标 HasViolatingOccurrence: 在句子上下文中检测违禁词（排除被否定的情况）"""
    search_start = 0
    while search_start < len(content):
        pos = content.find(forbidden_action, search_start)
        if pos < 0:
            break
        # 取前面最多15字符的上下文
        context_start = max(0, pos - 15)
        prefix = content[context_start:pos]
        # 截到上一个句末
        sent_break = max(prefix.rfind("。"), prefix.rfind("！"), prefix.rfind("？"), prefix.rfind("；"), prefix.rfind("\n"))
        if sent_break >= 0:
            prefix = prefix[sent_break + 1:]

        is_negated = any(neg in prefix for neg in _NEGATION_PREFIXES)
        if not is_negated:
            return True
        search_start = pos + len(forbidden_action)
    return False
