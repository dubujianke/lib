# -*- coding: utf-8 -*-
"""创作管线：从概念到章节的完整流程编排"""

import json
import os
from typing import Dict, List, Optional

from .models import (
    WorldRulesData, CharacterRulesData, FactionRulesData,
    LocationRulesData, PlotRulesData, CreativeMaterialData,
    OutlineData, VolumeDesignData, ChapterData, BlueprintData,
)
from .ai_service import AIService
from .prompt_library import PromptLibrary
from .design_generator_v4 import DesignGeneratorV4
from .planning_generator_v4 import PlanningGeneratorV4
from .writer import ChapterWriter
from .storage import Project, create_project


class NovelPipeline:
    """编排五维设定 → 四层规划 → 逐章生成"""

    def __init__(self, project: Project, ai: AIService, library: PromptLibrary):
        self.project = project
        self.ai = ai
        self.library = library
        self.design = DesignGeneratorV4(ai)
        self.planning = PlanningGeneratorV4(ai)
        self.writer = ChapterWriter(project, ai, library)

    # ---- 五维设定 (v4: 仅 {规则名称} 变量) ----
    def generate_design(self, genre: str, concept: str, total_volumes: int = 3,
                        total_chapters: int = 30, char_count: int = 3) -> dict:
        print("[1/5] 生成世界观规则...")
        world = self.design.generate_world_rules(f"{genre}世界观", concept)
        self._save_design_entity("world", [world.to_dict()])

        print("[2/5] 生成角色规则...")
        characters = []
        for i in range(char_count):
            c = self.design.generate_character(f"{genre}角色{i+1}", concept)
            characters.append(c)
        self._save_design_entity("characters", [c.to_dict() for c in characters])

        print("[3/5] 生成势力规则...")
        fc = max(2, char_count // 2 + 1)
        factions = []
        for i in range(fc):
            f = self.design.generate_faction(f"{genre}势力{i+1}", concept)
            factions.append(f)
        self._save_design_entity("factions", [f.to_dict() for f in factions])

        print("[4/5] 生成地点规则...")
        lc = max(3, char_count)
        locations = []
        for i in range(lc):
            l = self.design.generate_location(f"{genre}地点{i+1}", concept)
            locations.append(l)
        self._save_design_entity("locations", [l.to_dict() for l in locations])

        print("[5/5] 生成剧情规则...")
        plot = self.design.generate_plot_rule(
            f"{genre}主线", concept,
            extra={"total_volumes": str(total_volumes), "total_chapters": str(total_chapters)})
        self._save_design_entity("plot", [plot.to_dict()])

        print("    五维设定完成。")
        return {
            "world": world, "characters": characters, "factions": factions,
            "locations": locations, "plot": plot,
        }

    def _save_design_entity(self, entity: str, items: List[dict]):
        existing = self.project.load_design(entity)
        if isinstance(existing, dict) and "items" in existing:
            existing = existing.get("items", [])
        merged = list(existing or [])
        merged.extend(items)
        self.project.save_design(entity, {"items": merged})

    # ---- 四层规划 (v4: 小说创作者模板 + 上下文注入) ----
    def generate_plan(self, genre: str, total_chapters: int) -> dict:
        world = self._load_first("world")
        characters = self._load_all("characters")
        factions = self._load_all("factions")
        locations = self._load_all("locations")
        plot = self._load_first("plot")
        total_volumes = int(plot.get("TargetVolume", 2) or 2)

        # 构建基础上下文（设计数据 + 候选实体列表）
        char_names = [c.get('Name', '') for c in characters if c.get('Name')]
        fac_names = [f.get('Name', '') for f in factions if f.get('Name')]
        loc_names = [l.get('Name', '') for l in locations if l.get('Name')]
        base_ctx = f"""<design_context>
世界观: {world.get('OneLineSummary', '')[:200]}
力量体系: {world.get('PowerSystem', '')[:200]}
核心冲突: {plot.get('Conflict', '')[:200]}
主题: {plot.get('Goal', '')[:200]}
</design_context>
<available_characters>
可选角色（必须从以下选择，不得编造）：{'、'.join(char_names[:15])}
</available_characters>
<available_factions>
可选势力（必须从以下选择，不得编造）：{'、'.join(fac_names[:10])}
</available_factions>
<available_locations>
可选地点（必须从以下选择，不得编造）：{'、'.join(loc_names[:10])}
</available_locations>
<field_constraints>
1. 「出场角色」「涉及势力」「涉及地点」必须从上方的候选列表中精确选取，不得编造不存在于列表中的实体。
2. 如无合适的候选实体，留空即可，不要填「无」「暂无」等占位词。
</field_constraints>"""

        # Step 1: 大纲
        print("[1/4] 生成大纲...")
        outline = self.planning.generate_outline(total_chapters, base_ctx)
        self._save_plan_entity("outline", outline.to_dict())

        # Step 2: 分卷
        print(f"[2/4] 生成 {total_volumes} 卷分卷设计...")
        vol_range = self._calc_volume_ranges(outline.VolumeDivision, total_volumes, total_chapters)
        volumes = []
        for vn in range(1, total_volumes + 1):
            start, end = vol_range.get(vn, (1, total_chapters))
            vol_ctx = base_ctx + f"\n<outline_reference>\n大纲核心冲突: {outline.CoreConflict}\n卷划分: {outline.VolumeDivision[:200]}\n</outline_reference>"
            vol = self.planning.generate_volume(vn, start, end, vol_ctx)
            volumes.append(vol)
        self._save_plan_entity("volumes", [v.to_dict() for v in volumes])

        # Step 3: 章节
        print("[3/4] 生成章节设计...")
        all_chapters = []
        for vol in volumes:
            for num in range(vol.StartChapter, vol.EndChapter + 1):
                ch_ctx = base_ctx + f"\n<volume_reference>\n卷: 第{vol.VolumeNumber}卷「{vol.VolumeTitle}」\n阶段目标: {vol.StageGoal}\n主冲突: {vol.MainConflict}\n章节生成提示: {vol.ChapterGenerationHints}\n</volume_reference>"
                ch = self.planning.generate_chapter(num, vol.VolumeTitle, ch_ctx)
                all_chapters.append(ch)
        all_chapters.sort(key=lambda c: c.ChapterNumber)
        self._save_plan_entity("chapters", [c.to_dict() for c in all_chapters])

        # Step 4: 蓝图
        print("[4/4] 生成场景蓝图...")
        blueprints = {}
        for ch in all_chapters:
            bp_ctx = base_ctx + f"\n<chapter_reference>\n第{ch.ChapterNumber}章「{ch.ChapterTitle}」\n目标: {ch.MainGoal}\n转折: {ch.KeyTurn}\n钩子: {ch.Hook}\n</chapter_reference>"
            bp = self.planning.generate_blueprint(ch, bp_ctx)
            blueprints.setdefault(ch.Id, []).append(bp)
        for cid, bps in blueprints.items():
            self.project.save_plan(f"blueprints_{cid}", [b.to_dict() for b in bps])

        print("    四层规划完成。")

        # Preflight 校验（对标 PreflightValidator.RunAsync）
        from .preflight import PreflightValidator
        pf = PreflightValidator(self.project)
        pf.run()
        return {"outline": outline, "volumes": volumes,
                "chapters": all_chapters, "blueprints": blueprints}

    def _calc_volume_ranges(self, volume_division, total_volumes: int, total_chapters: int) -> dict:
        """对标 ChapterAllocationHelper"""
        vd = volume_division
        if isinstance(vd, str) and vd.strip():
            import re
            ranges = {}
            for m in re.finditer(r"第\s*(\d+)\s*卷[^0-9]*?(\d+)\s*[^0-9]*?(\d+)\s*章", vd):
                vn, s, e = int(m.group(1)), int(m.group(2)), int(m.group(3))
                ranges[vn] = (s, e)
            if len(ranges) == total_volumes:
                return ranges
        # 回退：算法分配
        ranges = {}
        per = max(1, total_chapters // total_volumes)
        for vn in range(1, total_volumes + 1):
            start = (vn - 1) * per + 1
            end = min(total_chapters, vn * per) if vn < total_volumes else total_chapters
            ranges[vn] = (max(start, 1), max(start, end))
        return ranges

    def _save_plan_entity(self, entity: str, item: dict):
        self.project.save_plan(entity, item)

    def _load_first(self, entity: str) -> dict:
        data = self.project.load_design(entity)
        items = data.get("items", []) if isinstance(data, dict) else (data or [])
        return items[0] if items else {}

    def _load_all(self, entity: str) -> List[dict]:
        data = self.project.load_design(entity)
        return data.get("items", []) if isinstance(data, dict) else (data or [])
# ---- 逐章生成 ----
    def generate_chapter(self, genre: str, chapter_number: int, creative_spec: str = "",
                         word_count: int = 3500, verbose: bool = True) -> dict:
        chapter = self._find_chapter(chapter_number)
        if not chapter:
            raise ValueError(f"未找到第 {chapter_number} 章设计")
        cd = ChapterData.from_dict(chapter)

        # 对标重复生成拦截: 检查章节是否已存在
        cid = cd.Id
        existing = self.project.load_chapter(cid)
        if existing and len(existing) > 100:
            print(f"  ⚠ 第 {chapter_number} 章已存在，跳过（如需重新生成请先删除）")
            return {"chapter_id": cid, "chapter_number": chapter_number,
                    "content": existing, "skipped": True}

        blueprints = self._load_blueprints(cd.Id)
        bps = [BlueprintData.from_dict(b) for b in blueprints]

        volumes = self.project.load_plan("volumes")
        vol_list = volumes if isinstance(volumes, list) else (volumes.get("volumes", []) if isinstance(volumes, dict) else [])
        chapter_vol = chapter.get("Volume", "")
        volume = next((v for v in vol_list if v.get("VolumeTitle") == chapter_vol), None)
        if not volume and vol_list:
            volume = vol_list[0]  # fallback to first volume

        # 对标自动存档前卷: 新卷第1章时存档前卷
        if chapter_number == 1:
            self._try_archive_previous_volume(volume)

        outline = self.project.load_plan("outline") or {}
        world = self._load_first("world")
        characters = self._load_all("characters")
        factions = self._load_all("factions")
        locations = self._load_all("locations")
        plot = self._load_first("plot")
        materials = self._load_all("materials")

        print(f"  ▶ 生成第 {chapter_number} 章《{cd.ChapterTitle}》...")
        result = self.writer.write_chapter(
            cd, bps, volume, outline, world, characters, factions, locations,
            plot, materials, genre, creative_spec, word_count, verbose)
        return result

    def _try_archive_previous_volume(self, current_volume: dict):
        """对标 AutoArchiveVolumeIfNeededAsync: 新卷第1章时自动存档前卷"""
        if not current_volume:
            return
        current_vn = current_volume.get("VolumeNumber", 0)
        if current_vn <= 1:
            return
        prev_vn = current_vn - 1
        try:
            from .volume_archive import VolumeArchiver
            archiver = VolumeArchiver(self.project)
            archiver.archive_volume(prev_vn)
        except Exception:
            pass

    def generate_all_chapters(self, genre: str, start: int = 1, end: int = None,
                              creative_spec: str = "", word_count: int = 3500,
                              verbose: bool = True) -> List[dict]:
        plans = self.project.load_plan("chapters")
        chapters = plans.get("chapters", []) if isinstance(plans, dict) else plans
        chapters = sorted(chapters, key=lambda c: c.get("ChapterNumber", 0))
        if end is None:
            end = len(chapters)
        results = []
        for c in chapters:
            num = c.get("ChapterNumber", 0)
            if num < start or num > end:
                continue
            try:
                r = self.generate_chapter(genre, num, creative_spec, word_count, verbose)
                results.append(r)
            except Exception as e:
                print(f"  ✗ 第 {num} 章失败: {e}")
                continue
        return results

    def _find_chapter(self, chapter_number: int) -> Optional[dict]:
        plans = self.project.load_plan("chapters")
        chapters = plans.get("chapters", []) if isinstance(plans, dict) else plans
        for c in chapters:
            if c.get("ChapterNumber") == chapter_number:
                return c
        return None

    def _load_blueprints(self, chapter_id: str) -> List[dict]:
        data = self.project.load_plan(f"blueprints_{chapter_id}")
        return data if isinstance(data, list) else []
