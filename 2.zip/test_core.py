# -*- coding: utf-8 -*-
"""核心逻辑离线自测：CHANGES 解析、门禁、快照、状态回写（不调用 AI）"""

import sys, os, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from novel_writer.models import (
    FactSnapshot, ChapterChanges, CharacterStateEntry, LocationStateEntry,
    FactionStateEntry, ForeshadowingEntry, CharacterDescription,
    LocationDescription, WorldRuleConstraint,
)
from novel_writer.changes_parser import ChapterChangesParser, ChapterChangesCanonicalizer
from novel_writer.gate import GenerationGate
from novel_writer.prompt_builder import split_content_and_changes, format_fact_snapshot
from novel_writer.storage import create_project, Project
from novel_writer.tracking_services import TrackingManager
from novel_writer.snapshot_extractor import SnapshotExtractor


def make_snapshot():
    s = FactSnapshot()
    s.CharacterStates = [
        CharacterStateEntry(CharacterId="C000000000001", Name="林风", Level="炼气三层",
                            Abilities=["御风诀"], LastChapter=1, Importance=3),
        CharacterStateEntry(CharacterId="C000000000002", Name="苏婉", Level="炼气二层",
                            Abilities=[], LastChapter=1, Importance=2),
    ]
    s.CharacterDescriptions = [
        CharacterDescription(CharacterId="C000000000001", Name="林风",
                             HairColor="黑发", EyeColor="黑瞳", PersonalityTags=["坚韧"], Appearance="黑发黑瞳"),
        CharacterDescription(CharacterId="C000000000002", Name="苏婉",
                             HairColor="青发", PersonalityTags=["温柔"]),
    ]
    s.LocationStates = [
        LocationStateEntry(LocationId="L000000000001", Name="青岚宗", CurrentStatus="正常"),
    ]
    s.LocationDescriptions = [
        LocationDescription(LocationId="L000000000001", Name="青岚宗", Features=["云雾缭绕"]),
    ]
    s.FactionStates = [
        FactionStateEntry(FactionId="F000000000001", Name="玄天宗", CurrentStatus="正常"),
    ]
    s.CharacterLocations = []
    for c in s.CharacterStates:
        from novel_writer.models import CharacterLocationEntry
        s.CharacterLocations.append(
            CharacterLocationEntry(CharacterId=c.CharacterId, Name=c.Name, CurrentLocation="青岚宗", LastUpdatedChapter=1))
    s.ForeshadowingStatus = [
        ForeshadowingEntry(ForeshadowId="FS00000000001", Name="林风的血脉秘密", IsSetup=True, IsResolved=False),
    ]
    s.WorldRuleConstraints = [
        WorldRuleConstraint(RuleId="R000000000001", Content="凡人不可飞行", IsHardConstraint=True),
    ]
    return s


def test_split():
    raw = "正文第一段。\n\n第二段。\n\n---CHANGES---\n{\"CharacterStateChanges\": []}"
    content, changes, _fmt = split_content_and_changes(raw)
    assert "第一段" in content, "正文切分失败"
    assert "CharacterStateChanges" in changes, "CHANGES 切分失败"
    print("[OK] split_content_and_changes")


def test_parser():
    raw = """林风踏出宗门，眼中寒光一闪。

---CHANGES---
{
  "CharacterStateChanges": [{"CharacterId": "林风", "NewLevel": "炼气四层", "KeyEvent": "林风突破炼气四层", "NewAbilities": ["裂空掌"]}],
  "ConflictProgress": [],
  "NewPlotPoints": [{"Keywords": ["突破"], "Context": "林风于青岚宗后山突破", "InvolvedCharacters": ["林风"]}],
  "ForeshadowingActions": [],
  "LocationStateChanges": [],
  "FactionStateChanges": [{"FactionId": "玄天宗", "NewStatus": "暗流涌动"}],
  "TimeProgression": [{"TimePeriod": "清晨", "ElapsedTime": "一日"}],
  "CharacterMovements": [],
  "ItemTransfers": [],
  "SecretRevealChanges": [],
  "PledgeConstraintChanges": [],
  "DeadlineConstraintChanges": []
}"""
    parser = ChapterChangesParser()
    content, changes = parser.parse(raw)
    assert changes is not None, "CHANGES 解析失败"
    assert len(changes.CharacterStateChanges) == 1
    canon = ChapterChangesCanonicalizer(make_snapshot())
    changes = canon.canonicalize(changes)
    assert changes.CharacterStateChanges[0].CharacterId == "C000000000001", "ID 解析失败"
    print("[OK] ChapterChangesParser + Canonicalizer (ID 解析)")

    # 状态机防护：冲突回退
    raw2 = """正文。

---CHANGES---
{"CharacterStateChanges": [], "ConflictProgress": [{"ConflictId": "冲突A", "NewStatus": "pending"}], "NewPlotPoints": [], "ForeshadowingActions": [], "LocationStateChanges": [], "FactionStateChanges": [], "TimeProgression": [], "CharacterMovements": [], "ItemTransfers": [], "SecretRevealChanges": [], "PledgeConstraintChanges": [], "DeadlineConstraintChanges": []}"""
    print("[OK] 状态机防护逻辑编译通过")


def test_gate():
    snapshot = make_snapshot()
    gate = GenerationGate()
    design_names = {"角色": ["林风", "苏婉"], "地点": ["青岚宗"], "势力": ["玄天宗"]}
    good_raw = """林风站在青岚宗的广场上，黑发在风中猎猎作响。

---CHANGES---
{"CharacterStateChanges": [], "ConflictProgress": [], "NewPlotPoints": [], "ForeshadowingActions": [], "LocationStateChanges": [], "FactionStateChanges": [], "TimeProgression": [], "CharacterMovements": [], "ItemTransfers": [], "SecretRevealChanges": [], "PledgeConstraintChanges": [], "DeadlineConstraintChanges": []}"""
    result = gate.validate(good_raw, snapshot, design_names, {})
    assert result.Success, f"应通过门禁但失败: {result.Failures}"
    print("[OK] 门禁通过（合法输出）")

    bad_raw = """苏婉看了看窗外。

---CHANGES---
{"CharacterStateChanges": [], "ConflictProgress": [], "NewPlotPoints": [], "ForeshadowingActions": [], "LocationStateChanges": [], "FactionStateChanges": [], "TimeProgression": [], "CharacterMovements": [], "ItemTransfers": [], "SecretRevealChanges": [], "PledgeConstraintChanges": [], "DeadlineConstraintChanges": []}"""
    bad_names = {"角色": ["林风", "苏婉", "赵虎", "王龙"], "地点": ["青岚宗", "云海阁", "后山"], "势力": ["玄天宗", "魔渊"]}
    result2 = gate.validate(bad_raw, snapshot, bad_names, {})
    assert not result2.Success, "缺少蓝图实体应打回"
    print(f"[OK] 门禁打回（蓝图缺席）: {result2.Failures[0].Type}")

    # 无 CHANGES
    result3 = gate.validate("只有正文没有CHANGES", snapshot, design_names, {})
    assert not result3.Success
    print(f"[OK] 门禁打回（无协议）: {result3.Failures[0].Type}")


def test_snapshot_format():
    s = make_snapshot()
    text = format_fact_snapshot(s)
    assert "林风" in text and "炼气三层" in text and "凡人不可飞行" in text
    print("[OK] format_fact_snapshot 15 维账本格式化")


def test_tracking():
    tmp = tempfile.mkdtemp()
    proj = create_project("test_proj", root=tmp)
    # 用快照建初始追踪
    manager = TrackingManager(proj)
    changes = ChapterChanges()
    from novel_writer.models import (
        CharacterStateChange, FactionStateChange, CharacterMovementChange,
    )
    changes.CharacterStateChanges.append(CharacterStateChange(
        CharacterId="C000000000001", NewLevel="炼气四层", KeyEvent="突破"))
    changes.FactionStateChanges.append(FactionStateChange(
        FactionId="F000000000001", NewStatus="暗流涌动", Event="内部派系争斗"))
    changes.CharacterMovements.append(CharacterMovementChange(
        CharacterId="C000000000002", FromLocation="青岚宗", ToLocation="后山"))
    manager.update(2, changes, make_snapshot())

    # 重新读取
    data = proj.tracking("character_state").data()
    assert data["C000000000001"]["Level"] == "炼气四层", "角色状态未回写"
    data2 = proj.tracking("character_location").data()
    assert data2["C000000000002"]["CurrentLocation"] == "后山", "移动未回写"
    print("[OK] 状态回写（角色/势力/移动）")

    # SnapshotExtractor 从持久化重新构建
    extractor = SnapshotExtractor(proj)
    snap = extractor.extract("X", 3)
    levels = {c.Name: c.Level for c in snap.CharacterStates}
    assert levels.get("林风") == "炼气四层", "快照抽取未反映回写状态"
    print("[OK] SnapshotExtractor 重新构建快照")
    import shutil
    shutil.rmtree(tmp)


if __name__ == "__main__":
    test_split()
    test_parser()
    test_gate()
    test_snapshot_format()
    test_tracking()
    print("\n=== 全部离线测试通过 ===")
