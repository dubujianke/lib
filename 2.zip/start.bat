# 一键启动
# 终端1: 启动 Python 后端
start "API Server" cmd /c "cd /d D:\stock\novel\novel_to_script && python -m novel_writer.server"
# 终端2: 启动 Vue 前端
start "Vue Web" cmd /c "cd /d D:\study\cartoon\novelweb && npm run dev"
