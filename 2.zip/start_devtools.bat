@echo off
chcp 65001 >nul
rem ============================================
rem DevTools viewer 启动器
rem
rem 用法:
rem   start_devtools.bat python   → 看 Python 日志 (4983)
rem   start_devtools.bat toonflow → 看 Toonflow 日志 (4984)
rem   start_devtools.bat both     → 两个都启动
rem ============================================

if "%~1"=="python" goto :python
if "%~1"=="toonflow" goto :toonflow
if "%~1"=="both" goto :both

:usage
echo 用法: start_devtools.bat [python^|toonflow^|both]
exit /b

:python
start "DevTools-Python" cmd /k "cd /d D:\stock\novel\novel_to_script && set AI_SDK_DEVTOOLS_PORT=4983 && node D:\study\cartoon\Toonflow-app-master\node_modules\@ai-sdk\devtools\bin\cli.js"
echo Python 日志: http://localhost:4983
exit /b

:toonflow
start "DevTools-Toonflow" cmd /k "cd /d D:\study\cartoon\Toonflow-app-master && set AI_SDK_DEVTOOLS_PORT=4984 && node D:\study\cartoon\Toonflow-app-master\node_modules\@ai-sdk\devtools\bin\cli.js"
echo Toonflow 日志: http://localhost:4984  (目录: D:\study\cartoon\Toonflow-app-master\.devtools)
exit /b

:both
call :python
call :toonflow
echo.
echo Python:   http://localhost:4983
echo Toonflow: http://localhost:4984
exit /b
