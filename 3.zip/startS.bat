start "API Server" cmd /c "cd /d D:\stock\novel\novel_to_script && python -m novel_writer.server"
