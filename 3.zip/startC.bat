
# 终端2: 启动 Vue 前端
start "Vue Web" cmd /c "cd /d D:\study\cartoon\novelweb && npm run dev"
