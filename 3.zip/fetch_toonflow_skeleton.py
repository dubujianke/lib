# -*- coding: utf-8 -*-
"""调用 Toonflow 接口获取骨架数据"""
import httpx
import json

BASE = "http://localhost:10588"
USERNAME = "admin"
PASSWORD = "admin123"
PROJECT_ID = 1785660085629


def login():
    r = httpx.post(f"{BASE}/api/login/login", json={"username": USERNAME, "password": PASSWORD}, timeout=10)
    return r.json()["data"]["token"]


def get_plan_data(token):
    headers = {"Authorization": token, "Content-Type": "application/json"}
    r = httpx.post(
        f"{BASE}/api/scriptAgent/getPlanData",
        json={"projectId": PROJECT_ID, "agentType": "scriptAgent"},
        headers=headers,
        timeout=30,
    )
    return r.json()


def main():
    token = login()
    print("[获取] 登录成功")
    resp = get_plan_data(token)
    data = resp.get("data", {}).get("data", {})
    skeleton = data.get("storySkeleton", "")
    adaptation = data.get("adaptationStrategy", "")
    scripts = data.get("script", [])
    print(f"[获取] storySkeleton: {len(skeleton)} 字")
    print(f"[获取] adaptationStrategy: {len(adaptation)} 字")
    print(f"[获取] script: {len(scripts)} 个")

    # 保存到本地
    out = {
        "storySkeleton": skeleton,
        "adaptationStrategy": adaptation,
        "script": scripts,
    }
    with open(r"D:\stock\novel\novel_to_script\books_data\plot_extraction\1\toonflow_plan_data.json", "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print("[保存] toonflow_plan_data.json")

    # 打印骨架前 1000 字
    print("\n=== storySkeleton 前1000字 ===")
    print(skeleton[:1000])


if __name__ == "__main__":
    main()
