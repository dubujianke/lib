declare module 'three/examples/jsm/controls/OrbitControls' {
  import { EventDispatcher, PerspectiveCamera, MOUSE, TOUCH, Vector3 } from 'three'

  export class OrbitControls extends EventDispatcher {
    constructor(object: PerspectiveCamera, domElement?: HTMLElement)
    object: PerspectiveCamera
    domElement: HTMLElement | undefined
    enabled: boolean
    target: Vector3
    minDistance: number
    maxDistance: number
    minZoom: number
    maxZoom: number
    maxPolarAngle: number
    enableDamping: boolean
    dampingFactor: number
    update(): void
    dispose(): void
    addEventListener(type: string, listener: (event: Event) => void): void
    removeEventListener(type: string, listener: (event: Event) => void): void
    mouseButtons: { LEFT: MOUSE; MIDDLE: MOUSE; RIGHT: MOUSE }
    touches: { ONE: TOUCH; TWO: TOUCH }
  }
}
