import * as THREE from 'three'
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader'

export function useModelLoader(scene, url) {
    const loader = new GLTFLoader()
    loader.load(url, (gltf) => {
      if (url) {
        scene.remove(url)
      }
      const model = gltf.scene
      scene.add(model)
      model.updateMatrixWorld(true)

      // 居中、贴地、缩放
      const box = new THREE.Box3().setFromObject(model)
      const center = new THREE.Vector3()
      const size = new THREE.Vector3()
      box.getCenter(center)
      box.getSize(size)

      model.position.sub(center)
      model.position.y -= box.min.y - center.y

      const maxAxis = Math.max(size.x, size.y, size.z)
      const scale = 2 / maxAxis
      model.scale.setScalar(scale)

    })
  }
