﻿<template>
  <div class="layout">

    <div class="list">

      <div
        class="card"
        v-for="item in list"
        :key="item.id"
        @click="handleCardClick(item)"
      >
        <img :src="item.previewUrl" @error="onImgError" />

        <div class="title">{{ item.title }}</div>
        <div class="sub">{{ item.keywordEn }}</div>
      </div>
    </div>

  </div>
</template>

<script setup>
import { ref, onMounted } from "vue"
import axios from "axios"

import * as THREE from "three"
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls"
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader"
import { OBB } from "three/examples/jsm/math/OBB.js"

const list = ref([])
const threeBox = ref(null)

let scene, camera, renderer, controls
let currentModel = null
let boxHelper = null

// ----------------------
const onImgError = (e) => {
  e.target.src =
    "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgZmlsbD0iIzMzMyI+PHRleHQgeD0iNTAiIHk9IjUwIiBmaWxsPSIjOTk5Ij5OTyBJTUFHRTwvdGV4dD48L3N2Zz4="
}

// ----------------------
const initThree = () => {

  scene = new THREE.Scene()
  scene.background = new THREE.Color(0x1e1e1e)

  camera = new THREE.PerspectiveCamera(
    60,
    (window.innerWidth - 420) / window.innerHeight,
    0.1,
    1000
  )

  camera.position.set(3, 3, 3)
  camera.lookAt(0, 0, 0)

  renderer = new THREE.WebGLRenderer({ antialias: true })
  renderer.setSize(window.innerWidth - 420, window.innerHeight)

  

  controls = new OrbitControls(camera, renderer.domElement)
  controls.enableDamping = true

  scene.add(new THREE.HemisphereLight(0xffffff, 0x444444, 1.2))

  const dir = new THREE.DirectionalLight(0xffffff, 1)
  dir.position.set(5, 10, 7)
  scene.add(dir)

  const plane = new THREE.Mesh(
    new THREE.PlaneGeometry(50, 50),
    new THREE.MeshStandardMaterial({ color: 0x1a1a1a })
  )
  plane.rotation.x = -Math.PI / 2
  scene.add(plane)

  scene.add(new THREE.GridHelper(50, 50, 0x444444, 0x222222))

  animate()
}

// ----------------------
const animate = () => {
  requestAnimationFrame(animate)
  controls.update()
  renderer.render(scene, camera)
}

const drawOBBBox = (model) => {

  const box = new THREE.Box3().setFromObject(model)

  const size = new THREE.Vector3()
  const center = new THREE.Vector3()

  box.getSize(size)
  box.getCenter(center)

  // =========================
  // 1. 创建盒子
  // =========================
  const geo = new THREE.BoxGeometry(size.x, size.y, size.z)

  const mat = new THREE.MeshBasicMaterial({
    color: 0x00ff00,
    wireframe: true
  })

  const mesh = new THREE.Mesh(geo, mat)

  // =========================
  // 2. 放到中心
  // =========================
  mesh.position.copy(center)

  // =========================
  // 3. 应用模型旋转（关键）
  // =========================
  model.updateMatrixWorld(true)

  const m = model.matrixWorld.clone()

  // 提取旋转+缩放
  const pos = new THREE.Vector3()
  const quat = new THREE.Quaternion()
  const scale = new THREE.Vector3()

  m.decompose(pos, quat, scale)

  mesh.quaternion.copy(quat)

  return mesh
}

// ----------------------
// GLB + OBB正确版本
// ----------------------
const loadGLB = (url) => {

  const loader = new GLTFLoader()

  loader.load(url, (gltf) => {

    if (currentModel) {
      scene.remove(currentModel)
      scene.remove(boxHelper)
    }


    currentModel = gltf.scene
    scene.add(currentModel)
    currentModel.updateMatrixWorld(true)

    boxHelper = drawOBBBox(currentModel)
    scene.add(boxHelper)
    
    // ======================
    // AABB
    // ======================
    const box = new THREE.Box3().setFromObject(currentModel)

    const center = new THREE.Vector3()
    const size = new THREE.Vector3()

    box.getCenter(center)
    box.getSize(size)

    // ======================
    // 居中
    // ======================
    currentModel.position.sub(center)

    // ======================
    // 贴地
    // ======================
    currentModel.position.y -= box.min.y - center.y

    // ======================
    // 缩放
    // ======================
    const maxAxis = Math.max(size.x, size.y, size.z)
    const scale = 2 / maxAxis
    currentModel.scale.setScalar(scale)

    // ======================
    // OBB（正确方式）
    // ======================
    currentModel.updateMatrixWorld(true)

    const obb = new OBB()

    const box2 = new THREE.Box3().setFromObject(currentModel)

    const c2 = new THREE.Vector3()
    const s2 = new THREE.Vector3()

    box2.getCenter(c2)
    box2.getSize(s2)

    obb.center.copy(c2)
    obb.halfSize.copy(s2.multiplyScalar(0.5))
    obb.rotation.copy(currentModel.matrixWorld)

    // ======================
    // 画盒子
    // ======================
    const helper = new THREE.Mesh(
      new THREE.BoxGeometry(s2.x, s2.y, s2.z),
      new THREE.MeshBasicMaterial({
        color: 0x00ff00,
        wireframe: true
      })
    )

    helper.position.copy(c2)
    helper.quaternion.copy(obb.rotation)

    boxHelper = helper
    scene.add(helper)

  })
}

// ----------------------
const loadModel = (item) => {
  loadGLB(item.glbUrl)
}

// ----------------------
const fetchData = async () => {
  const res = await axios.get(
    "http://localhost:3840/api/model/search",
    {
      params: { name: "sofa" }
    }
  )

  list.value = res.data
}

// ----------------------
onMounted(() => {
  //initThree()
  fetchData()
})

const props = defineProps({
  mode: {
    type: String,
    default: 'viewer'   // 'viewer' 或 'selector'
  }
})
const emit = defineEmits(['select', 'close'])

// 点击卡片
const handleCardClick = (item) => {
  if (props.mode === 'selector') {
    emit('select', item)   // 传回完整数据
    emit('close')          // 通知父组件关闭
  } else {
    loadGLB(item.glbUrl)   // 保留你的 3D 查看逻辑（如果需要）
  }
}

</script>

<style scoped>

.layout {
  display: flex;
}

/* =========================
   左侧资产库（彻底修复版）
========================= */



/* 文本 */
.title {
  color: #fff;
  font-size: 13px;
  padding: 6px;
  font-weight: bold;
}

.sub {
  color: #aaa;
  font-size: 11px;
  padding: 0 6px 8px;
}

/* =========================
   右侧3D
========================= */
.viewer {
  flex: 1;
  height: 100vh;
  overflow: hidden;
}

.card {
  height: 100%;
  background: #1a1a1a;
  border-radius: 8px;
  overflow: hidden;
  border: 1px solid #222;

  display: flex;
  flex-direction: column;
}
.layout {
  display: flex;
  margin: 0;
  padding: 0;
}
.list {
  width: 100%;
  height: 100vh;
  overflow-y: auto;
  background: #111;
  padding: 10px;

  display: grid;
  grid-template-columns: repeat(6, 1fr);
  gap: 10px;

  /* ⭐关键：锁定行高 */
  grid-auto-rows: 180px;
}
html, body {
  margin: 0;
  padding: 0;
}
</style>