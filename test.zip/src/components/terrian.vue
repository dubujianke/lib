﻿<template>
  <div ref="container" class="terrain-container"></div>
</template>

<script setup lang="ts">
import { onBeforeUnmount, onMounted, ref } from 'vue'
import * as THREE from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls'

const container = ref<HTMLElement | null>(null)
let renderer: THREE.WebGLRenderer | null = null
let scene: THREE.Scene | null = null
let camera: THREE.PerspectiveCamera | null = null
let controls: OrbitControls | null = null
let animationId = 0

const terrainParams = {
  width: 500,
  depth: 500,
  maxHeight: 100,
}

// 四宫格图片路径
const QUAD_IMAGE_URL = './terrain_quad.png'

// ==================== 加载图片 ====================
async function loadImage(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.onload = () => resolve(img)
    img.onerror = reject
    img.src = url
  })
}

// 从四宫格图片中裁剪指定区域
function cropQuad(
  img: HTMLImageElement,
  col: number, // 0=左列, 1=右列
  row: number  // 0=上行, 1=下行
): ImageData {
  const halfW = Math.floor(img.width / 2)
  const halfH = Math.floor(img.height / 2)

  const canvas = document.createElement('canvas')
  canvas.width = halfW
  canvas.height = halfH
  const ctx = canvas.getContext('2d')!

  // 从大图指定位置裁剪
  ctx.drawImage(
    img,
    col * halfW, row * halfH, halfW, halfH,  // 源区域
    0, 0, halfW, halfH                        // 目标区域
  )

  return ctx.getImageData(0, 0, halfW, halfH)
}

// ==================== 地形颜色映射（兜底） ====================
function heightToColor(h: number): [number, number, number] {
  // 0 → 深绿，1 → 白色雪顶
  const stops: [number, number, number, number][] = [
    [0.0, 0.10, 0.30, 0.10],  // 深绿
    [0.15, 0.18, 0.42, 0.18], // 绿
    [0.30, 0.35, 0.55, 0.25], // 草绿
    [0.50, 0.55, 0.40, 0.20], // 棕褐
    [0.70, 0.62, 0.62, 0.62], // 灰
    [0.85, 0.85, 0.85, 0.85], // 浅灰
    [1.00, 1.00, 1.00, 1.00], // 白
  ]

  for (let i = 0; i < stops.length - 1; i++) {
    const [h0, r0, g0, b0] = stops[i]
    const [h1, r1, g1, b1] = stops[i + 1]
    if (h <= h1) {
      const t = (h - h0) / (h1 - h0)
      return [r0 + (r1 - r0) * t, g0 + (g1 - g0) * t, b0 + (b1 - b0) * t]
    }
  }
  return [1, 1, 1]
}

// ==================== 创建地形几何体 ====================
function createTerrainGeometry(heightData: ImageData, colorData: ImageData): THREE.BufferGeometry {
  const imgW = heightData.width
  const imgH = heightData.height
  const hPixels = heightData.data
  const cPixels = colorData.data

  // 确保两张图分辨率一致
  const segW = imgW - 1
  const segH = imgH - 1

  const geometry = new THREE.PlaneGeometry(
    terrainParams.width,
    terrainParams.depth,
    segW,
    segH
  )

  const positions = geometry.attributes.position.array as Float32Array
  const colors: number[] = []

  for (let i = 0; i < positions.length; i += 3) {
    const x = positions[i]
    const y = positions[i + 1]

    // 映射顶点坐标到像素坐标
    const px = Math.round(((x / terrainParams.width) + 0.5) * segW)
    const py = Math.round(((y / terrainParams.depth) + 0.5) * segH)

    const cx = Math.max(0, Math.min(px, segW))
    const cy = Math.max(0, Math.min(py, segH))

    // 注意：图像坐标 Y 轴是反的（顶部是 row=0）
    const pixelIdx = (cy * imgW + cx) * 4

    // 高度：R 通道
    const h = hPixels[pixelIdx] / 255.0
    positions[i + 2] = h * terrainParams.maxHeight

    // 颜色：优先颜色图，如果全黑则用高度着色
    const cr = cPixels[pixelIdx] / 255.0
    const cg = cPixels[pixelIdx + 1] / 255.0
    const cb = cPixels[pixelIdx + 2] / 255.0

    if (cr + cg + cb < 0.01) {
      // 颜色图为黑色 → 用高度自动着色
      const [r, g, b] = heightToColor(h)
      colors.push(r, g, b)
    } else {
      colors.push(cr, cg, cb)
    }
  }

  geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3))
  geometry.computeVertexNormals()
  geometry.attributes.position.needsUpdate = true

  return geometry
}

// ==================== 初始化场景 ====================
function initScene() {
  if (!container.value) return

  scene = new THREE.Scene()
  scene.background = new THREE.Color(0x1a1a2e)
  scene.fog = new THREE.Fog(0x1a1a2e, 200, 1000)

  camera = new THREE.PerspectiveCamera(
    50,
    container.value.clientWidth / container.value.clientHeight,
    1,
    2000
  )
  camera.position.set(300, 250, 350)
  camera.lookAt(0, 20, 0)

  renderer = new THREE.WebGLRenderer({ antialias: true })
  renderer.setSize(container.value.clientWidth, container.value.clientHeight)
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
  renderer.shadowMap.enabled = true
  renderer.shadowMap.type = THREE.PCFSoftShadowMap
  renderer.toneMapping = THREE.ACESFilmicToneMapping
  renderer.toneMappingExposure = 1.1
  container.value.appendChild(renderer.domElement)

  controls = new OrbitControls(camera, renderer.domElement)
  controls.enableDamping = true
  controls.dampingFactor = 0.08
  controls.target.set(0, 25, 0)
  controls.minDistance = 30
  controls.maxDistance = 600
  controls.maxPolarAngle = Math.PI / 2.15
  controls.update()

  // 光照
  scene.add(new THREE.AmbientLight(0x404060, 0.5))
  scene.add(new THREE.HemisphereLight(0x87ceeb, 0x362907, 0.4))

  const sun = new THREE.DirectionalLight(0xfff5e6, 3.5)
  sun.position.set(200, 300, 100)
  sun.castShadow = true
  sun.shadow.mapSize.width = 2048
  sun.shadow.mapSize.height = 2048
  sun.shadow.camera.near = 0.5
  sun.shadow.camera.far = 1200
  sun.shadow.camera.left = -300
  sun.shadow.camera.right = 300
  sun.shadow.camera.top = 300
  sun.shadow.camera.bottom = -300
  sun.shadow.bias = -0.0004
  scene.add(sun)

  scene.add(new THREE.DirectionalLight(0x4488cc, 0.5))

  // 基础平面
  const baseGeo = new THREE.PlaneGeometry(600, 600)
  const baseMat = new THREE.MeshStandardMaterial({ color: 0x222222, roughness: 0.9 })
  const base = new THREE.Mesh(baseGeo, baseMat)
  base.rotation.x = -Math.PI / 2
  base.position.y = -2
  base.receiveShadow = true
  scene.add(base)
}

// ==================== 加载并生成地形 ====================
async function buildTerrain() {
  if (!scene) return

  try {
    const img = await loadImage(QUAD_IMAGE_URL)

    console.log(`📐 四宫格原图: ${img.width} × ${img.height}`)

    // 左上角: col=0, row=0 → 高度图
    const heightData = cropQuad(img, 0, 0)
    // 左下角: col=0, row=1 → 颜色图
    const colorData = cropQuad(img, 0, 1)

    console.log(`🗻 高度图: ${heightData.width} × ${heightData.height}`)
    console.log(`🎨 颜色图: ${colorData.width} × ${colorData.height}`)

    // 检查颜色图是否有效（非全黑）
    let coloredPixels = 0
    const cPix = colorData.data
    for (let i = 0; i < cPix.length; i += 4) {
      if (cPix[i] + cPix[i + 1] + cPix[i + 2] > 5) coloredPixels++
    }
    console.log(
      `🟢 颜色图有效像素: ${coloredPixels} / ${colorData.width * colorData.height}` +
      (coloredPixels === 0 ? ' → 将使用高度自动着色' : '')
    )

    const geometry = createTerrainGeometry(heightData, colorData)

    const material = new THREE.MeshStandardMaterial({
      vertexColors: true,
      roughness: 0.7,
      metalness: 0.05,
    })

    const terrain = new THREE.Mesh(geometry, material)
    terrain.rotation.x = -Math.PI / 2
    terrain.castShadow = true
    terrain.receiveShadow = true
    terrain.name = 'terrain'
    scene.add(terrain)

    console.log('✅ 地形生成完成')
  } catch (error) {
    console.error('❌ 加载失败:', error)
  }
}

// ==================== 动画循环 ====================
function animate() {
  animationId = requestAnimationFrame(animate)
  controls?.update()
  if (renderer && scene && camera) {
    renderer.render(scene, camera)
  }
}

function onResize() {
  if (!container.value || !renderer || !camera) return
  camera.aspect = container.value.clientWidth / container.value.clientHeight
  camera.updateProjectionMatrix()
  renderer.setSize(container.value.clientWidth, container.value.clientHeight)
}

// ==================== 生命周期 ====================
onMounted(async () => {
  initScene()
  await buildTerrain()
  animate()
  window.addEventListener('resize', onResize)
})

onBeforeUnmount(() => {
  cancelAnimationFrame(animationId)
  window.removeEventListener('resize', onResize)
  renderer?.dispose()
  renderer?.domElement.remove()
  controls?.dispose()
  scene?.traverse((obj) => {
    if (obj instanceof THREE.Mesh) {
      obj.geometry?.dispose()
      const mat = obj.material
      if (Array.isArray(mat)) mat.forEach((m) => m.dispose())
      else mat?.dispose()
    }
  })
})
</script>

<style scoped>
.terrain-container {
  width: 100%;
  height: 100vh;
  overflow: hidden;
}
</style>