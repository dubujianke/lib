﻿<template>
  <div class="scene-root">
    <!-- 左侧面板容器 -->
    <div class="panels-wrapper">
      <!-- 左侧第一列：组件列表面板 -->
      <aside class="component-panel left-panel">
        <div class="panel-title">Components</div>
        <div class="panel-count">
          Total: {{ filteredComponentList.length }} / {{ componentList.length }}
          <span v-if="selectedComponentNames.length > 0" class="selected-count">
            | Selected: {{ selectedComponentNames.length }}
          </span>
        </div>
        <div class="filter-box">
          <input
            v-model="filterText"
            type="text"
            class="filter-input"
            placeholder="Filter components..."
            @keyup.escape="clearFilter"
          />
          <button v-if="filterText" class="filter-clear" @click="clearFilter">✕</button>
        </div>
        <div class="rebuild-section">
          <button 
            class="rebuild-btn" 
            @click="rebuildScene"
            :disabled="isLoading"
          >
            <span v-if="isLoading">⏳ Rebuilding...</span>
            <span v-else>🔄 Rebuild from Export Data</span>
          </button>
        </div>
        <div v-if="selectedComponentNames.length > 0" class="action-buttons">
          <button class="delete-selection-btn" @click="deleteSelected">🗑 Delete Selected</button>
          <button class="clear-selection-btn" @click="clearSelection">✕ Clear Selection</button>
          <button class="export-btn" @click="exportJSON">📥 Export JSON</button>
          <div v-if="exportMessage" class="export-msg">{{ exportMessage }}</div>
        </div>
        <div class="component-flow">
          <div
            v-for="item in filteredComponentList"
            :key="item.name"
            class="component-chip"
            :class="{ selected: selectedComponentNames.includes(item.name), deleted: deletedComponentNames.has(item.name) }"
            @click="toggleComponentSelection(item.name, $event)"
          >
            <span class="chip-name">{{ item.name }}</span>
            <span class="chip-type">{{ item.type }}</span>
            <span v-if="item.parent" class="chip-parent">parent: {{ item.parent }}</span>
          </div>
        </div>
      </aside>

      <!-- 左侧第二列：变换控制面板 -->
      <aside class="component-panel transform-panel" v-if="selectedComponentNames.length > 0">
        <div class="panel-title">Transform</div>
        <div class="transform-section">
          <div class="transform-group">
            <div class="transform-group-title">Position</div>
            <div class="transform-title-info">
              <span v-if="selectedComponentNames.length === 1">
                {{ selectedComponentNames[0] }}
              </span>
              <span v-else>
                {{ selectedComponentNames.length }} components selected
              </span>
            </div>
            <div class="transform-row">
              <span class="axis-label axis-x">X</span>
              <button class="dir-btn" @click="moveSelected('-x')">-</button>
              <button class="dir-btn" @click="moveSelected('+x')">+</button>
            </div>
            <div class="transform-row">
              <span class="axis-label axis-y">Y</span>
              <button class="dir-btn" @click="moveSelected('-y')">-</button>
              <button class="dir-btn" @click="moveSelected('+y')">+</button>
            </div>
            <div class="transform-row">
              <span class="axis-label axis-z">Z</span>
              <button class="dir-btn" @click="moveSelected('-z')">-</button>
              <button class="dir-btn" @click="moveSelected('+z')">+</button>
            </div>
            <div class="transform-step">
              <label>
                Step:
                <select v-model="moveStep" class="step-select">
                  <option :value="0.01">0.01</option>
                  <option :value="0.05">0.05</option>
                  <option :value="0.1">0.1</option>
                  <option :value="0.5">0.5</option>
                  <option :value="1.0">1.0</option>
                </select>
              </label>
            </div>
          </div>

          <div class="transform-divider"></div>

          <div class="transform-group">
            <div class="transform-group-title">Scale</div>
            <div class="transform-scale-display">{{ formatScale(selectedScale) }}</div>
            <div class="transform-row">
              <span class="axis-label axis-x">X</span>
              <button class="dir-btn" @click="scaleSelected('-x')">-</button>
              <button class="dir-btn" @click="scaleSelected('+x')">+</button>
            </div>
            <div class="transform-row">
              <span class="axis-label axis-y">Y</span>
              <button class="dir-btn" @click="scaleSelected('-y')">-</button>
              <button class="dir-btn" @click="scaleSelected('+y')">+</button>
            </div>
            <div class="transform-row">
              <span class="axis-label axis-z">Z</span>
              <button class="dir-btn" @click="scaleSelected('-z')">-</button>
              <button class="dir-btn" @click="scaleSelected('+z')">+</button>
            </div>
            <div class="transform-step">
              <label>
                Step:
                <select v-model="scaleStep" class="step-select">
                  <option :value="0.01">0.01</option>
                  <option :value="0.05">0.05</option>
                  <option :value="0.1">0.1</option>
                  <option :value="0.25">0.25</option>
                  <option :value="0.5">0.5</option>
                </select>
              </label>
            </div>
          </div>
        </div>
      </aside>
    </div>

    <div ref="container" class="canvas-container"></div>
  </div>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import * as THREE from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls'
import { SUBTRACTION, Brush, Evaluator } from 'three-bvh-csg'

const container = ref<HTMLElement | null>(null)
let renderer: THREE.WebGLRenderer | null = null
let scene: THREE.Scene | null = null
let camera: THREE.PerspectiveCamera | null = null
let controls: OrbitControls | null = null
let animationId = 0

// 原始 JSON 缓存（从文件加载后不再修改，用于导出和参考）
let cachedJSON: { objects: any[] } | null = null
// 运行时定义（用于渲染，位置会随移动更新）
const objectDefinitions: Record<string, any> = {}
// 记录被移动过的对象
const movedObjects = new Set<string>()
// 记录被删除的对象名称
const deletedComponentNames = ref(new Set<string>())
const HIDE_WINDOW_MESHES = false
const componentList = ref<Array<{ name: string; type: string; parent?: string }>>([])
const filterText = ref('')
const selectedComponentNames = ref<string[]>([])
const moveStep = ref(0.1)
const scaleStep = ref(0.1)
const selectedScale = ref<[number, number, number]>([1, 1, 1])
const exportMessage = ref('')
const meshByComponentName: Record<string, THREE.Object3D> = {}
const originalSizes: Record<string, [number, number, number] | [number]> = {}
const selectionBoxHelpers: Record<string, THREE.BoxHelper> = {}
const isLoading = ref(false)

// 双击选择相关变量
const raycaster = new THREE.Raycaster()
const mouse = new THREE.Vector2()
let lastClickTime = 0
let lastClickObject: THREE.Object3D | null = null

const filteredComponentList = computed(() => {
  const query = filterText.value.trim().toLowerCase()
  let list = componentList.value
  
  // 过滤掉已删除的组件
  list = list.filter(item => !deletedComponentNames.value.has(item.name))
  
  if (!query) return list
  return list.filter(item => item.name.toLowerCase().includes(query))
})

const clearFilter = () => {
  filterText.value = ''
}

const formatScale = (scale: [number, number, number]) => {
  return `${scale[0].toFixed(2)}, ${scale[1].toFixed(2)}, ${scale[2].toFixed(2)}`
}

let exportTimeout: ReturnType<typeof setTimeout> | null = null

const getMeshWorldPosition = (obj: THREE.Object3D): THREE.Vector3 => {
  const worldPos = new THREE.Vector3()
  obj.getWorldPosition(worldPos)
  return worldPos
}

const getParentWorldPosition = (parentName: string): THREE.Vector3 | null => {
  const parentMesh = meshByComponentName[parentName]
  if (parentMesh) {
    return getMeshWorldPosition(parentMesh)
  }

  const parentDef = objectDefinitions[parentName]
  if (parentDef) {
    const worldMatrix = getWorldMatrix(parentDef)
    const pos = new THREE.Vector3()
    pos.setFromMatrixPosition(worldMatrix)
    return pos
  }

  return null
}

const getWorldMatrix = (obj: any, visited = new Set<string>()): THREE.Matrix4 => {
  const local = getLocalMatrix(obj)
  if (!obj.parent) return local

  const parentName = String(obj.parent)
  if (visited.has(parentName)) {
    return local
  }

  const parentObj = objectDefinitions[parentName]
  if (!parentObj) return local

  visited.add(parentName)
  const parentWorld = getWorldMatrix(parentObj, visited)
  return parentWorld.multiply(local)
}

const getRelativePosition = (def: any): [number, number, number] | null => {
  if (!def.position) return null

  if (!def.parent) {
    return [...def.position]
  }

  const parentDef = objectDefinitions[def.parent]
  if (!parentDef || !parentDef.position) {
    return [...def.position]
  }

  return [
    def.position[0] - parentDef.position[0],
    def.position[1] - parentDef.position[1],
    def.position[2] - parentDef.position[2],
  ]
}

// 获取导出数据（包含所有运行时修改，排除已删除的对象）
const getExportData = () => {
  if (!cachedJSON) {
    return null
  }

  const exportedObjects = cachedJSON.objects
    .filter((cachedObj: any) => {
      // 过滤掉已删除的对象
      return !deletedComponentNames.value.has(cachedObj.name)
    })
    .map((cachedObj: any) => {
      const name = cachedObj.name
      const runtimeDef = name ? objectDefinitions[name] : null

      const exported: any = {}

      // 复制所有原始属性
      for (const key of Object.keys(cachedObj)) {
        exported[key] = cachedObj[key]
      }

      // 覆盖运行时修改过的属性
      if (runtimeDef) {
        // 只对移动过的对象使用叠加
        if (name && movedObjects.has(name) && cachedObj.position) {
          const meshObj = meshByComponentName[name]
          if (meshObj) {
            exported.position = [
              cachedObj.position[0] + meshObj.position.x,
              cachedObj.position[1] + meshObj.position.y,
              cachedObj.position[2] + meshObj.position.z
            ]
          } else {
            // subtract 对象，直接使用运行时定义的位置（相对坐标）
            exported.position = [...runtimeDef.position]
          }
        }
        
        if (runtimeDef.size) {
          exported.size = [...runtimeDef.size]
        }
        if (cachedObj.type === 'cylinder') {
          if (runtimeDef.radius !== undefined) exported.radius = runtimeDef.radius
          if (runtimeDef.height !== undefined) exported.height = runtimeDef.height
        }
      }

      return exported
    })

  return { objects: exportedObjects }
}

const exportJSON = () => {
  const exportData = getExportData()
  
  if (!exportData) {
    exportMessage.value = '❌ No cached JSON'
    if (exportTimeout) clearTimeout(exportTimeout)
    exportTimeout = setTimeout(() => { exportMessage.value = '' }, 3000)
    return
  }

  const jsonStr = JSON.stringify(exportData, null, 2)
  navigator.clipboard.writeText(jsonStr).then(() => {
    exportMessage.value = '✅ Copied to clipboard!'
  }).catch(() => {
    const blob = new Blob([jsonStr], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'bus_modified.json'
    a.click()
    URL.revokeObjectURL(url)
    exportMessage.value = '⬇ Downloaded bus_modified.json'
  })
  if (exportTimeout) clearTimeout(exportTimeout)
  exportTimeout = setTimeout(() => {
    exportMessage.value = ''
  }, 3000)
}

const updateScaleDisplay = () => {
  if (selectedComponentNames.value.length === 0) {
    selectedScale.value = [1, 1, 1]
    return
  }
  const firstSelected = selectedComponentNames.value[0]
  const mesh = meshByComponentName[firstSelected]
  if (mesh) {
    selectedScale.value = [mesh.scale.x, mesh.scale.y, mesh.scale.z]
  }
}

const setMeshHighlighted = (mesh: THREE.Object3D | undefined, highlighted: boolean) => {
  if (!mesh) return
  mesh.traverse(child => {
    if (child instanceof THREE.Mesh) {
      const materials = Array.isArray(child.material) ? child.material : [child.material]
      materials.forEach(material => {
        if (!(material instanceof THREE.MeshStandardMaterial || material instanceof THREE.MeshPhysicalMaterial)) {
          return
        }
        if (highlighted) {
          if (material.userData.__origEmissive === undefined) {
            material.userData.__origEmissive = material.emissive.getHex()
            material.userData.__origEmissiveIntensity = material.emissiveIntensity
          }
          material.emissive.setHex(0x22c55e)
          material.emissiveIntensity = 0.9
        } else if (material.userData.__origEmissive !== undefined) {
          material.emissive.setHex(material.userData.__origEmissive)
          material.emissiveIntensity = material.userData.__origEmissiveIntensity ?? 1
        }
      })
    }
  })
}

const addBoundingBox = (name: string) => {
  if (selectionBoxHelpers[name]) return
  
  const def = objectDefinitions[name]
  if (!def) return
  
  // 从 objectDefinitions 获取当前定义（包含运行时修改）
  const currentDef = objectDefinitions[name]
  if (!currentDef) return
  
  // 创建临时几何体
  let geometry: THREE.BufferGeometry
  
  if (currentDef.type === 'box' || currentDef.shape === 'box' || currentDef.type === 'subtract') {
    const size = currentDef.size || [1, 1, 1]
    geometry = new THREE.BoxGeometry(size[0], size[1], size[2])
  } else if (currentDef.type === 'cylinder' || currentDef.shape === 'cylinder') {
    geometry = new THREE.CylinderGeometry(
      currentDef.radius || 0.5, 
      currentDef.radius || 0.5, 
      currentDef.height || 1, 
      16
    )
  } else {
    return
  }
  
  const tempMesh = new THREE.Mesh(geometry)
  
  // 计算当前位置
  let worldPos = new THREE.Vector3(
    currentDef.position?.[0] || 0,
    currentDef.position?.[1] || 0,
    currentDef.position?.[2] || 0
  )
  
  // 如果是 subtract 对象或子对象，需要加上父对象的位置
  if ((currentDef.type === 'subtract' || currentDef.shape) && currentDef.parent) {
    const parentDef = objectDefinitions[currentDef.parent]
    if (parentDef && parentDef.position) {
      worldPos.x += parentDef.position[0]
      worldPos.y += parentDef.position[1]
      worldPos.z += parentDef.position[2]
    }
  }
  
  // 如果对象有 mesh 且被移动过，加上偏移量
  if (movedObjects.has(name)) {
    const mesh = meshByComponentName[name]
    if (mesh) {
      worldPos.x += mesh.position.x
      worldPos.y += mesh.position.y
      worldPos.z += mesh.position.z
    }
  }
  
  tempMesh.position.copy(worldPos)
  
  // 应用旋转
  if (currentDef.rotation) {
    tempMesh.rotation.set(
      (currentDef.rotation[0] * Math.PI) / 180,
      (currentDef.rotation[1] * Math.PI) / 180,
      (currentDef.rotation[2] * Math.PI) / 180
    )
  }
  
  const boxHelper = new THREE.BoxHelper(tempMesh, 0x22c55e)
  scene?.add(boxHelper)
  selectionBoxHelpers[name] = boxHelper
}

const removeBoundingBox = (name: string) => {
  const boxHelper = selectionBoxHelpers[name]
  if (boxHelper) {
    scene?.remove(boxHelper)
    delete selectionBoxHelpers[name]
  }
}

const clearSelection = () => {
  selectedComponentNames.value.forEach(name => {
    setMeshHighlighted(meshByComponentName[name], false)
    removeBoundingBox(name)
  })
  selectedComponentNames.value = []
  updateScaleDisplay()
}

const toggleComponentSelection = (name: string, event?: MouseEvent) => {
  const isCtrlPressed = event?.ctrlKey || event?.metaKey
  
  if (isCtrlPressed) {
    const index = selectedComponentNames.value.indexOf(name)
    if (index === -1) {
      selectedComponentNames.value.push(name)
      setMeshHighlighted(meshByComponentName[name], true)
      addBoundingBox(name)
    } else {
      selectedComponentNames.value.splice(index, 1)
      setMeshHighlighted(meshByComponentName[name], false)
      removeBoundingBox(name)
    }
    updateScaleDisplay()
  } else {
    selectedComponentNames.value.forEach(selectedName => {
      setMeshHighlighted(meshByComponentName[selectedName], false)
      removeBoundingBox(selectedName)
    })
    
    if (selectedComponentNames.value.length === 1 && selectedComponentNames.value[0] === name) {
      selectedComponentNames.value = []
    } else {
      selectedComponentNames.value = [name]
      setMeshHighlighted(meshByComponentName[name], true)
      addBoundingBox(name)
    }
    updateScaleDisplay()
  }
}

const moveSelected = (direction: string) => {
  if (selectedComponentNames.value.length === 0) return
  
  const step = moveStep.value
  
  selectedComponentNames.value.forEach(name => {
    const mesh = meshByComponentName[name]
    const def = objectDefinitions[name]
    
    if (mesh) {
      // 有 mesh 的对象，直接移动
      switch (direction) {
        case '+x': mesh.position.x += step; break
        case '-x': mesh.position.x -= step; break
        case '+y': mesh.position.y += step; break
        case '-y': mesh.position.y -= step; break
        case '+z': mesh.position.z += step; break
        case '-z': mesh.position.z -= step; break
      }
    } else if (def && (def.type === 'subtract' || def.shape)) {
      // subtract 对象，更新相对父对象的局部坐标
      switch (direction) {
        case '+x': def.position[0] += step; break
        case '-x': def.position[0] -= step; break
        case '+y': def.position[1] += step; break
        case '-y': def.position[1] -= step; break
        case '+z': def.position[2] += step; break
        case '-z': def.position[2] -= step; break
      }
    }
    
    // 标记为已移动
    movedObjects.add(name)
  })
  
  // 更新包围盒
  selectedComponentNames.value.forEach(name => {
    const boxHelper = selectionBoxHelpers[name]
    if (boxHelper) {
      boxHelper.update()
    }
  })
  
  
}

const scaleSelected = (direction: string) => {
  if (selectedComponentNames.value.length === 0) return
  
  const step = scaleStep.value
  const sign = direction.startsWith('+') ? 1 : -1
  const axis = direction.slice(1) as 'x' | 'y' | 'z'
  
  selectedComponentNames.value.forEach(name => {
    const mesh = meshByComponentName[name]
    if (!mesh) return
    
    const newVal = THREE.MathUtils.clamp(mesh.scale[axis] + sign * step, 0.01, 100)
    mesh.scale[axis] = newVal
    
    const def = objectDefinitions[name]
    if (def) {
      if (def.type === 'cylinder' && def.radius !== undefined) {
        const origRadius = originalSizes[name]?.[0] ?? def.radius
        if (axis === 'x' || axis === 'y') {
          def.radius = origRadius * newVal
        }
        if (def.height !== undefined && axis === 'z') {
          const origHeight = (originalSizes[name] as [number])?.[1] ?? def.height
          def.height = origHeight * newVal
        }
      } else if (def.size) {
        const origSize = (originalSizes[name] as [number, number, number]) ?? [...def.size]
        const idx = axis === 'x' ? 0 : axis === 'y' ? 1 : 2
        def.size[idx] = origSize[idx] * newVal
      }
    }
    
    // 更新包围盒
    const boxHelper = selectionBoxHelpers[name]
    if (boxHelper) {
      boxHelper.update()
    }
  })
  
  updateScaleDisplay()
}

// 删除选中的组件
const deleteSelected = () => {
  if (selectedComponentNames.value.length === 0) return
  
  // 收集所有要删除的名称（包括子对象）
  const namesToDelete = new Set<string>()
  
  selectedComponentNames.value.forEach(name => {
    namesToDelete.add(name)
    
    // 如果删除的是父对象，也删除其所有 subtract 子对象
    if (cachedJSON) {
      cachedJSON.objects.forEach((obj: any) => {
        if (obj.type === 'subtract' && obj.parent === name) {
          if (obj.name) {
            namesToDelete.add(obj.name)
          }
        }
      })
    }
  })
  
  // 添加到删除集合
  namesToDelete.forEach(name => {
    deletedComponentNames.value.add(name)
  })
  
  // 清除选择
  clearSelection()
  
  // 重建场景
  rebuildScene()
}

const isGlassObjectName = (name?: string) => {
  if (!name) return false
  return /(side_window|glass|windshield)/i.test(name) && !/^seat_/i.test(name)
}

const keyState: Record<'KeyW' | 'KeyA' | 'KeyS' | 'KeyD' | 'ArrowUp' | 'ArrowDown', boolean> = {
  KeyW: false,
  KeyA: false,
  KeyS: false,
  KeyD: false,
  ArrowUp: false,
  ArrowDown: false,
}

const onKeyDown = (event: KeyboardEvent) => {
  if (event.code in keyState) {
    keyState[event.code as keyof typeof keyState] = true
  }
  
  // 处理 Delete 键
  if (event.code === 'Delete' || event.code === 'Backspace') {
    // 防止在输入框中按删除键时触发
    const target = event.target as HTMLElement
    if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable) {
      return
    }
    
    if (selectedComponentNames.value.length > 0) {
      event.preventDefault()
      deleteSelected()
    }
  }
}

const onKeyUp = (event: KeyboardEvent) => {
  if (event.code in keyState) {
    keyState[event.code as keyof typeof keyState] = false
  }
}

// 双击选择场景中的物体
const onMouseDown = (event: MouseEvent) => {
  if (!container.value || !camera) return
  
  // 计算鼠标位置
  const rect = container.value.getBoundingClientRect()
  mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1
  mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1
  
  // 从相机发射射线
  raycaster.setFromCamera(mouse, camera)
  
  // 获取所有可选择的物体
  const selectableObjects: THREE.Object3D[] = []
  Object.values(meshByComponentName).forEach(obj => {
    selectableObjects.push(obj)
  })
  
  // 检测射线与物体的交点
  const intersects = raycaster.intersectObjects(selectableObjects, true)
  
  if (intersects.length > 0) {
    // 找到被点击的最顶层对象
    let clickedObject: THREE.Object3D | null = null
    
    for (const intersect of intersects) {
      let obj = intersect.object
      // 向上查找有名字的对象
      while (obj) {
        if (obj.name && meshByComponentName[obj.name]) {
          clickedObject = obj
          break
        }
        obj = obj.parent as THREE.Object3D
      }
      if (clickedObject) break
    }
    
    if (clickedObject && clickedObject.name) {
      const currentTime = Date.now()
      
      // 检测是否是双击（两次点击间隔小于300ms且点击同一物体）
      if (currentTime - lastClickTime < 300 && lastClickObject === clickedObject) {
        // 双击事件
        const syntheticEvent = new MouseEvent('dblclick', {
          ctrlKey: event.ctrlKey || event.metaKey,
          metaKey: event.metaKey
        })
        
        const clickedName = clickedObject.name
        
        // 找到基础对象名称和相关对象
        let baseName = clickedName
        const relatedNames: string[] = []
        
        // 如果点击的是 _cut 对象，找到基础对象名称
        if (clickedName.endsWith('_cut')) {
          baseName = clickedName.replace(/_cut$/, '')
          relatedNames.push(baseName) // 添加基础对象
          relatedNames.push(clickedName) // 添加当前 _cut 对象
          
          // 查找同名的所有 _cut 变体（如 _arch, 普通 _cut 等）
          if (cachedJSON) {
            cachedJSON.objects.forEach((obj: any) => {
              if (obj.type === 'subtract' && obj.parent === baseName) {
                if (obj.name && !relatedNames.includes(obj.name)) {
                  relatedNames.push(obj.name)
                }
              }
            })
          }
        } else {
          // 点击的是基础对象
          relatedNames.push(clickedName) // 添加基础对象
          
          // 查找所有关联的 subtract 对象
          if (cachedJSON) {
            cachedJSON.objects.forEach((obj: any) => {
              if (obj.type === 'subtract' && obj.parent === clickedName) {
                if (obj.name && !relatedNames.includes(obj.name)) {
                  relatedNames.push(obj.name)
                }
              }
              // 也查找以 baseName_ 开头的对象
              if (obj.name && obj.name.startsWith(clickedName + '_') && !relatedNames.includes(obj.name)) {
                relatedNames.push(obj.name)
              }
            })
          }
        }
        
        // 过滤掉不存在的对象
        const validRelatedNames = relatedNames.filter(name => 
          name && name !== '' && objectDefinitions[name] && !deletedComponentNames.value.has(name)
        )
        
        // 确保至少包含原对象
        if (!validRelatedNames.includes(clickedName) && !deletedComponentNames.value.has(clickedName)) {
          validRelatedNames.unshift(clickedName)
        }
        
        // 处理选择逻辑（支持 Ctrl 多选）
        if (syntheticEvent.ctrlKey || syntheticEvent.metaKey) {
          // Ctrl + 双击：添加选择
          validRelatedNames.forEach(name => {
            if (!selectedComponentNames.value.includes(name)) {
              selectedComponentNames.value.push(name)
              setMeshHighlighted(meshByComponentName[name], true)
              addBoundingBox(name)
            }
          })
        } else {
          // 普通双击：替换选择
          // 清除所有已选中的高亮
          selectedComponentNames.value.forEach(selectedName => {
            setMeshHighlighted(meshByComponentName[selectedName], false)
            removeBoundingBox(selectedName)
          })
          
          // 选中所有相关对象
          selectedComponentNames.value = []
          validRelatedNames.forEach(name => {
            if (objectDefinitions[name] && !deletedComponentNames.value.has(name)) {
              selectedComponentNames.value.push(name)
              setMeshHighlighted(meshByComponentName[name], true)
              addBoundingBox(name)
            }
          })
        }
        
        updateScaleDisplay()
        
        // 滚动到第一个组件
        if (selectedComponentNames.value.length > 0) {
          scrollToComponent(selectedComponentNames.value[0])
        }
        
        // 重置
        lastClickTime = 0
        lastClickObject = null
      } else {
        // 第一次点击，记录
        lastClickTime = currentTime
        lastClickObject = clickedObject
      }
    } else {
      // 点击了物体但没有名字，重置
      lastClickTime = 0
      lastClickObject = null
    }
  } else {
    // 点击空白区域，重置
    lastClickTime = 0
    lastClickObject = null
  }
}

// 滚动到对应的组件
const scrollToComponent = (name: string) => {
  // 找到对应的组件元素并滚动到可见位置
  setTimeout(() => {
    const chipElements = document.querySelectorAll('.component-chip')
    chipElements.forEach((el) => {
      const chipName = el.querySelector('.chip-name')?.textContent
      if (chipName === name) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' })
      }
    })
  }, 100)
}

const getLocalMatrix = (obj: any) => {
  const matrix = new THREE.Matrix4()
  matrix.identity()

  if (obj.rotation) {
    const euler = new THREE.Euler(
      (obj.rotation[0] * Math.PI) / 180,
      (obj.rotation[1] * Math.PI) / 180,
      (obj.rotation[2] * Math.PI) / 180
    )
    const quat = new THREE.Quaternion()
    quat.setFromEuler(euler)
    const rotMatrix = new THREE.Matrix4()
    rotMatrix.makeRotationFromQuaternion(quat)
    matrix.multiply(rotMatrix)
  }

  if (obj.position) {
    matrix.setPosition(obj.position[0], obj.position[1], obj.position[2])
  }

  return matrix
}

const makeMaterial = (obj: any) => {
  const color = new THREE.Color(
    obj.color ? obj.color[0] : 0.8,
    obj.color ? obj.color[1] : 0.8,
    obj.color ? obj.color[2] : 0.8
  )
  const opacity = obj.opacity ?? 1
  const transparent = opacity < 1
  const isWindow = isGlassObjectName(obj.name)

  if (isWindow) {
    return new THREE.MeshPhysicalMaterial({
      color,
      transparent: true,
      opacity: opacity < 1 ? opacity : 0.35,
      transmission: 0.9,
      roughness: 0.08,
      metalness: 0,
      thickness: 0.02,
      attenuationColor: color,
      attenuationDistance: 0.7,
      side: THREE.DoubleSide,
      depthTest: true,
      depthWrite: false,
    })
  }

  const material = new THREE.MeshStandardMaterial({
    color,
    metalness: 0.1,
    roughness: 0.8,
    transparent,
    opacity,
    side: THREE.DoubleSide,
    depthTest: true,
    depthWrite: transparent ? false : true,
    alphaTest: transparent ? 0 : 0,
  })

  return material
}

const createRulerAxis = (
  length: number,
  direction: THREE.Vector3,
  color: number,
  majorTickSpacing: number,
  minorTickSpacing: number,
  majorTickSize: number,
  minorTickSize: number
) => {
  const points: THREE.Vector3[] = []
  const axisEnd = direction.clone().multiplyScalar(length)
  points.push(new THREE.Vector3(0, 0, 0), axisEnd)

  for (let pos = 0; pos <= length + 0.0001; pos += minorTickSpacing) {
    const tickCenter = direction.clone().multiplyScalar(pos)
    const tickOffset = new THREE.Vector3()
    const isMajor = Math.abs(pos % majorTickSpacing) < 0.0001
    const size = isMajor ? majorTickSize : minorTickSize

    if (Math.abs(direction.x) > 0) tickOffset.set(0, size, 0)
    else if (Math.abs(direction.y) > 0) tickOffset.set(size, 0, 0)
    else tickOffset.set(size, 0, 0)

    points.push(tickCenter.clone().sub(tickOffset))
    points.push(tickCenter.clone().add(tickOffset))
  }

  const geometry = new THREE.BufferGeometry().setFromPoints(points)
  const material = new THREE.LineBasicMaterial({
    color,
    transparent: true,
    opacity: 0.2,
    depthTest: true,
  })
  const line = new THREE.LineSegments(geometry, material)

  const group = new THREE.Group()
  group.add(line)
  return group
}

const updateCameraByKeyboard = () => {
  if (!camera || !controls) return

  const speed = 0.1
  const worldUp = new THREE.Vector3(0, 1, 0)
  const forward = new THREE.Vector3()
  camera.getWorldDirection(forward)
  forward.y = 0
  if (forward.lengthSq() < 1e-8) {
    forward.set(0, 0, -1)
  } else {
    forward.normalize()
  }
  const right = new THREE.Vector3().crossVectors(forward, worldUp).normalize()
  const move = new THREE.Vector3()

  if (keyState.KeyW || keyState.ArrowUp) {
    move.add(forward)
  }
  if (keyState.KeyS || keyState.ArrowDown) {
    move.sub(forward)
  }
  if (keyState.KeyA) {
    move.sub(right)
  }
  if (keyState.KeyD) {
    move.add(right)
  }

  if (move.lengthSq() > 0) {
    move.normalize().multiplyScalar(speed)
    camera.position.add(move)
    controls.target.add(move)
  }
}

const resize = () => {
  if (!container.value || !renderer || !camera) return
  const width = container.value.clientWidth
  const height = container.value.clientHeight
  camera.aspect = width / height
  camera.updateProjectionMatrix()
  renderer.setSize(width, height)
}

const animate = () => {
  if (!renderer || !scene || !camera || !controls) return
  updateCameraByKeyboard()
  controls.update()
  renderer.render(scene, camera)
  animationId = requestAnimationFrame(animate)
}

// 从场景中清理所有网格体（保留辅助对象如网格、坐标轴等）
const clearSceneMeshes = () => {
  if (!scene) return
  
  const objectsToRemove: THREE.Object3D[] = []
  scene.traverse((child) => {
    if (child instanceof Brush || 
        (child instanceof THREE.Mesh && !(child instanceof THREE.GridHelper) && 
         !(child instanceof THREE.AxesHelper))) {
      objectsToRemove.push(child)
    } else if (child instanceof THREE.Group && child.children.length > 0) {
      const hasLine = child.children.some(c => c instanceof THREE.LineSegments)
      if (!hasLine) {
        objectsToRemove.push(child)
      }
    }
  })
  
  objectsToRemove.forEach(obj => {
    scene?.remove(obj)
  })
  
  // 清理所有 box helpers
  Object.keys(selectionBoxHelpers).forEach(key => {
    const boxHelper = selectionBoxHelpers[key]
    if (boxHelper && scene) {
      scene.remove(boxHelper)
    }
    delete selectionBoxHelpers[key]
  })
}

// 使用指定数据构建场景
const buildSceneFromData = (data: { objects: any[] }) => {
  if (!scene) return
  
  // 清理场景
  clearSceneMeshes()
  
  // 清理数据结构
  Object.keys(objectDefinitions).forEach(key => delete objectDefinitions[key])
  Object.keys(meshByComponentName).forEach(key => delete meshByComponentName[key])
  Object.keys(originalSizes).forEach(key => delete originalSizes[key])
  movedObjects.clear()
  selectedComponentNames.value = []
  updateScaleDisplay()
  
  // 初始化对象定义（过滤已删除的对象）
  data.objects.forEach((obj: any) => {
    if (obj.name && !deletedComponentNames.value.has(obj.name)) {
      objectDefinitions[obj.name] = JSON.parse(JSON.stringify(obj))
    }
  })
  
  // 初始化原始尺寸
  data.objects.forEach((obj: any) => {
    if (!obj.name || deletedComponentNames.value.has(obj.name)) return
    if (obj.type === 'cylinder') {
      originalSizes[obj.name] = [obj.radius, obj.height]
    } else if (obj.size) {
      originalSizes[obj.name] = [...obj.size] as [number, number, number]
    }
  })
  
  // 分类对象
  const evaluator = new Evaluator()
  const baseObjects: any[] = []
  const subtractOps: { [parent: string]: any[] } = {}
  const decorativeObjects: any[] = []
  
  data.objects.forEach((obj: any) => {
    if (!obj.name || deletedComponentNames.value.has(obj.name)) return
    
    if (obj.type === 'subtract') {
      // 检查父对象是否已被删除
      if (deletedComponentNames.value.has(obj.parent)) return
      
      if (!subtractOps[obj.parent]) {
        subtractOps[obj.parent] = []
      }
      subtractOps[obj.parent].push(obj)
    } else if (HIDE_WINDOW_MESHES && isGlassObjectName(obj.name)) {
      return
    } else if (isGlassObjectName(obj.name) || (obj.opacity !== undefined && obj.opacity < 1 && (obj.type === 'box' || obj.type === 'cylinder'))) {
      decorativeObjects.push(obj)
    } else if (obj.type === 'box' || obj.type === 'cylinder') {
      baseObjects.push(obj)
    }
  })
  
  const getMatrixForObject = (obj: any) => {
    return getWorldMatrix(obj)
  }
  
  // 构建基础对象（包含 CSG 减法）
  baseObjects.forEach((obj: any) => {
    let geom: THREE.BufferGeometry
    const material = makeMaterial(obj)

    if (obj.type === 'box') {
      geom = new THREE.BoxGeometry(obj.size[0], obj.size[1], obj.size[2])
    } else if (obj.type === 'cylinder') {
      geom = new THREE.CylinderGeometry(obj.radius, obj.radius, obj.height, 32)
    } else {
      return
    }

    const matrix = getMatrixForObject(obj)
    geom.applyMatrix4(matrix)

    let result = new Brush(geom, material)

    if (subtractOps[obj.name]) {
      subtractOps[obj.name].forEach((sub: any) => {
        let subGeom: THREE.BufferGeometry
        if (sub.shape === 'box') {
          subGeom = new THREE.BoxGeometry(sub.size[0], sub.size[1], sub.size[2])
        } else if (sub.shape === 'cylinder') {
          subGeom = new THREE.CylinderGeometry(sub.radius, sub.radius, sub.height, 32)
        } else {
          return
        }

        const subMatrix = getMatrixForObject(sub)
        subGeom.applyMatrix4(subMatrix)

        const subBrush = new Brush(
          subGeom,
          new THREE.MeshStandardMaterial({
            depthTest: true,
          })
        )
        result = evaluator.evaluate(result, subBrush, SUBTRACTION)
      })
    }

    scene?.add(result)
    result.renderOrder = 0
    if (obj.name) {
      result.name = obj.name
      meshByComponentName[obj.name] = result
    }
  })
  
  // 构建装饰对象
  decorativeObjects.forEach((obj: any) => {
    let geom: THREE.BufferGeometry
    const material = makeMaterial(obj)

    if (obj.type === 'box') {
      geom = new THREE.BoxGeometry(obj.size[0], obj.size[1], obj.size[2])
    } else if (obj.type === 'cylinder') {
      geom = new THREE.CylinderGeometry(obj.radius, obj.radius, obj.height, 32)
    } else {
      return
    }

    const matrix = getMatrixForObject(obj)
    geom.applyMatrix4(matrix)

    const mesh = new THREE.Mesh(geom, material)
    mesh.renderOrder = obj.opacity !== undefined && obj.opacity < 1 ? 2 : 1
    if (obj.name) {
      mesh.name = obj.name
      meshByComponentName[obj.name] = mesh
    }
    scene?.add(mesh)
  })
}

// 重建场景 - 使用 exportJSON 的数据
const rebuildScene = () => {
  const exportData = getExportData()
  
  if (!exportData) {
    exportMessage.value = '❌ No data to rebuild from'
    if (exportTimeout) clearTimeout(exportTimeout)
    exportTimeout = setTimeout(() => { exportMessage.value = '' }, 3000)
    return
  }
  cachedJSON = exportData
  isLoading.value = true
  
  try {
    // 使用导出数据重建场景
    buildSceneFromData(cachedJSON)
    
    exportMessage.value = '✅ Scene rebuilt'
  } catch (error) {
    console.error('Failed to rebuild scene:', error)
    exportMessage.value = '❌ Failed to rebuild scene'
  } finally {
    isLoading.value = false
    if (exportTimeout) clearTimeout(exportTimeout)
    exportTimeout = setTimeout(() => { exportMessage.value = '' }, 3000)
  }
}

onMounted(async () => {
  if (!container.value) return

  const width = container.value.clientWidth
  const height = container.value.clientHeight

  scene = new THREE.Scene()
  scene.background = new THREE.Color(0x111827)

  camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000)
  camera.position.set(18, 12, 28)

  renderer = new THREE.WebGLRenderer({ antialias: true })
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
  renderer.setSize(width, height)
  renderer.sortObjects = true
  container.value.appendChild(renderer.domElement)

  const ambientLight = new THREE.AmbientLight(0xffffff, 0.6)
  scene.add(ambientLight)

  const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8)
  directionalLight.position.set(5, 10, 7.5)
  scene.add(directionalLight)

  // 添加辅助对象（这些不会被重建清除）
  const grid = new THREE.GridHelper(220, 22, 0x444444, 0x222222)
  scene.add(grid)

  const meterAxis = createRulerAxis(12, new THREE.Vector3(1, 0, 0), 0xff0000, 1, 0.1, 0.4, 0.15)
  meterAxis.position.set(0, 0.01, 0)
  scene.add(meterAxis)

  const yAxis = createRulerAxis(12, new THREE.Vector3(0, 1, 0), 0x00ff00, 1, 0.1, 0.4, 0.15)
  yAxis.position.set(0, 0.01, 0)
  scene.add(yAxis)

  const zAxis = createRulerAxis(12, new THREE.Vector3(0, 0, 1), 0x0000ff, 1, 0.1, 0.4, 0.15)
  zAxis.position.set(0, 0.01, 0)
  scene.add(zAxis)

  const axes = new THREE.AxesHelper(5)
  scene.add(axes)

  // 加载初始数据
  try {
    const response = await fetch('/bus.json')
    const data = await response.json()

    cachedJSON = { objects: (data.objects ?? []).map((obj: any) => ({ ...obj })) }

    componentList.value = (data.objects ?? []).map((obj: any, index: number) => ({
      name: obj.name ?? `unnamed_${index}`,
      type: obj.type ?? 'unknown',
      parent: obj.parent,
    }))

    // 使用原始数据构建初始场景
    if (cachedJSON) {
      buildSceneFromData(cachedJSON)
    }
  } catch (error) {
    console.error('Failed to load bus.json:', error)
  }

  controls = new OrbitControls(camera!, renderer!.domElement)
  controls.enableDamping = true

  window.addEventListener('resize', resize)
  window.addEventListener('keydown', onKeyDown)
  window.addEventListener('keyup', onKeyUp)
  
  // 添加双击选择事件
  if (container.value) {
    container.value.addEventListener('mousedown', onMouseDown)
  }
  
  animate()
})

onBeforeUnmount(() => {
  if (animationId) cancelAnimationFrame(animationId)
  window.removeEventListener('resize', resize)
  window.removeEventListener('keydown', onKeyDown)
  window.removeEventListener('keyup', onKeyUp)
  
  // 移除双击选择事件
  if (container.value) {
    container.value.removeEventListener('mousedown', onMouseDown)
  }

  // 清理所有包围盒
  Object.keys(selectionBoxHelpers).forEach(key => {
    const boxHelper = selectionBoxHelpers[key]
    if (boxHelper && scene) {
      scene.remove(boxHelper)
    }
    delete selectionBoxHelpers[key]
  })

  if (renderer && renderer.domElement.parentNode) {
    renderer.domElement.parentNode.removeChild(renderer.domElement)
  }

  renderer = null
  scene = null
  camera = null
  controls = null
})
</script>

<style scoped>
.scene-root {
  width: 100%;
  min-height: 100vh;
  position: relative;
  overflow: hidden;
}

.panels-wrapper {
  position: fixed;
  left: 0;
  top: 0;
  bottom: 0;
  display: flex;
  z-index: 20;
}

.component-panel {
  width: 280px;
  background: #0f172a;
  color: #e2e8f0;
  padding: 12px;
  box-sizing: border-box;
  overflow-y: auto;
  height: 100%;
}

/* 左侧第一列：组件列表 */
.left-panel {
  border-right: 1px solid #1e293b;
}

/* 左侧第二列：变换控制 */
.transform-panel {
  width: 240px;
  border-right: 1px solid #1e293b;
}

.panel-title {
  font-size: 16px;
  font-weight: 700;
  margin-bottom: 8px;
}

.panel-count {
  margin-top: 4px;
  margin-bottom: 10px;
  color: #94a3b8;
  font-size: 12px;
}

.selected-count {
  color: #22c55e;
  font-weight: 600;
}

.filter-box {
  position: relative;
  margin-bottom: 10px;
}

.filter-input {
  width: 100%;
  padding: 8px 32px 8px 10px;
  border-radius: 6px;
  border: 1px solid #1f2937;
  background: #111827;
  color: #e2e8f0;
  font-size: 13px;
  outline: none;
  box-sizing: border-box;
  transition: border-color 0.15s ease;
}

.filter-input:focus {
  border-color: #22c55e;
}

.filter-input::placeholder {
  color: #64748b;
}

.filter-clear {
  position: absolute;
  right: 6px;
  top: 50%;
  transform: translateY(-50%);
  background: none;
  border: none;
  color: #94a3b8;
  cursor: pointer;
  font-size: 14px;
  padding: 2px 6px;
  border-radius: 3px;
  transition: color 0.15s ease, background-color 0.15s ease;
}

.filter-clear:hover {
  color: #e2e8f0;
  background: #1e293b;
}

.rebuild-section {
  margin-bottom: 10px;
}

.rebuild-btn {
  width: 100%;
  padding: 10px 0;
  border-radius: 6px;
  border: 1px solid #3b82f6;
  background: #0a1a3a;
  color: #3b82f6;
  cursor: pointer;
  font-size: 14px;
  font-weight: 600;
  transition: background-color 0.3s ease, border-color 0.3s ease, opacity 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
}

.rebuild-btn:hover {
  background: #0d1f4a;
  border-color: #60a5fa;
  color: #60a5fa;
}

.rebuild-btn:active {
  background: #071430;
  transform: scale(0.98);
}

.rebuild-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  background: #1a1a2e;
  border-color: #334155;
  color: #64748b;
  transform: none;
}

.action-buttons {
  margin-bottom: 10px;
}

.delete-selection-btn {
  width: 100%;
  padding: 8px 0;
  border-radius: 6px;
  border: 1px solid #f59e0b;
  background: #1a140a;
  color: #f59e0b;
  cursor: pointer;
  font-size: 14px;
  font-weight: 600;
  margin-bottom: 8px;
  transition: background-color 0.15s ease;
}

.delete-selection-btn:hover {
  background: #2d1f0a;
}

.clear-selection-btn {
  width: 100%;
  padding: 8px 0;
  border-radius: 6px;
  border: 1px solid #ef4444;
  background: #1a0f0f;
  color: #ef4444;
  cursor: pointer;
  font-size: 14px;
  font-weight: 600;
  margin-bottom: 8px;
  transition: background-color 0.15s ease;
}

.clear-selection-btn:hover {
  background: #2d1515;
}

.export-btn {
  width: 100%;
  padding: 8px 0;
  border-radius: 6px;
  border: 1px solid #22c55e;
  background: #052e16;
  color: #22c55e;
  cursor: pointer;
  font-size: 14px;
  font-weight: 600;
  transition: background-color 0.15s ease;
}

.export-btn:hover {
  background: #064e1b;
}

.export-msg {
  margin-top: 6px;
  font-size: 12px;
  color: #22c55e;
  text-align: center;
}

.component-flow {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.component-chip {
  background: #111827;
  border: 1px solid #1f2937;
  border-radius: 6px;
  padding: 8px;
  display: flex;
  flex-direction: column;
  gap: 2px;
  max-width: 100%;
  cursor: pointer;
  transition: border-color 0.15s ease, background-color 0.15s ease;
}

.component-chip.selected {
  border-color: #22c55e;
  background: #052e16;
}

.component-chip.deleted {
  opacity: 0.3;
  text-decoration: line-through;
}

.chip-name {
  font-size: 13px;
  font-weight: 600;
  word-break: break-word;
}

.chip-type,
.chip-parent {
  font-size: 11px;
  color: #94a3b8;
  word-break: break-word;
}

/* 变换面板样式 */
.transform-section {
  display: flex;
  flex-direction: column;
  gap: 0;
}

.transform-group {
  margin-bottom: 4px;
}

.transform-group-title {
  font-size: 14px;
  font-weight: 700;
  color: #22c55e;
  margin-bottom: 8px;
  padding-bottom: 4px;
  border-bottom: 1px solid #1e293b;
}

.transform-title-info {
  font-size: 12px;
  color: #94a3b8;
  margin-bottom: 10px;
  word-break: break-word;
}

.transform-scale-display {
  font-size: 16px;
  font-weight: 600;
  color: #e2e8f0;
  margin-bottom: 10px;
  padding: 4px 8px;
  background: #1a1a2e;
  border-radius: 4px;
  text-align: center;
}

.transform-row {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 6px;
}

.axis-label {
  width: 20px;
  text-align: center;
  font-size: 13px;
  font-weight: 700;
  color: #64748b;
}

.axis-x {
  color: #ef4444;
}

.axis-y {
  color: #22c55e;
}

.axis-z {
  color: #3b82f6;
}

.dir-btn {
  flex: 1;
  padding: 6px 0;
  border-radius: 4px;
  border: 1px solid #1f2937;
  background: #0f172a;
  color: #e2e8f0;
  cursor: pointer;
  font-size: 13px;
  font-weight: 600;
  transition: background-color 0.15s ease, border-color 0.15s ease;
}

.dir-btn:hover {
  background: #1e293b;
  border-color: #22c55e;
}

.transform-step {
  margin-top: 8px;
  font-size: 12px;
  color: #94a3b8;
}

.step-select {
  margin-left: 4px;
  padding: 2px 4px;
  border-radius: 4px;
  border: 1px solid #1f2937;
  background: #0f172a;
  color: #e2e8f0;
  font-size: 12px;
  outline: none;
}

.transform-divider {
  height: 1px;
  background: #1e293b;
  margin: 12px 0;
}

.canvas-container {
  width: 100%;
  min-height: 100vh;
  overflow: hidden;
}

/* 响应式布局 */
@media (max-width: 1100px) {
  .transform-panel {
    display: none;
  }
  
  .left-panel {
    width: 260px;
  }
}
</style>  <template>
  <div class="scene-root">
    <!-- 左侧面板容器 -->
    <div class="panels-wrapper">
      <!-- 左侧第一列：组件列表面板 -->
      <aside class="component-panel left-panel">
        <div class="panel-title">Components</div>
        <div class="panel-count">
          Total: {{ filteredComponentList.length }} / {{ componentList.length }}
          <span v-if="selectedComponentNames.length > 0" class="selected-count">
            | Selected: {{ selectedComponentNames.length }}
          </span>
        </div>
        <div class="filter-box">
          <input
            v-model="filterText"
            type="text"
            class="filter-input"
            placeholder="Filter components..."
            @keyup.escape="clearFilter"
          />
          <button v-if="filterText" class="filter-clear" @click="clearFilter">✕</button>
        </div>
        <div class="rebuild-section">
          <button 
            class="rebuild-btn" 
            @click="rebuildScene"
            :disabled="isLoading"
          >
            <span v-if="isLoading">⏳ Rebuilding...</span>
            <span v-else>🔄 Rebuild from Export Data</span>
          </button>
        </div>
        <div v-if="selectedComponentNames.length > 0" class="action-buttons">
          <button class="delete-selection-btn" @click="deleteSelected">🗑 Delete Selected</button>
          <button class="clear-selection-btn" @click="clearSelection">✕ Clear Selection</button>
          <button class="export-btn" @click="exportJSON">📥 Export JSON</button>
          <div v-if="exportMessage" class="export-msg">{{ exportMessage }}</div>
        </div>
        <div class="component-flow">
          <div
            v-for="item in filteredComponentList"
            :key="item.name"
            class="component-chip"
            :class="{ selected: selectedComponentNames.includes(item.name), deleted: deletedComponentNames.has(item.name) }"
            @click="toggleComponentSelection(item.name, $event)"
          >
            <span class="chip-name">{{ item.name }}</span>
            <span class="chip-type">{{ item.type }}</span>
            <span v-if="item.parent" class="chip-parent">parent: {{ item.parent }}</span>
          </div>
        </div>
      </aside>

      <!-- 左侧第二列：变换控制面板 -->
      <aside class="component-panel transform-panel" v-if="selectedComponentNames.length > 0">
        <div class="panel-title">Transform</div>
        <div class="transform-section">
          <div class="transform-group">
            <div class="transform-group-title">Position</div>
            <div class="transform-title-info">
              <span v-if="selectedComponentNames.length === 1">
                {{ selectedComponentNames[0] }}
              </span>
              <span v-else>
                {{ selectedComponentNames.length }} components selected
              </span>
            </div>
            <div class="transform-row">
              <span class="axis-label axis-x">X</span>
              <button class="dir-btn" @click="moveSelected('-x')">-</button>
              <button class="dir-btn" @click="moveSelected('+x')">+</button>
            </div>
            <div class="transform-row">
              <span class="axis-label axis-y">Y</span>
              <button class="dir-btn" @click="moveSelected('-y')">-</button>
              <button class="dir-btn" @click="moveSelected('+y')">+</button>
            </div>
            <div class="transform-row">
              <span class="axis-label axis-z">Z</span>
              <button class="dir-btn" @click="moveSelected('-z')">-</button>
              <button class="dir-btn" @click="moveSelected('+z')">+</button>
            </div>
            <div class="transform-step">
              <label>
                Step:
                <select v-model="moveStep" class="step-select">
                  <option :value="0.01">0.01</option>
                  <option :value="0.05">0.05</option>
                  <option :value="0.1">0.1</option>
                  <option :value="0.5">0.5</option>
                  <option :value="1.0">1.0</option>
                </select>
              </label>
            </div>
          </div>

          <div class="transform-divider"></div>

          <div class="transform-group">
            <div class="transform-group-title">Scale</div>
            <div class="transform-scale-display">{{ formatScale(selectedScale) }}</div>
            <div class="transform-row">
              <span class="axis-label axis-x">X</span>
              <button class="dir-btn" @click="scaleSelected('-x')">-</button>
              <button class="dir-btn" @click="scaleSelected('+x')">+</button>
            </div>
            <div class="transform-row">
              <span class="axis-label axis-y">Y</span>
              <button class="dir-btn" @click="scaleSelected('-y')">-</button>
              <button class="dir-btn" @click="scaleSelected('+y')">+</button>
            </div>
            <div class="transform-row">
              <span class="axis-label axis-z">Z</span>
              <button class="dir-btn" @click="scaleSelected('-z')">-</button>
              <button class="dir-btn" @click="scaleSelected('+z')">+</button>
            </div>
            <div class="transform-step">
              <label>
                Step:
                <select v-model="scaleStep" class="step-select">
                  <option :value="0.01">0.01</option>
                  <option :value="0.05">0.05</option>
                  <option :value="0.1">0.1</option>
                  <option :value="0.25">0.25</option>
                  <option :value="0.5">0.5</option>
                </select>
              </label>
            </div>
          </div>
        </div>
      </aside>
    </div>

    <div ref="container" class="canvas-container"></div>
  </div>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import * as THREE from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls'
import { SUBTRACTION, Brush, Evaluator } from 'three-bvh-csg'

const container = ref<HTMLElement | null>(null)
let renderer: THREE.WebGLRenderer | null = null
let scene: THREE.Scene | null = null
let camera: THREE.PerspectiveCamera | null = null
let controls: OrbitControls | null = null
let animationId = 0

// 原始 JSON 缓存（从文件加载后不再修改，用于导出和参考）
let cachedJSON: { objects: any[] } | null = null
// 运行时定义（用于渲染，位置会随移动更新）
const objectDefinitions: Record<string, any> = {}
// 记录被移动过的对象
const movedObjects = new Set<string>()
// 记录被删除的对象名称
const deletedComponentNames = ref(new Set<string>())
const HIDE_WINDOW_MESHES = false
const componentList = ref<Array<{ name: string; type: string; parent?: string }>>([])
const filterText = ref('')
const selectedComponentNames = ref<string[]>([])
const moveStep = ref(0.1)
const scaleStep = ref(0.1)
const selectedScale = ref<[number, number, number]>([1, 1, 1])
const exportMessage = ref('')
const meshByComponentName: Record<string, THREE.Object3D> = {}
const originalSizes: Record<string, [number, number, number] | [number]> = {}
const selectionBoxHelpers: Record<string, THREE.BoxHelper> = {}
const isLoading = ref(false)

// 双击选择相关变量
const raycaster = new THREE.Raycaster()
const mouse = new THREE.Vector2()
let lastClickTime = 0
let lastClickObject: THREE.Object3D | null = null

const filteredComponentList = computed(() => {
  const query = filterText.value.trim().toLowerCase()
  let list = componentList.value
  
  // 过滤掉已删除的组件
  list = list.filter(item => !deletedComponentNames.value.has(item.name))
  
  if (!query) return list
  return list.filter(item => item.name.toLowerCase().includes(query))
})

const clearFilter = () => {
  filterText.value = ''
}

const formatScale = (scale: [number, number, number]) => {
  return `${scale[0].toFixed(2)}, ${scale[1].toFixed(2)}, ${scale[2].toFixed(2)}`
}

let exportTimeout: ReturnType<typeof setTimeout> | null = null

const getMeshWorldPosition = (obj: THREE.Object3D): THREE.Vector3 => {
  const worldPos = new THREE.Vector3()
  obj.getWorldPosition(worldPos)
  return worldPos
}

const getParentWorldPosition = (parentName: string): THREE.Vector3 | null => {
  const parentMesh = meshByComponentName[parentName]
  if (parentMesh) {
    return getMeshWorldPosition(parentMesh)
  }

  const parentDef = objectDefinitions[parentName]
  if (parentDef) {
    const worldMatrix = getWorldMatrix(parentDef)
    const pos = new THREE.Vector3()
    pos.setFromMatrixPosition(worldMatrix)
    return pos
  }

  return null
}

const getWorldMatrix = (obj: any, visited = new Set<string>()): THREE.Matrix4 => {
  const local = getLocalMatrix(obj)
  if (!obj.parent) return local

  const parentName = String(obj.parent)
  if (visited.has(parentName)) {
    return local
  }

  const parentObj = objectDefinitions[parentName]
  if (!parentObj) return local

  visited.add(parentName)
  const parentWorld = getWorldMatrix(parentObj, visited)
  return parentWorld.multiply(local)
}

const getRelativePosition = (def: any): [number, number, number] | null => {
  if (!def.position) return null

  if (!def.parent) {
    return [...def.position]
  }

  const parentDef = objectDefinitions[def.parent]
  if (!parentDef || !parentDef.position) {
    return [...def.position]
  }

  return [
    def.position[0] - parentDef.position[0],
    def.position[1] - parentDef.position[1],
    def.position[2] - parentDef.position[2],
  ]
}

// 获取导出数据（包含所有运行时修改，排除已删除的对象）
const getExportData = () => {
  if (!cachedJSON) {
    return null
  }

  const exportedObjects = cachedJSON.objects
    .filter((cachedObj: any) => {
      // 过滤掉已删除的对象
      return !deletedComponentNames.value.has(cachedObj.name)
    })
    .map((cachedObj: any) => {
      const name = cachedObj.name
      const runtimeDef = name ? objectDefinitions[name] : null

      const exported: any = {}

      // 复制所有原始属性
      for (const key of Object.keys(cachedObj)) {
        exported[key] = cachedObj[key]
      }

      // 覆盖运行时修改过的属性
      if (runtimeDef) {
        // 只对移动过的对象使用叠加
        if (name && movedObjects.has(name) && cachedObj.position) {
          const meshObj = meshByComponentName[name]
          if (meshObj) {
            exported.position = [
              cachedObj.position[0] + meshObj.position.x,
              cachedObj.position[1] + meshObj.position.y,
              cachedObj.position[2] + meshObj.position.z
            ]
          } else {
            // subtract 对象，直接使用运行时定义的位置（相对坐标）
            exported.position = [...runtimeDef.position]
          }
        }
        
        if (runtimeDef.size) {
          exported.size = [...runtimeDef.size]
        }
        if (cachedObj.type === 'cylinder') {
          if (runtimeDef.radius !== undefined) exported.radius = runtimeDef.radius
          if (runtimeDef.height !== undefined) exported.height = runtimeDef.height
        }
      }

      return exported
    })

  return { objects: exportedObjects }
}

const exportJSON = () => {
  const exportData = getExportData()
  
  if (!exportData) {
    exportMessage.value = '❌ No cached JSON'
    if (exportTimeout) clearTimeout(exportTimeout)
    exportTimeout = setTimeout(() => { exportMessage.value = '' }, 3000)
    return
  }

  const jsonStr = JSON.stringify(exportData, null, 2)
  navigator.clipboard.writeText(jsonStr).then(() => {
    exportMessage.value = '✅ Copied to clipboard!'
  }).catch(() => {
    const blob = new Blob([jsonStr], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'bus_modified.json'
    a.click()
    URL.revokeObjectURL(url)
    exportMessage.value = '⬇ Downloaded bus_modified.json'
  })
  if (exportTimeout) clearTimeout(exportTimeout)
  exportTimeout = setTimeout(() => {
    exportMessage.value = ''
  }, 3000)
}

const updateScaleDisplay = () => {
  if (selectedComponentNames.value.length === 0) {
    selectedScale.value = [1, 1, 1]
    return
  }
  const firstSelected = selectedComponentNames.value[0]
  const mesh = meshByComponentName[firstSelected]
  if (mesh) {
    selectedScale.value = [mesh.scale.x, mesh.scale.y, mesh.scale.z]
  }
}

const setMeshHighlighted = (mesh: THREE.Object3D | undefined, highlighted: boolean) => {
  if (!mesh) return
  mesh.traverse(child => {
    if (child instanceof THREE.Mesh) {
      const materials = Array.isArray(child.material) ? child.material : [child.material]
      materials.forEach(material => {
        if (!(material instanceof THREE.MeshStandardMaterial || material instanceof THREE.MeshPhysicalMaterial)) {
          return
        }
        if (highlighted) {
          if (material.userData.__origEmissive === undefined) {
            material.userData.__origEmissive = material.emissive.getHex()
            material.userData.__origEmissiveIntensity = material.emissiveIntensity
          }
          material.emissive.setHex(0x22c55e)
          material.emissiveIntensity = 0.9
        } else if (material.userData.__origEmissive !== undefined) {
          material.emissive.setHex(material.userData.__origEmissive)
          material.emissiveIntensity = material.userData.__origEmissiveIntensity ?? 1
        }
      })
    }
  })
}

const addBoundingBox = (name: string) => {
  if (selectionBoxHelpers[name]) return
  
  const def = objectDefinitions[name]
  if (!def) return
  
  // 从 objectDefinitions 获取当前定义（包含运行时修改）
  const currentDef = objectDefinitions[name]
  if (!currentDef) return
  
  // 创建临时几何体
  let geometry: THREE.BufferGeometry
  
  if (currentDef.type === 'box' || currentDef.shape === 'box' || currentDef.type === 'subtract') {
    const size = currentDef.size || [1, 1, 1]
    geometry = new THREE.BoxGeometry(size[0], size[1], size[2])
  } else if (currentDef.type === 'cylinder' || currentDef.shape === 'cylinder') {
    geometry = new THREE.CylinderGeometry(
      currentDef.radius || 0.5, 
      currentDef.radius || 0.5, 
      currentDef.height || 1, 
      16
    )
  } else {
    return
  }
  
  const tempMesh = new THREE.Mesh(geometry)
  
  // 计算当前位置
  let worldPos = new THREE.Vector3(
    currentDef.position?.[0] || 0,
    currentDef.position?.[1] || 0,
    currentDef.position?.[2] || 0
  )
  
  // 如果是 subtract 对象或子对象，需要加上父对象的位置
  if ((currentDef.type === 'subtract' || currentDef.shape) && currentDef.parent) {
    const parentDef = objectDefinitions[currentDef.parent]
    if (parentDef && parentDef.position) {
      worldPos.x += parentDef.position[0]
      worldPos.y += parentDef.position[1]
      worldPos.z += parentDef.position[2]
    }
  }
  
  // 如果对象有 mesh 且被移动过，加上偏移量
  if (movedObjects.has(name)) {
    const mesh = meshByComponentName[name]
    if (mesh) {
      worldPos.x += mesh.position.x
      worldPos.y += mesh.position.y
      worldPos.z += mesh.position.z
    }
  }
  
  tempMesh.position.copy(worldPos)
  
  // 应用旋转
  if (currentDef.rotation) {
    tempMesh.rotation.set(
      (currentDef.rotation[0] * Math.PI) / 180,
      (currentDef.rotation[1] * Math.PI) / 180,
      (currentDef.rotation[2] * Math.PI) / 180
    )
  }
  
  const boxHelper = new THREE.BoxHelper(tempMesh, 0x22c55e)
  scene?.add(boxHelper)
  selectionBoxHelpers[name] = boxHelper
}

const removeBoundingBox = (name: string) => {
  const boxHelper = selectionBoxHelpers[name]
  if (boxHelper) {
    scene?.remove(boxHelper)
    delete selectionBoxHelpers[name]
  }
}

const clearSelection = () => {
  selectedComponentNames.value.forEach(name => {
    setMeshHighlighted(meshByComponentName[name], false)
    removeBoundingBox(name)
  })
  selectedComponentNames.value = []
  updateScaleDisplay()
}

const toggleComponentSelection = (name: string, event?: MouseEvent) => {
  const isCtrlPressed = event?.ctrlKey || event?.metaKey
  
  if (isCtrlPressed) {
    const index = selectedComponentNames.value.indexOf(name)
    if (index === -1) {
      selectedComponentNames.value.push(name)
      setMeshHighlighted(meshByComponentName[name], true)
      addBoundingBox(name)
    } else {
      selectedComponentNames.value.splice(index, 1)
      setMeshHighlighted(meshByComponentName[name], false)
      removeBoundingBox(name)
    }
    updateScaleDisplay()
  } else {
    selectedComponentNames.value.forEach(selectedName => {
      setMeshHighlighted(meshByComponentName[selectedName], false)
      removeBoundingBox(selectedName)
    })
    
    if (selectedComponentNames.value.length === 1 && selectedComponentNames.value[0] === name) {
      selectedComponentNames.value = []
    } else {
      selectedComponentNames.value = [name]
      setMeshHighlighted(meshByComponentName[name], true)
      addBoundingBox(name)
    }
    updateScaleDisplay()
  }
}

const moveSelected = (direction: string) => {
  if (selectedComponentNames.value.length === 0) return
  
  const step = moveStep.value
  
  selectedComponentNames.value.forEach(name => {
    const mesh = meshByComponentName[name]
    const def = objectDefinitions[name]
    
    if (mesh) {
      // 有 mesh 的对象，直接移动
      switch (direction) {
        case '+x': mesh.position.x += step; break
        case '-x': mesh.position.x -= step; break
        case '+y': mesh.position.y += step; break
        case '-y': mesh.position.y -= step; break
        case '+z': mesh.position.z += step; break
        case '-z': mesh.position.z -= step; break
      }
    } else if (def && (def.type === 'subtract' || def.shape)) {
      // subtract 对象，更新相对父对象的局部坐标
      switch (direction) {
        case '+x': def.position[0] += step; break
        case '-x': def.position[0] -= step; break
        case '+y': def.position[1] += step; break
        case '-y': def.position[1] -= step; break
        case '+z': def.position[2] += step; break
        case '-z': def.position[2] -= step; break
      }
    }
    
    // 标记为已移动
    movedObjects.add(name)
  })
  
  // 更新包围盒
  selectedComponentNames.value.forEach(name => {
    const boxHelper = selectionBoxHelpers[name]
    if (boxHelper) {
      boxHelper.update()
    }
  })
  
  
}

const scaleSelected = (direction: string) => {
  if (selectedComponentNames.value.length === 0) return
  
  const step = scaleStep.value
  const sign = direction.startsWith('+') ? 1 : -1
  const axis = direction.slice(1) as 'x' | 'y' | 'z'
  
  selectedComponentNames.value.forEach(name => {
    const mesh = meshByComponentName[name]
    if (!mesh) return
    
    const newVal = THREE.MathUtils.clamp(mesh.scale[axis] + sign * step, 0.01, 100)
    mesh.scale[axis] = newVal
    
    const def = objectDefinitions[name]
    if (def) {
      if (def.type === 'cylinder' && def.radius !== undefined) {
        const origRadius = originalSizes[name]?.[0] ?? def.radius
        if (axis === 'x' || axis === 'y') {
          def.radius = origRadius * newVal
        }
        if (def.height !== undefined && axis === 'z') {
          const origHeight = (originalSizes[name] as [number])?.[1] ?? def.height
          def.height = origHeight * newVal
        }
      } else if (def.size) {
        const origSize = (originalSizes[name] as [number, number, number]) ?? [...def.size]
        const idx = axis === 'x' ? 0 : axis === 'y' ? 1 : 2
        def.size[idx] = origSize[idx] * newVal
      }
    }
    
    // 更新包围盒
    const boxHelper = selectionBoxHelpers[name]
    if (boxHelper) {
      boxHelper.update()
    }
  })
  
  updateScaleDisplay()
}

// 删除选中的组件
const deleteSelected = () => {
  if (selectedComponentNames.value.length === 0) return
  
  // 收集所有要删除的名称（包括子对象）
  const namesToDelete = new Set<string>()
  
  selectedComponentNames.value.forEach(name => {
    namesToDelete.add(name)
    
    // 如果删除的是父对象，也删除其所有 subtract 子对象
    if (cachedJSON) {
      cachedJSON.objects.forEach((obj: any) => {
        if (obj.type === 'subtract' && obj.parent === name) {
          if (obj.name) {
            namesToDelete.add(obj.name)
          }
        }
      })
    }
  })
  
  // 添加到删除集合
  namesToDelete.forEach(name => {
    deletedComponentNames.value.add(name)
  })
  
  // 清除选择
  clearSelection()
  
  // 重建场景
  rebuildScene()
}

const isGlassObjectName = (name?: string) => {
  if (!name) return false
  return /(side_window|glass|windshield)/i.test(name) && !/^seat_/i.test(name)
}

const keyState: Record<'KeyW' | 'KeyA' | 'KeyS' | 'KeyD' | 'ArrowUp' | 'ArrowDown', boolean> = {
  KeyW: false,
  KeyA: false,
  KeyS: false,
  KeyD: false,
  ArrowUp: false,
  ArrowDown: false,
}

const onKeyDown = (event: KeyboardEvent) => {
  if (event.code in keyState) {
    keyState[event.code as keyof typeof keyState] = true
  }
  
  // 处理 Delete 键
  if (event.code === 'Delete' || event.code === 'Backspace') {
    // 防止在输入框中按删除键时触发
    const target = event.target as HTMLElement
    if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable) {
      return
    }
    
    if (selectedComponentNames.value.length > 0) {
      event.preventDefault()
      deleteSelected()
    }
  }
}

const onKeyUp = (event: KeyboardEvent) => {
  if (event.code in keyState) {
    keyState[event.code as keyof typeof keyState] = false
  }
}

// 双击选择场景中的物体
const onMouseDown = (event: MouseEvent) => {
  if (!container.value || !camera) return
  
  // 计算鼠标位置
  const rect = container.value.getBoundingClientRect()
  mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1
  mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1
  
  // 从相机发射射线
  raycaster.setFromCamera(mouse, camera)
  
  // 获取所有可选择的物体
  const selectableObjects: THREE.Object3D[] = []
  Object.values(meshByComponentName).forEach(obj => {
    selectableObjects.push(obj)
  })
  
  // 检测射线与物体的交点
  const intersects = raycaster.intersectObjects(selectableObjects, true)
  
  if (intersects.length > 0) {
    // 找到被点击的最顶层对象
    let clickedObject: THREE.Object3D | null = null
    
    for (const intersect of intersects) {
      let obj = intersect.object
      // 向上查找有名字的对象
      while (obj) {
        if (obj.name && meshByComponentName[obj.name]) {
          clickedObject = obj
          break
        }
        obj = obj.parent as THREE.Object3D
      }
      if (clickedObject) break
    }
    
    if (clickedObject && clickedObject.name) {
      const currentTime = Date.now()
      
      // 检测是否是双击（两次点击间隔小于300ms且点击同一物体）
      if (currentTime - lastClickTime < 300 && lastClickObject === clickedObject) {
        // 双击事件
        const syntheticEvent = new MouseEvent('dblclick', {
          ctrlKey: event.ctrlKey || event.metaKey,
          metaKey: event.metaKey
        })
        
        const clickedName = clickedObject.name
        
        // 找到基础对象名称和相关对象
        let baseName = clickedName
        const relatedNames: string[] = []
        
        // 如果点击的是 _cut 对象，找到基础对象名称
        if (clickedName.endsWith('_cut')) {
          baseName = clickedName.replace(/_cut$/, '')
          relatedNames.push(baseName) // 添加基础对象
          relatedNames.push(clickedName) // 添加当前 _cut 对象
          
          // 查找同名的所有 _cut 变体（如 _arch, 普通 _cut 等）
          if (cachedJSON) {
            cachedJSON.objects.forEach((obj: any) => {
              if (obj.type === 'subtract' && obj.parent === baseName) {
                if (obj.name && !relatedNames.includes(obj.name)) {
                  relatedNames.push(obj.name)
                }
              }
            })
          }
        } else {
          // 点击的是基础对象
          relatedNames.push(clickedName) // 添加基础对象
          
          // 查找所有关联的 subtract 对象
          if (cachedJSON) {
            cachedJSON.objects.forEach((obj: any) => {
              if (obj.type === 'subtract' && obj.parent === clickedName) {
                if (obj.name && !relatedNames.includes(obj.name)) {
                  relatedNames.push(obj.name)
                }
              }
              // 也查找以 baseName_ 开头的对象
              if (obj.name && obj.name.startsWith(clickedName + '_') && !relatedNames.includes(obj.name)) {
                relatedNames.push(obj.name)
              }
            })
          }
        }
        
        // 过滤掉不存在的对象
        const validRelatedNames = relatedNames.filter(name => 
          name && name !== '' && objectDefinitions[name] && !deletedComponentNames.value.has(name)
        )
        
        // 确保至少包含原对象
        if (!validRelatedNames.includes(clickedName) && !deletedComponentNames.value.has(clickedName)) {
          validRelatedNames.unshift(clickedName)
        }
        
        // 处理选择逻辑（支持 Ctrl 多选）
        if (syntheticEvent.ctrlKey || syntheticEvent.metaKey) {
          // Ctrl + 双击：添加选择
          validRelatedNames.forEach(name => {
            if (!selectedComponentNames.value.includes(name)) {
              selectedComponentNames.value.push(name)
              setMeshHighlighted(meshByComponentName[name], true)
              addBoundingBox(name)
            }
          })
        } else {
          // 普通双击：替换选择
          // 清除所有已选中的高亮
          selectedComponentNames.value.forEach(selectedName => {
            setMeshHighlighted(meshByComponentName[selectedName], false)
            removeBoundingBox(selectedName)
          })
          
          // 选中所有相关对象
          selectedComponentNames.value = []
          validRelatedNames.forEach(name => {
            if (objectDefinitions[name] && !deletedComponentNames.value.has(name)) {
              selectedComponentNames.value.push(name)
              setMeshHighlighted(meshByComponentName[name], true)
              addBoundingBox(name)
            }
          })
        }
        
        updateScaleDisplay()
        
        // 滚动到第一个组件
        if (selectedComponentNames.value.length > 0) {
          scrollToComponent(selectedComponentNames.value[0])
        }
        
        // 重置
        lastClickTime = 0
        lastClickObject = null
      } else {
        // 第一次点击，记录
        lastClickTime = currentTime
        lastClickObject = clickedObject
      }
    } else {
      // 点击了物体但没有名字，重置
      lastClickTime = 0
      lastClickObject = null
    }
  } else {
    // 点击空白区域，重置
    lastClickTime = 0
    lastClickObject = null
  }
}

// 滚动到对应的组件
const scrollToComponent = (name: string) => {
  // 找到对应的组件元素并滚动到可见位置
  setTimeout(() => {
    const chipElements = document.querySelectorAll('.component-chip')
    chipElements.forEach((el) => {
      const chipName = el.querySelector('.chip-name')?.textContent
      if (chipName === name) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' })
      }
    })
  }, 100)
}

const getLocalMatrix = (obj: any) => {
  const matrix = new THREE.Matrix4()
  matrix.identity()

  if (obj.rotation) {
    const euler = new THREE.Euler(
      (obj.rotation[0] * Math.PI) / 180,
      (obj.rotation[1] * Math.PI) / 180,
      (obj.rotation[2] * Math.PI) / 180
    )
    const quat = new THREE.Quaternion()
    quat.setFromEuler(euler)
    const rotMatrix = new THREE.Matrix4()
    rotMatrix.makeRotationFromQuaternion(quat)
    matrix.multiply(rotMatrix)
  }

  if (obj.position) {
    matrix.setPosition(obj.position[0], obj.position[1], obj.position[2])
  }

  return matrix
}

const makeMaterial = (obj: any) => {
  const color = new THREE.Color(
    obj.color ? obj.color[0] : 0.8,
    obj.color ? obj.color[1] : 0.8,
    obj.color ? obj.color[2] : 0.8
  )
  const opacity = obj.opacity ?? 1
  const transparent = opacity < 1
  const isWindow = isGlassObjectName(obj.name)

  if (isWindow) {
    return new THREE.MeshPhysicalMaterial({
      color,
      transparent: true,
      opacity: opacity < 1 ? opacity : 0.35,
      transmission: 0.9,
      roughness: 0.08,
      metalness: 0,
      thickness: 0.02,
      attenuationColor: color,
      attenuationDistance: 0.7,
      side: THREE.DoubleSide,
      depthTest: true,
      depthWrite: false,
    })
  }

  const material = new THREE.MeshStandardMaterial({
    color,
    metalness: 0.1,
    roughness: 0.8,
    transparent,
    opacity,
    side: THREE.DoubleSide,
    depthTest: true,
    depthWrite: transparent ? false : true,
    alphaTest: transparent ? 0 : 0,
  })

  return material
}

const createRulerAxis = (
  length: number,
  direction: THREE.Vector3,
  color: number,
  majorTickSpacing: number,
  minorTickSpacing: number,
  majorTickSize: number,
  minorTickSize: number
) => {
  const points: THREE.Vector3[] = []
  const axisEnd = direction.clone().multiplyScalar(length)
  points.push(new THREE.Vector3(0, 0, 0), axisEnd)

  for (let pos = 0; pos <= length + 0.0001; pos += minorTickSpacing) {
    const tickCenter = direction.clone().multiplyScalar(pos)
    const tickOffset = new THREE.Vector3()
    const isMajor = Math.abs(pos % majorTickSpacing) < 0.0001
    const size = isMajor ? majorTickSize : minorTickSize

    if (Math.abs(direction.x) > 0) tickOffset.set(0, size, 0)
    else if (Math.abs(direction.y) > 0) tickOffset.set(size, 0, 0)
    else tickOffset.set(size, 0, 0)

    points.push(tickCenter.clone().sub(tickOffset))
    points.push(tickCenter.clone().add(tickOffset))
  }

  const geometry = new THREE.BufferGeometry().setFromPoints(points)
  const material = new THREE.LineBasicMaterial({
    color,
    transparent: true,
    opacity: 0.2,
    depthTest: true,
  })
  const line = new THREE.LineSegments(geometry, material)

  const group = new THREE.Group()
  group.add(line)
  return group
}

const updateCameraByKeyboard = () => {
  if (!camera || !controls) return

  const speed = 0.1
  const worldUp = new THREE.Vector3(0, 1, 0)
  const forward = new THREE.Vector3()
  camera.getWorldDirection(forward)
  forward.y = 0
  if (forward.lengthSq() < 1e-8) {
    forward.set(0, 0, -1)
  } else {
    forward.normalize()
  }
  const right = new THREE.Vector3().crossVectors(forward, worldUp).normalize()
  const move = new THREE.Vector3()

  if (keyState.KeyW || keyState.ArrowUp) {
    move.add(forward)
  }
  if (keyState.KeyS || keyState.ArrowDown) {
    move.sub(forward)
  }
  if (keyState.KeyA) {
    move.sub(right)
  }
  if (keyState.KeyD) {
    move.add(right)
  }

  if (move.lengthSq() > 0) {
    move.normalize().multiplyScalar(speed)
    camera.position.add(move)
    controls.target.add(move)
  }
}

const resize = () => {
  if (!container.value || !renderer || !camera) return
  const width = container.value.clientWidth
  const height = container.value.clientHeight
  camera.aspect = width / height
  camera.updateProjectionMatrix()
  renderer.setSize(width, height)
}

const animate = () => {
  if (!renderer || !scene || !camera || !controls) return
  updateCameraByKeyboard()
  controls.update()
  renderer.render(scene, camera)
  animationId = requestAnimationFrame(animate)
}

// 从场景中清理所有网格体（保留辅助对象如网格、坐标轴等）
const clearSceneMeshes = () => {
  if (!scene) return
  
  const objectsToRemove: THREE.Object3D[] = []
  scene.traverse((child) => {
    if (child instanceof Brush || 
        (child instanceof THREE.Mesh && !(child instanceof THREE.GridHelper) && 
         !(child instanceof THREE.AxesHelper))) {
      objectsToRemove.push(child)
    } else if (child instanceof THREE.Group && child.children.length > 0) {
      const hasLine = child.children.some(c => c instanceof THREE.LineSegments)
      if (!hasLine) {
        objectsToRemove.push(child)
      }
    }
  })
  
  objectsToRemove.forEach(obj => {
    scene?.remove(obj)
  })
  
  // 清理所有 box helpers
  Object.keys(selectionBoxHelpers).forEach(key => {
    const boxHelper = selectionBoxHelpers[key]
    if (boxHelper && scene) {
      scene.remove(boxHelper)
    }
    delete selectionBoxHelpers[key]
  })
}

// 使用指定数据构建场景
const buildSceneFromData = (data: { objects: any[] }) => {
  if (!scene) return
  
  // 清理场景
  clearSceneMeshes()
  
  // 清理数据结构
  Object.keys(objectDefinitions).forEach(key => delete objectDefinitions[key])
  Object.keys(meshByComponentName).forEach(key => delete meshByComponentName[key])
  Object.keys(originalSizes).forEach(key => delete originalSizes[key])
  movedObjects.clear()
  selectedComponentNames.value = []
  updateScaleDisplay()
  
  // 初始化对象定义（过滤已删除的对象）
  data.objects.forEach((obj: any) => {
    if (obj.name && !deletedComponentNames.value.has(obj.name)) {
      objectDefinitions[obj.name] = JSON.parse(JSON.stringify(obj))
    }
  })
  
  // 初始化原始尺寸
  data.objects.forEach((obj: any) => {
    if (!obj.name || deletedComponentNames.value.has(obj.name)) return
    if (obj.type === 'cylinder') {
      originalSizes[obj.name] = [obj.radius, obj.height]
    } else if (obj.size) {
      originalSizes[obj.name] = [...obj.size] as [number, number, number]
    }
  })
  
  // 分类对象
  const evaluator = new Evaluator()
  const baseObjects: any[] = []
  const subtractOps: { [parent: string]: any[] } = {}
  const decorativeObjects: any[] = []
  
  data.objects.forEach((obj: any) => {
    if (!obj.name || deletedComponentNames.value.has(obj.name)) return
    
    if (obj.type === 'subtract') {
      // 检查父对象是否已被删除
      if (deletedComponentNames.value.has(obj.parent)) return
      
      if (!subtractOps[obj.parent]) {
        subtractOps[obj.parent] = []
      }
      subtractOps[obj.parent].push(obj)
    } else if (HIDE_WINDOW_MESHES && isGlassObjectName(obj.name)) {
      return
    } else if (isGlassObjectName(obj.name) || (obj.opacity !== undefined && obj.opacity < 1 && (obj.type === 'box' || obj.type === 'cylinder'))) {
      decorativeObjects.push(obj)
    } else if (obj.type === 'box' || obj.type === 'cylinder') {
      baseObjects.push(obj)
    }
  })
  
  const getMatrixForObject = (obj: any) => {
    return getWorldMatrix(obj)
  }
  
  // 构建基础对象（包含 CSG 减法）
  baseObjects.forEach((obj: any) => {
    let geom: THREE.BufferGeometry
    const material = makeMaterial(obj)

    if (obj.type === 'box') {
      geom = new THREE.BoxGeometry(obj.size[0], obj.size[1], obj.size[2])
    } else if (obj.type === 'cylinder') {
      geom = new THREE.CylinderGeometry(obj.radius, obj.radius, obj.height, 32)
    } else {
      return
    }

    const matrix = getMatrixForObject(obj)
    geom.applyMatrix4(matrix)

    let result = new Brush(geom, material)

    if (subtractOps[obj.name]) {
      subtractOps[obj.name].forEach((sub: any) => {
        let subGeom: THREE.BufferGeometry
        if (sub.shape === 'box') {
          subGeom = new THREE.BoxGeometry(sub.size[0], sub.size[1], sub.size[2])
        } else if (sub.shape === 'cylinder') {
          subGeom = new THREE.CylinderGeometry(sub.radius, sub.radius, sub.height, 32)
        } else {
          return
        }

        const subMatrix = getMatrixForObject(sub)
        subGeom.applyMatrix4(subMatrix)

        const subBrush = new Brush(
          subGeom,
          new THREE.MeshStandardMaterial({
            depthTest: true,
          })
        )
        result = evaluator.evaluate(result, subBrush, SUBTRACTION)
      })
    }

    scene?.add(result)
    result.renderOrder = 0
    if (obj.name) {
      result.name = obj.name
      meshByComponentName[obj.name] = result
    }
  })
  
  // 构建装饰对象
  decorativeObjects.forEach((obj: any) => {
    let geom: THREE.BufferGeometry
    const material = makeMaterial(obj)

    if (obj.type === 'box') {
      geom = new THREE.BoxGeometry(obj.size[0], obj.size[1], obj.size[2])
    } else if (obj.type === 'cylinder') {
      geom = new THREE.CylinderGeometry(obj.radius, obj.radius, obj.height, 32)
    } else {
      return
    }

    const matrix = getMatrixForObject(obj)
    geom.applyMatrix4(matrix)

    const mesh = new THREE.Mesh(geom, material)
    mesh.renderOrder = obj.opacity !== undefined && obj.opacity < 1 ? 2 : 1
    if (obj.name) {
      mesh.name = obj.name
      meshByComponentName[obj.name] = mesh
    }
    scene?.add(mesh)
  })
}

// 重建场景 - 使用 exportJSON 的数据
const rebuildScene = () => {
  const exportData = getExportData()
  
  if (!exportData) {
    exportMessage.value = '❌ No data to rebuild from'
    if (exportTimeout) clearTimeout(exportTimeout)
    exportTimeout = setTimeout(() => { exportMessage.value = '' }, 3000)
    return
  }
  cachedJSON = exportData
  isLoading.value = true
  
  try {
    // 使用导出数据重建场景
    buildSceneFromData(cachedJSON)
    
    exportMessage.value = '✅ Scene rebuilt'
  } catch (error) {
    console.error('Failed to rebuild scene:', error)
    exportMessage.value = '❌ Failed to rebuild scene'
  } finally {
    isLoading.value = false
    if (exportTimeout) clearTimeout(exportTimeout)
    exportTimeout = setTimeout(() => { exportMessage.value = '' }, 3000)
  }
}

onMounted(async () => {
  if (!container.value) return

  const width = container.value.clientWidth
  const height = container.value.clientHeight

  scene = new THREE.Scene()
  scene.background = new THREE.Color(0x111827)

  camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000)
  camera.position.set(18, 12, 28)

  renderer = new THREE.WebGLRenderer({ antialias: true })
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
  renderer.setSize(width, height)
  renderer.sortObjects = true
  container.value.appendChild(renderer.domElement)

  const ambientLight = new THREE.AmbientLight(0xffffff, 0.6)
  scene.add(ambientLight)

  const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8)
  directionalLight.position.set(5, 10, 7.5)
  scene.add(directionalLight)

  // 添加辅助对象（这些不会被重建清除）
  const grid = new THREE.GridHelper(220, 22, 0x444444, 0x222222)
  scene.add(grid)

  const meterAxis = createRulerAxis(12, new THREE.Vector3(1, 0, 0), 0xff0000, 1, 0.1, 0.4, 0.15)
  meterAxis.position.set(0, 0.01, 0)
  scene.add(meterAxis)

  const yAxis = createRulerAxis(12, new THREE.Vector3(0, 1, 0), 0x00ff00, 1, 0.1, 0.4, 0.15)
  yAxis.position.set(0, 0.01, 0)
  scene.add(yAxis)

  const zAxis = createRulerAxis(12, new THREE.Vector3(0, 0, 1), 0x0000ff, 1, 0.1, 0.4, 0.15)
  zAxis.position.set(0, 0.01, 0)
  scene.add(zAxis)

  const axes = new THREE.AxesHelper(5)
  scene.add(axes)

  // 加载初始数据
  try {
    const response = await fetch('/bus.json')
    const data = await response.json()

    cachedJSON = { objects: (data.objects ?? []).map((obj: any) => ({ ...obj })) }

    componentList.value = (data.objects ?? []).map((obj: any, index: number) => ({
      name: obj.name ?? `unnamed_${index}`,
      type: obj.type ?? 'unknown',
      parent: obj.parent,
    }))

    // 使用原始数据构建初始场景
    if (cachedJSON) {
      buildSceneFromData(cachedJSON)
    }
  } catch (error) {
    console.error('Failed to load bus.json:', error)
  }

  controls = new OrbitControls(camera!, renderer!.domElement)
  controls.enableDamping = true

  window.addEventListener('resize', resize)
  window.addEventListener('keydown', onKeyDown)
  window.addEventListener('keyup', onKeyUp)
  
  // 添加双击选择事件
  if (container.value) {
    container.value.addEventListener('mousedown', onMouseDown)
  }
  
  animate()
})

onBeforeUnmount(() => {
  if (animationId) cancelAnimationFrame(animationId)
  window.removeEventListener('resize', resize)
  window.removeEventListener('keydown', onKeyDown)
  window.removeEventListener('keyup', onKeyUp)
  
  // 移除双击选择事件
  if (container.value) {
    container.value.removeEventListener('mousedown', onMouseDown)
  }

  // 清理所有包围盒
  Object.keys(selectionBoxHelpers).forEach(key => {
    const boxHelper = selectionBoxHelpers[key]
    if (boxHelper && scene) {
      scene.remove(boxHelper)
    }
    delete selectionBoxHelpers[key]
  })

  if (renderer && renderer.domElement.parentNode) {
    renderer.domElement.parentNode.removeChild(renderer.domElement)
  }

  renderer = null
  scene = null
  camera = null
  controls = null
})
</script>

<style scoped>
.scene-root {
  width: 100%;
  min-height: 100vh;
  position: relative;
  overflow: hidden;
}

.panels-wrapper {
  position: fixed;
  left: 0;
  top: 0;
  bottom: 0;
  display: flex;
  z-index: 20;
}

.component-panel {
  width: 280px;
  background: #0f172a;
  color: #e2e8f0;
  padding: 12px;
  box-sizing: border-box;
  overflow-y: auto;
  height: 100%;
}

/* 左侧第一列：组件列表 */
.left-panel {
  border-right: 1px solid #1e293b;
}

/* 左侧第二列：变换控制 */
.transform-panel {
  width: 240px;
  border-right: 1px solid #1e293b;
}

.panel-title {
  font-size: 16px;
  font-weight: 700;
  margin-bottom: 8px;
}

.panel-count {
  margin-top: 4px;
  margin-bottom: 10px;
  color: #94a3b8;
  font-size: 12px;
}

.selected-count {
  color: #22c55e;
  font-weight: 600;
}

.filter-box {
  position: relative;
  margin-bottom: 10px;
}

.filter-input {
  width: 100%;
  padding: 8px 32px 8px 10px;
  border-radius: 6px;
  border: 1px solid #1f2937;
  background: #111827;
  color: #e2e8f0;
  font-size: 13px;
  outline: none;
  box-sizing: border-box;
  transition: border-color 0.15s ease;
}

.filter-input:focus {
  border-color: #22c55e;
}

.filter-input::placeholder {
  color: #64748b;
}

.filter-clear {
  position: absolute;
  right: 6px;
  top: 50%;
  transform: translateY(-50%);
  background: none;
  border: none;
  color: #94a3b8;
  cursor: pointer;
  font-size: 14px;
  padding: 2px 6px;
  border-radius: 3px;
  transition: color 0.15s ease, background-color 0.15s ease;
}

.filter-clear:hover {
  color: #e2e8f0;
  background: #1e293b;
}

.rebuild-section {
  margin-bottom: 10px;
}

.rebuild-btn {
  width: 100%;
  padding: 10px 0;
  border-radius: 6px;
  border: 1px solid #3b82f6;
  background: #0a1a3a;
  color: #3b82f6;
  cursor: pointer;
  font-size: 14px;
  font-weight: 600;
  transition: background-color 0.3s ease, border-color 0.3s ease, opacity 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
}

.rebuild-btn:hover {
  background: #0d1f4a;
  border-color: #60a5fa;
  color: #60a5fa;
}

.rebuild-btn:active {
  background: #071430;
  transform: scale(0.98);
}

.rebuild-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  background: #1a1a2e;
  border-color: #334155;
  color: #64748b;
  transform: none;
}

.action-buttons {
  margin-bottom: 10px;
}

.delete-selection-btn {
  width: 100%;
  padding: 8px 0;
  border-radius: 6px;
  border: 1px solid #f59e0b;
  background: #1a140a;
  color: #f59e0b;
  cursor: pointer;
  font-size: 14px;
  font-weight: 600;
  margin-bottom: 8px;
  transition: background-color 0.15s ease;
}

.delete-selection-btn:hover {
  background: #2d1f0a;
}

.clear-selection-btn {
  width: 100%;
  padding: 8px 0;
  border-radius: 6px;
  border: 1px solid #ef4444;
  background: #1a0f0f;
  color: #ef4444;
  cursor: pointer;
  font-size: 14px;
  font-weight: 600;
  margin-bottom: 8px;
  transition: background-color 0.15s ease;
}

.clear-selection-btn:hover {
  background: #2d1515;
}

.export-btn {
  width: 100%;
  padding: 8px 0;
  border-radius: 6px;
  border: 1px solid #22c55e;
  background: #052e16;
  color: #22c55e;
  cursor: pointer;
  font-size: 14px;
  font-weight: 600;
  transition: background-color 0.15s ease;
}

.export-btn:hover {
  background: #064e1b;
}

.export-msg {
  margin-top: 6px;
  font-size: 12px;
  color: #22c55e;
  text-align: center;
}

.component-flow {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.component-chip {
  background: #111827;
  border: 1px solid #1f2937;
  border-radius: 6px;
  padding: 8px;
  display: flex;
  flex-direction: column;
  gap: 2px;
  max-width: 100%;
  cursor: pointer;
  transition: border-color 0.15s ease, background-color 0.15s ease;
}

.component-chip.selected {
  border-color: #22c55e;
  background: #052e16;
}

.component-chip.deleted {
  opacity: 0.3;
  text-decoration: line-through;
}

.chip-name {
  font-size: 13px;
  font-weight: 600;
  word-break: break-word;
}

.chip-type,
.chip-parent {
  font-size: 11px;
  color: #94a3b8;
  word-break: break-word;
}

/* 变换面板样式 */
.transform-section {
  display: flex;
  flex-direction: column;
  gap: 0;
}

.transform-group {
  margin-bottom: 4px;
}

.transform-group-title {
  font-size: 14px;
  font-weight: 700;
  color: #22c55e;
  margin-bottom: 8px;
  padding-bottom: 4px;
  border-bottom: 1px solid #1e293b;
}

.transform-title-info {
  font-size: 12px;
  color: #94a3b8;
  margin-bottom: 10px;
  word-break: break-word;
}

.transform-scale-display {
  font-size: 16px;
  font-weight: 600;
  color: #e2e8f0;
  margin-bottom: 10px;
  padding: 4px 8px;
  background: #1a1a2e;
  border-radius: 4px;
  text-align: center;
}

.transform-row {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 6px;
}

.axis-label {
  width: 20px;
  text-align: center;
  font-size: 13px;
  font-weight: 700;
  color: #64748b;
}

.axis-x {
  color: #ef4444;
}

.axis-y {
  color: #22c55e;
}

.axis-z {
  color: #3b82f6;
}

.dir-btn {
  flex: 1;
  padding: 6px 0;
  border-radius: 4px;
  border: 1px solid #1f2937;
  background: #0f172a;
  color: #e2e8f0;
  cursor: pointer;
  font-size: 13px;
  font-weight: 600;
  transition: background-color 0.15s ease, border-color 0.15s ease;
}

.dir-btn:hover {
  background: #1e293b;
  border-color: #22c55e;
}

.transform-step {
  margin-top: 8px;
  font-size: 12px;
  color: #94a3b8;
}

.step-select {
  margin-left: 4px;
  padding: 2px 4px;
  border-radius: 4px;
  border: 1px solid #1f2937;
  background: #0f172a;
  color: #e2e8f0;
  font-size: 12px;
  outline: none;
}

.transform-divider {
  height: 1px;
  background: #1e293b;
  margin: 12px 0;
}

.canvas-container {
  width: 100%;
  min-height: 100vh;
  overflow: hidden;
}

/* 响应式布局 */
@media (max-width: 1100px) {
  .transform-panel {
    display: none;
  }
  
  .left-panel {
    width: 260px;
  }
}
</style>