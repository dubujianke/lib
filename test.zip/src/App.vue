<template>
  <ThreeScene />
</template>

<script setup lang="ts">
// import ThreeScene from './components/ThreeScene.vue'
// import ThreeScene from './components/terrian.vue'
import ThreeScene from './components/house.vue'
</script>