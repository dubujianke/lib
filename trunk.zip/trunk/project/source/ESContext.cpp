//build:http://blog.csdn.net/langresser_king/article/details/8275291
//opengl api  https://www.khronos.org/registry/OpenGL-Refpages/
//sound https://www.aigei.com/view/13122-5977153.html
//fileSystem = "d:\\assets.zip"; for test android
//ptr should be null check

//print crash log
//adb logcat | E:\android-ndk-r10\ndk-stack -sym D:\myprojectxx\trunk\dsa\obj\local\armeabi
#include "ESContext.h"
#include "SpecialUtil.h"
#include "gfx.h"
#include "MKOBJSprite.h"
#include "MKSprite.h"
#include "memory.h"
#include "texture.h"
#include "MKConfig.h"
#include "MKTerrain.h"
#include "MKWall.h"
#include "json/json.h"
#include "RoundCreateDynamicObj.h"
#include "OgreRay.h"
#include "ui/MKFontManager.h"
#include "MKTest.h"
#include "particle/Matrix3.h"
#include "particle/Matrix2.h"
#include "particle/Matrix4.h"
#include "utils.h"
#include "LineParse.h"
#include "MK3DRect.h"
#include "BrushButtonListener.h"
#include "engine\LetterParser.h"
#include "ui/MKFontManager.h"
#include "mk/MKCaculator.h"
#include "ui/MKCombox.h"
#include "ui/MKEditorText.h"
#include "ViewManager.h"
#include "AxisAlignedBox.h"
#include "particle/Matrix4.h"
#include "cUnpackFile.h"
#include "Log.h"
#include "Addr.h"
#include "MKClickListener.h"
#include "MKMouseDownListener.h"
#include "business/WalkListener.h"
#include "business/WalkMouseDownListener.h"
#include "Scene.h"
#include "business/ChooseLocationListener.h"
#include "business/ListChooseLocationListener.h"
#include "business/MenuFileChooseListener.h"
#include "business/BtnListener.h"
#include "ui/MKContentChangeListener.h"
#include "business/WindowLisener.h"
#include "HStringConverter.h"
#include "UTF8.h"

#include "UnicodeString.h"
#include "PropertyConfig.h"
#include "MKCube.h"
#include "particle/ParticleManager.h"
#include "particle/MKMath.h"
#include "business/TributeListener.h"
#include "MyVector.h"
#include "SpriteInitThread.h"
#include <assert.h>
#include "sss/SSSGrid.h"
#include "ui/CursorManager.h"
#include "ui/MKContentChangeListener.h"
#include "Perspective.h"
#include "net/MKHttpClient.h"
#include "ui/MyActivity.h"
#include "particle/ParticleUniverseDynamicAttribute.h"
#include "SceneLoadListener.h"
#include "ui/MKLabel.h"
#include "SpriteManager.h"
#include "LuaThread.h"
#include "particle/ParticleUniverseDynamicAttribute.h"
#include "ui/MKProgressbar.h"
#include "LUAContext.h"
#include "MKBean.h"
#include "ObjMergeManager.h"
#include "MKPng.h"
#include "MKFBODepthTexture.h"
#include "MKFBOColorTexture.h"
#include "tiffio.h"
#include "MKThreadLocal.h"
#include "mk/MKLuaBean.h"
#include "FreeImage.h"
#include <regex>
#include "ActionStateEngine.h"
#include "mymd5.h"
#include "MKJson.h"
#include "SpriteMap.h"
#include "mk/MKMutex.h"
//#include "mpg123.h"
#include "ObjMergeManager.h"
#include "MKClass.h"
#include "2d/LayerManager.h"
//#include "2d/MK2DSprite.h"
//#include "2d/Costume.h"
#include "Mp3Play.h"
#include <cmath>
#include "2d/Sprite2DMap.h"
#include "mk/SyncVector.h"
#include "curl/curl.h"
#include "MKFbo.h"
#include "Texture2dApp.h"
#include "harmonics.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <array>
//#include "canvas/Canvas.h"

glm::u32 i = 0;

//template<typename T>
//using object_pointer_type = T*;
//template<typename T, typename... Args>
//static object_pointer_type<T> create(Args&&... args)
//{
//	return new T(std::forward<Args>(args)...);
//}


std::string CoefficientsString(const std::vector<glm::vec3>& vCoefs)
{
	ostringstream oss;
	for (int i=0; i<vCoefs.size(); i++)
	{
		const glm::vec3& c = vCoefs[i];
		oss << c.r << "\t" << c.g << "\t" << c.b << std::endl;
	}
	return oss.str();
}


//////////////////////////////////////////////////
//2D
//#include "2d/Sprite2DMap.h"
///////////////////////////////////////////////////////////
//#include <noise.h>
//#include "noiseutils.h"
//.using namespace noise;
#define lecture1 1
#define lecture2 0

#define drawFbxFlag
#define drawSkyFlag
#define drawUIFlag
#define draw2DFlag
/************************************************************************/
/* Scene load process
   setUserData
   InitResource
   1.1InitUI
   1.2Init3D
   1.3InitMoon:use userdata
   SceneLoad Listener:use user data
*/
/************************************************************************/
#ifdef WIN32

#else
#include <iconv.h>
#endif


extern "C"{
#include "jpeglib.h"
};

using namespace mk;


size_t DownloadCallback(void* pBuffer, size_t nSize, size_t nMemByte, void* pParam)  
{  
	FILE* fp = (FILE*)pParam;  
	size_t nWrite = fwrite(pBuffer, nSize, nMemByte, fp);  
	return nWrite;  
}  


static size_t OnWriteData2(void* buffer, size_t size, size_t nmemb, void* lpVoid)
{
	std::string* str = dynamic_cast<std::string*>((std::string *)lpVoid);
	if( NULL == str || NULL == buffer )
	{
		return -1;
	}
	char* pData = (char*)buffer;
	str->append(pData, size * nmemb);
	return nmemb;
}
void getMK()
{
	LogUtil::logInfo("https", "get():%s", "https begin");
	const std::string strUrl = "https://jsonplaceholder.typicode.com/posts/1";
	std::string strResponse;
	CURLcode res; 
	CURL* curl = curl_easy_init();
	curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_easy_setopt(curl, CURLOPT_URL, strUrl.c_str());  
	curl_easy_setopt(curl, CURLOPT_READFUNCTION, NULL);
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, OnWriteData2);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&strResponse);
	curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1);
	curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 10000);
	curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10000);
	res = curl_easy_perform(curl);
	if(res != CURLE_OK) {
		LogUtil::logInfo("https", "get:%s", curl_easy_strerror(res));
	}

	curl_easy_cleanup(curl);
	LogUtil::logInfo("https", "get():%s", strResponse.c_str());
}


void get()
{
}

void cubeTest() {

}

void playMp3(string url, string dir, string fileName) {
	//Mp3Play::newInstance(url, dir, fileName)->start();
}

float getAngleFromX(float x, float z) {
	Vector2 dltDir(x, z);
	float distance = dltDir.length();
	dltDir.normalise();

	float angle = Vector2(x, z).getSriteRotateAngle();
	return angle;
}

float getAngle(vec2 a, vec2 b) {
	float a1 = getAngleFromX(a.x, a.y);
	float a2 = getAngleFromX(b.x, b.y);
	return a2-a1;
}


float getAngle2(float x, float z, float x2, float z2) {
	float angle = getAngleFromX(x, z);
	float angle2 = getAngleFromX(x2, z2);
	return angle2- angle;
}


void playMp3UTF(UTF8String url, string dir, string fileName) {
	string urls = url.toUTF8();
	//Mp3Play::newInstance(urls, dir, fileName)->start();
}

void addSetIntPacket(string prsFun, string objId, string propName, int v) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	MKPacketPtr pacetPtr = MKPacket::instance();
	pacetPtr->setProcessFun(prsFun);
	pacetPtr->setInt(propName, v);
	pacetPtr->setObjId(objId);
	ctx->addPacket(pacetPtr);
}

void addSetStringPacket(string prsFun, string objId, string propName, string v) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	MKPacketPtr pacetPtr = MKPacket::instance();
	pacetPtr->setProcessFun(prsFun);
	pacetPtr->setString(propName, v);
	pacetPtr->setObjId(objId);
	ctx->addPacket(pacetPtr);
}

void addSetFloatPacket(string prsFun, string objId, string propName, float v) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	MKPacketPtr pacetPtr = MKPacket::instance();
	pacetPtr->setProcessFun(prsFun);
	pacetPtr->setFloat(propName, v);
	pacetPtr->setObjId(objId);
	ctx->addPacket(pacetPtr);
}

void setUIImage(string id, string path) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	ctx->setUIImage(id, path);
}

void setUIFloat(string id, string prop, float v) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	ctx->setUIFloat(id, prop, v);
}

float getUIFloat(string id, string prop) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	return ctx->getUIFloat(id, prop);
}

void setUIBOOL(string id, string prop, BOOL v) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	ctx->setUIBOOL(id, prop, v);
}

BOOL getUIBOOL(string id, string prop) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	return ctx->getUIBOOL(id, prop);
}

void setUIString(string id, string prop, string v) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	ctx->setUIString(id, prop, v);
}

string getUIString(string id, string prop) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	return ctx->getUIString(id, prop);
}

MKVirtualSprite* toVirtual(MK3DObject* ptr) {
	if(ptr==NULL) {
		return NULL;
	}
	return dynamic_cast<MKVirtualSprite*>(ptr);
}

void testLUA(luabridge::LuaRef aRef) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	LUAContextPtr pLUAContextPtr = ctx->getLUAContext();

	int m = ctx->call1<int, luabridge::LuaRef>("eat", aRef);
	
	luabridge::LuaRef fun = aRef["eat"];
	if (fun.isFunction()) {
		for (int i = 0; i < 1; i++) {
			luabridge::LuaRef ret = fun(aRef, i);
			int m = ret.cast<int>();
		}
		//luabridge::Stack<luabridge::LuaRef>::push(pLUAContextPtr->luaContext, aRef);
		//luabridge::Stack<int>::push(pLUAContextPtr->luaContext, 99);
		//int errNum = lua_pcall(pLUAContextPtr->luaContext, 1, 0, 0);
		
		int a = 0;
	}
	
	//aRef
	
	//aRef["name"] = "A"; 
	/*MKClass* a = dynamic_cast<MKClass*>(aMKRef);
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	ctx->call2<int>("testLUA", 1, 1);*/
}

long getMsTime() {
	struct timeval tv;
	gettimeofday(&tv,NULL);
	long microsecond = tv.tv_sec*1000000+tv.tv_usec;
	return microsecond;
}

long getMiTime() {
	struct timeval tv;
	gettimeofday(&tv,NULL);
	long millisecond = (tv.tv_sec*1000000+tv.tv_usec)/1000;
	return millisecond;
}

BOOL isStopWorld() {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	return ctx->isStop();
}

float getMKFloat(string v) {
	return Costume::getFloat(v);
}

float getDPFloat(int v) {
	string v2 = formatStr("%ddp", v);
	return Costume::getFloat(v2);
}

void stopWorld() {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	ctx->run(FALSE);
}

void resumeWorld() {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	ctx->run(TRUE);
}

void addSprite2DTimer(string id, int endTime, MK2DSprite* data, string begin, string alive, string end, string endNotify, MKLuaBridge* param) {
	LogUtil::logInfo("rot", "addSprite2DTimer begin");
	MKTimerPtr timer = MKTimer::instance();
	timer->id = id;
	if(param && timer->pMKLuaBridgePtr) {
		MKLuaBridge* tMKLuaBridge = timer->pMKLuaBridgePtr.get();
		(*tMKLuaBridge) = *param;
	}
	timer->setEndTime(endTime);
	timer->setEndNotify(endNotify);
	timer->setMK2DSpritePtr(data);
	timer->startSprite2D(begin, alive, end);
	LogUtil::logInfo("rot", "addSprite2DTimer end");
}

void addUITimer(int endTime, MKUINode* data, string alive, string end) {
	MKTimerPtr timer = MKTimer::instance();
	timer->setEndTime(endTime);
	timer->setMKUINodePtr(data);
	timer->start(alive, end);
}

void addUITimerById(int endTime, string id, string alive, string end) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	ctx->addUITimerById(endTime, id, alive, end);
}

void addFbxTimerById(int endTime, string id, string alive, string end) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	ctx->addFbxTimerById(endTime, id, alive, end);
}

MKTimer* addVirtualSpriteTimerById(int endTime, string id, string alive, string end) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	MKTimerPtr ptr = ctx->addVirtualSpriteTimerById(endTime, id, alive, end);
	return ptr;
}


void addActvityTimer(int endTime, Activity* id, string alive, string end) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	ctx->addActvityTimer(endTime, id, alive, end);
}

Activity* getActivity() {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	ActivityPtr ptr =  ctx->getActivity();
	if(ptr==NULL) {
		return NULL;
	}
	return ptr.get();
}

MKUINode* getUINode(string id) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	ActivityPtr ptr =  ctx->getActivity();
	if(ptr==NULL) {
		return NULL;
	}
	MKUINodePtr nodePtr = ptr->getNode(id);
	if(nodePtr==NULL) {
		return NULL;
	}
	return nodePtr.get();
}

MKProgressbar* getProgressBar(string id) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	ActivityPtr ptr =  ctx->getActivity();
	if(ptr==NULL) {
		return NULL;
	}
	MKProgressbarPtr nodePtr = dynamic_pointer_cast<MKProgressbar>(ptr->getNode(id));
	if(nodePtr==NULL) {
		return NULL;
	}
	return nodePtr.get();
}

MKFbxSpriteActionPtr getIdelAction(MKPacketPtr ptr) {
	return ptr;
}

MKFbxSpriteActionPtr getWalkAction(MKPacketPtr ptr) {
	return ptr;
}

MKFbxSpriteActionPtr getAtkAction(MKPacketPtr ptr) {
	return ptr;
}

MKFbxSpriteActionPtr getSetAttrAction(MKPacketPtr ptr) {
	return ptr;
}

MKObj* ESContext::pobj = 0;

ESContext::ESContext(void):
enableEvent(FALSE),
scene2d(""),
frameRate2D(3)
{
	firstTouchDown = FALSE;
	is2DGame = FALSE;
	indx=0;
	mouseState = 0;
	stragety = 0;
	activity = NULL;
	canUnloadScene = FALSE;
	sceneAddr = "";
	isVR = FALSE;
	sceneLoadStatus = 0;
	dltTime=0;
	eglNativeDisplay = 0;
	//isVR = TRUE;
	heroPtr = NULL;

	VB_WIDTH = 1920;
	VB_HEIGHT = 1080;
	gameState = GAME_INIT;
	terriansPtr = NULL;

	collisionconfiguration = NULL;
	dispatcher= NULL;
	broadphase= NULL;
	solver= NULL;
	dynamicsworld= NULL;
	aCameraPtr = NULL;
	pRequestPoolPtr = NULL;
	//myTime.start();
	luaInstance = NULL;
	pLUAPoolList = NULL;
	pMKBulletWorldPtr = NULL;
	initPhysicFlag = FALSE;
	exitFlag = FALSE;
	pLayerManager = NULL;
	actionList.setNOCycle();
}

ESContext::~ESContext(void)
{
	LogUtil::logInfo("ui", "~ESContext");
	MKDELETE(pRequestPoolPtr);
}

void ESContext::addObj(MK3DObjectPtr obj) {
	BOOL isTerrians = MKConfig::instance()->isTerrianProject;
	if(isTerrians) {
		if(objs.size()==0) {
			objs.push_back(obj);
		}else {
			shared_ptr<MKTerrians> spritePtr = dynamic_pointer_cast<MKTerrians>(objs.at(0));
			shared_ptr<MKOBJSprite> objPtr = dynamic_pointer_cast<MKOBJSprite>(obj);
			spritePtr->addChildren(objPtr);
		}
	}else {
		objs.push_back(obj);
	}
}

void ESContext::addFBXObj(MK3DObjectPtr obj) {
	fbxObjs.push_back(obj);
}


void ESContext::addDynamicObj(MK3DObjectPtr obj) {
	dynamicObjs.push_back(obj);
}


Vector3 ESContext::getCameraOrientation() {
	vec3 mPosition = aCameraPtr->getV3Position();
	float orx =  aCameraPtr->centerVec.x - mPosition.x;
	float ory =  aCameraPtr->centerVec.y - mPosition.y;
	float orz =  aCameraPtr->centerVec.z - mPosition.z;
	return Vector3(orx, ory, orz);
}


MKUINodePtr ESContext::destroyUI(string id) {
	ActivityPtr activity = getActivity();
	if(activity!=NULL) {
		return activity->destroyUI(id);
	}
	return NULL;
}

MKUINodePtr ESContext::getUI(string id) {
	ActivityPtr activity = this->getActivity();
	if(activity!=NULL) {
		return activity->getUI(id);
	}
	return NULL;
}

ScenePtr ESContext::getCurrentScene() {
	if(aSpriteInitThread==NULL) {
		return NULL;
	}
	return aSpriteInitThread->CurrentScene();
}

int ESContext::getSceneLoadFinish() {
	ScenePtr aScenePtr= getCurrentScene();
	if(aScenePtr->isSceneLoadEnd()) {
		return 1;
	}
	return 0;
}

void ESContext::printActivity() {

}
void ESContext::setCurActivity(ActivityPtr activity) {
	activityMutex.enter();
	this->activity = activity;
	activityMutex.leave();
	LogUtil::logInfo("ui", "setCurActivity is %s", activity->getName().c_str());
	if(activity==NULL) {
		//LogUtil::logInfo("dialog", "setCurActivity is null");
	}
	/*
	this->activitySync.write(activity);*/
}

ActivityPtr ESContext::getActivity() {
	activityMutex.enter();
	ActivityPtr activity = this->activity;
	activityMutex.leave();
	return activity;
	/*ActivityPtr ptr = this->activitySync.read();
	if(ptr==NULL) {
	LogUtil::logInfo("dialog", "getActivity is null");
	}
	return ptr;*/
}


ActivityPtr ESContext::readActivity() {
	return activity;
	/*ActivityPtr ptr = this->activitySync.read();
	if(ptr==NULL) {
	LogUtil::logInfo("dialog", "getActivity is null");
	}
	return ptr;*/
}

int InitAudioDevice(ESContext *esContext) {
	return 0;
}

void chaHuAction(ESContext *esContext, MKOBJSprite *pMKSprite) {
	
}

/************************************************************************/
/* max shaders:27                                                                     */
/************************************************************************/
int InitPrograme(ESContext *esContext) {
	LogUtil::logInfo("shader", "InitPrograme begin");
	MKConfig::instance()->mkProgrameManager.clear();
	MKConfig::instance()->mkProgrameManager.preLoad("bump", "vobj_bump.shader", "fobj_bump.shader");
	//MKConfig::instance()->mkProgrameManager.preLoad("EasyWater10_C2TDRO", "vobj_bumpwater.shader", "EasyWater10_C2TDRO.shader");	
	MKConfig::instance()->mkProgrameManager.preLoad("sky", "vobj_diffuse.shader", "fobj_diffuse.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("diffuseText", "vobj.shader", "fobj_diffuseText.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("diffuseColor", "vobj.shader", "fobj_diffuseColor.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("default", "vobj.shader", "fobj_blinnphong.shader");	
	MKConfig::instance()->mkProgrameManager.preLoad("lambertText", "vobj_lambert_gl3.shader", "fobj_lambertText.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("lambertGLTF", "vobj_lambert_gltf.shader", "fobj_lambertText.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("lambertGLTFSkin", "vobj_lambert_gltf_skin.shader", "fobj_lambertText_skin.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("lambertGLTFSkinDlod", "vobj_lambert_gltf_skin_dlod.shader", "fobj_lambertText_skin_dlod.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("lambert",  "vobj_lambert.shader", "fobj_lambert.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("lambert_nodiffuse",  "vobj_lambert.shader", "fobj_lambert_nodiffuse.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("lambert_inst",  "vobj_lambert_inst.shader", "fobj_lambert.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("ui", "vBrush.shader","fBrush.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("depth", "vDepth.shader","fDepth.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("templateui", "vBrush.shader","ftemplate_ui.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("terrian", "vTerrian.shader","fTerrian.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("simterrain", "vTerrian.shader","fsim_Terrian.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("billboard", "vbillboard.shader","fbillboard.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("unit", "vobj_unit.shader","fobj_unit.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("transparent", "trans.shader", "trans_diffuse.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("diffuse", "trans.shader", "normal_diffuse.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("diffuse_s", "vtrans_cutoff.shader", "fDiffuse.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("diffuse_cutof", "vtrans_cutoff.shader", "fcutof_diffuse.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("diffuse_cutof_inst", "vtrans_cutoff_inst.shader", "fcutof_diffuse_inst.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("vertext_lit", "vvertext_lit.shader", "fvertext_lit.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("line", "v_line.shader","f_line.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("lambert_color",  "vobj_lambert.shader", "fobj_lambert_color.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("lambert_color_inst",  "vobj_lambert_inst.shader", "fobj_lambert_color.shader");
	//TODO
	MKConfig::instance()->mkProgrameManager.preLoad("linemesh", "v_linemesh.shader", "f_linemesh.shader");
	//MKConfig::instance()->mkProgrameManager.preLoad("line", "trans.shader","normal_diffuse.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("ptparticle", "vparticle.shader","fparticle.shader");
	MKConfig::instance()->mkProgrameManager.preLoad("particle", "vCommParticle.shader","fCommParticle.shader");

	MKConfig::instance()->mkProgrameManager.preLoad("lambert_nodiffuse_dlod", "vobj_lambert_dlod.shader", "fobj_lambert_nodiffuse_dlod.shader");
	LogUtil::logInfo("shader", "InitPrograme end");
	return 0;
}

void ff() {
	MEMORY * memoryV =   mopen("terrain_height.mk", 1);
	unsigned char* data = memoryV->buffer;
	float* dataF = (float*)data;
	for(int i=0; i<=512; i++) {
		for(int j=0; j<=512; j++) {
			int idxHeightMap = (i)*513+(j);
			float v = dataF[idxHeightMap];
			LogUtil::logFileInfo("ter", "%f\n", v);
		}
	}
}

int ESContext::InitUI(ESContext *esContext) {
	LogUtil::logInfo("ui", "InitUI begin");
	//CursorManager::ninstance();
	//CursorManager::instance()->initData();

	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	ctx->call1<int>("onCreateUI", this);

	LogUtil::logInfo("ui", "InitUI end");
	
	return TRUE;
}


ParticleSystemPtr ESContext::getParticle(string id) {
	map<string,ParticleSystemPtr>::iterator it= particles.find(id); 
	if(it != particles.end()) {
		return it->second;
	}
	return NULL;
}


ParticleSystemPtr ESContext::getParticleSystemByIdx(int idx) {
	

	return NULL;
}

void ESContext::clearParticles() {

	map<string, ParticleSystemPtr>::iterator it;
	it = particles.begin();
	while(it != particles.end())
	{
		it->second->unLink();
		it ++;         
	}
	particles.clear();
}


void ESContext::removeParticleAbms(string key) {
	for ( map<string,ParticleSystemPtr>::iterator it = particles.begin(); it != particles.end();)  
	{
		string id = it->first;
		if( strncmp(id.c_str(), key.c_str() ,key.length()) == 0 )
		{
			particles.erase(it++);
		}else {
			it++;
		}
	}
}



void ESContext::removeParticle(string id) {
	map<string,ParticleSystemPtr>::iterator it= particles.find(id); 
	it->second = NULL;
	particles.erase(it++);
}

void ESContext::addParticle(ParticleSystemPtr particle) {
	particles[particle->id] =particle;
}

void ESContext::addParticle(string id, ParticleSystemPtr particle) {
	particles[particle->id] = particle;
}


string& replace_all3(string& str, const string& old_value, const string& new_value)     
{     
	for(string::size_type pos(0); pos!=string::npos; pos+=new_value.length())   {     
		if((pos=str.find(old_value,pos))!=string::npos) {     
			str.replace(pos,old_value.length(),new_value);
		}
		else {
			break;
		}
	}     
	return str;     
} 

bool LoadTexture(const char* filename)
{
	/*const unsigned int texID = 0;
	GLenum image_format;
	GLint internal_format;
	GLint level;
	GLint border;
	*/


	//return success
	return true;
}

UTF8String getStrUtf(string name) {
	MEMORY * memoryV = mopen((char*)name.c_str(), 1);
	unsigned char* data = memoryV->buffer;
	string vv = string((char*)data);
	UTF8String aUTF8String = UTF8String(vv);
	return aUTF8String;
}

int ESContext::Init2D(ESContext *esContext) {
	LogUtil::logInfo("2d", "init2D begin");
	Sprite2DMap::instance = make_shared<Sprite2DMap>();
	pLayerManager = LayerManager::instance();
	pLayerManager->setEsConext(this);
	pLayerManager->init();
	LogUtil::logInfo("2d", "init2D begin");
	return TRUE;
}

int ESContext::Init3D(ESContext *esContext) {


	MKJson* json = new MKJson("[      {         \"blockId\" : \"block_02\",         \"coin\" : 200,         \"createTime\" : \"2022-05-04 09:10:37\",         \"duration\" : 12123009,         \"endTime\" : \"2022-05-04 21:10:37\",         \"id\" : 91,         \"liveTime\" : 43200000,         \"obj\" : \"Hydrangea\",         \"objId\" : \"carroit94746325\",         \"questionId\" : 2984,         \"state\" : 0,         \"x\" : -278,         \"y\" : 5,        \"z\" : -289      }   ]");
	json->getByPath("[0]");

	LogUtil::logInfo("res", "Init3D begin");

	//activityManagerPtr = ActivityManager::newInstance();
	//activityManagerPtr->setEsConext(this);

	esContext->aLuaCallBackThread = NULL;
	esContext->aLuaCallBackThread = LuaCallBackThread::newInstance();
	esContext->aLuaCallBackThread->ctx = esContext;
	esContext->aLuaCallBackThread->Url("http://localhost:8080/test/");
	esContext->aLuaCallBackThread->init(this->getRequestPool());
	esContext->aLuaCallBackThread->setName("LuaCallBackThread");
	esContext->aLuaCallBackThread->start();


	//SpriteMap::instance = make_shared<SpriteMap>();

	esContext->aSpriteInitThread = SpriteInitThread::newInstance();
	aSpriteInitThread->Context(this);
	aSpriteInitThread->init(this);
	aSpriteInitThread->setName("SpriteInitThread");
	esContext->sceneLoadStatus=1;
	esContext->aSpriteInitThread->setScene(esContext->sceneAddr);
	SceneLoadListenerPtr aSceneLoadListener = SceneLoadListener::newInstance();
	esContext->aSpriteInitThread->sceneLoadListenerPtr = aSceneLoadListener;
	esContext->aSpriteInitThread->start();

	aLuaThread = LuaThread::newInstance();
	aLuaThread->Context(this);
	aLuaThread->init(this);
	aLuaThread->setName("LuaThread");
	esContext->aLuaThread->start();
	
	aTimerThread = TimerThread::newInstance();
	aTimerThread->Context(this);
	aTimerThread->init(this);
	aTimerThread->setName("TimerThread");
	aTimerThread->start();
	
	isVR = MKConfig::instance()->isVR;
	if(isVR) {
		int screenWidth = esContext->userData->width;
		int screenHeight = esContext->userData->height;
	}
	
	enableSky = TRUE;

	LogUtil::logInfo("res", "Init3D end");

	return TRUE;
}



MKOBJSprite*  ESContext::initSky() {
	MKOBJSpritePtr aMKSkyPtr = MKOBJSprite::instance();	
	aMKSkyPtr->createSpriteWithJSON("{ \"id\": \"sphere\", \"isAsync\": 0, \"r\": 2000,  \"spriteType\": \"normal\", \"type\": \"sky\", \"posGlobal\": 1,        \"hNums\": 18,		\"wNums\": 9,        \"isFaceNormal\": \"0\",        \"material\": \"sky.mtl\",		\"use\":\"spheremk\",        \"programe\": \"sky\",        \"pos\": [          -100.000000,          0.000000,          -150.000000        ],        \"scale\": 1.000000      }");
	this->setSky(aMKSkyPtr.get());

	return aMKSkyPtr.get();
}

void ESContext::drawSky(ESContext *esContext) {
	if(esContext->aMKSkyPtr!=NULL) {
		esContext->setPositionByCamera();
		aMKSkyPtr->draw();
	}
}

int ESContext::InitFontResource(string fontName, ESContext *esContext) {                                                                   

	string fontPath = MKFontManager::instance()->getFontFromSystemPath(fontName);
	string fontPath3 = MKFontManager::instance()->getFontPath(fontName);
	if(FileUtil::IsFileExist(fontPath.c_str())) {
		LogUtil::logInfo("font", "load sys font DroidSansFallback sexist");
		MKFontManager::instance()->loadFontFromSystemPath(fontName, 16);
	}
	else if(FileUtil::IsFileExist(fontPath3.c_str())) {
		LogUtil::logInfo("font", "load font DroidSansFallback exist");
		MKFontManager::instance()->loadFontPathExist(fontName, 16);
	}else {
		LogUtil::logInfo("font", "load font DroidSansFallback not exist");
		MKFontManager::instance()->loadFontPath(fontName, 16);
	}
	return TRUE;
}

string ESContext::getProperty(string key) {
	string as = PropertyConfig::instance->getProperty(key);
	return as;
}

int ESContext::InitRealResource(ESContext *esContext) {
	LogUtil::logInfo("mk", "InitRealResource");
	int a = FALSE;
	EventData aEventData = FALSE;

	PropertyConfig::instance->loadLogPropertyConfig();
	Addr::serverIP = PropertyConfig::instance->getProperty("serverIP");
	if(Addr::serverIP == PropertyConfig::instance->getProperty("serverIP")) {
		LogUtil::logInfo("res", ":%d", Addr::serverIP.size());
	}else {
		LogUtil::logInfo("res", ":%d",  PropertyConfig::instance->getProperty("serverIP").size());
	}
	string as = PropertyConfig::instance->getProperty("serverIP");
	for(int i=0; i<as.size(); i++) {
		LogUtil::logInfo("res", "--%d", as.at(i));
	}
	LogUtil::logInfo("res", "Addr::serverIP:%s", Addr::serverIP.c_str());

	esContext->aDownloadManager.init();
	esContext->aDownloadManager.startDownoad();
	InitPrograme(esContext);

	curl_global_init(CURL_GLOBAL_ALL);
	string zipPath = getAPKPath();
	LogUtil::logInfo("download", "FILESYSTEM:%s", zipPath.c_str());
	std::vector<MKDIR> dirs;
	getAllRelativeDir(dirs);
	for(int i=0; i<dirs.size(); i++) {
		MKDIR aMKDIR = dirs[i];
		LogUtil::logInfo("res", "%d %s %s %d", i, aMKDIR.path.c_str(), aMKDIR.rootDirInZip.c_str(), aMKDIR.isZip);
	}

	LogUtil::logInfo("res", "load font begin");
	return TRUE;
}

int ESContext::InitLog() {
	LogUtil::instance->loadLogConfig();
	return 0;
}

void BuildAttribList( EGLint *attribList )
{

	GLuint flags = 0; 
	EGLint attribList2[] =
	{
		EGL_RED_SIZE,       5,
		EGL_GREEN_SIZE,     6,
		EGL_BLUE_SIZE,      5,
		EGL_ALPHA_SIZE,     EGL_DONT_CARE,
		EGL_DEPTH_SIZE,     EGL_DONT_CARE,
		EGL_STENCIL_SIZE,   EGL_DONT_CARE,
		EGL_SAMPLE_BUFFERS, 0,
		EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT_KHR,
		EGL_NONE
	};

	int len = sizeof(attribList2);
	memcpy(attribList, attribList2, len);

	//int  nAttribCount = 0;

	///////////////////////
	//attribList[nAttribCount++] = EGL_SURFACE_TYPE;
	//attribList[nAttribCount++] = EGL_PBUFFER_BIT;
	///////////////////////
	//attribList[nAttribCount++] = EGL_RED_SIZE;
	//attribList[nAttribCount++] = 5; 
	//attribList[nAttribCount++] = EGL_GREEN_SIZE;
	//attribList[nAttribCount++] = 6;
	//attribList[nAttribCount++] = EGL_BLUE_SIZE;
	//attribList[nAttribCount++] = 5;
	//attribList[nAttribCount++] = EGL_ALPHA_SIZE;
	//attribList[nAttribCount++] = 0;
	//attribList[nAttribCount++] = EGL_DEPTH_SIZE;
	//attribList[nAttribCount++] = 16;
	//attribList[nAttribCount++] = EGL_STENCIL_SIZE;
	//attribList[nAttribCount++] = 0;
	//attribList[nAttribCount++] = EGL_SAMPLES;
	//attribList[nAttribCount++] = 4;
	//attribList[nAttribCount++] = EGL_NONE;
}


void BuildAttribList_ANDROID( EGLint *attribList )
{
	int  nAttribCount = 0;

	/////////////////////
	attribList[nAttribCount++] = EGL_SURFACE_TYPE;
	attribList[nAttribCount++] = EGL_PBUFFER_BIT;
	/////////////////////
	attribList[nAttribCount++] = EGL_LEVEL;
	attribList[nAttribCount++] = 0; 
	attribList[nAttribCount++] = EGL_RENDERABLE_TYPE;
	attribList[nAttribCount++] = 4; 
	attribList[nAttribCount++] = EGL_COLOR_BUFFER_TYPE;
	attribList[nAttribCount++] = EGL_RGB_BUFFER; 

	attribList[nAttribCount++] = EGL_RED_SIZE;
	attribList[nAttribCount++] = 5; 
	attribList[nAttribCount++] = EGL_GREEN_SIZE;
	attribList[nAttribCount++] = 6;
	attribList[nAttribCount++] = EGL_BLUE_SIZE;
	attribList[nAttribCount++] = 5;
	attribList[nAttribCount++] = EGL_SAMPLE_BUFFERS;
	attribList[nAttribCount++] = 1;
	attribList[nAttribCount++] = EGL_SAMPLES;
	attribList[nAttribCount++] = 4;
	attribList[nAttribCount++] = EGL_NONE;
}


//for game
int ESContext::InitSize(ESContext *esContext)
{
	MyShaderProp::maxBindingPoint = 0;

	//for texture context
	EGLint contextAttribs[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };
	esContext->eglContext = eglGetCurrentContext();
	esContext->eglDisplay = eglGetDisplay(EGL_DEFAULT_DISPLAY);
	esContext->eglSurface = eglGetCurrentSurface(EGL_DRAW);
	LogUtil::logError("err", "eglInitialize eglDisplay InitSize:%p %p %p", esContext->eglContext, esContext->eglDisplay, esContext->eglSurface);
	EGLint numConfigs = 0;
	if ( ! eglGetConfigs( esContext->eglDisplay, NULL, 0, &numConfigs ) )
	{
		LogUtil::logError("err", "eglInitialize eglGetConfigs error");
	}

	//EGLint attribList[64];
	EGLint attribList[128];
	BuildAttribList(attribList);
	if ( !eglChooseConfig ( esContext->eglDisplay, attribList, &config, 1, &numConfigs ) )
	{
		LogUtil::logError("err", "eglInitialize eglChooseConfig error");
	}
	if ( numConfigs < 1 )
	{
		LogUtil::logError("err", "eglInitialize numConfigs<1 error");
	}


	
	vec3 c = {-80,10,-50};
	esContext->aCameraPtr = Camera::instance();
	esContext->aCameraPtr->bindFBO();
	esContext->aCameraPtr->spriteCenterDltVec = Vector3(0,0,-1);
	esContext->aCameraPtr->dltLenght = 80;
	esContext->aCameraPtr->angle = 0;
	esContext->aCameraPtr->centerVec = c;

	esContext->uiCameraPtr = Camera::newInstance();
	esContext->uiCameraPtr->bindFBO(FBO_IMG_TEXTURE);
	esContext->uiCameraPtr->spriteCenterDltVec = Vector3(0, 0, -1);
	esContext->uiCameraPtr->dltLenght = 80;
	esContext->uiCameraPtr->angle = 0;
	esContext->uiCameraPtr->centerVec = c;
	LogUtil::logError("camera", "InitSize======");



	MKConfig::instance()->clientWidth =  esContext->userData->width;
	MKConfig::instance()->clientHeight = esContext->userData->height;

	GFX_start();

	float width = esContext->userData->width;
	float height = esContext->userData->height;
	glViewport( 0.0f, 0.0f, width, height );
	glGetIntegerv( GL_VIEWPORT, viewport_matrix );
	esContext->aCameraPtr->viewport_matrix = viewport_matrix;
	glHint( GL_GENERATE_MIPMAP_HINT, GL_NICEST );
	glHint( GL_FRAGMENT_SHADER_DERIVATIVE_HINT_OES, GL_NICEST );
	glEnable( GL_DEPTH_TEST );
	
	return TRUE;
}


void ESContext::init_physic_world( void )
{
	pMKBulletWorldPtr = MKBulletWorld::instance();
	pMKBulletWorldPtr->init();
	initPhysicFlag = TRUE;

}

int ESContext::InitSurface(ESContext *esContext) {
		Init2D(esContext);
		Init3D(esContext);
		InitUI(esContext);
		return TRUE;
}


int ESContext::initMP3Resource()
{

	int iMpg123_error;
	/*
	if(MPG123_OK != (iMpg123_error = mpg123_init()))
	{
		printf("failed to init mpg123\n");
		return -1;
	}
	*/
	pDevice = alcOpenDevice(NULL); //select the perfered device
	if(pDevice){
		pContext = alcCreateContext(pDevice, NULL);
		alcMakeContextCurrent(pContext);
	}else
	{
		printf("failed to get a openal decice\n");
		return -2;
	}

	return 0;
}

void vbo_error5(unsigned int error, string title)
{

	while( ( error = glGetError() ) != GL_NO_ERROR )
	{
		char str[ MAX_CHAR ] = {""};
		switch( error )
		{
		case GL_INVALID_ENUM:
			{
				strcpy( str, "GL_INVALID_ENUM" );
				break;
			}

		case GL_INVALID_VALUE:
			{
				strcpy( str, "GL_INVALID_VALUE" );
				break;
			}

		case GL_INVALID_OPERATION:
			{
				strcpy( str, "GL_INVALID_OPERATION" );
				break;
			}

		case GL_OUT_OF_MEMORY:
			{
				strcpy( str, "GL_OUT_OF_MEMORY" );
				break;
			}
		}

		LogUtil::logError("err", "gl error %s, %d: %s",  title.c_str(), error, str);
	}
}

static void TestMaxGLBufferData()
{

	long long nNumberM = 0;
	const long long MAX_NUMBER = 10000;
	unsigned int error = 0;
	while ((error=glGetError()) == GL_NO_ERROR && nNumberM < MAX_NUMBER)
	{
		GLuint objectVBO = 0;
		glGenBuffers(1, &objectVBO);
		glBindBuffer(GL_ARRAY_BUFFER, objectVBO);
		// 1<<20 = 1M �Ŀռ�;
		glBufferData(GL_ARRAY_BUFFER, 1 << 20, NULL, GL_STATIC_DRAW);
		nNumberM++;
	}
	vbo_error5(error, "TestMaxGLBufferData");
	LogUtil::logError("err", "max memory test:%dM", nNumberM);

	//printf("gpu����������� %lld M, ��ඥ����Ŀ(x, y, z����):%lld ��\n", nNumberM, nNumberM * 1024 * (1024 / 12));
}

MyString prsSquareIdx(MyString& a) {
	int idx = 0;
	int len = a.length();
	MyString all;
	MyString params;
	int i = 0;
	while(len>0) {
		int aidx1 = a.indexOf("[", 0);
		int aidx2 = a.indexOf("]", 0);
		MyString pre = a.subString(0, aidx1);
		MyString mid = a.subString(aidx1+1, aidx2);
		MyString suf = a.subStr(aidx2+1);
		MyString item = pre+"[%s]";
		all+=item;
		if(i==0) {
			params=params+"toStr("+mid+")";
		}else {
			params=params+","+"toStr("+mid+")";
		}
		
		a = suf;
		len = a.length();
		i++;
	}
	MyString ret = "string.format(";
	ret=ret+"'"+all+"'";
	ret+=",";
	ret+=params;
	return ret;
}

int ESContext::InitResource(ESContext *esContext) {
    MKThreadLocal::setStrAttr("thread_name", "DRAW");	
	LogUtil::logInfo("lock", "set thread_name:%s", "DRAW");
	//canvasContext = Canvas::createInstance();
	//main_harmonics();


	pMKLuaBridgePtr = MKLuaBridge::newInstance();
	activityManagerPtr = ActivityManager::newInstance();
	activityManagerPtr->setEsConext(this);

	LogUtil::logInfo("scene", "InitResource begin");
	setScene(esContext, 0);
	pObjMergeManagerPtr  = make_shared<ObjMergeManager>();

	MKConfig::instance()->setDrawThreadId(getThreaId());
	pLUAPoolList = new LuaPoolList(1, 1);
	pLUAPoolList->init(this);
	initMP3Resource();
	//QuickjsContext
	qjsInstance = newQJSNode(this);

	esContext->aMyTime.start();
	esContext->curFrame2DIdx = -1;
	esContext->oldTime = esContext->aMyTime.endTime;
	initMKPacketProcess();

	if(!MKConfig::instance()->ResourceInitOK()) {
		InitRealResource(esContext);
	}
	MKConfig::instance()->ResourceInitOK(TRUE);

	LogUtil::logInfo("mk", "ResourceInitOK():%d", MKConfig::instance()->ResourceInitOK());

	return TRUE;
}

void ESContext::reset2D(int idx) {
	getPLayerManager()->reset(idx);
}

void ESContext::startLUA() {
	this->gameState = GAME_LIVE;
	startLUA("showstr");

	//quickjs
	qjsInstance->start();
}

void ESContext::startLUA(string func) {
	this->call1<string>(func.c_str(), this);
}

void ESContext::initMKPacketProcess() {
	packetDecodeList.push_back(getIdelAction);
	packetDecodeList.push_back(getWalkAction);
	packetDecodeList.push_back(getAtkAction);
	packetDecodeList.push_back(getSetAttrAction);
}


void ESContext::stopAllFbxSprite() {
	run(FALSE);
}

void ESContext::resumeAllFbxSprite() {
	run(TRUE);
}


int InitSize(ESContext *esContext) {
	LogUtil::logInfo("mk", "InitSize():%d", 0);

	//MKHttpClient aMKHttpClient;
	//string url = "http://192.168.0.101:8080/test/getExam.do?params=%7B%22id%22%3A18%7D";
	//string res = aMKHttpClient.getContent(url);
	//MKJson* pMKJson = MKJson::newByContent(res);
	//UTF8String str = pMKJson->getStr("data[0]['data']['cn'][0]['cname']");
	//LogUtil::logInfo("mk", "c->:%s", str.utf8());
	esContext->InitSize(esContext);
	LogUtil::logInfo("mk", "InitSize():%d", 1);
	return TRUE;
}

/************************************************************************/
/*
load resources:
MKShadow
LuaPoolList
initMP3Resource
PropertyConfig
DownloadManager
Programe
*/
/************************************************************************/
int InitResource(ESContext *esContext) {
	/*NVGcontext* canvasContext = esContext->createCanvasContext();
	Canvas* canvasPtr = new Canvas(canvasContext);
	esContext->canvasContext = canvasPtr;*/
	SpriteMap::instance = make_shared<SpriteMap>();
	esContext->shadowCameraPtr = Camera::newInstance();
	esContext->shadowCameraPtr->bindFBO(FBO_DEPTHO_TEXTURE);
	esContext->cameraMap["gShadowCamera"] = esContext->shadowCameraPtr;

	esContext->InitResource(esContext);
	esContext->SetFrameBufferObject(0, 0);

	return TRUE;
}

int InitSurface(ESContext *esContext) {
	LogUtil::logInfo("mk", "MKInitSurface begin");
	esContext->init_physic_world();
	esContext->InitSurface(esContext);
	LogUtil::logInfo("mk", "MKInitSurface end");
	return TRUE;
}

void ESContext::init2D() {
}

void ESContext::draw2D() {
	pLayerManager->doTimer();
	pLayerManager->clearTimer();
	pLayerManager->drawFunc(this, curFrame2DIdx);
}

//for windows no android
int Init(ESContext *esContext)
{
	esContext->InitLog();
	InitSize(esContext);
	InitResource(esContext);
	InitSurface(esContext);
	
	esContext->init2D();

	return TRUE;
}


int setScreenDensity(ESContext *esContext, int density) {
	ViewManagerPtr aViewManager = ViewManager::instance();
	aViewManager->Densitiy(1.0*density/1000);
	return 0;
}

inline float intBitsToFloat(int i)
{
	union
	{
		int i;
		float f;
	} u;
	u.i = i;
	return u.f;
}

float ff(int bits) {

	int s = ((bits >> 31) == 0) ? 1 : -1;
	int e = ((bits >> 23) & 0xff);
	int m =  (bits & 0x7fffff);

	return (s*m*pow(2.0f, e-127));

}

inline int floatToRawIntBits(float f)
{
	union
	{
		int i;
		float f;
	} u;
	u.f = f;
	return u.i;
}


void drawVideo( ESContext *esContext )
{

	return;
	GLint compiled = TRUE;
	GLint linked;
	

	float y = intBitsToFloat(0xBAADEE00);
	int b = floatToRawIntBits(0.25f);
	int b2 = 0x3E800000;

	MKConfig::instance()->mkProgrameManager.preLoad("feed", "vobj_feed.shader", "fobj_feed.shader");
	MyPrograme aMyPrograme;
	MKConfig::instance()->mkProgrameManager.getFromCache("feed", aMyPrograme);
	GLuint program = aMyPrograme.mProgramObject;
	glUseProgram(program);

	GLuint vao;
	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);

	GLfloat data[] = { 1.0f, 2.0f, 3.0f, 4.0f, 5.0f };
	GLuint vbo;
	glGenBuffers(1, &vbo);
	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferData(GL_ARRAY_BUFFER, sizeof(data), data, GL_STATIC_DRAW);

	GLint inputAttrib = glGetAttribLocation(program, "inValue");
	glEnableVertexAttribArray(inputAttrib);
	glVertexAttribPointer(inputAttrib, 1, GL_FLOAT, GL_FALSE, 0, 0);

	GLuint tbo;
	glGenBuffers(1, &tbo);
	glBindBuffer(GL_ARRAY_BUFFER, tbo);
	glBufferData(GL_ARRAY_BUFFER, 20, nullptr, GL_STATIC_READ);

	glEnable(GL_RASTERIZER_DISCARD);
	glBindBufferBase(GL_TRANSFORM_FEEDBACK_BUFFER, 0, tbo);
	glBeginTransformFeedback(GL_POINTS);
	glDrawArrays(GL_POINTS, 0, 5);
	glEndTransformFeedback();
	glDisable(GL_RASTERIZER_DISCARD);
	float* memoryBuffer = (float *)glMapBufferRange(GL_TRANSFORM_FEEDBACK_BUFFER, 0, 20, GL_MAP_READ_BIT);
	glFlush();

	//uint uu = 0;
	//uu=uu^0x00018000u;
	
	/*for(int i=0; i<5; i++) {
		printf("%f\n", memoryBuffer[i]);
	}*/
 }


void printFramebufferInfo(GLuint fbo)
{
	// bind fbo
	glBindFramebuffer(GL_FRAMEBUFFER, fbo);

	std::cout << "\n===== FBO STATUS =====\n";

	// print max # of colorbuffers supported by FBO
	int colorBufferCount = 0;
	//glGetIntegerv(GL_MAX_COLOR_ATTACHMENTS, &colorBufferCount);
	std::cout << "Max Number of Color Buffer Attachment Points: " << colorBufferCount << std::endl;

	// get max # of multi samples
	int multiSampleCount = 0;
	//glGetIntegerv(GL_MAX_SAMPLES, &multiSampleCount);
	std::cout << "Max Number of Samples for MSAA: " << multiSampleCount << std::endl;

	int objectType;
	int objectId;

	// print info of the colorbuffer attachable image
	for(int i = 0; i < colorBufferCount; ++i)
	{
		glGetFramebufferAttachmentParameteriv(GL_FRAMEBUFFER,
			GL_COLOR_ATTACHMENT0+i,
			GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE,
			&objectType);
		if(objectType != GL_NONE)
		{
			glGetFramebufferAttachmentParameteriv(GL_FRAMEBUFFER,
				GL_COLOR_ATTACHMENT0+i,
				GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME,
				&objectId);

			std::string formatName;

			std::cout << "Color Attachment " << i << ": ";
			if(objectType == GL_TEXTURE)
			{
				//std::cout << "GL_TEXTURE, " << getTextureParameters(objectId) << std::endl;
			}
			else if(objectType == GL_RENDERBUFFER)
			{
				//std::cout << "GL_RENDERBUFFER, " << getRenderbufferParameters(objectId) << std::endl;
			}
		}
	}

	// print info of the depthbuffer attachable image
	glGetFramebufferAttachmentParameteriv(GL_FRAMEBUFFER,
		GL_DEPTH_ATTACHMENT,
		GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE,
		&objectType);
	if(objectType != GL_NONE)
	{
		glGetFramebufferAttachmentParameteriv(GL_FRAMEBUFFER,
			GL_DEPTH_ATTACHMENT,
			GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME,
			&objectId);

		std::cout << "Depth Attachment: ";
		switch(objectType)
		{
		case GL_TEXTURE:
			//std::cout << "GL_TEXTURE, " << getTextureParameters(objectId) << std::endl;
			break;
		case GL_RENDERBUFFER:
			//std::cout << "GL_RENDERBUFFER, " << getRenderbufferParameters(objectId) << std::endl;
			break;
		}
	}

	// print info of the stencilbuffer attachable image
	glGetFramebufferAttachmentParameteriv(GL_FRAMEBUFFER,
		GL_STENCIL_ATTACHMENT,
		GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE,
		&objectType);
	if(objectType != GL_NONE)
	{
		glGetFramebufferAttachmentParameteriv(GL_FRAMEBUFFER,
			GL_STENCIL_ATTACHMENT,
			GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME,
			&objectId);

		std::cout << "Stencil Attachment: ";
		switch(objectType)
		{
		case GL_TEXTURE:
			//std::cout << "GL_TEXTURE, " << getTextureParameters(objectId) << std::endl;
			break;
		case GL_RENDERBUFFER:
			//std::cout << "GL_RENDERBUFFER, " << getRenderbufferParameters(objectId) << std::endl;
			break;
		}
	}

	std::cout << std::endl;
	glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

int drawIdx = 0;

//main thread
BOOL processFrameRate(ESContext *esContext) {
	if(esContext->gameState == GAME_INIT) {
		return TRUE;
	}

	int frameRate = 60;
	float frameTime = 1000.0f/frameRate;
	esContext->aMyTime.next();
	long offsetTime = esContext->aMyTime.endTime - esContext->oldTime;
	int fraction = offsetTime/frameTime;
	if(fraction<=0) {
		return FALSE;
	}

	int dlt = offsetTime - frameTime*fraction;
	esContext->oldTime = esContext->aMyTime.endTime - dlt;

	LogUtil::logInfo("mktime", "es duration:%f", esContext->aMyTime.duration);
	return TRUE;
}

BOOL processFrameRate2D(ESContext *esContext) {
	if(esContext->gameState == GAME_INIT) {
		return FALSE;
	}

	int frameRate = 60;
	float frameTime = 1000.0f/frameRate;
	esContext->aMyTime.next();
	long offsetTime = esContext->aMyTime.endTime - esContext->oldTime;
	int fraction = offsetTime/frameTime;
	if(fraction<=0) {
		return FALSE;
	}

	int dlt = offsetTime - frameTime*fraction;
	esContext->oldTime = esContext->aMyTime.endTime - dlt;
	esContext->curFrame2DIdx++;
	LogUtil::logInfo("drawIdx", "1 es duration:%f", esContext->aMyTime.duration);
	return TRUE;
}


void processSyncDrawEvent(ESContext *esContext) {
	MKCyleList<MKUIActionPtr>& actionList = esContext->syncDrawActionList;
	while(actionList.hasNext()) {
		MKUIActionPtr currentPtr = actionList.getCurrent();
		if(currentPtr->State()==MKUIACTION_END) {
			actionList.next();
		}else{
			LogUtil::logInfo("sync", "processSyncDrawEvent syncDraw");
			currentPtr->process();
		}
	}
}

void processFbxEvent(ESContext *esContext) {
	if(esContext->isStop()) {
		return;
	}
	for(int i=0; i<esContext->fbxObjs.size(); i++) {
		MK3DObjectPtr &node = esContext->fbxObjs.at(i);
		shared_ptr<MKFBXOBJSprite> spritePtr = dynamic_pointer_cast<MKFBXOBJSprite>(node);
		string onAlive = spritePtr->GetOnAlive();
		if(onAlive!="") {
			LogUtil::logInfo("bullet", "processFbxEvent begin:%s", onAlive.c_str());
			MKFBXOBJSprite* obj = spritePtr.get();
			esContext->call2<int>(onAlive.c_str(), obj, esContext);
			LogUtil::logInfo("bullet", "processFbxEvent end");			
		}
		spritePtr->behaviorUpdate();
	} 
}

void processObjSpriteEvent(ESContext *esContext) {
	for(int i=0; i<esContext->dynamicObjs.size(); i++) {
		MK3DObjectPtr &node = esContext->dynamicObjs.at(i);
		string onAlive = node->GetOnAlive();
		if(onAlive!="") {
			string type = node->typeClass;
			if(type=="OBJSprite") {
				shared_ptr<MKOBJSprite> spritePtr = dynamic_pointer_cast<MKOBJSprite>(node);
				MKOBJSprite* obj = spritePtr.get();
				esContext->call2<int>(onAlive.c_str(), obj, esContext);
			}else if(type=="VirtualSprite") {
				shared_ptr<MKVirtualSprite> spritePtr = dynamic_pointer_cast<MKVirtualSprite>(node);
				MKVirtualSprite* obj = spritePtr.get();
				esContext->call2<int>(onAlive.c_str(), obj, esContext);
			}

			//test js

		}
	} 
}

//void testDepth() {
//	int m_textureWidth = 1024;
//	int m_textureHeight = 768;
//	GLuint m_texture_depth;
//	glGenTextures(1, &m_texture_depth);
//	glBindTexture(GL_TEXTURE_2D, m_texture_depth);
//
//
//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
//
//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
//	glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, m_textureWidth, m_textureHeight, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_SHORT, NULL);
//
//	//glCopyTexImage2D();
//	glBindTexture(GL_TEXTURE_2D, 0);
//}

void ESContext::lockEvent() {
	eventLock.enter();
}

void ESContext::unlockEvent() {
	eventLock.leave();
}


void ESContext::lockSyncDrawEvent() {
	syncDrawMutex.enter();
}

void ESContext::unlockSyncDrawEvent() {
	syncDrawMutex.leave();
}



///////////////////////////////////////////test fbo
void ESContext::GenImage()  
{
	glBindFramebuffer(GL_FRAMEBUFFER, imageFBO);
	processFbxEvent(this);
	this->drawFunc(this);
	glBindFramebuffer(GL_FRAMEBUFFER, 0);
}


///////////////////////////////////////////test fbo end

//common for lua
MKFBXOBJSprite* getSprite(string objId) {
	MKFBXOBJSpritePtr pSprite = SpriteMap::instance->getFBXObj(objId);
	if(pSprite!=NULL) {
		return pSprite.get();
	}
	return NULL;
}

MKVirtualSprite* getVirtualSprite(string objId) {
	MKVirtualSpritePtr pSprite = SpriteMap::instance->getVirtual(objId);
	if(pSprite!=NULL) {
		return pSprite.get();
	}
	return NULL;
}


void setGString(string propName, string v) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	ctx->getExt()->setString(propName, v);
}
void setGInt(string propName, int v) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	ctx->getExt()->setInt(propName, v);
}
void setGFloat(string propName, float v) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	ctx->getExt()->setFloat(propName, v);
}

string setGString(string propName) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	return ctx->getExt()->getString(propName);
}
int setGInt(string propName) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	return ctx->getExt()->getInt(propName);
}
float setGFloat(string propName) {
	ESContext* ctx = MKConfig::instance()->getCurrentEsContext();
	return ctx->getExt()->getFloat(propName);
}

void drawFunc( ESContext *esContext ) {
	if(esContext->exitFlag) {
		return;
	}

	if(esContext->is2DGame) {
		BOOL frameFlag =processFrameRate2D(esContext);
		if(frameFlag==FALSE) {
			return;
		}
	}else {
		BOOL frameFlag =processFrameRate(esContext);
		if(frameFlag==FALSE) {
			return;
		}
		if(esContext->shadowCameraPtr!=NULL) {
			esContext->shadowCameraPtr->DrawShaow(esContext);
		}
	}

	unsigned long tId = getThreaId();
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); 
	glEnable( GL_CULL_FACE  );
	glCullFace ( GL_BACK );

	processSyncDrawEvent(esContext);
	if(esContext->is2DGame) {
	}else {
		processFbxEvent(esContext);
		processObjSpriteEvent(esContext);
	}
	esContext->drawFunc(esContext);	
	drawIdx++;		

#ifdef ANDROID
#else
	eglSwapBuffers (esContext->eglDisplay, esContext->eglSurface );
#endif

}

int ESContext::getClientWidth() {
	return userData->width;
}

int ESContext::getClientHeight() {
	return userData->height;
}

BOOL ESContext::isNULLScene() {
	if(aSpriteInitThread==NULL) {
		return TRUE;
	}

	if(aSpriteInitThread->CurrentScene()==NULL) {
		return TRUE;
	}

	if(aSpriteInitThread->lockScene==TRUE) {
		return TRUE;
	}

	return FALSE;
}

vector<MK3DObjectPtr> ESContext::getFbxOK() {
	ScenePtr currentScene = getCurrentScene();
	if(currentScene==NULL) {
		LogUtil::logInfo("ui", "currentScene NULL");
	}	
	return currentScene->getFBXOK();
}

vector<MK3DObjectPtr> ESContext::getDynamicOK() {
	ScenePtr currentScene = getCurrentScene();
	if(currentScene==NULL) {
		LogUtil::logInfo("ui", "currentScene NULL");
	}	
	return currentScene->getDynamicOK();
}


void ESContext::processFbxNewSprite(ESContext *esContext) {
	
	//end ui action
	if(esContext->isNULLScene()) {
		return;
	}
	
	vector<MK3DObjectPtr> oks = esContext->getFbxOK();
	int spriteLen = oks.size();
	for(int i=0; i<spriteLen; i++) { 
		MK3DObjectPtr aMK3DObjectPtr = oks[i];
		shared_ptr<MKFBXOBJSprite> spritePtr = dynamic_pointer_cast<MKFBXOBJSprite>(aMK3DObjectPtr);
	
		spritePtr->createVAO();
		spritePtr->buildTextureAndMaterial();
		esContext->addFBXObj(spritePtr);


		if(terriansPtr!=NULL) {
			terriansPtr->addSearchGridSprite(aMK3DObjectPtr);
		}

		if(spritePtr->isHero) {
			esContext->heroPtr = spritePtr;
		}

		loadEnd(spritePtr);
	}

}

void ESContext::loadEnd(MKFBXOBJSpritePtr spritePtr) {
	string fun = spritePtr->getOnLoadEnd();
	if(fun!="") {
		LogUtil::logInfo("bullet", "loadEnd begin:%s", fun.c_str());
		MKFBXOBJSprite* obj = spritePtr.get();
		call2<int>(fun.c_str(), obj, this);
		LogUtil::logInfo("bullet", "loadEnd end");
	}
	spritePtr->behaviorLoadEnd();
}

void ESContext::markObj() {
	SpriteMapPtr spriteMapInst = SpriteMap::instance;
	map<string, MKOBJSpritePtr> spriteMap = spriteMapInst->spriteMap;
	map<string,MKOBJSpritePtr>::iterator it = spriteMap.begin();
	int idx=0;
	int wordsLen = words.size();
	for ( map<string,MKOBJSpritePtr>::iterator it = spriteMap.begin(); it != spriteMap.end();   ++it)  
	{
		MKOBJSpritePtr aMKOBJSpritePtr = (MKOBJSpritePtr)(it->second);
		if(aMKOBJSpritePtr->isMarked) {
			if(idx>=wordsLen) {
				aMKOBJSpritePtr->IsObjVisible(FALSE);
				continue;
			}
			MKBeanPtr aMKBeanPtr = words[idx];
			string qId = aMKBeanPtr->getAttr("id");
			string img = aMKBeanPtr->getAttr("img");
			aMKOBJSpritePtr->setAttr("qId", qId);
			aMKOBJSpritePtr->setImage(0, img);
			idx++;
		}
	}
}


void saveStatic() {
	/*SpriteMapPtr spriteMapInst = SpriteMap::instance;
	map<string, MKOBJSpritePtr> spriteMap = spriteMapInst->spriteMap;
	map<string,MKOBJSpritePtr>::iterator it = spriteMap.begin();
	int idx=0;
	for ( map<string,MKOBJSpritePtr>::iterator it = spriteMap.begin(); it != spriteMap.end();   ++it)  
	{
	MKOBJSpritePtr aMKOBJSpritePtr = (MKOBJSpritePtr)(it->second);
	PObjAttr aptr = new ObjAttr;
	aptr->OBJ_FILE = aMKOBJSpritePtr->OBJ_FILE;
	aptr->scale = aMKOBJSpritePtr->pMKObj->scale;
	Vector3 pos(aMKOBJSpritePtr->x, aMKOBJSpritePtr->y, aMKOBJSpritePtr->z);
	aptr->pos = toVec3(pos);
	ObjMergeManager::instance->put(aptr);
	}
	ObjMergeManager::instance->obj2objfile();*/
}

void ESContext::processNewSprite(ESContext *esContext) {
	if(esContext->isNULLScene()) {
		return;
	}

	vbo_error3("processNewSprite");
	//resetCommands
	int resetCmdSize = resetCommands.size();
	if(resetCmdSize>0) {
		for(int i=0; i<resetCmdSize; i++) {
			string resetData = resetCommands.at(i);
			LogUtil::logInfo("thread", "resetData:%s", resetData.c_str());
			processUserDataFromJava(esContext, resetData);
		}
	}
	clearVector(resetCommands);

	vbo_error3("processNewSprite");

	//particleCommands
	int particleCmdSize = particleCommands.size();
	if(particleCmdSize>0) {
		for(int i=0; i<particleCmdSize; i++) {
			string data = particleCommands.at(i);
			LogUtil::logInfo("thread", "particleData:%s", data.c_str());
			processParticle(esContext, data);
		}
	}
	clearVector(particleCommands);

	//prs cmd end
	vector<MK3DObjectPtr> oks = esContext->aSpriteInitThread->getOK();
	int spriteLen = oks.size();
	for(int i=0; i<spriteLen; i++) {
		MK3DObjectPtr aMK3DObjectPtr = oks[i];
		LogUtil::logInfo("draw", "gl init begin:%s", aMK3DObjectPtr->id.c_str());
		aMK3DObjectPtr->buildTextureAndMaterialWidthChild();
		aMK3DObjectPtr->createVBOWithChild();
		aMK3DObjectPtr->createVAOWithChild();
		aMK3DObjectPtr->startActionWithChild();
		LogUtil::logInfo("draw", "gl init end:%s", aMK3DObjectPtr->id.c_str());

		esContext->addObj(aMK3DObjectPtr);

		if(aMK3DObjectPtr->spriteType == "terrians") {
			shared_ptr<MKTerrians> spritePtr = dynamic_pointer_cast<MKTerrians>(aMK3DObjectPtr);
			terriansPtr = spritePtr;
			LogUtil::logInfo("outer", "set terriansPtr");
		}
	}
	vbo_error3("processNewSprite");
	if(aSpriteInitThread->isSceneLoadEnd() && initPhysicFlag) {

		if(!aSpriteInitThread->isSceneLoadEndDataSet()) {
			aSpriteInitThread->setSceneLoadEndDataSet();
			enableEvent = TRUE;
			canUnloadScene = TRUE;
			esContext->aSpriteInitThread->sceneLoadEnd(esContext);
			markObj();
			//saveStatic();//TODO

			pLUAPoolList->setCurrentThreadNoPoolNode();
			//startLUA();
			enableSky = TRUE;
			return;
		}
	}
}


void ESContext::processDynamicNewSprite(ESContext *esContext) {
	if(esContext->isNULLScene()) {
		return;
	}

	//prs cmd end
	vector<MK3DObjectPtr> oks = esContext->getDynamicOK();
	int spriteLen = oks.size();
	for(int i=0; i<spriteLen; i++) {
		MK3DObjectPtr aMK3DObjectPtr = oks[i];
		string id = aMK3DObjectPtr->id;
		LogUtil::logInfo("draw", "gl init begin:%s", aMK3DObjectPtr->id.c_str());
		aMK3DObjectPtr->buildTextureAndMaterialWidthChild();
		aMK3DObjectPtr->createVBOWithChild();
		aMK3DObjectPtr->createVAOWithChild();
		aMK3DObjectPtr->startActionWithChild();
		LogUtil::logInfo("draw", "gl init end:%s", aMK3DObjectPtr->id.c_str());

		esContext->addDynamicObj(aMK3DObjectPtr);
	}

}

void ESContext::setCurrentThreadNoPoolNode() {
	pLUAPoolList->setCurrentThreadNoPoolNode();
}

void ESContext::drawLFunc( ESContext *esContext )
{
}

void ESContext::drawRFunc( ESContext *esContext )
{
}

/*
void ESContext::drawSetMatrix( ESContext *esContext ) {
	//set view port begin
	float width = esContext->userData->width;
	float height = esContext->userData->height;
	glViewport( 0, 0 , width, height );
	glGetIntegerv( GL_VIEWPORT, viewport_matrix );
	esContext->aCameraPtr->viewport_matrix = viewport_matrix;
	esContext->aCameraPtr->Width(width);
	esContext->aCameraPtr->Height(height);
	//end view port
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
	//esContext->processNewSprite(esContext);	
	//esContext->processDynamicNewSprite(esContext);
	//esContext->processFbxNewSprite(esContext);
	GFX_set_matrix_mode( PROJECTION_MATRIX );
	{
		GFX_load_identity();
		GFX_set_perspective( 45.0f, ( float )esContext->userData->width / ( float )esContext->userData->height,	10.0f, 5000.0f, 0.0f, esContext->aCameraPtr );
		glDisable( GL_CULL_FACE );
	}

	vec3 cameraPos = esContext->aCameraPtr->getV3Position();
	LogUtil::logInfo("camera", "camera:%f %f %f", cameraPos.x, cameraPos.y, cameraPos.z);
	vec3 centerVec = esContext->aCameraPtr->getCenterVec();
	vec3 upDiv = toVec3(esContext->aCameraPtr->getUp());
	GFX_look_at( &cameraPos, &centerVec, &upDiv, esContext->aCameraPtr );//VIEW_MATRIX
	
}
*/

void ESContext::setLabelValueUTF8(string id, UTF8String value) {
	string v = value.utf8();
	setLabelValue(id, v);
}


void ESContext::setUIImage(string id, string path) {
	ActivityPtr activityPtr = getActivity();
	if(activityPtr==NULL) {
		LogUtil::logInfo("sky", "setLabelValue NULL");
	}
	MKUINodePtr uiPtr = activityPtr->getNode(id);
	if (uiPtr== nullptr) {
		return;
	}
	uiPtr->setBackgroundAct(path);
}

float ESContext::getUIFloat(string id, string prop) {
	ActivityPtr activityPtr = getActivity();
	if(activityPtr==NULL) {
		LogUtil::logInfo("sky", "setLabelValue NULL");
		return 0;
	}
	MKUINodePtr uiPtr = activityPtr->getNode(id);
	return uiPtr->aMKLuaBridgePtr->getFloat(prop);
}

void ESContext::setUIFloat(string id, string prop, float v) {
	ActivityPtr activityPtr = getActivity();
	if(activityPtr==NULL) {
		return;
	}
	MKUINodePtr uiPtr = activityPtr->getNode(id);
	LogUtil::logInfo("uik", "setLabelValue %f",v );
	if(uiPtr==NULL) {
		return;
	}
	uiPtr->aMKLuaBridgePtr->setFloat(prop, v);
}


BOOL ESContext::getUIBOOL(string id, string prop) {
	ActivityPtr activityPtr = getActivity();
	if(activityPtr==NULL) {
		return 0;
	}
	MKUINodePtr uiPtr = activityPtr->getNode(id);
	return uiPtr->aMKLuaBridgePtr->getInt(prop);
}

void ESContext::setUIBOOL(string id, string prop, BOOL v) {
	ActivityPtr activityPtr = getActivity();
	if(activityPtr==NULL) {
		return;
	}
	MKUINodePtr uiPtr = activityPtr->getNode(id);
	if(uiPtr==NULL) {
		return;
	}
	uiPtr->aMKLuaBridgePtr->setInt(prop, v);
}

string ESContext::getUIString(string id, string prop) {
	ActivityPtr activityPtr = getActivity();
	if(activityPtr==NULL) {
		return "";
	}
	MKUINodePtr uiPtr = activityPtr->getNode(id);
	return uiPtr->aMKLuaBridgePtr->getString(prop);
}

void ESContext::setUIString(string id, string prop, string v) {
	ActivityPtr activityPtr = getActivity();
	if(activityPtr==NULL) {
		return;
	}
	MKUINodePtr uiPtr = activityPtr->getNode(id);
	if(uiPtr==NULL) {
		return;
	}
	uiPtr->aMKLuaBridgePtr->setString(prop, v);
}


void ESContext::setLabelValue(string id, string value) {
	ActivityPtr activityPtr = getActivity();
	if(activityPtr==NULL) {
		LogUtil::logInfo("sky", "setLabelValue NULL");
	}
	shared_ptr<MKLabel> uiPtr = dynamic_pointer_cast<MKLabel>(activityPtr->getNode(id));
	if(activityPtr==NULL) {
		LogUtil::logInfo("sky", "setLabelValue NULL");
	}
	uiPtr->setTextByAction(value);
}

void ESContext::processCallBack(ESContext *esContext) {
	if(aLuaCallBackThread==NULL) {
		return;
	}
	RequestPool* pRequestPool = this->getRequestPool();
	if(pRequestPool==NULL) {
		return;
	}
	
	vector<RequestPacket*> list = pRequestPool->consume();
	int size = list.size();
	for(int i=0; i<size; i++) {
		RequestPacket* pRequestPacket = list.at(i);
		string ret = esContext->call1<string>("callBack", this);
	}

}

void ESContext::addUIAction(MKUIActionPtr ptr) {
	aLuaThread->lock();
	this->actionList.push_back(ptr);
	this->notifyUI();
	LogUtil::logInfo("download", "addUIAction : %d", actionList.getSize());
	aLuaThread->unlock();
}

void ESContext::addSyncDrawUIAction(MKUIActionPtr ptr) {
	this->syncDrawActionList.push_back(ptr);
}

void ESContext::callFun(string fun, string v) {
	MKUIActionPtr action = MKUIAction::newInstance();
	action->PNode(NULL);
	action->Fun(fun);
	action->ctx = this;
	action->prsPtr = &MKUIAction::processCallFun;
	LogUtil::logInfo("download", "callFun: begin%d", actionList.getSize());
	addUIAction(action);
	LogUtil::logInfo("download", "callFun: end%d", actionList.getSize());
}


void ESContext::callSequence(string path, MKLuaBridge* v) {
	MKUIActionPtr action = MKUIAction::createSequenceAction(path, v);
	LogUtil::logInfo("download", "callSequence begin:%d", actionList.getSize());
	addUIAction(action);
	LogUtil::logInfo("download", "callSequence end:%d", actionList.getSize());
}

void ESContext::callComplex(string fun, mk::MKLuaRefVector* v) {
	MKUIActionPtr action = MKUIAction::newInstance();
	action->PNode(NULL);
	action->Fun(fun);
	action->params = v;
	action->ctx = this;
	action->prsPtr = &MKUIAction::processCallFunComplex;
	LogUtil::logInfo("download", "callComplex begin:%d", actionList.getSize());
	addUIAction(action);
	LogUtil::logInfo("download", "callComplex end:%d", actionList.getSize());
}


void ESContext::callFunMap(string fun, MKLuaBridge* v) {
	MKUIActionPtr action = MKUIAction::newInstance();
	action->PNode(NULL);
	action->Fun(fun);
	action->mapParams = v;
	action->ctx = this;
	action->prsPtr = &MKUIAction::processCallFunMap;
	LogUtil::logInfo("download", "callFunMap begin:%d", actionList.getSize());
	addUIAction(action);
	LogUtil::logInfo("download", "callFunMap end:%d", actionList.getSize());
}

void ESContext::callFunJson(string fun, MKJson* v) {
	MKUIActionPtr action = MKUIAction::newInstance();
	action->PNode(NULL);
	action->Fun(fun);
	action->jsonParams = v;
	action->ctx = this;
	action->prsPtr = &MKUIAction::processCallFunJson;
	LogUtil::logInfo("download", "callFunJson begin:%d", actionList.getSize());
	addUIAction(action);
	LogUtil::logInfo("download", "callFunJson end:%d", actionList.getSize());
}

void ESContext::callFunJsonStr(string fun, string str) {
	MKJson* v = new MKJson(str);
	MKUIActionPtr action = MKUIAction::newInstance();
	action->PNode(NULL);
	action->Fun(fun);
	action->jsonParams = v;
	action->ctx = this;
	action->prsPtr = &MKUIAction::processCallFunJson;
	LogUtil::logInfo("download", "callFunJsonStr begin:%d", actionList.getSize());
	addUIAction(action);
	LogUtil::logInfo("download", "callFunJsonStr end:%d", actionList.getSize());
}

void ESContext::waitActionEnd(MKUIActionPtr action) {
	while(action->State()!=MKUIACTION_END) {
		mkSleep(50);
		LogUtil::logInfo("ui", "MKUIActionPtr ing");
	}
	LogUtil::logInfo("ui", "MKUIActionPtr end");
}

void ESContext::callFunSync(string fun, string v) {
	MKUIActionPtr action = MKUIAction::newInstance();
	action->PNode(NULL);
	action->Fun(fun);
	action->isSync = TRUE;
	action->ctx = this;
	action->prsPtr = &MKUIAction::processCallFun;
	LogUtil::logInfo("download", "callFunSync begin:%d", actionList.getSize());
	addUIAction(action);
	LogUtil::logInfo("download", "callFunSync end:%d", actionList.getSize());
	waitActionEnd(action);
}

void ESContext::callComplexSync(string fun, mk::MKLuaRefVector* v) {
	MKUIActionPtr action = MKUIAction::newInstance();
	action->PNode(NULL);
	action->Fun(fun);
	action->params = v;
	action->ctx = this;
	action->prsPtr = &MKUIAction::processCallFunComplex;
	LogUtil::logInfo("download", "callComplexSync begin:%d", actionList.getSize());
	addUIAction(action);
	LogUtil::logInfo("download", "callComplexSync end:%d", actionList.getSize());
	waitActionEnd(action);
}


void ESContext::callFunMapSync(string fun, MKLuaBridge* v) {
	MKUIActionPtr action = MKUIAction::newInstance();
	action->PNode(NULL);
	action->Fun(fun);
	action->mapParams = v;
	action->ctx = this;
	action->prsPtr = &MKUIAction::processCallFunMap;
	LogUtil::logInfo("download", "callFunMapSync begin:%d", actionList.getSize());
	addUIAction(action);
	LogUtil::logInfo("download", "callFunMapSync end:%d", actionList.getSize());
	waitActionEnd(action);
}

void ESContext::callFunJsonSync(string fun, MKJson* v) {
	MKUIActionPtr action = MKUIAction::newInstance();
	action->PNode(NULL);
	action->Fun(fun);
	action->jsonParams = v;
	action->ctx = this;
	action->prsPtr = &MKUIAction::processCallFunJson;
	LogUtil::logInfo("download", "callFunJsonSync begin:%d", actionList.getSize());
	addUIAction(action);
	LogUtil::logInfo("download", "callFunJsonSync end:%d", actionList.getSize());
	waitActionEnd(action);
}

void ESContext::callFunJsonStrSync(string fun, string str) {
	MKJson* v = new MKJson(str);
	MKUIActionPtr action = MKUIAction::newInstance();
	action->PNode(NULL);
	action->Fun(fun);
	action->jsonParams = v;
	action->ctx = this;
	action->prsPtr = &MKUIAction::processCallFunJson;
	LogUtil::logInfo("download", "callFunJsonStrSync begin:%d", actionList.getSize());
	addUIAction(action);
	LogUtil::logInfo("download", "callFunJsonStrSync end:%d", actionList.getSize());
	waitActionEnd(action);
}

bool flagg = true;
Texture2dApp aTexture2dApp;

void ESContext::SetFrameBufferObject(int fbowidth, int fboheight)  
{
	LogUtil::logInfo("prsimg", "SetFrameBufferObject");
	aMK2DRect2.uvFlag = 0;
	aMK2DRect2.flipV = true;
	aMK2DRect2.isRelative = FALSE;
	aMK2DRect2.loadTexture("Water2.png");

	aMK2DRect2.setPosition(0,0,0);
	aMK2DRect2.Programe("diffuseText");
	aMK2DRect2.initData();
	AtomDrawResPtr pAtomDrawRes = AtomDrawRes::instance();
	pAtomDrawRes->beginPrevDraw();

	pAtomDrawRes->setTexture(aMK2DRect2.pTexture);
	aMK2DRect2.initSizeByRes(userData->width, userData->height, pAtomDrawRes);
	pAtomDrawRes->endPrevDraw();
	aMK2DRect2.setAtomDrawRes(pAtomDrawRes);
	
	//glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

bool useShadowFlag = true;

void ESContext::drawFunc( ESContext *esContext )
{
	if (!initPhysicFlag) {
		return;
	}
	pMKBulletWorldPtr->step();
	processCallBack(esContext);
	CameraPtr cameraPtr = esContext->aCameraPtr;
	CameraPtr uiCameraPtr = esContext->uiCameraPtr;
	glBindFramebuffer ( GL_FRAMEBUFFER, 0 );
	if(cameraPtr->fboWrappPtr!=0) {
		GLenum tmpStatus = glCheckFramebufferStatus(GL_FRAMEBUFFER);
		if (tmpStatus != GL_FRAMEBUFFER_COMPLETE)
		{
			return;
		}
		float width = MKConfig::instance()->getCurrentEsContext()->userData->width;
		float height = MKConfig::instance()->getCurrentEsContext()->userData->height;	
	}
	glColorMask ( GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE );
	glClearColor( 0.0f, 0.0f, 0.0f, 1.0f );
	glEnable(GL_DEPTH_TEST);  
	esContext->processNewSprite(esContext);	
	esContext->processDynamicNewSprite(esContext);
	esContext->processFbxNewSprite(esContext);
	cameraPtr->drawSetMatrix(esContext);

	myTime.next();
	float dltTime = aMyTime.dlt()/1000.0;
	long duration = myTime.diff();
	LogUtil::logInfo("mktime", "es duration::%f", esContext->aMyTime.duration);
	GLuint fboId = cameraPtr->fboWrappPtr->getFBOId();
	cameraPtr->drawFuncBegin(esContext, fboId);
	cameraPtr->drawFunc(esContext);
	cameraPtr->drawFuncEnd(esContext);

	vbo_error3("dynamicObjs");
	map<string, ParticleSystemPtr>::iterator iter;  
	for(iter = esContext->particles.begin(); iter != esContext->particles.end(); iter++)  {
		ParticleSystemPtr ptr = iter->second;
		if(ptr->is2D) {
			continue;
		}
		ptr->process();
		if(!ptr->Enable()) {
			iter->second = NULL;
			esContext->particles.erase(iter++);
		}
	}
	vbo_error3("particles");

	//2D--------------------------------------->

	uiCameraPtr->drawFBO2DBegin(esContext);
	//nvgBeginFrame(MKConfig::instance()->getCurrentEsContext()->canvasContext->vg_, 1536, 801, 1);
	uiCameraPtr->draw2D(esContext);
	//nvgEndFrame(MKConfig::instance()->getCurrentEsContext()->canvasContext->vg_);
	uiCameraPtr->drawFBO2DEnd(esContext);
	uiCameraPtr->draw2DBegin(esContext);
	aMK2DRect2.drawTid(NULL, cameraPtr->fboWrappPtr->getTextureId());
	aMK2DRect2.drawTid(NULL, uiCameraPtr->fboWrappPtr->getTextureId());
	uiCameraPtr->draw2DEnd(esContext);
}



long ESContext::getDuration() {
	long duration = aMyTime.diff();
	return duration;
}

/************************************************************************/
/* DOWN UP CLICK                                                                     */
/************************************************************************/
string ESContext::tochUIBegin(ESContext *pEsContext, int x, int y, int mouseType, int pointerId) {
	ActivityPtr activity = this->getActivity();
	if(activity!=NULL) {
		string ret = activity->tochUIDown(pEsContext, x, y, mouseType, pointerId);
		return ret;
	}
	return "";
}

string ESContext::tochUIEnd(ESContext *pEsContext, int x, int y, int mouseType, int pointerId) {
	pEsContext->mouseState = MOUSE_UP;
	ActivityPtr activity = this->getActivity();
	if(activity!=NULL) {
		activity->touchEnd(pEsContext, x, y, MOUSE_UP, pointerId);
	}
	return "";
}

/************************************************************************/
/* MOUSE_MOVE                                                                     */
/************************************************************************/
string ESContext::tochUIMove(ESContext *pEsContext, int x, int y, MKMouseEvent event, int pointerId) {
	string ret = "";
	ActivityPtr activity = this->getActivity();
	if(activity!=NULL) {
		ret = activity->tochUIMove(pEsContext, x, y, event, pointerId);
	}
	
	pEsContext->oldX = x;
	pEsContext->oldY = y;

	return ret;
}




////////////////////////////////////////////////////////////////////////////////////
/************************************************************************/
/* DOWN UP CLICK                                                                     */
/************************************************************************/
string ESContext::toch2DBegin(ESContext *pEsContext, int x, int y, int mouseType, int pointerId) {
	LayerManagerPtr pLayerManagerPtr = this->getPLayerManager();
	if(pLayerManagerPtr!=NULL) {
		LogUtil::logInfo("2d", "pLayerManagerPtr tochUIDown 2d:%d %d", x, y);
		string ret = pLayerManagerPtr->tochUIDown(pEsContext, x, y, mouseType, pointerId);
		return ret;
	}
	return "";
}

string ESContext::toch2DEnd(ESContext *pEsContext, int x, int y, int mouseType, int pointerId) {
	pEsContext->mouseState = MOUSE_UP;
	LayerManagerPtr pLayerManagerPtr = this->getPLayerManager();
	if(pLayerManagerPtr!=NULL) {
		pLayerManagerPtr->touchEnd(pEsContext, x, y, MOUSE_UP, pointerId);
	}
	return "";
}

/************************************************************************/
/* MOUSE_MOVE                                                                     */
/************************************************************************/
string ESContext::toch2DMove(ESContext *pEsContext, int x, int y, MKMouseEvent& event, int pointerId) {
	string ret = "";
	LayerManagerPtr pLayerManagerPtr = this->getPLayerManager();
	if(pLayerManagerPtr!=NULL) {
		ret = pLayerManagerPtr->tochUIMove(pEsContext, x, y, event, pointerId);
	}

	pEsContext->old2DX = x;
	pEsContext->old2DY = y;

	return ret;
}

string ESContext::touch2DClick(ESContext *pEsContext, int x, int y, int mouseType, int pointerId) {
	string ret = "";
	LayerManagerPtr pLayerManagerPtr = this->getPLayerManager();
	if(pLayerManagerPtr!=NULL) {
		ret = activity->tochUIClick(pEsContext, x, y, mouseType, pointerId);
	}

	pEsContext->old2DX = x;
	pEsContext->old2DY = y;

	return ret;
}



vector<MKOBJSpritePtr> ESContext::findByType(ESContext *esContext, string type) {
	vector<MKOBJSpritePtr> list;
	map<string, MKOBJSpritePtr>& aMap = SpriteMap::instance->spriteMap;
	map<string,MKOBJSpritePtr>::iterator it= aMap.begin();
	for(it=aMap.begin();it!=aMap.end();++it) {
		MKOBJSpritePtr aMKOBJSpritePtr = it->second;
		string id = aMKOBJSpritePtr->id;
		if(id=="") {
			continue;
		}
		vector<string> items = mk::split(id, "_");
		if(items[0]==type) {
			list.push_back(aMKOBJSpritePtr);
		}
	}
	return list;
}


//string ESContext::isHit(ESContext *esContext, Ray& aRay) {
//	map<string, MKOBJSpritePtr>& aMap = SpriteMap::instance->spriteMap;
//	map<string,MKOBJSpritePtr>::iterator it= aMap.begin();
//	for(it=aMap.begin();it!=aMap.end();++it) {
//		MKOBJSpritePtr aMKOBJSpritePtr = it->second;
//		if(aMKOBJSpritePtr == NULL) {
//			continue;
//		}
//		BOOL flag = aMKOBJSpritePtr->isHit(aRay);
//		if(flag) {
//			return aMKOBJSpritePtr->id;
//		}
//	}
//	return "";
//}

vector<MK3DObjectPtr> ESContext::isHit(ESContext *esContext, Ray& aRay) {
	map<string, MKOBJSpritePtr>& aMap = SpriteMap::instance->dynamicSpriteMap;
	map<string,MKOBJSpritePtr>::iterator it= aMap.begin();

	vector<MK3DObjectPtr> vs = dynamicObjs;
	int len = vs.size();
	for(int i=0; i<len; i++) {
		MK3DObjectPtr aMKOBJSpritePtr = vs[i];
		if(aMKOBJSpritePtr == NULL) {
			continue;
		}
		vector<MK3DObjectPtr> ptrList;
		BOOL flag = aMKOBJSpritePtr->isHit(aRay, ptrList);
		if(flag) {
			return ptrList;
		}
	}

	int len2 = esContext->fbxObjs.size();
	vector<MK3DObjectPtr> vs2 = esContext->fbxObjs;
	MK3DObjectPtr& node = vs2.at(i);
	for (int i = 0; i < len2; i++) {
		MK3DObjectPtr aMKOBJSpritePtr = vs2[i];
		if (aMKOBJSpritePtr == NULL) {
			continue;
		}
		vector<MK3DObjectPtr> ptrList;
		BOOL flag = aMKOBJSpritePtr->isHit(aRay, ptrList);
		if (flag) {
			return ptrList;
		}
	}
	vector<MK3DObjectPtr> ptrList;
	return ptrList;

}

void ESContext::mouseWheel(ESContext *esContext, int x, int y, int zDelta) {
	return;

	if(SpriteMap::instance->selectedObj!=NULL) {
		float dltScale = 0.1;
		if(zDelta<0) {
			dltScale = -0.1;
		}
		float scale = SpriteMap::instance->selectedObj->getObj()->scale*(1.0+dltScale);
		SpriteMap::instance->selectedObj->getObj()->setScale(scale);
		return;
	}

	esContext->aCameraPtr->moveByZ(-zDelta/10);



}


void ESContext::mouseRbuttnDown(ESContext *esContext, int x, int y, int zDelta) {
	esContext->mouseState = MOUSE_RBUTTONDOWN;

}

void ESContext::mouseRbuttnUp(ESContext *esContext, int x, int y, int zDelta) {
	esContext->mouseState -= MOUSE_RBUTTONDOWN;
}


void ESContext::addUITimerById(int endTime, string id, string alive, string end) {
	LogUtil::logInfo("timer", "addUITimerById");
	ActivityPtr activityPtr = getActivity();
	if(activityPtr==NULL) {
		LogUtil::logInfo("sky", "ActivityPtr NULL");
		return;
	}
	MKUINodePtr uiPtr = activityPtr->getNode(id);
	if(uiPtr==NULL) {
		LogUtil::logInfo("sky", "uiPtr NULL");
		return;
	}
	LogUtil::logInfo("timer", "addUITimerById2");
	MKTimerPtr timer = MKTimer::instance();
	timer->setEndTime(endTime);
	timer->setMKUINodePtr(uiPtr.get());
	timer->start(alive, end);
}

void ESContext::addFbxTimerById(int endTime, string id, string alive, string end) {
	MKFBXOBJSprite* uiPtr = getSprite(id);
	if(uiPtr==NULL) {
		return;
	}
	MKTimerPtr timer = MKTimer::instance();
	timer->setEndTime(endTime);
	timer->setFbxPtr(uiPtr);
	timer->start(alive, end);
}

MKTimerPtr ESContext::addVirtualSpriteTimerById(int endTime, string id, string alive, string end) {
	MKVirtualSprite* uiPtr = getVirtualSprite(id);
	if(uiPtr==NULL) {
		LogUtil::logError("timer", "id is null:%s", id.c_str());
		return NULL;
	}
	MKTimerPtr timer = MKTimer::instance();
	timer->setEndTime(endTime);
	timer->setVirtualPtr(uiPtr);
	return timer;
}


void ESContext::addSprite2DTimer(int endTime, MK2DSprite* ptr, string alive, string end) {
	MKTimerPtr timer = MKTimer::instance();
	timer->setEndTime(endTime);
	timer->setMK2DSpritePtr(ptr);
	timer->start(alive, end);
}


void ESContext::addActvityTimer(int endTime, Activity* ptr, string alive, string end) {
	MKTimerPtr timer = MKTimer::instance();
	timer->setEndTime(endTime);
	timer->setAcitivyPtr(ptr);
	timer->start(alive, end);
}

int ESContext::download(string url, string dstPath) {
	std::string rootPath = MKConfig::instance()->MKROOT_PATH;
	dstPath = rootPath +"/" + dstPath;

	HttpDownload hdd;
	hdd.DownloadFile(url, dstPath);
	return 0;
}

void mouseWheel(ESContext *esContext, int x, int y, int zDelta) {
	esContext->mouseWheel(esContext, x,y, zDelta);
}

void mouseRbuttnDown(ESContext *esContext, int x, int y, int zDelta) {
	esContext->mouseWheel(esContext, x,y, zDelta);
}

void mouseRbuttnUp(ESContext *esContext, int x, int y, int zDelta) {
	esContext->mouseWheel(esContext, x,y, zDelta);
}

string getSpriteJSONInfo(ESContext *esContext) {
	map<string, MKOBJSpritePtr>& aMap = SpriteMap::instance->spriteMap;
	map<string,MKOBJSpritePtr>::iterator it= aMap.begin();

	string info = "";
	for(int i=0; i<esContext->objs.size(); i++) {
	MK3DObjectPtr &node = esContext->objs.at(i);
	string json = node->getJSONInfo();
	if(i>0) {
		info=info+",";
	}		
		info=info+json;
	}


	MKHttpClient aMKHttpClient;
	string url = "http://127.0.0.1:8080/test/updateTerrian.do?params="+info;
	string res;
	aMKHttpClient.get(url, res);
	return "";

}



void touchBegin(ESContext *esContext, int x, int y, int tapCount, int pointerId) {
	unsigned long tId = getThreaId();
	LogUtil::logInfo("event", "lua touchBegin %u begin", tId);
	if(esContext->is2DGame==0) {
		if(esContext->enableEvent) {
			LogUtil::logInfo("2d", "touchBegin 3d:%d %d", x, y);
			esContext->touchBegin(esContext,x,y,tapCount, pointerId);
		}
	}else {
		if(esContext->enableEvent) {
			LogUtil::logInfo("2d", "touchBegin 2d:%d %d", x, y);
			esContext->touchBegin2D(esContext,x,y,tapCount, pointerId);
		}
	}

	LogUtil::logInfo("event", "lua touchBegin %u end", tId);
}

string touchMove(ESContext *esContext, int x, int y, int tapCount, int pointerId) {
	unsigned long tId = getThreaId();
	LogUtil::logInfo("lua", "lua touchMove %u begin", tId);
	string ret = "";
	if(esContext->is2DGame==0) {
		if(esContext->enableEvent) {
			ret =  esContext->touchMove(esContext,x,y,tapCount, pointerId);
		}
	}else {
		if(esContext->enableEvent) {
			ret =  esContext->touchMove2D(esContext,x,y,tapCount, pointerId);
		}
	}

	LogUtil::logInfo("lua", "lua touchMove %u end", tId);
	return ret;
}

void touchEnd(ESContext *esContext, int x, int y, int tapCount, int pointerId) {
	unsigned long tId = getThreaId();
	LogUtil::logInfo("lua", "lua touchEnd %u begin", tId);

	if(esContext->is2DGame==0) {
		if(esContext->enableEvent) {
			esContext->touchEnd(esContext,x,y,tapCount, pointerId);
		}
	}else {
		if(esContext->enableEvent) {
			esContext->touchEnd2D(esContext,x,y,tapCount, pointerId);
		}
	}



	LogUtil::logInfo("lua", "lua touchEnd %u end", tId);
}

string touchClick(ESContext *esContext, int x, int y, int tapCount, int pointerId) {
	unsigned long tId = getThreaId();
	string ret = "";
	LogUtil::logInfo("lua", "lua touchClick %u begin", tId);
	if(esContext->is2DGame==0) {
		if(esContext->enableEvent) {
			ret =  esContext->touchClick(esContext,x,y,tapCount, pointerId);
		}
	}else {
		if(esContext->enableEvent) {
			esContext->touchClick2D(esContext,x,y,tapCount, pointerId);
		}
	}

	LogUtil::logInfo("lua", "lua touchClick %u end", tId);

	return ret;
}

void loadScene(string url, ESContext *esContext) {	
	esContext->loadScene(url, esContext);
}

/************************************************************************/
/*touchClick                                                           */
/************************************************************************/
string ESContext::touchClick(ESContext *esContext, int x, int y, int tapCount, int pointerId) {

	//2D
	ActivityPtr activity = this->getActivity();
	if(activity!=NULL) {
		string uiId = activity->tochUIClick(esContext, x, y, MOUSE_CLICK, pointerId);
		if(uiId!="") {
			string message = "{t:\"ui\", id:\""+uiId+"\"}";
			return message;
		}		
	}

	MKUINodePtr curMouseOn = ViewManager::instance()->currentMouseOnUI;
	if(curMouseOn!=NULL && !curMouseOn->IsVirtual()) {
		return "";
	}

	//3D
	esContext->userData->toucheX = x;
	esContext->userData->toucheY = esContext->userData->height - y;
	vec3 location;
	if( GFX_unproject(
		esContext->userData->toucheX,
		esContext->userData->toucheY,
		1.0f,
		GFX_get_modelview_matrix(),
		GFX_get_projection_matrix(),
		viewport_matrix,
		&location.x,
		&location.y,
		&location.z  ) ) {
			LogUtil::logInfo("event", "Touch location:%f %f %f\r\n", location.x, location.y, location.z);
	}
	
	vec3 mPosition = aCameraPtr->getV3Position();
	float eX = mPosition.x;
	float eY = mPosition.y;
	float eZ = mPosition.z;


	//the ground click position
	vec3 v0 = esContext->aCameraPtr->getV3Position();
	vec3 v1  = location;
	vec3 ret = {0,0,0};
	vec3LerpByY(v0,v1,ret);

	Json::Value root;

	Vector3 origin(eX, eY, eZ);
	Vector3 direction(location.x-eX, location.y-eY, location.z-eZ);
	Ray aRay(origin, direction); 

	for(int i=0; i<esContext->dynamicObjs.size(); i++) {
		MK3DObjectPtr &node = esContext->dynamicObjs.at(i);
		string uiId = node->tochUIClick(esContext, x, y, MOUSE_CLICK, pointerId);
		if(uiId!="") {
			root["obj_ui"] = uiId;
			string message = root.toStyledString();
			return message;
		}
	}
	for(int i=0; i<esContext->fbxObjs.size(); i++) {
		MK3DObjectPtr &node = esContext->fbxObjs.at(i);
		string uiId = node->tochUIClick(esContext, x, y, MOUSE_CLICK, pointerId);
		if(uiId!="") {
			root["dobj_ui"] = uiId;
			string message = root.toStyledString();
			return message;
		}
	}

	vector<MK3DObjectPtr> hitIds = esContext->isHit(esContext, aRay);
	if(hitIds.size()>0) {
		Json::Value ids;
		for(int k=0; k<hitIds.size(); k++) {
			MK3DObjectPtr ptr = hitIds[k];
			ids.append(ptr->getID());
			string script = ptr->getClickFun();
			ESContext* esContext = MKConfig::instance()->getCurrentEsContext();
			if(script!="") {
				esContext->call1<string>(script.c_str(), ptr.get());
			}
			ptr->onClickbehavior();
		}
		root["objs"] = ids;
	}

	if(root==Json::nullValue) {
		return "";
	}
	string message = root.toStyledString();
	return message;
}


/************************************************************************/
/*   
MOUSE_DOWN for pc
finger touch(down) for phone
																   */
/************************************************************************/
void ESContext::touchBegin2D(ESContext *esContext, int x, int y, int tapCount, int pointerId) {
	setCurrentThreadNoPoolNode();
	LogUtil::logInfo("mmv", "touchBegin2D");
	esContext->mouseState = MOUSE_DOWN;
	//2D
	string uiId = esContext->tochUIBegin(esContext, x, y, MOUSE_DOWN, pointerId);
	if(uiId!="") {
		string message = "{t:\"ui\", id:\""+uiId+"\"}";	
		return;
	}
	//2D
	uiId = esContext->toch2DBegin(esContext, x, y, MOUSE_DOWN, pointerId);
	if(uiId!="") {
		string message = "{t:\"ui\", id:\""+uiId+"\"}";	
		//reloadScene(esContext);
		return;
	}
}

void ESContext::touchEnd2D(ESContext *esContext, int x, int y, int tapCount, int pointerId) {
	esContext->mouseState = MOUSE_UP;

	string uiId = esContext->tochUIEnd(esContext, x, y, MOUSE_DOWN, pointerId);
	if(uiId!="") {
		string message = "{t:\"ui\", id:\""+uiId+"\"}";	
		return;
	}

	
	esContext->toch2DEnd(esContext, x, y, MOUSE_UP, pointerId);
}

void ESContext::touchClick2D(ESContext *esContext, int x, int y, int tapCount, int pointerId) {
	esContext->mouseState = MOUSE_UP;

	ActivityPtr activity = this->getActivity();
	if(activity!=NULL) {
		string uiId = activity->tochUIClick(esContext, x, y, MOUSE_CLICK, pointerId);
		if(uiId!="") {
			string message = "{t:\"ui\", id:\""+uiId+"\"}";
			return;
		}		
	}

	MKUINodePtr curMouseOn = ViewManager::instance()->currentMouseOnUI;
	if(curMouseOn!=NULL && !curMouseOn->IsVirtual()) {
		return;
	}

	
	esContext->touch2DClick(esContext, x, y, MOUSE_UP, pointerId);
}

string ESContext::touchMove2D(ESContext *esContext, int x, int y, int scrollY, int pointerId) {
	esContext->mouseState |= MOUSE_MOVE;

	if(esContext->mouseState&MOUSE_RBUTTONDOWN) {
		int dltX = esContext->oldX-x;
		int dltY = esContext->oldY-y;
		float dlt = 0.1;
		Vector2 vt(dltX, dltY);
		esContext->old2DX = x;
		esContext->old2DY = y;
		return "";
	}

	MKMouseEvent event2 = {x, y, esContext->mouseState};
	event2.scrollY =scrollY;
	esContext->tochUIMove(esContext, x, y, event2, pointerId);


	MKMouseEvent event = {x, y, esContext->mouseState};
	event.scrollY =scrollY;
	esContext->toch2DMove(esContext, x, y, event, pointerId);

	string ret = "";
	if(onLuaMouseMove!="") {
		ret = esContext->call1<string>(onLuaMouseMove.c_str(), this);
		if(ret!="") {
			return ret;
		}
	}

	return "";
}
/////////////////////////////////////////////////////////////////////////////////////////////




/************************************************************************/
/*   
MOUSE_DOWN for pc
finger touch(down) for phone
																   */
/************************************************************************/
void ESContext::touchBegin(ESContext *esContext, int x, int y, int tapCount, int pointerId) {
	setCurrentThreadNoPoolNode();
	esContext->mouseState = MOUSE_DOWN;
	//2D
	string uiId = esContext->tochUIBegin(esContext, x, y, MOUSE_DOWN, pointerId);
	if(uiId!="") {
		string message = "{t:\"ui\", id:\""+uiId+"\"}";	
		//reloadScene(esContext);
		return;
	}
	//3D
	esContext->userData->toucheX = x;
	esContext->userData->toucheY = esContext->userData->height - y;
	vec3 location;
	if( GFX_unproject( 
		esContext->userData->toucheX,
		esContext->userData->toucheY,
		1.0f,
		GFX_get_modelview_matrix(),
		GFX_get_projection_matrix(),
		viewport_matrix,
		&location.x,
		&location.y,
		&location.z  ) ) {
			esLogMessage("touch location:%f %f %f\r\n", location.x, location.y, location.z);
	}

	vec3 mPosition = aCameraPtr->getV3Position();
	float eX = mPosition.x;
	float eY = mPosition.y;
	float eZ = mPosition.z;

	Vector3 origin(eX, eY, eZ);
	Vector3 direction(location.x-eX, location.y-eY, location.z-eZ);
	Ray aRay(origin, direction);


	//vector<MK3DObjectPtr> hitIds = esContext->isHit(esContext, aRay);

	//int pageX = getPageIdx(eX);
	//int pageZ = getPageIdx(eZ);
	//ScenePtr aScenePtr = esContext->getCurrentScene();
	//aScenePtr->pMKTerriansPtr->refresh(pageX,pageZ);
	for(int i=0; i<esContext->dynamicObjs.size(); i++) {
		MK3DObjectPtr &node = esContext->dynamicObjs.at(i);
		node->tochUIDown(esContext, x, y, MOUSE_DOWN, pointerId);
	}
	for(int i=0; i<esContext->fbxObjs.size(); i++) {
		MK3DObjectPtr &node = esContext->fbxObjs.at(i);
		node->tochUIDown(esContext, x, y, MOUSE_DOWN, pointerId);
	}

	Json::Value root;
	vector<MK3DObjectPtr> hitIds = esContext->isHit(esContext, aRay);
	if (hitIds.size() > 0) {
		Json::Value ids;
		for (int k = 0; k < hitIds.size(); k++) {
			MK3DObjectPtr ptr = hitIds[k];
			ids.append(ptr->getID());
			ESContext* esContext = MKConfig::instance()->getCurrentEsContext();
			ptr->onMouseDownbehavior();
		}
		root["objs"] = ids;
	}
	if (root == Json::nullValue) {
		//return "";
	}
	string message = root.toStyledString();
	//return message;
}

void ESContext::touchEnd(ESContext *esContext, int x, int y, int tapCount, int pointerId) {
	esContext->mouseState = MOUSE_UP;
	esContext->tochUIEnd(esContext, x, y, MOUSE_UP, pointerId);


	for(int i=0; i<esContext->dynamicObjs.size(); i++) {
		MK3DObjectPtr &node = esContext->dynamicObjs.at(i);
		node->touchEnd(esContext, x, y, MOUSE_UP, pointerId);
	}
	for(int i=0; i<esContext->fbxObjs.size(); i++) {
		MK3DObjectPtr &node = esContext->fbxObjs.at(i);
		node->touchEnd(esContext, x, y, MOUSE_UP, pointerId);
	}
}

void ESContext::setPositionByCamera() {
	if(aMKSkyPtr==NULL || this->aCameraPtr == NULL) {
		LogUtil::logInfo("sky", "setPositionByCamera NULL");
		return;
	}
	//if(this->aCameraPtr->mPosition.x<-1000) {
	//	int a = 0;
	//}
	vec3 mPosition = aCameraPtr->getV3Position();
	LogUtil::logInfo("sky", "setPositionByCamera %f %f", mPosition.x,  mPosition.z);
	this->aMKSkyPtr->setPosition(mPosition.x, -100, mPosition.z);

}

string ESContext::touchMove(ESContext *esContext, int x, int y, int scrollY, int pointerId) {
	esContext->mouseState |= MOUSE_MOVE;

	if(esContext->mouseState&MOUSE_RBUTTONDOWN) {
		int dltX = esContext->oldX-x;
		int dltY = esContext->oldY-y;
		float dlt = 0.1;
		Vector2 vt(dltX, dltY);
		vt.normalise();
		esContext->aCameraPtr->moveByXZ(vt.x*dlt, vt.y*dlt);
		esContext->oldX = x;
		esContext->oldY = y;
		return "";
	}

	MKMouseEvent event = {x, y, esContext->mouseState};
	event.scrollY =scrollY;
	esContext->tochUIMove(esContext, x, y, event, pointerId);
	//3D
	{
		esContext->userData->toucheX = x;
		esContext->userData->toucheY = esContext->userData->height - y;
		vec3 location;
		if (GFX_unproject(
			esContext->userData->toucheX,
			esContext->userData->toucheY,
			1.0f,
			GFX_get_modelview_matrix(),
			GFX_get_projection_matrix(),
			viewport_matrix,
			&location.x,
			&location.y,
			&location.z)) {
			esLogMessage("touch location:%f %f %f\r\n", location.x, location.y, location.z);
		}

		vec3 mPosition = aCameraPtr->getV3Position();
		float eX = mPosition.x;
		float eY = mPosition.y;
		float eZ = mPosition.z;

		Vector3 origin(eX, eY, eZ);
		Vector3 direction(location.x - eX, location.y - eY, location.z - eZ);
		Ray aRay(origin, direction);

		Json::Value root;
		vector<MK3DObjectPtr> hitIds = esContext->isHit(esContext, aRay);
		if (hitIds.size() > 0) {
			Json::Value ids;
			for (int k = 0; k < hitIds.size(); k++) {
				MK3DObjectPtr ptr = hitIds[k];
				ids.append(ptr->getID());
				ESContext* esContext = MKConfig::instance()->getCurrentEsContext();
				ptr->onMouseMovebehavior();
			}
			root["objs"] = ids;
		}
		if (root == Json::nullValue) {
			//return "";
		}
		string message = root.toStyledString();
		//return message;
		//
	}
///////////////////////////////////////////////////////////////////////////////

	setPositionByCamera();
	//for word flag
	SpriteMapPtr spriteMapInst = SpriteMap::instance;
	map<string, MKOBJSpritePtr> spriteMap = spriteMapInst->spriteMap;
	vec3 mPosition = aCameraPtr->getV3Position();
	float cameraX = mPosition.x;
	float cameraZ = mPosition.z;

	float eX = mPosition.x;
	float eZ = mPosition.z;
	int pageX = getPageIdx(eX);
	int pageZ = getPageIdx(eZ);
	ScenePtr aScenePtr = esContext->getCurrentScene();
	if(aScenePtr && aScenePtr->pMKTerriansPtr) {
		aScenePtr->pMKTerriansPtr->refresh(pageX,pageZ);
	}

	//lua
	string ret = "";
	if(onLuaMouseMove!="") {
		ret = esContext->call1<string>(onLuaMouseMove.c_str(), this);
		if(ret!="") {
			return ret;
		}
	}

	return "";
}

int getPosition(ESContext *context, string id) {
	for(int i=0; i<context->objs.size(); i++) {
		MK3DObjectPtr &node = context->objs.at(i);
		if(node->id==id) {
			return i;
		}
	}
	return -1;
}

void removeParticle(ESContext *pEsContext, string id) {
	pEsContext->removeParticle(id);
}

void processParticle(ESContext *pEsContext, string content) {

}


void ESContext::attachParticleByPos(ParticleSystem* particleSystemPtr, float x, float y, float z, float scale, BOOL canRotate) {
	string id = particleSystemPtr->id;
	ParticleSystemPtr aParticleSystemPtr = ParticleManager::m_pInstance->getObj(id);
	if(aParticleSystemPtr==NULL) {
		return;
	}
	aParticleSystemPtr->setPosition(x,y,z);
	aParticleSystemPtr->scale = scale;
	aParticleSystemPtr->canRotate = canRotate;

	aParticleSystemPtr->enable = TRUE;
	addParticle(aParticleSystemPtr);
}


MKTexture* ESContext::creatTexture(string filename) {
	LogUtil::logInfo("https", "creatTexture file %s ", filename.c_str());
	MKTexturePtr aMKTexturePtr = TextureCache::instance->getTexture(filename);
	if(aMKTexturePtr) {
		int a=0;
		//LogUtil::logInfo("mat", "OBJ_add_texture file %s from cache", filename);
	}else {
		TEXTURE* temp= NULL;
		temp = TEXTURE_init( (char*)filename.c_str() );
		temp->notInverse = 1;
		aMKTexturePtr = MKTexture::newInstance();
		aMKTexturePtr->setTexture(temp);
		TextureCache::instance->put(filename, aMKTexturePtr);
		aMKTexturePtr->OBJ_build_textureCommon((char*)"", TEXTURE_MIPMAP | TEXTURE_16_BITS, TEXTURE_FILTER_2X, 0.0f );
		glFinish();
		LogUtil::logInfo("https", "OBJ_add_texture file %s ", filename.c_str());
	}

	return aMKTexturePtr.get();

}


MK3DObjectPtr get3DObject(string id, ESContext *context) {
	MK3DObjectPtr ptr = SpriteMap::instance->getObj(id);	
	if(ptr!=NULL) {
		return ptr;
	}
	MK3DObjectPtr ptr2 = SpriteMap::instance->getDynamicObj(id);	
	if(ptr2!=NULL) {
		return ptr2;
	}
	if(MKConfig::instance()->isTerrianProject) {
		shared_ptr<MKTerrians> spritePtr = dynamic_pointer_cast<MKTerrians>(context->objs.at(0));
		if(spritePtr->id==id) {
			return spritePtr;
		}
	}

	return NULL;
}
void ESContext::removeSprite(string id) {
	LogUtil::logInfo("bullet", "removeSprite begin:%s", id.c_str());

	ESContext *context = this;
	MK3DObjectPtr ptr = get3DObject(id,context);
	if(ptr==NULL) {
		return;
	}
	SpriteMap::instance->deleteSprite(id);
	//MK3DObjectPtr parentPtr = get3DObject(ptr->parentId, context);
	//if(parentPtr!=NULL) {
	//	parentPtr->removeChild(id);
	//}else {
	//	context->removeObjSprite(id, context);
	//}
	context->removeObjSprite(id, context);
	//context->pMKBulletWorldPtr->remove(ptr.get());
	LogUtil::logInfo("bullet", "removeSprite end");
}

void processSprite(string content,  ESContext *context) {

	Json::Reader reader;
	Json::Value val;
	if(!reader.parse(content, val, false)) {
		return;
	}

	LogUtil::logInfo("thread", "processParticle:%s", content.c_str());
	string cmd = val["type"].asString();
	if(cmd=="visible") {
		string id = val["id"].asString();
		int value = val["value"].asInt();
		MK3DObjectPtr ptr = SpriteMap::instance->getObj(id);	
		if(ptr==NULL) {
			return;
		}
		ptr->IsObjVisible(value);
	}
}


void removeSpriteAmbs(string id, ESContext *context) {
	LogUtil::logInfo("thread", id.c_str());
	vector<string> retIds;
	SpriteMap::instance->getSpritesIdAmbs(id, retIds);
	for(int i=0; i<retIds.size(); i++) {
		string delId = retIds.at(i);
		context->deleteCommands.push_back(delId);
	}
}

void newSprite(string content, ESContext *context) {
	SpriteManagerPtr pSpriteManager = SpriteManager::newInstance();	
	MKOBJSpritePtr pMKOBJSpritePtr = pSpriteManager->getSpriteFromStr(content);
	context->getCurrentScene()->addObject(pMKOBJSpritePtr);
}

string luaCommand(string cmd, string content, ESContext *context) {
	string ret = "";
	if(content!="") {
		LogUtil::logInfo("lua", "processCommendLuaFromJava:%s", content.c_str());
		ret = context->call1<string>(cmd.c_str(), content.c_str());
	}
	LogUtil::logInfo("lua", "processCommendLuaFromJava ret: %s", ret.c_str());
	return ret;
}


void newSpritesUseLocalFile(string content, ESContext *context) {
	string splitFlag = "&";
	vector<string> strs = mk::split(content, splitFlag);
	int len = strs.size();
	for(int i=0; i<len;i++) {
		string objFile =  strs[i];
		string objStr = FileUtil::readContent(objFile);
		processCommend(context, "newSprite", objStr);
	}
}

void ESContext::reloadScene(ESContext *esContext) {
	//begin loadscene
	if(canUnloadScene==FALSE) {
		LogUtil::logInfo("download", "canUnloadScene FALSE");
		return;
	}
	canUnloadScene = FALSE;
	LogUtil::logInfo("download", "canUnloadSceneFlag FALSE");
	clearScene();
	loadScene("02/xx/scene6.txt", esContext);
	//end load scene
}


string formatInt(float v) {
	char a[10];
	sprintf(a, "%.2f", v);
	return a;
}

MKLuaBridge* ESContext::getExt() const{
	return pMKLuaBridgePtr.get();
}

void ESContext::setExt(MKLuaBridge* ptr) {
}

void ESContext::setEditText(string id, string v) {
	MKEditorTextPtr posXView = dynamic_pointer_cast<MKEditorText>(getViewManager()->getNode(id));
	if(posXView!=NULL) {
		MKOBJSpritePtr selectedMKOBJSpritePtr = SpriteMap::instance->selectedObj;			
		posXView->setText(v);
	}
}

void ESContext::setEditText(string id, float v) {
	MKEditorTextPtr posXView = dynamic_pointer_cast<MKEditorText>(getViewManager()->getNode(id));
	if(posXView!=NULL) {
		MKOBJSpritePtr selectedMKOBJSpritePtr = SpriteMap::instance->selectedObj;			
		posXView->setText(formatInt(v));
	}
}




LUAContextPtr ESContext::getLUAContext(string name) {
	LUANode* pNode = pLUAPoolList->pop();
	return pNode;
}


void ESContext::putLUAContext() {
	pLUAPoolList->push();
}

void ESContext::putLUAContext(string name, LUAContextPtr pLUAContextPtr) {
	this->luaMap.push_back(pLUAContextPtr);

}


void ESContext::addBean(){
}

MKTerrians* ESContext::getTerrains() {
	return terriansPtr.get();
}

void ESContext::clearScene() {

	LogUtil::logInfo("obj", "clearScene begin:%d", objs.size());

	if(aSpriteInitThread!=NULL) {
		ScenePtr aScene = aSpriteInitThread->CurrentScene();
		LogUtil::logInfo("obj", "clearScene3:%d", objs.size());
		if(aScene!=NULL) {
			aScene->RunFlag(FALSE);
			aScene->unload();
		}
	}

	clearVector(beans);
	clearVector(objs);
	clearVector(dynamicObjs);
	clearVector(fbxObjs);
	

	SpriteMap::instance->clear();
	aSpriteInitThread->currentScene->clearMaterial();
	aSpriteInitThread->CurrentScene(NULL);
	pMKBulletWorldPtr->unload();
	//aSpriteInitThread = NULL;

	//clear texture
	//////////////////////////////
	map<string,MKTexturePtr>& textMap= TextureCache::instance->textureMap;
	map<string,MKTexturePtr>::iterator it;
	for(it=textMap.begin();it!=textMap.end();++it) {
		MKTexturePtr aMKTexturePtr = it->second;
		aMKTexturePtr->deleteTexture2();
	}
	MKThreadLocal::clear();
	freeBullet();
	LogUtil::logInfo("obj", "clearScene5 end");

}

void ESContext::freeBullet() {
	pMKBulletWorldPtr = NULL;
}

void ESContext::removeObjSprite(string id, ESContext *esContext) {
	//remove this loop
	LogUtil::logInfo("bullet", "removeObjSprite begin:%s", id.c_str());
	for ( vector<MK3DObjectPtr>::iterator it = dynamicObjs.begin(); it != dynamicObjs.end();  )  
	{
		MK3DObjectPtr aMKOBJSpritePtr = *it; 
		string keyId = aMKOBJSpritePtr->id;
		if (id==keyId) {
			it = dynamicObjs.erase( it );
			LogUtil::logInfo("bullet", "removeObjSprite OK:%s", id.c_str());
		}else  {
			++it;
		}
	}
	LogUtil::logInfo("bullet", "removeObjSprite end");

	//for ( vector<MK3DObjectPtr>::iterator it = objs.begin(); it != objs.end();  )  
	//{
	//	MK3DObjectPtr aMKOBJSpritePtr = *it; 
	//	string keyId = aMKOBJSpritePtr->id;
	//	if (id==keyId) {
	//		it = objs.erase( it );
	//	}else  {
	//		++it;
	//	}
	//}
}

void ESContext::removeObjSpriteFromTerrian(string id, ESContext *esContext) {
	//remove this loop
	shared_ptr<MKTerrians> spritePtr = dynamic_pointer_cast<MKTerrians>(objs.at(0));
	vector<MKOBJSpritePtr> terObjs = spritePtr->objs;
	for ( vector<MKOBJSpritePtr>::iterator it = terObjs.begin(); it != terObjs.end();  )  
	{
		MKOBJSpritePtr aMKOBJSpritePtr = *it; 
		string keyId = aMKOBJSpritePtr->id;
		if (id==keyId) {
			it = terObjs.erase( it );
		}else  {
			++it;
		}
	}
}


void ESContext::clearSpriteMap() {
	map<string, MKOBJSpritePtr>& spriteMap = SpriteMap::instance->spriteMap;
	for (map<string,MKOBJSpritePtr>::iterator it = spriteMap.begin(); it != spriteMap.end(); ++it)  
	{
		MKOBJSpritePtr aMKOBJSpritePtr = it->second;
		aMKOBJSpritePtr->clear();
	}

	map<string, MKOBJSpritePtr>& dynamicSpriteMap = SpriteMap::instance->dynamicSpriteMap;
	for (map<string,MKOBJSpritePtr>::iterator it = dynamicSpriteMap.begin(); it != dynamicSpriteMap.end(); ++it)  
	{
		MKOBJSpritePtr aMKOBJSpritePtr = it->second;
		aMKOBJSpritePtr->clear();
	}

	map<string, MKFBXOBJSpritePtr>& spriteFBXMap = SpriteMap::instance->spriteFBXMap;
	for (map<string,MKFBXOBJSpritePtr>::iterator it = spriteFBXMap.begin(); it != spriteFBXMap.end(); ++it)  
	{
		MKFBXOBJSpritePtr aMKOBJSpritePtr = it->second;
		aMKOBJSpritePtr->clear();
	}
	
}

void ESContext::clearSprite(vector<MK3DObjectPtr>& objList) {
	for(int i=0; i<objList.size(); i++) {
		objList.at(i)->clear();
	}
	clearVector(objList);
}

void ESContext::clear(ESContext *esContext) {
	templateFbx.clear();

	exitFlag = TRUE;
	enableEvent = FALSE;
	if(pObjMergeManagerPtr) {
		pObjMergeManagerPtr = NULL;
	}
	LogUtil::logInfo("memory", "clear begin");

	if(this->pPacketProcessThread!=NULL) {
		pPacketProcessThread->InitFlag(FALSE);
		pPacketProcessThread = NULL;
	}

	if(terriansPtr!=NULL) {
		terriansPtr->clear();
		terriansPtr = NULL;
	}
	if(aSpriteInitThread!=NULL) {
		ScenePtr aScene = aSpriteInitThread->CurrentScene();
		LogUtil::logInfo("shader", "clearScene3:%d", objs.size());
		if(aScene!=NULL) {
			aScene->RunFlag(FALSE);
			aScene->unload();
		}
		aSpriteInitThread->preExit();
	}
	if(aLuaThread) {
		aLuaThread->preExit();
	}
	if(aTimerThread) {
		aTimerThread->preExit();
	}
	if(aLuaCallBackThread) {
		aLuaCallBackThread->preExit();
	}

	MKFontManager::instance()->unloadFont();
	LogUtil::logInfo("mmemory", "unloadFont end");

	MaterialCache::instance->clear();

	clearSpriteMap();
	LogUtil::logInfo("memory", "scene unload end");
	SpriteMap::instance->spriteMap.clear();
	SpriteMap::instance->dynamicSpriteMap.clear();
	SpriteMap::instance->spriteFBXMap.clear();
	SpriteMap::instance->clear();
	LogUtil::logInfo("memory", "spriteMap clear");

	for(int i=0; i<fbxObjs.size(); i++) {
		MK3DObjectPtr ptr = fbxObjs.at(i);
		MKFBXOBJSpritePtr fbxPtr = dynamic_pointer_cast<MKFBXOBJSprite>(ptr);
		fbxPtr->clear();
		int a = 0;
	}

	clearSprite(beans);
	clearSprite(objs);
	clearSprite(dynamicObjs);
	clearSprite(fbxObjs);
	if(heroPtr!=NULL) {
		heroPtr = NULL;
	}
	LogUtil::logInfo("memory", "objs clear");
	aDownloadManager.finish();

	aSpriteInitThread->currentScene->RunFlag(FALSE);
	aSpriteInitThread->currentScene->clearMaterial();
	aSpriteInitThread->CurrentScene(NULL);
	
	pLayerManager = NULL;
	MKThreadLocal::clear();

	//clear texture
	//////////////////////////////
	map<string,MKTexturePtr>& textMap= TextureCache::instance->textureMap;
	map<string,MKTexturePtr>::iterator it;
	for(it=textMap.begin();it!=textMap.end();++it) {
		MKTexturePtr aMKTexturePtr = it->second;
		aMKTexturePtr->deleteTexture2();
	}
	LogUtil::logInfo("scene", "texture clear");

	
	//particles
	clearParticles();
	if(luaInstance!=NULL) {
		lua_State* luaContext = luaInstance->luaContext;
		luaInstance = NULL;
		if(luaContext!=NULL) {
			lua_close(luaContext);
		}
	}
	MyShaderProp::maxBindingPoint = 0;
	pLUAPoolList->exit();

	LogUtil::logInfo("memory", "clear end");

}



void ESContext::loadScene(string url, ESContext *esContext) {
	esContext->aSpriteInitThread = NULL;
	esContext->aSpriteInitThread = SpriteInitThread::newInstance();
	esContext->aSpriteInitThread->setScene(url);
	esContext->aSpriteInitThread->start();
}

void ESContext::run(int flag) {
	this->aMyTime.setIsStop(!flag);
}

int ESContext::isStop() {
	BOOL flag = this->aMyTime.getIsStop();
	return flag;
}

void ESContext::notifyUI() {
	aLuaThread->notify();
}


Member* ESContext::getMember() {
	Member* ptr = MKConfig::instance()->member;
	return ptr;
}

long ESContext::getUID() {
	Member* ptr = MKConfig::instance()->member;
	if(ptr) {
		return ptr->getUid();
	}
	return 0;
}


MKFBXOBJSpritePtr ESContext::clone(string id, string path) {
	MKFBXOBJSpritePtr ptr = templateFbx[path];
	if(ptr==NULL) {
		return NULL;
	}
	MKFBXOBJSpritePtr clonePtr = ptr->clone(path, id);
	return clonePtr;
}

PMKFBXOBJSprite ESContext::lua_clone(string id, string path) {
	MKFBXOBJSpritePtr ptr = clone(id, path);
	return ptr.get();
}

MKFBXOBJSpritePtr ESContext::getFbxTemplate(string path) {
	MKFBXOBJSpritePtr ptr = templateFbx[path];
	return ptr;
}

CameraPtr ESContext::AMKShadowPtr(string cameraId) {
	CameraPtr aCameraPtr =  cameraMap[cameraId];
	if(aCameraPtr == nullptr) {
		aCameraPtr = Camera::defaultCamera;
	}
	return aCameraPtr;
}
CameraPtr ESContext::AMKShadowPtr(MK3DObjectPtr objPtr) {
	string cameraId = objPtr->shadowCamera;
	if(cameraId!="") {
		return AMKShadowPtr(cameraId);
	}else {
		return AMKShadowPtr();
	}
}


void mkExit(ESContext *esContext) {



	LogUtil::logInfo("mmemory", "mkExit begin");

	esContext->clear(esContext);

	
	if(esContext->activityManagerPtr) {
		esContext->activityManagerPtr->destroy();
		esContext->activityManagerPtr = NULL;
	}

	MKConfig::instance()->clear();

	
	
	if (esContext->userData != NULL )
	{
		free ( esContext->userData );
	}

	//CursorManager::m_pInstance = NULL;


	//exit other
	SpriteMap::instance=NULL;

	//curl_global_cleanup();

	LogUtil::logInfo("mmemory", "mkExit end");

}



int surfaceDestroyed(ESContext *pEsContext) {
	pEsContext->surfaceDestroyed(pEsContext);
	return 0;

}

int ESContext::surfaceDestroyed(ESContext *pEsContext) {
	//LogUtil::logInfo("shader", "surfaceDestroyed begin");

	//pEsContext->aVideoState.isSurfaceDestroyed = 1;


	//TODO


	//LogUtil::logInfo("shader", "surfaceDestroyed end");
	return 0;
}

int surfaceCreated(ESContext *pEsContext) {
	return 0;
}

int ESContext::surfaceCreated(ESContext *pEsContext) {

	return 0;
}




void setVideoFilePos(ESContext *esContext, unsigned int pos) {
	
}

int getVideoState(ESContext *pEsContext) {
	return pEsContext->aVideoState.playState;
}

int getDuration(ESContext *esContext) {
	return esContext->aVideoState.duration;
}

int getCurrentTime(ESContext *esContext) {
	return esContext->aVideoState.currentTime;
}

void processUserDataFromJava(ESContext *pEsContext, string content) {
	pEsContext->userContent = content;
	processUserData(pEsContext);
}

void processCommendFromJava(ESContext *pEsContext, string cmd, string content) {
	processCommend(pEsContext, cmd, content);
}

void processCommendFromJavaMain(ESContext *pEsContext, string cmd, string content) {

	
	//LogUtil::logInfo("mk", "processCommendFromJavaMain begin");

	MKLuaBridge* pMKLuaBridge = pEsContext->getExt();
	MKJson* pMKJson = new MKJson();
	pMKJson->setValue(content);
	//string id = pMKJson->getString("id");
	//pMKLuaBridge->setMKJsonPtr(cmd, pMKJson);
	//pMKLuaBridge->setString("cnt", content);
	//LogUtil::logInfo("content", "processCommendFromJavaMain end");

}

string processCommendLuaFromJava(ESContext *pEsContext, string cmd, string content) {
	return processCommendLua(pEsContext, cmd, content);
}

void yawFromJava(ESContext *pEsContext, float angle) {
	pEsContext->aCameraPtr->yaw(angle);
}

void rollFromJava(ESContext *pEsContext, float angle) {
	pEsContext->aCameraPtr->roll(angle);
}

void processCommendsFromJava(ESContext *pEsContext, string content) {
	string cmd = "";
	Json::Reader reader;
	Json::Value commands;
	if(!reader.parse(content,commands, false)) {
		return;
	}
	//---------------------------------------
	for(int i=0; i<commands.size(); i++) {
		Json::Value command = commands[i];
		if(command==Json::nullValue) {
			continue;
		}
		cmd = command["cmd"].asString();
		string cmdContent = command["content"].toStyledString();
		processCommend(pEsContext, cmd, cmdContent);
	}
	
}



void processConfigFromExternal(string content) {
	Json::Reader reader;
	Json::Value val;
	if(!reader.parse(content, val, false)) {
		return;
	}
	string mkAPKPath = val["mkAPKPath"].asString();
	string mkRootPath = val["rootPath"].asString();
	string mkPrjPath = val["prjPath"].asString();
	string httpRoot = val["httpRoot"].asString();
	BOOL isTerrian = val["isTerrian"].asInt();
	BOOL game2D =  val["2d"].asInt();
	BOOL isVR =  val["isVR"].asInt();
	string scene2d =  getString(val, "scene2d");

	MKConfig::LOG_PATH = mkRootPath;
	MKConfig::MK_APK_PATH = mkAPKPath;
	MKConfig::instance()->MKROOT_PATH = mkRootPath;
	MKConfig::instance()->MKPRJ_PATH = mkPrjPath;
	MKConfig::instance()->HTTP_ROOT_PATH = httpRoot;
	MKConfig::instance()->isTerrianProject = isTerrian;
	MKConfig::instance()->isVR = isVR;
	MKConfig::instance()->scene2d = scene2d;
	MKConfig::instance()->is2DGame = game2D;
	MKConfig::instance()->getCurrentEsContext()->is2DGame = MKConfig::instance()->is2DGame;

	MKConfig::instance()->getCurrentEsContext()->scene2d = scene2d;

	LogUtil::logInfo("mat", "MKROOT_PATH:%s", mkRootPath.c_str());
	LogUtil::logInfo("mat", "MKPRJ_PATH:%s", mkPrjPath.c_str());
}

/************************************************************************/
/* newSprites use localfile                                             */
/************************************************************************/
void processCommend(ESContext *pEsContext, string cmd, string content) {
	if(cmd=="lua") {
		luaCommand(cmd, content, pEsContext);
	}else if(cmd=="newSprite") {
		newSprite(content, pEsContext);
	}else if(cmd=="newSprites") {
		newSpritesUseLocalFile(content, pEsContext);
	}else if(cmd=="sprite") {
		processSprite(content, pEsContext);
	}else if(cmd=="removeSpAmbs") {
		vector<string> items = mk::split(content, "&");
		for(int i=0; i<items.size(); i++) {			
			removeSpriteAmbs(items.at(i), pEsContext);
		}
	}else if(cmd=="resetData") {
		LogUtil::logInfo("thread", "data reset");
		pEsContext->resetCommands.push_back(content);
	}else if(cmd=="setUIValue") {
		LogUtil::logInfo("thread", "data reset");
		Json::Reader reader;
		Json::Value val;
		if(!reader.parse(content, val, false)) {
			return;
		}
		string id = val["id"].asString();
		string value = val["value"].asString();
		ActivityPtr activityPtr = pEsContext->getActivity();
		shared_ptr<MKLabel> uiPtr = dynamic_pointer_cast<MKLabel>(activityPtr->getNode(id));
		uiPtr->setTextByAction(value);
	}else if(cmd=="particle") {		
		LogUtil::logInfo("thread", "addLevel:%s", content.c_str());
		pEsContext->particleCommands.push_back(content);
	}else if(cmd=="vr") {
		Json::Reader reader;
		Json::Value val;
		if(!reader.parse(content, val, false)) {
			return;
		}
		int isVR = val["isVR"].asInt();
		pEsContext->isVR = isVR;
	}
}


string processCommendLua(ESContext *pEsContext, string cmd, string content) {
	return luaCommand(cmd, content, pEsContext);
}

void setLevel(ESContext *pEsContext, string level) {

}


void processUserData(ESContext *pEsContext) {

}


float slorp(float x, float x1, float x2, float y1, float y2) {
	float y = y1+(y2-y1)*(x-x1)/(x2-x1);
	return y;
}

void processExam(ESContext *pEsContext, Json::Value exam) {

	Json::Value items =  exam["data"];
	for(int i=0; i<items.size(); i++) {
		Json::Value item = items[i];
		MKBeanPtr beanPtr = MKBean::newInstance();
		beanPtr->createAttrWithJSON(item);
		pEsContext->words.push_back(beanPtr);
	}
}

void setScene(ESContext *esContext, float time2) {
	ParticleManagerPtr pParticleManager = ParticleManager::instance();

 	Json::Reader reader;
	Json::Value val;
	if(!reader.parse(esContext->userContent, val, false)) {
		return;
	}
	
	//scene
	Json::Value sceneAddr = val["sceneAddr"];
	if(sceneAddr!=Json::nullValue) {
		esContext->sceneAddr = sceneAddr.asString();
		LogUtil::logInfo("mksce", "setScene url:%s", esContext->sceneAddr.c_str());
	}else {
		LogUtil::logError("mksce", "setScene url null");
	}

	Json::Value gameAddr = val["gameAddr"];
	if(gameAddr!=Json::nullValue) {
		esContext->gameAddr = gameAddr.asString();
		LogUtil::logInfo("mksce", "gameAddr url:%s", esContext->gameAddr.c_str());
	}else {
		LogUtil::logError("mksce", "gameAddr url null");
	}


	MKConfig::instance()->member->loadFromJson(val["member"]);
	MKConfig::instance()->member->setVariable(val);
	return;


	//headimg begin
	string headImg = "";
	headImg = getStringWithDef(val, "headImg", "");
	ActivityPtr activityPtr = esContext->getActivity();
	if(headImg!="") {
		MKUINodePtr node = activityPtr->getNode("head_icon");
		node->setBackground(headImg);
	}
	//headimg end

	
}




int setUserDataFromJava(ESContext *pEsContext, string content) {
	pEsContext->userContent = content;
	return 0;
}




//########################################################
void keyFunc(ESContext *esContext, unsigned char key, int, int )  {
	esContext->keyFunc(esContext, key, 0, 0 );
}

void ESContext::keyFunc(ESContext *esContext, unsigned char key, int, int ) {
	float dlt = 0.5;
	float dlt2 = 1.5;


	if(key=='S') {
		esContext->aCameraPtr->moveByZ(+dlt);
	}else if(key=='W') {
		//EGLNativeWindowType  eglNativeWindow =MKConfig::instance()->getCurrentEsContext()->eglNativeWindow;
		//MKConfig::instance()->setContext(new Perspective());
		//MKConfig::instance()->getCurrentEsContext()->eglNativeWindow = eglNativeWindow;

		esContext->aCameraPtr->moveByZ(-dlt);
	}else if(key=='A') {
		esContext->aCameraPtr->moveByX(-dlt);
	}else if(key=='D') {
		esContext->aCameraPtr->moveByX(dlt);
	}else if(key== 27) {
		MKConfig::instance()->done = TRUE;
	}else if(key== '&') {//UP
		esContext->aCameraPtr->moveByY(-dlt2);
	}else if(key== '(') {//DWN
		esContext->aCameraPtr->moveByY(+dlt2);
	}else if(key== '%') {//LEFT
		esContext->aCameraPtr->moveByX(-dlt2);
	}else if(key== ',') {//RIGHT
		esContext->aCameraPtr->moveByZ(+dlt2);
	}
	


	
	//MKUINodePtr aMKUINodePtr = CursorManager::instance()->NodePtr();
	//if(aMKUINodePtr!=NULL) {
	//	shared_ptr<MKEditorText> aMKEditorText = dynamic_pointer_cast<MKEditorText>(aMKUINodePtr);
	//	string ds = aMKEditorText->getText();
	//	aMKEditorText->appendChar(-1, (char)key);
	//}

	setPositionByCamera();

	////esLogMessage("eye location:%f %f %f\r\n", origin.x, origin.y, origin.z);

	//printf("%c\r\n", key);
}

void keyFunc2(ESContext *esContext, unsigned char key, int, int ) {
	esContext->keyFunc2(esContext, key, 0, 0);
}


void ESContext::keyFunc2(ESContext *esContext, unsigned char key, int, int ) {
	float dlt = 2.5;
	float dlt2 = 1.5;

	if(key=='S') {
		esContext->aCameraPtr->moveByZ(dlt);// mPosition.z+=dlt;
	}else if(key=='W') {
		esContext->aCameraPtr->moveByZ(-dlt);
	}else if(key=='A') {
		esContext->aCameraPtr->moveByX(-dlt);
	}else if(key=='D') {
		esContext->aCameraPtr->moveByX(dlt);
	}else if(key== 27) {
		MKConfig::instance()->done = TRUE;
		return;
	}else if(key== '&') {//UP
		esContext->aCameraPtr->moveByY(-dlt2);
	}else if(key== '(') {//DWN
		esContext->aCameraPtr->moveByY(dlt2);
	}else if(key== '%') {//LEFT
		esContext->aCameraPtr->moveByX(-dlt2);
	}else if(key== ',') {//RIGHT
		esContext->aCameraPtr->moveByX(dlt2);
	}

	vec3 centerDltVec = esContext->aCameraPtr->centerDltVec;

	vec3 e = esContext->aCameraPtr->getV3Position();
	vec3 c = {e.x+centerDltVec.x, e.y+centerDltVec.y, e.z+centerDltVec.z};
	esContext->aCameraPtr->centerVec = c;

	if(activityManagerPtr!=NULL) {
		ActivityPtr aActivityPtr = activityManagerPtr->currentActivity();
		if(aActivityPtr!=NULL) {
			aActivityPtr->keyFunc(esContext, key, 0, 0);
		}
	}

	setPositionByCamera();
}

void shutdownFunc( ) {
}

void  updateFunc(ESContext *esContext, float deltaTime ) {
}



GLboolean esCreateWindow ( ESContext *esContext, const char *title, GLint width, GLint height, GLuint flags ) {
	return esContext->esCreateWindow(esContext, title, width, height, flags);
}

GLboolean ESContext::esCreateWindow ( ESContext *esContext, const char *title, GLint width, GLint height, GLuint flags )
{
#ifndef __APPLE__
	//EGLConfig config;
	EGLint majorVersion;
	EGLint minorVersion;
	EGLint contextAttribs[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };

	if ( esContext == NULL )
	{
		return GL_FALSE;
	}

#ifdef ANDROID
	// For Android, get the width/height from the window rather than what the
	// application requested.
	esContext->userData->width = ANativeWindow_getWidth ( esContext->eglNativeWindow );
	esContext->userData->height = ANativeWindow_getHeight ( esContext->eglNativeWindow );
#else
#endif


	esContext->eglDisplay = eglGetDisplay( esContext->eglNativeDisplay );
	if ( esContext->eglDisplay == EGL_NO_DISPLAY )
	{
		return GL_FALSE;
	}
	if ( !eglInitialize ( esContext->eglDisplay, &majorVersion, &minorVersion ) )
	{
		return GL_FALSE;
	}
	LogUtil::logError("err", "eglInitialize v:%d, %d", (int)minorVersion, (int)majorVersion);

	{
		EGLint numConfigs = 0;
		if ( ! eglGetConfigs( esContext->eglDisplay, NULL, 0, &numConfigs ) )
		{
			return FALSE;
		}

		EGLint attribList[64];
		BuildAttribList(attribList);
		if ( !eglChooseConfig ( esContext->eglDisplay, attribList, &config, 1, &numConfigs ) )
		{
			return GL_FALSE;
		}
		if ( numConfigs < 1 )
		{
			return GL_FALSE;
		}
	}


#ifdef ANDROID
	// For Android, need to get the EGL_NATIVE_VISUAL_ID and set it using ANativeWindow_setBuffersGeometry
	{
		EGLint format = 0;
		eglGetConfigAttrib ( esContext->eglDisplay, config, EGL_NATIVE_VISUAL_ID, &format );
		ANativeWindow_setBuffersGeometry ( esContext->eglNativeWindow, 0, 0, format );
	}
#endif // ANDROID

	// Create a surface
	esContext->eglSurface = eglCreateWindowSurface ( esContext->eglDisplay, config, esContext->eglNativeWindow, NULL );
	if ( esContext->eglSurface == EGL_NO_SURFACE )
	{
		return GL_FALSE;
	}

	// Create a GL context
	esContext->eglContext = eglCreateContext ( esContext->eglDisplay, config, EGL_NO_CONTEXT, contextAttribs );
	if ( esContext->eglContext == EGL_NO_CONTEXT )
	{
		return GL_FALSE;
	}
	

	// Make the context current
	if ( !eglMakeCurrent ( esContext->eglDisplay, esContext->eglSurface, esContext->eglSurface, esContext->eglContext ) )
	{
		int a = 0;
		a++;
		return GL_FALSE;
	}


#endif // #ifndef __APPLE__

	return GL_TRUE;
}


void ESContext::load_physic_world( void )
{

	
}


//shadow

#define POSITION_LOC    0
#define COLOR_LOC       1




GLuint ESUTIL_API esLoadShader ( GLenum type, const char *shaderSrc )
{
	GLuint shader;
	GLint compiled;

	shader = glCreateShader ( type );

	if ( shader == 0 )
	{
		return 0;
	}

	// Load the shader source
	glShaderSource ( shader, 1, &shaderSrc, NULL );

	// Compile the shader
	glCompileShader ( shader );

	// Check the compile status
	glGetShaderiv ( shader, GL_COMPILE_STATUS, &compiled );

	if ( !compiled )
	{
		GLint infoLen = 0;

		glGetShaderiv ( shader, GL_INFO_LOG_LENGTH, &infoLen );

		if ( infoLen > 1 )
		{
			char *infoLog = (char*)malloc ( sizeof ( char ) * infoLen );

			glGetShaderInfoLog ( shader, infoLen, NULL, infoLog );
			esLogMessage ( "Error compiling shader:\n%s\n", infoLog );

			free ( infoLog );
		}

		glDeleteShader ( shader );
		return 0;
	}

	return shader;

}



GLuint esLoadProgram ( const char *vertShaderSrc, const char *fragShaderSrc )
{
	GLuint vertexShader;
	GLuint fragmentShader;
	GLuint programObject;
	GLint linked;

	vertexShader = esLoadShader ( GL_VERTEX_SHADER, vertShaderSrc );

	if ( vertexShader == 0 )
	{
		return 0;
	}

	fragmentShader = esLoadShader ( GL_FRAGMENT_SHADER, fragShaderSrc );

	if ( fragmentShader == 0 )
	{
		glDeleteShader ( vertexShader );
		return 0;
	}

	// Create the program object
	programObject = glCreateProgram ( );

	if ( programObject == 0 )
	{
		return 0;
	}

	glAttachShader ( programObject, vertexShader );
	glAttachShader ( programObject, fragmentShader );

	glLinkProgram ( programObject );
	glGetProgramiv ( programObject, GL_LINK_STATUS, &linked );
	if ( !linked )
	{
		GLint infoLen = 0;

		glGetProgramiv ( programObject, GL_INFO_LOG_LENGTH, &infoLen );

		if ( infoLen > 1 )
		{
			char *infoLog = (char*)malloc ( sizeof ( char ) * infoLen );

			glGetProgramInfoLog ( programObject, infoLen, NULL, infoLog );
			esLogMessage ( "Error linking program:\n%s\n", infoLog );

			free ( infoLog );
		}

		glDeleteProgram ( programObject );
		return 0;
	}

	glDeleteShader ( vertexShader );
	glDeleteShader ( fragmentShader );

	return programObject;
}




void logMatrixES(string flag, ESMatrix mat) {
	LogUtil::logInfo(flag, "%.4f %.4f %.4f %.4f", mat.m[0][0], mat.m[1][0], mat.m[2][0], mat.m[3][0]);
	LogUtil::logInfo(flag, "%.4f %.4f %.4f %.4f", mat.m[0][1], mat.m[1][1], mat.m[2][1], mat.m[3][1]);
	LogUtil::logInfo(flag, "%.4f %.4f %.4f %.4f", mat.m[0][2], mat.m[1][2], mat.m[2][2], mat.m[3][2]);
	LogUtil::logInfo(flag, "%.4f %.4f %.4f %.4f", mat.m[0][3], mat.m[1][3], mat.m[2][3], mat.m[3][3]);
}


void setShadow(UserData *userData ) {

}

void toMatrix(mat4* v, ESMatrix& aESMatrix) {
	v->m[0].x= aESMatrix.m[0][0];
	v->m[0].y= aESMatrix.m[0][1];
	v->m[0].z= aESMatrix.m[0][2];
	v->m[0].w= aESMatrix.m[0][3];

	v->m[1].x= aESMatrix.m[1][0];
	v->m[1].y= aESMatrix.m[1][1];
	v->m[1].z= aESMatrix.m[1][2];
	v->m[1].w= aESMatrix.m[1][3];

	v->m[2].x= aESMatrix.m[2][0];
	v->m[2].y= aESMatrix.m[2][1];
	v->m[2].z= aESMatrix.m[2][2];
	v->m[2].w= aESMatrix.m[2][3];

	v->m[3].x= aESMatrix.m[3][0];
	v->m[3].y= aESMatrix.m[3][1];
	v->m[3].z= aESMatrix.m[3][2];
	v->m[3].w= aESMatrix.m[3][3];
}

ESMatrix toEsMatrix(mat4 * v) {
	ESMatrix aESMatrix;
	aESMatrix.m[0][0] = v->m[0].x;
	aESMatrix.m[0][1] = v->m[0].y;
	aESMatrix.m[0][2] = v->m[0].z;
	aESMatrix.m[0][3] = v->m[0].w;

	aESMatrix.m[1][0] = v->m[1].x;
	aESMatrix.m[1][1] = v->m[1].y;
	aESMatrix.m[1][2] = v->m[1].z;
	aESMatrix.m[1][3] = v->m[1].w;

	aESMatrix.m[2][0] = v->m[2].x;
	aESMatrix.m[2][1] = v->m[2].y;
	aESMatrix.m[2][2] = v->m[2].z;
	aESMatrix.m[2][3] = v->m[2].w;

	aESMatrix.m[3][0] = v->m[3].x;
	aESMatrix.m[3][1] = v->m[3].y;
	aESMatrix.m[3][2] = v->m[3].z;
	aESMatrix.m[3][3] = v->m[3].w;

	return aESMatrix;
}


//for callback lua
void ESContext::addRequestPacket(RequestPacket* pPacket) {
	//pRequestPoolPtr->add(pPacket);
	aLuaCallBackThread->addPacket(pPacket);
}

RequestPool* ESContext::getRequestPool() { 
	if(pRequestPoolPtr==NULL) {
		pRequestPoolPtr = new RequestPool();
	}
	return pRequestPoolPtr; 
}

MKLabel* ESContext::getLabel(string id) {
	ActivityPtr activityPtr = this->getActivity();
	shared_ptr<MKLabel> uiPtr = dynamic_pointer_cast<MKLabel>(activityPtr->getNode(id));
	return uiPtr.get();
}


void ESContext::setSky(MKOBJSprite* sky) {
	this->aMKSkyPtr = sky->getThis();
}

void ESContext::addPacket(MKPacketPtr ptr) {
	aSpriteInitThread->addPacket(ptr);
}

QJSNode* ESContext::newQJSNode(ESContext* ctx) {
	QJSNode* luaInstance = QJSNode::newInstance();
	luaInstance->esContext = ctx;
	luaInstance->init();
	return luaInstance;
}


///////////////////////////////////////////////////////////////////
//#include "LuaPool.h"
//#include "LUAContext.h"
//#include "ESContext.h"

string LuaPool::DRAW_NODE = "DRAW_NODE";
string LuaPool::EVENT_NODE= "EVENT_NODE";
string LuaPool::GLCTX_NODE= "GLCTX_NODE";

Member::Member():
uid(0),
name(""),
accessToken(""),
expValue(0),
coin(0),
img(""),
liveValue(0)
{

}
void Member::init() {
	pMKLuaBridgePtr = MKLuaBridge::newInstance();
}


void Member::setVariable(Json::Value val) {
	variable = new MKJson();
	variable->Value(val);
}

void Member::loadFromJson(Json::Value v) {
	getInt(v, "uid", uid);
	getInt(v, "sex", sex);
	getInt(v, "coin", coin);
	getInt(v, "expValue", expValue);
	getInt(v, "liveValue", liveValue);
	name = getUTF8StringValue(v, "name");
	img = getUTF8StringValue(v, "img");
	accessToken = getString(v, "appToken");
	liveValue = getInt(v, "liveValue");
	magicValue = getInt(v, "magicValue");
	powerValue = getInt(v, "powerValue");
	speedValue = getInt(v, "speedValue");
	vip = getInt(v, "vip");
}

void Member::updateFromJson(Json::Value v) {
	getInt(v, "uid", uid);
	getInt(v, "coin", coin);
	getInt(v, "expValue", expValue);
	getInt(v, "liveValue", liveValue);
	UTF8String aname = getUTF8StringValue(v, "name");
	if(aname!="") {
		name = aname;
	}
	UTF8String aimg = getUTF8StringValue(v, "img");
	if(aimg!="") {
		img = aimg;
	}
}


LuaPool::LuaPool(int capacity){
	header = NULL;
	tail = NULL;
	last = NULL;
	this->capacity = capacity;
	size = 0;	
}


LuaPool::~LuaPool() {

}

void LuaPool::init() {
	int size = 10;
	for (int i = 0; i < capacity; i++) {
		addInit(NULL);
	}
	tail = header;
	size = 0;
}


void LuaPool::printInfo() {
	WrapperNode<LUANode*>* c = header;
	while (c!=NULL)
	{
		if (c->t == NULL) {
			printf("NULL ");
		}
		else {
			printf("%p ", c->t);
		}

		c = c->next;
	}
	printf("\n");
}

void LuaPool::addInit(LUANode* nd) {
	WrapperNode<LUANode*>* node = new WrapperNode<LUANode*>(nd);
	if (header == NULL) {
		header = node;
		last = header;
		tail = header;
		return;
	}

	last->next = node;
	node->prev = last;
	last = last->next;

}

LUANode* LuaPool::popSync() {
	lock();
	LUANode* nd = pop();
	unlock();
	return nd;
}

LUANode* LuaPool::pop() {
	if(size==0) {
		LogUtil::logInfo("lua", "LuaPool::pop return NULL");
		return NULL;
	}
	LUANode* ret = tail->t;
	tail->clear();
	tail = tail->prev;
	size--;
	if(ret->getBorrowCount()!=0) {
		LogUtil::logError("lua", "LuaPool::pop() borrow count is error");
	}
	return ret;

}

void LuaPool::push(LUANode* nd) {
	if(size==capacity) {
		return;
	}
	if (header->isNull()) {
		header->t = nd;
		tail = header;
		size++;
		return;
	}
	tail = tail->next;
	tail->t = nd;
	size++;

}

void LuaPool::pushSync(LUANode* nd) {
	lock();
	push(nd);
	unlock();
}

void LuaPool::pushInit(LUANode* nd) {
	if(size==capacity) {
		return;
	}
	nd->reset();
	if (header->isNull()) {
		header->t = nd;
		tail = header;
		size++;
		return;
	}

	tail = tail->next;
	tail->t = nd;
	size++;

}




void LuaPool::lock() {
	mutex.enter();
}

void LuaPool::unlock() {
	mutex.leave();
}

LuaPoolList::LuaPoolList(int capacity, int poolCapacity) {
	this->capacity = capacity;
	this->poolCapacity = poolCapacity;
	noPoolIdx = 0;
}

LuaPoolList::~LuaPoolList() {
	for(int i=0; i<capacity; i++) {
		LuaPool* item = list.at(i);
		delete item;
	}
	clearVector(list);
}

void LuaPoolList::pushNoPool(LUANode* nd) {
	nd->isPoolNode = FALSE;
	namedList.push_back(nd);
}

void LuaPoolList::pushNoPool() {
	LUANode* nd = newNode(this->context);
	nd->isPoolNode = FALSE;
	namedList.push_back(nd);
}

void LuaPoolList::exit() {
	for(int i=0; i<namedList.size(); i++) {
		LUANode* nd = namedList.at(i);
		nd->exit();
	}
}

LUANode* LuaPoolList::getNoPool() {
	LUANode* ret = NULL;
	if(noPoolIdx>=namedList.size()) {
		LogUtil::logInfo("lua","lua error getNoPool noPoolIdx>=namedList.size()");
		pushNoPool();
		//return NULL;
	}
	ret = namedList[noPoolIdx];
	noPoolIdx++;
	return ret;
}

//for each thread begin code
void LuaPoolList::setCurrentThreadNoPoolNode() {
	LUANode* nd = (LUANode*)MKThreadLocal::getAttr("lua");
	if(nd!=NULL) {
		return;
	}
	LUANode* ret = getNoPool();
	MKThreadLocal::setAttr("lua", ret);
}


LUANode* LuaPoolList::newNode(ESContext* ctx) {
	LUANode* luaInstance = LUANode::newInstance();
	luaInstance->esContext = ctx;
	luaInstance->init();
	return luaInstance;
}



void LuaPoolList::init(ESContext* ctx) {
	this->Context(ctx);

	//pushNoPool(newNode(ctx));
	//pushNoPool(newNode(ctx));
	//pushNoPool(newNode(ctx));
	//pushNoPool(newNode(ctx));

	///////////////////////////////////////////////
	for (int i = 0; i < capacity; i++) {
		LuaPool* pool = new LuaPool(poolCapacity);
		pool->init();
		list.push_back(pool);
	}
	for (int i = 0; i < capacity; i++) {
		LuaPool* pool = list.at(i);
		for(int j=0; j<poolCapacity; j++) {
			LUANode* luaInstance = LUANode::newInstance();
			luaInstance->esContext = ctx;
			luaInstance->init();
			pool->pushInit(luaInstance);
			//luabridge::setGlobal(luaInstance->luaContext, luaInstance, "luaContext");
			//luabridge::setGlobal(luaInstance->luaContext, luaInstance->esContext, "ctx");
			
		}
	}

	////QuickjsContext
	//QJSNode* qjsInstance = QJSNode::newInstance();
	//qjsInstance->init();
}

void LuaPoolList::push(LUANode* nd) {
	unsigned long tId = getThreaId();
	int idx = tId%capacity;
	LuaPool* pool = list.at(idx);
	pool->pushSync(nd);
}

void LuaPoolList::push() {
	LUANode* nd = (LUANode*)MKThreadLocal::getAttr("lua");
	unsigned long tId = getThreaId();
	if(nd==NULL) {
		LogUtil::logInfo("lua", "lua push, error node not exist, tId:%u, nd==NULL", tId);
		return;
	}
	nd->give();
	if(nd->getBorrowCount()>0) {
		LogUtil::logInfo("lua", "lua push, tId:%u node:%p borrowCount:%d isPool:%d ", tId, nd, nd->getBorrowCount(), nd->isPoolNode);
		return;
	}
	if(!nd->isPoolNode) {
		LogUtil::logInfo("lua", "lua push real(no pool), tId:%u node:%p, borrowCount:%d ", tId, nd, nd->getBorrowCount());
		return;
	}
	int idx = tId%capacity;
	LuaPool* pool = list.at(idx);
	pool->pushSync(nd);
	LogUtil::logInfo("lua", "lua push real(pool), tId:%u idx:%d node:%p, borrowCount:%d ", tId, idx, nd, nd->getBorrowCount());
	MKThreadLocal::setAttr("lua", NULL);
}


LUANode* LuaPoolList::pop() {
	LUANode* nd = (LUANode*)MKThreadLocal::getAttr("lua");
	unsigned long tId = getThreaId();
	if(nd!=NULL) {
		nd->borrow();
		LogUtil::logInfo("lua", "lua pop, exist tId:%u, node:%p borrowCount:%d pool:%d", tId, nd, nd->getBorrowCount(), nd->isPoolNode);
		return nd;
	}
	if(capacity==0) {
		LogUtil::logError("lua", "lua pop, no node tId:%u", tId);
		return nd;
	}

	int idx = tId%capacity;
	LuaPool* pool = list.at(idx);
	LUANode* node = pool->popSync();
	if(node!=NULL) {
		node->borrow();
		MKThreadLocal::setAttr("lua", node);
		LogUtil::logInfo("lua", "lua pop(pool), tId:%u idx:%d node:%p borrowCount:%d ", tId, idx, node, node->getBorrowCount());
	}else {
		LogUtil::logInfo("lua", "lua pop, error no node tId:%u idx:%d node:%p", tId, idx, NULL);
	}
	
	return node;
}



void LuaPoolList::printInfo() {
	for(int i=0; i<capacity; i++) {
		LuaPool* item = list.at(i);
		printf("\n--------------:%d\n", i);
		item->printInfo();
	}
}
