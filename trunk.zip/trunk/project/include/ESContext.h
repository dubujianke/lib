
#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include "MKCommon.h"
#include "MKVBOSprite.h"
#include "MKOBJSprite.h"
#include "MKTerrain.h"
#include "MKTerrians.h"

#include "MKVerticle3DRect.h"
#include "MKSky.h"
#include "MKSphere.h"
#include "Camera.h"
#include "particle/Vector3.h"
#include "engine/MKVideoCommon.h"
#include "Graphics.h"
#include "MKLine.h"
#include "CoordinaSystem.h"
#include "Graphics.h"
#include "MK3DRect.h"
#include "SpriteInitThread.h"
#include "SpriteMap.h"
#include "net/DownloadManager.h"
#include "MyEpoch.h"
#include "MyTime.h"
#include "MKPanel.h"
#include "shareptr.h"
#include "ViewManager.h"
#include "MKButton.h"
#include "MKBrush.h"
#include "MK2DRect.h"
#include "ui/MKTextPanel.h"
#include "MKGraphic.h"
#include "Scene.h"
#include "particle/renderer/ParticleRender.h"
#include "particle/ParticleSystem.h"
#include "SpriteAddThread.h"
#include "BillboardOBJSprite.h"
#include "MKFBXOBJSprite.h"
#include "ui/Activity.h"
#include "ui/ActivityManager.h"
#include "MKFBOTexture.h"
#include "MKFBO2DRect.h"
#include "ui/MKFBOImg.h"
#include "mk/MKMutex.h"
#include "particle/OgreBillboard.h"
#include "particle/OgreBillboardSet.h"
#include "MKCyleList.h"
#include "MKUIAction.h"
#include "MyTime.h"
#include "LUAContext.h"
#include "QuickjsContext.h"
#include "LuaThread.h"
#include "MKBean.h"
#include "esTransform.h"
#include "MKShadow.h"
#include "call/RequestPool.h"
#include "LuaCallBackThread.h"
#include "LuaBridge.h"
#include "MKBulletWorld.h"
#include "MKPacket.h"
#include "MKPacketQueue.h"
#include "MKPacketQueueManager.h"
#include "mk/MKMutex.h"
#include <al.h>
#include <alc.h>
#include "MyTime.h"
#include "mk/SyncValue.h"

class Canvas;
class NVGcontext;
class MK2DSprite;
typedef shared_ptr<MK2DSprite> MK2DSpritePtr;

class LayerManager;
typedef shared_ptr<LayerManager> LayerManagerPtr;

class Mp3Play;
typedef Mp3Play* Mp3PlayPtr;

class MKFbo;
typedef shared_ptr<MKFbo> MKFboPtr;

class MKClass;

//class MKPacket;
//typedef MKPacket* MKPacketPtr;
#include "PacketProcessThread.h"
//class Perspective;
class ESContext;

class ObjMergeManager;
typedef shared_ptr<ObjMergeManager> ObjMergeManagerPtr;

#define GAME_INIT 0
#define GAME_LIVE 2
#define GAME_END  3


void playMp3(string url, string dir, string fileName);
void playMp3UTF(UTF8String url, string dir, string fileName);
float getAngleFromX(float x, float z);
float getAngle2(float x, float z, float x2, float z2);
float getAngle(vec2 a, vec2 b);
void addSetIntPacket(string prsFun, string objId, string propName, int v);
void addSetStringPacket(string prsFun, string objId, string propName, string v);
void addSetFloatPacket(string prsFun, string objId, string propName, float v);
void setUIImage(string id, string path);
void setUIFloat(string id, string prop, float v);
float getUIFloat(string id, string prop);

void setUIBOOL(string id, string prop, BOOL v);
BOOL getUIBOOL(string id, string prop);

void setUIString(string id, string prop, string v);
string getUIString(string id, string prop);
MKVirtualSprite* toVirtual(MK3DObject* ptr);
void testLUA(luabridge::LuaRef aRef);
long getMsTime();
long getMiTime();
BOOL isStopWorld();
float getMKFloat(string v);
float getDPFloat(int v);
void stopWorld();
void resumeWorld();
void addSprite2DTimer(string id, int endTime, MK2DSprite* data, string begin, string alive, string end, string endNotify, MKLuaBridge* param);
void addUITimer(int endTime, MKUINode* data, string alive, string end);
void addUITimerById(int endTime, string id, string alive, string end);
void addFbxTimerById(int endTime, string id, string alive, string end);
MKTimer* addVirtualSpriteTimerById(int endTime, string id, string alive, string end);
void addActvityTimer(int endTime, Activity* id, string alive, string end);
Activity* getActivity();
MKUINode* getUINode(string id);
MKProgressbar* getProgressBar(string id);
MKFbxSpriteActionPtr getIdelAction(MKPacketPtr ptr);
MKFbxSpriteActionPtr getWalkAction(MKPacketPtr ptr);
MKFbxSpriteActionPtr getAtkAction(MKPacketPtr ptr);
MKFbxSpriteActionPtr getSetAttrAction(MKPacketPtr ptr);
typedef MKFbxSpriteActionPtr (*PacketDecodeFun)(MKPacketPtr ptr);

#define TERRIAN_WIDTH 1024
MKFBXOBJSprite* getSprite(string id);
MKVirtualSprite* getVirtualSprite(string id);
void setGString(string propName, string v);
void setGInt(string propName, int v);
void setGFloat(string propName, float v);
void setGUTF8String(string propName, UTF8String v);
string setGString(string propName);
int setGInt(string propName);
float setGFloat(string propName);

void drawFunc( ESContext *esContext);
void drawVideo( ESContext *esContext );
void shutdownFunc();
void keyFunc(ESContext *esContext, unsigned char, int, int );
void keyFunc2(ESContext *esContext, unsigned char key, int, int );
void updateFunc(ESContext *esContext, float deltaTime );
string getSpriteJSONInfo(ESContext *esContext);
void touchBegin(ESContext *esContext, int x, int y, int tapCount, int pointerId);
string touchMove(ESContext *esContext, int x, int y, int tapCount, int pointerId);
void touchEnd(ESContext *esContext, int x, int y, int tapCount, int pointerId);
string touchClick(ESContext *esContext, int x, int y, int tapCount, int pointerId);


GLboolean esCreateWindow (ESContext *esContext, const char *title, GLint width, GLint height, GLuint flags );
int Init(ESContext *esContext);
int InitSize(ESContext *esContext);
int InitResource(ESContext *esContext);
int InitSurface(ESContext *esContext);

int setScreenDensity(ESContext *esContext, int density);
int InitPrograme(ESContext *esContext);
int InitAudioDevice(ESContext *esContext);
int createPrograme(ESContext *esContext, char * vertex, char * fragment);
//###############################################################################
float slorp(float x, float x1, float x2, float y1, float y2);
int setUserDataFromJava(ESContext *pEsContext, string content);
void processUserData(ESContext *pEsContext);
void setLevel(ESContext *pEsContext, string level);
string luaCommand(string cmd, string content, ESContext *context);
void newSprite(string content, ESContext *context);
MK3DObjectPtr get3DObject(string id, ESContext *context);
void processSprite(string content, ESContext *context);
void removeParticle(ESContext *pEsContext, string id);
void processParticle(ESContext *pEsContext, string content);
void processCommend(ESContext *pEsContext, string cmd, string content);
string processCommendLua(ESContext *pEsContext, string cmd, string content);
void setScene(ESContext *pEsContext, float time);
void processExam(ESContext *pEsContext, Json::Value exam);
void processUserDataFromJava(ESContext *pEsContext, string content);
void processCommendFromJava(ESContext *pEsContext, string cmd, string content);
void processCommendFromJavaMain(ESContext *pEsContext, string cmd, string content);
string processCommendLuaFromJava(ESContext *pEsContext, string cmd, string content);
void processCommendsFromJava(ESContext *pEsContext, string contents);
void yawFromJava(ESContext *pEsContext, float angle);
void rollFromJava(ESContext *pEsContext, float angle);
void processConfigFromExternal(string content);
int surfaceDestroyed(ESContext *esContext);
int getVideoState(ESContext *esContext);
int surfaceCreated(ESContext *esContext);
void setVideoFilePos(ESContext *esContext, unsigned int pos);
int getDuration(ESContext *esContext);
int getCurrentTime(ESContext *esContext);
//###############################################################################
void clear(ESContext *esContext);
void loadScene(string url, ESContext *esContext);
void mkExit(ESContext *esContext);
typedef shared_ptr<ESContext> ESContextPtr;


//shadow begin
ESMatrix toEsMatrix(mat4 * v);
void toMatrix(mat4 * v, ESMatrix& aESMatrix);
GLuint ESUTIL_API esLoadShader ( GLenum type, const char *shaderSrc );
GLuint ESUTIL_API esLoadProgram ( const char *vertShaderSrc, const char *fragShaderSrc );
int esGenCube ( float scale, GLfloat **vertices, GLfloat **normals, GLfloat **texCoords, GLuint **indices );
int esGenSquareGrid ( int size, GLfloat **vertices, GLuint **indices );
//shadow end

void processLuaPacket(RequestPacket* pRequestPacket);

/////////////////////////////////////////////////////////////
class Member {
public:
	int uid;
	int sex;

	Member();
	string accessToken;

	UTF8String name;
	UTF8String img;
	int coin;
	int expValue;
	int dimand;
	int liveValue;

	int magicValue;
	int getMagicValue() const { return magicValue; }
	void setMagicValue(int val) { magicValue = val; }
	
	int powerValue;
	int getPowerValue() const { return powerValue; }
	void setPowerValue(int val) { powerValue = val; }
	
	int speedValue;
	int getSpeedValue() const { return speedValue; }
	void setSpeedValue(int val) { speedValue = val; }

	int protectValue;
	int getProtectValue() const { return protectValue; }
	void setProtectValue(int val) { protectValue = val; }

	int energyValue;
	int getEnergyValue() const { return energyValue; }
	void setEnergyValue(int val) { energyValue = val; }



	int maxLiveValue;
	int getMaxLiveValue() const { return maxLiveValue; }
	void setMaxLiveValue(int val) { maxLiveValue = val; }

	int maxMagicValue;
	int getMaxMagicValue() const { return maxMagicValue; }
	void setMaxMagicValue(int val) { maxMagicValue = val; }

	int maxPowerValue;
	int getMaxPowerValue() const { return maxPowerValue; }
	void setMaxPowerValue(int val) { maxPowerValue = val; }

	int maxSpeedValue;
	int getMaxSpeedValue() const { return maxSpeedValue; }
	void setMaxSpeedValue(int val) { maxSpeedValue = val; }

	int maxProtectValue;
	int getMaxProtectValue() const { return maxProtectValue; }
	void setMaxProtectValue(int val) { maxProtectValue = val; }

	int maxEnergyValue;
	int getMaxEnergyValue() const { return maxEnergyValue; }
	void setMaxEnergyValue(int val) { maxEnergyValue = val; }

	//////////////////////////////////

	int totalMagicValue;
	int getTotalMagicValue() const { return totalMagicValue; }
	void setTotalMagicValue(int val) { totalMagicValue = val; }

	int totalPowerValue;
	int getTotalPowerValue() const { return totalPowerValue; }
	void setTotalPowerValue(int val) { totalPowerValue = val; }

	int totalSpeedValue;
	int getTotalSpeedValue() const { return totalSpeedValue; }
	void setTotalSpeedValue(int val) { totalSpeedValue = val; }

	int totalProtectValue;
	int getTotalProtectValue() const { return totalProtectValue; }
	void setTotalProtectValue(int val) { totalProtectValue = val; }
	
	int vip;
	int getVip() const { return vip; }
	void setVip(int val) { vip = val; }

	//from server
	MKJson* variable;
	MKJson* getVariable() const { return variable; }
	void setVariable(Json::Value val);

	MKLuaBridgePtr pMKLuaBridgePtr;

	MKLuaBridge* getMKLuaBridge() const {
		return pMKLuaBridgePtr.get();
	}

	void setMKLuaBridge(MKLuaBridge* val) {
	}

	void init();

	void loadFromJson(Json::Value v);
	void updateFromJson(Json::Value v);
	string getAccessToken() const { return accessToken; }
	void setAccessToken(string val) { accessToken = val; }

	int getUid() const { return uid; }
	void setUid(int val) { uid = val; }

	int  getDimand() const { return dimand; }
	void setDimand(int val) { dimand = val; }

	int  getExpValue() const { return expValue; }
	void setExpValue(int val) { expValue = val; }

	int  getCoin() const { return coin; }
	void setCoin(int val) { coin = val; }

	UTF8String  getImg() const { return img; }
	void setImg(UTF8String& val) { img = val; }

	UTF8String getName() const { return name; }
	void setName(UTF8String& val) { name = val; }

	int getSex() const { return sex; }
	void setSex(int val) { sex = val; }

	int  getLiveValue() const { 
		return liveValue; 
	}
	void setLiveValue(int val) { 
		liveValue = val; 
	}
};
////////////////////////////////////////////////////////////////
//class LUAContext;
class ESContext;
typedef LUAContext LUANode;
typedef QuickjsContext QJSNode;
template <class T>
class WrapperNode
{
public:

	WrapperNode(T t) {
		next = NULL;
		prev = NULL;
		this->t = t;
	}

	T t;
	WrapperNode* next;
	WrapperNode* prev;


	bool isNull() {
		if (t == NULL) {
			return true;
		}
		return false;
	}

	void clear() {
		t = NULL;
	}
};

class LuaPool {
public:
	static string DRAW_NODE;
	static string EVENT_NODE;
	static string GLCTX_NODE;

	LuaPool(int capacity);
	~LuaPool();
	int size;
	int capacity;
	WrapperNode<LUANode*>* header;
	WrapperNode<LUANode*>* tail;
	WrapperNode<LUANode*>* last;
	void init();
	void pushInit(LUANode* nd);
	void pushSync(LUANode* nd);
	LUANode* popSync();
	void printInfo();

private:
	MKMutex mutex;
	void addInit(LUANode* nd);
	void push(LUANode* nd);
	LUANode* pop();

	void lock();
	void unlock();



};

class LuaPoolList {

public:

	int capacity;
	int poolCapacity;
	vector<LuaPool*> list;
	LuaPoolList(int capacity, int poolCapacity=5);
	~LuaPoolList();
	LUANode* newNode(ESContext* ctx);
	void init(ESContext* ctx);
	void push(LUANode* nd);
	void push();
	LUANode* pop();
	void printInfo();
	ESContext* context;
	ESContext* Context() const { return context; }
	void Context(ESContext* val) { context = val; }

	void pushNoPool(LUANode* nd);
	void pushNoPool();
	void exit();
	LUANode* getNoPool();
	void setCurrentThreadNoPoolNode();
	vector<LUANode*> namedList;
	int noPoolIdx;
};
////////////////////////////////////////////////////////////////////////////
class ESContext
{
public:
	ESContext(void);
	~ESContext(void);

	ALCdevice * pDevice;
	ALCcontext *pContext;
	Canvas* canvasContext = nullptr;
	int viewport_matrix[ 4 ];
	string sceneAddr;
	string gameAddr;

	vec2 touchDownPos;
	vec2 circleOriPos;
	BOOL firstTouchDown;
	void       *platformData;
	UserData   *userData;
	CameraPtr AMKShadowPtr(string cameraId = "gShadowCamera");
	CameraPtr AMKShadowPtr(MK3DObjectPtr objPtr);

	map<string, CameraPtr> cameraMap;
	map<string, MKFBXOBJSpritePtr> templateFbx;
	MKFBXOBJSpritePtr clone(string id, string path);
	PMKFBXOBJSprite lua_clone(string id, string path);
	MKFBXOBJSpritePtr getFbxTemplate(string path);
	//MKTextPanelPtr aMKTextPanel;
//test begin
	MKVerticle3DRectPtr aMKVerticle3DRectPtr;

	BOOL enableEvent;
	MKFBOImgPtr aMKFBOImgPtr;
	MKFBOImgPtr aMKFBOImgRPtr;

	MKLuaBridgePtr pMKLuaBridgePtr;
	//unsigned int depth_texture;
	//MKFBOTexturePtr pMKFBOTexture;
	//MKOBJSpritePtr child;
//test end
	//CoordinaSystem aCoordinaSystemAlbumn;
	//CoordinaSystem aCoordinaSystem;
	//Graphics aGraphics;
	//MKGraphic graphic;
	vector<MKUINodePtr> topLayer;
	vector<MKUINodePtr> uiFactor;
	int indx;
	//scene begin
	vector<MK3DObjectPtr> objs;
	vector<MK3DObjectPtr> fbxObjs;
	vector<MK3DObjectPtr> dynamicObjs;
	vector<MKTexturePtr> texts;
	MKFBXOBJSpritePtr heroPtr;

	////////////////////////////////////////////////////
	LayerManagerPtr pLayerManager;
	LayerManagerPtr getPLayerManager() const { return pLayerManager; }
	void setPLayerManager(LayerManagerPtr val) { pLayerManager = val; }
	////////////////////////////////////////////////////
	QJSNode* newQJSNode(ESContext* ctx);
	Member* getMember();
	long getUID();

	ScenePtr scenePtr;	
	int curFrame2DIdx;

	//main camera
	CameraPtr aCameraPtr;
	CameraPtr uiCameraPtr;

	CameraPtr shadowCameraPtr;
	MKUINodePtr getUI(string id);
	MKUINodePtr destroyUI(string id);
	MKOBJSprite* initSky();

	PacketProcessThreadPtr pPacketProcessThread;
	
	vector<PacketDecodeFun> packetDecodeList;
	void initMKPacketProcess();
	//MKFbxSpriteActionPtr getPacketAction(MKPacketPtr ptr);
	void startLUA();
	void reset2D(int idx=-1);
	void startLUA(string func);
	void drawSky(ESContext *esContext);
	int InitRealResource(ESContext *esContext);
	string getProperty(string key);
	int InitFontResource(string fontName, ESContext *esContext);
	int InitResource(ESContext *esContext);
	int InitSurface(ESContext *esContext);
	int InitSize(ESContext *esContext);
	int initMP3Resource();
	int InitLog();
	void stopAllFbxSprite();
	void resumeAllFbxSprite();

	virtual int InitUI(ESContext *esContext);
	virtual int Init3D(ESContext *esContext);
	virtual int Init2D(ESContext *esContext);
	//particle op
	ParticleSystemPtr getParticle(string id);
	void clearParticles();
	void removeParticleAbms(string id);
	void addParticle(ParticleSystemPtr particle);
	void addParticle(string id, ParticleSystemPtr particle);
	void attachParticleByPos(ParticleSystem* particleSystemPtr, float x, float y, float z, float scale, BOOL canRotate);
	MKTexture* creatTexture(string texturePath);
	MKTexture* buildTexture(string texturePath);
	//op end
	
	//void drawSetMatrix( ESContext *esContext );
	void setLabelValue(string id, string value);
	void setLabelValueUTF8(string id, UTF8String value);
	void setUIImage(string id, string path);
	void setUIFloat(string id, string prop, float v);
	float getUIFloat(string id, string prop);

	void setUIBOOL(string id, string prop, BOOL v);
	BOOL getUIBOOL(string id, string prop);

	void setUIString(string id, string prop, string v);
	string getUIString(string id, string prop);
	void callSequence(string fun, MKLuaBridge* v);
	void callFun(string path, string v);
	void callComplex(string fun, mk::MKLuaRefVector* v);
	void callFunMap(string fun, MKLuaBridge* v);
	void callFunJson(string fun, MKJson* v);
	void callFunJsonStr(string fun, string str);
	void waitActionEnd(MKUIActionPtr action);
	void callFunSync(string fun, string v);
	void callComplexSync(string fun, mk::MKLuaRefVector* v);
	void callFunMapSync(string fun, MKLuaBridge* v);
	void callFunJsonSync(string fun, MKJson* v);
	void callFunJsonStrSync(string fun, string str);
	long getDuration();
	void setCurrentThreadNoPoolNode();
	virtual void drawFunc( ESContext *esContext);
	//virtual void drawFunc2D( ESContext *esContext);
	virtual void drawLFunc( ESContext *esContext);
	virtual void drawRFunc( ESContext *esContext);
	void markObj();
	void processCallBack(ESContext *esContext);
	void loadEnd(MKFBXOBJSpritePtr spritePtr);
	void processNewSprite(ESContext *esContext);
	void processFbxNewSprite(ESContext *esContext);
	void processDynamicNewSprite(ESContext *esContext);
	void addObj(MK3DObjectPtr obj);
	void addFBXObj(MK3DObjectPtr obj);
	void addDynamicObj(MK3DObjectPtr obj);
	vector<MK3DObjectPtr> getFbxOK();
	vector<MK3DObjectPtr> getDynamicOK();
	void clear(ESContext *esContext);
	void clearSprite(vector<MK3DObjectPtr>& objList);
	void clearSpriteMap();
	void removeObjSprite(string id, ESContext *esContext);
	void removeObjSpriteFromTerrian(string id, ESContext *esContext);
	void removeParticle(string id);
	void loadScene(string url, ESContext *esContext);
	void reloadScene(ESContext *esContext);
	int surfaceDestroyed(ESContext *pEsContext);
	int surfaceCreated(ESContext *pEsContext);
	ParticleSystemPtr getParticleSystemByIdx(int idx);
	BOOL isNULLScene();

	int getClientWidth();
	int getClientHeight();
//event
	virtual void touchBegin(ESContext *esContext, int x, int y, int tapCount, int pointerId);
	virtual string touchMove(ESContext *esContext, int x, int y, int tapCount, int pointerId);
	virtual void touchEnd(ESContext *esContext, int x, int y, int tapCount, int pointerId);

	virtual void touchBegin2D(ESContext *esContext, int x, int y, int tapCount, int pointerId);
	virtual string touchMove2D(ESContext *esContext, int x, int y, int tapCount, int pointerId);
	virtual void touchEnd2D(ESContext *esContext, int x, int y, int tapCount, int pointerId);
	virtual void touchClick2D(ESContext *esContext, int x, int y, int tapCount, int pointerId);

	virtual string tochUIBegin(ESContext *pEsContext, int x, int y, int mouseType, int pointerId);
	virtual string tochUIEnd(ESContext *pEsContext, int x, int y, int mouseType, int pointerId);
	virtual string tochUIMove(ESContext *pEsContext, int x, int y, MKMouseEvent event, int pointerId);
	virtual string touchClick(ESContext *esContext, int x, int y, int tapCount, int pointerId);


	virtual string toch2DBegin(ESContext *pEsContext, int x, int y, int mouseType, int pointerId);
	virtual string toch2DEnd(ESContext *pEsContext, int x, int y, int mouseType, int pointerId);
	virtual string toch2DMove(ESContext *pEsContext, int x, int y,  MKMouseEvent& event, int pointerId);
	virtual string touch2DClick(ESContext *pEsContext, int x, int y, int mouseType, int pointerId);


	void setPositionByCamera();
	void setEditText(string id, string v);
	void setEditText(string id, float v);
	void keyFunc(ESContext *esContext, unsigned char key, int, int );
	void keyFunc2(ESContext *esContext, unsigned char key, int, int );
	virtual void mouseWheel(ESContext *esContext, int x, int y, int zDelta);
	virtual void mouseRbuttnDown(ESContext *esContext, int x, int y, int zDelta);
	virtual void mouseRbuttnUp(ESContext *esContext, int x, int y, int zDelta);
	MKLuaBridge* getExt() const;
	void setExt(MKLuaBridge* ptr);
	void removeSprite(string id);

	vector<MK3DObjectPtr> isHit(ESContext *esContext, Ray& aRay);

	vector<MKOBJSpritePtr> findByType(ESContext *esContext, string type);
	GLboolean esCreateWindow ( ESContext *esContext, const char *title, GLint width, GLint height, GLuint flags );
#ifndef __APPLE__
	/// Display handle
	EGLNativeDisplayType eglNativeDisplay;

	/// Window handle
	EGLNativeWindowType  eglNativeWindow;
	EGLDisplay  eglDisplay;
	EGLContext  eglContext;
	EGLSurface  eglSurface;

	EGLSurface buffEglSurface;
	EGLSurface buffEglUISurface;
	//for texture
	EGLContext  eglTextureContext;
	EGLContext  eglUIContext;

	string headImgPath;
	string beiwenMTLPath;
	VideoState aVideoState;
	DownloadManager aDownloadManager;
#endif

	map<string, ParticleSystemPtr> particles;

	/// Callbacks
	Vector3 getCameraOrientation();
	Vector3 getCameraOrientationZ();
	Vector3 getCameraOrientationX();
	Vector3 getCameraOrientationY();
	//Graphics graphic2;
	SpriteInitThreadPtr aSpriteInitThread;
	LuaThreadPtr aLuaThread;
	TimerThreadPtr aTimerThread;
	SpriteAddThreadPtr aSpriteAddThread;


	void clearScene();
	//MKVerticle3DRectPtr aMKBeiZiLu;
	MK3DObjectPtr aMKSkyPtr;
	ScenePtr getCurrentScene();
	int mouseState;
	int oldX;
	int oldY;

	int is2DGame;
	int old2DX;
	int old2DY;
	MyTime mouseClickTime;
	MyTime myTime;
	BOOL enableSky;
	void run(int flag);
	int isStop();
	void notifyUI();
	ActivityManagerPtr activityManagerPtr;
	ActivityManager* getActivityManager() const { 
		return activityManagerPtr.get(); 
	}

	inline ViewManagerPtr getViewManager() {
		ActivityPtr activity = getActivity();
		if(activity!=NULL) {
			return activity->ViewManager();
		}
		return NULL;
	}

	void setCurActivity(ActivityPtr activity);
	void printActivity();
	ActivityPtr readActivity();
	ActivityPtr getActivity();

	int sceneLoadStatus;
	int getSceneLoadFinish();

	//for client
	string userContent;
	int stragety;
	MKCyleList<MKUIActionPtr> actionList;
	MKCyleList<MKUIActionPtr> syncDrawActionList;

	void addUIAction(MKUIActionPtr ptr);
	void addSyncDrawUIAction(MKUIActionPtr ptr);

	vector<string> deleteCommands;
	vector<string> resetCommands;
	vector<string> particleCommands;
	volatile BOOL exitFlag;
	BOOL isVR;
	int gameState;
	MyTime aMyTime;
	long oldTime;
	//MyEpoch aMyEpoch;
	float dltTime;
    int frameRate2D;
	MKFBXOBJSpritePtr aMKFBXOBJSprite;
	LUAContextPtr luaInstance;
	LUAContextPtr luaInstance4Draw;
	ObjMergeManagerPtr pObjMergeManagerPtr;
vector<LUAContextPtr> luaMap; 
	LUAContextPtr headerLua;
	LUAContextPtr tailLua;
	LUAContextPtr getLUAContext(string name="");
	void putLUAContext(string name, LUAContextPtr pLUAContextPtr);
	void putLUAContext();

	static MK3DObjectPtr test;
	void init2D();
	void draw2D();

	shared_ptr<MKTerrians> terriansPtr;

	//exam words
	vector<MKBeanPtr> words;
	vector<MK3DObjectPtr> beans;
	void addBean();


	string getOnMouseMove() const { return onLuaMouseMove; }
	void setOnMouseMove(string val) { onLuaMouseMove = val; }
	MKTerrians* getTerrains();

	//ppint fun
	long setMaterial(int meshIndex, int index)  {
		return 1;
	}

	template<typename T1>
	void call1NRet(const char* name, T1 arg1)
	{
		unsigned long tId = getThreaId();
		LogUtil::logInfo("mklua", "lua wrap call1 %s begin, tid:%u", name, tId);
		LUAContextPtr pLUAContextPtr = getLUAContext();
		if(pLUAContextPtr==NULL) {
			LogUtil::logInfo("mklua", "lua error call1 getLUAContext is null:%s tid:%u", name, tId);
			LogUtil::logInfo("mklua", "lua wrap call1 %s end, tid:%u", name, tId);
		}
		pLUAContextPtr->call1NRet<T1>(name, arg1);
		putLUAContext();
		LogUtil::logInfo("mklua", "lua wrap call1 %s end, tid:%u", name, tId);
	}

	template<typename R, typename T1>
	R call1(const char* name, T1 arg1)
	{
		unsigned long tId = getThreaId();
		LogUtil::logInfo("mklua", "lua wrap call1 %s begin, tid:%u", name, tId);
		LUAContextPtr pLUAContextPtr = getLUAContext();
		if(pLUAContextPtr==NULL) {
			LogUtil::logInfo("mklua", "lua error call1 getLUAContext is null:%s tid:%u", name, tId);
			LogUtil::logInfo("mklua", "lua wrap call1 %s end, tid:%u", name, tId);
			return MKNULLStack<R>::getNULL();
		}
		R ret = pLUAContextPtr->call1<R,T1>(name, arg1);
		putLUAContext();
		LogUtil::logInfo("mklua", "lua wrap call1 %s end, tid:%u", name, tId);
		return ret;
	}


	template<typename R, typename T1, typename T2>
	R call2(string name, T1 arg1, T2 arg2)
	{
		unsigned long tId = getThreaId();
		LogUtil::logInfo("lua", "lua wrap call2 %s begin, tid:%u", name.c_str(), tId);
		LUAContextPtr pLUAContextPtr = getLUAContext();
		if(pLUAContextPtr==NULL) {
			LogUtil::logInfo("lua", "lua error call2 getLUAContext is null:%s tid:%u", name.c_str(), tId);
			LogUtil::logInfo("lua", "lua wrap call2 %s end, tid:%u", name.c_str(), tId);
			return MKNULLStack<R>::getNULL();
		}
		R ret = pLUAContextPtr->call2<R,T1,T2>(name, arg1, arg2);
		putLUAContext();
		LogUtil::logInfo("lua", "lua wrap call2 %s end, tid:%u", name.c_str(), tId);
		return ret;
	}

	template<typename R, typename T1, typename T2, typename T3>
	R call3(const char* name, T1 arg1, T2 arg2, T3 arg3)
	{
		unsigned long tId = getThreaId();
		LogUtil::logInfo("lua", "lua wrap call3 %s begin, tid:%u", name, tId);
		LUAContextPtr pLUAContextPtr = getLUAContext();
		if(pLUAContextPtr==NULL) {
			LogUtil::logInfo("lua", "lua error call3 getLUAContext is null:%s tid:%u", name, tId);
			LogUtil::logInfo("lua", "lua wrap call3 %s end, tid:%u", name, tId);
			return MKNULLStack<R>::getNULL();
		}
		R ret = pLUAContextPtr->call3<R,T1,T2,T3>(name, arg1, arg2,arg3);
		putLUAContext();
		LogUtil::logInfo("lua", "lua wrap call3 %s end, tid:%u", name, tId);
		return ret;	
	}

	template<typename R, typename T1, typename T2, typename T3, typename T4>
	R call4(const char* name, T1 arg1, T2 arg2, T3 arg3, T4 arg4)
	{
		unsigned long tId = getThreaId();
		LogUtil::logInfo("lua", "lua wrap call4 %s begin, tid:%u", name, tId);
		LUAContextPtr pLUAContextPtr = getLUAContext();
		if(pLUAContextPtr==NULL) {
			LogUtil::logInfo("lua", "lua error call4 getLUAContext is null:%s", name);
			LogUtil::logInfo("lua", "lua wrap call4 %s end, tid:%u", name, tId);
			return MKNULLStack<R>::getNULL();
		}
		R ret = pLUAContextPtr->call4<R,T1,T2,T3,T4>(name, arg1, arg2, arg3, arg4);
		putLUAContext();
		LogUtil::logInfo("lua", "lua wrap call4 %s end, tid:%u", name, tId);
		return ret;	
	}

	void addUITimerById(int endTime, string id, string alive, string end);
	void addFbxTimerById(int endTime, string id, string alive, string end);
	void addActvityTimer(int endTime, Activity* ptr, string alive, string end);
	MKTimerPtr addVirtualSpriteTimerById(int endTime, string id, string alive, string end);
	void addSprite2DTimer(int endTime, MK2DSprite* ptr, string alive, string end);
	int download(string url, string dstPath);

	private:
		ActivityPtr activity;
		MKMutex activityMutex;
		SyncValue<ActivityPtr> activitySync;
		BOOL canUnloadScene;
		string onLuaMouseMove;

		//frame rate begin
		//MyTime aMyTime;
		//frame rate end
		

		MKFboPtr fboPtr;
///////////////////////////////////
		public:
		MKMutex eventLock;
		void lockEvent();
		void unlockEvent();

		MKMutex syncDrawMutex;
		void lockSyncDrawEvent();
		void unlockSyncDrawEvent();

		GLuint imageFBO;  
		GLuint imageID;  
		GLuint depthTextureID;
		int VB_WIDTH;
		int VB_HEIGHT;
		MK2DRect aMK2DRect2;

		void SetFrameBufferObject(int fbowidth, int fboheight);

		void GenImage();

		void blit() {
			glBindFramebuffer(GL_READ_FRAMEBUFFER, imageFBO);
			glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);

			glBlitFramebuffer(0, 0, VB_WIDTH, VB_HEIGHT, 0, 0, VB_WIDTH, VB_HEIGHT, GL_COLOR_BUFFER_BIT, GL_NEAREST);

			glBindFramebuffer(GL_READ_FRAMEBUFFER, 0);
			glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
		}

		//https://www.cnblogs.com/liangliangh/p/3575590.html
		void init_physic_world( void );
		BOOL initPhysicFlag;
		void load_physic_world( void );
		btTransform startTransform;


		btSoftBodyRigidBodyCollisionConfiguration *collisionconfiguration;
		btCollisionDispatcher *dispatcher;
		btBroadphaseInterface *broadphase;
		btConstraintSolver *solver;
		btSoftRigidDynamicsWorld *dynamicsworld;

		//call back for lua
		LuaCallBackThreadPtr aLuaCallBackThread;
		RequestPool* pRequestPoolPtr;
		RequestPool* getRequestPool();
		void addRequestPacket(RequestPacket* pPacket);
		MKLabel* getLabel(string uiId);
		void setSky(MKOBJSprite* sky);
		void addPacket(MKPacketPtr ptr);
		static MKObj* pobj;
		string scene2d;
		string getScene2d() const { return scene2d; }
		void setScene2d(string val) { scene2d = val; }
		LuaPoolList* pLUAPoolList;
		QJSNode* qjsInstance;
		//bullet
		MKBulletWorldPtr pMKBulletWorldPtr;
		MKBulletWorldPtr getPMKBulletWorldPtr() const { return pMKBulletWorldPtr; }
		void setPMKBulletWorldPtr(MKBulletWorldPtr val) { pMKBulletWorldPtr = val; }
		void freeBullet();

#ifndef __APPLE__
		EGLConfig config;
#endif
};

