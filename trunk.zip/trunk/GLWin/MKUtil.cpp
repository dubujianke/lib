//#include "StdAfx.h"
#include "MKUtil.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include "ESContext.h"

#ifdef ANDROID
#include <android/log.h>
#include <android_native_app_glue.h>
#include <android/asset_manager.h>
typedef AAsset esFile;
#else
typedef FILE esFile;
#endif

#ifdef __APPLE__
#include "FileWrapper.h"
#endif

#ifndef __APPLE__
EGLint GetContextRenderableType ( EGLDisplay eglDisplay )
{
#ifdef EGL_KHR_create_context
	const char *extensions = eglQueryString ( eglDisplay, EGL_EXTENSIONS );

	// check whether EGL_KHR_create_context is in the extension string
	if ( extensions != NULL && strstr( extensions, "EGL_KHR_create_context" ) )
	{
		// extension is supported
		return EGL_OPENGL_ES3_BIT_KHR;
	}
#endif
	// extension is not supported
	return EGL_OPENGL_ES2_BIT;
}
#endif


