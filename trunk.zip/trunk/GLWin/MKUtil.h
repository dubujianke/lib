#pragma once
#include "MKCommon.h"

EGLint GetContextRenderableType ( EGLDisplay eglDisplay );

