#include "meshoptimizer/meshoptimizer.h"
#include "nanight/nanight.h"

namespace lod {
#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif
int vscprintf_(const char* format, va_list pargs) {
	int retval;
	va_list argcopy;
	va_copy(argcopy, pargs);

	retval = vsnprintf(NULL, 0, format, argcopy);
	va_end(argcopy);
	return retval;
}

void writeFile_(std::string file, const char* formatStr, ...) {
	FILE* fp;
	fp = fopen(file.c_str(), "a");

	int LEN = 50000;
	va_list paramsLen;
	va_start(paramsLen, formatStr);
	LEN = vscprintf_(formatStr, paramsLen) + 1;
	va_end(paramsLen);

	char* buf = new char[LEN];
	va_list params;
	va_start(params, formatStr);
	vsprintf(buf, formatStr, params);
	va_end(params);

	fprintf(fp, buf);
	fflush(fp);
	fclose(fp);
}

void writeFile(std::string file, std::string content) {
	FILE* fp;
	fp = fopen(file.c_str(), "a");
	fprintf(fp, content.c_str());
	fclose(fp);
}

void reIndex(int& gIdx, std::vector<VertexIdx*>& verticeIdxs, int oriIdx, VertexIdx*& last, VertexIdx*& first) {
	VertexIdx* v = verticeIdxs[oriIdx];
	if (v == nullptr) {
		VertexIdx* ptr = new VertexIdx();
		ptr->setIdx(gIdx);
		gIdx++;
		ptr->next = nullptr;
		verticeIdxs[oriIdx] = ptr;
		if (last != nullptr) {
			last->next = ptr;
		}
		last = ptr;
		if (!first) {
			first = ptr;
		}
	}
}

void logNormal(std::string file, VertexIdx* last) {
	while (last) {
		vec3 normal = last->normal;
		char cnt[100] = { 0 };
		sprintf(cnt, "vn %f %f %f\n", normal.x, normal.y, normal.z);
		writeFile(file, cnt);
		last = last->next;
	}
}

void dumpObj(std::string file, const std::vector<Vertex>& vertices, const std::vector<unsigned int>& indices, bool recomputeNormals)
{
	std::vector<float> normals;
	int vLen = vertices.size();
	std::vector<VertexIdx*> verticeIdxs(vLen, nullptr);
	VertexIdx* last = nullptr;
	VertexIdx* first = nullptr;
	if (recomputeNormals)
	{
		int gIdx = 0;
		normals.resize(vertices.size() * 3);
		for (size_t i = 0; i < indices.size(); i += 3)
		{
			unsigned int a = indices[i], b = indices[i + 1], c = indices[i + 2];
			if (i == 0) {
				last = nullptr;
			}
			reIndex(gIdx, verticeIdxs, a, last, first);
			reIndex(gIdx, verticeIdxs, b, last, first);
			reIndex(gIdx, verticeIdxs, c, last, first);
			const Vertex& va = vertices[a];
			const Vertex& vb = vertices[b];
			const Vertex& vc = vertices[c];
			float nx = (vb.py - va.py) * (vc.pz - va.pz) - (vb.pz - va.pz) * (vc.py - va.py);
			float ny = (vb.pz - va.pz) * (vc.px - va.px) - (vb.px - va.px) * (vc.pz - va.pz);
			float nz = (vb.px - va.px) * (vc.py - va.py) - (vb.py - va.py) * (vc.px - va.px);
			for (int k = 0; k < 3; ++k)
			{
				unsigned int index = indices[i + k];
				normals[index * 3 + 0] += nx;
				normals[index * 3 + 1] += ny;
				normals[index * 3 + 2] += nz;
			}
		}
	}
	//printReIndex(first);
	for (size_t i = 0; i < vertices.size(); ++i)
	{
		const Vertex& v = vertices[i];
		float nx = v.nx, ny = v.ny, nz = v.nz;
		if (recomputeNormals)
		{
			nx = normals[i * 3 + 0];
			ny = normals[i * 3 + 1];
			nz = normals[i * 3 + 2];
			float l = sqrtf(nx * nx + ny * ny + nz * nz);
			float s = l == 0.f ? 0.f : 1.f / l;
			nx *= s;
			ny *= s;
			nz *= s;
		}
		if (verticeIdxs[i]) {
			vec3 normal = { nx, ny, nz };
			verticeIdxs[i]->normal = normal;
		}
		char cnt[100] = { 0 };
		sprintf(cnt, "v %f %f %f\n", v.px, v.py, v.pz);
		writeFile(file, cnt);
	}
	logNormal(file, first);
	for (size_t i = 0; i < indices.size(); i += 3)
	{
		unsigned int a = indices[i], b = indices[i + 1], c = indices[i + 2];
		int a1 = verticeIdxs[a]->idx;
		int b1 = verticeIdxs[b]->idx;
		int c1 = verticeIdxs[c]->idx;
		char cnt[200] = { 0 };
		sprintf(cnt, "f %d//%d %d//%d %d//%d\n", a + 1, a1 + 1, b + 1, b1 + 1, c + 1, c1 + 1);
		writeFile(file, cnt);
	}
}

void dumpObj(std::string file, const char* section, const std::vector<unsigned int>& indices)
{
	FILE* fp;
	fp = fopen(file.c_str(), "a");
	fprintf(fp, "o %s\n", section);
	for (size_t j = 0; j < indices.size(); j += 3)
	{
		unsigned int a = indices[j], b = indices[j + 1], c = indices[j + 2];
		fprintf(fp, "f %d//%d %d//%d %d//%d\n", a + 1, a + 1, b + 1, b + 1, c + 1, c + 1);
	}
	fclose(fp);
}

const size_t kClusterSize = 128;
const size_t kGroupSize = 8;
const bool kUseLocks = true;
const bool kUseNormals = true;
const bool kUseRetry = true;
const bool kUseSpatial = false;
const bool kUseSloppyFallback = false;
const int kMetisSlop = 2;
const float kSimplifyThreshold = 0.85f;

static LODBounds bounds(const std::vector<Vertex>& vertices, const std::vector<unsigned int>& indices, float error)
{
	meshopt_Bounds bounds = meshopt_computeClusterBounds(&indices[0], indices.size(), &vertices[0].px, vertices.size(), sizeof(Vertex));
	LODBounds result;
	result.center[0] = bounds.center[0];
	result.center[1] = bounds.center[1];
	result.center[2] = bounds.center[2];
	result.radius = bounds.radius;
	result.error = error;
	return result;
}

static LODBounds boundsMerge(const std::vector<Cluster>& clusters, const std::vector<int>& group)
{
	std::vector<LODBounds> bounds(group.size());
	for (size_t j = 0; j < group.size(); ++j)
		bounds[j] = clusters[group[j]].self;
	meshopt_Bounds merged = meshopt_computeSphereBounds(&bounds[0].center[0], bounds.size(), sizeof(LODBounds), &bounds[0].radius, sizeof(LODBounds));
	LODBounds result = {};
	result.center[0] = merged.center[0];
	result.center[1] = merged.center[1];
	result.center[2] = merged.center[2];
	result.radius = merged.radius;
	// merged bounds error must be conservative wrt cluster errors
	result.error = 0.f;
	for (size_t j = 0; j < group.size(); ++j)
		result.error = std::max(result.error, clusters[group[j]].self.error);
	return result;
}

// computes approximate (perspective) projection error of a cluster in screen space (0..1; multiply by screen height to get pixels)
// camera_proj is projection[1][1], or cot(fovy/2); camera_znear is *positive* near plane distance
// for DAG cut to be valid, boundsError must be monotonic: it must return a larger error for parent cluster
// for simplicity, we ignore perspective distortion and use rotationally invariant projection size estimation
static float boundsError(const LODBounds& bounds, float camera_x, float camera_y, float camera_z, float camera_proj, float camera_znear)
{
	float dx = bounds.center[0] - camera_x, dy = bounds.center[1] - camera_y, dz = bounds.center[2] - camera_z;
	float d = sqrtf(dx * dx + dy * dy + dz * dz) - bounds.radius;
	return bounds.error / (d > camera_znear ? d : camera_znear) * (camera_proj * 0.5f);
}

static std::vector<Cluster> clusterizeMetis(const std::vector<Vertex>& vertices, const std::vector<unsigned int>& indices);
static std::vector<std::vector<int> > partitionMetis(const std::vector<Cluster>& clusters, const std::vector<int>& pending, const std::vector<unsigned int>& remap);

static std::vector<Cluster> clusterize(const std::vector<Vertex>& vertices, const std::vector<unsigned int>& indices)
{
	return clusterizeMetis(vertices, indices);	
}

static std::vector<std::vector<int> > partition(const std::vector<Cluster>& clusters, const std::vector<int>& pending, const std::vector<unsigned int>& remap, const std::vector<Vertex>& vertices)
{
	return partitionMetis(clusters, pending, remap);
}

static void lockBoundary(std::vector<unsigned char>& locks, const std::vector<std::vector<int> >& groups, const std::vector<Cluster>& clusters, const std::vector<unsigned int>& remap)
{
	// for each remapped vertex, keep track of index of the group it's in (or -2 if it's in multiple groups)
	std::vector<int> groupmap(locks.size(), -1);

	for (size_t i = 0; i < groups.size(); ++i)
		for (size_t j = 0; j < groups[i].size(); ++j)
		{
			const Cluster& cluster = clusters[groups[i][j]];
			for (size_t k = 0; k < cluster.indices.size(); ++k)
			{
				unsigned int v = cluster.indices[k];
				unsigned int r = remap[v];

				if (groupmap[r] == -1 || groupmap[r] == int(i))
					groupmap[r] = int(i);
				else
					groupmap[r] = -2;
			}
		}

	// note: we need to consistently lock all vertices with the same position to avoid holes
	for (size_t i = 0; i < locks.size(); ++i)
	{
		unsigned int r = remap[i];

		locks[i] = (groupmap[r] == -2);
	}
}

static std::vector<unsigned int> simplify(const std::vector<Vertex>& vertices, const std::vector<unsigned int>& indices, const std::vector<unsigned char>* locks, size_t target_count, float* error = NULL)
{
	if (target_count > indices.size())
		return indices;

	std::vector<unsigned int> lod(indices.size());
	unsigned int options = meshopt_SimplifySparse | meshopt_SimplifyErrorAbsolute;
	float normal_weights[3] = {0.5f, 0.5f, 0.5f};
	if (kUseNormals)
		lod.resize(meshopt_simplifyWithAttributes(&lod[0], &indices[0], indices.size(), &vertices[0].px, vertices.size(), sizeof(Vertex), &vertices[0].nx, sizeof(Vertex), normal_weights, 3, locks ? &(*locks)[0] : NULL, target_count, FLT_MAX, options, error));
	else if (locks)
		lod.resize(meshopt_simplifyWithAttributes(&lod[0], &indices[0], indices.size(), &vertices[0].px, vertices.size(), sizeof(Vertex), NULL, 0, NULL, 0, &(*locks)[0], target_count, FLT_MAX, options, error));
	else
		lod.resize(meshopt_simplify(&lod[0], &indices[0], indices.size(), &vertices[0].px, vertices.size(), sizeof(Vertex), target_count, FLT_MAX, options | meshopt_SimplifyLockBorder, error));

	if (lod.size() > target_count && kUseSloppyFallback)
		lod.resize(meshopt_simplifySloppy(&lod[0], &indices[0], indices.size(), &vertices[0].px, vertices.size(), sizeof(Vertex), locks ? &(*locks)[0] : NULL, target_count, FLT_MAX, error));

	return lod;
}

static Level* getLevels(Level levelObj, int level, std::vector<Cluster>& queue, const std::vector<std::vector<int> >& groups, const std::vector<unsigned int>& remap, const std::vector<unsigned char>& locks, const std::vector<int>& retry);



LodCluster* nanite(std::vector<Vertex>& vertices, std::vector<unsigned int>& indices)
{
	meshopt_encodeVertexVersion(1);
	meshopt_encodeIndexVersion(1);

	LodCluster* pLodCluster = new LodCluster();
	pLodCluster->vertices = vertices;
	static const char* dump = "-1";
	int depth = 0;
	std::vector<unsigned char> locks(vertices.size());

	// for cluster connectivity, we need a position-only remap that maps vertices with the same position to the same index
	// it's more efficient to build it once; unfortunately, meshopt_generateVertexRemap doesn't support stride so we need to use *Multi version
	std::vector<unsigned int> remap(vertices.size());
	meshopt_Stream position = {&vertices[0].px, sizeof(float) * 3, sizeof(Vertex)};
	meshopt_generateVertexRemapMulti(&remap[0], &indices[0], indices.size(), vertices.size(), &position, 1);

	// initial clusterization splits the original mesh
	std::vector<Cluster> clusters = clusterize(vertices, indices);
	for (size_t i = 0; i < clusters.size(); ++i) {
		clusters[i].self = bounds(vertices, clusters[i].indices, 0.f);
	}
	printf("ideal lod chain: %.1f levels\n", log2(double(indices.size() / 3) / double(kClusterSize)));
	std::vector<int> pending(clusters.size());
	for (size_t i = 0; i < clusters.size(); ++i) {
		pending[i] = int(i);
	}
	// merge and simplify clusters until we can't merge anymore
	while (pending.size() > 1)
	{
		std::vector<std::vector<int>> groups = partition(clusters, pending, remap, vertices);
		if (kUseLocks) {
			lockBoundary(locks, groups, clusters, remap);
		}
		pending.clear();
		std::vector<int> retry;
		size_t triangles = 0;
		size_t stuck_triangles = 0;
		if (dump && depth == atoi(dump)) {
			//dumpObj(vertices, std::vector<unsigned int>());
		}
		// every group needs to be simplified now
		for (size_t i = 0; i < groups.size(); ++i)
		{
			if (groups[i].empty()) {
				continue; // metis shortcut
			}
			std::vector<unsigned int> merged;
			for (size_t j = 0; j < groups[i].size(); ++j) {
				merged.insert(merged.end(), clusters[groups[i][j]].indices.begin(), clusters[groups[i][j]].indices.end());
			}
			if (atoi(dump) == -1 || (dump && depth == atoi(dump)))
			{
				for (size_t j = 0; j < groups[i].size(); ++j) {
					//dumpObj("cluster", clusters[groups[i][j]].indices);
				}
				//dumpObj("group", merged);
				//printf();
			}

			// aim to reduce group size in half
			size_t target_size = (merged.size() / 3) / 2 * 3;
			float error = 0.f;
			std::vector<unsigned int> simplified = simplify(vertices, merged, kUseLocks ? &locks : NULL, target_size, &error);
			if (simplified.size() > merged.size() * kSimplifyThreshold)
			{
				stuck_triangles += merged.size() / 3;
				for (size_t j = 0; j < groups[i].size(); ++j) {
					retry.push_back(groups[i][j]);
				}
				continue; // simplification is stuck; abandon the merge
			}
			// enforce bounds and error monotonicity
			// note: it is incorrect to use the precise bounds of the merged or simplified mesh, because this may violate monotonicity
			LODBounds groupb = boundsMerge(clusters, groups[i]);
			groupb.error += error; // this may overestimate the error, but we are starting from the simplified mesh so this is a little more correct
			std::vector<Cluster> split = clusterize(vertices, simplified);
			// update parent bounds and error for all clusters in the group
			// note that all clusters in the group need to switch simultaneously so they have the same bounds
			for (size_t j = 0; j < groups[i].size(); ++j)
			{
				assert(clusters[groups[i][j]].parent.error == FLT_MAX);
				clusters[groups[i][j]].parent = groupb;
			}
			for (size_t j = 0; j < split.size(); ++j)
			{
				split[j].self = groupb;
				clusters.push_back(split[j]); // std::move
				pending.push_back(int(clusters.size()) - 1);
				triangles += split[j].indices.size() / 3;
			}
		}
		//DUMP
		Level levelObj;
		Level* pLevel = getLevels(levelObj, depth, clusters, groups, remap, locks, retry);
		pLodCluster->addLevel(pLevel);
		depth++;
		if (kUseRetry)
		{
			if (triangles < stuck_triangles / 3) {
				break;
			}
			pending.insert(pending.end(), retry.begin(), retry.end());
		}
	}//pending

	size_t lowest_triangles = 0;
	for (size_t i = 0; i < clusters.size(); ++i) {
		if (clusters[i].parent.error == FLT_MAX) {
			lowest_triangles += clusters[i].indices.size() / 3;
		}
	}
	printf("lowest lod: %d triangles\n", int(lowest_triangles));

	/////////////////////////////////////////////////////////////////////////////////////////////////////TEST
	// for testing purposes, we can compute a DAG cut from a given viewpoint and dump it as an OBJ
	float maxx = 0.f, maxy = 0.f, maxz = 0.f;
	for (size_t i = 0; i < vertices.size(); ++i)
	{
		maxx = std::max(maxx, vertices[i].px * 2)* 1;
		maxy = std::max(maxy, vertices[i].py * 2)* 1;
		maxz = std::max(maxz, vertices[i].pz * 2)* 1;
		if(maxz>1000) {
			printf("i:======>%d\n", i);
		}
	}
	maxx = 1.521018;
	maxy = 3.807926;
	maxz = 5;
	printf("======>%f %f %f\n", maxx, maxy, maxz);
	float threshold = 2e-3f; // 2 pixels at 1080p
	float fovy = 60.f;
	float znear = 1e-2f;
	float proj = 1.f / tanf(fovy * 3.1415926f / 180.f * 0.5f);
	std::vector<unsigned int> rets;
	int k = 0;
	for (size_t i = 0; i < clusters.size(); ++i) {
		if (boundsError(clusters[i].self, maxx, maxy, maxz, proj, znear) <= threshold && boundsError(clusters[i].parent, maxx, maxy, maxz, proj, znear) > threshold) {
			rets.insert(rets.end(), clusters[i].indices.begin(), clusters[i].indices.end());
			k++;
		}
	}
	printf("cut (%.3f): %d triangles\n", threshold, int(rets.size() / 3));
	if (dump && -1 == atoi(dump))
	{
		//dumpObj(vertices, rets, true);
		for (size_t i = 0; i < clusters.size(); ++i) {
			if (boundsError(clusters[i].self, maxx, maxy, maxz, proj, znear) <= threshold && boundsError(clusters[i].parent, maxx, maxy, maxz, proj, znear) > threshold) {
				//dumpObj("cluster", clusters[i].indices);
			}
		}
	}
	pLodCluster->clusters = clusters;
	return pLodCluster;
}

static std::vector<Cluster> clusterizeMetis(const std::vector<Vertex>& vertices, const std::vector<unsigned int>& indices)
{
	std::vector<unsigned int> shadowib(indices.size());
	meshopt_generateShadowIndexBuffer(&shadowib[0], &indices[0], indices.size(), &vertices[0].px, vertices.size(), sizeof(float) * 3, sizeof(Vertex));

	std::vector<std::vector<int> > trilist(vertices.size());

	for (size_t i = 0; i < indices.size(); ++i)
		trilist[shadowib[i]].push_back(int(i / 3));

	std::vector<int> xadj(indices.size() / 3 + 1);
	std::vector<int> adjncy;
	std::vector<int> adjwgt;
	std::vector<int> part(indices.size() / 3);

	std::vector<int> scratch;

	for (size_t i = 0; i < indices.size() / 3; ++i)
	{
		unsigned int a = shadowib[i * 3 + 0], b = shadowib[i * 3 + 1], c = shadowib[i * 3 + 2];

		scratch.clear();
		scratch.insert(scratch.end(), trilist[a].begin(), trilist[a].end());
		scratch.insert(scratch.end(), trilist[b].begin(), trilist[b].end());
		scratch.insert(scratch.end(), trilist[c].begin(), trilist[c].end());
		std::sort(scratch.begin(), scratch.end());

		for (size_t j = 0; j < scratch.size(); ++j)
		{
			if (scratch[j] == int(i))
				continue;

			if (j == 0 || scratch[j] != scratch[j - 1])
			{
				adjncy.push_back(scratch[j]);
				adjwgt.push_back(1);
			}
			else if (j != 0)
			{
				assert(scratch[j] == scratch[j - 1]);
				adjwgt.back()++;
			}
		}

		xadj[i + 1] = int(adjncy.size());
	}

	int options[METIS_NOPTIONS];
	METIS_SetDefaultOptions(options);
	options[METIS_OPTION_SEED] = 42;
	options[METIS_OPTION_UFACTOR] = 1; // minimize partition imbalance

	// since Metis can't enforce partition sizes, add a little slop to reduce the change we need to split results further
	int nvtxs = int(indices.size() / 3);
	int ncon = 1;
	int nparts = int(indices.size() / 3 + (kClusterSize - kMetisSlop) - 1) / (kClusterSize - kMetisSlop);
	int edgecut = 0;

	// not sure why this is a special case that we need to handle but okay metis
	if (nparts > 1)
	{
		int r = METIS_PartGraphRecursive(&nvtxs, &ncon, xadj.data(), adjncy.data(), NULL, NULL, adjwgt.data(), &nparts, NULL, NULL, options, &edgecut, part.data());
		(void)r;
	}

	std::vector<Cluster> result(nparts);

	for (size_t i = 0; i < indices.size() / 3; ++i)
	{
		result[part[i]].indices.push_back(indices[i * 3 + 0]);
		result[part[i]].indices.push_back(indices[i * 3 + 1]);
		result[part[i]].indices.push_back(indices[i * 3 + 2]);
	}

	for (int i = 0; i < nparts; ++i)
	{
		result[i].parent.error = FLT_MAX;

		// need to split the cluster further...
		// this could use meshopt but we're trying to get a complete baseline from metis
		if (result[i].indices.size() > kClusterSize * 3)
		{
			std::vector<Cluster> splits = clusterizeMetis(vertices, result[i].indices);
			assert(splits.size() > 1);

			result[i] = splits[0];
			for (size_t j = 1; j < splits.size(); ++j)
				result.push_back(splits[j]);
		}
	}

	return result;
}

static std::vector<std::vector<int> > partitionMetis(const std::vector<Cluster>& clusters, const std::vector<int>& pending, const std::vector<unsigned int>& remap)
{
	std::vector<std::vector<int> > result;
	std::vector<std::vector<int> > vertices(remap.size());

	for (size_t i = 0; i < pending.size(); ++i)
	{
		const Cluster& cluster = clusters[pending[i]];

		for (size_t j = 0; j < cluster.indices.size(); ++j)
		{
			int v = remap[cluster.indices[j]];

			std::vector<int>& list = vertices[v];
			if (list.empty() || list.back() != int(i))
				list.push_back(int(i));
		}
	}

	std::map<std::pair<int, int>, int> adjacency;

	for (size_t v = 0; v < vertices.size(); ++v)
	{
		const std::vector<int>& list = vertices[v];

		for (size_t i = 0; i < list.size(); ++i)
			for (size_t j = i + 1; j < list.size(); ++j)
				adjacency[std::make_pair(std::min(list[i], list[j]), std::max(list[i], list[j]))]++;
	}

	std::vector<std::vector<std::pair<int, int> > > neighbors(pending.size());

	for (std::map<std::pair<int, int>, int>::iterator it = adjacency.begin(); it != adjacency.end(); ++it)
	{
		neighbors[it->first.first].push_back(std::make_pair(it->first.second, it->second));
		neighbors[it->first.second].push_back(std::make_pair(it->first.first, it->second));
	}

	std::vector<int> xadj(pending.size() + 1);
	std::vector<int> adjncy;
	std::vector<int> adjwgt;
	std::vector<int> part(pending.size());

	for (size_t i = 0; i < pending.size(); ++i)
	{
		for (size_t j = 0; j < neighbors[i].size(); ++j)
		{
			adjncy.push_back(neighbors[i][j].first);
			adjwgt.push_back(neighbors[i][j].second);
		}

		xadj[i + 1] = int(adjncy.size());
	}

	int options[METIS_NOPTIONS];
	METIS_SetDefaultOptions(options);
	options[METIS_OPTION_SEED] = 42;
	options[METIS_OPTION_UFACTOR] = 100;

	int nvtxs = int(pending.size());
	int ncon = 1;
	int nparts = int(pending.size() + kGroupSize - 1) / kGroupSize;
	int edgecut = 0;

	// not sure why this is a special case that we need to handle but okay metis
	if (nparts > 1)
	{
		int r = METIS_PartGraphRecursive(&nvtxs, &ncon, &xadj[0], &adjncy[0], NULL, NULL, &adjwgt[0], &nparts, NULL, NULL, options, &edgecut, &part[0]);
		(void)r;
	}

	result.resize(nparts);
	for (size_t i = 0; i < part.size(); ++i)
		result[part[i]].push_back(pending[i]);

	return result;
}

// What follows is code that is helpful for collecting metrics, visualizing cuts, etc.
// This code is not used in the actual clustering implementation and can be ignored.

static int follow(std::vector<int>& parents, int index)
{
	while (index != parents[index])
	{
		int parent = parents[index];
		parents[index] = parents[parent];
		index = parent;
	}

	return index;
}

static int measureComponents(std::vector<int>& parents, const std::vector<unsigned int>& indices, const std::vector<unsigned int>& remap)
{
	assert(parents.size() == remap.size());

	for (size_t i = 0; i < indices.size(); ++i)
	{
		unsigned int v = remap[indices[i]];
		parents[v] = v;
	}

	for (size_t i = 0; i < indices.size(); ++i)
	{
		int v0 = remap[indices[i]];
		int v1 = remap[indices[i + (i % 3 == 2 ? -2 : 1)]];

		v0 = follow(parents, v0);
		v1 = follow(parents, v1);

		parents[v0] = v1;
	}

	for (size_t i = 0; i < indices.size(); ++i)
	{
		unsigned int v = remap[indices[i]];
		parents[v] = follow(parents, v);
	}

	int roots = 0;
	for (size_t i = 0; i < indices.size(); ++i)
	{
		unsigned int v = remap[indices[i]];
		roots += parents[v] == int(v);
		parents[v] = -1; // make sure we only count each root once
	}

	return roots;
}

static int measureUnique(std::vector<int>& used, const std::vector<unsigned int>& indices, const std::vector<unsigned char>* locks = NULL)
{
	for (size_t i = 0; i < indices.size(); ++i)
	{
		unsigned int v = indices[i];
		used[v] = 1;
	}

	size_t vertices = 0;

	for (size_t i = 0; i < indices.size(); ++i)
	{
		unsigned int v = indices[i];
		vertices += used[v] && (!locks || (*locks)[v]);
		used[v] = 0;
	}

	return int(vertices);
}

static Level* getLevels(Level levelObj, int level, std::vector<Cluster>& queue, const std::vector<std::vector<int>>& groups, const std::vector<unsigned int>& remap, const std::vector<unsigned char>& locks, const std::vector<int>& retry)
{
	Level* pLevel = new Level();
	std::vector<int> parents(remap.size());
	int clusters = 0;
	int triangles = 0;
	int full_clusters = 0;
	int components = 0;
	int xformed = 0;
	int boundary = 0;
	float radius = 0;
	for (size_t i = 0; i < groups.size(); ++i)
	{
		Group* group = new Group();
		pLevel->addGroup(group);
		std::vector<int> clusterIdxs = groups[i];
		for (size_t j = 0; j < clusterIdxs.size(); ++j)
		{
			int clusterIdx = groups[i][j];
			group->addCluster(clusterIdx);
			Cluster& cluster = queue[clusterIdx];
			cluster.depth = level;
			clusters++;
			triangles += int(cluster.indices.size() / 3);
			full_clusters += cluster.indices.size() == kClusterSize * 3;
			components += measureComponents(parents, cluster.indices, remap);
			xformed += measureUnique(parents, cluster.indices);
			boundary += kUseLocks ? measureUnique(parents, cluster.indices, &locks) : 0;
			radius += cluster.self.radius;
		}
	}
	int stuck_clusters = 0;
	int stuck_triangles = 0;
	for (size_t i = 0; i < retry.size(); ++i)
	{
		const Cluster& cluster = queue[retry[i]];
		stuck_clusters++;
		stuck_triangles += int(cluster.indices.size() / 3);
	}
	double avg_group = double(clusters) / double(groups.size());
	double inv_clusters = 1.0 / double(clusters);
	printf("lod %d: %d clusters (%.1f%% full, %.1f tri/cl, %.1f vtx/cl, %.2f connected, %.1f boundary, %.1f partition, %f radius), %d triangles",
	    level, clusters,
	    double(full_clusters) * inv_clusters * 100, 
		double(triangles) * inv_clusters, 
		double(xformed) * inv_clusters, 
		double(components) * inv_clusters, 
		double(boundary) * inv_clusters, 
		avg_group, 
		radius * inv_clusters,
	    int(triangles));
	if (stuck_clusters)
		printf("; stuck %d clusters (%d triangles)", stuck_clusters, stuck_triangles);
	printf("\n");

	return pLevel;
}

static void mergeBox(Box& box, const Box& other)
{
	for (int k = 0; k < 3; ++k)
	{
		box.min[k] = std::min(box.min[k], other.min[k]);
		box.max[k] = std::max(box.max[k], other.max[k]);
	}
}

inline float surface(const Box& box)
{
	float sx = box.max[0] - box.min[0], sy = box.max[1] - box.min[1], sz = box.max[2] - box.min[2];
	return sx * sy + sx * sz + sy * sz;
}

static float sahCost(const Box* boxes, unsigned int* orderx, unsigned int* ordery, unsigned int* orderz, float* scratch, unsigned char* sides, size_t count, int depth)
{
	assert(count > 0);

	if (count == 1)
		return surface(boxes[orderx[0]]);

	// for each axis, accumulated SAH cost in forward and backward directions
	float* costs = scratch;
	Box accum[6] = {boxes[orderx[0]], boxes[orderx[count - 1]], boxes[ordery[0]], boxes[ordery[count - 1]], boxes[orderz[0]], boxes[orderz[count - 1]]};
	unsigned int* axes[3] = {orderx, ordery, orderz};

	for (size_t i = 0; i < count; ++i)
	{
		for (int k = 0; k < 3; ++k)
		{
			mergeBox(accum[2 * k + 0], boxes[axes[k][i]]);
			mergeBox(accum[2 * k + 1], boxes[axes[k][count - 1 - i]]);
		}

		for (int k = 0; k < 3; ++k)
		{
			costs[i + (2 * k + 0) * count] = surface(accum[2 * k + 0]);
			costs[i + (2 * k + 1) * count] = surface(accum[2 * k + 1]);
		}
	}

	// find best split that minimizes SAH
	int bestk = -1;
	size_t bestsplit = 0;
	float bestcost = FLT_MAX;

	for (size_t i = 0; i < count - 1; ++i)
		for (int k = 0; k < 3; ++k)
		{
			// costs[x] = inclusive cost of boxes[0..x]
			float costl = costs[i + (2 * k + 0) * count] * (i + 1);
			// costs[count-1-x] = inclusive cost of boxes[x..count-1]
			float costr = costs[(count - 1 - (i + 1)) + (2 * k + 1) * count] * (count - (i + 1));
			float cost = costl + costr;

			if (cost < bestcost)
			{
				bestcost = cost;
				bestk = k;
				bestsplit = i;
			}
		}

	float total = costs[count - 1];

	// mark sides of split
	for (size_t i = 0; i < bestsplit + 1; ++i)
		sides[axes[bestk][i]] = 0;

	for (size_t i = bestsplit + 1; i < count; ++i)
		sides[axes[bestk][i]] = 1;

	// partition all axes into two sides, maintaining order
	// note: we reuse scratch[], invalidating costs[]
	for (int k = 0; k < 3; ++k)
	{
		if (k == bestk)
			continue;

		unsigned int* temp = reinterpret_cast<unsigned int*>(scratch);
		memcpy(temp, axes[k], sizeof(unsigned int) * count);

		unsigned int* ptr[2] = {axes[k], axes[k] + bestsplit + 1};

		for (size_t i = 0; i < count; ++i)
		{
			unsigned char side = sides[temp[i]];
			*ptr[side] = temp[i];
			ptr[side]++;
		}
	}

	float sahl = sahCost(boxes, orderx, ordery, orderz, scratch, sides, bestsplit + 1, depth + 1);
	float sahr = sahCost(boxes, orderx + bestsplit + 1, ordery + bestsplit + 1, orderz + bestsplit + 1, scratch, sides, count - bestsplit - 1, depth + 1);

	return total + sahl + sahr;
}

static float sahCost(const Box* boxes, size_t count)
{
	std::vector<unsigned int> axes(count * 3);

	for (int k = 0; k < 3; ++k)
	{
		for (size_t i = 0; i < count; ++i)
			axes[i + k * count] = unsigned(i);

		BoxSort sort = {boxes, k};
		std::sort(&axes[k * count], &axes[k * count] + count, sort);
	}

	std::vector<float> scratch(count * 6);
	std::vector<unsigned char> sides(count);

	return sahCost(boxes, &axes[0], &axes[count], &axes[count * 2], &scratch[0], &sides[0], count, 0);
}

static void expandBox(Box& box, float x, float y, float z)
{
	box.min[0] = std::min(box.min[0], x);
	box.min[1] = std::min(box.min[1], y);
	box.min[2] = std::min(box.min[2], z);

	box.max[0] = std::max(box.max[0], x);
	box.max[1] = std::max(box.max[1], y);
	box.max[2] = std::max(box.max[2], z);

	box.pos[0] += x;
	box.pos[1] += y;
	box.pos[2] += z;
}

double timestamp();


LodCluster* processNanite(const char* path)
{
	Mesh mesh;
	if (!loadMesh(mesh, path))
		return nullptr;
	LodCluster* pCluster = nanite(mesh.vertices, mesh.indices);
	return pCluster;
}
};