#include "meshoptimizer/meshoptimizer.h"

#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string>
#include <time.h>
#include "nanight/lodutil.h"
#include "nanight/nanight.h"
#include <vector>
#include <ft2build.h>
#include FT_FREETYPE_H
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "canvas/stb_image_write.h"

#include <iostream>
#include <vector>
int processNanight()
{
	//meshopt_encodeVertexVersion(1);
	//meshopt_encodeIndexVersion(1);
	//lod::LodCluster* pCluster = lod::processNanite("E:\\applib\\prj\\objs_xx_new\\pirate\\pirate.obj");
	lod::LodCluster* pCluster = lod::processNanite("E:\\applib\\prj\\objs_xx_new\\pirate.obj");
	pCluster->printInfo();
	return 0;
}

int main_9(int argc, char** argv)
{
	processNanight();
	return 0;
}


// ---------------- UTF-8 �� Unicode ----------------
static const char* utf8_next(const char* p, uint32_t& code)
{
    unsigned char c = (unsigned char)*p;
    if (c < 0x80) {
        code = c;
        return p + 1;
    }
    else if ((c & 0xE0) == 0xC0) {
        code = ((p[0] & 0x1F) << 6) |
            (p[1] & 0x3F);
        return p + 2;
    }
    else {
        code = ((p[0] & 0x0F) << 12) |
            ((p[1] & 0x3F) << 6) |
            (p[2] & 0x3F);
        return p + 3;
    }
}

void writeImage(int& penX, FT_GlyphSlot g, std::vector<unsigned char>& image, int width, int height) {
        uint32_t code;
        FT_Bitmap& bmp = g->bitmap;
        int x0 = penX + g->bitmap_left;
        int y0 = 0;
        for (int y = 0; y < bmp.rows; y++) {
            for (int x = 0; x < bmp.width; x++) {
                int dstX = x0 + x;
                int dstY = y0 + y;
                if (dstX < 0 || dstY < 0 ||
                    dstX >= width || dstY >= height)
                    continue;

                unsigned char src =
                    bmp.buffer[y * bmp.pitch + x];

                unsigned char& dst =
                    image[dstY * width + dstX];

                if (src > dst)
                    dst = src;
            }
        }
        penX += g->advance.x >> 6;
}

void writeImage1(int& penX, FT_GlyphSlot g, std::vector<unsigned char>& image, int width, int height) {
    uint32_t code;
    FT_Bitmap& bmp = g->bitmap;
    int x0 = penX + g->bitmap_left;
    int y0 = 0;
    int w = bmp.width;
    for (int y = 0; y < bmp.rows; y++) {
        for (int x = 0; x < w; x++) {
            int dstX = x0 + x;
            int dstY = y0 + y;
            if (dstX < 0 || dstY < 0 ||
                dstX >= width || dstY >= height)
                continue;
            unsigned char srcR = bmp.buffer[y * bmp.pitch + x + 0];
            unsigned char& dstR = image[dstY * width + dstX + 0];
            //if (src > dst)
            dstR = srcR;

        }
    }
    penX += g->advance.x >> 6;
}

void writeImageLCD(int& penX, FT_GlyphSlot g, std::vector<unsigned char>& image, int width, int height) {
    uint32_t code;
    FT_Bitmap& bmp = g->bitmap;
    int x0 = penX + g->bitmap_left;
    int y0 = 0;
    int w = bmp.width / 3;
    for (int y = 0; y < bmp.rows; y++) {
        for (int x = 0; x < w; x++) {
            int dstX = x0 + x;
            int dstY = y0 + y;
            if (dstX < 0 || dstY < 0 ||
                dstX >= width || dstY >= height)
                continue;
            unsigned char srcR = bmp.buffer[y * bmp.pitch + x * 3 + 0];
            unsigned char srcG = bmp.buffer[y * bmp.pitch + x * 3 + 1];
            unsigned char srcB = bmp.buffer[y * bmp.pitch + x * 3 + 2];

            unsigned char& dstR = image[dstY * width * 3 + dstX * 3 + 0];
            unsigned char& dstG = image[dstY * width * 3 + dstX * 3 + 1];
            unsigned char& dstB = image[dstY * width * 3 + dstX * 3 + 2];

            //if (src > dst)
                dstR = srcR;
                dstG = srcG;
                dstB = srcB;
        }
    }
    penX += g->advance.x >> 6;
}

#include <ft2build.h>
#include FT_FREETYPE_H
#include <iostream>

int maind() {
    FT_Library ft;
    if (FT_Init_FreeType(&ft)) {
        std::cerr << "FT_Init_FreeType failed\n";
        return -1;
    }

    const char* fontPath = "C:/Windows/Fonts/simsun.ttc";

    FT_Face face;
    int ttcIndex = 0;
    if (FT_New_Face(ft, fontPath, ttcIndex, &face)) {
        std::cerr << "FT_New_Face failed\n";
        return -1;
    }

    std::cout << "Loaded font: " << face->family_name << "\n";
    FT_Set_Char_Size(face, 0, 16 * 64, 96, 96); // 48pt, 96 DPI

    uint32_t code = 0x503C;
    FT_UInt gi = FT_Get_Char_Index(face, code);

    if (gi == 0) {
        std::cerr << "Glyph not found!\n";
    }
    else {
        FT_Load_Glyph(face, gi, FT_LOAD_TARGET_LCD | FT_LOAD_FORCE_AUTOHINT);
        FT_Render_Glyph(face->glyph, FT_RENDER_MODE_LCD);

        FT_Bitmap& bmp = face->glyph->bitmap;
        std::cout << "Bitmap: width=" << bmp.width
            << " rows=" << bmp.rows
            << " pitch=" << bmp.pitch << "\n";
    }

    FT_Done_Face(face);
    FT_Done_FreeType(ft);
    return 0;
}

int mainF()
{
    const char* text = "ֵ";
    const char* fontPath = "C:/Windows/Fonts/msyh.ttc";
    const int fontSize = 16;
    FT_Library ft;
    FT_Face face;

    if (FT_Init_FreeType(&ft)) {
        std::cerr << "FT_Init_FreeType failed\n";
        return -1;
    }

    if (FT_New_Face(ft, fontPath, 0, &face)) {
        std::cerr << "FT_New_Face failed\n";
        return -1;
    }

    FT_Set_Pixel_Sizes(face, 0, fontSize);

    int penX = 0;
    int ascent = 0;
    int descent = 0;
    int width = 300;
    int height = 300;
    std::vector<unsigned char> image(width * height);
    memset(image.data(), 0, image.size());

    penX = 0;
    for (const char* p = text; *p; ) {
        uint32_t code;
        p = utf8_next(p, code);
        FT_UInt gi = FT_Get_Char_Index(face, 0x503c);
        FT_Load_Glyph(face, gi, FT_LOAD_DEFAULT | FT_LOAD_FORCE_AUTOHINT);
        FT_Render_Glyph(face->glyph, FT_RENDER_MODE_NORMAL);
        FT_GlyphSlot g = face->glyph;
        writeImage1(penX, g, image, width, height);
    }
    if (!stbi_write_png(
        "d:/0string.png",
        width,
        height,
        1,          // �Ҷ�
        image.data(),
        width))
    {
        std::cerr << "write png failed\n";
    }

    FT_Done_Face(face);
    FT_Done_FreeType(ft);
    std::cout << "Export string.png success\n";
    return 0;
}

int mainH()
{
    const char* text = "ֵ";
    const char* fontPath = "C:/Windows/Fonts/msyh.ttc";
    const int fontSize = 16;
    FT_Library ft;
    FT_Face face;

    if (FT_Init_FreeType(&ft)) {
        std::cerr << "FT_Init_FreeType failed\n";
        return -1;
    }

    if (FT_New_Face(ft, fontPath, 0, &face)) {
        std::cerr << "FT_New_Face failed\n";
        return -1;
    }

    FT_Set_Pixel_Sizes(face, 0, fontSize);

    int penX = 0;
    int ascent = 0;
    int descent = 0;
    int width = 300;
    int height = 300;
    std::vector<unsigned char> image(width*3 * height);
    memset(image.data(), 0, image.size());

    penX = 0;
    for (const char* p = text; *p; ) {
        uint32_t code;
        p = utf8_next(p, code);
        //FT_Load_Char(face, code, FT_LOAD_RENDER);
        FT_UInt gi = FT_Get_Char_Index(face, 0x503c);
        FT_Load_Glyph(face, gi, FT_LOAD_TARGET_LCD | FT_LOAD_FORCE_AUTOHINT);
        FT_Render_Glyph(face->glyph, FT_RENDER_MODE_LCD);
        FT_GlyphSlot g = face->glyph;
        writeImageLCD(penX, g, image, width, height);
    }
    if (!stbi_write_png(
        "d:/0string.png",
        width,
        height,
        3,          // �Ҷ�
        image.data(),
        width*3))
    {
        std::cerr << "write png failed\n";
    }

    FT_Done_Face(face);
    FT_Done_FreeType(ft);
    std::cout << "Export string.png success\n";
    return 0;
}