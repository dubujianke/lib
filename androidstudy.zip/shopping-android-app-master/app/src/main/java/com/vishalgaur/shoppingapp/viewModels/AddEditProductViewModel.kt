package com.xthea.eggdelivery.viewModels

import android.app.Application
import android.net.Uri
import android.util.Log
import androidx.annotation.VisibleForTesting
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.xthea.eggdelivery.ERR_UPLOAD
import com.xthea.eggdelivery.ShoppingApplication
import com.xthea.eggdelivery.data.Product
import com.xthea.eggdelivery.data.Result.Error
import com.xthea.eggdelivery.data.Result.Success
import com.xthea.eggdelivery.data.ShoppingAppSessionManager
import com.xthea.eggdelivery.data.utils.AddProductErrors
import com.xthea.eggdelivery.data.utils.StoreDataStatus
import com.xthea.eggdelivery.getProductId
import com.xthea.eggdelivery.ui.AddProductViewErrors
import kotlinx.coroutines.async
import kotlinx.coroutines.launch

private const val TAG = "AddEditViewModel"

class AddEditProductViewModel(application: Application) : AndroidViewModel(application) {


	private val sessionManager = ShoppingAppSessionManager(application.applicationContext)

	private val currentUser = sessionManager.getUserIdFromSession()

	private val _selectedCategory = MutableLiveData<String>()
	val selectedCategory: LiveData<String> get() = _selectedCategory

	private val _productId = MutableLiveData<String>()
	val productId: LiveData<String> get() = _productId

	private val _isEdit = MutableLiveData<Boolean>()
	val isEdit: LiveData<Boolean> get() = _isEdit

	private val _errorStatus = MutableLiveData<AddProductViewErrors>()
	val errorStatus: LiveData<AddProductViewErrors> get() = _errorStatus

	private val _dataStatus = MutableLiveData<StoreDataStatus>()
	val dataStatus: LiveData<StoreDataStatus> get() = _dataStatus

	private val _addProductErrors = MutableLiveData<AddProductErrors?>()
	val addProductErrors: LiveData<AddProductErrors?> get() = _addProductErrors

	private val _productData = MutableLiveData<Product>()
	val productData: LiveData<Product> get() = _productData

	@VisibleForTesting(otherwise = VisibleForTesting.PRIVATE)
	val newProductData = MutableLiveData<Product>()

	init {
		_errorStatus.value = AddProductViewErrors.NONE
	}

	fun setIsEdit(state: Boolean) {
		_isEdit.value = state
	}

	fun setCategory(catName: String) {
		_selectedCategory.value = catName
	}

	fun setProductData(productId: String) {
	}

	fun submitProduct(
		name: String,
		price: Double?,
		mrp: Double?,
		desc: String,
		sizes: List<Int>,
		colors: List<String>,
		imgList: List<Uri>,
	) {
	}

	private fun updateProduct(imgList: List<Uri>) {
	}

	private fun insertProduct(imgList: List<Uri>) {
	}

}