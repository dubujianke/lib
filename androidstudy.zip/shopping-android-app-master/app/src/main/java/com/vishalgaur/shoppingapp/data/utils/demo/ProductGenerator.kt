package com.vishalgaur.shoppingapp.data.utils.demo

import com.xthea.eggdelivery.data.Product
import java.util.UUID
import kotlin.random.Random

object ProductGenerator {

	private val names = listOf(
		"新鲜红富士苹果 1kg",
		"进口香蕉 1kg",
		"橙汁饮料 500ml",
		"纯牛奶 250ml×12",
		"香辣方便面 5连包",
		"黄油曲奇饼干 200g",
		"蓝月亮洗衣液 2L",
		"柔软抽纸 3层×10包",
		"速冻猪肉水饺 800g",
		"鸡腿肉串 500g",
		"芒果干 100g",
		"苏打饼干 250g",
		"矿泉水 500ml",
		"酸奶 200ml×8",
		"咖啡饮料 330ml",
		"清新牙膏 120g",
		"洗发露 750ml",
		"纸巾盒装 400抽",
		"冷冻鸡翅中 1kg",
		"玉米棒 2根装"
	)

	private val categories = listOf(
		"水果", "饮料", "零食", "乳制品", "生活用品", "冷冻食品", "粮油调味"
	)

	private val owners = listOf("小象超市自营", "每日优鲜", "盒马鲜生", "京东超市")

	private val colors = listOf("红", "黄", "蓝", "绿", "白", "黑", "粉", "紫")
	private val sizes = listOf(250, 500, 750, 1000, 2000) // ml or g

	// 可用图片 URL (picsum.photos)
	private val imageUrls = listOf(
		"https://bkimg.cdn.bcebos.com/pic/b999a9014c086e061d955c61b25e6cf40ad162d95dd8?x-bce-process=image/format,f_auto/resize,m_lfit,limit_1,h_336",
	)

	fun generateProducts(count: Int = 20): List<Product> {
		val list = mutableListOf<Product>()
		repeat(count) {
			val i = Random.nextInt(names.size)
			val price = Random.nextDouble(5.0, 60.0)
			val mrp = price + Random.nextDouble(3.0, 15.0)

			val product = Product(
				productId = UUID.randomUUID().toString(),
				name = names[i],
				owner = owners.random(),
				description = "${names[i]}，品质保障，新鲜直达。",
				category = categories.random(),
				price = String.format("%.2f", price).toDouble(),
				mrp = String.format("%.2f", mrp).toDouble(),
				availableSizes = sizes.shuffled().take(Random.nextInt(1, 3)),
				availableColors = colors.shuffled().take(Random.nextInt(1, 3)),
				images = listOf(imageUrls[0]),
				rating = Random.nextDouble(3.5, 5.0)
			)
			list.add(product)
		}
		return list
	}
}