package com.xthea.eggdelivery

import android.app.Application

class ShoppingApplication : Application() {
	override fun onCreate() {
		super.onCreate()
	}
}