package com.xthea.eggdelivery.viewModels

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.xthea.eggdelivery.*
import com.xthea.eggdelivery.data.UserData
import com.xthea.eggdelivery.data.utils.LogInErrors
import com.xthea.eggdelivery.data.utils.SignUpErrors
import com.xthea.eggdelivery.data.utils.UserType
import com.xthea.eggdelivery.ui.LoginViewErrors
import com.xthea.eggdelivery.ui.SignUpViewErrors
import kotlinx.coroutines.async
import kotlinx.coroutines.launch

private const val TAG = "AuthViewModel"

class AuthViewModel(application: Application) : AndroidViewModel(application) {


	private val _userData = MutableLiveData<UserData>()
	val userData: LiveData<UserData> get() = _userData

	private val _signErrorStatus = MutableLiveData<SignUpErrors?>()
	val signErrorStatus: LiveData<SignUpErrors?> get() = _signErrorStatus

	private val _errorStatus = MutableLiveData<SignUpViewErrors>()
	val errorStatus: LiveData<SignUpViewErrors> get() = _errorStatus

	private val _errorStatusLoginFragment = MutableLiveData<LoginViewErrors>()
	val errorStatusLoginFragment: LiveData<LoginViewErrors> get() = _errorStatusLoginFragment

	private val _loginErrorStatus = MutableLiveData<LogInErrors?>()
	val loginErrorStatus: LiveData<LogInErrors?> get() = _loginErrorStatus

	init {
	}

	private fun refreshStatus() {
	}

	fun signUpSubmitData(
		name: String,
		mobile: String,
		email: String,
		pwd1: String,
		pwd2: String,
		isAccepted: Boolean,
		isSeller: Boolean
	) {
	}

	private fun checkUniqueUser(uData: UserData) {
	}

	fun loginSubmitData(mobile: String, password: String) {
	}

	private fun logIn(phoneNumber: String, pwd: String) {
	}

	private suspend fun getCurrUser() {
	}
}