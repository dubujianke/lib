package com.xthea.eggdelivery.viewModels

import android.app.Application
import android.util.Log
import androidx.annotation.VisibleForTesting
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.xthea.eggdelivery.ShoppingApplication
import com.xthea.eggdelivery.data.Result.Error
import com.xthea.eggdelivery.data.Result.Success
import com.xthea.eggdelivery.data.ShoppingAppSessionManager
import com.xthea.eggdelivery.data.UserData
import com.xthea.eggdelivery.data.utils.AddObjectStatus
import com.xthea.eggdelivery.data.utils.StoreDataStatus
import com.xthea.eggdelivery.getAddressId
import com.xthea.eggdelivery.isPhoneValid
import com.xthea.eggdelivery.isZipCodeValid
import com.xthea.eggdelivery.ui.AddAddressViewErrors
import kotlinx.coroutines.async
import kotlinx.coroutines.launch

class AddEditAddressViewModel(application: Application) : AndroidViewModel(application) {


	private val sessionManager = ShoppingAppSessionManager(application.applicationContext)
	private val currentUser = sessionManager.getUserIdFromSession()

	private val _isEdit = MutableLiveData<Boolean>()
	val isEdit: LiveData<Boolean> get() = _isEdit

	private val _addressId = MutableLiveData<String>()
	val addressId: LiveData<String> get() = _addressId

	private val _dataStatus = MutableLiveData<StoreDataStatus>()
	val dataStatus: LiveData<StoreDataStatus> get() = _dataStatus

	private val _errorStatus = MutableLiveData<List<AddAddressViewErrors>>()
	val errorStatus: LiveData<List<AddAddressViewErrors>> get() = _errorStatus

	private val _addAddressStatus = MutableLiveData<AddObjectStatus?>()
	val addAddressStatus: LiveData<AddObjectStatus?> get() = _addAddressStatus

	private val _addressData = MutableLiveData<UserData.Address>()
	val addressData: LiveData<UserData.Address> get() = _addressData

	@VisibleForTesting(otherwise = VisibleForTesting.PRIVATE)
	val newAddressData = MutableLiveData<UserData.Address>()

	init {
		_errorStatus.value = mutableListOf()
	}

	fun setIsEdit(state: Boolean) {
		_isEdit.value = state
	}

	fun setAddressData(addressId: String) {
	}

	fun submitAddress(
		countryCode: String,
		firstName: String,
		lastName: String,
		streetAdd: String,
		streetAdd2: String,
		city: String,
		state: String,
		zipCode: String,
		phoneNumber: String
	) {
	}

	private fun updateAddress() {
	}

	private fun insertAddress() {
	}

}