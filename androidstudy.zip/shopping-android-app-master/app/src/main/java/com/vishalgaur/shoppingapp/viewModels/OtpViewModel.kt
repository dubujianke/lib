package com.xthea.eggdelivery.viewModels

import android.app.Application
import android.util.Log
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.google.firebase.FirebaseException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.xthea.eggdelivery.ShoppingApplication
import com.xthea.eggdelivery.data.UserData
import com.xthea.eggdelivery.shouldBypassOTPValidation
import com.xthea.eggdelivery.ui.OTPStatus
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

private const val TAG = "OtpViewModel"

class OtpViewModel(application: Application, private val uData: UserData) :
	AndroidViewModel(application) {

	private val _otpStatus = MutableLiveData<OTPStatus>()
	val otpStatus: LiveData<OTPStatus> get() = _otpStatus

	private val _isOTPSent = MutableLiveData<Boolean>()
	val isOTPSent: LiveData<Boolean> get() = _isOTPSent


	var isUserLoggedIn = MutableLiveData(false)
	var storedVerificationId: String? = ""
	private var verificationInProgress = false
	private lateinit var resendToken: PhoneAuthProvider.ForceResendingToken

	init {
		_isOTPSent.value = false
	}

	fun verifyOTP(otp: String) {
	}

	fun signUp() {
	}

	fun login(rememberMe: Boolean) {
	}

	fun verifyPhoneOTPStart(phoneNumber: String, activity: FragmentActivity) {
	}

	fun manuallyOverrideVerification() {
		if (shouldBypassOTPValidation())
			isUserLoggedIn.value = true
	}

	private val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

		override fun onVerificationCompleted(credential: PhoneAuthCredential) {
		}

		override fun onVerificationFailed(e: FirebaseException) {
		}

		override fun onCodeSent(
			verificationId: String,
			token: PhoneAuthProvider.ForceResendingToken
		) {
		}
	}

	private fun verifyPhoneWithCode(verificationId: String, code: String, isUserLoggedIn: MutableLiveData<Boolean>) {
	}
}