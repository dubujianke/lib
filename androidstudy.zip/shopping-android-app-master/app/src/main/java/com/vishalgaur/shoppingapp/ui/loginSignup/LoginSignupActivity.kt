package com.xthea.eggdelivery.ui.loginSignup

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.xthea.eggdelivery.R

class LoginSignupActivity : AppCompatActivity() {
	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_signup)
	}
}