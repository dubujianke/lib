package com.xthea.eggdelivery.viewModels

import android.app.Application
import android.util.Log
import androidx.lifecycle.*
import com.vishalgaur.shoppingapp.data.utils.demo.ProductGenerator
import com.xthea.eggdelivery.ShoppingApplication
import com.xthea.eggdelivery.data.Product
import com.xthea.eggdelivery.data.Result
import com.xthea.eggdelivery.data.Result.Error
import com.xthea.eggdelivery.data.Result.Success
import com.xthea.eggdelivery.data.ShoppingAppSessionManager
import com.xthea.eggdelivery.data.UserData
import com.xthea.eggdelivery.data.utils.StoreDataStatus
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import java.time.Month
import java.util.*

private const val TAG = "HomeViewModel"

class HomeViewModel(application: Application) : AndroidViewModel(application) {

	private val sessionManager = ShoppingAppSessionManager(application.applicationContext)
	private val currentUser = sessionManager.getUserIdFromSession()
	val isUserASeller = sessionManager.isUserSeller()

	private var _allProducts = MutableLiveData<List<Product>>(emptyList())
	val allProducts: LiveData<List<Product>> get() = _allProducts

	private var _userProducts = MutableLiveData<List<Product>>()
	val userProducts: LiveData<List<Product>> get() = _userProducts

	private var _userOrders = MutableLiveData<List<UserData.OrderItem>>()
	val userOrders: LiveData<List<UserData.OrderItem>> get() = _userOrders

	private var _userAddresses = MutableLiveData<List<UserData.Address>>()
	val userAddresses: LiveData<List<UserData.Address>> get() = _userAddresses

	private var _selectedOrder = MutableLiveData<UserData.OrderItem?>()
	val selectedOrder: LiveData<UserData.OrderItem?> get() = _selectedOrder

	private var _orderProducts = MutableLiveData<List<Product>>()
	val orderProducts: LiveData<List<Product>> get() = _orderProducts

	private var _likedProducts = MutableLiveData<List<Product>>()
	val likedProducts: LiveData<List<Product>> get() = _likedProducts

	private var _userLikes = MutableLiveData<List<String>>()
	val userLikes: LiveData<List<String>> get() = _userLikes

	private var _filterCategory = MutableLiveData("All")
	val filterCategory: LiveData<String> get() = _filterCategory

	private val _storeDataStatus = MutableLiveData<StoreDataStatus>()
	val storeDataStatus: LiveData<StoreDataStatus> get() = _storeDataStatus

	private val _dataStatus = MutableLiveData<StoreDataStatus>()
	val dataStatus: LiveData<StoreDataStatus> get() = _dataStatus

	private val _userData = MutableLiveData<UserData?>()
	val userData: LiveData<UserData?> get() = _userData

	fun generateRandomProducts(count: Int): List<Product> {
		return ProductGenerator.generateProducts(30)
	}

	init {
		viewModelScope.launch {
		}
		getProducts()
	}


	fun setDataLoaded() {
		_storeDataStatus.value = StoreDataStatus.DONE
	}

	fun isProductLiked(productId: String): Boolean {
		return _userLikes.value?.contains(productId) == true
	}

	fun toggleLikeByProductId(productId: String) {
	}

	fun isProductInCart(productId: String): Boolean {
		return false
	}

	fun toggleProductInCart(product: Product) {

	}

	fun setDataLoading() {
	}

	private fun getProducts() {
		_allProducts.value = generateRandomProducts(20)
	}

	fun getUserLikes() {
	}

	fun getLikedProducts() {
	}

	private fun getProductsLiveData(result: Result<List<Product>?>?): LiveData<List<Product>> {
		val res = MutableLiveData<List<Product>>()
		return res
	}


	fun filterBySearch(queryText: String) {
	}

	fun filterProducts(filterType: String) {

	}

	fun deleteProduct(productId: String) {
	}

	fun signOut() {
	}

	fun getAllOrders() {
	}

	fun getOrderDetailsByOrderId(orderId: String) {
	}

	fun onSetStatusOfOrder(orderId: String, status: String) {
	}

	private fun setStatusOfOrder(orderId: String, statusString: String) {
	}

	fun getUserAddresses() {
	}

	fun deleteAddress(addressId: String) {
	}

	fun getUserData() {
	}
}