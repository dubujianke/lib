package com.xthea.eggdelivery.ui.home

import android.content.Context
import android.graphics.Paint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.net.toUri
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.xthea.eggdelivery.R
import com.xthea.eggdelivery.data.Product
import com.xthea.eggdelivery.databinding.ProductsListItemBinding
import com.xthea.eggdelivery.getOfferPercentage

class LikedProductAdapter(proList: List<Product>, private val context: Context) :
	RecyclerView.Adapter<LikedProductAdapter.ViewHolder>() {

	var data = proList
	lateinit var onClickListener: OnClickListener

	inner class ViewHolder(private val binding: ProductsListItemBinding) :
		RecyclerView.ViewHolder(binding.root) {
		fun bind(productData: Product) {
			binding.productCard.setOnClickListener {
				onClickListener.onClick(productData)
			}
			binding.productNameTv.text = productData.name
			binding.productPriceTv.text =
				context.getString(R.string.pro_details_price_value, productData.price.toString())
			binding.productActualPriceTv.apply {
				paintFlags = Paint.STRIKE_THRU_TEXT_FLAG
				text = context.getString(
					R.string.pro_details_actual_strike_value,
					productData.mrp.toString()
				)
			}
			binding.productOfferValueTv.text = context.getString(
				R.string.pro_offer_precent_text,
				getOfferPercentage(productData.mrp, productData.price).toString()
			)
			if (productData.images.isNotEmpty()) {
				val imgUrl = productData.images[0].toUri().buildUpon().scheme("https").build()
				Glide.with(context)
					.asBitmap()
					.load(imgUrl)
					.into(binding.productImageView)
				binding.productImageView.clipToOutline = true
			}
			binding.productAddToCartButton.visibility = View.GONE
		}
	}

	override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
		return ViewHolder(
			ProductsListItemBinding.inflate(
				LayoutInflater.from(parent.context),
				parent,
				false
			)
		)
	}

	override fun onBindViewHolder(holder: ViewHolder, position: Int) {
		holder.bind(data[position])
	}

	override fun getItemCount() = data.size

	interface OnClickListener {
		fun onClick(productData: Product)
		fun onDeleteClick(productId: String)
	}
}