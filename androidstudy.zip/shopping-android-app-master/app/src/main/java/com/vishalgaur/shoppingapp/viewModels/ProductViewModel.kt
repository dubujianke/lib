package com.xthea.eggdelivery.viewModels

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.xthea.eggdelivery.ShoppingApplication
import com.xthea.eggdelivery.data.Product
import com.xthea.eggdelivery.data.Result.Error
import com.xthea.eggdelivery.data.Result.Success
import com.xthea.eggdelivery.data.ShoppingAppSessionManager
import com.xthea.eggdelivery.data.UserData
import com.xthea.eggdelivery.data.utils.AddObjectStatus
import com.xthea.eggdelivery.data.utils.StoreDataStatus
import com.xthea.eggdelivery.ui.AddItemErrors
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import java.util.*

private const val TAG = "ProductViewModel"

class ProductViewModel(private val productId: String, application: Application) :
	AndroidViewModel(application) {

	private val _productData = MutableLiveData<Product?>()
	val productData: LiveData<Product?> get() = _productData

	private val _dataStatus = MutableLiveData<StoreDataStatus>()
	val dataStatus: LiveData<StoreDataStatus> get() = _dataStatus

	private val _errorStatus = MutableLiveData<List<AddItemErrors>>()
	val errorStatus: LiveData<List<AddItemErrors>> get() = _errorStatus

	private val _addItemStatus = MutableLiveData<AddObjectStatus?>()
	val addItemStatus: LiveData<AddObjectStatus?> get() = _addItemStatus

	private val _isLiked = MutableLiveData<Boolean>()
	val isLiked: LiveData<Boolean> get() = _isLiked

	private val _isItemInCart = MutableLiveData<Boolean>()
	val isItemInCart: LiveData<Boolean> get() = _isItemInCart

	private val sessionManager = ShoppingAppSessionManager(application.applicationContext)
	private val currentUserId = sessionManager.getUserIdFromSession()

	init {
		_isLiked.value = false
		_errorStatus.value = emptyList()
		viewModelScope.launch {
			getProductDetails()
			checkIfInCart()
			setLike()
		}
	}

	private fun getProductDetails() {
	}

	fun setLike() {
	}

	fun toggleLikeProduct() {
	}

	fun isSeller() = sessionManager.isUserSeller()

	fun checkIfInCart() {
	}

	fun addToCart(size: Int?, color: String?) {
	}

	private fun insertCartItem(item: UserData.CartItem) {
	}
}