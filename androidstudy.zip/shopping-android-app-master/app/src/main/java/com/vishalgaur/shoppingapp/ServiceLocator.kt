package com.xthea.eggdelivery

import android.content.Context
import androidx.annotation.VisibleForTesting
import com.xthea.eggdelivery.data.ShoppingAppSessionManager


object ServiceLocator {

}