package com.xthea.eggdelivery.viewModels

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.xthea.eggdelivery.ShoppingApplication
import com.xthea.eggdelivery.data.Product
import com.xthea.eggdelivery.data.Result.Error
import com.xthea.eggdelivery.data.Result.Success
import com.xthea.eggdelivery.data.ShoppingAppSessionManager
import com.xthea.eggdelivery.data.UserData
import com.xthea.eggdelivery.data.utils.StoreDataStatus
import com.xthea.eggdelivery.getRandomString
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import java.util.*

private const val TAG = "OrderViewModel"

class OrderViewModel(application: Application) : AndroidViewModel(application) {

	private val sessionManager = ShoppingAppSessionManager(application.applicationContext)
	private val currentUser = sessionManager.getUserIdFromSession()


	private val _userAddresses = MutableLiveData<List<UserData.Address>>()
	val userAddresses: LiveData<List<UserData.Address>> get() = _userAddresses

	private val _userLikes = MutableLiveData<List<String>>()
	val userLikes: LiveData<List<String>> get() = _userLikes

	private val _cartItems = MutableLiveData<List<UserData.CartItem>>()
	val cartItems: LiveData<List<UserData.CartItem>> get() = _cartItems

	private val _priceList = MutableLiveData<Map<String, Double>>()
	val priceList: LiveData<Map<String, Double>> get() = _priceList

	private val _cartProducts = MutableLiveData<List<Product>>()
	val cartProducts: LiveData<List<Product>> get() = _cartProducts

	private val _dataStatus = MutableLiveData<StoreDataStatus>()
	val dataStatus: LiveData<StoreDataStatus> get() = _dataStatus

	private val _orderStatus = MutableLiveData<StoreDataStatus>()
	val orderStatus: LiveData<StoreDataStatus> get() = _orderStatus

	private val _selectedAddress = MutableLiveData<String>()
	private val _selectedPaymentMethod = MutableLiveData<String>()
	private val newOrderData = MutableLiveData<UserData.OrderItem>()

	init {
	}

	fun getCartItems() {
	}

	fun getUserAddresses() {
	}

	fun getUserLikes() {
	}

	fun deleteAddress(addressId: String) {
	}

	fun getItemsPriceTotal(): Double {
		var totalPrice = 0.0
		return totalPrice
	}

	fun toggleLikeProduct(productId: String) {
	}

	fun getItemsCount(): Int {
		var totalCount = 0
		return totalCount
	}

	fun setQuantityOfItem(itemId: String, value: Int) {
	}

	fun deleteItemFromCart(itemId: String) {
	}

	fun setSelectedAddress(addressId: String) {
	}

	fun setSelectedPaymentMethod(method: String) {
	}

	fun finalizeOrder() {
	}

	private fun insertOrder() {
	}

	private suspend fun getAllProductsInCart() {
	}
}