package com.xthea.eggdelivery

import org.hamcrest.CoreMatchers.`is`
import org.hamcrest.MatcherAssert.assertThat
import org.junit.Assert.assertEquals
import org.junit.Test

class UtilsTest {
	open class Animal();
	class Dog:Animal();

	class A<in T>() {
		fun info(t:T) {
			println(t)
		}
	}


	@Test
	fun checkEmail_empty_returnsFalse() {
		val email = ""
		val result = isEmailValid(email)

		assertEquals(result, false)
	}

	@Test
	fun ff() {
		val obj: A<Dog> = A<Animal>();
		obj.info(Dog())

	}

}