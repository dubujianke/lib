# -*- coding: utf-8 -*-
"""
剧本 Decision Agent — Toonflow 三层架构（完全对齐）

  Decision Agent (skills/script_agent_decision.md)
     ↓ tool calls → sub_agents（每个子代理都有独立工具调用循环）
  Sub-Agents:
    skeleton.py     → skills/script_execution_skeleton.md
    adaptation.py   → skills/script_execution_adaptation.md
    script_writer.py → skills/script_execution_script.md
    supervision.py  → skills/script_agent_supervision.md
     ↓
  planData 持久存储

子代理像 Toonflow 一样：收到 prompt（任务描述），自己调 get_planData / get_novel_events / get_novel_text / get_script_content 拿数据，循环调用 LLM 直到完成。
"""

import os, json, sys, re

# 确保可以从当前目录导入
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ai_client import AIClient
from event_extractor import EventExtractor


SKILLS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "skills")

# 调用方式开关：True=流式（对齐原版 streamText），False=非流式
STREAM_MODE = False


def load_skill(name: str) -> str:
    path = os.path.join(SKILLS_DIR, f"{name}.md")
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def _repair_arguments(raw: str) -> dict:
    """尝试修复损坏的 JSON arguments。策略：
    1. 去掉末尾不完整的部分
    2. 如果含 chapterIndexs 数组，尽力提取
    """
    if not raw:
        return {}
    for cut in (0, 1, 2, 5, 10, 20):
        s = raw[:len(raw)-cut] if cut else raw
        try:
            d = json.loads(s)
            if isinstance(d, dict):
                return d
        except (json.JSONDecodeError, TypeError):
            continue
    # 正则提取 chapterIndexs
    try:
        import re
        m = re.search(r'chapterIndexs["\s:]+\[([\d,\s]+)\]', raw)
        if m:
            nums = [int(x) for x in re.findall(r'\d+', m.group(1))]
            return {"chapterIndexs": nums}
        m2 = re.search(r'chapterIndex["\s:]+"?(\d+)', raw)
        if m2:
            return {"chapterIndex": m2.group(1)}
    except Exception:
        pass
    return {}


def extract_xml_tag(text: str, tag: str) -> str:
    """提取 <tag>...</tag> 标签内的内容（支持带属性的开标签）。
    优先匹配成对标签；若无闭合标签，则从开标签截取到文本末尾。
    """
    if not text:
        return ""
    m = re.search(rf"<{tag}[^>]*>(.*?)</{tag}>", text, re.DOTALL)
    if m:
        return m.group(1).strip()
    m = re.search(rf"<{tag}[^>]*>(.*)$", text, re.DOTALL)
    if m:
        return m.group(1).strip()
    return ""


# ============ 数据访问工具定义（与 Toonflow tools.ts 完全一致） ============

DATA_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "get_novel_events",
            "description": "获取章节事件",
            "parameters": {
                "type": "object",
                "properties": {
                    "chapterIndexs": {
                        "type": "array",
                        "items": {"type": "integer"},
                        "description": "章节的编号"
                    }
                },
                "required": ["chapterIndexs"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_plan_data",
            "description": "获取工作区数据",
            "parameters": {
                "type": "object",
                "properties": {
                    "key": {
                        "type": "string",
                        "enum": ["storySkeleton", "adaptationStrategy", "script"],
                        "description": "数据key：storySkeleton / adaptationStrategy / script"
                    }
                },
                "required": ["key"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_novel_text",
            "description": "获取小说章节原始文本内容",
            "parameters": {
                "type": "object",
                "properties": {
                    "chapterIndex": {
                        "type": "string",
                        "description": "章节编号"
                    }
                },
                "required": ["chapterIndex"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_script_content",
            "description": "获取剧本本内容",
            "parameters": {
                "type": "object",
                "properties": {
                    "ids": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "脚本id"
                    }
                },
                "required": ["ids"]
            }
        }
    },
]


class SubAgentRunner:
    """通用的子代理执行器：有独立工具调用循环，完全对齐 Toonflow"""

    def __init__(self, client: AIClient, plan_data: dict, novel_text: str, chapters: list, events: list, scripts: list):
        self.client = client
        self.plan_data = plan_data
        self.novel_text = novel_text
        self.chapters = chapters
        self.events = events
        self.scripts = scripts

    # ---------- 数据工具执行（与 Toonflow tools.ts 完全一致） ----------

    def _execute_data_tool(self, name: str, args: dict) -> str:
        if name == "get_novel_events":
            # 参数: chapterIndexs: number[]（必填，对应 Toonflow 强制分批）
            chapter_indexs = args.get("chapterIndexs", [])
            total = len(self.events)
            if not chapter_indexs:
                return f"无数据。可查询章节范围为 1~{total}。请传入 chapterIndexs。"
            # 过滤超出范围的章节
            valid_idx = [i for i in chapter_indexs if 1 <= i <= total]
            if not valid_idx:
                return f"指定的章节 {chapter_indexs} 不在范围 1~{total} 内，无数据。全书共有 {total} 章。"
            event_strings = []
            for idx in valid_idx:
                ev = self.events[idx-1]
                # Toonflow: "第X章，标题:xxx，事件:xxx"
                event_strings.append(f"第{idx}章，标题:第{idx}章，事件:{ev}")
            return "\n".join(event_strings)
        if name == "get_novel_text":
            # 参数: chapterIndex: string
            chapter_index = args.get("chapterIndex", "")
            try:
                idx = int(chapter_index)
            except (ValueError, TypeError):
                return "无数据"
            if 1 <= idx <= len(self.chapters):
                return self.chapters[idx-1]
            return "无数据"
        if name == "get_plan_data":
            # 参数: key: 'storySkeleton' | 'adaptationStrategy' | 'script'
            key = args.get("key", "")
            value = self.plan_data.get(key, "")
            if not value:
                return "无数据"
            # Toonflow 存储时 removeAllXmlTags 去掉了 XML 标签，这里也去掉，返回干净内容
            return re.sub(r'<[^>]+>', '', value).strip()
        if name == "get_script_content":
            # 参数: ids: string[]
            ids = args.get("ids", [])
            if ids and self.scripts:
                # Toonflow: <scriptItem name="...">content</scriptItem>
                items = []
                for i, s in enumerate(self.scripts):
                    if str(i) in ids or str(i+1) in ids:
                        items.append(f'<scriptItem name="第{i+1}集">{s}</scriptItem>')
                return "\n".join(items) if items else "无数据"
            return "无数据"
        return f"未知工具: {name}"

    def _call_with_tools(self, messages: list, tools: list, category: str) -> dict:
        """调用 LLM 支持 function calling。
        默认流式（对齐原版 streamText + consumeFullStream），STREAM_MODE=False 切非流式。
        """
        if STREAM_MODE:
            return self._call_with_tools_stream(messages, tools, category)
        return self._call_with_tools_nostream(messages, tools, category)

    def _call_with_tools_nostream(self, messages: list, tools: list, category: str) -> dict:
        """非流式：完整响应后解析"""
        resp = self.client._client.chat.completions.create(
            model=self.client.config.model,
            messages=messages,
            tools=tools,
            tool_choice="auto",
            temperature=self.client.config.temperature,
            max_tokens=32768,
        )
        msg = resp.choices[0].message
        tool_calls = []
        if msg.tool_calls:
            tool_calls = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.function.name or "",
                        "arguments": tc.function.arguments or "",
                    },
                }
                for tc in msg.tool_calls
            ]
        # DeepSeek 思考模式：工具调用轮必须把 reasoning_content 回传
        reasoning = getattr(msg, "reasoning_content", None)

        # 记录日志（对齐 devtools：input / output / raw）
        if self.client.log_dir:
            sys_text = next((m["content"] for m in messages if m.get("role") == "system" and isinstance(m.get("content"), str)), "")
            user_text = "\n".join(
                m["content"] for m in messages
                if m.get("role") == "user" and isinstance(m.get("content"), str)
            ) or str(messages)
            raw = {
                "model": self.client.config.model,
                "content": msg.content or "",
                "reasoning_content": reasoning,
                "tool_calls": tool_calls,
            }
            self.client._log(category, sys_text, user_text, msg.content or "", raw=raw)

        return {
            "content": msg.content or "",
            "tool_calls": tool_calls,
            "reasoning_content": reasoning,
        }

    def _call_with_tools_stream(self, messages: list, tools: list, category: str) -> dict:
        """流式：逐 chunk 消费，累积 content / tool_calls / reasoning_content（对齐原版 streamText）"""
        stream = self.client._client.chat.completions.create(
            model=self.client.config.model,
            messages=messages,
            tools=tools,
            tool_choice="auto",
            temperature=self.client.config.temperature,
            max_tokens=32768,
            stream=True,
        )

        content_parts: list[str] = []
        reasoning_parts: list[str] = []
        tool_calls_map: dict[int, dict] = {}

        for chunk in stream:
            if not chunk.choices:
                continue
            delta = chunk.choices[0].delta
            if delta is None:
                continue
            piece = getattr(delta, "content", None) or ""
            if piece:
                content_parts.append(piece)
            think = getattr(delta, "reasoning_content", None) or ""
            if think:
                reasoning_parts.append(think)
            for tc in (delta.tool_calls or []):
                idx = tc.index
                if idx not in tool_calls_map:
                    tool_calls_map[idx] = {"id": "", "function": {"name": "", "arguments": ""}}
                if tc.id:
                    tool_calls_map[idx]["id"] = tc.id
                if tc.function and tc.function.name:
                    tool_calls_map[idx]["function"]["name"] = tc.function.name
                if tc.function and tc.function.arguments:
                    tool_calls_map[idx]["function"]["arguments"] += tc.function.arguments
        stream.close()

        content = "".join(content_parts)
        reasoning = "".join(reasoning_parts)
        tool_calls = list(tool_calls_map.values()) if tool_calls_map else []

        # 记录日志（对齐 devtools：input / output / raw）
        if self.client.log_dir:
            sys_text = next((m["content"] for m in messages if m.get("role") == "system" and isinstance(m.get("content"), str)), "")
            user_text = "\n".join(
                m["content"] for m in messages
                if m.get("role") == "user" and isinstance(m.get("content"), str)
            ) or str(messages)
            raw = {
                "model": self.client.config.model,
                "content": content,
                "reasoning_content": reasoning,
                "tool_calls": tool_calls,
            }
            self.client._log(category, sys_text, user_text, content, raw=raw)

        return {
            "content": content,
            "tool_calls": tool_calls,
            "reasoning_content": reasoning,
        }

    def run(self, system_prompt: str, prompt: str, category: str,
            xml_tag: str = "", assistant_context: str = "",
            max_turns: int = None) -> str:
        """执行子代理：循环调用 LLM + 数据工具，直到模型不再调用工具为止。
        完全对齐 Toonflow runAgent：
        - system = systemPrompt（+formatPrompt 已在调用方拼好）
        - messages = [assistant(预注入), user(prompt，已含 formatPrompt)]
        - 工具循环上限 = 工具数 × 50（对应 stopWhen: stepCountIs）
        - 累积所有 content（对应 consumeFullStream 累积所有 text-delta）
        """
        if max_turns is None:
            max_turns = len(DATA_TOOLS) * 50
        print(f"    [子代理:{category}] 开始...")

        messages = [{"role": "system", "content": system_prompt}]
        if assistant_context:
            # Toonflow: messages 里先放一条 assistant 预注入信息
            messages.append({"role": "assistant", "content": assistant_context})
        messages.append({"role": "user", "content": prompt})
        accumulated = ""  # 累积所有 content（对应 consumeFullStream 累积 text-delta）

        for turn in range(max_turns):
            resp = self._call_with_tools(messages, DATA_TOOLS, category)
            content = resp.get("content", "")
            if content:
                accumulated += content

            if not resp.get("tool_calls"):
                # 模型不再调用工具，说明完成
                print(f"    [子代理:{category}] 完成 (共{len(accumulated)}字)")
                # 校验 XML 标签成对（同时存在开+闭标签），否则强制重试
                if xml_tag:
                    open_tag = f"<{xml_tag}>"
                    close_tag = f"</{xml_tag}>"
                    # 开标签可能带属性，用 <tag 前缀匹配
                    has_open = f"<{xml_tag}" in accumulated and ">" in accumulated
                    has_close = close_tag in accumulated
                    if not (has_open and has_close):
                        print(f"    [子代理:{category}] XML 标签不完整(开:{has_open}/闭:{has_close})，重试...")
                        messages.append({
                            "role": "user",
                            "content": f"你的输出必须用成对的 {open_tag} 和 {close_tag} 包裹完整内容，"
                                       f"且标签前后不得有任何其他文字。请重新完整输出。"
                        })
                        continue
                return accumulated

            # 处理工具调用
            for tc in resp["tool_calls"]:
                fn = tc["function"]
                name = fn["name"]
                try:
                    args = json.loads(fn.get("arguments") or "{}")
                    if not isinstance(args, dict):
                        args = {}
                except (json.JSONDecodeError, TypeError):
                    # arguments 损坏时容错：提取基本参数或置空
                    raw = fn.get("arguments") or ""
                    print(f"    [子代理:{category}] arguments 解析失败({len(raw)}字符)，尝试修复...")
                    args = _repair_arguments(raw)
                print(f"    [子代理:{category}] 调工具 → {name} 参数={json.dumps(args, ensure_ascii=False)}")

                result_text = self._execute_data_tool(name, args)
                # 打印工具返回结果（完整）
                print(f"    [子代理:{category}] ← {name} 返回: {result_text}")
                # DeepSeek 思考模式：assistant 工具调用消息必须带上 reasoning_content 回传
                asst_msg = {"role": "assistant", "content": None, "tool_calls": [tc]}
                if resp.get("reasoning_content"):
                    asst_msg["reasoning_content"] = resp["reasoning_content"]
                messages.append(asst_msg)
                messages.append({"role": "tool", "tool_call_id": tc["id"],
                                 "content": result_text[:8000]})

        print(f"    [子代理:{category}] 达到最大轮次")
        return accumulated


# ============ Decision Agent 工具（含子代理工具） ============

def build_decision_tools(runner: SubAgentRunner):
    """构建 Decision Agent 的完整工具集（数据 + 子代理）"""
    tools = list(DATA_TOOLS)

    # 子代理工具：像 Toonflow 一样，只传 prompt（任务描述），子代理自己调数据工具
    # tools_names: 每个子代理只暴露自己需要的工具（对应 Toonflow useTools 的 toolsNames 过滤）
    sub_agent_tools = [
        {
            "name": "run_sub_agent_story_skeleton",
            "skill": "script_execution_skeleton",
            "format": "\n你必须使用如下XML格式写入工作区：\n<storySkeleton>故事骨架内容</storySkeleton>",
            "xml_tag": "storySkeleton",
            "description": "运行执行subAgent来完成故事骨架相关任务",
            "tools_names": ["get_plan_data", "get_novel_events"],
        },
        {
            "name": "run_sub_agent_adaptation_strategy",
            "skill": "script_execution_adaptation",
            "format": "\n你必须使用如下XML格式写入工作区：\n<adaptationStrategy>改编策略内容</adaptationStrategy>",
            "xml_tag": "adaptationStrategy",
            "description": "运行执行subAgent来完成改编策略相关任务",
            "tools_names": ["get_plan_data", "get_novel_events"],
        },
        {
            "name": "run_sub_agent_script",
            "skill": "script_execution_script",
            "format": "\n你必须使用如下XML格式写入工作区：\nXML不得添加任何额外标签"
                      "<scriptItem name=\"剧本名称\">剧本内容</scriptItem>"
                      "<scriptItem name=\"剧本名称\">剧本内容</scriptItem>"
                      "<scriptItem name=\"剧本名称\">剧本内容</scriptItem>",
            "xml_tag": "scriptItem",
            "description": "运行执行subAgent来完成剧本相关任务",
            "tools_names": ["get_plan_data", "get_novel_text", "get_script_content", "get_novel_events"],
        },
        {
            "name": "run_supervision_agent",
            "skill": "script_agent_supervision",
            "format": "",
            "xml_tag": "",
            "description": "运行监督层subAgent执行独立任务，完成后返回结果",
            "tools_names": ["get_plan_data", "get_script_content"],
        },
    ]

    # 每个子代理工具：参数只有一个 prompt
    for sa in sub_agent_tools:
        tools.append({
            "type": "function",
            "function": {
                "name": sa["name"],
                "description": sa["description"],
                "parameters": {
                    "type": "object",
                    "properties": {
                        "prompt": {"type": "string", "description": "交给子Agent的任务简约描述，100字以内"}
                    },
                    "required": ["prompt"]
                }
            }
        })

    # finish 工具
    tools.append({
        "type": "function",
        "function": {
            "name": "finish",
            "description": "完成所有工作，生成最终总结。",
            "parameters": {
                "type": "object",
                "properties": {
                    "summary": {"type": "string"}
                },
                "required": ["summary"]
            }
        }
    })
    return tools, sub_agent_tools


class ScriptAgent:
    """Decision Agent：自主决定调用哪些子代理（完全对齐 Toonflow）"""

    def __init__(self, client: AIClient, log_dir: str = None, data_dir: str = None):
        self.client = client
        self.decision_prompt = load_skill("script_agent_decision")
        self.event_extractor = EventExtractor(client, log_dir=log_dir)

        # 工作区
        self.plan_data = {}
        self.novel_text = ""
        self.chapters = []
        self.events = []
        self.scripts = []

        # 子代理执行器
        self.runner = SubAgentRunner(client, self.plan_data, self.novel_text,
                                     self.chapters, self.events, self.scripts)
        self.decision_tools, self.sub_agent_specs = build_decision_tools(self.runner)

        # 决策层记忆（对齐 Toonflow Memory）
        self.memory = None
        self._data_dir = data_dir

    def load_data(self, chapters: list[str], events: list[str], config: dict = None):
        """外部注入章节原文、事件表、项目配置（不重新提取事件）"""
        self.chapters = chapters
        self.events = events
        self.novel_text = "\n\n".join(chapters)
        self.runner.chapters = chapters
        self.runner.events = events
        self.runner.novel_text = self.novel_text

        total = len(chapters)
        dur_min = int(config.get("episodeDuration", 2) or 2) if config else 2
        eps = int(config.get("totalEpisodes", 0) or 0) if config else 0
        if eps <= 0:
            eps = max(1, total // 3)
        self.plan_data = {
            "projectConfig": {
                "episodeDuration": dur_min * 60,
                "episodeCount": eps,
                "totalChapters": total,
                "startChapter": int(config.get("startChapter", 1) or 1) if config else 1,
                "endChapter": int(config.get("endChapter", total) or total) if config else total,
                "platform": config.get("platform", "16:9") if config else "16:9",
                "style": config.get("style", "") if config else "",
                "paywall": config.get("paywall", "") if config else "",
            }
        }
        # 加载已持久化的工作区（storySkeleton / adaptationStrategy），供修复/衔接使用
        self._load_plan_data()
        self.runner.plan_data = self.plan_data

    def _plan_data_file(self) -> str:
        """工作区持久化文件路径（对齐原版 o_agentWorkData）"""
        if self._data_dir:
            return os.path.join(self._data_dir, "plan_data.json")
        return os.path.join("data", "plan_data.json")

    def _load_plan_data(self):
        f = self._plan_data_file()
        if os.path.isfile(f):
            try:
                with open(f, "r", encoding="utf-8") as fp:
                    saved = json.load(fp)
                for k in ("storySkeleton", "adaptationStrategy"):
                    if saved.get(k):
                        self.plan_data[k] = saved[k]
            except Exception:
                pass

    def _save_plan_data(self):
        try:
            with open(self._plan_data_file(), "w", encoding="utf-8") as fp:
                json.dump({
                    "storySkeleton": self.plan_data.get("storySkeleton", ""),
                    "adaptationStrategy": self.plan_data.get("adaptationStrategy", ""),
                }, fp, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def dispatch(self, user_message: str, max_turns: int = 30) -> dict:
        """Decision Agent 调度入口：接受用户指令，决策层自主调子代理/数据工具。
        对齐原版 runDecisionAI：
        - system = decision skill
        - assistant = 项目信息 + 记忆
        - user = 用户指令
        - Memory：add 用户消息；注入 get() 记忆；deepRetrieve 工具
        """
        # 初始化记忆（对齐原版 new Memory("scriptAgent", isolationKey)）
        if self.memory is None:
            from memory import Memory, build_mem_prompt
            isolation_key = f"project:{self._data_dir or 'default'}:scriptAgent"
            self.memory = Memory("scriptAgent", isolation_key,
                                 data_dir=os.path.join(self._data_dir or "", "memory"),
                                 client=self.client)

        # 原版 runDecisionAI: 先 add 用户消息，再 memory.get(text) 取记忆
        self.memory.add("user", user_message)
        mem = build_mem_prompt(self.memory.get(user_message))

        pc = self.plan_data.get("projectConfig", {})
        project_info = [
            "## 项目信息",
            f"小说名称：{pc.get('name', '未知')}",
            f"章节数量：{len(self.chapters)}章",
            f"集数：{pc.get('episodeCount', '?')}",
            f"单集时长：{pc.get('episodeDuration', '?')}秒（约{int(pc.get('episodeDuration', 0))//60*150 if pc.get('episodeDuration') else 0}字台词）",
            f"原著范围：第{pc.get('startChapter', 1)}-{pc.get('endChapter', len(self.chapters))}章",
            f"章节范围：{pc.get('startChapter', 1)}-{pc.get('endChapter', len(self.chapters))}",
            f"平台规格：{pc.get('platform', '16:9')}",
            f"风格定位：{pc.get('style', '')}",
            f"付费策略：{pc.get('paywall', '')}",
        ]

        messages = [
            {"role": "system", "content": self.decision_prompt},
            {"role": "assistant", "content": "\n".join(project_info) + "\n" + mem},
            {"role": "user", "content": user_message},
        ]

        # 追加 deepRetrieve 工具（对齐原版 memory.getTools()）
        tools = list(self.decision_tools)
        tools.append({
            "type": "function",
            "function": {
                "name": "deepRetrieve",
                "description": "深度检索记忆：当你需要回忆与某个关键词相关的详细历史信息时使用此工具",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "keyword": {"type": "string", "description": "要检索的关键词"}
                    },
                    "required": ["keyword"]
                }
            }
        })

        for turn in range(max_turns):
            print(f"\n  [Decision Agent] 第 {turn+1} 轮思考...")
            resp = self._call_decision(messages, tools=tools)

            if not resp.get("tool_calls"):
                print(f"  [Decision Agent] 完成: {resp.get('content', '')[:200]}")
                break

            for tc in resp["tool_calls"]:
                fn = tc["function"]
                name = fn["name"]
                try:
                    args = json.loads(fn.get("arguments") or "{}")
                    if not isinstance(args, dict):
                        args = {}
                except (json.JSONDecodeError, TypeError):
                    raw = fn.get("arguments") or ""
                    print(f"  [Decision Agent] arguments 解析失败，尝试修复...")
                    args = _repair_arguments(raw)
                print(f"  [Decision Agent] → {name}")

                if name == "deepRetrieve":
                    keyword = args.get("keyword", "")
                    results = self.memory.deep_retrieve(keyword)
                    if results:
                        result_text = "找到相关记忆：\n" + "\n".join(r["content"] for r in results)
                    else:
                        result_text = "未找到相关记忆"
                else:
                    result_text = self._execute_decision_tool(name, args)
                    # 执行/监督结果写入记忆（对齐原版 onFinish / runAgent 的 memory.add）
                    if name == "run_sub_agent_story_skeleton":
                        self.memory.add("assistant:execution:storySkeleton", result_text, name="编剧")
                    elif name == "run_sub_agent_adaptation_strategy":
                        self.memory.add("assistant:execution:adaptationStrategy", result_text, name="编剧")
                    elif name == "run_sub_agent_script":
                        self.memory.add("assistant:execution:script", result_text, name="编剧")
                    elif name == "run_supervision_agent":
                        self.memory.add("assistant:supervision", result_text, name="编辑")
                print(f"  [Decision Agent] ← {name} 返回 {len(result_text)} 字")
                # DeepSeek 思考模式：assistant 工具调用消息必须带上 reasoning_content 回传
                asst_msg = {"role": "assistant", "content": None, "tool_calls": [tc]}
                if resp.get("reasoning_content"):
                    asst_msg["reasoning_content"] = resp["reasoning_content"]
                messages.append(asst_msg)
                messages.append({"role": "tool", "tool_call_id": tc["id"],
                                 "content": result_text[:8000]})

                if name == "finish":
                    break

        return {
            "story_skeleton": self.plan_data.get("storySkeleton", ""),
            "adaptation_strategy": self.plan_data.get("adaptationStrategy", ""),
            "script": self.plan_data.get("script", ""),
            "quality_review": self.plan_data.get("qualityReview", ""),
        }

    def execute(self, novel_text: str, chapters: list[str]) -> dict:
        """完整流程（旧入口，保留兼容）"""
        self.novel_text = novel_text
        self.chapters = chapters
        self._extract_events()

        # 初始化项目配置（Toonflow 所需）
        self.plan_data = {
            "projectConfig": {
                "episodeDuration": 60,
                "episodeCount": min(len(chapters) * 3, 100),
                "chargeStrategy": "standard",
                "totalChapters": len(chapters),
            }
        }

        messages = [
            {"role": "system", "content": self.decision_prompt},
            {"role": "user", "content": f"请开始处理这部小说。共 {len(chapters)} 章。"
                                        f"先拉取事件列表，然后按流程生成。完成后请质检。"}
        ]

        for turn in range(20):
            print(f"\n  [Decision Agent] 第 {turn+1} 轮思考...")
            resp = self._call_decision(messages)

            if not resp.get("tool_calls"):
                print(f"  [Decision Agent] {resp['content'][:200]}")
                break

            for tc in resp["tool_calls"]:
                fn = tc["function"]
                name = fn["name"]
                try:
                    args = json.loads(fn.get("arguments") or "{}")
                    if not isinstance(args, dict):
                        args = {}
                except (json.JSONDecodeError, TypeError):
                    raw = fn.get("arguments") or ""
                    print(f"  [Decision Agent] arguments 解析失败，尝试修复...")
                    args = _repair_arguments(raw)
                print(f"  [Decision Agent] → {name}")

                result_text = self._execute_decision_tool(name, args)
                messages.append({"role": "assistant", "content": None, "tool_calls": [tc]})
                messages.append({"role": "tool", "tool_call_id": tc["id"],
                                 "content": result_text[:8000]})

                if name == "finish":
                    break

        return {
            "story_skeleton": self.plan_data.get("storySkeleton", ""),
            "adaptation_strategy": self.plan_data.get("adaptationStrategy", ""),
            "script": self.plan_data.get("script", ""),
            "quality_review": self.plan_data.get("qualityReview", ""),
        }

    # ==================== 事件提取 ====================

    def _extract_events(self):
        for i, ch in enumerate(self.chapters):
            print(f"  [Event] 提取第 {i+1}/{len(self.chapters)} 章...")
            ev = self.event_extractor.extract(i + 1, ch)
            self.events.append(ev)

    # ==================== Decision Agent 调用 ====================

    def _call_decision(self, messages: list, tools: list = None) -> dict:
        return self.runner._call_with_tools(messages, tools or self.decision_tools, "decision")

    # ==================== Decision Agent 工具执行 ====================

    def _execute_decision_tool(self, name: str, args: dict) -> str:
        # 数据层工具
        data_names = {"get_novel_events", "get_novel_text", "get_plan_data", "get_script_content"}
        if name in data_names:
            return self.runner._execute_data_tool(name, args)

        # 子代理工具（完全对齐 Toonflow：只传 prompt，子代理自己调数据工具）
        for sa in self.sub_agent_specs:
            if name == sa["name"]:
                prompt = args.get("prompt", "")
                system_prompt = load_skill(sa["skill"]) + sa["format"]
                category = name.replace("run_sub_agent_", "").replace("_", "")
                # 按原版"派发格式模板"规范派发指令（对齐 script_agent_decision.md 派发格式模板）
                pc = self.plan_data.get("projectConfig", {})
                cfg_block = "\n".join([
                    "【项目配置】",
                    f"- 集数：{pc.get('episodeCount', '?')}集",
                    f"- 单集时长：{pc.get('episodeDuration', 0) // 60 if pc.get('episodeDuration') else '?'}分钟"
                    f"（约{int(pc.get('episodeDuration', 0) or 0) // 60 * 150 if pc.get('episodeDuration') else '?'}字台词）",
                    f"- 原著范围：第{pc.get('startChapter', 1)}-{pc.get('endChapter', len(self.chapters))}章",
                    f"- 章节范围：{pc.get('startChapter', 1)}-{pc.get('endChapter', len(self.chapters))}",
                    f"- 平台规格：{pc.get('platform', '16:9')}",
                    f"- 风格定位：{pc.get('style', '')}",
                    f"- 付费策略：{pc.get('paywall', '')}",
                ])
                # 任务名映射
                task_name = "故事骨架" if "story_skeleton" in name else ("改编策略" if "adaptation" in name else "剧本" if "script" in name else "审核")
                if "supervision" in name:
                    # 监督/复审：对齐"审核请求"模板
                    prompt = (f"请审核【{task_name}】的产出物。\n{cfg_block}\n\n"
                              f"审核维度：{prompt}")
                else:
                    # 执行/修复：对齐原版两种格式
                    #   生成：配置在前 → 【项目配置】... 请执行【故事骨架】任务...
                    #   修复：指令在前 → 请执行【故事骨架修复】任务。【项目配置】... 目标：...
                    is_fix = "修复" in prompt or "遗留" in prompt
                    task_label = f"{task_name}修复" if is_fix else task_name
                    if is_fix:
                        tail = "修复后更新planData。"
                        prompt = (f"请执行【{task_label}】任务。\n"
                                  f"{cfg_block}\n\n"
                                  f"目标：{prompt}\n{tail}")
                    else:
                        prompt = (f"{cfg_block}\n\n"
                                  f"请执行【{task_label}】任务。\n"
                                  f"目标：{prompt}")
                result = self.runner.run(system_prompt, prompt, category,
                                         xml_tag=sa.get("xml_tag", ""))
                # 对齐原版：前端按 tag 解析只存标签内内容，去掉"阐述思路"等杂质
                tag = sa.get("xml_tag", "")
                clean = extract_xml_tag(result, tag) if tag else result
                if not clean:
                    clean = result
                # 保存到 plan_data
                if "story_skeleton" in name:
                    self.plan_data["storySkeleton"] = clean
                    self._save_plan_data()
                elif "adaptation_strategy" in name:
                    self.plan_data["adaptationStrategy"] = clean
                    self._save_plan_data()
                elif name == "run_sub_agent_script":
                    self.plan_data["script"] = clean
                    self.scripts.append(clean)
                elif "supervision" in name:
                    self.plan_data["qualityReview"] = clean
                return result

        if name == "finish":
            self.plan_data["summary"] = args.get("summary", "")
            return "完成"

        return f"未知工具: {name}"
