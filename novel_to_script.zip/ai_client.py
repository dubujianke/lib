# -*- coding: utf-8 -*-
"""AI 客户端封装 - 基于 OpenAI SDK（兼容 DeepSeek 等 OpenAI 接口）
   支持流式与非流式，自动记录输入/输出/原始响应到日志
"""

import json
import os
from dataclasses import dataclass
from typing import Optional

from openai import OpenAI


# 全局日志目录（记录每次 LLM 输入输出）
LOG_DIR = os.environ.get("LLM_LOG_DIR", "")
_LOG_SEQ = 0


@dataclass
class AIConfig:
    api_key: str = "sk-d542e24e9d004aada8d138e24a87e54b"
    base_url: str = "https://api.deepseek.com/v1"
    model: str = "deepseek-v4-flash"
    temperature: float = 1
    timeout: int = 300

    def __post_init__(self):
        if not self.api_key:
            self.api_key = os.environ.get("LLM_API_KEY", "")
        if not self.api_key:
            print("⚠ 未设置 API Key！请在 ai_client.py 中配置或设置环境变量 LLM_API_KEY")


class AIClient:
    """封装 LLM 调用，支持流式 + 非流式，自动记录输入输出到日志"""

    def __init__(self, config: Optional[AIConfig] = None, log_dir: str = None):
        self.config = config or AIConfig()
        # verify=False 跳过 SSL 证书校验
        self._client = OpenAI(
            api_key=self.config.api_key,
            base_url=self.config.base_url,
            timeout=self.config.timeout,
            max_retries=1,
        )
        self.log_dir = log_dir or LOG_DIR

    def _log(self, category: str, system: str, user: str, result: str, raw: dict = None):
        """记录一次 LLM 调用的输入输出到文件。
        与原版 @ai-sdk/devtools 的 step 记录对齐：保存完整原始响应（含 reasoning_content）。
        """
        if not self.log_dir:
            return
        global _LOG_SEQ
        _LOG_SEQ += 1
        os.makedirs(self.log_dir, exist_ok=True)
        seq = _LOG_SEQ
        try:
            # 输入
            with open(os.path.join(self.log_dir, f"{seq:04d}_{category}_input.txt"), "w", encoding="utf-8") as f:
                f.write(f"=== SYSTEM ===\n{system}\n\n=== USER ===\n{user}")
            # 输出（最终答案）
            with open(os.path.join(self.log_dir, f"{seq:04d}_{category}_output.txt"), "w", encoding="utf-8") as f:
                f.write(result)
            # 原始响应（含 reasoning_content），对齐原版 raw_response
            if raw is not None:
                with open(os.path.join(self.log_dir, f"{seq:04d}_{category}_raw.json"), "w", encoding="utf-8") as f:
                    json.dump(raw, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def chat(self, system: str, user: str, stream: bool = False, category: str = "chat") -> str:
        """非流式调用，返回完整文本"""
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]
        resp = self._client.chat.completions.create(
            model=self.config.model,
            messages=messages,
            stream=False,
            temperature=self.config.temperature,
        )
        content = resp.choices[0].message.content or ""
        reasoning = getattr(resp.choices[0].message, "reasoning_content", None)
        raw = {
            "id": resp.id,
            "model": resp.model,
            "usage": resp.usage.model_dump() if resp.usage else None,
            "choices": [
                {
                    "index": resp.choices[0].index,
                    "message": {
                        "role": resp.choices[0].message.role,
                        "content": resp.choices[0].message.content,
                        "reasoning_content": reasoning,
                    },
                    "finish_reason": resp.choices[0].finish_reason,
                }
            ],
        }
        self._log(category, system, user, content, raw=raw)
        return content

    def stream_chat(self, system: str, user: str, category: str = "chat"):
        """流式调用，返回 (内容生成器, 完整文本最终结果)。
        用法：
            gen, full = client.stream_chat(system, user)
            for piece in gen:
                print(piece, end="")
            text = full()
        """
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]
        stream = self._client.chat.completions.create(
            model=self.config.model,
            messages=messages,
            stream=True,
            temperature=self.config.temperature,
        )

        collected: list[str] = []
        reasoning: list[str] = []

        def generator():
            for chunk in stream:
                if not chunk.choices:
                    continue
                delta = chunk.choices[0].delta
                if delta is None:
                    continue
                piece = getattr(delta, "content", None) or ""
                think = getattr(delta, "reasoning_content", None) or ""
                if think:
                    reasoning.append(think)
                if piece:
                    collected.append(piece)
                    yield piece
            stream.close()

        def full():
            text = "".join(collected)
            raw = {
                "model": self.config.model,
                "reasoning_content": "".join(reasoning),
                "content": text,
            }
            self._log(category, system, user, text, raw=raw)
            return text

        return generator(), full

    def close(self):
        try:
            self._client.close()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
