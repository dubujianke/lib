import json, sys
sys.stdout.reconfigure(encoding='utf-8')
data = json.load(open(r'F:\toonflow\ToonFlow\.devtools\generations.json', encoding='utf-8'))
steps = data['steps']
for s in steps:
    if s['run_id'] == '20260802040540922-64f1e4ee':
        # 打印所有消息的完整内容
        req = s.get('raw_request')
        req_json = json.loads(req) if isinstance(req, str) else req
        print("=== RAW_REQUEST keys:", list(req_json.keys()))
        msgs = req_json.get('messages', [])
        for i, m in enumerate(msgs):
            role = m.get('role')
            content = m.get('content', '')
            extra = {k: v for k, v in m.items() if k not in ('role', 'content')}
            print(f"\n----- msg[{i}] role={role} extra={extra} len={len(content) if isinstance(content,str) else '?'} -----")
            if isinstance(content, str):
                print(content[:1500])
        break
