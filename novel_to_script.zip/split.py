import os
import re

def split_novel(input_file, output_dir, save_preface=True):
    """
    将小说 TXT 按章节分割，每章保存为一个独立文件。
    """
    os.makedirs(output_dir, exist_ok=True)

    # 自动尝试常见编码
    encodings = ['utf-8', 'gbk', 'gb18030', 'utf-16']
    content = None
    for enc in encodings:
        try:
            with open(input_file, 'r', encoding=enc) as f:
                content = f.read()
            break
        except UnicodeDecodeError:
            continue
    if content is None:
        raise ValueError("无法识别文件编码，请手动指定编码")

    lines = content.splitlines()

    # 匹配“第X章”开头的行（支持阿拉伯数字和简单中文数字）
    chapter_pattern = re.compile(r'^第[0-9零一二三四五六七八九十百千万]+章\b.*')

    chapters = []
    preface_lines = []
    current_title = None
    current_lines = []
    in_preface = True

    for line in lines:
        if chapter_pattern.match(line.strip()):
            if current_title is not None:
                chapters.append((current_title, current_lines))
            current_title = line.strip()
            current_lines = []
            in_preface = False
        else:
            if in_preface:
                preface_lines.append(line)
            else:
                current_lines.append(line)

    # 保存最后一个章节
    if current_title is not None:
        chapters.append((current_title, current_lines))

    # 保存前言
    if save_preface and preface_lines:
        preface_text = '\n'.join(preface_lines).strip()
        if preface_text:
            preface_path = os.path.join(output_dir, "前言.txt")
            with open(preface_path, 'w', encoding='utf-8') as f:
                f.write(preface_text)
            print(f"已保存前言: {preface_path}")

    # 保存各章节
    for idx, (title, body_lines) in enumerate(chapters, start=1):
        body_text = '\n'.join(body_lines).strip()
        # 清理文件名中的非法字符
        safe_title = re.sub(r'[\\/*?:"<>|]', '_', title)
        if len(safe_title) > 50:
            safe_title = safe_title[:50]
        filepath = os.path.join(output_dir, f"{safe_title}.txt")

        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(title + '\n\n')
            f.write(body_text)

        print(f"[{idx}/{len(chapters)}] {safe_title}.txt")

    print(f"分割完成！共 {len(chapters)} 章，所有文件已保存到：{output_dir}")


if __name__ == "__main__":
    # ====== 请根据你的实际路径修改这里 ======
    novel_path = r"D:\xiaoshuo_data_merge\1.txt"
    # 新建一个目录存放所有章节（可根据喜好修改名称）
    output_folder = r"D:\xiaoshuo_data_merge\1"
    # =======================================

    split_novel(novel_path, output_folder, save_preface=True)