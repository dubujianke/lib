# -*- coding: utf-8 -*-
"""事件提取：逐章提取结构化事件
   Prompt 从 skills/event_extraction.md 加载
   user 消息格式与原版 Toonflow cleanNovel.ts 完全一致
   输入输出写入 log 文件
"""

import os
import re
from datetime import datetime
from ai_client import AIClient

SKILLS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "skills")


def strip_think(text: str) -> str:
    """去除深度思考模型输出的 <think>...</think> 标签及其内容（对应原版 stripThink）"""
    return re.sub(r"<think>[\s\S]*?</think>", "", text).strip()


def load_skill(name: str) -> str:
    path = os.path.join(SKILLS_DIR, f"{name}.md")
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Skill 文件不存在: {path}")
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


class EventExtractor:

    def __init__(self, client: AIClient, log_dir: str = None):
        self.client = client
        self.prompt = load_skill("event_extraction")
        self.log_dir = log_dir

    def _log(self, filename: str, content: str):
        if not self.log_dir:
            return
        full = os.path.join(self.log_dir, filename)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "w", encoding="utf-8") as f:
            f.write(content)

    def extract(self, chapter_index: int, chapter_text: str, chapter: str = "", reel: str = "") -> str:
        # 与原版 cleanNovel.ts 的 user 消息拼接完全一致，全文传入不截断
        user = ("请根据以下小说章节数：" + str(chapter_index) +
                "小说章节券：" + reel +
                "小说章节名称：" + chapter +
                "、小说章节内容生成事件摘要：\n" + chapter_text)
        ts = datetime.now().strftime("%H:%M:%S")
        print(f"    [{ts}] 第{chapter_index}章, 输入{len(chapter_text)}字 -> 发送{len(user)}字")

        # 记录输入
        self._log(f"log_events/{chapter_index}_input.txt",
                  f"SYSTEM:\n{self.prompt}\n\nUSER:\n{user}")

        result = self.client.chat(self.prompt, user, category="event")
        result = strip_think(result)
        print(f"    [{ts}] 第{chapter_index}章, 输出{len(result)}字")

        # 记录输出
        self._log(f"log_events/{chapter_index}_output.txt", result)

        return result
