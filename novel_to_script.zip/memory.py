# -*- coding: utf-8 -*-
"""决策层记忆 Memory — 完全对齐 Toonflow src/utils/agent/memory.ts
   存储：data/{projectId}/memory.json
   机制：add() 写入消息，满 messagesPerSummary 条自动生成摘要；
        get() 返回 shortTerm(近期) + summaries(摘要) + rag(相关检索)；
        deepRetrieve() 关键词检索历史（向量搜索用关键词匹配近似）。
"""

import os
import json
import uuid
import time

import numpy as np


# 全局 embedding 模型（懒加载，对齐原版 initEmbedding）
_EMBED_SESSION = None
_EMBED_TOKENIZER = None


def _get_embedder():
    """懒加载原版 all-MiniLM-L6-v2 ONNX 模型（对齐原版 embedding.ts initEmbedding）"""
    global _EMBED_SESSION, _EMBED_TOKENIZER
    if _EMBED_SESSION is not None:
        return _EMBED_SESSION, _EMBED_TOKENIZER
    import onnxruntime as ort
    from transformers import AutoTokenizer

    model_dir = os.environ.get(
        "MINILM_MODEL_DIR",
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "all-MiniLM-L6-v2"),
    )
    onnx_path = os.path.join(model_dir, "onnx", "model_fp16.onnx")
    _EMBED_SESSION = ort.InferenceSession(onnx_path, providers=["CPUExecutionProvider"])
    _EMBED_TOKENIZER = AutoTokenizer.from_pretrained(model_dir, local_files_only=True)
    return _EMBED_SESSION, _EMBED_TOKENIZER


def get_embedding(text: str) -> list:
    """对齐原版 getEmbedding：MiniLM ONNX + mean pooling + 归一化"""
    sess, tokenizer = _get_embedder()
    tokens = tokenizer(text, padding=True, truncation=True, max_length=256, return_tensors="np")
    outputs = sess.run(None, {
        "input_ids": tokens["input_ids"],
        "attention_mask": tokens["attention_mask"],
        "token_type_ids": np.zeros_like(tokens["input_ids"]),
    })
    last_hidden = outputs[0]  # (batch, seq, 384)
    mask = tokens["attention_mask"].astype(np.float32)[:, :, None]
    pooled = (last_hidden * mask).sum(axis=1) / mask.sum(axis=1)
    pooled = pooled / np.linalg.norm(pooled, axis=1, keepdims=True)
    return pooled[0].tolist()


def _simple_embed(text: str) -> list:
    """兼容旧路径：直接走 MiniLM"""
    return get_embedding(text)


# 与 Toonflow memory.ts DEFAULTS 一致
DEFAULTS = {
    "messagesPerSummary": 3,   # 每累积多少条message触发一次summary生成
    "summaryMaxLength": 500,   # summary最大字符长度
    "shortTermLimit": 5,       # get()返回的近期未总结message条数
    "summaryLimit": 10,        # get()返回的summary条数
    "ragLimit": 3,             # get()相关检索返回条数
    "deepRetrieveSummaryLimit": 5,
}


def _cosine(a: list, b: list) -> float:
    """对齐原版 cosineSimilarity（归一化向量点积）"""
    if not a or not b or len(a) != len(b):
        return 0.0
    return sum(x * y for x, y in zip(a, b))


class Memory:
    def __init__(self, agent_type: str, isolation_key: str, data_dir: str = "data", client=None):
        self.agentType = agent_type
        self.isolationKey = isolation_key
        self.client = client  # AIClient，用于生成摘要
        self.store_path = os.path.join(data_dir, "memory.json")
        self._ensure_file()

    def _ensure_file(self):
        os.makedirs(os.path.dirname(self.store_path) or ".", exist_ok=True)
        if not os.path.isfile(self.store_path):
            self._save({"rows": []})

    def _load(self) -> dict:
        try:
            with open(self.store_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {"rows": []}

    def _save(self, data: dict):
        with open(self.store_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def _rows(self) -> list:
        return self._load().get("rows", [])

    def _add_row(self, row: dict):
        data = self._load()
        data["rows"].append(row)
        self._save(data)

    def _update_rows(self, rows: list):
        data = self._load()
        data["rows"] = rows
        self._save(data)

    # ---------- 摘要生成（对齐 generateSummary） ----------

    def _generate_summary(self, contents: list) -> str:
        max_len = DEFAULTS["summaryMaxLength"]
        if not self.client:
            return " ".join(contents)[:max_len]
        user = "\n".join(f"{i+1}. {c}" for i, c in enumerate(contents))
        try:
            text = self.client.chat(
                system=f"你是一个记忆压缩助手。请将以下多条记忆内容压缩为一段简洁的摘要，不超过{max_len}个字符。只输出摘要内容，不要加任何前缀或解释。",
                user=user,
                category="memory_summary",
            )
            return text[:max_len]
        except Exception:
            return " ".join(contents)[:max_len]

    # ---------- add（对齐 add） ----------

    def add(self, role: str = "user", content: str = "", name: str = None, create_time: int = None):
        row = {
            "id": uuid.uuid4().hex,
            "isolationKey": self.isolationKey,
            "type": "message",
            "role": role,
            "name": name,
            "content": content,
            "embedding": _simple_embed(content),
            "relatedMessageIds": None,
            "summarized": 0,
            "createTime": create_time or int(time.time() * 1000),
        }
        self._add_row(row)

        # 检查未总结消息数量，满 messagesPerSummary 触发摘要
        unsummarized = [r for r in self._rows()
                        if r["isolationKey"] == self.isolationKey
                        and r["type"] == "message" and r["summarized"] == 0]
        unsummarized.sort(key=lambda r: r["createTime"])
        if len(unsummarized) >= DEFAULTS["messagesPerSummary"]:
            batch = unsummarized[:DEFAULTS["messagesPerSummary"]]
            batch_ids = [r["id"] for r in batch]
            batch_contents = [r["content"] for r in batch]

            summary_content = self._generate_summary(batch_contents)
            summary_row = {
                "id": uuid.uuid4().hex,
                "isolationKey": self.isolationKey,
                "type": "summary",
                "content": summary_content,
                "embedding": _simple_embed(summary_content),
                "relatedMessageIds": batch_ids,
                "summarized": 0,
                "createTime": int(time.time() * 1000),
            }
            self._add_row(summary_row)

            # 标记已总结
            rows = self._rows()
            for r in rows:
                if r["id"] in batch_ids:
                    r["summarized"] = 1
            self._update_rows(rows)

    # ---------- get（对齐 get） ----------

    def get(self, text: str) -> dict:
        rows = [r for r in self._rows() if r["isolationKey"] == self.isolationKey]

        # shortTerm: 最近未被总结的 messages
        short_term = [r for r in rows if r["type"] == "message" and r["summarized"] == 0]
        short_term.sort(key=lambda r: r["createTime"], reverse=True)
        short_term = short_term[:DEFAULTS["shortTermLimit"]]
        short_term.reverse()

        # summaries: 最近的 summary
        summaries = [r for r in rows if r["type"] == "summary"]
        summaries.sort(key=lambda r: r["createTime"], reverse=True)
        summaries = summaries[:DEFAULTS["summaryLimit"]]
        summaries.reverse()

        # rag: 相似检索所有 messages
        query_emb = _simple_embed(text)
        messages = [r for r in rows if r["type"] == "message"]
        scored = [(r, _cosine(query_emb, r.get("embedding") or [])) for r in messages]
        scored.sort(key=lambda x: x[1], reverse=True)
        rag = [r for r, _ in scored[:DEFAULTS["ragLimit"]]]

        return {
            "shortTerm": [{"id": r["id"], "role": r["role"], "name": r.get("name"),
                           "content": r["content"], "createTime": r["createTime"]} for r in short_term],
            "summaries": [{"id": r["id"], "content": r["content"],
                           "relatedMessageIds": r.get("relatedMessageIds") or [],
                           "createTime": r["createTime"]} for r in summaries],
            "rag": [{"id": r["id"], "content": r["content"]} for r in rag],
        }

    # ---------- deepRetrieve（对齐 deepRetrieve，简化：直接相似检索） ----------

    def deep_retrieve(self, keyword: str) -> list:
        rows = [r for r in self._rows()
                if r["isolationKey"] == self.isolationKey and r["type"] == "message"]
        query_emb = _simple_embed(keyword)
        scored = [(r, _cosine(query_emb, r.get("embedding") or [])) for r in rows]
        scored.sort(key=lambda x: x[1], reverse=True)
        results = scored[:DEFAULTS["deepRetrieveSummaryLimit"]]
        return [{"id": r["id"], "content": r["content"], "createTime": r["createTime"]} for r, _ in results]


def build_mem_prompt(mem: dict) -> str:
    """对齐 Toonflow index.ts buildMemPrompt"""
    parts = []
    if mem.get("rag"):
        parts.append("[相关记忆]\n" + "\n".join(r["content"] for r in mem["rag"]))
    if mem.get("summaries"):
        if parts:
            parts.append("")
        parts.append("[历史摘要]\n" + "\n".join(f"{i+1}. {s['content']}" for i, s in enumerate(mem["summaries"])))
    if mem.get("shortTerm"):
        if parts:
            parts.append("")
        parts.append("[近期对话]\n" + "\n".join(f"{m['role']}: {m['content']}" for m in mem["shortTerm"]))
    return "## Memory\n以下是你对用户的记忆，可作为参考但不要主动提及：\n" + "\n".join(parts)
