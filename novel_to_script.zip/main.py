# -*- coding: utf-8 -*-
"""小说→剧本 AI流水线（toonflow 架构）
   用法:
     python main.py --projectId abc            # 项目ID
     python main.py --projectId D:/xiaoshuo_data/113566   # 绝对路径
"""

import sys, os, re, argparse, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ai_client import AIClient
from script_agent import ScriptAgent


DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")


def extract_xml_tag(text: str, tag: str) -> str:
    """提取 <tag>...</tag> 标签内的内容（支持带属性的开标签如 <tag name="x">）。
    优先匹配成对标签；若无闭合标签，则从开标签截取到文本末尾。
    """
    if not text:
        return ""
    # 成对标签（支持属性）
    m = re.search(rf"<{tag}[^>]*>(.*?)</{tag}>", text, re.DOTALL)
    if m:
        return m.group(1).strip()
    # 只有开标签，截取到末尾
    m = re.search(rf"<{tag}[^>]*>(.*)$", text, re.DOTALL)
    if m:
        return m.group(1).strip()
    return ""


def parse_episodes(skeleton: str) -> list:
    """从骨架 <storySkeleton> 内容解析分集。
    匹配格式: ### 集{N}：{标题}（第X-Y章） 或 ### 集{N}: {标题}（第X-Y章）
    返回 [{num, title, chapters}] 列表。
    """
    episodes = []
    for m in re.finditer(r'^#{1,3}\s*集(\d+)[：:]\s*(.+?)（第(.+?)章）', skeleton, re.MULTILINE):
        num = int(m.group(1))
        title = m.group(2).strip()
        chapters = m.group(3).strip()
        episodes.append({"num": num, "title": title, "chapters": chapters})
    # 若没匹配到带章节的，退而匹配 "### 集{N}：{标题}"
    if not episodes:
        for m in re.finditer(r'^#{1,3}\s*集(\d+)[：:]\s*(.+)', skeleton, re.MULTILINE):
            episodes.append({"num": int(m.group(1)), "title": m.group(2).strip(), "chapters": ""})
    episodes.sort(key=lambda e: e["num"])
    return episodes


def parse_chapter_range(chapters_str: str) -> list:
    """解析章节范围字符串，如 "1-3" → [1,2,3]；"1,5-7" → [1,5,6,7]。"""
    if not chapters_str:
        return []
    result = []
    for part in str(chapters_str).split(","):
        part = part.strip()
        m = re.match(r'^(\d+)-(\d+)$', part)
        if m:
            a, b = int(m.group(1)), int(m.group(2))
            result.extend(range(a, b + 1))
        elif part.isdigit():
            result.append(int(part))
    return sorted(set(result))


def extract_episode_info(skeleton: str, ep_num: int) -> str:
    """从骨架中提取指定集的完整信息块。
    匹配 "### 集{N}：标题（第X-Y章）" 到下一个 "### 集{N+1}" 之前的内容。
    返回该集的戏剧功能/场景核心/章节分配/删减决策/集末钩子等。
    """
    # 找该集标题。注意 f-string 里正则量词 {1,3} 需转义为 {{1,3}}
    start = re.search(rf'#{{1,3}}\s*集{ep_num}[：:][^\n]*', skeleton)
    if not start:
        return ""
    s_idx = start.start()
    nxt = re.search(rf'#{{1,3}}\s*集{ep_num + 1}[：:][^\n]*', skeleton)
    e_idx = nxt.start() if nxt else len(skeleton)
    return skeleton[s_idx:e_idx].strip()


def check_adaptation_modules(text: str) -> list:
    """校验改编策略是否包含必需模块，返回缺失模块列表。"""
    missing = []
    required = {
        "核心改编原则": ["核心改编原则"],
        "主要删除决策": ["主要删除决策", "删除决策"],
        "世界观呈现策略": ["世界观呈现策略", "世界观"],
        "矛盾强化": ["矛盾强化", "矛盾升级", "矛盾四级"],
        "信息差策略": ["信息差", "观众先知", "观众焦急", "观众上帝"],
        "反转对齐": ["股价级反转", "反转"],
        "情绪基调映射": ["情绪基调", "甜宠", "复仇", "重生逆袭", "家庭伦理"],
        "八大改编要点": ["强画面感", "画面感", "可拍摄性", "台词精简", "节奏", "单主线", "情绪大于"],
        "短剧用语规范": ["家主", "市首", "执法局", "亿元", "口语化", "短剧语言"],
    }
    for name, keywords in required.items():
        if not any(kw in text for kw in keywords):
            missing.append(name)

    # 校验核心改编原则条数（3-5条）：只统计"核心改编原则"到"主要删除决策"之间的编号条目
    principle_section = ""
    m = re.search(r'核心改编原则(.*?)(?:主要删除决策|主要删减决策)', text, re.DOTALL)
    if m:
        principle_section = m.group(1)
    count = len(re.findall(r'^#{1,3}\s*\d+[\.、]', principle_section, re.MULTILINE)) \
        + len(re.findall(r'^\d+[\.、]\s*[^\n]', principle_section, re.MULTILINE))
    if count < 3 or count > 5:
        missing.append(f"核心改编原则条数({count})需为3-5条")
    return missing


def load_from_folder(folder_path: str) -> tuple:
    """文件夹模式：读取章节 txt，支持两种命名
       1.txt / 2.txt...
       第1章 xxx.txt / 第100章 xxx.txt...
       跳过 info.txt
       返回 (chapters, chapter_meta)，chapter_meta = [{index, chapter, reel}, ...]
    """
    files = []
    for f in os.listdir(folder_path):
        if not f.endswith(".txt") or f.lower() == "info.txt":
            continue
        # 提取章节号
        m = re.match(r"(\d+)", f)  # 数字开头: 1.txt
        if not m:
            m = re.search(r"第(\d+)章", f)  # "第X章" 开头
        if m:
            files.append((int(m.group(1)), f))
    files.sort(key=lambda x: x[0])

    chapters = []
    chapter_meta = []
    for idx, f in files:
        with open(os.path.join(folder_path, f), "r", encoding="utf-8") as fp:
            content = fp.read().strip()
            if content:
                chapters.append(content)
                # 章标题：优先从 "第X章 标题" 提取，纯数字文件名则用空
                title = ""
                tm = re.search(r"第\d+章\s*(.+)", f)
                if tm:
                    title = tm.group(1).replace(".txt", "").strip()
                chapter_meta.append({"index": idx, "chapter": title, "reel": ""})
        print(f"  [OK] 第{idx}章  {f}")
    return chapters, chapter_meta


def load_project_config() -> dict:
    """读取项目配置文件 project_config.json（不存在则返回空）"""
    cfg_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "project_config.json")
    if os.path.isfile(cfg_file):
        with open(cfg_file, "r", encoding="utf-8") as fp:
            return json.load(fp)
    return {}


def build_project_config_block(cfg: dict, total_chapters: int) -> str:
    """构建原版【项目配置】头部文本"""
    eps = cfg.get("totalEpisodes", 0)
    dur = cfg.get("episodeDuration", 0)
    words = int(dur) * 150 if dur else 0
    lines = [
        "【项目配置】",
        f"- 集数：{eps}集" if eps else "",
        f"- 单集时长：{dur}分钟（约{words}字台词）" if dur else "",
        f"- 原著范围：第{cfg.get('startChapter', 1)}-{cfg.get('endChapter', total_chapters)}章",
        f"- 章节范围：{cfg.get('startChapter', 1)}-{cfg.get('endChapter', total_chapters)}",
        f"- 平台规格：{cfg.get('platform', '16:9')}",
        f"- 风格定位：{cfg.get('style', '')}",
        f"- 付费策略：{cfg.get('paywall', '')}",
    ]
    return "\n".join(l for l in lines if l)


def main():
    parser = argparse.ArgumentParser(description="小说→剧本 AI流水线")
    parser.add_argument("path", nargs="?", help="小说文件夹路径")
    parser.add_argument("--projectId", "-p", dest="projectId", help="小说文件夹路径")
    parser.add_argument("--dry-run", action="store_true", help="只加载章节，不跑AI")
    parser.add_argument("--extract-events", action="store_true", help="执行第二步：事件提取")
    parser.add_argument("--skeleton", action="store_true", help="执行第三步：故事骨架")
    parser.add_argument("--adaptation", action="store_true", help="执行第四步：改编策略")
    parser.add_argument("--script", action="store_true", help="执行第五步：剧本撰写")
    parser.add_argument("--start", type=int, default=1, help="起始章节号，默认1")
    parser.add_argument("--end", type=int, default=0, help="结束章节号，默认全部")
    parser.add_argument("--episodes", type=int, default=0, help="改编集数，默认自动按章节数推算")
    parser.add_argument("--ep", type=str, default="", help="只跑指定集，如 1 或 1,3,5")
    parser.add_argument("--duration", type=int, default=60, help="单集时长(秒)，默认60")
    parser.add_argument("--agent", type=str, default="", help="Decision Agent 模式：传入用户指令，如 '生成故事骨架'")
    parser.add_argument("--style", type=str, default="", help="风格定位，如 '幻爽剧'（覆盖配置文件）")
    parser.add_argument("--paywall", type=str, default="", help="付费策略，如 '前2集免费，第3集开始付费'（覆盖配置文件）")
    args = parser.parse_args()

    novel_path = args.projectId or args.path
    if not novel_path:
        novel_path = input("小说文件夹路径: ").strip().strip('"')

    # 如果是纯数字或简单名称，自动补全到 D:\xiaoshuo_data
    if not os.path.isabs(novel_path) and "/" not in novel_path and "\\" not in novel_path:
        novel_path = os.path.join(r"D:\xiaoshuo_data", novel_path)
    novel_path = os.path.abspath(novel_path)

    if not os.path.isdir(novel_path):
        print(f"路径不存在或不是文件夹: {novel_path}")
        return

    project_name = os.path.basename(novel_path)
    print(f"项目: {project_name}")
    print(f"路径: {novel_path}")

    client = AIClient(log_dir=os.path.join(DATA_DIR, project_name, "logs"))
    print(f"模型: {client.config.model}")

    # 读取章节
    chapters, chapter_meta = load_from_folder(novel_path)
    novel_text = "\n\n".join(chapters)
    print(f"共 {len(chapters)} 章, {len(novel_text)} 字\n")

    if args.dry_run:
        out_dir = os.path.join(DATA_DIR, project_name)
        chapters_dir = os.path.join(out_dir, "chapters")
        os.makedirs(chapters_dir, exist_ok=True)
        with open(os.path.join(out_dir, "chapters_info.txt"), "w", encoding="utf-8") as f:
            for i, ch in enumerate(chapters):
                chapter_file = os.path.join(chapters_dir, f"{i+1}.txt")
                with open(chapter_file, "w", encoding="utf-8") as cf:
                    cf.write(ch)
                title = chapter_meta[i]["chapter"] if i < len(chapter_meta) else ""
                f.write(f"第{i+1}章: {len(ch)}字" + (f" | {title}" if title else "") + "\n")
        print(f"[dry-run] 共 {len(chapters)} 章, {len(novel_text)} 字")
        print(f"[dry-run] 目录: {out_dir}")
        print(f"[dry-run] 章节: {chapters_dir}")
        print(f"[dry-run] 正式运行去掉 --dry-run")
        return

    # Decision Agent 模式：加载已有事件/章节，决策层自主调度子代理
    if args.agent:
        from script_agent import ScriptAgent, load_skill
        out_dir = os.path.join(DATA_DIR, project_name)

        # 加载章节原文
        chapters_dir = os.path.join(out_dir, "chapters")
        events_dir = os.path.join(out_dir, "events")
        if not (os.path.isdir(chapters_dir) and os.path.isdir(events_dir)):
            print("请先执行 --dry-run 和 --extract-events 生成章节与事件数据")
            return

        chapter_nums = sorted(int(f[:-4]) for f in os.listdir(chapters_dir) if f[:-4].isdigit())
        chapters = []
        for n in chapter_nums:
            with open(os.path.join(chapters_dir, f"{n}.txt"), "r", encoding="utf-8") as fp:
                chapters.append(fp.read())

        events = []
        for n in chapter_nums:
            ev_file = os.path.join(events_dir, f"{n}.txt")
            if os.path.isfile(ev_file):
                with open(ev_file, "r", encoding="utf-8") as fp:
                    events.append(fp.read())
            else:
                events.append("")

        cfg = load_project_config()
        # 命令行参数覆盖配置文件（--episodes / --duration(秒) / --start / --end / --style）
        if args.episodes > 0:
            cfg["totalEpisodes"] = args.episodes
        if args.duration != 60:
            cfg["episodeDuration"] = args.duration / 60  # 转分钟
        if args.start > 1:
            cfg["startChapter"] = args.start
        if args.end > 0:
            cfg["endChapter"] = args.end
        if getattr(args, "style", None):
            cfg["style"] = args.style
        if getattr(args, "paywall", None):
            cfg["paywall"] = args.paywall
        agent = ScriptAgent(client, log_dir=out_dir, data_dir=out_dir)
        agent.load_data(chapters, events, cfg)

        print(f"[agent] 用户指令: {args.agent}")
        print(f"[agent] 章节: {len(chapters)} 章, 事件: {len(events)} 个")

        # 指定章节范围
        if args.start > 1 or args.end > 0:
            chapter_nums_filtered = [n for n in chapter_nums
                                     if args.start <= n <= (args.end if args.end > 0 else 10**9)]
            agent.runner.events = [events[n-1] for n in chapter_nums_filtered]
            agent.runner.chapters = [chapters[n-1] for n in chapter_nums_filtered]
            print(f"[agent] 限定范围: 第{args.start}-{args.end if args.end>0 else chapter_nums[-1]}章, {len(chapter_nums_filtered)}章")

        result = agent.dispatch(args.agent)

        # 保存产出物
        os.makedirs(out_dir, exist_ok=True)
        if result["story_skeleton"]:
            clean = extract_xml_tag(result["story_skeleton"], "storySkeleton")
            content = f"<storySkeleton>\n{clean}\n</storySkeleton>" if clean else result["story_skeleton"]
            with open(os.path.join(out_dir, "story_skeleton.xml"), "w", encoding="utf-8") as f:
                f.write(content)
            print(f"[agent] 骨架已保存: {out_dir}\\story_skeleton.xml")
        if result["adaptation_strategy"]:
            clean = extract_xml_tag(result["adaptation_strategy"], "adaptationStrategy")
            content = f"<adaptationStrategy>\n{clean}\n</adaptationStrategy>" if clean else result["adaptation_strategy"]
            with open(os.path.join(out_dir, "adaptation_strategy.xml"), "w", encoding="utf-8") as f:
                f.write(content)
            print(f"[agent] 改编策略已保存: {out_dir}\\adaptation_strategy.xml")
        if result["script"]:
            script_dir = os.path.join(out_dir, "scripts")
            os.makedirs(script_dir, exist_ok=True)
            with open(os.path.join(script_dir, "agent_script.xml"), "w", encoding="utf-8") as f:
                f.write(result["script"])
            print(f"[agent] 剧本已保存: {script_dir}\\agent_script.xml")
        if result["quality_review"]:
            with open(os.path.join(out_dir, "quality_review.md"), "w", encoding="utf-8") as f:
                f.write(result["quality_review"])
            print(f"[agent] 审核报告已保存: {out_dir}\\quality_review.md")
        return

    # 第二步：事件提取（从 data 目录读章节）
    if args.extract_events:
        from event_extractor import EventExtractor
        out_dir = os.path.join(DATA_DIR, project_name)
        data_chapters_dir = os.path.join(out_dir, "chapters")
        if not os.path.isdir(data_chapters_dir):
            print("请先执行第一步: python main.py --projectId {projectId} --dry-run")
            return

        chapter_files = sorted(
            [f for f in os.listdir(data_chapters_dir) if f[:-4].isdigit()],
            key=lambda f: int(f[:-4])
        )
        # 章节范围过滤
        chapter_files = [f for f in chapter_files
                         if args.start <= int(f[:-4]) <= (args.end if args.end > 0 else 10**9)]

        # 读取章标题映射（dry-run 时写入 chapters_info.txt）
        chapter_titles = {}
        info_file = os.path.join(out_dir, "chapters_info.txt")
        if os.path.isfile(info_file):
            with open(info_file, "r", encoding="utf-8") as fp:
                for line in fp:
                    m = re.match(r"第(\d+)章: \d+字 \| (.*)", line.strip())
                    if m:
                        chapter_titles[int(m.group(1))] = m.group(2)

        extractor = EventExtractor(client, log_dir=out_dir)
        events_dir = os.path.join(out_dir, "events")
        os.makedirs(events_dir, exist_ok=True)

        for f in chapter_files:
            event_file = os.path.join(events_dir, f)
            if os.path.isfile(event_file):
                continue
            idx = int(f[:-4])
            with open(os.path.join(data_chapters_dir, f), "r", encoding="utf-8") as fp:
                ch = fp.read()
            ev = extractor.extract(idx, ch, chapter=chapter_titles.get(idx, ""), reel="")
            with open(event_file, "w", encoding="utf-8") as fp:
                fp.write(ev)

        print(f"[events] 完成！范围 {args.start}~{args.end if args.end>0 else len(chapter_files)} 章")
        print(f"[events] 输出: {events_dir}")
        return

    # 第三步：故事骨架
    if args.skeleton:
        from script_agent import SubAgentRunner, load_skill
        out_dir = os.path.join(DATA_DIR, project_name)
        events_dir = os.path.join(out_dir, "events")
        if not os.path.isdir(events_dir):
            print("请先执行第二步: python main.py --projectId {projectId} --extract-events")
            return

        # 读取指定范围的事件
        chapter_files = sorted(
            [f for f in os.listdir(events_dir) if f[:-4].isdigit()],
            key=lambda f: int(f[:-4])
        )
        chapter_files = [f for f in chapter_files
                         if args.start <= int(f[:-4]) <= (args.end if args.end > 0 else 10**9)]

        events_list = []
        for f in chapter_files:
            with open(os.path.join(events_dir, f), "r", encoding="utf-8") as fp:
                content = fp.read()
            events_list.append(content)

        print(f"[skeleton] 范围 {args.start}~{chapter_files[-1].rstrip('.txt') if chapter_files else '?'} 章, {len(chapter_files)} 个事件")

        # 项目配置：优先取配置文件 project_config.json，命令行参数覆盖
        cfg = load_project_config()
        episode_count = args.episodes if args.episodes > 0 else int(cfg.get("totalEpisodes", 0) or 0)
        if episode_count <= 0:
            episode_count = max(1, len(chapter_files) // 3)
        duration_sec = args.duration if args.duration != 60 else int(cfg.get("episodeDuration", 0) or 0) * 60
        if duration_sec <= 0:
            duration_sec = args.duration
        plan_data = {
            "projectConfig": {
                "episodeDuration": duration_sec,
                "episodeCount": episode_count,
                "totalChapters": len(chapter_files),
            },
            "storySkeleton": "",
        }
        print(f"[skeleton] 集数: {episode_count}, 单集时长: {duration_sec}秒")

        # 原版【项目配置】头部（决策层派发给执行层的格式）
        config_block = build_project_config_block(cfg, len(chapter_files))
        runner = SubAgentRunner(
            client, plan_data,
            novel_text="", chapters=chapter_files, events=events_list, scripts=[]
        )
        format_prompt = "\n你必须使用如下XML格式写入工作区：\n<storySkeleton>故事骨架内容</storySkeleton>"
        system_prompt = load_skill("script_execution_skeleton") + format_prompt
        skeleton_prompt = (f"请为这部小说构建故事骨架。\n{config_block}\n\n"
                           f"全书共有 {len(chapter_files)} 章事件可用（第{args.start}~{chapter_files[-1].rstrip('.txt')}章）。"
                           f"事件通过 get_novel_events 工具按需获取，请分批拉取全部事件后构建完整骨架。")
        result = runner.run(
            system_prompt,
            skeleton_prompt + format_prompt,
            "skeleton",
            xml_tag="storySkeleton"
        )

        # 提取 <storySkeleton>...</storySkeleton> 标签内的内容，去掉前后杂质文本
        clean = extract_xml_tag(result, "storySkeleton")
        if clean:
            # 用成对标签重新包裹，确保输出是完整的 XML 结构
            clean = f"<storySkeleton>\n{clean}\n</storySkeleton>"
        else:
            clean = result  # 没找到标签则原样保存

        skeleton_file = os.path.join(out_dir, "story_skeleton.xml")
        with open(skeleton_file, "w", encoding="utf-8") as f:
            f.write(clean)

        print(f"[skeleton] 完成！输出: {skeleton_file}")
        return

    # 第四步：改编策略
    if args.adaptation:
        from script_agent import SubAgentRunner, load_skill
        out_dir = os.path.join(DATA_DIR, project_name)

        skeleton_file = os.path.join(out_dir, "story_skeleton.xml")
        if not os.path.isfile(skeleton_file):
            print("请先执行第三步: python main.py --projectId {projectId} --skeleton")
            return

        events_dir = os.path.join(out_dir, "events")
        if not os.path.isdir(events_dir):
            print("请先执行第二步: python main.py --projectId {projectId} --extract-events")
            return

        # 读取骨架
        with open(skeleton_file, "r", encoding="utf-8") as fp:
            skeleton = fp.read()

        # 读取指定范围的事件
        chapter_files = sorted(
            [f for f in os.listdir(events_dir) if f[:-4].isdigit()],
            key=lambda f: int(f[:-4])
        )
        chapter_files = [f for f in chapter_files
                         if args.start <= int(f[:-4]) <= (args.end if args.end > 0 else 10**9)]
        events_list = []
        for f in chapter_files:
            with open(os.path.join(events_dir, f), "r", encoding="utf-8") as fp:
                events_list.append(fp.read())

        # 集数推算
        episode_count = args.episodes if args.episodes > 0 else max(1, len(chapter_files) // 3)
        plan_data = {
            "projectConfig": {
                "episodeDuration": args.duration,
                "episodeCount": episode_count,
                "totalChapters": len(chapter_files),
            },
            "storySkeleton": skeleton,
        }
        print(f"[adaptation] 集数: {episode_count}, 单集时长: {args.duration}秒")

        runner = SubAgentRunner(
            client, plan_data,
            novel_text="", chapters=chapter_files, events=events_list, scripts=[]
        )
        format_prompt = "\n你必须使用如下XML格式写入工作区：\n<adaptationStrategy>改编策略内容</adaptationStrategy>"
        system_prompt = load_skill("script_execution_adaptation") + format_prompt
        base_prompt = (f"请基于故事骨架制定改编策略。全书共 {len(chapter_files)} 章事件可用。"
                       f"项目配置：{episode_count}集，每集{args.duration}秒。")
        result = runner.run(system_prompt, base_prompt + format_prompt, "adaptation",
                            xml_tag="adaptationStrategy")

        # 校验必需模块，缺失则重试一次
        missing = check_adaptation_modules(result)
        if missing:
            print(f"[adaptation] 缺少模块 {missing}，重试...")
            retry_prompt = (base_prompt + format_prompt + "\n\n你上一次的输出缺少以下必需模块："
                            + "、".join(missing)
                            + "。请务必完整输出以下全部内容：核心改编原则（严格3-5条，每条含✅正面指导/❌负面边界）、"
                              "主要删除决策、世界观呈现策略、矛盾强化（四级矛盾阶梯）、"
                              "信息差策略（观众先知/焦急/上帝型）、股价级反转对齐、"
                              "情绪基调映射（甜宠/复仇/重生逆袭/家庭伦理）、八大改编要点、"
                              "短剧用语规范（家主/市首/亿元/口语化）。")
            result = runner.run(system_prompt, retry_prompt, "adaptation", xml_tag="adaptationStrategy")

        clean = extract_xml_tag(result, "adaptationStrategy")
        if clean:
            clean = f"<adaptationStrategy>\n{clean}\n</adaptationStrategy>"
        else:
            clean = result

        adaptation_file = os.path.join(out_dir, "adaptation_strategy.xml")
        with open(adaptation_file, "w", encoding="utf-8") as f:
            f.write(clean)

        print(f"[adaptation] 完成！输出: {adaptation_file}")
        return

    # 第五步：剧本撰写（逐集）
    if args.script:
        from script_agent import SubAgentRunner, load_skill
        out_dir = os.path.join(DATA_DIR, project_name)

        skeleton_file = os.path.join(out_dir, "story_skeleton.xml")
        adaptation_file = os.path.join(out_dir, "adaptation_strategy.xml")
        chapters_dir = os.path.join(out_dir, "chapters")
        if not (os.path.isfile(skeleton_file) and os.path.isfile(adaptation_file)):
            print("请先执行骨架和改编策略")
            return

        with open(skeleton_file, "r", encoding="utf-8") as fp:
            skeleton = fp.read()
        with open(adaptation_file, "r", encoding="utf-8") as fp:
            strategy = fp.read()

        # 加载章节原文（get_novel_text 需要）
        chapter_texts = []
        chapter_nums = sorted(int(f[:-4]) for f in os.listdir(chapters_dir)
                              if f[:-4].isdigit() and args.start <= int(f[:-4]) <= (args.end if args.end > 0 else 10**9))
        for n in chapter_nums:
            with open(os.path.join(chapters_dir, f"{n}.txt"), "r", encoding="utf-8") as fp:
                chapter_texts.append(fp.read())

        # 读取事件（剧本阶段 get_novel_events 也需要，与 Toonflow 一致）
        events_dir = os.path.join(out_dir, "events")
        events_list = []
        if os.path.isdir(events_dir):
            for n in chapter_nums:
                ev_file = os.path.join(events_dir, f"{n}.txt")
                if os.path.isfile(ev_file):
                    with open(ev_file, "r", encoding="utf-8") as fp:
                        events_list.append(fp.read())
                else:
                    events_list.append("")
        if not events_list:
            print("提示: events/ 目录无事件数据，get_novel_events 将返回空。建议先执行 --extract-events")

        # 从骨架解析分集
        episodes = parse_episodes(skeleton)
        if not episodes:
            print("骨架中未找到分集信息")
            return

        # 只跑指定集（--ep 1 或 1,3,5）
        if args.ep:
            want = set(int(x) for x in args.ep.split(",") if x.strip().isdigit())
            episodes = [e for e in episodes if e["num"] in want]
            if not episodes:
                print(f"指定的集号 {args.ep} 不在骨架中")
                return
            print(f"[script] 只跑集号: {sorted(want)}")

        episode_count = len(episodes)
        plan_data = {
            "projectConfig": {
                "episodeDuration": args.duration,
                "episodeCount": episode_count,
                "totalChapters": len(chapter_nums),
            },
            "storySkeleton": skeleton,
            "adaptationStrategy": strategy,
        }

        runner = SubAgentRunner(
            client, plan_data,
            novel_text="\n\n".join(chapter_texts),
            chapters=chapter_texts,  # 存原文，get_novel_text 按索引返回
            events=events_list,      # 事件表，get_novel_events 可用
            scripts=[],
        )
        system_prompt = load_skill("script_execution_script") + (
            "\n你必须使用如下XML格式写入工作区：\nXML不得添加任何额外标签"
            "<scriptItem name=\"剧本名称\">剧本内容</scriptItem>"
            "<scriptItem name=\"剧本名称\">剧本内容</scriptItem>"
            "<scriptItem name=\"剧本名称\">剧本内容</scriptItem>"
        )
        format_prompt = ("\n你必须使用如下XML格式写入工作区：\nXML不得添加任何额外标签"
                        "<scriptItem name=\"剧本名称\">剧本内容</scriptItem>"
                        "<scriptItem name=\"剧本名称\">剧本内容</scriptItem>"
                        "<scriptItem name=\"剧本名称\">剧本内容</scriptItem>")

        script_dir = os.path.join(out_dir, "scripts")
        os.makedirs(script_dir, exist_ok=True)

        # 加载已存在的剧本到 scripts 列表，供 get_script_content 衔接
        existing = sorted([f for f in os.listdir(script_dir) if f.startswith("ep") and f.endswith(".xml")])
        for f in existing:
            with open(os.path.join(script_dir, f), "r", encoding="utf-8") as fp:
                runner.scripts.append(fp.read())

        for i, ep in enumerate(episodes):
            ep_num = ep["num"]
            ep_title = ep["title"]
            ep_chapters = ep["chapters"]
            print(f"\n[script] 写第 {ep_num} 集: {ep_title} (第{ep_chapters}章)")

            # 提取当前集在骨架中的完整信息（戏剧功能/场景核心/删减决策/集末钩子等）
            ep_info = extract_episode_info(skeleton, ep_num)
            # 台词量 = 时长 × 150字/分钟
            words_per_ep = max(100, args.duration * 150 // 60)

            # 取当前集覆盖章节的原文（直接注入，不依赖 get_novel_text 逐章取）
            ep_chapter_nums = parse_chapter_range(ep_chapters)
            if not ep_chapter_nums:
                ep_chapter_nums = chapter_nums  # 取不到范围则用全部
            ep_novel_text = ""
            for n in ep_chapter_nums:
                if 1 <= n <= len(chapter_texts):
                    ep_novel_text += f"\n===== 第{n}章原文 =====\n{chapter_texts[n-1]}\n"

            prompt = (f"请为第{ep_num}集撰写剧本，第{ep_num}集名称为《{ep_title}》，"
                      f"项目配置：{episode_count}集/每集{args.duration}秒约{words_per_ep}字台词"
                      f"/覆盖第{args.start}-{args.end if args.end>0 else len(chapter_nums)}章"
                      f"/平台16:9画面。\n"
                      f"第{ep_num}集覆盖章节：第{ep_chapters}章，戏剧功能为：\n"
                      f"{ep_info}\n"
                      f"以下是本集覆盖章节的原文：\n{ep_novel_text}\n"
                      f"请根据骨架中该集的信息、改编策略和上述原文撰写剧本，台词量约{words_per_ep}字。")

            # 对齐 Toonflow: assistant 消息预注入"可用剧本 + 章节数量"
            if runner.scripts:
                script_list = ",".join(
                    f"{i+1}:第{i+1}集" for i in range(len(runner.scripts))
                )
            else:
                script_list = ""
            assistant_context = (f"## 可用剧本(ID:名称)\n{script_list}\n"
                                 f"章节数量：{len(chapter_nums)}章")

            result = runner.run(system_prompt, prompt + format_prompt, "script", xml_tag="scriptItem",
                                assistant_context=assistant_context)

            clean = extract_xml_tag(result, "scriptItem")
            if clean:
                # 用 <scriptItem name="..."> 重新包裹（name 取剧本首行 # 标题）
                title_match = re.match(r'^#\s*(.+?)\s*$', clean, re.MULTILINE)
                name = title_match.group(1).strip() if title_match else f"第{ep_num}集"
                clean = f'<scriptItem name="{name}">\n{clean}\n</scriptItem>'
            else:
                clean = result
            # 保存单集剧本
            script_file = os.path.join(script_dir, f"ep{ep_num:02d}.xml")
            with open(script_file, "w", encoding="utf-8") as f:
                f.write(clean)
            # 加入 scripts 列表供 get_script_content 衔接下一集
            runner.scripts.append(clean)
            print(f"  [script] 已保存: {script_file}")

        print(f"\n[script] 完成！共 {len(episodes)} 集，输出: {script_dir}")
        return
    result = agent.execute(novel_text, chapters)

    # 输出到 data/{project_name}/
    out_dir = os.path.join(DATA_DIR, project_name)
    os.makedirs(out_dir, exist_ok=True)

    for name, content in result.items():
        if not content:
            continue
        p = os.path.join(out_dir, f"{name}.md")
        with open(p, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"  已保存: {p}")

    print(f"\n完成！{out_dir}")


if __name__ == "__main__":
    main()