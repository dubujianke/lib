# -*- coding: utf-8 -*-
"""解读 @ai-sdk/devtools 的 generations.json"""
import json, sys, os

path = sys.argv[1] if len(sys.argv) > 1 else r"D:\study\cartoon\Toonflow-app-master\.devtools\generations.json"
with open(path, "r", encoding="utf-8") as f:
    data = json.load(f)

print(f"顶层 keys: {list(data.keys())}")
print(f"runs 数量: {len(data.get('runs', []))}")
print(f"steps 数量: {len(data.get('steps', []))}\n")

# run 索引
for i, r in enumerate(data.get("runs", [])):
    print(f"[run {i}] {r.get('id')} started_at={r.get('started_at')}")

print("\n" + "=" * 80)

def summarize_messages(messages):
    out = []
    for m in messages:
        role = m.get("role")
        content = m.get("content")
        if isinstance(content, list):
            texts = []
            for c in content:
                if isinstance(c, dict):
                    texts.append(f"[{c.get('type')}]{str(c.get('text', ''))[:120]}")
                else:
                    texts.append(str(c)[:120])
            content = " | ".join(texts)
        else:
            content = str(content)[:150]
        out.append(f"  {role}: {content}")
    return "\n".join(out)

for s in data.get("steps", []):
    print(f"\n{'='*80}")
    print(f"step #{s.get('step_number')} | type={s.get('type')} | model={s.get('model_id')} | provider={s.get('provider')}")
    print(f"run_id={s.get('run_id')} | started={s.get('started_at')} | duration={s.get('duration_ms')}ms")

    # input
    inp = s.get("input")
    if isinstance(inp, str):
        try:
            inp = json.loads(inp)
        except Exception:
            pass
    if isinstance(inp, dict):
        if "prompt" in inp:
            print("--- INPUT messages ---")
            print(summarize_messages(inp.get("prompt", [])))
        if "tools" in inp and inp.get("tools"):
            print("--- INPUT tools ---")
            tlist = inp["tools"]
            if isinstance(tlist, dict):
                tlist = [{"name": k, **(v if isinstance(v, dict) else {})} for k, v in tlist.items()]
            for t in tlist:
                if isinstance(t, dict):
                    name = t.get("name") or t.get("type", "?")
                    desc = t.get("description", t.get("function", {}).get("description", "")) if isinstance(t, dict) else ""
                    print(f"  - {name}: {str(desc)[:100]}")

    # output
    out = s.get("output")
    if isinstance(out, str):
        try:
            out = json.loads(out)
        except Exception:
            pass
    if isinstance(out, dict):
        content = out.get("content")
        if isinstance(content, list):
            print("--- OUTPUT ---")
            for c in content:
                if isinstance(c, dict):
                    typ = c.get("type")
                    txt = c.get("text", "")
                    print(f"  [{typ}] {txt[:300]}{'...' if len(txt)>300 else ''}")
                else:
                    print(f"  {str(c)[:300]}")
        tc = out.get("toolCalls")
        if tc:
            print("--- OUTPUT toolCalls ---")
            for t in tc:
                print(f"  {t.get('name')}({json.dumps(t.get('args', {}), ensure_ascii=False)[:200]})")

    # raw_response 里找 tool calls / reasoning
    rr = s.get("raw_response")
    if isinstance(rr, str) and rr:
        try:
            raw = json.loads(rr)
            choices = raw.get("choices", [])
            for ch in choices:
                msg = ch.get("message", {})
                tool_calls = msg.get("tool_calls")
                if tool_calls:
                    print("--- RAW tool_calls ---")
                    for tc in tool_calls:
                        fn = tc.get("function", {})
                        print(f"  {fn.get('name')}({fn.get('arguments', '')[:200]})")
        except Exception as e:
            pass

    # usage
    usage = s.get("usage")
    if isinstance(usage, str):
        try:
            usage = json.loads(usage)
        except Exception:
            pass
    if isinstance(usage, dict):
        u = usage.get("raw") or usage
        if isinstance(u, dict):
            print(f"--- USAGE --- prompt={u.get('prompt_tokens')} completion={u.get('completion_tokens')} reasoning={u.get('completion_tokens_details', {}).get('reasoning_tokens') if isinstance(u.get('completion_tokens_details'), dict) else None}")
