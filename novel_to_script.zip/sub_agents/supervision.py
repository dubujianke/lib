# -*- coding: utf-8 -*-
"""质检审查子代理 — 对应 skills/script_agent_supervision.md"""

import os
from ai_client import AIClient

SKILL = os.path.join(os.path.dirname(os.path.dirname(__file__)), "skills",
                     "script_agent_supervision.md")

with open(SKILL, "r", encoding="utf-8") as f:
    SYSTEM_PROMPT = f.read()


class SupervisionAgent:
    """子代理：审查剧本质量，A/B/C/D 评分"""

    def __init__(self, client: AIClient):
        self.client = client

    def run(self, script: str) -> str:
        print("    [子代理] 质检审查中...")
        return self.client.chat(
            SYSTEM_PROMPT,
            f"请审查以下剧本：\n\n{script[:10000]}"
        )
