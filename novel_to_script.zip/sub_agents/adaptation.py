# -*- coding: utf-8 -*-
"""改编策略子代理 — 对应 skills/script_execution_adaptation.md"""

import os
from ai_client import AIClient

SKILL = os.path.join(os.path.dirname(os.path.dirname(__file__)), "skills",
                     "script_execution_adaptation.md")

with open(SKILL, "r", encoding="utf-8") as f:
    SYSTEM_PROMPT = f.read()


class AdaptationAgent:
    """子代理：制定改编策略（Phase 2）"""

    def __init__(self, client: AIClient):
        self.client = client

    def run(self, skeleton: str, events_text: str) -> str:
        print("    [子代理] 改编策略制定中...")
        return self.client.chat(
            SYSTEM_PROMPT,
            f"故事骨架：\n{skeleton}\n\n事件列表：\n{events_text}\n\n请制定改编策略。"
        )
