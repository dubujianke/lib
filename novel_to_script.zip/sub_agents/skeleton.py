# -*- coding: utf-8 -*-
"""故事骨架子代理 — 对应 skills/script_execution_skeleton.md"""

import os
from ai_client import AIClient

SKILL = os.path.join(os.path.dirname(os.path.dirname(__file__)), "skills",
                     "script_execution_skeleton.md")

with open(SKILL, "r", encoding="utf-8") as f:
    SYSTEM_PROMPT = f.read()


class SkeletonAgent:
    """子代理：生成故事骨架（Phase 1）"""

    def __init__(self, client: AIClient):
        self.client = client

    def run(self, context: str) -> str:
        print("    [子代理] 故事骨架生成中...")
        user = f"请按系统指令处理以下事件数据并构建故事骨架。\n\n{context}"
        result = self.client.chat(SYSTEM_PROMPT, user, category="skeleton")

        # 校验是否 XML 格式，否则重试一次
        if "<storySkeleton>" not in result:
            print("    [子代理] 输出不是 XML，重试...")
            user2 = (f"请按系统指令处理以下事件数据并构建故事骨架。\n\n{context}\n\n"
                     f"警告：你上一次的输出没有使用 <storySkeleton> XML 标签。"
                     f"必须严格把完整骨架包裹在 <storySkeleton>...</storySkeleton> 中输出，禁止输出其他任何内容。")
            result = self.client.chat(SYSTEM_PROMPT, user2, category="skeleton")
        return result
