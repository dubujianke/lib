# -*- coding: utf-8 -*-
"""剧本撰写子代理 — 对应 skills/script_execution_script.md"""

import os
from ai_client import AIClient

SKILL = os.path.join(os.path.dirname(os.path.dirname(__file__)), "skills",
                     "script_execution_script.md")

with open(SKILL, "r", encoding="utf-8") as f:
    SYSTEM_PROMPT = f.read()


class ScriptWriterAgent:
    """子代理：撰写剧本（Phase 3）"""

    def __init__(self, client: AIClient):
        self.client = client

    def run(self, skeleton: str, strategy: str, novel_text: str) -> str:
        print("    [子代理] 剧本撰写中...")
        return self.client.chat(
            SYSTEM_PROMPT,
            f"故事骨架：\n{skeleton}\n\n改编策略：\n{strategy}\n\n原文：\n{novel_text[:8000]}"
        )
