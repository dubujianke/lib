# -*- coding: utf-8 -*-
"""流式调用测试：演示 stream_chat 的逐块输出与完整结果"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ai_client import AIClient

client = AIClient(log_dir="data/test_stream_logs")

print("=== 流式调用测试 ===\n")

gen, full = client.stream_chat(
    "你是中文小说助手",
    "请用一句话介绍你自己，不超过30个字",
    category="test_stream",
)

print("逐块输出：")
pieces = []
for piece in gen:
    pieces.append(piece)
    print(piece, end="", flush=True)

print("\n\n完整结果：")
text = full()
print(text)

print("\n日志文件：")
log_dir = os.path.join("data", "test_stream_logs")
for f in sorted(os.listdir(log_dir)):
    size = os.path.getsize(os.path.join(log_dir, f))
    print(f"  {f}  ({size} 字节)")

client.close()
print("\n测试完成")
