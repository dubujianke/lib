# -*- coding: utf-8 -*-
"""分集断点计算：基于事件表的情绪强度/主线关系，将每集边界"滑"到情绪低谷
   用法: python episode_split.py --projectId 1 --episodes 20 [--dry-run]
   输出: data/{projectId}/episode_split.txt（每集章节范围 + 断点理由）
"""

import os
import re
import argparse

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# 情绪评分：分数越低越适合作为断点
EMOTION_SCORE = {
    "平铺": 0,
    "情感": 1,
    "喜剧": 1,
    "悬疑": 2,
    "转折": 2,
    "冲突": 3,
    "高潮": 3,
}
# 主线关系加分（弱/中关系倾向断点）
MAINLINE_BONUS = {"弱": -1, "中": 0, "强": 2}


def parse_event(text: str):
    """解析一行事件: | 章节 | 角色 | 核心事件 | 主线关系 | 信息密度 | 预估集长 | 情绪强度 |"""
    parts = [p.strip() for p in text.strip().strip("|").split("|")]
    if len(parts) < 7:
        return None
    chapter, role, event, mainline, density, duration, emotion = parts[:7]
    return {
        "chapter": chapter,
        "role": role,
        "event": event,
        "mainline": re.sub(r"（.*?）", "", mainline).strip(),
        "density": density,
        "duration": duration,
        "emotion": emotion,
    }


def chapter_num(chapter_str: str) -> int:
    m = re.search(r"第(\d+)章", chapter_str)
    return int(m.group(1)) if m else 0


def load_events(project_id: str, start: int, end: int):
    ev_dir = os.path.join(DATA_DIR, project_id, "events")
    items = []
    for f in os.listdir(ev_dir):
        if not f[:-4].isdigit():
            continue
        n = int(f[:-4])
        if start <= n <= end:
            with open(os.path.join(ev_dir, f), "r", encoding="utf-8") as fp:
                parsed = parse_event(fp.read())
            if parsed:
                parsed["index"] = n
                items.append(parsed)
    items.sort(key=lambda x: x["index"])
    return items


def boundary_score(item):
    """断点分数：越低越适合作为集边界"""
    emotion = item["emotion"]
    emo = min(EMOTION_SCORE.get(e, 1) for e in emotion.split("+")) if emotion else 1
    ml = MAINLINE_BONUS.get(item["mainline"], 1)
    return emo + ml


def compute_splits(events, episodes, window=3):
    """在理想边界附近滑到最低分章节"""
    total = len(events)
    base = total / episodes  # 理想每集章节数
    boundaries = []  # 每集的最后一个章节 index
    prev = 0
    for ep in range(1, episodes):
        ideal = round(base * ep)  # 理想边界位置（0-based）
        lo = max(prev + 1, ideal - window)
        hi = min(total - 1, ideal + window)
        # 在 [lo, hi] 内找最低分章节作为边界
        best = ideal
        best_score = float("inf")
        for i in range(lo, hi + 1):
            s = boundary_score(events[i])
            if s < best_score:
                best_score = s
                best = i
        boundaries.append(best)
        prev = best
    # 边界对应的章节号
    result = []
    last = 0
    for b in boundaries:
        result.append((events[last]["index"], events[b]["index"], events[b]))
        last = b + 1
    result.append((events[last]["index"], events[-1]["index"], events[-1]))
    return result


def main():
    parser = argparse.ArgumentParser(description="分集断点计算")
    parser.add_argument("--projectId", required=True)
    parser.add_argument("--episodes", type=int, required=True, help="目标集数")
    parser.add_argument("--start", type=int, default=1)
    parser.add_argument("--end", type=int, default=0)
    parser.add_argument("--window", type=int, default=3, help="理想边界附近搜索窗口")
    args = parser.parse_args()

    end = args.end if args.end > 0 else 10**9
    events = load_events(args.projectId, args.start, end)
    if not events:
        print("没有事件数据")
        return
    print(f"事件总数: {len(events)} (第{events[0]['index']}-{events[-1]['index']}章)")
    print(f"目标集数: {args.episodes}, 平均每集约 {len(events)/args.episodes:.1f} 章")

    splits = compute_splits(events, args.episodes, args.window)
    print(f"\n{'集':<4}{'章节范围':<14}{'边界章节情绪':<10}{'断点理由'}")
    print("-" * 60)
    for i, (s, e, item) in enumerate(splits, 1):
        reason = f"{item['emotion']} + 主线{item['mainline']}"
        print(f"第{i:>2}集 第{s}-{e}章  {item['emotion']:<8} {reason}")

    out = os.path.join(DATA_DIR, args.projectId, "episode_split.txt")
    with open(out, "w", encoding="utf-8") as fp:
        fp.write(f"# 分集断点（事件情绪/主线智能切分）\n")
        fp.write(f"事件: {len(events)}章 | 集数: {args.episodes} | 平均每集约{len(events)/args.episodes:.1f}章\n\n")
        for i, (s, e, item) in enumerate(splits, 1):
            fp.write(f"第{i}集: 第{s}-{e}章 | 断点章事件: {item['event']} | 情绪:{item['emotion']} 主线:{item['mainline']}\n")
    print(f"\n输出: {out}")


if __name__ == "__main__":
    main()
