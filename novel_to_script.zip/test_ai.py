# -*- coding: utf-8 -*-
"""AI 客户端自测脚本
   运行: python test_ai.py
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ai_client import AIClient


def main():
    print("=== AI Client 自测 ===\n")
    client = AIClient()

    # 1. 基本信息
    print(f"API 地址: {client.config.base_url}")
    print(f"模型:     {client.config.model}")
    print(f"Key:      {client.config.api_key[:8]}...{client.config.api_key[-4:]}")
    print()

    # 2. 基础对话
    print("[1] 基础对话测试...")
    r1 = client.chat("You are a helpful assistant", "Say hello")
    print(f"    -> {r1}\n")

    # 3. 中文测试
    print("[2] 中文测试...")
    r2 = client.chat("你是助手", "用一句话介绍你自己")
    print(f"    -> {r2}\n")

    # 4. 长文本测试
    print("[3] 长文本测试...")
    r3 = client.chat("你是助手", "请写一段关于AI的100字介绍")
    print(f"    -> 收到 {len(r3)} 字: {r3[:60]}...\n")

    # 5. 事件提取 prompt 测试
    print("[4] 事件提取 prompt 测试...")
    from event_extractor import EventExtractor
    ex = EventExtractor(client)
    ev = ex.extract(1, "小明是一个快递员，一天他收到一封神秘的信件，决定去探个究竟。")
    print(f"    -> {ev}\n")

    print("=== 全部测试通过 ===")


if __name__ == "__main__":
    main()
