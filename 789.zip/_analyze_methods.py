# -*- coding: utf-8 -*-
"""分析 implementations/ 下每个类的每个方法是否存在真实实现，输出 d:/nvl.xlsx"""
import os, sys, ast

base = "novel_writer/implementations"

all_files = []
for root, dirs, files in os.walk(base):
    for f in files:
        if not f.endswith(".py") or f == "__init__.py" or "__pycache__" in root:
            continue
        rel = os.path.relpath(os.path.join(root, f), base).replace("\\", "/").replace(".py", "")
        all_files.append(rel)
all_files.sort()

rows = []
for imp_file in all_files:
    path = os.path.join(base, imp_file + ".py")
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    try:
        tree = ast.parse(content)
    except SyntaxError:
        rows.append([imp_file, "(文件级)", "(语法错误)", "N"])
        continue

    # 判断整个文件是否只是转发 import（shim）
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            for child in node.body:
                if isinstance(child, ast.FunctionDef):
                    method_name = child.name
                    # 统计真实代码行（排除 docstring 和 pass）
                    code_lines = 0
                    for s in child.body:
                        if isinstance(s, ast.Expr) and isinstance(s.value, ast.Constant) and isinstance(s.value.value, str):
                            continue
                        if isinstance(s, ast.Pass):
                            continue
                        code_lines += 1
                    is_present = "Y" if code_lines > 0 else "N"
                    rows.append([imp_file, node.name, method_name, is_present])
        # 模块级函数
        elif isinstance(node, ast.FunctionDef) and not any(isinstance(p, ast.ClassDef) for p in ast.walk(tree)):
            # 只处理顶层函数
            pass

# 单独处理模块级函数（在 ast.walk 中 node.parent 不可用，改用直接遍历 tree.body）
for imp_file in all_files:
    path = os.path.join(base, imp_file + ".py")
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    tree = ast.parse(content)
    for node in tree.body:
        if isinstance(node, ast.FunctionDef):
            code_lines = 0
            for s in node.body:
                if isinstance(s, ast.Expr) and isinstance(s.value, ast.Constant) and isinstance(s.value.value, str):
                    continue
                if isinstance(s, ast.Pass):
                    continue
                code_lines += 1
            is_present = "Y" if code_lines > 0 else "N"
            rows.append([imp_file, "(模块级)", node.name, is_present])

import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils import get_column_letter

wb = openpyxl.Workbook()
ws = wb.active
ws.title = "implementations方法存在性"
ws.append(["文件路径", "类名", "方法名", "是否存在"])

green = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
red = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
header_font = Font(color="FFFFFF", bold=True)

for col in range(1, 5):
    c = ws.cell(row=1, column=col)
    c.fill = header_fill
    c.font = header_font
    c.alignment = Alignment(horizontal="center")

for row in rows:
    ws.append(row)
    r = ws.max_row
    cell = ws.cell(row=r, column=4)
    if row[3] == "Y":
        cell.fill = green
        cell.value = "Y"
    else:
        cell.fill = red
        cell.value = "N"

total = len(rows)
y_count = sum(1 for r in rows if r[3] == "Y")
n_count = total - y_count

summary_row = ws.max_row + 2
ws.cell(row=summary_row, column=1, value="统计")
ws.cell(row=summary_row, column=2, value=f"总方法数: {total}")
ws.cell(row=summary_row + 1, column=1, value="存在(Y)")
ws.cell(row=summary_row + 1, column=2, value=str(y_count))
ws.cell(row=summary_row + 2, column=1, value="不存在(N)")
ws.cell(row=summary_row + 2, column=2, value=str(n_count))
ws.cell(row=summary_row + 3, column=3, value="Y = 有真实实现")
ws.cell(row=summary_row + 4, column=3, value="N = 空壳/未实现/pass")

for col in range(1, 5):
    max_len = 4
    for row_cells in ws.iter_rows(min_col=col, max_col=col):
        cell = row_cells[0]
        if cell.value:
            max_len = max(max_len, len(str(cell.value)))
    ws.column_dimensions[get_column_letter(col)].width = min(max_len + 2, 60)

wb.save("d:/nvl.xlsx")
print(f"Written to d:/nvl.xlsx")
print(f"Total methods: {total}, Exists(Y): {y_count}, Missing(N): {n_count}")
