# -*- coding: utf-8 -*-
"""对比 C# 参考项目 Implementations 与 Python 项目，输出 d:/nvl2.xlsx"""
import os, re, ast

CS_BASE = r"D:\study\cartoon\tianming-novel-ai-writer-4.1.1\Services\Modules\ProjectData\Implementations"
PY_BASE = r"D:\stock\novel2\novel_to_script\novel_writer"

# ---------------- C# 解析 ----------------
CLASS_RE = re.compile(r"\b(class|struct|interface|record)\s+([A-Za-z_]\w*)")
# 方法声明行：以修饰符开头
MODIFIER_RE = re.compile(
    r"^\s*(?:public|private|protected|internal|static|async|override|virtual|"
    r"abstract|sealed|partial|new|unsafe|extern|const|readonly|volatile|ref|out)\b"
)
# 排除控制流关键字开头（方法体内）
NON_METHOD_RE = re.compile(r"^\s*(if|for|foreach|while|switch|catch|using|return|throw|lock|yield|goto|else|do)\b")


def read_text(path):
    for enc in ("utf-8-sig", "utf-8", "gbk", "latin-1"):
        try:
            with open(path, "r", encoding=enc) as f:
                return f.read()
        except (UnicodeDecodeError, UnicodeError):
            continue
    return ""


def parse_csharp(path):
    """返回 {类名: set(方法名)}，用类栈追踪嵌套类"""
    content = read_text(path)
    classes = {}
    class_stack = []  # (类名, 该类body深度)
    depth = 0
    for line in content.split("\n"):
        stripped = line.strip()
        # 类声明（优先判断，可能含 '{' 在同一行）
        cm = CLASS_RE.search(line)
        if cm:
            class_name = cm.group(2)
            classes.setdefault(class_name, set())
            # 类 body 深度 = 当前 depth + 1（声明行的 '{' 尚未计入 depth）
            class_stack.append((class_name, depth + 1))

        # 方法声明：归属栈顶类
        if class_stack and depth >= class_stack[-1][1] and MODIFIER_RE.match(line) and "(" in line:
            if not NON_METHOD_RE.match(line):
                paren = line.rfind("(")
                prefix = line[:paren]
                eq = line.find("=")
                if eq == -1 or eq >= paren:
                    m2 = re.search(r"([A-Za-z_]\w*)\s*$", prefix.strip())
                    if m2:
                        mn = m2.group(1)
                        owner = class_stack[-1][0]
                        if (mn != owner and not mn.startswith("~")
                                and mn != "this" and mn not in ("new", "default", "typeof", "sizeof", "nameof")):
                            classes[owner].add(mn)

        depth += line.count("{") - line.count("}")
        if depth < 0:
            depth = 0
        # 弹出已结束的类
        while class_stack and depth < class_stack[-1][1]:
            class_stack.pop()
    return classes


def pascal_to_snake(name):
    s1 = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", name)
    return s1.lower()


def normalize_cs_method(name):
    """C# 方法名 -> 归一化 snake_case（去掉 async 后缀）"""
    s = pascal_to_snake(name)
    if s.endswith("_async"):
        s = s[:-6]
    return s


# ---------------- Python 解析 ----------------
def parse_python(path):
    """返回 {类名: (文件相对路径, set(方法名))}"""
    try:
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
        tree = ast.parse(content)
    except (SyntaxError, UnicodeDecodeError):
        return {}
    classes = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            methods = set()
            for child in node.body:
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    methods.add(child.name)
            classes[node.name] = (path, methods)
    return classes


def normalize_py_method(name):
    return name.lower().strip("_")


# ---------------- 收集 C# 数据 ----------------
cs_rows = []  # (csharp相对路径, 类名, 方法名)
cs_files = []
for root, dirs, files in os.walk(CS_BASE):
    dirs[:] = [d for d in dirs if d not in ("bin", "obj")]
    for f in files:
        if f.endswith(".cs"):
            cs_files.append(os.path.join(root, f))
cs_files.sort()

for path in cs_files:
    rel = os.path.relpath(path, CS_BASE).replace("\\", "/")
    classes = parse_csharp(path)
    for cls, methods in classes.items():
        for m in sorted(methods):
            cs_rows.append((rel, cls, m))

# ---------------- 收集 Python 数据 ----------------
# 类名 -> (文件路径, set(方法名))
py_classes = {}
# 模块级函数归一化 -> (文件, 原始函数名)
py_module_funcs = {}
py_files = []
for root, dirs, files in os.walk(PY_BASE):
    dirs[:] = [d for d in dirs if d not in ("__pycache__", ".git")]
    for f in files:
        if f.endswith(".py"):
            py_files.append(os.path.join(root, f))

for path in py_files:
    try:
        with open(path, "r", encoding="utf-8") as f:
            tree = ast.parse(f.read())
    except (SyntaxError, UnicodeDecodeError):
        continue
    rel = os.path.relpath(path, PY_BASE).replace("\\", "/")
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            methods = set()
            for child in node.body:
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    methods.add(child.name)
            if node.name not in py_classes:
                py_classes[node.name] = (rel, set())
            py_classes[node.name][1].update(methods)
    # 模块级函数
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            key = normalize_py_method(node.name)
            if key not in py_module_funcs:
                py_module_funcs[key] = (rel, node.name)

# 方法归一化索引：类名 -> {归一化方法名: 原始方法名}
py_normalized = {}
for cls, (fp, methods) in py_classes.items():
    nmap = {}
    for m in methods:
        key = normalize_py_method(m)
        if key not in nmap:
            nmap[key] = m
    py_normalized[cls] = nmap

# ---------------- 交叉匹配 ----------------
results = []
for cs_rel, cs_cls, cs_method in cs_rows:
    norm = normalize_cs_method(cs_method)
    candidates = [norm, norm + "_async"]

    # 1. 按类名匹配
    found_py_file = ""
    found_py_method = ""
    if cs_cls in py_normalized:
        py_nmap = py_normalized[cs_cls]
        found_py_file = py_classes[cs_cls][0]
        for cand in candidates:
            if cand in py_nmap:
                found_py_method = py_nmap[cand]
                break

    # 2. 类内找不到，全局模块级函数匹配
    if not found_py_method:
        for cand in candidates:
            if cand in py_module_funcs:
                found_py_file, found_py_method = py_module_funcs[cand]
                break

    if found_py_method:
        results.append([cs_rel, cs_cls, cs_method, found_py_file, found_py_method, "Y"])
    else:
        results.append([cs_rel, cs_cls, cs_method, "", "", "N"])

# ---------------- 写 Excel ----------------
import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils import get_column_letter

wb = openpyxl.Workbook()
ws = wb.active
ws.title = "Implementations对比"
ws.append(["原文件名", "类名", "方法名", "Python文件名", "Python方法名", "是否实现"])

green = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
red = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
header_font = Font(color="FFFFFF", bold=True)

for col in range(1, 7):
    c = ws.cell(row=1, column=col)
    c.fill = header_fill
    c.font = header_font
    c.alignment = Alignment(horizontal="center")

for row in results:
    ws.append(row)
    r = ws.max_row
    cell = ws.cell(row=r, column=6)
    if row[5] == "Y":
        cell.fill = green
    else:
        cell.fill = red

total = len(results)
y_count = sum(1 for r in results if r[5] == "Y")
n_count = total - y_count

sr = ws.max_row + 2
ws.cell(row=sr, column=1, value="统计")
ws.cell(row=sr, column=2, value=f"总方法数: {total}")
ws.cell(row=sr + 1, column=1, value="已实现(Y)")
ws.cell(row=sr + 1, column=2, value=str(y_count))
ws.cell(row=sr + 2, column=1, value="未实现(N)")
ws.cell(row=sr + 2, column=2, value=str(n_count))

widths = [60, 30, 40, 45, 35, 10]
for i, w in enumerate(widths, start=1):
    ws.column_dimensions[get_column_letter(i)].width = w

wb.save("d:/nvl2.xlsx")
print(f"Written to d:/nvl2.xlsx")
print(f"Total methods: {total}, Y: {y_count}, N: {n_count}")
