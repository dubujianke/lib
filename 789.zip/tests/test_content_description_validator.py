# -*- coding: utf-8 -*-
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from novel_writer.implementations.validation.content_description_validator import (
    ContentDescriptionValidator, _get_antonyms, _content_contains_near,
    _find_hair_color_contradiction, _ANTONYM_PAIRS,
)


class TestAntonymHelpers:
    def test_get_antonyms_found(self):
        result = _get_antonyms("沉默寡言")
        assert "滔滔不绝" in result
        assert "健谈" in result

    def test_get_antonyms_not_found(self):
        assert _get_antonyms("不存在") == []

    def test_content_contains_near_basic(self):
        assert _content_contains_near("张三是一个沉默寡言的人", "张三", "滔滔不绝", 50) is False

    def test_content_contains_near_found(self):
        content = "张三今天突然变得滔滔不绝，和平时完全不同。"
        assert _content_contains_near(content, "张三", "滔滔不绝", 50) is True

    def test_content_contains_near_empty(self):
        assert _content_contains_near("", "a", "b", 10) is False
        assert _content_contains_near("abc", "", "b", 10) is False
        assert _content_contains_near("abc", "a", "", 10) is False

    def test_content_contains_near_out_of_range(self):
        content = "张三" + "。" * 100 + "滔滔不绝"
        assert _content_contains_near(content, "张三", "滔滔不绝", 50) is False

    def test_find_hair_color_contradiction_found(self):
        content = "李四走进来，他的金发在阳光下闪闪发光。"
        result = _find_hair_color_contradiction(content, "李四", "黑发")
        assert result is not None
        assert "金发" in result

    def test_find_hair_color_contradiction_not_found(self):
        content = "李四走进来，他的黑发在阳光下闪闪发光。"
        result = _find_hair_color_contradiction(content, "李四", "黑发")
        assert result is None

    def test_hair_color_keywords_defined(self):
        assert "黑发" in _ANTONYM_PAIRS
        assert "金发" in _ANTONYM_PAIRS
        assert "蓝眼" in _ANTONYM_PAIRS
        assert "黑眼" in _ANTONYM_PAIRS


class FakeDesc:
    def __init__(self, name="", hair_color="", personality_tags=None, features=None):
        self.Name = name
        self.HairColor = hair_color
        self.PersonalityTags = personality_tags or []
        self.Features = features or []


class TestContentDescriptionValidator:
    def test_validate_character_descriptions_empty(self):
        v = ContentDescriptionValidator()
        assert v.validate_character_descriptions("", {}) == []
        assert v.validate_character_descriptions(None, {}) == []
        assert v.validate_character_descriptions("content", None) == []

    def test_validate_character_hair_contradiction(self):
        v = ContentDescriptionValidator()
        content = "王五走进来，他的金发格外显眼。"
        descs = {"char1": FakeDesc(name="王五", hair_color="黑发")}
        issues = v.validate_character_descriptions(content, descs)
        assert len(issues) == 1
        assert "发色矛盾" in issues[0]

    def test_validate_character_hair_match(self):
        v = ContentDescriptionValidator()
        content = "王五走进来，他的黑发格外显眼。"
        descs = {"char1": FakeDesc(name="王五", hair_color="黑发")}
        issues = v.validate_character_descriptions(content, descs)
        assert len(issues) == 0

    def test_validate_character_personality_contradiction(self):
        v = ContentDescriptionValidator()
        content = "赵六平时沉默寡言，今天却滔滔不绝地说个不停。"
        descs = {"char1": FakeDesc(name="赵六", personality_tags=["沉默寡言"])}
        issues = v.validate_character_descriptions(content, descs)
        assert len(issues) == 1
        assert "性格矛盾" in issues[0]

    def test_validate_character_personality_ok(self):
        v = ContentDescriptionValidator()
        content = "赵六平时沉默寡言，一句话也不说。"
        descs = {"char1": FakeDesc(name="赵六", personality_tags=["沉默寡言"])}
        issues = v.validate_character_descriptions(content, descs)
        assert len(issues) == 0

    def test_validate_character_with_dict_desc(self):
        v = ContentDescriptionValidator()
        content = "张三的金发飘扬。"
        descs = {"char1": {"Name": "张三", "HairColor": "黑发", "PersonalityTags": []}}
        issues = v.validate_character_descriptions(content, descs)
        assert len(issues) == 1

    def test_validate_location_descriptions_empty(self):
        v = ContentDescriptionValidator()
        assert v.validate_location_descriptions("", {}) == []
        assert v.validate_location_descriptions(None, {}) == []

    def test_validate_location_descriptions_contradiction(self):
        v = ContentDescriptionValidator()
        # "冷漠" antonym includes "温暖"; "城堡" within 100 chars of "温暖"
        content = "城堡里温暖如春，壁炉的火光映照在石墙上。"
        descs = {"loc1": FakeDesc(name="城堡", features=["冷漠"])}
        issues = v.validate_location_descriptions(content, descs)
        assert len(issues) == 1
        assert "特征矛盾" in issues[0]

    def test_validate_location_descriptions_ok(self):
        v = ContentDescriptionValidator()
        content = "城堡阴冷潮湿，石墙长满了青苔。"
        descs = {"loc1": FakeDesc(name="城堡", features=["冷漠"])}
        issues = v.validate_location_descriptions(content, descs)
        assert len(issues) == 0

    def test_validate_location_without_features(self):
        v = ContentDescriptionValidator()
        content = "城堡很漂亮。"
        descs = {"loc1": FakeDesc(name="城堡", features=[])}
        issues = v.validate_location_descriptions(content, descs)
        assert len(issues) == 0