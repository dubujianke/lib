# -*- coding: utf-8 -*-
"""Consolidated unit tests for the per-entity tracking state services.

Covers: character_state, conflict_progress, faction_state, location_state,
item_state, secret_reveal, pledge_constraint, deadline_constraint,
foreshadowing_status, timeline, relation_strength.
"""
import sys
import os
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest

from novel_writer.implementations.tracking.character_state_service import CharacterStateService
from novel_writer.implementations.tracking.conflict_progress_service import ConflictProgressService
from novel_writer.implementations.tracking.faction_state_service import FactionStateService
from novel_writer.implementations.tracking.location_state_service import LocationStateService
from novel_writer.implementations.tracking.item_state_service import ItemStateService
from novel_writer.implementations.tracking.secret_reveal_service import SecretRevealService
from novel_writer.implementations.tracking.pledge_constraint_service import PledgeConstraintService
from novel_writer.implementations.tracking.deadline_constraint_service import DeadlineConstraintService
from novel_writer.implementations.tracking.foreshadowing_status_service import ForeshadowingStatusService
from novel_writer.implementations.tracking.timeline_service import TimelineService
from novel_writer.implementations.tracking.relation_strength_service import (
    RelationStrengthService,
    RelationStrengthIndex,
    determine_strength_by_relation_type,
    apply_strength_hint,
    get_pair_key,
)

from novel_writer.models.tracking import (
    CharacterStateChange,
    ConflictProgressChange,
    FactionStateChange,
    LocationStateChange,
    ItemTransferChange,
    SecretRevealChange,
    PledgeConstraintChange,
    DeadlineConstraintChange,
    TimeProgressionChange,
    CharacterMovementChange,
)


# ---- minimal backing store / project fakes ----

class FakeStore:
    """Loose stand-in for GuideStore: exposes data() / set_all()."""

    def __init__(self):
        self._data = {}

    def data(self):
        return self._data

    def set_all(self, data):
        self._data = data


class FakeProject:
    def __init__(self, **stores):
        self.dir = tempfile.mkdtemp(prefix="test_tracking_")
        self._stores = {name: store for name, store in stores.items()}
        self.design = {}
        self.plan = {}

    def tracking(self, name):
        return self._stores.setdefault(name, FakeStore())

    def guide(self, name):
        return self._stores.setdefault(name, FakeStore())

    def load_design(self, entity):
        return self.design.get(entity, {})

    def load_plan(self, entity):
        return self.plan.get(entity, {})


def make_project(store_names):
    stores = {name: FakeStore() for name in store_names}
    return FakeProject(**stores), stores


# =====================================================================
# 1. CharacterStateService
# =====================================================================

def test_character_state_init():
    project, _ = make_project(["character_state"])
    svc = CharacterStateService(project)
    assert svc.project is project
    assert svc._store is None


def test_character_state_update_basic_create():
    project, stores = make_project(["character_state"])
    svc = CharacterStateService(project)
    change = CharacterStateChange(CharacterId="C1", NewLevel="3",
                                  NewAbilities=["sword"], KeyEvent="庙门被毁")
    new_state = svc.update_character_state("vol1_ch1", change, name_hint="阿明")
    assert new_state["Chapter"] == "vol1_ch1"
    assert new_state["Level"] == "3"
    assert "sword" in new_state["Abilities"]
    entry = stores["character_state"].data()["C1"]
    assert entry["Name"] == "阿明"
    assert len(entry["StateHistory"]) == 1


def test_character_state_update_merges_abilities_and_lost():
    project, _ = make_project(["character_state"])
    svc = CharacterStateService(project)
    svc.update_character_state("vol1_ch1",
                               CharacterStateChange(CharacterId="C1", NewAbilities=["a", "b"]))
    svc.update_character_state("vol1_ch2",
                               CharacterStateChange(CharacterId="C1", NewAbilities=["c"], LostAbilities=["a"]))
    entry = svc._get_store().data()["C1"]
    assert set(entry["Abilities"]) == {"b", "c"}


def test_character_state_remove_chapter_data():
    project, stores = make_project(["character_state"])
    svc = CharacterStateService(project)
    svc.update_character_state("vol1_ch1", CharacterStateChange(CharacterId="C1"))
    svc.update_character_state("vol1_ch2", CharacterStateChange(CharacterId="C1"))
    removed = svc.remove_chapter_data("vol1_ch1")
    assert removed == 1
    assert len(stores["character_state"].data()["C1"]["StateHistory"]) == 1


def test_character_state_merge_relationships_static():
    change = CharacterStateChange(CharacterId="C2")
    change.RelationshipChanges["C9"] = __import__(
        "novel_writer.models.tracking", fromlist=["RelationshipChange"]).RelationshipChange(
        Relation="恋人", TrustDelta=5, EmotionPhase="热恋")
    rel = CharacterStateService.merge_relationships(None, change.RelationshipChanges)
    assert rel["C9"]["Relation"] == "恋人"
    assert rel["C9"]["Trust"] == 5


# =====================================================================
# 2. ConflictProgressService
# =====================================================================

def test_conflict_init():
    project, _ = make_project(["conflict_progress"])
    svc = ConflictProgressService(project)
    assert svc is not None


def test_conflict_update_and_active():
    project, stores = make_project(["conflict_progress"])
    svc = ConflictProgressService(project)
    svc.update_conflict_progress("vol1_ch1",
                                 ConflictProgressChange(ConflictId="X1", NewStatus="active", Event="开战"))
    entry = stores["conflict_progress"].data()["X1"]
    assert entry["Status"] == "active"
    assert len(entry["ProgressPoints"]) == 1
    assert entry["InvolvedChapters"] == ["vol1_ch1"]
    active = svc.get_active_conflicts()
    assert len(active) == 1


def test_conflict_remove_chapter():
    project, _ = make_project(["conflict_progress"])
    svc = ConflictProgressService(project)
    svc.update_conflict_progress("vol1_ch1", ConflictProgressChange(ConflictId="X1"))
    svc.update_conflict_progress("vol1_ch2", ConflictProgressChange(ConflictId="X1"))
    assert svc.remove_chapter_data("vol1_ch1") == 1


# =====================================================================
# 3. FactionStateService
# =====================================================================

def test_faction_init():
    project, _ = make_project(["faction_state"])
    svc = FactionStateService(project)
    assert svc is not None


def test_faction_update_and_get_all():
    project, stores = make_project(["faction_state"])
    svc = FactionStateService(project)
    svc.update_faction_state("vol1_ch1",
                             FactionStateChange(FactionId="F1", NewStatus="rising", Event="扩张"))
    entry = stores["faction_state"].data()["F1"]
    assert entry["CurrentStatus"] == "rising"
    assert len(entry["StateHistory"]) == 1
    assert len(svc.get_all_faction_states()) == 1


def test_faction_remove_chapter_refills_unknown():
    project, stores = make_project(["faction_state"])
    svc = FactionStateService(project)
    svc.update_faction_state("vol1_ch1", FactionStateChange(FactionId="F1"))
    assert svc.remove_chapter_data("vol1_ch1") == 1
    assert stores["faction_state"].data()["F1"]["CurrentStatus"] == "unknown"


# =====================================================================
# 4. LocationStateService
# =====================================================================

def test_location_init():
    project, _ = make_project(["location_state"])
    svc = LocationStateService(project)
    assert svc is not None


def test_location_update_and_get_all():
    project, stores = make_project(["location_state"])
    svc = LocationStateService(project)
    svc.update_location_state("vol1_ch1",
                              LocationStateChange(LocationId="L1", LocationName="皇宫",
                                                  NewStatus="contested"))
    entry = stores["location_state"].data()["L1"]
    assert entry["Name"] == "皇宫"
    assert entry["CurrentStatus"] == "contested"
    assert len(svc.get_all_location_states()) == 1


def test_location_remove_chapter():
    project, _ = make_project(["location_state"])
    svc = LocationStateService(project)
    svc.update_location_state("vol1_ch1", LocationStateChange(LocationId="L1"))
    assert svc.remove_chapter_data("vol1_ch1") == 1


# =====================================================================
# 5. ItemStateService
# =====================================================================

def test_item_init():
    project, _ = make_project(["item_state"])
    svc = ItemStateService(project)
    assert svc is not None


def test_item_update_creates_and_returns_id():
    project, stores = make_project(["item_state"])
    svc = ItemStateService(project)
    sid = svc.update_item_state("vol1_ch1",
                                ItemTransferChange(ItemId="I000000000001", ItemName="神剑",
                                                   ToHolder="C1", NewStatus="active"))
    assert sid is not None
    entry = stores["item_state"].data()[sid]
    assert entry["CurrentHolder"] == "C1"
    assert len(entry["StateHistory"]) == 1


def test_item_update_guards_empty_id():
    project, _ = make_project(["item_state"])
    svc = ItemStateService(project)
    assert svc.update_item_state("vol1_ch1", ItemTransferChange(ItemId="")) is None


def test_item_remove_chapter():
    project, _ = make_project(["item_state"])
    svc = ItemStateService(project)
    svc.update_item_state("vol1_ch1", ItemTransferChange(ItemId="I000000000001"))
    assert svc.remove_chapter_data("vol1_ch1") == 1


# =====================================================================
# 6. SecretRevealService
# =====================================================================

def test_secret_init():
    project, _ = make_project(["secret"])
    svc = SecretRevealService(project)
    assert svc is not None


def test_secret_update_and_extract_snapshot():
    project, stores = make_project(["secret"])
    svc = SecretRevealService(project)
    sid = svc.update_secret_reveal("vol1_ch1",
                                   SecretRevealChange(SecretId="S000000000001",
                                                      SecretName="身世", NewKnowerIds=["C1", "C2"]))
    assert sid is not None
    entry = stores["secret"].data()[sid]
    assert entry["CurrentStatus"] == "partially_known"
    assert entry["KnowerIds"] == ["C1", "C2"]
    snap = svc.extract_snapshot()
    assert len(snap) == 1
    assert snap[0]["Id"] == sid


def test_secret_update_guard():
    project, _ = make_project(["secret"])
    svc = SecretRevealService(project)
    assert svc.update_secret_reveal("vol1_ch1", SecretRevealChange(SecretId="S1", NewKnowerIds=[])) is None


def test_secret_remove_chapter_rebuilds_status():
    project, stores = make_project(["secret"])
    svc = SecretRevealService(project)
    svc.update_secret_reveal("vol1_ch1", SecretRevealChange(SecretId="S000000000001",
                                                            NewKnowerIds=["C1"]))
    assert svc.remove_chapter_data("vol1_ch1") == 1
    # no history left -> no knowers
    entry = stores["secret"].data()["S000000000001"]
    assert entry["CurrentStatus"] == "hidden"


# =====================================================================
# 7. PledgeConstraintService
# =====================================================================

def test_pledge_init():
    project, _ = make_project(["pledge"])
    svc = PledgeConstraintService(project)
    assert svc is not None


def test_pledge_create_and_snapshot():
    project, stores = make_project(["pledge"])
    svc = PledgeConstraintService(project)
    pid = svc.update_pledge("vol1_ch1",
                            PledgeConstraintChange(PledgeId="P000000000001", PledgeName="誓言",
                                                   Action="create", Type="oath", PartyIds=["C1"]))
    assert pid is not None
    entry = stores["pledge"].data()[pid]
    assert entry["CurrentStatus"] == "active"
    assert entry["PartyIds"] == ["C1"]
    assert len(svc.extract_snapshot()) == 1


def test_pledge_fulfill_updates_status():
    project, stores = make_project(["pledge"])
    svc = PledgeConstraintService(project)
    svc.update_pledge("vol1_ch1", PledgeConstraintChange(PledgeId="P000000000001", Action="create"))
    svc.update_pledge("vol1_ch2", PledgeConstraintChange(PledgeId="P000000000001", Action="fulfill"))
    assert stores["pledge"].data()["P000000000001"]["CurrentStatus"] == "fulfilled"


def test_pledge_guard():
    project, _ = make_project(["pledge"])
    svc = PledgeConstraintService(project)
    assert svc.update_pledge("vol1_ch1", PledgeConstraintChange(PledgeName="", Action="")) is None


# =====================================================================
# 8. DeadlineConstraintService
# =====================================================================

def test_deadline_init():
    project, _ = make_project(["deadline"])
    svc = DeadlineConstraintService(project)
    assert svc is not None


def test_deadline_create_and_snapshot():
    project, stores = make_project(["deadline"])
    svc = DeadlineConstraintService(project)
    did = svc.update_deadline("vol1_ch1",
                              DeadlineConstraintChange(DeadlineId="D000000000001",
                                                       DeadlineName="总攻", Action="create",
                                                       Deadline="vol3_ch1"))
    assert did is not None
    entry = stores["deadline"].data()[did]
    assert entry["CurrentStatus"] == "active"
    assert entry["Deadline"] == "vol3_ch1"
    assert len(svc.extract_snapshot()) == 1


def test_deadline_trigger_updates_status_and_overdue_off():
    project, stores = make_project(["deadline"])
    svc = DeadlineConstraintService(project)
    svc.update_deadline("vol1_ch1", DeadlineConstraintChange(DeadlineId="D000000000001", Action="create"))
    svc.update_deadline("vol1_ch2", DeadlineConstraintChange(DeadlineId="D000000000001", Action="trigger"))
    assert stores["deadline"].data()["D000000000001"]["CurrentStatus"] == "triggered"


def test_deadline_guard():
    project, _ = make_project(["deadline"])
    svc = DeadlineConstraintService(project)
    assert svc.update_deadline("vol1_ch1", DeadlineConstraintChange(DeadlineId="", Action="")) is None


def test_deadline_refresh_overdue_marks():
    project, stores = make_project(["deadline"])
    svc = DeadlineConstraintService(project)
    svc.update_deadline("vol1_ch1", DeadlineConstraintChange(DeadlineId="D000000000001", Action="create"))
    # distance = 10 chapters ahead -> overdue
    svc.refresh_overdue_status("vol2_ch1", 10)
    assert stores["deadline"].data()["D000000000001"]["IsOverdue"] is True


# =====================================================================
# 9. ForeshadowingStatusService
# =====================================================================

def test_foreshadowing_init():
    project, _ = make_project(["foreshadowing"])
    svc = ForeshadowingStatusService(project)
    assert svc is not None


def test_foreshadowing_mark_setup_resolved():
    project, stores = make_project(["foreshadowing"])
    svc = ForeshadowingStatusService(project)
    svc.mark_as_setup("FS1", "vol1_ch1")
    svc.mark_as_resolved("FS1", "vol2_ch5")
    entry = stores["foreshadowing"].data()["FS1"]
    assert entry["IsSetup"] is True
    assert entry["IsResolved"] is True
    assert entry["ActualPayoffChapter"] == "vol2_ch5"


def test_foreshadowing_statistics():
    project, _ = make_project(["foreshadowing"])
    svc = ForeshadowingStatusService(project)
    svc.mark_as_setup("FS1", "vol1_ch1")
    svc.mark_as_resolved("FS2", "vol1_ch2")
    stats = svc.get_statistics()
    assert stats["TotalCount"] == 2
    assert stats["SetupCount"] == 1
    assert stats["ResolvedCount"] == 1


def test_foreshadowing_refresh_overdue():
    project, stores = make_project(["foreshadowing"])
    svc = ForeshadowingStatusService(project)
    svc.mark_as_setup("FS1", "vol1_ch1")
    stores["foreshadowing"].data()["FS1"]["ExpectedPayoffChapter"] = "vol2_ch1"
    svc.refresh_overdue_status("vol2_ch2")  # moved past expected -> overdue
    assert stores["foreshadowing"].data()["FS1"]["IsOverdue"] is True


# =====================================================================
# 10. TimelineService
# =====================================================================

def test_timeline_init():
    project, _ = make_project(["timeline", "character_location"])
    svc = TimelineService(project)
    assert svc is not None


def test_timeline_update_time_progression():
    project, stores = make_project(["timeline", "character_location"])
    svc = TimelineService(project)
    result = svc.update_time_progression("vol1_ch1",
                                         TimeProgressionChange(TimePeriod="清晨", ElapsedTime="1天"))
    assert result is not None
    assert len(stores["timeline"].data()["ChapterTimeline"]) == 1
    timeline = svc.get_recent_timeline()
    assert len(timeline) == 1


def test_timeline_update_time_guards_empty():
    project, _ = make_project(["timeline", "character_location"])
    svc = TimelineService(project)
    assert svc.update_time_progression("vol1_ch1", TimeProgressionChange(TimePeriod="", ElapsedTime="")) is None
    assert svc.update_time_progression("vol1_ch1", None) is None


def test_timeline_update_character_movements():
    project, stores = make_project(["timeline", "character_location"])
    svc = TimelineService(project)
    moves = [CharacterMovementChange(CharacterId="C1", FromLocation="A", ToLocation="B")]
    count = svc.update_character_movements("vol1_ch1", moves)
    assert count == 1
    locs = svc.get_all_character_locations()
    assert locs["C1"]["CurrentLocation"] == "B"
    assert len(stores["character_location"].data()["C1"]["MovementHistory"]) == 1


def test_timeline_remove_chapter():
    project, _ = make_project(["timeline", "character_location"])
    svc = TimelineService(project)
    svc.update_time_progression("vol1_ch1", TimeProgressionChange(TimePeriod="清晨", ElapsedTime="1天"))
    assert svc.remove_chapter_data("vol1_ch1") == 1


# =====================================================================
# 11. RelationStrengthService
# =====================================================================

def test_relation_strength_init():
    project, _ = make_project([])
    svc = RelationStrengthService(project, use_cache=False)
    assert svc is not None


def test_relation_strength_compute_weak_on_empty():
    project, _ = make_project([])
    svc = RelationStrengthService(project, use_cache=False)
    svc.invalidate_cache()
    # no design data -> weak (0)
    assert svc.compute_strength_realtime("C1", "C2") == 0


def test_relation_strength_helpers():
    assert determine_strength_by_relation_type("仇敌") == 2
    assert apply_strength_hint(0, "Strong") == 2
    assert get_pair_key("B", "A") == "A_B"


def test_relation_strength_index():
    idx = RelationStrengthIndex()
    idx.add_pair("C1", "C2", 2)
    assert idx.get_strength("C2", "C1") == 2
    idx.ensure_min_strength("C3", "C4", 1)
    assert idx.get_strength("C3", "C4") == 1


def test_relation_strength_build_index_from_project():
    project, _ = make_project([])
    project.plan["chapters"] = {"chapters": [{"Id": "C1"}]}
    svc = RelationStrengthService(project, use_cache=False)
    index = svc.build_strength_index()
    assert index is not None
    assert hasattr(index, "get_strength")