# -*- coding: utf-8 -*-
"""tests for novel_writer/implementations/tracking/entity_drift/*"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest

from novel_writer.implementations.tracking.entity_drift import (
    EntityOmissionRecord,
    EntityDriftFallbackResult,
    EntityDimensionDescriptor,
    DriftEntityRecord,
    AUTO_PATCH,
    WARN_ONLY,
    EntityDimensionRegistry,
    append_bounded_warning,
    name_exists_in_content,
    EntityOmissionDetector,
    EntityDriftFallbackPatcher,
)


class TestEntityOmissionRecord:
    def test_fields(self):
        r = EntityOmissionRecord("角色", "character", "1", "张三", "CharacterStateChanges")
        assert r.DimensionName == "角色"
        assert r.DimensionCode == "character"
        assert r.EntityId == "1"
        assert r.EntityName == "张三"
        assert r.ChangeFieldName == "CharacterStateChanges"


class TestEntityDriftFallbackResult:
    def test_defaults(self):
        r = EntityDriftFallbackResult()
        assert r.AutoPatchedCount == 0
        assert r.WarnOnlyCount == 0
        assert r.DirtyGuideFiles == set()
        assert r.Details == []

    def test_patched_changes(self):
        r = EntityDriftFallbackResult(AutoPatchedCount=2)
        assert r.PatchedChanges is True
        r.AutoPatchedCount = 0
        assert r.PatchedChanges is False

    def test_has_any_drift_warn_only(self):
        r = EntityDriftFallbackResult(WarnOnlyCount=1)
        assert r.HasAnyDrift is True
        r = EntityDriftFallbackResult()
        assert r.HasAnyDrift is False


class TestEntityDimensionDescriptor:
    def test_defaults(self):
        d = EntityDimensionDescriptor()
        assert d.DimensionName == ""
        assert d.DimensionCode == ""
        assert d.GuideFileName == ""
        assert d.IsVolumeScoped is False
        assert d.Strategy == WARN_ONLY
        assert d.ChangeFieldName == ""
        assert d.LoadRecentEntities is None
        assert d.ExtractDeclaredIds is None
        assert d.AppendDriftWarning is None
        assert d.AutoPatchAction is None

    def test_custom_values(self):
        fn = lambda tracking: []
        d = EntityDimensionDescriptor(
            DimensionName="角色", DimensionCode="character",
            GuideFileName="g.json", IsVolumeScoped=True,
            Strategy=AUTO_PATCH, ChangeFieldName="X",
            LoadRecentEntities=fn,
        )
        assert d.Strategy == AUTO_PATCH
        assert d.LoadRecentEntities is fn

    def test_drift_entity_record(self):
        r = DriftEntityRecord("1", "张三", 2)
        assert r.Id == "1"
        assert r.Name == "张三"
        assert r.VolumeNumber == 2
        assert r.DriftWarnings == []

    def test_strategy_constants(self):
        assert AUTO_PATCH == "AutoPatch"
        assert WARN_ONLY == "WarnOnly"


class TestAppendBoundedWarning:
    def test_append_new(self):
        entry = {}
        append_bounded_warning(entry, "w1", 3)
        assert entry["DriftWarnings"] == ["w1"]

    def test_converts_non_list(self):
        entry = {"DriftWarnings": "notalist"}
        append_bounded_warning(entry, "w1", 5)
        assert entry["DriftWarnings"] == ["w1"]

    def test_bounded_over_max_removes_oldest(self):
        entry = {"DriftWarnings": ["a", "b"]}
        append_bounded_warning(entry, "c", 2)
        assert entry["DriftWarnings"] == ["b", "c"]


class TestNameExistsInContent:
    def test_exact_match(self):
        assert name_exists_in_content("张三来了", "张三") is True

    def test_primary_name_in_brackets(self):
        # 张三（张三丰）的括号是别名；主名"张三"出现
        assert name_exists_in_content("张三出现", "张三（张三丰）") is True

    def test_alias_in_brackets(self):
        assert name_exists_in_content("小小说话了", "张小（小小）") is True

    def test_not_present(self):
        assert name_exists_in_content("风很大", "李四") is False

    def test_empty_inputs(self):
        assert name_exists_in_content("", "张三") is False
        assert name_exists_in_content("张三", "") is False


class TestEntityDimensionRegistry:
    def test_nine_dimensions(self):
        dims = EntityDimensionRegistry.all()
        assert len(dims) == 9

    def test_codes_present(self):
        codes = {d.DimensionCode for d in EntityDimensionRegistry.all()}
        expected = {"character", "faction", "location", "conflict", "item",
                    "foreshadowing", "secret", "pledge", "deadline"}
        assert codes == expected

    def test_get_by_code_case_insensitive(self):
        c = EntityDimensionRegistry.get_by_code("CHARACTER")
        assert c is not None
        assert c.DimensionCode == "character"

    def test_get_by_code_missing(self):
        assert EntityDimensionRegistry.get_by_code("nope") is None

    def test_auto_patch_dimensions(self):
        codes = {d.DimensionCode for d in EntityDimensionRegistry.auto_patch_dimensions()}
        assert codes == {"character", "faction", "location"}

    def test_warn_only_dimensions(self):
        codes = {d.DimensionCode for d in EntityDimensionRegistry.warn_only_dimensions()}
        assert codes == {"conflict", "item", "foreshadowing", "secret", "pledge", "deadline"}

    def test_strategies(self):
        for d in EntityDimensionRegistry.all():
            assert d.Strategy in (AUTO_PATCH, WARN_ONLY)


class FakeTracking:
    """Minimal stub exposing per-store data()/set_all()."""

    def __init__(self):
        self._stores = {}
        for key in ("character_state", "faction_state", "location_state",
                    "conflict_progress", "item_state", "foreshadowing",
                    "secret", "pledge", "deadline"):
            self._stores[key] = FakeStore()


class FakeStore:
    def __init__(self):
        self._data = {}

    def data(self):
        return self._data

    def set_all(self, data):
        self._data = data


class FakeChanges:
    """Stub container holding change lists used by ExtractDeclaredIds."""

    def __init__(self, **kwargs):
        self.CharacterStateChanges = []
        self.FactionStateChanges = []
        self.LocationStateChanges = []
        self.ConflictProgress = []
        self.ItemTransfers = []
        self.ForeshadowingActions = []
        self.SecretRevealChanges = []
        self.PledgeConstraintChanges = []
        self.DeadlineConstraintChanges = []
        for k, v in kwargs.items():
            setattr(self, k, v)


class _E:
    def __init__(self, **kw):
        for k, v in kw.items():
            setattr(self, k, v)


class TestEntityOmissionDetector:
    def test_empty_content_returns_empty(self):
        d = EntityOmissionDetector(project=None, tracking_manager=FakeTracking())
        assert d.detect("", FakeChanges()) == []

    def test_no_entities_returns_empty(self):
        tr = FakeTracking()
        d = EntityOmissionDetector(None, tr)
        assert d.detect("正文内容", FakeChanges()) == []

    def test_detects_omission(self):
        tr = FakeTracking()
        tr._stores["character_state"]._data = {
            "c1": {"Name": "张三"},
        }
        d = EntityOmissionDetector(None, tr)
        records = d.detect("张三走进了大厅", FakeChanges())
        assert len(records) == 1
        rec = records[0]
        assert rec.DimensionName == "角色"
        assert rec.DimensionCode == "character"
        assert rec.EntityId == "c1"
        assert rec.EntityName == "张三"
        assert rec.ChangeFieldName == "CharacterStateChanges"

    def test_declared_entity_not_omitted(self):
        tr = FakeTracking()
        tr._stores["character_state"]._data = {"c1": {"Name": "张三"}}
        changes = FakeChanges()
        changes.CharacterStateChanges.append(_E(CharacterId="c1"))
        d = EntityOmissionDetector(None, tr)
        records = d.detect("张三走进了大厅", changes)
        assert records == []

    def test_excludes_pattern_keys_for_foreshadowing(self):
        # foreshadowing dimension deliberately skips PendingList/OverdueList
        tr = FakeTracking()
        tr._stores["foreshadowing"]._data = {
            "f1": {"Name": "暗线伏笔"},  # would be detected
        }
        d = EntityOmissionDetector(None, tr)
        records = d.detect("暗线伏笔出现了", FakeChanges())
        fores = [r for r in records if r.DimensionCode == "foreshadowing"]
        assert any(r.EntityId == "f1" for r in fores)


class TestEntityDriftFallbackPatcher:
    def test_empty_summary_returns_empty_result(self):
        p = EntityDriftFallbackPatcher(None, FakeTracking())
        r = p.detect_and_apply("ch1", "", FakeChanges())
        assert r.AutoPatchedCount == 0
        assert r.WarnOnlyCount == 0
        assert r.DirtyGuideFiles == set()

    def test_character_undisclosed_gets_autopatched(self):
        tr = FakeTracking()
        tr._stores["character_state"]._data = {"c1": {"Name": "张三"}}
        changes = FakeChanges()
        p = EntityDriftFallbackPatcher(None, tr)
        r = p.detect_and_apply("ch1", "张三走进了大厅", changes)
        assert r.AutoPatchedCount >= 1
        assert any(c.CharacterId == "c1" for c in changes.CharacterStateChanges)
        assert "character_state" in r.DirtyGuideFiles
        assert "角色" in r.Details[0]
        assert "张三" in r.Details[0]
        warnings = tr._stores["character_state"]._data["c1"]["DriftWarnings"]
        assert any("ch1" in w for w in warnings)

    def test_warn_only_dimension_not_autopatched(self):
        tr = FakeTracking()
        tr._stores["secret"]._data = {"s1": {"Name": "机密"}}
        changes = FakeChanges()
        p = EntityDriftFallbackPatcher(None, tr)
        r = p.detect_and_apply("ch1", "机密被保守着", changes)
        assert r.WarnOnlyCount >= 1
        assert r.AutoPatchedCount == 0

    def test_declared_entity_not_patched(self):
        tr = FakeTracking()
        tr._stores["character_state"]._data = {"c1": {"Name": "张三"}}
        changes = FakeChanges()
        changes.CharacterStateChanges.append(_E(CharacterId="c1"))
        p = EntityDriftFallbackPatcher(None, tr)
        r = p.detect_and_apply("ch1", "张三走进了大厅", changes)
        assert r.AutoPatchedCount == 0

    def test_too_short_name_skipped(self):
        tr = FakeTracking()
        tr._stores["character_state"]._data = {"c1": {"Name": "张"}}
        p = EntityDriftFallbackPatcher(None, tr)
        r = p.detect_and_apply("ch1", "张走进了大厅", changes=FakeChanges(), min_name_length=2)
        assert r.AutoPatchedCount == 0