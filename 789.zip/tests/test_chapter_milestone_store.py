# -*- coding: utf-8 -*-
"""tests for chapter_milestone_store.py"""
import sys, os, tempfile, shutil
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock, patch
from novel_writer.implementations.guides.chapter_milestone_store import ChapterMilestoneStore


class MockProject:
    def __init__(self):
        self.dir = tempfile.mkdtemp(prefix="test_cms_")
    def __del__(self):
        shutil.rmtree(self.dir, ignore_errors=True)


@pytest.fixture
def project():
    p = MockProject()
    yield p
    shutil.rmtree(p.dir, ignore_errors=True)


@pytest.fixture
def store(project):
    return ChapterMilestoneStore(project)


# --- 路径方法 ---

def test_get_milestones_dir(store):
    path = store.get_milestones_dir()
    assert "milestones" in path


def test_get_milestone_file_path(store):
    path = store.get_milestone_file_path(3)
    assert "vol3.txt" in path


# --- rebuild_volume_milestone ---

def test_rebuild_volume_milestone_normal(store, project):
    summaries = {"ch1": "第一章总结", "ch2": "第二章总结"}
    store.rebuild_volume_milestone(1, summaries)
    path = store.get_milestone_file_path(1)
    assert os.path.exists(path)
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    assert "第1卷" in content
    assert "第一章总结" in content or "ch1" in content


def test_rebuild_volume_milestone_invalid_number(store):
    store.rebuild_volume_milestone(0, {"ch1": "test"})
    assert store._cache == {}


def test_rebuild_volume_milestone_empty_summaries(store):
    store.rebuild_volume_milestone(1, {})
    assert store._cache == {}


# --- append_chapter_milestone ---

def test_append_chapter_milestone_new(store, project):
    store.append_chapter_milestone(1, "ch1", "第一章总结")
    path = store.get_milestone_file_path(1)
    assert os.path.exists(path)
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    assert "ch1" in content
    assert "第一章总结" in content


def test_append_chapter_milestone_append(store, project):
    store.append_chapter_milestone(1, "ch1", "第一章总结")
    store.append_chapter_milestone(1, "ch2", "第二章总结")
    with open(store.get_milestone_file_path(1), "r", encoding="utf-8") as f:
        content = f.read()
    assert "ch1" in content
    assert "ch2" in content


def test_append_chapter_milestone_invalid_number(store):
    store.append_chapter_milestone(0, "ch1", "test")
    assert store._cache == {}


def test_append_chapter_milestone_empty_summary(store):
    store.append_chapter_milestone(1, "ch1", "")
    assert store._cache == {}


# --- get_previous_milestones ---

def test_get_previous_milestones_normal(store, project):
    for v in range(1, 4):
        store.append_chapter_milestone(v, f"ch{v}", f"第{v}卷总结")
    result = store.get_previous_milestones(4)
    assert len(result) == 3
    assert all(e.VolumeNumber in (1, 2, 3) for e in result)


def test_get_previous_milestones_volume_one(store):
    result = store.get_previous_milestones(1)
    assert result == []


def test_get_previous_milestones_missing_volumes(store):
    store.append_chapter_milestone(5, "ch5", "总结")
    result = store.get_previous_milestones(6)
    assert len(result) == 1


# --- get_total_char_count ---

def test_get_total_char_count_empty():
    assert ChapterMilestoneStore.get_total_char_count([]) == 0


def test_get_total_char_count_normal():
    result = ChapterMilestoneStore.get_total_char_count(["hello", "世界"])
    assert result == 7


def test_get_total_char_count_none_values():
    result = ChapterMilestoneStore.get_total_char_count([None, "abc"])
    assert result == 7  # str(None)="None"(4) + "abc"(3)


# --- invalidate_cache ---

def test_invalidate_cache(store, project):
    store.append_chapter_milestone(1, "ch1", "总结")
    assert 1 in store._cache
    store.invalidate_cache()
    assert store._cache == {}