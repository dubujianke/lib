# -*- coding: utf-8 -*-
"""tests for preflight.py (PreflightValidator)"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock, patch
from novel_writer.preflight import PreflightValidator


class MockProject:
    def __init__(self):
        self._design = {}
        self._plan = {}
    def load_design(self, entity):
        return self._design.get(entity, [])
    def load_plan(self, entity):
        return self._plan.get(entity, [])
    def set_design(self, entity, data):
        self._design[entity] = data
    def set_plan(self, entity, data):
        self._plan[entity] = data


@pytest.fixture
def validator():
    return PreflightValidator(MockProject())


# --- run ---

def test_run_passes(validator):
    validator.project.set_design("characters", [{"Name": "小明", "Id": "c1"}])
    validator.project.set_design("factions", [{"Name": "教团", "Id": "f1"}])
    validator.project.set_design("locations", [{"Name": "森林", "Id": "l1"}])
    validator.project.set_plan("volumes", [{
        "VolumeNumber": 1, "Name": "序章",
        "ReferencedCharacterNames": "小明",
        "ReferencedFactionNames": "教团",
        "ReferencedLocationNames": "森林",
    }])
    validator.project.set_plan("chapters", [{
        "ChapterNumber": 1, "ChapterTitle": "开始",
        "Volume": "第1卷",
        "ReferencedCharacterNames": "小明",
    }])
    assert validator.run() is True


def test_run_fails_with_unmatched(validator):
    validator.project.set_plan("volumes", [{
        "VolumeNumber": 1, "Name": "序章",
        "ReferencedCharacterNames": "不存在的角色",
    }])
    validator.project.set_plan("chapters", [])
    assert validator.run() is False
    assert any("不存在的角色" in e for e in validator.errors)


# --- normalize_to_id ---

def test_normalize_to_id_found(validator):
    idx = {"names": {"小明": "c1"}, "name_to_id": {"小明": "c1"}}
    result = validator.normalize_to_id("小明", idx)
    assert result == "c1"


def test_normalize_to_id_not_found(validator):
    idx = {"names": set(), "name_to_id": {}}
    result = validator.normalize_to_id("未知", idx)
    assert result == "未知"


def test_normalize_to_id_none(validator):
    idx = {"names": set(), "name_to_id": {}}
    result = validator.normalize_to_id(None, idx)
    assert result == ""


# --- find_unmatched ---

def test_find_unmatched_some_missing(validator):
    idx = {"names": {"小明"}, "ids": set()}
    result = validator.find_unmatched(["小明", "小红", "小刚"], idx)
    assert result == ["小红", "小刚"]


def test_find_unmatched_all_matched(validator):
    idx = {"names": {"小明", "小红"}, "ids": set()}
    result = validator.find_unmatched(["小明", "小红"], idx)
    assert result == []


def test_find_unmatched_empty(validator):
    result = validator.find_unmatched([], {"names": set(), "ids": set()})
    assert result == []


def test_find_unmatched_with_ids(validator):
    idx = {"names": set(), "ids": {"c1"}}
    result = validator.find_unmatched(["c1", "c2"], idx)
    assert result == ["c2"]


# --- validate_volume_references ---

def test_validate_volume_references_valid(validator):
    volumes = [{"VolumeNumber": 1, "ReferencedCharacterNames": "小明"}]
    idx = {"names": {"小明"}, "name_to_id": {"小明": "c1"}, "ids": {"c1"}}
    validator.validate_volume_references(volumes, idx, {}, {})
    assert len(validator.errors) == 0


def test_validate_volume_references_unmatched(validator):
    volumes = [{"VolumeNumber": 1, "ReferencedCharacterNames": "不存在的角色"}]
    idx = {"names": set(), "name_to_id": {}, "ids": set()}
    validator.validate_volume_references(volumes, idx, {}, {})
    assert any("不存在的角色" in e for e in validator.errors)


# --- validate_chapter_references ---

def test_validate_chapter_references_valid(validator):
    chapters = [{"ChapterNumber": 1, "Volume": "第1卷", "ReferencedCharacterNames": "小明"}]
    idx = {"names": {"小明"}, "name_to_id": {"小明": "c1"}, "ids": {"c1"}}
    validator.validate_chapter_references(chapters, idx, {}, {})
    assert len(validator.errors) == 0


def test_validate_chapter_references_unmatched(validator):
    chapters = [{"ChapterNumber": 1, "ReferencedCharacterNames": "张三"}]
    idx = {"names": set(), "name_to_id": {}, "ids": set()}
    validator.validate_chapter_references(chapters, idx, {}, {})
    assert len(validator.errors) > 0
    assert "张三" in validator.errors[0]


# --- validate_blueprint_references ---

def test_validate_blueprint_references_valid(validator):
    blueprints = [{"ChapterId": "ch1", "SceneNumber": 1, "Cast": "小明"}]
    idx = {"names": {"小明"}, "name_to_id": {"小明": "c1"}, "ids": {"c1"}}
    validator.validate_blueprint_references(blueprints, idx, {}, {})
    assert len(validator.errors) == 0


def test_validate_blueprint_references_unmatched(validator):
    blueprints = [{"ChapterId": "ch1", "SceneNumber": 1, "Cast": "不存在的角色"}]
    idx = {"names": set(), "name_to_id": {}, "ids": set()}
    validator.validate_blueprint_references(blueprints, idx, {}, {})
    assert any("不存在的角色" in e for e in validator.errors)


# --- validate_uniqueness ---

def test_validate_uniqueness_no_duplicates(validator):
    chapters = [{"ChapterNumber": 1, "Volume": "第1卷", "ChapterTitle": "第一章"},
                {"ChapterNumber": 2, "Volume": "第1卷", "ChapterTitle": "第二章"}]
    blueprints = []
    validator.validate_uniqueness(chapters, blueprints)
    assert len(validator.errors) == 0


def test_validate_uniqueness_duplicate_chapters(validator):
    chapters = [{"ChapterNumber": 1, "Volume": "第1卷", "ChapterTitle": "重复"},
                {"ChapterNumber": 1, "Volume": "第1卷", "ChapterTitle": "重复2"}]
    validator.validate_uniqueness(chapters, [])
    assert any("重复" in e for e in validator.errors)


def test_validate_uniqueness_duplicate_blueprints(validator):
    chapters = []
    blueprints = [{"ChapterId": "ch1", "SceneNumber": 1, "SceneTitle": "场景A"},
                  {"ChapterId": "ch1", "SceneNumber": 1, "SceneTitle": "场景B"}]
    validator.validate_uniqueness(chapters, blueprints)
    assert any("场景A" in e for e in validator.errors)


# --- normalize_to_id_set ---

def test_normalize_to_id_set(validator):
    idx = {"names": {"小明": "c1"}, "name_to_id": {"小明": "c1"}, "ids": {"c1"}}
    result = validator.normalize_to_id_set(["小明", "未知"], idx)
    assert result == {"c1"}


def test_normalize_to_id_set_empty(validator):
    result = validator.normalize_to_id_set([], {"names": {}, "name_to_id": {}, "ids": set()})
    assert result == set()


# --- check_subset ---

def test_check_subset_no_escape(validator):
    idx = {"names": {"小明": "c1"}, "name_to_id": {"小明": "c1"}}
    validator.check_subset({"c1"}, {"c1"}, "章节", "分卷", idx, "角色")
    assert len(validator.errors) == 0


def test_check_subset_with_escape(validator):
    idx = {"names": {"小明": "c1"}, "name_to_id": {"小明": "c1"}}
    validator.check_subset({"c2"}, {"c1"}, "章节", "分卷", idx, "角色")
    assert any("c2" in e for e in validator.errors)


# --- try_parse_volume_number ---

def test_try_parse_volume_number_valid():
    assert PreflightValidator.try_parse_volume_number("第1卷") == 1
    assert PreflightValidator.try_parse_volume_number("第12卷") == 12


def test_try_parse_volume_number_chinese():
    assert PreflightValidator.try_parse_volume_number("第二卷") == 2
    assert PreflightValidator.try_parse_volume_number("第十卷") == 10


def test_try_parse_volume_number_invalid():
    assert PreflightValidator.try_parse_volume_number("") is None
    assert PreflightValidator.try_parse_volume_number("abc") is None
    assert PreflightValidator.try_parse_volume_number(None) is None


# --- try_parse_chinese_number ---

def test_try_parse_chinese_number_simple():
    assert PreflightValidator.try_parse_chinese_number("一") == 1
    assert PreflightValidator.try_parse_chinese_number("五") == 5
    assert PreflightValidator.try_parse_chinese_number("九") == 9


def test_try_parse_chinese_number_compound():
    assert PreflightValidator.try_parse_chinese_number("十") == 10
    assert PreflightValidator.try_parse_chinese_number("十一") == 11
    assert PreflightValidator.try_parse_chinese_number("二十") == 20
    assert PreflightValidator.try_parse_chinese_number("二十一") == 21
    assert PreflightValidator.try_parse_chinese_number("一百") == 100
    assert PreflightValidator.try_parse_chinese_number("一百二十三") == 123


def test_try_parse_chinese_number_invalid():
    assert PreflightValidator.try_parse_chinese_number("") is None
    assert PreflightValidator.try_parse_chinese_number("abc") is None
    assert PreflightValidator.try_parse_chinese_number(None) is None


# --- get_module_path_from_relative_path ---

def test_get_module_path_from_relative_path_normal():
    result = PreflightValidator.get_module_path_from_relative_path("Design/Elements/Characters")
    assert result == "Design/Elements"


def test_get_module_path_from_relative_path_short():
    result = PreflightValidator.get_module_path_from_relative_path("Design")
    assert result == ""


def test_get_module_path_from_relative_path_empty():
    assert PreflightValidator.get_module_path_from_relative_path("") == ""
    assert PreflightValidator.get_module_path_from_relative_path(None) == ""


# ---- 追加测试：validate_volume_references（多卷/多索引） ----

def test_validate_volume_references_valid_all_idx(validator):
    volumes = [{"VolumeNumber": 1, "ReferencedCharacterNames": "小明", "ReferencedFactionNames": "教团", "ReferencedLocationNames": "森林"}]
    idx = {"names": {"小明", "教团", "森林"}, "name_to_id": {"小明": "c1", "教团": "f1", "森林": "l1"}, "ids": {"c1", "f1", "l1"}}
    validator.validate_volume_references(volumes, idx, idx, idx)
    assert len(validator.errors) == 0


def test_validate_volume_references_multiple_unmatched(validator):
    volumes = [{"VolumeNumber": 1, "ReferencedCharacterNames": "A、B", "ReferencedFactionNames": "X"}]
    idx = {"names": set(), "name_to_id": {}, "ids": set()}
    validator.validate_volume_references(volumes, idx, idx, idx)
    assert any("A" in e for e in validator.errors)
    assert any("B" in e for e in validator.errors)
    assert any("X" in e for e in validator.errors)


# ---- 追加测试：validate_chapter_references（多章/多索引） ----

def test_validate_chapter_references_multi_chapter(validator):
    chapters = [{"ChapterNumber": 1, "Volume": "第1卷", "ReferencedCharacterNames": "小明"},
                {"ChapterNumber": 2, "Volume": "第1卷", "ReferencedCharacterNames": "小红"}]
    idx = {"names": {"小明", "小红"}, "name_to_id": {"小明": "c1", "小红": "c2"}, "ids": {"c1", "c2"}}
    validator.validate_chapter_references(chapters, idx, {}, {})
    assert len(validator.errors) == 0


def test_validate_chapter_references_with_faction_and_location(validator):
    chapters = [{"ChapterNumber": 1, "Volume": "第1卷", "ReferencedCharacterNames": "小明",
                 "ReferencedFactionNames": "教团", "ReferencedLocationNames": "森林"}]
    idx = {"names": {"小明", "教团", "森林"}, "name_to_id": {"小明": "c1", "教团": "f1", "森林": "l1"}, "ids": {"c1", "f1", "l1"}}
    validator.validate_chapter_references(chapters, idx, idx, idx)
    assert len(validator.errors) == 0


# ---- 追加测试：validate_blueprint_references ----

def test_validate_blueprint_references_cast_loc_fac(validator):
    blueprints = [{"ChapterId": "ch1", "SceneNumber": 1, "Cast": "小明", "Locations": "森林", "Factions": "教团"}]
    idx = {"names": {"小明", "森林", "教团"}, "name_to_id": {"小明": "c1", "森林": "l1", "教团": "f1"}, "ids": {"c1", "l1", "f1"}}
    validator.validate_blueprint_references(blueprints, idx, idx, idx)
    assert len(validator.errors) == 0


def test_validate_blueprint_references_all_missing(validator):
    blueprints = [{"ChapterId": "ch1", "SceneNumber": 1, "Cast": "X", "Locations": "Y", "Factions": "Z"}]
    idx = {"names": set(), "name_to_id": {}, "ids": set()}
    validator.validate_blueprint_references(blueprints, idx, idx, idx)
    assert any("X" in e for e in validator.errors)
    assert any("Y" in e for e in validator.errors)
    assert any("Z" in e for e in validator.errors)


# ---- 追加测试：validate_uniqueness ----

def test_validate_uniqueness_duplicate_blueprints_across_chapters(validator):
    chapters = []
    blueprints = [{"ChapterId": "ch1", "SceneNumber": 1, "SceneTitle": "场景A"},
                  {"ChapterId": "ch1", "SceneNumber": 1, "SceneTitle": "场景A2"},
                  {"ChapterId": "ch2", "SceneNumber": 1, "SceneTitle": "场景B"}]
    validator.validate_uniqueness(chapters, blueprints)
    assert any("场景A" in e for e in validator.errors)
    assert any("场景A2" in e for e in validator.errors)


def test_validate_uniqueness_empty(validator):
    validator.validate_uniqueness([], [])
    assert len(validator.errors) == 0


# ---- 追加测试：normalize_to_id_set ----

def test_normalize_to_id_set_mixed(validator):
    idx = {"names": {"小明": "c1"}, "name_to_id": {"小明": "c1"}, "ids": {"c1", "c2"}}
    result = validator.normalize_to_id_set(["小明", "c2", "未知"], idx)
    assert result == {"c1", "c2"}


def test_normalize_to_id_set_duplicates(validator):
    idx = {"names": {"小明": "c1"}, "name_to_id": {"小明": "c1"}, "ids": {"c1"}}
    result = validator.normalize_to_id_set(["小明", "小明"], idx)
    assert result == {"c1"}


def test_normalize_to_id_set_none_items(validator):
    idx = {"names": {}, "name_to_id": {}, "ids": set()}
    result = validator.normalize_to_id_set([None, ""], idx)
    assert result == set()


# ---- 追加测试：check_subset ----

def test_check_subset_no_escape_with_ids(validator):
    idx = {"names": {"小明": "c1"}, "name_to_id": {"小明": "c1"}}
    validator.check_subset({"c1", "c2"}, {"c1", "c2"}, "章节", "分卷", idx, "角色")
    assert len(validator.errors) == 0


def test_check_subset_partial_escape(validator):
    idx = {"names": {"小明": "c1"}, "name_to_id": {"小明": "c1"}}
    validator.check_subset({"c1", "c3", "c4"}, {"c1"}, "章节", "分卷", idx, "角色")
    assert any("c3" in e for e in validator.errors)
    assert any("c4" in e for e in validator.errors)


# ---- 追加测试：try_parse_volume_number ----

def test_try_parse_volume_number_chinese_large():
    assert PreflightValidator.try_parse_volume_number("第一百卷") == 100
    assert PreflightValidator.try_parse_volume_number("第二十二卷") == 22


def test_try_parse_volume_number_with_spaces():
    assert PreflightValidator.try_parse_volume_number("第 5 卷") == 5
    assert PreflightValidator.try_parse_volume_number("第   10   卷") == 10


# ---- 追加测试：try_parse_chinese_number ----

def test_try_parse_chinese_number_large():
    assert PreflightValidator.try_parse_chinese_number("一万") == 10000
    assert PreflightValidator.try_parse_chinese_number("一千零一") is not None


def test_try_parse_chinese_number_variants():
    assert PreflightValidator.try_parse_chinese_number("叁") == 3
    assert PreflightValidator.try_parse_chinese_number("拾") == 10
    assert PreflightValidator.try_parse_chinese_number("贰拾伍") == 25


# ---- 追加测试：get_module_path_from_relative_path ----

def test_get_module_path_from_relative_path_deep():
    result = PreflightValidator.get_module_path_from_relative_path("Design/Elements/Characters/Sub")
    assert result == "Design/Elements"


def test_get_module_path_from_relative_path_exact_two():
    result = PreflightValidator.get_module_path_from_relative_path("Design/Elements")
    assert result == "Design/Elements"