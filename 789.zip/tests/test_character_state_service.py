# -*- coding: utf-8 -*-
"""CharacterStateService 单元测试 — 对标 4.1.1 CharacterStateService.cs"""
import sys
import os
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock, patch

from novel_writer.implementations.tracking.character_state_service import (
    CharacterStateService,
    parse_chapter_id,
    compare_chapter_id,
    build_chapter_id,
)


class FakeStore:
    """模拟 GuideStore：提供 data() / set_all()。"""

    def __init__(self):
        self._data = {}

    def data(self):
        return self._data

    def set_all(self, data):
        self._data = data


class FakeProject:
    def __init__(self, **stores):
        self.dir = tempfile.mkdtemp(prefix="test_char_")
        self._stores = {k: v for k, v in stores.items()}
        self.design = {}
        self.plan = {}

    def tracking(self, name):
        return self._stores.setdefault(name, FakeStore())

    def load_design(self, entity):
        return self.design.get(entity, {})

    def load_plan(self, entity):
        return self.plan.get(entity, {})


@pytest.fixture
def service():
    store = FakeStore()
    project = FakeProject(character_state=store)
    return CharacterStateService(project), project, store


def make_change(**kwargs):
    """构造伪造的 CharacterStateChange（鸭子类型，字段可访问）。"""
    change = MagicMock()
    change.CharacterId = kwargs.get("CharacterId", "C1")
    change.NewLevel = kwargs.get("NewLevel", "")
    change.NewAbilities = kwargs.get("NewAbilities", [])
    change.LostAbilities = kwargs.get("LostAbilities", [])
    change.RelationshipChanges = kwargs.get("RelationshipChanges", {})
    change.NewMentalState = kwargs.get("NewMentalState", "")
    change.KeyEvent = kwargs.get("KeyEvent", "")
    change.Importance = kwargs.get("Importance", "")
    change.CausedBy = kwargs.get("CausedBy", "")
    return change


# =====================================================================
# get_character_state_at（查询角色在指定章节时点的状态）
# =====================================================================

def test_get_character_state_at_returns_latest_at_or_before_chapter(service):
    svc, _, store = service
    store.data()["C1"] = {
        "Name": "阿明",
        "StateHistory": [
            {"Chapter": "vol1_ch1", "Level": "1"},
            {"Chapter": "vol1_ch3", "Level": "3"},
        ],
    }
    # >= 最近历史且 <= 目标章的记录
    state = svc.get_character_state_at("C1", "vol1_ch5")
    assert state is not None
    assert state["Level"] == "3"


def test_get_character_state_at_before_first_record_returns_none(service):
    svc, _, store = service
    store.data()["C1"] = {"Name": "阿明", "StateHistory": [{"Chapter": "vol2_ch1", "Level": "5"}]}
    # 目标章早于所有历史 → 二分返回 None
    assert svc.get_character_state_at("C1", "vol1_ch1") is None


def test_get_character_state_at_missing_character_returns_none(service):
    svc, _, _ = service
    assert svc.get_character_state_at("NONEXIST", "vol1_ch1") is None


def test_get_character_state_at_malformed_history_returns_none(service):
    svc, _, store = service
    store.data()["C1"] = {"Name": "阿明", "StateHistory": "not-a-list"}
    assert svc.get_character_state_at("C1", "vol1_ch1") is None


# =====================================================================
# update_character_state（更新/注册角色状态并追加快照）
# =====================================================================

def test_update_character_state_registers_new_character(service):
    svc, _, store = service
    new_state = svc.update_character_state("vol1_ch1", make_change(CharacterId="C1", NewLevel="3"),
                                           name_hint="阿明")
    assert new_state["Chapter"] == "vol1_ch1"
    assert new_state["Level"] == "3"
    entry = store.data()["C1"]
    assert entry["Name"] == "阿明"
    assert len(entry["StateHistory"]) == 1


def test_update_character_state_merges_abilities(service):
    svc, _, store = service
    svc.update_character_state("vol1_ch1", make_change(NewAbilities=["剑", "刀"]))
    # 重名小写去重 + 移除
    svc.update_character_state("vol1_ch2", make_change(NewAbilities=["枪"], LostAbilities=["剑"]))
    assert set(store.data()["C1"]["Abilities"]) == {"刀", "枪"}


def test_update_character_state_auto_escalates_to_important(service):
    svc, _, store = service
    # KeyEvent >= 20 字 且命中关键词 "第一次"
    key_event = "这是阿明第一次亲眼见到天地崩塌万物崩毁的场景令人震撼不已久久无法言语"
    new_state = svc.update_character_state("vol1_ch1",
                                           make_change(KeyEvent=key_event), name_hint="阿明")
    assert new_state["Importance"] == "important"
    assert store.data()["C1"]["Importance"] == 3


# =====================================================================
# remove_chapter_data（删除章节数据并重排）
# =====================================================================

def test_remove_chapter_data_removes_matching_records(service):
    svc, _, store = service
    svc.update_character_state("vol1_ch1", make_change())
    svc.update_character_state("vol1_ch2", make_change())
    removed = svc.remove_chapter_data("vol1_ch1")
    assert removed == 1
    assert len(store.data()["C1"]["StateHistory"]) == 1


def test_remove_chapter_data_no_match_returns_zero(service):
    svc, _, store = service
    svc.update_character_state("vol1_ch1", make_change())
    assert svc.remove_chapter_data("vol9_ch9") == 0


# =====================================================================
# try_resolve_display_name（从设计库解析角色名）
# =====================================================================

def test_try_resolve_display_name_found(service):
    svc, project, _ = service
    project.design["characters"] = {"items": [{"Id": "C1", "Name": "阿明"}, {"Id": "C2", "Name": "小虎"}]}
    assert svc.try_resolve_display_name("C1") == "阿明"


def test_try_resolve_display_name_not_found_returns_none(service):
    svc, project, _ = service
    project.design["characters"] = {"items": [{"Id": "C1", "Name": "阿明"}]}
    assert svc.try_resolve_display_name("C9") is None


def test_try_resolve_display_name_empty_name_returns_none(service):
    svc, project, _ = service
    project.design["characters"] = {"items": [{"Id": "C1", "Name": ""}]}
    assert svc.try_resolve_display_name("C1") is None


def test_try_resolve_display_name_exception_returns_none(service):
    svc, project, _ = service
    project.load_design = MagicMock(side_effect=Exception("boom"))
    assert svc.try_resolve_display_name("C1") is None


# =====================================================================
# _binary_search_state（二分查找 <= target 的最新记录）
# =====================================================================

def test_binary_search_state_finds_floor(service):
    history = [
        {"Chapter": "vol1_ch1", "Level": "1"},
        {"Chapter": "vol1_ch3", "Level": "3"},
        {"Chapter": "vol2_ch1", "Level": "10"},
    ]
    assert CharacterStateService._binary_search_state(history, "vol1_ch2")["Chapter"] == "vol1_ch1"
    assert CharacterStateService._binary_search_state(history, "vol2_ch1")["Chapter"] == "vol2_ch1"


def test_binary_search_state_empty_returns_none(service):
    assert CharacterStateService._binary_search_state([], "vol1_ch1") is None


def test_binary_search_state_before_all_returns_none(service):
    history = [{"Chapter": "vol2_ch1"}, {"Chapter": "vol2_ch5"}]
    assert CharacterStateService._binary_search_state(history, "vol1_ch9") is None


# =====================================================================
# get_phase_from_chapter（起承转合推导）
# =====================================================================

def test_get_phase_from_chapter_by_ratio(service):
    svc, project, _ = service
    project.plan["volumes"] = {"volumes": [1, 2, 3, 4]}
    assert svc.get_phase_from_chapter("vol1_ch1") == "起"
    assert svc.get_phase_from_chapter("vol3_ch1") == "转"
    assert svc.get_phase_from_chapter("vol4_ch1") == "合"


def test_get_phase_from_chapter_fallback_on_error(service):
    svc, project, _ = service
    project.load_plan = MagicMock(side_effect=Exception("boom"))
    assert svc.get_phase_from_chapter("vol2_ch1") == "承"


# =====================================================================
# merge_abilities / merge_relationships（合并逻辑）
# =====================================================================

def test_merge_abilities_case_insensitive_dedup(service):
    merged = CharacterStateService.merge_abilities(["剑", "刀"], ["剑", "枪"], [])
    assert set(merged) == {"剑", "刀", "枪"}


def test_merge_abilities_removes_lost(service):
    merged = CharacterStateService.merge_abilities(["剑", "刀"], [], ["剑"])
    assert merged == ["刀"]


def test_merge_abilities_none_inputs(service):
    assert CharacterStateService.merge_abilities(None, None, None) == []


# =====================================================================
# 工具函数：章节 ID 解析 / 比较 / 构造
# =====================================================================

def test_parse_chapter_id_formats():
    assert parse_chapter_id("vol2_ch3") == (2, 3)
    assert parse_chapter_id("v2_c3") == (2, 3)
    assert parse_chapter_id("2_3") == (2, 3)
    assert parse_chapter_id("") == (0, 0)
    assert parse_chapter_id("abc") == (0, 0)


def test_compare_chapter_id():
    assert compare_chapter_id("vol1_ch9", "vol2_ch1") < 0
    assert compare_chapter_id("vol2_ch1", "vol1_ch9") > 0
    assert compare_chapter_id("vol1_ch2", "vol1_ch1") > 0
    assert compare_chapter_id("vol1_ch1", "vol1_ch1") == 0


def test_build_chapter_id():
    assert build_chapter_id(3, 5) == "vol3_ch5"