# -*- coding: utf-8 -*-
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from unittest.mock import MagicMock, patch
from novel_writer.implementations.validation.consistency_reconciler import (
    ConsistencyReconciler, ReconcileResult,
)


class TestReconcileResult:
    def test_defaults(self):
        r = ReconcileResult()
        assert r.StagingCleaned == 0
        assert r.BakCleaned == 0
        assert r.SummariesRepaired == 0
        assert r.Errors == []

    def test_has_repairs_false(self):
        r = ReconcileResult()
        assert r.has_repairs is False

    def test_has_repairs_true(self):
        r = ReconcileResult()
        r.StagingCleaned = 1
        assert r.has_repairs is True
        r.StagingCleaned = 0
        r.TrackingOrphansCleared = 1
        assert r.has_repairs is True


class FakeProject:
    def __init__(self):
        self.dir = os.path.join(os.path.dirname(__file__), "fixtures")
        self.generated_dir = os.path.join(self.dir, "generated")
        self.tracking_dir = os.path.join(self.dir, "tracking")

    def guide(self, name):
        return MagicMock(data=MagicMock(return_value={}), set_all=MagicMock(), flush=MagicMock())

    def tracking(self, name):
        return MagicMock(data=MagicMock(return_value={}))

    def load_plan(self, entity):
        return []

    def load_chapter(self, cid):
        return None


class TestConsistencyReconciler:
    def test_reconcile_empty_project(self, tmp_path):
        project = MagicMock()
        project.generated_dir = str(tmp_path / "generated")
        project.tracking_dir = str(tmp_path / "tracking")
        project.dir = str(tmp_path)
        project.guide.return_value = MagicMock(
            data=MagicMock(return_value={}),
            set_all=MagicMock(),
            flush=MagicMock(),
        )
        project.tracking.return_value = MagicMock(data=MagicMock(return_value={}))
        project.load_plan.return_value = []
        project.load_chapter.return_value = None

        r = ConsistencyReconciler(project)
        result = r.reconcile()
        assert isinstance(result, ReconcileResult)
        assert result.has_repairs is False

    def test_clean_staging_and_backups_no_dir(self):
        project = MagicMock()
        project.generated_dir = "/nonexistent"
        r = ConsistencyReconciler(project)
        result = ReconcileResult()
        r.clean_staging_and_backups(result)
        assert result.StagingCleaned == 0
        assert result.BakCleaned == 0

    def test_validate_guides_integrity_no_dir(self):
        project = MagicMock()
        project.tracking_dir = "/nonexistent"
        r = ConsistencyReconciler(project)
        result = ReconcileResult()
        r.validate_guides_integrity(result)
        assert result.CorruptedGuides == []

    def test_extract_summary_from_head_short(self):
        text = "这是短文本。"
        result = ConsistencyReconciler._extract_summary_from_head(text)
        assert result == "这是短文本。"

    def test_extract_summary_from_head_empty(self):
        assert ConsistencyReconciler._extract_summary_from_head("") == ""

    def test_extract_summary_from_head_long(self):
        text = "这是第一句。" + "这是中间的内容。" * 60 + "这是最后一句。"
        result = ConsistencyReconciler._extract_summary_from_head(text)
        assert len(result) <= 500 + 3
        # truncated text should end with ellipsis or be the full 500-char region
        assert result.endswith("……") or len(result) <= 500

    def test_reconcile_generates_no_errors(self, tmp_path):
        project = MagicMock()
        project.generated_dir = str(tmp_path / "generated")
        project.tracking_dir = str(tmp_path / "tracking")
        project.dir = str(tmp_path)
        os.makedirs(project.generated_dir, exist_ok=True)
        os.makedirs(project.tracking_dir, exist_ok=True)

        guide_mock = MagicMock()
        guide_mock.data.return_value = {}
        guide_mock.set_all = MagicMock()
        guide_mock.flush = MagicMock()
        project.guide.return_value = guide_mock

        tracking_mock = MagicMock()
        tracking_mock.data.return_value = {}
        project.tracking.return_value = tracking_mock

        project.load_plan.return_value = []
        project.load_chapter.return_value = None

        r = ConsistencyReconciler(project)
        result = r.reconcile()
        assert len(result.Errors) == 0

    def test_clean_staging_renames(self, tmp_path):
        project = MagicMock()
        project.generated_dir = str(tmp_path)
        st = os.path.join(tmp_path, "test.md.staging")
        with open(st, "w") as f:
            f.write("content")
        r = ConsistencyReconciler(project)
        result = ReconcileResult()
        r.clean_staging_and_backups(result)
        assert result.StagingCleaned == 1
        assert os.path.exists(os.path.join(tmp_path, "test.md"))

    def test_clean_bak_when_final_exists(self, tmp_path):
        project = MagicMock()
        project.generated_dir = str(tmp_path)
        # both .bak and the final file exist
        with open(os.path.join(tmp_path, "test.md"), "w") as f:
            f.write("final")
        with open(os.path.join(tmp_path, "test.md.bak"), "w") as f:
            f.write("bak")
        r = ConsistencyReconciler(project)
        result = ReconcileResult()
        r.clean_staging_and_backups(result)
        assert result.BakCleaned == 1
        assert os.path.exists(os.path.join(tmp_path, "test.md"))
        assert not os.path.exists(os.path.join(tmp_path, "test.md.bak"))


# ---- 追加测试 ----

class TestConsistencyReconcilerNewMethods:
    def test_auto_archive_volume_if_needed(self, tmp_path):
        project = MagicMock()
        project.generated_dir = str(tmp_path / "generated")
        project.tracking_dir = str(tmp_path / "tracking")
        project.dir = str(tmp_path)
        os.makedirs(project.generated_dir, exist_ok=True)
        os.makedirs(project.tracking_dir, exist_ok=True)
        # Create a generated chapter
        with open(os.path.join(project.generated_dir, "vol1_ch1.md"), "w") as f:
            f.write("content")
        guide_mock = MagicMock()
        guide_mock.data.return_value = {"vol1_ch1": "summary"}
        guide_mock.set_all = MagicMock()
        guide_mock.flush = MagicMock()
        project.guide.return_value = guide_mock
        project.tracking.return_value = MagicMock(data=MagicMock(return_value={}))
        project.load_plan.return_value = []
        project.load_chapter.return_value = None

        r = ConsistencyReconciler(project)
        r._auto_archive_volume_if_needed(1)  # should not raise

    def test_read_head(self, tmp_path):
        file_path = os.path.join(tmp_path, "test.txt")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write("Hello World")
        import asyncio
        content = asyncio.run(ConsistencyReconciler._read_head(file_path, 5))
        assert content == "Hello"

    def test_read_head_not_found(self, tmp_path):
        import asyncio
        content = asyncio.run(ConsistencyReconciler._read_head(os.path.join(tmp_path, "nonexistent.txt")))
        assert content == ""

    def test_read_head_empty(self, tmp_path):
        file_path = os.path.join(tmp_path, "empty.txt")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write("")
        import asyncio
        content = asyncio.run(ConsistencyReconciler._read_head(file_path))
        assert content == ""