# -*- coding: utf-8 -*-
"""tests for chapter_summary_store.py"""
import sys, os, json, tempfile, shutil
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from unittest.mock import MagicMock, patch
from novel_writer.implementations.guides.chapter_summary_store import ChapterSummaryStore


@pytest.fixture
def project():
    tmpdir = tempfile.mkdtemp()
    p = MagicMock()
    p.dir = tmpdir
    yield p
    shutil.rmtree(tmpdir)


class TestChapterSummaryStore:
    def test_init(self, project):
        store = ChapterSummaryStore(project)
        assert store.project is project
        assert store.SUMMARY_GUARD_MAX_CHARS == 1500

    def test_set_and_get_summary(self, project):
        store = ChapterSummaryStore(project)
        store.set_summary("vol1_ch1", "Chapter one summary")
        assert store.get_summary("vol1_ch1") == "Chapter one summary"

    def test_get_nonexistent_summary(self, project):
        store = ChapterSummaryStore(project)
        assert store.get_summary("vol1_ch99") == ""

    def test_set_summary_truncates_long(self, project):
        store = ChapterSummaryStore(project)
        long_text = "A" * 2000
        store.set_summary("vol1_ch1", long_text)
        result = store.get_summary("vol1_ch1")
        assert len(result) == 1503  # 1500 + "..."
        assert result.endswith("...")

    def test_set_summary_empty(self, project):
        store = ChapterSummaryStore(project)
        store.set_summary("vol1_ch1", "")
        assert store.get_summary("vol1_ch1") == ""

    def test_set_summary_none(self, project):
        store = ChapterSummaryStore(project)
        store.set_summary("vol1_ch1", None)
        assert store.get_summary("vol1_ch1") == ""

    def test_remove_summary(self, project):
        store = ChapterSummaryStore(project)
        store.set_summary("vol1_ch1", "Some summary")
        store.remove_summary("vol1_ch1")
        assert store.get_summary("vol1_ch1") == ""

    def test_remove_nonexistent(self, project):
        store = ChapterSummaryStore(project)
        store.remove_summary("vol1_ch99")  # should not raise

    def test_volume_number_parsing(self, project):
        store = ChapterSummaryStore(project)
        assert store._volume_number("vol1_ch1") == 1
        assert store._volume_number("vol2_ch10") == 2
        assert store._volume_number("invalid") == 1

    def test_get_volume_summaries(self, project):
        store = ChapterSummaryStore(project)
        store.set_summary("vol1_ch1", "Sum1")
        store.set_summary("vol1_ch2", "Sum2")
        summaries = store.get_volume_summaries(1)
        assert summaries == {"vol1_ch1": "Sum1", "vol1_ch2": "Sum2"}

    def test_get_volume_summaries_empty(self, project):
        store = ChapterSummaryStore(project)
        assert store.get_volume_summaries(99) == {}

    def test_get_all_summaries(self, project):
        store = ChapterSummaryStore(project)
        store.set_summary("vol1_ch1", "Sum1")
        store.set_summary("vol2_ch1", "Sum2")
        all_s = store.get_all_summaries()
        assert all_s["vol1_ch1"] == "Sum1"
        assert all_s["vol2_ch1"] == "Sum2"

    def test_get_all_summaries_no_dir(self, project):
        store = ChapterSummaryStore(project)
        assert store.get_all_summaries() == {}

    def test_bulk_set(self, project):
        store = ChapterSummaryStore(project)
        store.bulk_set({"vol1_ch1": "S1", "vol1_ch2": "S2"})
        assert store.get_summary("vol1_ch1") == "S1"
        assert store.get_summary("vol1_ch2") == "S2"

    def test_bulk_set_empty(self, project):
        store = ChapterSummaryStore(project)
        store.bulk_set({})  # should not raise
        store.bulk_set(None)  # should not raise

    def test_bulk_set_overwrites_volume(self, project):
        store = ChapterSummaryStore(project)
        store.set_summary("vol1_ch1", "Old")
        store.bulk_set({"vol1_ch1": "New", "vol1_ch2": "S2"})
        assert store.get_summary("vol1_ch1") == "New"
        assert store.get_summary("vol1_ch2") == "S2"

    def test_invalidate_cache(self, project):
        store = ChapterSummaryStore(project)
        store.set_summary("vol1_ch1", "S1")
        assert store.get_summary("vol1_ch1") == "S1"
        store.invalidate_cache()
        assert store._volume_cache == {}

    def test_persistence_across_instances(self, project):
        store1 = ChapterSummaryStore(project)
        store1.set_summary("vol1_ch1", "Persistent")

        store2 = ChapterSummaryStore(project)
        assert store2.get_summary("vol1_ch1") == "Persistent"

    def test_multiple_volumes(self, project):
        store = ChapterSummaryStore(project)
        store.set_summary("vol1_ch1", "V1C1")
        store.set_summary("vol2_ch1", "V2C1")
        store.set_summary("vol3_ch1", "V3C1")
        assert store.get_volume_summaries(1) == {"vol1_ch1": "V1C1"}
        assert store.get_volume_summaries(2) == {"vol2_ch1": "V2C1"}
        assert store.get_volume_summaries(3) == {"vol3_ch1": "V3C1"}

    def test_summaries_dir(self, project):
        store = ChapterSummaryStore(project)
        expected = os.path.join(project.dir, "guides", "summaries")
        assert store._summaries_dir() == expected

    def test_volume_path(self, project):
        store = ChapterSummaryStore(project)
        expected = os.path.join(project.dir, "guides", "summaries", "vol5.json")
        assert store._volume_path(5) == expected