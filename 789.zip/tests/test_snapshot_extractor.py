# -*- coding: utf-8 -*-
"""tests for novel_writer/implementations/tracking/snapshot_extractor.py"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from unittest.mock import MagicMock, patch
from novel_writer.models import FactSnapshot
from novel_writer.implementations.tracking.snapshot_config import SnapshotConfig
from novel_writer.implementations.tracking.snapshot_extractor import SnapshotExtractor
from novel_writer.implementations.tracking import character_state_service


class Object:
    """Minimal attribute-bag for mock entries."""
    def __init__(self, **kw):
        self.__dict__.update(kw)


class MockGuide:
    def __init__(self, data):
        self._data = data or {}
    def data(self):
        return self._data


class MockProject:
    """Minimal project exposing only what SnapshotExtractor touches."""
    def __init__(self):
        self.dir = os.path.join("C:", "test", "proj")
        self._design = {}
        self._guides = {}
        self._tracking = {}
        self._plans = {}
        self._saved = None

    def load_design(self, entity):
        return self._design.get(entity, {})

    def load_plan(self, name):
        return self._plans.get(name, {})

    def guide(self, name):
        return MockGuide(self._guides.get(name, {}))

    def tracking(self, name):
        return MockGuide(self._tracking.get(name, {}))

    def save_design(self, name, data):
        self._saved = (name, data)


def make_extractor(project=None, config=None):
    return SnapshotExtractor(project or MockProject(), config or SnapshotConfig())


class TestStaticHelpers:
    def test_extract_hair(self):
        assert SnapshotExtractor._extract_hair("一头黑发") == "黑发"
        assert SnapshotExtractor._extract_hair("银色的长发") == "银发"
        assert SnapshotExtractor._extract_hair("") == ""
        assert SnapshotExtractor._extract_hair("无特征") == ""

    def test_importance_to_int(self):
        assert SnapshotExtractor._importance_to_int("Critical") == 4
        assert SnapshotExtractor._importance_to_int("important") == 3
        assert SnapshotExtractor._importance_to_int("") == 0
        assert SnapshotExtractor._importance_to_int(None) == 0
        assert SnapshotExtractor._importance_to_int(2) == 2

    def test_chapter_to_int(self):
        assert SnapshotExtractor._chapter_to_int("vol2_ch5") == 2
        assert SnapshotExtractor._chapter_to_int(9) == 9
        assert SnapshotExtractor._chapter_to_int("") == 0
        assert SnapshotExtractor._chapter_to_int("abc") == 0

    def test_split_abilities(self):
        assert SnapshotExtractor._split_abilities("炼体、筑基、金丹") == ["炼体", "筑基", "金丹"]
        assert SnapshotExtractor._split_abilities(["a", "b"]) == ["a", "b"]
        assert SnapshotExtractor._split_abilities("") == []
        assert SnapshotExtractor._split_abilities(None) == []

    def test_limit(self):
        assert SnapshotExtractor._limit([1, 2, 3, 4], 2) == [1, 2]
        assert SnapshotExtractor._limit([1, 2], 5) == [1, 2]

    def test_binary_search_state(self):
        hist = [{"Chapter": "vol1_ch1"}, {"Chapter": "vol1_ch3"}, {"Chapter": "vol2_ch1"}]
        assert SnapshotExtractor._binary_search_state(hist, "vol1_ch3")["Chapter"] == "vol1_ch3"
        assert SnapshotExtractor._binary_search_state(hist, "vol1_ch2")["Chapter"] == "vol1_ch1"
        assert SnapshotExtractor._binary_search_state(hist, "vol0_ch1") is None
        assert SnapshotExtractor._binary_search_state([], "x") is None
        # empty target returns last
        assert SnapshotExtractor._binary_search_state(hist, "")["Chapter"] == "vol2_ch1"


class TestVolumeHelpers:
    def test_get_volume_for_chapter(self):
        p = MockProject()
        p._plans["volumes"] = {"volumes": [
            {"VolumeNumber": 1, "StartChapter": 1, "EndChapter": 5},
            {"VolumeNumber": 2, "StartChapter": 6, "EndChapter": 10},
        ]}
        e = make_extractor(p)
        assert e._get_volume_for_chapter(7) == 2
        assert e._get_volume_for_chapter(3) == 1
        assert e._get_volume_for_chapter(99) == 1  # fallback

    def test_get_volume_for_chapter_with_no_plan(self):
        e = make_extractor(MockProject())
        assert e._get_volume_for_chapter(5) == 1

    def test_get_chapters_per_vol(self):
        p = MockProject()
        p._plans["volumes"] = {"volumes": [
            {"StartChapter": 1, "EndChapter": 5},
            {"StartChapter": 6, "EndChapter": 10},
        ]}
        e = make_extractor(p)
        assert e._get_chapters_per_vol() == 5

    def test_get_chapters_per_vol_default(self):
        e = make_extractor(MockProject())
        assert e._get_chapters_per_vol() == 20

    def test_is_active_in_recent_chapters(self):
        e = make_extractor(MockProject())
        e._prev_chapter_id = "vol1_ch5"
        # vol1_ch1 distance = (0*20)+(1-5) = -4, abs=4 <= 8 -> active
        assert e._is_active_in_recent_chapters("vol1_ch1", 8, 20) is True
        # vol1_ch4 distance = (0*20)+(4-5) = -1, abs=1 > 0 -> inactive
        assert e._is_active_in_recent_chapters("vol1_ch4", 0, 20) is False
        # last chapter newer than prev -> inactive
        assert e._is_active_in_recent_chapters("vol2_ch1", 8, 20) is False
        # empty chapter -> inactive
        assert e._is_active_in_recent_chapters("", 8, 20) is False


class TestApplyRelevanceLimit:
    def test_sort_foreshadowings_overdue_first(self):
        e = make_extractor(MockProject())
        fs = [
            Object(ForeshadowId="f1", IsOverdue=False, IsSetup=True, IsResolved=False),
            Object(ForeshadowId="f2", IsOverdue=True, IsSetup=False, IsResolved=False),
        ]
        snap = FactSnapshot(ForeshadowingStatus=fs)
        e._apply_relevance_limit(snap)
        assert snap.ForeshadowingStatus[0].ForeshadowId == "f2"

    def test_apply_limit_3tier(self):
        source = [
            Object(KnowerIds=["A"], LastChapter=1),
            Object(KnowerIds=[], LastChapter=5),
            Object(KnowerIds=["B"], LastChapter=2),
        ]
        out = SnapshotExtractor._apply_limit_3tier(
            source, max_inject=2, priority_ids={"B"},
            party_accessor=lambda s: s.KnowerIds,
            chapter_accessor=lambda s: s.LastChapter)
        assert len(out) == 2
        # B-related first, then highest chapter
        assert out[0] is source[2]


class TestExtract:
    def test_extract_returns_snapshot_with_characters(self):
        p = MockProject()
        p._tracking["character_state"] = {
            "c1": {"Name": "A",
                   "StateHistory": [{"Chapter": "vol1_ch1", "Level": "练气", "KeyEvent": "x"}]},
        }
        e = make_extractor(p)
        snap = e.extract("vol1_ch2", 2, prev_chapter_id="vol1_ch1")
        assert isinstance(snap, FactSnapshot)
        assert len(snap.CharacterStates) == 1
        c = snap.CharacterStates[0]
        assert c.CharacterId == "c1"
        assert c.Name == "A"
        assert c.Level == "练气"
        assert c.LastChapter == 1

    def test_extract_without_prev_generates_from_volume_map(self):
        p = MockProject()
        p._plans["volumes"] = {"volumes": [
            {"VolumeNumber": 1, "StartChapter": 1, "EndChapter": 5}]}
        p._tracking["character_state"] = {
            "c1": {"Name": "A",
                   "StateHistory": [{"Chapter": "vol1_ch1", "Level": "练气", "KeyEvent": "x"}]},
        }
        e = make_extractor(p)
        snap = e.extract("vol1_ch4", 4)
        assert len(snap.CharacterStates) == 1

    def test_extract_applies_inject_limits(self):
        p = MockProject()
        p._tracking["foreshadowing"] = {f"f{i}": {"Name": f"F{i}"} for i in range(10)}
        cfg = SnapshotConfig(SnapshotMaxForeshadowInject=3)
        e = make_extractor(p, cfg)
        snap = e.extract("vol1_ch2", 2, prev_chapter_id="vol1_ch1")
        assert len(snap.ForeshadowingStatus) <= 3

    def test_extract_conflict_progress_builds_last_event(self):
        p = MockProject()
        p._tracking["conflict_progress"] = {
            "cf1": {"Name": "C", "ProgressPoints": [
                {"Chapter": "vol1_ch1", "Event": "爆发"},
                {"Chapter": "vol1_ch2", "Event": "升级"},
            ]},
        }
        e = make_extractor(p)
        snap = e.extract("vol1_ch3", 3, prev_chapter_id="vol1_ch2")
        assert len(snap.ConflictProgress) == 1
        assert "升级" in snap.ConflictProgress[0].LastEvent
        # _chapter_to_int("vol1_ch2") = 1 (first digit), so LastChapter = 1
        assert snap.ConflictProgress[0].LastChapter == 1

    def test_extract_timeline_from_chapter_timeline(self):
        p = MockProject()
        p._tracking["timeline"] = {"ChapterTimeline": [
            {"ChapterId": "vol1_ch1", "TimePeriod": "白天", "KeyTimeEvent": "开始"},
        ]}
        e = make_extractor(p)
        snap = e.extract("vol1_ch2", 2, prev_chapter_id="vol1_ch1")
        assert len(snap.Timeline) == 1
        assert snap.Timeline[0].TimePeriod == "白天"


class TestExtractVolumeEnd:
    def test_extract_volume_end_no_truncation(self):
        p = MockProject()
        p._tracking["foreshadowing"] = {f"f{i}": {"Name": f"F{i}", "IsResolved": (i % 2 == 0)}
                                        for i in range(10)}
        e = make_extractor(p, SnapshotConfig(SnapshotMaxForeshadowInject=2))
        snap = e.extract_volume_end(1)
        assert len(snap.ForeshadowingStatus) == 10  # no limit at volume end

    def test_save_volume_snapshot_persists_archive(self):
        p = MockProject()
        p._tracking["character_state"] = {
            "c1": {"Name": "A", "StateHistory": [
                {"Chapter": "vol1_ch1", "Level": "练气", "KeyEvent": "x"}]},
        }
        e = make_extractor(p)
        snap = e.save_volume_snapshot(1)
        assert p._saved is not None
        assert p._saved[0] == "vol1_archive"
        assert isinstance(p._saved[1], dict)
        assert snap is not None


# ---- 追加测试：parse_tags / split_csv / has_relevant_party / importance_score / get_previous_chapter_id / get_last_chapter_of_volume / format_relationships ----

class TestNewStaticHelpers:
    def test_parse_tags(self):
        assert SnapshotExtractor.parse_tags("勇敢、善良、聪明") == ["勇敢", "善良", "聪明"]
        assert SnapshotExtractor.parse_tags("") == []
        assert SnapshotExtractor.parse_tags(None) == []

    def test_parse_tags_long(self):
        result = SnapshotExtractor.parse_tags("a" * 21)
        assert result == []

    def test_split_csv(self):
        assert SnapshotExtractor.split_csv("a,b,c") == ["a", "b", "c"]
        assert SnapshotExtractor.split_csv("a，b，c") == ["a", "b", "c"]
        assert SnapshotExtractor.split_csv("") == []
        assert SnapshotExtractor.split_csv("  ") == []

    def test_has_relevant_party(self):
        obj = Object(KnowerIds=["c1", "c2"])
        assert SnapshotExtractor.has_relevant_party(obj, {"c1"}, lambda s: s.KnowerIds) is True
        assert SnapshotExtractor.has_relevant_party(obj, {"c3"}, lambda s: s.KnowerIds) is False
        assert SnapshotExtractor.has_relevant_party(obj, set(), lambda s: s.KnowerIds) is False

    def test_importance_score_int(self):
        obj = Object(Importance=3)
        assert SnapshotExtractor.importance_score(obj) == 3

    def test_importance_score_str_critical(self):
        obj = Object(Importance="critical")
        assert SnapshotExtractor.importance_score(obj) == 3

    def test_importance_score_str_important(self):
        obj = Object(Importance="important")
        assert SnapshotExtractor.importance_score(obj) == 2

    def test_importance_score_main_storyline(self):
        obj = Object(Importance=1, Storyline="main")
        assert SnapshotExtractor.importance_score(obj) == 3

    def test_importance_score_fallback(self):
        obj = Object()
        assert SnapshotExtractor.importance_score(obj) == 1

    def test_get_previous_chapter_id(self):
        import novel_writer.implementations.tracking.snapshot_extractor as se_mod
        se_mod.parse_chapter_id = character_state_service.parse_chapter_id
        se_mod.build_chapter_id = character_state_service.build_chapter_id
        p = MockProject()
        e = make_extractor(p)
        with patch.object(character_state_service, 'parse_chapter_id', return_value=(2, 3)):
            with patch.object(character_state_service, 'build_chapter_id', return_value="vol2_ch2"):
                prev = e.get_previous_chapter_id("vol2_ch3")
                assert prev == "vol2_ch2"

    def test_get_previous_chapter_id_cn1(self):
        import novel_writer.implementations.tracking.snapshot_extractor as se_mod
        se_mod.parse_chapter_id = character_state_service.parse_chapter_id
        se_mod.build_chapter_id = character_state_service.build_chapter_id
        p = MockProject()
        e = make_extractor(p)
        def mock_get_last(vn):
            return 5 if vn == 1 else 0
        e.get_last_chapter_of_volume = mock_get_last
        with patch.object(character_state_service, 'parse_chapter_id', return_value=(2, 1)):
            with patch.object(character_state_service, 'build_chapter_id', return_value="vol1_ch5"):
                prev = e.get_previous_chapter_id("vol2_ch1")
                assert prev == "vol1_ch5"

    def test_get_previous_chapter_id_vol1_cn1(self):
        import novel_writer.implementations.tracking.snapshot_extractor as se_mod
        se_mod.parse_chapter_id = character_state_service.parse_chapter_id
        e = make_extractor(MockProject())
        with patch.object(character_state_service, 'parse_chapter_id', return_value=(1, 1)):
            prev = e.get_previous_chapter_id("vol1_ch1")
            assert prev == ""

    def test_get_previous_chapter_id_invalid(self):
        import novel_writer.implementations.tracking.snapshot_extractor as se_mod
        se_mod.parse_chapter_id = character_state_service.parse_chapter_id
        e = make_extractor(MockProject())
        with patch.object(character_state_service, 'parse_chapter_id', return_value=(0, 0)):
            assert e.get_previous_chapter_id("") == ""
            assert e.get_previous_chapter_id("abc") == ""

    def test_get_last_chapter_of_volume_no_dir(self):
        e = make_extractor(MockProject())
        assert e.get_last_chapter_of_volume(1) == 0

    def test_format_relationships(self):
        result = SnapshotExtractor.parse_tags("tag1,tag2")
        assert result == ["tag1", "tag2"]