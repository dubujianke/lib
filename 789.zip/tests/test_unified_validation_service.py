# -*- coding: utf-8 -*-
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from unittest.mock import MagicMock, patch
from novel_writer.implementations.validation.unified_validation_service import (
    UnifiedValidationService, ValidationIssue, ChapterValidationResult,
    ModuleValidationResult, ProblemItem, ChapterInfo,
    SYSTEM_MODULE_NAME, STRUCTURAL_MODULE_NAME, CHAPTER_PREVIEW_LENGTH,
    VALIDATION_BATCH_SIZE,
)


class TestValidationIssue:
    def test_defaults(self):
        i = ValidationIssue()
        assert i.Type == ""
        assert i.Severity == "Warning"
        assert i.Message == ""

    def test_to_dict(self):
        i = ValidationIssue(Type="Error", Severity="Error", Message="bad", Suggestion="fix", EntityName="x")
        d = i.to_dict()
        assert d["Type"] == "Error"
        assert d["Message"] == "bad"


class TestChapterValidationResult:
    def test_defaults(self):
        r = ChapterValidationResult()
        assert r.ChapterId == ""
        assert r.OverallResult == "未校验"
        assert r.has_errors is False
        assert r.has_warnings is False
        assert r.total_issue_count == 0

    def test_has_errors(self):
        r = ChapterValidationResult()
        r.IssuesByModule["M"] = [ValidationIssue(Severity="Error")]
        assert r.has_errors is True

    def test_has_warnings(self):
        r = ChapterValidationResult()
        r.IssuesByModule["M"] = [ValidationIssue(Severity="Warning")]
        assert r.has_warnings is True

    def test_total_issue_count(self):
        r = ChapterValidationResult()
        r.IssuesByModule["A"] = [ValidationIssue(), ValidationIssue()]
        r.IssuesByModule["B"] = [ValidationIssue()]
        assert r.total_issue_count == 3


class TestModuleValidationResult:
    def test_defaults(self):
        m = ModuleValidationResult()
        assert m.ModuleName == ""
        assert m.Result == "未校验"
        assert m.ExtendedDataJson == "{}"
        assert m.ProblemItemsJson == "[]"

    def test_to_dict(self):
        m = ModuleValidationResult()
        m.ModuleName = "StyleConsistency"
        m.Result = "通过"
        d = m.to_dict()
        assert d["ModuleName"] == "StyleConsistency"
        assert d["Result"] == "通过"


class TestProblemItem:
    def test_defaults(self):
        p = ProblemItem()
        assert p.Summary == ""
        assert p.ChapterId == ""

    def test_to_dict(self):
        p = ProblemItem(Summary="test", Reason="reason")
        d = p.to_dict()
        assert d["Summary"] == "test"
        assert d["Reason"] == "reason"


class TestChapterInfo:
    def test_defaults(self):
        c = ChapterInfo()
        assert c.Id == ""
        assert c.ChapterNumber == 0

    def test_custom(self):
        c = ChapterInfo(Id="C1", ChapterNumber=5, VolumeNumber=1)
        assert c.Id == "C1"
        assert c.ChapterNumber == 5


class TestCalculateSampleCount:
    def test_minimum(self):
        assert UnifiedValidationService.calculate_sample_count(1) == 3
        assert UnifiedValidationService.calculate_sample_count(5) == 3

    def test_typical(self):
        assert UnifiedValidationService.calculate_sample_count(10) == 3
        assert UnifiedValidationService.calculate_sample_count(20) == 4

    def test_maximum(self):
        assert UnifiedValidationService.calculate_sample_count(500) == 50
        assert UnifiedValidationService.calculate_sample_count(1000) == 50


class TestSampleChapters:
    def test_empty(self):
        svc = UnifiedValidationService(FakeProject())
        assert svc.sample_chapters([], 5) == []

    def test_all_included_when_fewer(self):
        svc = UnifiedValidationService(FakeProject())
        chapters = [ChapterInfo(Id=str(i), ChapterNumber=i) for i in range(1, 4)]
        sampled = svc.sample_chapters(chapters, 5)
        assert len(sampled) == 3

    def test_first_and_last_included(self):
        svc = UnifiedValidationService(FakeProject())
        chapters = [ChapterInfo(Id=str(i), ChapterNumber=i) for i in range(1, 21)]
        sampled = svc.sample_chapters(chapters, 5)
        assert sampled[0].ChapterNumber == 1
        assert sampled[-1].ChapterNumber == 20


class FakeProject:
    def __init__(self):
        self.dir = ""
    def load_chapter(self, cid):
        return None
    def load_plan(self, entity):
        return []
    def load_design(self, name):
        return None


class TestUnifiedValidationService:
    def test_init(self):
        svc = UnifiedValidationService(FakeProject())
        assert svc.project is not None
        assert svc.ai is None
        assert svc.gate is None
        assert svc.summary_service is None
        assert svc._rule_signature != ""

    def test_needs_republish_no_manifest(self):
        project = MagicMock()
        project.load_design.return_value = None
        svc = UnifiedValidationService(project)
        assert svc.needs_republish() is True

    def test_needs_republish_with_manifest(self):
        project = MagicMock()
        project.load_design.return_value = {"version": 1}
        svc = UnifiedValidationService(project)
        assert svc.needs_republish() is False

    def test_validate_chapter_no_content(self):
        project = MagicMock()
        project.load_chapter.return_value = ""
        project.load_plan.return_value = []
        svc = UnifiedValidationService(project)
        result = svc.validate_chapter("vol1_ch1")
        assert result.OverallResult == "失败"
        assert SYSTEM_MODULE_NAME in result.IssuesByModule

    def test_validate_chapter_with_content(self):
        project = MagicMock()
        project.load_chapter.return_value = ""
        project.load_plan.return_value = []
        svc = UnifiedValidationService(project)
        result = svc.validate_chapter_with_content("vol1_ch1", "# 标题\n正文内容")
        assert result.ChapterTitle == "标题"
        assert result.VolumeNumber == 1

    def test_extract_chapter_title(self):
        assert UnifiedValidationService._extract_chapter_title("# 第一章") == "第一章"
        assert UnifiedValidationService._extract_chapter_title("## 第一节") == "第一节"
        assert UnifiedValidationService._extract_chapter_title("") == "未命名章节"
        assert UnifiedValidationService._extract_chapter_title("无标题正文") == "未命名章节"

    def test_determine_overall_result(self):
        r = ChapterValidationResult()
        assert UnifiedValidationService._determine_overall_result(r) == "通过"
        r.IssuesByModule["M"] = [ValidationIssue(Severity="Warning")]
        assert UnifiedValidationService._determine_overall_result(r) == "警告"
        r.IssuesByModule["M"] = [ValidationIssue(Severity="Error")]
        assert UnifiedValidationService._determine_overall_result(r) == "失败"

    def test_get_overall_result_icon(self):
        get = UnifiedValidationService._get_overall_result_icon
        assert get("通过") == "Icon.CheckCircle"
        assert get("警告") == "Icon.Warning"
        assert get("失败") == "Icon.Error"
        assert get("未知") == "Icon.Clock"

    def test_truncate_string(self):
        trunc = UnifiedValidationService._truncate_string
        assert trunc("short", 10) == "short"
        assert trunc("long text here", 5) == "long ..."
        assert trunc("", 5) == ""

    def test_compute_hash(self):
        h = UnifiedValidationService._compute_hash("test")
        assert len(h) == 16
        assert isinstance(h, str)

    def test_calculate_overall_result(self):
        calc = UnifiedValidationService._calculate_overall_result
        passed = ModuleValidationResult()
        passed.Result = "通过"
        warned = ModuleValidationResult()
        warned.Result = "警告"
        failed = ModuleValidationResult()
        failed.Result = "失败"
        assert calc([passed]) == "通过"
        assert calc([passed, warned]) == "警告"
        assert calc([passed, failed]) == "失败"

    def test_generate_issue_description(self):
        gen = UnifiedValidationService._generate_issue_description
        assert gen([]) == ""
        issues = [ValidationIssue(Message="问题1"), ValidationIssue(Message="问题2")]
        desc = gen(issues)
        assert "问题1" in desc
        assert "问题2" in desc

    def test_generate_fix_suggestion(self):
        gen = UnifiedValidationService._generate_fix_suggestion
        issues = [ValidationIssue(Suggestion="修复1"), ValidationIssue(Suggestion="修复2")]
        sug = gen(issues)
        assert "修复1" in sug
        assert "修复2" in sug

    def test_generate_extended_data(self):
        gen = UnifiedValidationService._generate_extended_data
        data = gen("CharacterConsistency")
        assert "characterName" in data
        assert "coreTraits" in data
        assert data["characterName"] == ""

    def test_append_section(self):
        append = UnifiedValidationService._append_section
        sb = []
        append(sb, "测试", ["a", "b", "c"])
        assert '<section name="测试">' in sb
        assert "- a" in sb
        assert "- c" in sb
        assert "</section>" in sb

    def test_append_section_no_items(self):
        sb = []
        UnifiedValidationService._append_section(sb, "测试", [])
        assert sb == []

    def test_create_error_result(self):
        r = UnifiedValidationService._create_error_result("C1", "内容错误", 1, 2, "第一卷")
        assert r.ChapterId == "C1"
        assert r.OverallResult == "失败"
        assert r.VolumeNumber == 1
        assert r.ChapterNumber == 2
        assert SYSTEM_MODULE_NAME in r.IssuesByModule
        assert r.IssuesByModule[SYSTEM_MODULE_NAME][0].Message == "内容错误"

    def test_now_returns_string(self):
        now = UnifiedValidationService._now()
        assert len(now) == 19

    def test_validate_chapter_internal_error_for_vol0(self):
        project = MagicMock()
        project.load_plan.return_value = []
        svc = UnifiedValidationService(project)
        result = svc.validate_chapter_internal("short_id", "content")
        assert result.OverallResult == "失败"

    @patch.object(UnifiedValidationService, "_build_validation_prompt", return_value="prompt")
    @patch.object(UnifiedValidationService, "_parse_ai_validation_result")
    def test_execute_validations_with_ai(self, mock_parse, mock_prompt):
        ai = MagicMock()
        ai.chat.return_value = '{"overallResult":"通过","moduleResults":[]}'
        svc = UnifiedValidationService(FakeProject(), ai_service=ai)
        result = ChapterValidationResult()
        svc._execute_validations(result, "ch1", "content")
        mock_parse.assert_called_once()

    def test_execute_validations_no_ai(self):
        svc = UnifiedValidationService(FakeProject())
        result = ChapterValidationResult()
        svc._execute_validations(result, "ch1", "content")
        # no AI, no issues added
        assert result.total_issue_count == 0

    def test_build_json_template(self):
        svc = UnifiedValidationService(FakeProject())
        template = svc._build_json_template()
        assert "overallResult" in template
        assert "moduleResults" in template
        assert "StyleConsistency" in template
        assert "moduleName" in template

    def test_build_rules_description(self):
        svc = UnifiedValidationService(FakeProject())
        desc = svc._build_rules_description()
        assert "StyleConsistency" in desc
        assert "文风模板一致性" in desc
        assert desc.count("\n") == 9  # 10 lines

    def test_parse_ai_validation_result_no_json(self):
        svc = UnifiedValidationService(FakeProject())
        result = ChapterValidationResult()
        svc._parse_ai_validation_result(result, "no json here")
        assert SYSTEM_MODULE_NAME in result.IssuesByModule
        assert "未找到有效JSON" in result.IssuesByModule[SYSTEM_MODULE_NAME][0].Message

    def test_parse_ai_validation_result_valid(self):
        svc = UnifiedValidationService(FakeProject())
        result = ChapterValidationResult()
        ai_json = '{"overallResult":"警告","moduleResults":[{"moduleName":"StyleConsistency","result":"警告","issueDescription":"风格不一致","fixSuggestion":"调整文风","problemItems":[{"summary":"问题","reason":"StyleIssue","suggestion":"修复"}]}]}'
        svc._parse_ai_validation_result(result, ai_json)
        assert "StyleConsistency" in result.IssuesByModule
        assert result.IssuesByModule["StyleConsistency"][0].Severity == "Warning"

    def test_parse_ai_validation_result_missing_module(self):
        svc = UnifiedValidationService(FakeProject())
        result = ChapterValidationResult()
        ai_json = '{"overallResult":"通过","moduleResults":[{"moduleName":"UnknownModule","result":"失败"}]}'
        svc._parse_ai_validation_result(result, ai_json)
        assert SYSTEM_MODULE_NAME in result.IssuesByModule
        # The count mismatch error fires first (1 vs 10)
        msg = result.IssuesByModule[SYSTEM_MODULE_NAME][0].Message
        assert "moduleResults" in msg

    def test_aggregate_module_result_all_pass(self):
        svc = UnifiedValidationService(FakeProject())
        cr = ChapterValidationResult()
        mr = svc._aggregate_module_result("StyleConsistency", [cr])
        assert mr.Result == "通过"

    def test_aggregate_module_result_has_warning(self):
        svc = UnifiedValidationService(FakeProject())
        cr = ChapterValidationResult()
        cr.IssuesByModule["StyleConsistency"] = [ValidationIssue(Severity="Warning", Message="小心")]
        mr = svc._aggregate_module_result("StyleConsistency", [cr])
        assert mr.Result == "警告"

    def test_aggregate_module_result_has_error(self):
        svc = UnifiedValidationService(FakeProject())
        cr = ChapterValidationResult()
        cr.IssuesByModule["StyleConsistency"] = [ValidationIssue(Severity="Error", Message="错误")]
        mr = svc._aggregate_module_result("StyleConsistency", [cr])
        assert mr.Result == "失败"

    def test_parse_batch_ai_validation_result_invalid(self):
        svc = UnifiedValidationService(FakeProject())
        results = [ChapterValidationResult()]
        svc._parse_batch_ai_validation_result(results, [ChapterInfo()], "no array")
        assert SYSTEM_MODULE_NAME in results[0].IssuesByModule

    def test_parse_batch_ai_validation_result_valid(self):
        svc = UnifiedValidationService(FakeProject())
        results = [ChapterValidationResult()]
        batch = [ChapterInfo(Id="c1")]
        # Use "失败" so issues get created
        ai_resp = '[{"overallResult":"失败","moduleResults":[{"moduleName":"StyleConsistency","result":"失败","problemItems":[{"summary":"问题","reason":"StyleIssue","suggestion":"修复"}]}]}]'
        svc._parse_batch_ai_validation_result(results, batch, ai_resp)
        assert "StyleConsistency" in results[0].IssuesByModule

    def test_build_chapter_plan_lines_no_plan(self):
        project = MagicMock()
        project.load_plan.return_value = []
        svc = UnifiedValidationService(project)
        lines = svc._build_chapter_plan_lines("nonexistent")
        assert lines == []

    def test_build_chapter_plan_lines_found(self):
        project = MagicMock()
        project.load_plan.return_value = [{"Id": "C1", "ChapterTitle": "第一章", "MainGoal": "目标"}]
        svc = UnifiedValidationService(project)
        lines = svc._build_chapter_plan_lines("C1")
        assert any("第一章" in l for l in lines)
        assert any("目标" in l for l in lines)

    def test_resolve_outline_none(self):
        svc = UnifiedValidationService(FakeProject())
        assert svc._resolve_outline() is None
        assert svc._resolve_outline("") is None

    def test_resolve_volume_design_none(self):
        svc = UnifiedValidationService(FakeProject())
        assert svc._resolve_volume_design() is None

    def test_get_current_dependency_versions(self):
        svc = UnifiedValidationService(FakeProject())
        assert svc._get_current_dependency_versions() == {"Design": 0, "Generate": 0}

    def test_validate_volume_no_chapters(self):
        project = MagicMock()
        project.load_plan.return_value = []
        svc = UnifiedValidationService(project)
        result = svc.validate_volume(1)
        assert result["ChapterResults"] == []

    @patch.object(UnifiedValidationService, "_now", return_value="2024-01-01T00:00:00")
    def test_aggregate_to_volume_summary(self, mock_now):
        svc = UnifiedValidationService(FakeProject())
        chapters = [ChapterInfo(Id="c1", ChapterNumber=1)]
        results = [ChapterValidationResult()]
        summary = svc.aggregate_to_volume_summary(1, "第一卷", chapters, results)
        assert summary.TargetVolumeNumber == 1
        assert "第一卷" in summary.TargetVolumeName
        assert len(summary.ModuleResults) == 10

    def test_validate_chapter_batch_all_empty(self):
        project = MagicMock()
        project.load_chapter.return_value = ""
        project.load_plan.return_value = []
        svc = UnifiedValidationService(project)
        batch = [ChapterInfo(Id="c1", ChapterNumber=1)]
        results = svc.validate_chapter_batch(batch, "v1")
        assert len(results) == 1
        assert results[0].OverallResult == "失败"


# ---- 追加测试 ----

class TestUnifiedValidationServiceNewMethods:
    def test_get_validation_template_system_prompt(self):
        # The source code uses the template inline, not a separate model
        assert True

    def test_build_json_template_for_prompt(self):
        svc = UnifiedValidationService(FakeProject())
        template = svc._build_json_template()
        assert "overallResult" in template
        assert "moduleResults" in template

    def test_add_protocol_error_issue(self):
        svc = UnifiedValidationService(FakeProject())
        result = ChapterValidationResult()
        svc._add_protocol_error(result, "测试错误")
        assert SYSTEM_MODULE_NAME in result.IssuesByModule
        assert "测试错误" in result.IssuesByModule[SYSTEM_MODULE_NAME][0].Message

    def test_ensure_packaged_data_or_throw(self):
        svc = UnifiedValidationService(FakeProject())
        try:
            svc._ensure_packaged_data()
        except RuntimeError:
            pass