# -*- coding: utf-8 -*-
"""ForeshadowingStatusService 单元测试 — 对标 4.1.1 ForeshadowingStatusService.cs"""
import sys
import os
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock

from novel_writer.implementations.tracking.foreshadowing_status_service import (
    ForeshadowingStatusService,
)


class FakeStore:
    def __init__(self):
        self._data = {}

    def data(self):
        return self._data

    def set_all(self, data):
        self._data = data


class FakeProject:
    def __init__(self, **stores):
        self.dir = tempfile.mkdtemp(prefix="test_foreshadow_")
        self._stores = dict(stores)
        self.plan = {}

    def tracking(self, name):
        return self._stores.setdefault(name, FakeStore())

    def load_plan(self, entity):
        return self.plan.get(entity, {})


@pytest.fixture
def service():
    store = FakeStore()
    project = FakeProject(foreshadowing=store)
    return ForeshadowingStatusService(project), project, store


# =====================================================================
# get_status（查询伏笔状态）（通过 store.data 验证）
# =====================================================================

def test_get_status_returns_entry(service):
    svc, _, store = service
    svc.mark_as_setup("FS1", "vol1_ch1")
    entry = store.data()["FS1"]
    assert entry["IsSetup"] is True
    assert entry["ActualSetupChapter"] == "vol1_ch1"


def test_get_status_missing_key_raises_keyerror(service):
    svc, _, store = service
    assert "NOPE" not in store.data()


# =====================================================================
# set_status（标记/更新伏笔状态）
# =====================================================================

def test_mark_as_setup_creates_new_entry(service):
    svc, _, store = service
    svc.mark_as_setup("FS1", "vol1_ch1")
    assert store.data()["FS1"]["IsSetup"] is True


def test_mark_as_resolved_sets_resolved_and_clears_overdue(service):
    svc, _, store = service
    svc.mark_as_setup("FS1", "vol1_ch1")
    svc.mark_as_resolved("FS1", "vol2_ch5")
    entry = store.data()["FS1"]
    assert entry["IsResolved"] is True
    assert entry["IsOverdue"] is False
    assert entry["ActualPayoffChapter"] == "vol2_ch5"


def test_mark_as_setup_on_existing_keeps_others(service):
    svc, _, store = service
    svc.mark_as_resolved("FS1", "vol2_ch5")
    svc.mark_as_setup("FS1", "vol1_ch1")
    assert store.data()["FS1"]["IsSetup"] is True
    assert store.data()["FS1"]["IsResolved"] is True


# =====================================================================
# _get_latest_existing_chapter_id（从章节规划取最新章）
# =====================================================================

def test_get_latest_existing_chapter_id_from_plan(service):
    svc, project, _ = service
    project.plan["chapters"] = {"chapters": [
        {"VolumeNumber": 1, "ChapterNumber": 3},
        {"VolumeNumber": 2, "ChapterNumber": 1},
    ]}
    latest = ForeshadowingStatusService._get_latest_existing_chapter_id(project)
    assert latest == "vol2_ch1"


def test_get_latest_existing_chapter_id_empty_plan(service):
    svc, project, _ = service
    project.plan["chapters"] = {"chapters": []}
    assert ForeshadowingStatusService._get_latest_existing_chapter_id(project) == ""


def test_get_latest_existing_chapter_id_exception(service):
    svc, project, _ = service
    project.load_plan = MagicMock(side_effect=Exception("boom"))
    assert ForeshadowingStatusService._get_latest_existing_chapter_id(project) == ""


# =====================================================================
# get_latest_existing_chapter_id_from_files（从 .md 文件取最新章）
# =====================================================================

def test_get_latest_existing_chapter_id_from_files(service):
    svc, project, _ = service
    os.makedirs(os.path.join(project.dir, "chapters"), exist_ok=True)
    for name in ["vol2_ch1", "vol1_ch9", "readme"]:
        with open(os.path.join(project.dir, "chapters", f"{name}.md"), "w") as f:
            f.write("x")
    assert svc.get_latest_existing_chapter_id_from_files(project) == "vol2_ch1"


def test_get_latest_existing_chapter_id_from_files_no_dir(service):
    svc, project, _ = service
    assert svc.get_latest_existing_chapter_id_from_files(project) == ""


def test_get_latest_existing_chapter_id_from_files_empty_dir(service):
    svc, project, _ = service
    os.makedirs(os.path.join(project.dir, "chapters"), exist_ok=True)
    assert svc.get_latest_existing_chapter_id_from_files(project) == ""


# =====================================================================
# get_tier_stats（分 Tier 统计）
# =====================================================================

def test_get_statistics_counts_by_tier(service):
    svc, _, store = service
    svc.mark_as_setup("FS1", "vol1_ch1")
    store.data()["FS2"] = {"Name": "f", "Tier": "Tier-2", "IsSetup": True, "IsResolved": True,
                           "IsOverdue": False, "ActualSetupChapter": "", "ActualPayoffChapter": ""}
    stats = svc.get_statistics()
    assert stats["TotalCount"] == 2
    assert stats["SetupCount"] == 2
    assert stats["ResolvedCount"] == 1


def test_get_statistics_tier_stats_breakdown(service):
    svc, _, store = service
    svc.mark_as_setup("FS1", "vol1_ch1")
    store.data()["FS1"]["Tier"] = "Tier-1"
    stats = svc.get_statistics()
    assert stats["Tier1Stats"]["Total"] == 1
    assert stats["Tier3Stats"]["Total"] == 0


def test_get_statistics_empty(service):
    svc, _, _ = service
    stats = svc.get_statistics()
    assert stats["TotalCount"] == 0
    assert stats["Tier1Stats"]["Total"] == 0


# =====================================================================
# refresh_overdue_status（逾期判定）
# =====================================================================

def test_refresh_overdue_status_marks_overdue(service):
    svc, _, store = service
    svc.mark_as_setup("FS1", "vol1_ch1")
    store.data()["FS1"]["ExpectedPayoffChapter"] = "vol1_ch5"
    svc.refresh_overdue_status("vol1_ch9")
    assert store.data()["FS1"]["IsOverdue"] is True


def test_refresh_overdue_status_not_overdue_when_before(service):
    svc, _, store = service
    svc.mark_as_setup("FS1", "vol1_ch1")
    store.data()["FS1"]["ExpectedPayoffChapter"] = "vol2_ch1"
    svc.refresh_overdue_status("vol1_ch9")
    assert store.data()["FS1"]["IsOverdue"] is False


def test_refresh_overdue_status_invalid_current_chapter(service):
    svc, _, store = service
    svc.mark_as_setup("FS1", "vol1_ch1")
    store.data()["FS1"]["ExpectedPayoffChapter"] = "vol1_ch5"
    svc.refresh_overdue_status("")  # parse 失败直接返回
    assert store.data()["FS1"]["IsOverdue"] is False