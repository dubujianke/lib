# -*- coding: utf-8 -*-
"""tests for content_polisher.py"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from novel_writer.implementations.generation.content_polisher import (
    ContentPolisher, _find_changes_start, POLISH_SYSTEM,
)


class MockAI:
    def chat(self, system, user, category=""):
        return "润色后的内容。"


@pytest.fixture
def polisher():
    return ContentPolisher(MockAI())


def test_find_changes_start_xml():
    text = "正文内容\n<chapter_changes>\n{}</chapter_changes>"
    assert _find_changes_start(text) == text.find("<chapter_changes>")


def test_find_changes_start_marker():
    text = "正文内容\n---CHANGES---\n{}"
    assert _find_changes_start(text) == text.find("---CHANGES---")


def test_find_changes_start_none():
    assert _find_changes_start("纯文本") == -1


def test_content_polisher_init(polisher):
    assert polisher is not None


def test_polish_short_content(polisher):
    result = polisher.polish("短文本", verbose=False)
    assert result[0] == "短文本"  # too short, returns original


def test_polish_medium_content(polisher):
    content = "他拉下电闸，锁上门，掏出手机。她笑了笑，点点头。"
    result = polisher.polish(content, verbose=False)
    assert len(result) == 3


def test_polish_with_changes_section(polisher):
    content = "正文内容。\n\n<chapter_changes>{}</chapter_changes>"
    result = polisher.polish(content, verbose=False)
    assert len(result) == 3


def test_polish_local_only_mode(polisher):
    content = "这是一段需要润色的正文内容。他拉下电闸，锁上门，掏出手机。" * 5
    result = polisher.polish(content, polish_model=0, verbose=False)
    assert len(result) == 3
    # local-only mode should return content without AI call


def test_polish_system_prompt_contains_word_hint():
    assert "{WORD_COUNT_HINT}" in POLISH_SYSTEM