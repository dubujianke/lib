# -*- coding: utf-8 -*-
"""tests for chapter_key_event_store.py"""
import sys, os, json, tempfile, shutil
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock, patch
from novel_writer.implementations.guides.chapter_key_event_store import ChapterKeyEventStore


class MockEntry:
    def __init__(self, chapter_id, volume_number=1, chapter_number=1):
        self.ChapterId = chapter_id
        self.VolumeNumber = volume_number
        self.ChapterNumber = chapter_number
    def to_dict(self):
        return {"ChapterId": self.ChapterId, "VolumeNumber": self.VolumeNumber, "ChapterNumber": self.ChapterNumber}


class MockProject:
    def __init__(self):
        self.dir = tempfile.mkdtemp(prefix="test_cke_")
    def __del__(self):
        shutil.rmtree(self.dir, ignore_errors=True)


@pytest.fixture
def project():
    p = MockProject()
    yield p
    shutil.rmtree(p.dir, ignore_errors=True)


@pytest.fixture
def store(project):
    return ChapterKeyEventStore(project)


# --- upsert ---

def test_upsert_normal(store, project):
    entry = MockEntry("ch1", 1, 1)
    store.upsert(1, entry)
    path = os.path.join(store._keyevents_dir(), "vol1.jsonl")
    assert os.path.exists(path)
    with open(path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    assert len(lines) == 1
    data = json.loads(lines[0].strip())
    assert data["ChapterId"] == "ch1"


def test_upsert_duplicate_replaces(store, project):
    entry1 = MockEntry("ch1", 1, 1)
    entry2 = MockEntry("ch1", 1, 2)
    store.upsert(1, entry1)
    store.upsert(1, entry2)
    path = os.path.join(store._keyevents_dir(), "vol1.jsonl")
    with open(path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    assert len(lines) == 1
    data = json.loads(lines[0].strip())
    assert data["ChapterNumber"] == 2


def test_upsert_multi_entries(store, project):
    store.upsert(1, MockEntry("ch1", 1, 1))
    store.upsert(1, MockEntry("ch2", 1, 2))
    path = os.path.join(store._keyevents_dir(), "vol1.jsonl")
    with open(path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    assert len(lines) == 2


def test_upsert_invalid_number(store):
    store.upsert(0, MockEntry("ch1"))
    assert not os.path.exists(os.path.join(store._keyevents_dir(), "vol0.jsonl"))


def test_upsert_none_entry(store):
    store.upsert(1, None)
    assert not os.path.exists(os.path.join(store._keyevents_dir(), "vol1.jsonl"))


# --- get_previous_key_events ---

def test_get_previous_key_events_normal(store, project):
    store.upsert(1, MockEntry("ch1", 1, 1))
    store.upsert(2, MockEntry("ch2", 2, 1))
    result = store.get_previous_key_events(3, max_volumes=5, max_entries_per_volume=30)
    assert len(result) == 2


def test_get_previous_key_events_volume_one(store):
    result = store.get_previous_key_events(1)
    assert result == []


def test_get_previous_key_events_no_previous(store):
    store.upsert(1, MockEntry("ch1", 1, 1))
    result = store.get_previous_key_events(1)
    assert result == []


# --- invalidate_cache (no-op, no cache in this class) ---


# --- _load_volume ---

def test_load_volume_nonexistent(store):
    result = store._load_volume(999)
    assert result == []


def test_load_volume_corrupted_file(store, project):
    path = os.path.join(store._keyevents_dir(), "vol1.jsonl")
    os.makedirs(store._keyevents_dir(), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("not json\n")
    result = store._load_volume(1)
    assert result == []