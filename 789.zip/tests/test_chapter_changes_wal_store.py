# -*- coding: utf-8 -*-
"""tests for chapter_changes_wal_store.py"""
import sys, os, json, tempfile, shutil
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock, patch
from novel_writer.implementations.guides.chapter_changes_wal_store import ChapterChangesWalStore


class MockChanges:
    def __init__(self, data=None):
        self.data = data or {"key": "value"}
    def to_dict(self):
        return self.data


class MockProject:
    def __init__(self):
        self.dir = tempfile.mkdtemp(prefix="test_wal_")
    def __del__(self):
        shutil.rmtree(self.dir, ignore_errors=True)


@pytest.fixture
def project():
    p = MockProject()
    yield p
    shutil.rmtree(p.dir, ignore_errors=True)


@pytest.fixture
def store(project):
    return ChapterChangesWalStore(project)


# --- 路径方法 ---

def test_get_wal_dir(store):
    path = store.get_wal_dir()
    assert "changes_wal" in path


def test_get_file_path(store):
    path = store.get_file_path("ch1")
    assert "ch1.json" in path


# --- write ---

def test_write_normal(store, project):
    changes = MockChanges({"chapter": 1, "diff": "abc"})
    store.write("ch1", changes)
    path = store.get_file_path("ch1")
    assert os.path.exists(path)
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    assert data["chapter"] == 1
    assert data["diff"] == "abc"


def test_write_empty_chapter_id(store):
    changes = MockChanges()
    store.write("", changes)  # should not crash, creates file with empty name
    path = store.get_file_path("")
    assert os.path.exists(path)


# --- try_read ---

def test_try_read_exists(store, project):
    changes = MockChanges({"id": "ch1"})
    store.write("ch1", changes)
    result = store.try_read("ch1")
    assert result is not None


def test_try_read_not_exists(store):
    result = store.try_read("nonexistent")
    assert result is None


def test_try_read_corrupted_file(store, project):
    wal_dir = store.get_wal_dir()
    os.makedirs(wal_dir, exist_ok=True)
    path = store.get_file_path("corrupted")
    with open(path, "w", encoding="utf-8") as f:
        f.write("not json")
    result = store.try_read("corrupted")
    assert result is None


# --- delete ---

def test_delete_normal(store, project):
    changes = MockChanges()
    store.write("ch1", changes)
    path = store.get_file_path("ch1")
    assert os.path.exists(path)
    store.delete("ch1")
    assert not os.path.exists(path)


def test_delete_nonexistent(store):
    store.delete("nonexistent")  # should not crash


# --- get_all_chapter_ids ---

def test_get_all_chapter_ids(store, project):
    store.write("ch1", MockChanges())
    store.write("ch2", MockChanges())
    ids = store.get_all_chapter_ids()
    assert sorted(ids) == ["ch1", "ch2"]


def test_get_all_chapter_ids_empty(store):
    assert store.get_all_chapter_ids() == []


# --- cleanup_orphan_tmp ---

def test_cleanup_orphan_tmp(store, project):
    wal_dir = store.get_wal_dir()
    os.makedirs(wal_dir, exist_ok=True)
    tmp_path = os.path.join(wal_dir, "orphan.tmp")
    with open(tmp_path, "w") as f:
        f.write("tmp")
    good_path = os.path.join(wal_dir, "good.json")
    with open(good_path, "w") as f:
        f.write("{}")
    store.cleanup_orphan_tmp()
    assert not os.path.exists(tmp_path)
    assert os.path.exists(good_path)


def test_cleanup_orphan_tmp_no_dir(store):
    store.cleanup_orphan_tmp()  # should not crash