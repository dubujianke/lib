# -*- coding: utf-8 -*-
"""tests for plot_points_index_service.py"""
import sys, os, json, tempfile, shutil
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock, patch
from novel_writer.implementations.indexing.plot_points_index_service import PlotPointsIndexService


class MockChange:
    def __init__(self):
        self.Keywords = ["关键"]
        self.Context = "上下文"
        self.InvolvedCharacters = ["c1"]
        self.Importance = 5
        self.Storyline = "主线"
        self.CausedBy = "caused_by"


class MockProject:
    def __init__(self):
        self.dir = tempfile.mkdtemp(prefix="test_ppi_")


@pytest.fixture
def project():
    p = MockProject()
    yield p
    shutil.rmtree(p.dir, ignore_errors=True)


@pytest.fixture(autouse=True)
def mock_short_id():
    with patch("novel_writer.models.common.short_id", return_value="D000000000001"):
        yield


@pytest.fixture
def service(project):
    return PlotPointsIndexService(project)


# --- 路径方法 ---

def test_get_plot_points_dir(service):
    path = service._dir()
    assert "plot_points" in path


def test_get_volume_file_path(service):
    path = service._path(3)
    assert "vol3.json" in path


# --- add_plot_point ---

def test_add_plot_point(service, project):
    service.add_plot_point("vol1_ch1", MockChange())
    entries = service.get_volume_entries(1)
    assert len(entries) == 1
    assert entries[0]["Chapter"] == "vol1_ch1"
    assert entries[0]["Keywords"] == ["关键"]


def test_add_plot_point_multiple(service, project):
    c1 = MockChange()
    c1.Keywords = ["事件1"]
    c2 = MockChange()
    c2.Keywords = ["事件2"]
    service.add_plot_point("vol1_ch1", c1)
    service.add_plot_point("vol1_ch2", c2)
    entries = service.get_volume_entries(1)
    assert len(entries) == 2


# --- remove_chapter_data ---

def test_remove_chapter_data(service, project):
    c1 = MockChange()
    c2 = MockChange()
    service.add_plot_point("vol1_ch1", c1)
    service.add_plot_point("vol1_ch2", c2)
    service.remove_chapter_data("vol1_ch1")
    entries = service.get_volume_entries(1)
    assert len(entries) == 1
    assert entries[0]["Chapter"] == "vol1_ch2"


def test_remove_chapter_data_nonexistent(service):
    service.remove_chapter_data("nonexistent")  # should not crash


# --- search_recent ---

def test_search_recent(service, project):
    c1 = MockChange()
    c1.InvolvedCharacters = ["c1"]
    c2 = MockChange()
    c2.InvolvedCharacters = ["c2"]
    service.add_plot_point("vol1_ch1", c1)
    service.add_plot_point("vol1_ch2", c2)
    result = service.search_recent("vol1_ch3", ["c1"], [])
    assert len(result) == 1
    assert result[0]["InvolvedCharacters"] == ["c1"]


def test_search_recent_no_match(service):
    result = service.search_recent("vol1_ch1", ["nonexistent"], [])
    assert result == []


def test_search_recent_empty_current(service):
    result = service.search_recent("", [], [])
    assert result == []


# --- get_existing_volume_numbers ---

def test_get_existing_volume_numbers(service, project):
    service.add_plot_point("vol1_ch1", MockChange())
    service.add_plot_point("vol2_ch1", MockChange())
    nums = service.get_existing_volume_numbers()
    assert sorted(nums) == [1, 2]


def test_get_existing_volume_numbers_empty(service):
    assert service.get_existing_volume_numbers() == []


# --- set_volume_entries ---

def test_set_volume_entries(service, project):
    entries = [{"Chapter": "vol1_ch1", "Id": "e1"}]
    service.set_volume_entries(1, entries)
    loaded = service.get_volume_entries(1)
    assert len(loaded) == 1
    assert loaded[0]["Id"] == "e1"


# --- invalidate_cache ---

def test_invalidate_cache(service, project):
    service.add_plot_point("vol1_ch1", MockChange())
    assert 1 in service._volume_cache
    service.invalidate_cache()
    assert service._volume_cache == {}


def test_invalidate_cache_then_reload(service, project):
    service.add_plot_point("vol1_ch1", MockChange())
    service.invalidate_cache()
    entries = service.get_volume_entries(1)
    assert len(entries) == 1