# -*- coding: utf-8 -*-
"""tests for content_generation_callback.py"""
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from novel_writer.implementations.generation.content_generation_callback import (
    ContentGenerationCallback,
    ServiceLocator,
    StoragePathHelper,
    ChunkKey,
    EmbeddingMode,
)


# =============================================================================
# _parse_chapter_id (static)
# =============================================================================

class TestParseChapterId:
    def test_normal(self):
        result = ContentGenerationCallback._parse_chapter_id("1_3")
        assert result == {"volume_number": 1, "chapter_number": 3}

    def test_multi_digit(self):
        result = ContentGenerationCallback._parse_chapter_id("12_345")
        assert result == {"volume_number": 12, "chapter_number": 345}

    def test_invalid_format_no_underscore(self):
        assert ContentGenerationCallback._parse_chapter_id("abc") is None

    def test_invalid_format_non_numeric(self):
        assert ContentGenerationCallback._parse_chapter_id("a_b") is None

    def test_empty_string(self):
        assert ContentGenerationCallback._parse_chapter_id("") is None


# =============================================================================
# _strip_leading_headings (static)
# =============================================================================

class TestStripLeadingHeadings:
    def test_no_headings(self):
        text = "这是正文内容。\n第二行。"
        assert ContentGenerationCallback._strip_leading_headings(text) == text

    def test_strip_markdown_heading(self):
        text = "# 第一章\n\n这是正文。"
        assert ContentGenerationCallback._strip_leading_headings(text) == "这是正文。"

    def test_strip_chinese_heading(self):
        text = "第一章 标题\n\n正文内容。"
        assert ContentGenerationCallback._strip_leading_headings(text) == "正文内容。"

    def test_strip_multiple_headings(self):
        text = "# 序章\n\n## 第一节\n\n正文。"
        assert ContentGenerationCallback._strip_leading_headings(text) == "正文。"

    def test_empty_content(self):
        assert ContentGenerationCallback._strip_leading_headings("") == ""

    def test_only_headings(self):
        text = "# 第一章\n## 第一节\n"
        assert ContentGenerationCallback._strip_leading_headings(text) == ""

    def test_heading_with_colon(self):
        text = "第一章：测试\n\n正文"
        assert ContentGenerationCallback._strip_leading_headings(text) == "正文"

    def test_heading_with_spaces(self):
        text = "第一章   测试\n\n正文"
        assert ContentGenerationCallback._strip_leading_headings(text) == "正文"


# =============================================================================
# _build_canonical_title (static)
# =============================================================================

class TestBuildCanonicalTitle:
    def test_with_title(self):
        result = ContentGenerationCallback._build_canonical_title("1_3", "我的标题")
        assert result == "第3章 我的标题"

    def test_without_title(self):
        result = ContentGenerationCallback._build_canonical_title("1_3", "")
        assert result == "第3章"

    def test_fallback_to_id(self):
        result = ContentGenerationCallback._build_canonical_title("invalid", "")
        assert result == "invalid"

    def test_with_title_volume_0(self):
        # chapter_number is 0, so no prefix is added
        result = ContentGenerationCallback._build_canonical_title("0_0", "序章")
        assert result == "序章"


# =============================================================================
# _is_high_importance (static)
# =============================================================================

class TestIsHighImportance:
    def test_critical(self):
        assert ContentGenerationCallback._is_high_importance("critical") is True

    def test_important(self):
        assert ContentGenerationCallback._is_high_importance("important") is True

    def test_case_insensitive(self):
        assert ContentGenerationCallback._is_high_importance("Critical") is True
        assert ContentGenerationCallback._is_high_importance("IMPORTANT") is True

    def test_normal(self):
        assert ContentGenerationCallback._is_high_importance("normal") is False

    def test_none(self):
        assert ContentGenerationCallback._is_high_importance(None) is False

    def test_empty(self):
        assert ContentGenerationCallback._is_high_importance("") is False


# =============================================================================
# _is_zero_vector (static)
# =============================================================================

class TestIsZeroVector:
    def test_all_zeros(self):
        assert ContentGenerationCallback._is_zero_vector([0.0, 0.0, 0.0]) is True

    def test_has_nonzero(self):
        assert ContentGenerationCallback._is_zero_vector([0.0, 0.1, 0.0]) is False

    def test_empty_list(self):
        assert ContentGenerationCallback._is_zero_vector([]) is True

    def test_none(self):
        assert ContentGenerationCallback._is_zero_vector(None) is True


# =============================================================================
# _extract_key_event_entry (static)
# =============================================================================

class TestExtractKeyEventEntry:
    def test_high_importance_character(self):
        changes = {
            "CharacterStateChanges": [
                {"CharacterId": "char_1", "KeyEvent": "突破至金丹", "Importance": "critical"},
            ],
        }
        entry = ContentGenerationCallback._extract_key_event_entry("1_3", 1, 3, changes)
        assert entry is not None
        assert entry["ChapterId"] == "1_3"
        assert entry["VolumeNumber"] == 1
        assert entry["ChapterNumber"] == 3
        assert "char_1:突破至金丹" in entry["Characters"]

    def test_low_importance_character_skipped(self):
        changes = {
            "CharacterStateChanges": [
                {"CharacterId": "char_1", "KeyEvent": "闲聊", "Importance": "normal"},
            ],
        }
        entry = ContentGenerationCallback._extract_key_event_entry("1_3", 1, 3, changes)
        assert entry is None

    def test_high_importance_plot_point(self):
        changes = {
            "NewPlotPoints": [
                {"Context": "关键转折点", "Importance": "important"},
            ],
        }
        entry = ContentGenerationCallback._extract_key_event_entry("1_3", 1, 3, changes)
        assert entry is not None
        assert "关键转折点" in entry["Turnings"]

    def test_foreshadow_payoff(self):
        changes = {
            "ForeshadowingActions": [
                {"ForeshadowId": "f1", "Action": "payoff"},
            ],
        }
        entry = ContentGenerationCallback._extract_key_event_entry("1_3", 1, 3, changes)
        assert entry is not None
        assert "f1:回收" in entry["Foreshadows"]

    def test_foreshadow_setup(self):
        changes = {
            "ForeshadowingActions": [
                {"ForeshadowId": "f2", "Action": "setup"},
            ],
        }
        entry = ContentGenerationCallback._extract_key_event_entry("1_3", 1, 3, changes)
        assert entry is not None
        assert "f2:埋设" in entry["Foreshadows"]

    def test_faction_high_importance(self):
        changes = {
            "FactionStateChanges": [
                {"FactionId": "fac_1", "Event": "覆灭", "NewStatus": "灭亡", "Importance": "critical"},
            ],
        }
        entry = ContentGenerationCallback._extract_key_event_entry("1_3", 1, 3, changes)
        assert entry is not None
        assert "fac_1:覆灭→灭亡" in entry["Factions"]

    def test_conflict_high_importance(self):
        changes = {
            "ConflictProgress": [
                {"ConflictId": "conf_1", "Event": "战争结束", "NewStatus": "resolved", "Importance": "important"},
            ],
        }
        entry = ContentGenerationCallback._extract_key_event_entry("1_3", 1, 3, changes)
        assert entry is not None
        assert "conf_1:战争结束→resolved" in entry["Factions"]

    def test_no_important_events_returns_none(self):
        changes = {
            "CharacterStateChanges": [
                {"CharacterId": "char_1", "KeyEvent": "日常", "Importance": "normal"},
            ],
        }
        entry = ContentGenerationCallback._extract_key_event_entry("1_3", 1, 3, changes)
        assert entry is None

    def test_empty_changes(self):
        changes = {}
        entry = ContentGenerationCallback._extract_key_event_entry("1_3", 1, 3, changes)
        assert entry is None


# =============================================================================
# _extract_summary (instance method, but pure logic)
# =============================================================================

class TestExtractSummary:
    def test_short_content(self):
        cb = _make_minimal_callback()
        result = cb._extract_summary("你好世界", max_length=500)
        assert result == "你好世界"

    def test_empty_content(self):
        cb = _make_minimal_callback()
        assert cb._extract_summary("") == ""

    def test_content_truncated_at_sentence_end(self):
        cb = _make_minimal_callback()
        text = "第一句。第二句。第三句。" * 50
        result = cb._extract_summary(text, max_length=100)
        assert len(result) <= 100 + 3  # allow for "……" suffix
        assert result.endswith("……")

    def test_no_sentence_end_found(self):
        cb = _make_minimal_callback()
        text = "a" * 200
        result = cb._extract_summary(text, max_length=50)
        assert result == "a" * 50 + "……"

    def test_carriage_returns_replaced(self):
        cb = _make_minimal_callback()
        text = "hello\r\nworld"
        result = cb._extract_summary(text, max_length=500)
        assert result == "hello world"


# =============================================================================
# _build_structured_summary (instance method, but pure once _extract_summary is)
# =============================================================================

class TestBuildStructuredSummary:
    def test_empty_changes_uses_extract_summary(self):
        cb = _make_minimal_callback()
        result = cb._build_structured_summary("hello world", {})
        assert result == "hello world"

    def test_with_character_change(self):
        cb = _make_minimal_callback()
        changes = {
            "CharacterStateChanges": [
                {"CharacterId": "char_1", "KeyEvent": "突破金丹"},
            ],
        }
        result = cb._build_structured_summary("正文", changes)
        assert "[角色]char_1: 突破金丹" in result

    def test_with_name_map(self):
        cb = _make_minimal_callback()
        changes = {
            "CharacterStateChanges": [
                {"CharacterId": "char_1", "KeyEvent": "突破金丹"},
            ],
        }
        name_map = {"char_1": "张三"}
        result = cb._build_structured_summary("正文", changes, name_map)
        assert "[角色]张三: 突破金丹" in result

    def test_all_change_types(self):
        cb = _make_minimal_callback()
        changes = {
            "CharacterStateChanges": [{"CharacterId": "c1", "KeyEvent": "觉醒"}],
            "ConflictProgress": [{"ConflictId": "x1", "Event": "结束", "NewStatus": "resolved"}],
            "NewPlotPoints": [{"Context": "关键情节"}],
            "ForeshadowingActions": [{"ForeshadowId": "f1", "Action": "payoff"}],
            "LocationStateChanges": [{"LocationId": "l1", "Event": "迁移", "NewStatus": "空"}],
            "FactionStateChanges": [{"FactionId": "fa1", "Event": "结盟", "NewStatus": "盟友"}],
            "TimeProgression": {"TimePeriod": "三日", "ElapsedTime": "3天"},
            "CharacterMovements": [{"CharacterId": "c1", "FromLocation": "l1", "ToLocation": "l2"}],
            "ItemTransfers": [{"ItemName": "剑", "Event": "赠予", "FromHolder": "c1", "ToHolder": "c2"}],
            "SecretRevealChanges": [{"SecretId": "s1", "Method": "坦白", "KeyEvent": "说出真相"}],
            "PledgeConstraintChanges": [{"PledgeId": "p1", "Action": "完成", "KeyEvent": "履约"}],
            "DeadlineConstraintChanges": [{"DeadlineId": "d1", "Action": "到期", "KeyEvent": "时限到"}],
        }
        result = cb._build_structured_summary("正文", changes)
        assert "[角色]c1: 觉醒" in result
        assert "[冲突]x1: 结束→resolved" in result
        assert "[情节]关键情节" in result
        assert "[伏笔]f1: payoff" in result
        assert "[地点]l1: 迁移→空" in result
        assert "[势力]fa1: 结盟→盟友" in result
        assert "[时间]三日 经过3天" in result
        assert "[移动]c1: l1→l2" in result
        assert "[物品]剑: 赠予 (c1→c2)" in result
        assert "[秘密]s1: 坦白 说出真相" in result
        assert "[承诺]p1: 完成 履约" in result
        assert "[时限]d1: 到期 时限到" in result

    def test_summary_truncation(self):
        cb = _make_minimal_callback()
        cb.SUMMARY_MAX_CHARS = 50
        changes = {
            "CharacterStateChanges": [{"CharacterId": "c1", "KeyEvent": "A" * 100}],
        }
        result = cb._build_structured_summary("正文", changes)
        assert len(result) <= 50 + 20  # some slack for truncation marker


# =============================================================================
# clear_name_map_cache
# =============================================================================

class TestClearNameMapCache:
    def test_clears_cache(self):
        cb = _make_minimal_callback()
        cb._name_map_cache = ({"a": "b"}, 9999999999)
        cb.clear_name_map_cache()
        assert cb._name_map_cache is None


# =============================================================================
# _verify_commit_sync (static)
# =============================================================================

class TestVerifyCommitSync:
    def test_no_project_name_returns_true(self):
        StoragePathHelper.current_project_name = None
        cb = _make_minimal_callback()
        assert cb._verify_commit_sync("1_3") is True

    def test_with_project_name_and_no_staging(self, monkeypatch):
        StoragePathHelper.current_project_name = "test_project"
        cb = _make_minimal_callback()
        result = cb._verify_commit_sync("1_3")
        assert result is True


# =============================================================================
# _build_design_character_map (static)
# =============================================================================

class TestBuildDesignCharacterMap:
    def test_no_service_registered(self):
        # ServiceLocator has no CharacterRulesService
        result = ContentGenerationCallback._build_design_character_map()
        assert result == {}

    def test_with_service(self):
        mock_rules = [
            {"Id": "c1", "Name": "张三", "Identity": "散修"},
            {"Id": "c2", "Name": "李四", "Identity": "掌门"},
        ]
        class MockService:
            def get_all_character_rules(self):
                return mock_rules
        ServiceLocator.register("CharacterRulesService", MockService())
        try:
            result = ContentGenerationCallback._build_design_character_map()
            assert result["c1"] == {"Name": "张三", "Identity": "散修"}
            assert result["c2"] == {"Name": "李四", "Identity": "掌门"}
        finally:
            ServiceLocator._services.pop("CharacterRulesService", None)


# =============================================================================
# _get_layered_context_config (instance)
# =============================================================================

class TestGetLayeredContextConfig:
    def test_returns_empty_dict(self):
        cb = _make_minimal_callback()
        assert cb._get_layered_context_config() == {}


# =============================================================================
# _log and _report_phase (static) — smoke test only
# =============================================================================

class TestLogAndReport:
    def test_log_does_not_raise(self, capsys):
        ContentGenerationCallback._log("test message")
        captured = capsys.readouterr()
        assert "test message" in captured.out

    def test_report_phase_does_not_raise(self, capsys):
        ContentGenerationCallback._report_phase("test", "doing work")
        captured = capsys.readouterr()
        assert "[test]" in captured.out
        assert "doing work" in captured.out


# =============================================================================
# ChunkKey, EmbeddingMode, StoragePathHelper (module-level helpers)
# =============================================================================

class TestChunkKey:
    def test_format(self):
        assert ChunkKey.format("1_3", 42) == "1_3:42"


class TestEmbeddingMode:
    def test_constants(self):
        assert EmbeddingMode.PASSAGE == "passage"
        assert EmbeddingMode.QUERY == "query"


class TestStoragePathHelper:
    def test_defaults(self):
        # save and restore to avoid pollution from other tests
        old = StoragePathHelper.current_project_name
        StoragePathHelper.current_project_name = None
        try:
            assert StoragePathHelper.get_storage_root() == ""
            assert StoragePathHelper.get_project_chapters_path() == ""
            assert StoragePathHelper.current_project_name is None
        finally:
            StoragePathHelper.current_project_name = old


# =============================================================================
# Helpers
# =============================================================================

def _make_minimal_callback():
    """Create a ContentGenerationCallback with all deps as mocks."""
    import asyncio
    from unittest.mock import MagicMock, AsyncMock

    class MockGenGate:
        def validate_changes_protocol(self, content):
            return {"success": True, "changes": None, "content_without_changes": content}
        async def validate_async(self, *a, **kw):
            return {"success": True, "parsed_changes": None, "content_without_changes": ""}

    cb = ContentGenerationCallback(
        generation_gate=MockGenGate(),
        guide_manager=MagicMock(),
        ledger_trim=MagicMock(),
        summary_store=MagicMock(),
        milestone_store=MagicMock(),
        character_state_service=MagicMock(),
        conflict_progress_service=MagicMock(),
        plot_points_index_service=MagicMock(),
        foreshadowing_status_service=MagicMock(),
        location_state_service=MagicMock(),
        faction_state_service=MagicMock(),
        timeline_service=MagicMock(),
        item_state_service=MagicMock(),
        secret_reveal_service=MagicMock(),
        pledge_constraint_service=MagicMock(),
        deadline_constraint_service=MagicMock(),
        changes_wal_store=MagicMock(),
        key_event_store=MagicMock(),
        drift_fallback_patcher=MagicMock(),
    )
    return cb