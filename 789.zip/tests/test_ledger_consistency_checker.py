# -*- coding: utf-8 -*-
"""tests for novel_writer/implementations/tracking/ledger_consistency_checker.py"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from novel_writer.models import ChapterChanges, FactSnapshot
from novel_writer.models.tracking import (
    ForeshadowingAction, ForeshadowingEntry,
    CharacterStateChange, CharacterStateEntry,
    ConflictProgressChange, ConflictProgressEntry,
)
from novel_writer.implementations.tracking.ledger_consistency_checker import (
    LedgerConsistencyChecker,
    ConsistencyIssue,
    ConsistencyResult,
)


class TestConsistencyIssue:
    def test_defaults(self):
        issue = ConsistencyIssue()
        assert issue.EntityId == ""
        assert issue.IssueType == ""
        assert issue.Expected == ""
        assert issue.Actual == ""

    def test_custom_values(self):
        issue = ConsistencyIssue(entity_id="e1", issue_type="X",
                                 expected="a", actual="b")
        assert issue.EntityId == "e1"
        assert issue.Actual == "b"


class TestConsistencyResult:
    def test_default_no_issues(self):
        r = ConsistencyResult()
        assert r.Success is True
        assert r.HasIssues is False
        assert len(r.Issues) == 0

    def test_add_issue_marks_failure(self):
        r = ConsistencyResult()
        r.AddIssue(ConsistencyIssue())
        assert r.Success is False
        assert r.HasIssues is True
        assert len(r.Issues) == 1


class TestLedgerConsistencyChecker:
    def setup_method(self):
        self.checker = LedgerConsistencyChecker()

    def test_initializes_gate(self):
        assert self.checker._gate is not None

    def test_validate_none_changes_reports_issue(self):
        result = self.checker.Validate(None, FactSnapshot())
        assert result.Success is False
        assert result.HasIssues is True
        assert result.Issues[0].IssueType == "NullChanges"

    def test_validate_empty_changes_succeeds(self):
        result = self.checker.Validate(ChapterChanges(), FactSnapshot())
        assert result.Success is True
        assert result.HasIssues is False

    def test_validate_payoff_without_setup_flags_issue(self):
        changes = ChapterChanges()
        action = ForeshadowingAction(ForeshadowId="f1", Action="payoff")
        changes.ForeshadowingActions.append(action)
        snapshot = FactSnapshot(ForeshadowingStatus=[
            ForeshadowingEntry(ForeshadowId="f1", Name="伏笔A",
                               IsSetup=False, IsResolved=False),
        ])
        result = self.checker.Validate(changes, snapshot)
        assert result.Success is False
        assert "ForeshadowingConsistency" in [i.IssueType for i in result.Issues]

    def test_validate_setup_after_resolved_flags_issue(self):
        changes = ChapterChanges()
        action = ForeshadowingAction(ForeshadowId="f1", Action="setup")
        changes.ForeshadowingActions.append(action)
        snapshot = FactSnapshot(ForeshadowingStatus=[
            ForeshadowingEntry(ForeshadowId="f1", Name="伏笔A", IsResolved=True),
        ])
        result = self.checker.Validate(changes, snapshot)
        assert result.Success is False

    def test_validate_character_not_involved_flags_issue(self):
        changes = ChapterChanges()
        changes.CharacterStateChanges.append(
            CharacterStateChange(CharacterId="cX", NewLevel="金丹"))
        snapshot = FactSnapshot(CharacterStates=[
            CharacterStateEntry(CharacterId="cA", Name="A", Level="练气"),
        ])
        result = self.checker.Validate(changes, snapshot)
        assert result.Success is False
        assert "Consistency" in [i.IssueType for i in result.Issues]

    def test_validate_valid_character_change_passes(self):
        changes = ChapterChanges()
        changes.CharacterStateChanges.append(
            CharacterStateChange(CharacterId="cA", NewLevel="金丹"))
        snapshot = FactSnapshot(CharacterStates=[
            CharacterStateEntry(CharacterId="cA", Name="A", Level="练气"),
        ])
        result = self.checker.Validate(changes, snapshot)
        # character IS involved -> no V3 error
        assert result.Success is True

    def test_validate_with_custom_ruleset(self):
        # passing any falsy/None rule_set should not crash
        result = self.checker.Validate(ChapterChanges(), FactSnapshot(), rule_set=None)
        assert isinstance(result, ConsistencyResult)

    def test_validate_accepts_rule_set_object(self):
        # A plain object that exposes the needed attrs as defaults; universal
        # default is used when a LedgerRuleSet is passed.
        result = self.checker.Validate(ChapterChanges(), FactSnapshot())
        assert result.Success is True


class TestValidateStructuralOnly:
    def setup_method(self):
        self.checker = LedgerConsistencyChecker()

    def test_none_changes_returns_empty_result(self):
        result = self.checker.ValidateStructuralOnly(None)
        assert result.Success is True
        assert result.HasIssues is False

    def test_empty_changes_succeeds(self):
        result = self.checker.ValidateStructuralOnly(ChapterChanges())
        assert result.Success is True

    def test_returns_result_instance(self):
        result = self.checker.ValidateStructuralOnly(ChapterChanges())
        assert isinstance(result, ConsistencyResult)


# ---- 追加测试 ----

class TestLedgerConsistencyCheckerNewMethods:
    def setup_method(self):
        self.checker = LedgerConsistencyChecker()

    def test_validate_foreshadowing_consistency(self):
        changes = ChapterChanges()
        from novel_writer.models import ForeshadowingAction
        changes.ForeshadowingActions.append(ForeshadowingAction(ForeshadowId="f1", Action="payoff"))
        snapshot = FactSnapshot(ForeshadowingStatus=[
            type("FS", (), {"ForeshadowId": "f1", "Name": "伏笔A", "IsSetup": False, "IsResolved": False})(),
        ])
        result = self.checker.Validate(changes, snapshot)
        assert result.Success is False

    def test_validate_conflict_consistency(self):
        result = self.checker.Validate(ChapterChanges(), FactSnapshot())
        assert isinstance(result, ConsistencyResult)

    def test_validate_character_consistency(self):
        from novel_writer.models import CharacterStateChange
        changes = ChapterChanges()
        changes.CharacterStateChanges.append(CharacterStateChange(CharacterId="cX", NewLevel="金丹"))
        snapshot = FactSnapshot(CharacterStates=[
            type("CE", (), {"CharacterId": "cA", "Name": "A", "Level": "练气"})(),
        ])
        result = self.checker.Validate(changes, snapshot)
        assert result.Success is False

    def test_validate_timeline_consistency(self):
        result = self.checker.Validate(ChapterChanges(), FactSnapshot())
        assert isinstance(result, ConsistencyResult)

    def test_validate_item_ownership_consistency(self):
        result = self.checker.Validate(ChapterChanges(), FactSnapshot())
        assert isinstance(result, ConsistencyResult)

    def test_validate_faction_relationship_consistency(self):
        result = self.checker.Validate(ChapterChanges(), FactSnapshot())
        assert isinstance(result, ConsistencyResult)

    def test_is_ally_relation(self):
        from novel_writer.gate import _is_ally
        assert _is_ally("盟友") is True
        assert _is_ally("敌人") is False
        assert _is_ally("") is False

    def test_is_enemy_relation(self):
        from novel_writer.gate import _is_enemy
        assert _is_enemy("仇敌") is True
        assert _is_enemy("朋友") is False
        assert _is_enemy("") is False

    def test_validate_pledge_constraint_consistency(self):
        result = self.checker.Validate(ChapterChanges(), FactSnapshot())
        assert isinstance(result, ConsistencyResult)

    def test_validate_deadline_constraint_consistency(self):
        result = self.checker.Validate(ChapterChanges(), FactSnapshot())
        assert isinstance(result, ConsistencyResult)

    def test_build_status_index_map(self):
        result = LedgerConsistencyChecker.build_status_index_map(["pending", "active", "climax", "resolved"])
        assert result == {"pending": 0, "active": 1, "climax": 2, "resolved": 3}

    def test_build_status_index_map_short(self):
        assert LedgerConsistencyChecker.build_status_index_map([]) == {}
        assert LedgerConsistencyChecker.build_status_index_map(["a"]) == {}

    def test_normalize_conflict_status(self):
        assert LedgerConsistencyChecker.normalize_conflict_status("pending") == "pending"
        assert LedgerConsistencyChecker.normalize_conflict_status("active") == "active"
        assert LedgerConsistencyChecker.normalize_conflict_status("climax") == "climax"
        assert LedgerConsistencyChecker.normalize_conflict_status("resolved") == "resolved"
        assert LedgerConsistencyChecker.normalize_conflict_status("") == ""
        assert LedgerConsistencyChecker.normalize_conflict_status(None) == ""

    def test_normalize_conflict_status_chinese(self):
        assert LedgerConsistencyChecker.normalize_conflict_status("未开始") == "pending"
        assert LedgerConsistencyChecker.normalize_conflict_status("进行中") == "active"
        assert LedgerConsistencyChecker.normalize_conflict_status("高潮") == "climax"
        assert LedgerConsistencyChecker.normalize_conflict_status("已解决") == "resolved"

    def test_parse_level_number(self):
        level_map = {"Tier-1": 1, "Tier-2": 2, "S": 5}
        assert LedgerConsistencyChecker.parse_level_number("tier-1", level_map) == 1
        assert LedgerConsistencyChecker.parse_level_number("tier 2", level_map) == 2
        assert LedgerConsistencyChecker.parse_level_number("", level_map) == -1
        assert LedgerConsistencyChecker.parse_level_number(None, level_map) == -1

    def test_parse_level_number_grade(self):
        level_map = {"S": 5, "A": 4}
        assert LedgerConsistencyChecker.parse_level_number("S", level_map) == 5
        assert LedgerConsistencyChecker.parse_level_number("A", level_map) == 4

    def test_try_parse_roman_numeral(self):
        assert LedgerConsistencyChecker.try_parse_roman_numeral("I") == 1
        assert LedgerConsistencyChecker.try_parse_roman_numeral("V") == 5
        assert LedgerConsistencyChecker.try_parse_roman_numeral("X") == 10
        assert LedgerConsistencyChecker.try_parse_roman_numeral("IV") == 4
        assert LedgerConsistencyChecker.try_parse_roman_numeral("IX") == 9
        assert LedgerConsistencyChecker.try_parse_roman_numeral("XII") == 12
        assert LedgerConsistencyChecker.try_parse_roman_numeral("") is None
        assert LedgerConsistencyChecker.try_parse_roman_numeral(None) is None
        assert LedgerConsistencyChecker.try_parse_roman_numeral("ABC") is None

    def test_try_parse_chinese_number(self):
        assert LedgerConsistencyChecker.try_parse_chinese_number("一") == 1
        assert LedgerConsistencyChecker.try_parse_chinese_number("十") == 10
        assert LedgerConsistencyChecker.try_parse_chinese_number("十二") == 12
        assert LedgerConsistencyChecker.try_parse_chinese_number("二十") == 20
        assert LedgerConsistencyChecker.try_parse_chinese_number("一百") == 100
        assert LedgerConsistencyChecker.try_parse_chinese_number("") is None
        assert LedgerConsistencyChecker.try_parse_chinese_number(None) is None
        assert LedgerConsistencyChecker.try_parse_chinese_number("abc") is None