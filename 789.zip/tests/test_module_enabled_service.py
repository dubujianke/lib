# -*- coding: utf-8 -*-
"""ModuleEnabledService 单元测试 — 对标 Implementations/Packaging/ModuleEnabledService.cs"""
import sys
import os
import tempfile
import json

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock, patch

from novel_writer.implementations.packaging.module_enabled_service import ModuleEnabledService


class FakeProject:
    def __init__(self, project_dir):
        self.dir = project_dir
        self.design_dir = os.path.join(project_dir, "design")


@pytest.fixture
def svc():
    d = tempfile.mkdtemp(prefix="test_module_")
    os.makedirs(os.path.join(d, "design", "characters"), exist_ok=True)
    project = FakeProject(d)
    return ModuleEnabledService(project), d


# =====================================================================
# set_function_data_enabled（设置目录下所有 JSON 启用状态）
# =====================================================================

def test_set_function_data_enabled_returns_zero_for_empty_path(svc):
    s, _ = svc
    assert s._set_function_data_enabled("", True) == 0


def test_set_function_data_enabled_updates_files(svc):
    s, d = svc
    storage_dir = os.path.join(d, "storage", "test_data")
    os.makedirs(storage_dir, exist_ok=True)
    path = os.path.join(storage_dir, "data.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump([{"Name": "item1", "IsEnabled": False}, {"Name": "item2", "IsEnabled": False}], f)
    # 使用绝对路径
    updated = s._set_function_data_enabled(storage_dir, True)
    assert updated == 2
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    assert all(i["IsEnabled"] is True for i in data)


def test_set_function_data_enabled_skips_categories_json(svc):
    s, d = svc
    storage_dir = os.path.join(d, "storage", "test_data")
    os.makedirs(storage_dir, exist_ok=True)
    path = os.path.join(storage_dir, "categories.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump([{"Name": "cat"}], f)
    assert s._set_function_data_enabled(storage_dir, True) == 0


# =====================================================================
# update_json_file_enabled（更新单个 JSON 文件启用状态）
# =====================================================================

def test_update_json_file_enabled_returns_zero_for_missing(svc):
    s, _ = svc
    assert s._update_json_file_enabled("/nonexistent/path.json", True) == 0


def test_update_json_file_enabled_updates_list_items(svc):
    s, d = svc
    path = os.path.join(d, "test.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump([{"Name": "a", "IsEnabled": False}, {"Name": "b", "IsEnabled": False}], f)
    assert s._update_json_file_enabled(path, True) == 2
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    assert all(i["IsEnabled"] is True for i in data)


def test_update_json_file_enabled_handles_dict_with_items(svc):
    s, d = svc
    path = os.path.join(d, "test.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"items": [{"Name": "a", "IsEnabled": False}]}, f)
    assert s._update_json_file_enabled(path, True) == 1


# =====================================================================
# get_function_enabled_stats（统计启用状态）
# =====================================================================

def test_get_function_enabled_stats_empty_path(svc):
    s, _ = svc
    assert s._get_function_enabled_stats("") == (0, 0)


def test_get_function_enabled_stats_counts(svc):
    s, d = svc
    storage_dir = os.path.join(d, "storage", "test_data")
    os.makedirs(storage_dir, exist_ok=True)
    path = os.path.join(storage_dir, "data.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump([{"IsEnabled": True}, {"IsEnabled": False}, {"IsEnabled": True}], f)
    enabled, total = s._get_function_enabled_stats(storage_dir)
    assert enabled == 2
    assert total == 3


# =====================================================================
# set_all_sub_modules_enabled（设置所有子模块启用状态）
# =====================================================================

def test_set_all_sub_modules_enabled(svc):
    s, d = svc
    # design_dir 下直接放 .json 文件（set_module_enabled 遍历 design_dir 中的 .json 文件）
    for name in ["characters.json", "locations.json"]:
        path = os.path.join(d, "design", name)
        with open(path, "w", encoding="utf-8") as f:
            json.dump([{"Name": "x", "IsEnabled": False}], f)
    total = s.set_all_sub_modules_enabled("Design", True)
    assert total > 0


# =====================================================================
# resolve_storage_directory（解析存储路径）
# =====================================================================

def test_resolve_storage_directory_strips_storage_prefix():
    result = ModuleEnabledService._resolve_storage_directory("storage/test_data")
    assert "test_data" in result
    assert "storage" not in result.lower()


def test_resolve_storage_directory_empty():
    assert ModuleEnabledService._resolve_storage_directory("") == ""


def test_resolve_storage_directory_normalizes_slashes():
    result = ModuleEnabledService._resolve_storage_directory("/storage/test_data")
    assert "test_data" in result


# =====================================================================
# get_module_enabled / get_module_enabled_stats
# =====================================================================

def test_get_module_enabled_no_files(svc):
    s, d = svc
    assert s.get_module_enabled("Design", "characters") is False


def test_get_module_enabled_stats_returns_zero_for_empty_design(svc):
    s, d = svc  # design_dir 存在但无 .json 文件
    assert s.get_module_enabled_stats("Design", "characters") == (0, 0)