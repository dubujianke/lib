# -*- coding: utf-8 -*-
"""tests for volume_fact_archive_store.py"""
import sys, os, json, tempfile, shutil
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock, patch
from novel_writer.implementations.guides.volume_fact_archive_store import VolumeFactArchiveStore


class MockSnapshot:
    def __init__(self):
        self.CharacterStates = []
        self.ConflictProgress = []
        self.ForeshadowingStatus = []
        self.LocationStates = []
        self.FactionStates = []
        self.ItemStates = []
        self.SecretStates = []
        self.Timeline = []
        self.CharacterLocations = []
        self.PledgeStates = []
        self.DeadlineStates = []


class MockProject:
    def __init__(self):
        self.dir = tempfile.mkdtemp(prefix="test_vfa_")
    def __del__(self):
        shutil.rmtree(self.dir, ignore_errors=True)


@pytest.fixture
def project():
    p = MockProject()
    yield p
    shutil.rmtree(p.dir, ignore_errors=True)


@pytest.fixture
def store(project):
    return VolumeFactArchiveStore(project)


# --- 路径方法 ---

def test_get_archives_dir(store):
    path = store.get_archives_dir()
    assert "fact_archives" in path


def test_get_archive_file_path(store):
    path = store.get_archive_file_path(3)
    assert "vol3.json" in path


# --- archive_volume ---

def test_archive_volume_normal(store, project):
    snapshot = MockSnapshot()
    snapshot.CharacterStates = ["cs1"]
    snapshot.FactionStates = ["fs1"]
    store.archive_volume(1, snapshot, "ch1")
    path = store.get_archive_file_path(1)
    assert os.path.exists(path)
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    assert data["VolumeNumber"] == 1
    assert data["LastChapterId"] == "ch1"


def test_archive_volume_invalid_number(store):
    snapshot = MockSnapshot()
    store.archive_volume(0, snapshot, "ch1")
    assert store._cache == {}
    store.archive_volume(-1, snapshot, "ch1")
    assert store._cache == {}


def test_archive_volume_none_snapshot(store):
    store.archive_volume(1, None, "ch1")
    assert store._cache == {}


# --- delete_archive ---

def test_delete_archive_normal(store, project):
    snapshot = MockSnapshot()
    store.archive_volume(1, snapshot, "ch1")
    path = store.get_archive_file_path(1)
    assert os.path.exists(path)
    store.delete_archive(1)
    assert not os.path.exists(path)
    assert 1 not in store._cache


def test_delete_archive_nonexistent(store):
    store.delete_archive(999)


def test_delete_archive_invalid_number(store):
    store.delete_archive(0)
    store.delete_archive(-1)


# --- delete_archive_if_last_chapter ---

def test_delete_archive_if_last_chapter_matches(store, project):
    snapshot = MockSnapshot()
    store.archive_volume(1, snapshot, "ch1")
    path = store.get_archive_file_path(1)
    assert os.path.exists(path)
    store.delete_archive_if_last_chapter(1, "ch1")
    assert not os.path.exists(path)


def test_delete_archive_if_last_chapter_not_matches(store, project):
    snapshot = MockSnapshot()
    store.archive_volume(1, snapshot, "ch1")
    path = store.get_archive_file_path(1)
    store.delete_archive_if_last_chapter(1, "ch2")
    assert os.path.exists(path)


def test_delete_archive_if_last_chapter_no_archive(store):
    store.delete_archive_if_last_chapter(1, "ch1")  # should not crash


def test_delete_archive_if_last_chapter_empty_chapter_id(store):
    store.delete_archive_if_last_chapter(1, "")  # should not crash


# --- get_previous_archives ---

def test_get_previous_archives_normal(store, project):
    for v in range(1, 4):
        snapshot = MockSnapshot()
        store.archive_volume(v, snapshot, f"ch{v}")
    result = store.get_previous_archives(4)
    assert len(result) == 3
    assert all(a.VolumeNumber in (1, 2, 3) for a in result)


def test_get_previous_archives_volume_one(store):
    result = store.get_previous_archives(1)
    assert result == []


def test_get_previous_archives_missing_volumes(store):
    store.archive_volume(5, MockSnapshot(), "ch5")
    result = store.get_previous_archives(6)
    assert len(result) == 1


# --- invalidate_cache ---

def test_invalidate_cache(store, project):
    snapshot = MockSnapshot()
    store.archive_volume(1, snapshot, "ch1")
    assert 1 in store._cache
    store.invalidate_cache()
    assert store._cache == {}