# -*- coding: utf-8 -*-
"""tests for guide_manager.py"""
import sys, os, json, tempfile, shutil
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from unittest.mock import MagicMock, patch
from novel_writer.implementations.guides.guide_manager import GuideManager


@pytest.fixture
def project():
    tmpdir = tempfile.mkdtemp()
    p = MagicMock()
    p.dir = tmpdir
    yield p
    shutil.rmtree(tmpdir)


class FakeGuide:
    def __init__(self, data=None):
        self.data = data or {"name": "test"}
    def to_dict(self):
        return self.data
    @classmethod
    def from_dict(cls, data):
        return cls(data)


class TestGuideManager:
    def test_init(self, project):
        gm = GuideManager(project)
        assert gm.project is project
        assert gm.FLUSH_THRESHOLD == 10
        assert gm.COMMIT_MARKER == "_commit"
        assert gm.MAX_CLEAN_CACHE_ENTRIES == 1000
        stats = gm.get_stats()
        assert stats == (0, 0, 0)

    def test_get_guide_new(self, project):
        gm = GuideManager(project)
        guide = gm.get_guide("test.json", FakeGuide)
        assert isinstance(guide, FakeGuide)
        assert guide.data == {"name": "test"}

    def test_get_guide_no_cls(self, project):
        gm = GuideManager(project)
        guide = gm.get_guide("test.json")
        assert guide == {}

    def test_get_guide_cached(self, project):
        gm = GuideManager(project)
        guide1 = gm.get_guide("test.json", FakeGuide)
        guide2 = gm.get_guide("test.json", FakeGuide)
        assert guide1 is guide2

    def test_get_guide_loads_from_file(self, project):
        guides_dir = os.path.join(project.dir, "guides")
        os.makedirs(guides_dir)
        with open(os.path.join(guides_dir, "existing.json"), "w") as f:
            json.dump({"name": "from_file"}, f)
        gm = GuideManager(project)
        guide = gm.get_guide("existing.json", FakeGuide)
        assert guide.data == {"name": "from_file"}

    def test_get_guide_loads_from_file_no_cls(self, project):
        guides_dir = os.path.join(project.dir, "guides")
        os.makedirs(guides_dir)
        with open(os.path.join(guides_dir, "data.json"), "w") as f:
            json.dump({"key": "value"}, f)
        gm = GuideManager(project)
        guide = gm.get_guide("data.json")
        assert guide == {"key": "value"}

    def test_mark_dirty(self, project):
        gm = GuideManager(project)
        gm.mark_dirty("test.json")
        stats = gm.get_stats()
        assert stats[1] == 1  # 1 dirty file
        assert stats[2] == 1  # change count 1

    def test_should_flush(self, project):
        gm = GuideManager(project)
        assert not gm.should_flush()
        for _ in range(10):
            gm.mark_dirty(f"file{_}.json")
        assert gm.should_flush()

    def test_flush_all(self, project):
        gm = GuideManager(project)
        guide = gm.get_guide("test.json", FakeGuide)
        guide.data["modified"] = True
        gm.mark_dirty("test.json")
        gm.flush_all()
        # Verify file was written
        guide_path = os.path.join(project.dir, "guides", "test.json")
        assert os.path.exists(guide_path)
        with open(guide_path) as f:
            data = json.load(f)
        assert data["modified"] is True
        stats = gm.get_stats()
        assert stats[2] == 0  # change count reset

    def test_flush_all_no_dirty(self, project):
        gm = GuideManager(project)
        gm.flush_all()  # should not raise

    def test_flush_all_without_guide_cls(self, project):
        gm = GuideManager(project)
        guide = gm.get_guide("plain.json")
        guide["key"] = "value"
        gm.mark_dirty("plain.json")
        gm.flush_all()
        guide_path = os.path.join(project.dir, "guides", "plain.json")
        assert os.path.exists(guide_path)
        with open(guide_path) as f:
            data = json.load(f)
        assert data["key"] == "value"

    def test_flush_all_creates_staging_dir(self, project):
        gm = GuideManager(project)
        guide = gm.get_guide("test.json", FakeGuide)
        gm.mark_dirty("test.json")
        gm.flush_all()
        staging_dir = os.path.join(project.dir, "guides", ".flush_staging")
        assert not os.path.exists(staging_dir)  # cleaned up after commit

    def test_recover_pending_flush(self, project):
        guides_dir = os.path.join(project.dir, "guides")
        os.makedirs(guides_dir)
        staging_dir = os.path.join(guides_dir, ".flush_staging")
        os.makedirs(staging_dir)
        with open(os.path.join(staging_dir, "recovered.json"), "w") as f:
            json.dump({"recovered": True}, f)
        with open(os.path.join(staging_dir, "_commit"), "w") as f:
            f.write("ok")
        gm = GuideManager(project)
        gm.recover_pending_flush()
        assert os.path.exists(os.path.join(guides_dir, "recovered.json"))
        assert not os.path.exists(staging_dir)

    def test_recover_pending_flush_no_commit_marker(self, project):
        guides_dir = os.path.join(project.dir, "guides")
        os.makedirs(guides_dir)
        staging_dir = os.path.join(guides_dir, ".flush_staging")
        os.makedirs(staging_dir)
        with open(os.path.join(staging_dir, "orphan.json"), "w") as f:
            json.dump({"orphan": True}, f)
        gm = GuideManager(project)
        gm.recover_pending_flush()
        assert not os.path.exists(staging_dir)
        assert not os.path.exists(os.path.join(guides_dir, "orphan.json"))

    def test_recover_no_staging_dir(self, project):
        gm = GuideManager(project)
        gm.recover_pending_flush()  # should not raise

    def test_clear_cache(self, project):
        gm = GuideManager(project)
        gm.get_guide("test.json", FakeGuide)
        gm.mark_dirty("test.json")
        assert gm.get_stats()[0] == 1
        gm.clear_cache()
        assert gm.get_stats() == (0, 0, 0)

    def test_discard_dirty_and_evict(self, project):
        gm = GuideManager(project)
        guide = gm.get_guide("test.json", FakeGuide)
        gm.mark_dirty("test.json")
        gm.discard_dirty_and_evict()
        assert gm.get_stats() == (0, 0, 0)
        # Guide should be reloaded from file (doesn't exist, so fresh)
        guide2 = gm.get_guide("test.json", FakeGuide)
        assert guide2 is not guide

    def test_get_stats(self, project):
        gm = GuideManager(project)
        gm.get_guide("a.json", FakeGuide)
        gm.get_guide("b.json", FakeGuide)
        gm.mark_dirty("a.json")
        stats = gm.get_stats()
        assert stats[0] == 2  # 2 cached
        assert stats[1] == 1  # 1 dirty
        assert stats[2] == 1

    def test_get_volume_file_name(self, project):
        result = GuideManager.get_volume_file_name("guide.json", 3)
        assert result == "guide_vol3.json"
        result2 = GuideManager.get_volume_file_name("guide", 1)
        assert result2 == "guide_vol1"

    def test_get_existing_volume_numbers(self, project):
        guides_dir = os.path.join(project.dir, "guides")
        os.makedirs(guides_dir)
        for v in [1, 3, 5]:
            with open(os.path.join(guides_dir, f"guide_vol{v}.json"), "w") as f:
                json.dump({}, f)
        gm = GuideManager(project)
        nums = gm.get_existing_volume_numbers("guide.json")
        assert nums == [1, 3, 5]

    def test_get_existing_volume_numbers_no_dir(self, project):
        gm = GuideManager(project)
        assert gm.get_existing_volume_numbers("guide.json") == []

    def test_raise_entry_changed(self, project):
        gm = GuideManager(project)
        gm.raise_entry_changed("e1", "name", "desc")  # should not raise (no-op)

    def test_flush_all_error_restores_dirty(self, project):
        gm = GuideManager(project)
        guide = gm.get_guide("test.json", FakeGuide)
        gm.mark_dirty("test.json")
        with patch.object(GuideManager, '_commit_staging_files', side_effect=Exception("fail")):
            with pytest.raises(Exception):
                gm.flush_all()
        # dirty files should be restored
        assert gm.get_stats()[1] == 1

    # ---- 追加测试：flush_on_exit / cleanup_expired_cache / get_guides_dir / get_staging_dir ----

    def test_flush_on_exit(self, project):
        gm = GuideManager(project)
        guide = gm.get_guide("test.json", FakeGuide)
        guide.data["exit"] = True
        gm.mark_dirty("test.json")
        gm.flush_on_exit()
        guide_path = os.path.join(project.dir, "guides", "test.json")
        assert os.path.exists(guide_path)
        with open(guide_path) as f:
            data = json.load(f)
        assert data["exit"] is True

    def test_flush_on_exit_no_dirty(self, project):
        gm = GuideManager(project)
        gm.flush_on_exit()  # should not raise

    def test_cleanup_expired_cache_below_threshold(self, project):
        gm = GuideManager(project)
        for i in range(5):
            gm.get_guide(f"f{i}.json", FakeGuide)
        gm.cleanup_expired_cache()
        assert gm.get_stats()[0] == 5  # all kept

    def test_cleanup_expired_cache_above_threshold(self, project):
        gm = GuideManager(project)
        gm.MAX_CLEAN_CACHE_ENTRIES = 2
        for i in range(5):
            gm.get_guide(f"f{i}.json", FakeGuide)
        gm.cleanup_expired_cache()
        assert gm.get_stats()[0] <= 2

    def test_cleanup_expired_cache_skips_dirty(self, project):
        gm = GuideManager(project)
        gm.MAX_CLEAN_CACHE_ENTRIES = 0
        for i in range(3):
            gm.get_guide(f"f{i}.json", FakeGuide)
        gm.mark_dirty("f0.json")
        gm.cleanup_expired_cache()
        # f0 is dirty, should not be evicted
        assert "f0.json" in gm._cache
        assert gm.get_stats()[0] >= 1

    def test_get_guides_dir(self, project):
        gm = GuideManager(project)
        path = gm._guides_dir()
        assert path.endswith("guides") or path.endswith("guides/")

    def test_get_staging_dir(self, project):
        gm = GuideManager(project)
        guides_dir = os.path.join(project.dir, "guides")
        staging = gm._staging_dir(guides_dir)
        assert ".flush_staging" in staging