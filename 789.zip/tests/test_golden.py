# -*- coding: utf-8 -*-
"""Golden 对拍测试：期望值来自真实 C# 运行时（GoldenDump 导出 golden_data.json）。

生成方式：dotnet run Tests/GoldenDump -- golden_data.json（调用真实 C# 实现）
任何失败 = Python 与 C# 行为不一致，必须修 Python 实现到一致为止。
"""
import json
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

GOLDEN_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "opencode", "golden_data.json")
if not os.path.exists(GOLDEN_PATH):
    GOLDEN_PATH = r"D:\opencode\golden_data.json"

CASES = json.load(open(GOLDEN_PATH, encoding="utf-8"))


# ---- Python 实现适配层：每个 C# 方法 -> Python 调用 ----

def _py_call(method, inp):
    from novel_writer.character_state_service import parse_chapter_id, compare_chapter_id
    from novel_writer.implementations.generation.generation_gate import GenerationGate
    from novel_writer.humanize import HumanizeRules
    from novel_writer.implementations.generation.humanize_rules.high_risk_words import HighRiskWords
    from novel_writer.implementations.generation import importance_corrector as ic
    from novel_writer.implementations.tracking.ledger_consistency_checker import LedgerConsistencyChecker
    from novel_writer.preflight import PreflightValidator
    from novel_writer.implementations.indexing.keyword_chapter_index_service import KeywordChapterIndexService
    from novel_writer.implementations.guides.guide_manager import GuideManager
    from novel_writer.implementations.tracking.snapshot_extractor import SnapshotExtractor
    from novel_writer.implementations.validation.content_entity_extractor import ContentEntityExtractor
    from novel_writer.implementations.validation.content_description_validator import ContentDescriptionValidator
    from novel_writer.implementations.context.context_service import ContextService

    if method == "ChapterParserHelper.ParseChapterIdOrDefault":
        v, c = parse_chapter_id(inp)
        return [v, c]
    if method == "ChapterParserHelper.CompareChapterId":
        return compare_chapter_id(inp[0], inp[1])
    if method == "GenerationGate.FindChangesStartIndex":
        return GenerationGate.find_changes_start_index(inp)
    if method == "GenerationGate.HasChangesRegion":
        return GenerationGate.has_changes_region(inp)
    if method == "GenerationGate.StripChangesSection":
        return GenerationGate.strip_changes_section(inp)
    if method == "GenerationGate.ToCamelCase":
        return GenerationGate._to_camel_case(inp)
    if method == "GenerationGate.FindLastValidJsonBreakpoint":
        return GenerationGate._find_last_valid_json_breakpoint(inp)
    if method == "HumanizeRules.NormalizeEllipsis":
        return HumanizeRules._normalize_ellipsis(inp)
    if method == "HumanizeRules.NormalizeDash":
        return HumanizeRules._normalize_dash(inp)
    if method == "HumanizeRules.SmallNumberToChinese":
        return HumanizeRules.small_num_to_chinese(inp)
    if method == "HumanizeRules.ApplyDigitNormalization":
        return HumanizeRules._apply_digit_normalization(inp)
    if method == "HighRiskWords.IsHighRisk":
        return HighRiskWords.IsHighRisk(inp)
    if method == "ImportanceCorrector.CriticalCharKeywords":
        return ic.CRITICAL_CHAR_KEYWORDS
    if method == "ImportanceCorrector.ImportantCharKeywords":
        return ic.IMPORTANT_CHAR_KEYWORDS
    if method == "ImportanceCorrector.CriticalFactionKeywords":
        return ic.CRITICAL_FACTION_KEYWORDS
    if method == "ImportanceCorrector.ImportantFactionKeywords":
        return ic.IMPORTANT_FACTION_KEYWORDS
    if method == "ImportanceCorrector.ConflictImportantStatusKeywords":
        return ic.CONFLICT_IMPORTANT_STATUS_KEYWORDS
    if method == "ImportanceCorrector.MaxCriticalPerChapter":
        return ic.MAX_CRITICAL_PER_CHAPTER
    if method == "LedgerConsistencyChecker.TryParseRomanNumeral":
        v = LedgerConsistencyChecker.try_parse_roman_numeral(inp)
        return v  # None 表示失败（C# ok=false -> null）
    if method == "LedgerConsistencyChecker.TryParseChineseNumber":
        return LedgerConsistencyChecker.try_parse_chinese_number(inp)
    if method == "LedgerConsistencyChecker.NormalizeConflictStatus":
        return LedgerConsistencyChecker.normalize_conflict_status(inp or "")
    if method == "LedgerConsistencyChecker.IsAllyRelation":
        return LedgerConsistencyChecker.is_ally_relation(inp)
    if method == "LedgerConsistencyChecker.IsEnemyRelation":
        return LedgerConsistencyChecker.is_enemy_relation(inp)
    if method == "LedgerConsistencyChecker.ParseLevelNumber":
        s, mapstr = inp
        level_map = {}
        for kv in mapstr.split(","):
            k, v = kv.split("=")
            level_map[k] = int(v)
        return LedgerConsistencyChecker.parse_level_number(s, level_map)
    if method == "PreflightValidator.TryParseChineseNumber":
        return PreflightValidator.try_parse_chinese_number(inp)
    if method == "PreflightValidator.TryParseVolumeNumber":
        return PreflightValidator.try_parse_volume_number(inp)
    if method == "KeywordChapterIndexService.NormalizeKeyword":
        return KeywordChapterIndexService._normalize_keyword(inp)
    if method == "GuideManager.GetVolumeFileName":
        return GuideManager.get_volume_file_name(inp[0], int(inp[1]))
    if method == "FactSnapshotExtractor.ParseTags":
        return SnapshotExtractor.parse_tags(inp)
    if method == "FactSnapshotExtractor.SplitCsv":
        return list(SnapshotExtractor.split_csv(inp))
    if method == "ContentEntityExtractor.ExtractMentionedEntities":
        cee = ContentEntityExtractor(known_names=["张三", "李四", "青云宗", "王五"])
        return "|".join(cee.extract_mentioned_entities(inp))
    if method == "ContentEntityExtractor.GetUnknownEntities":
        cee = ContentEntityExtractor(known_names=["张三", "李四", "青云宗", "王五"])
        return "|".join(cee.get_unknown_entities(inp))
    if method == "ContentDescriptionValidator.ValidateCharacterDescriptions":
        cdv = ContentDescriptionValidator()
        char_desc = {"C123456789012": {"Name": "张三", "HairColor": "黑色", "Appearance": "瘦高"}}
        return "|".join(cdv.validate_character_descriptions(inp, char_desc))
    if method == "ContentDescriptionValidator.ValidateLocationDescriptions":
        cdv = ContentDescriptionValidator()
        loc_desc = {"L123456789012": {"Name": "青云宗", "Description": "山地"}}
        return "|".join(cdv.validate_location_descriptions(inp, loc_desc))
    if method == "ContextService.ExtractVolumeNumberFromText":
        return ContextService._extract_volume_number_from_text(inp or "")
    raise NotImplementedError(method)


def _norm(x):
    """JSON 里 list 与 Python 返回的 tuple 互通；bool/int 区分"""
    if isinstance(x, bool):
        return x
    if isinstance(x, int):
        return x
    if isinstance(x, (list, tuple)):
        return [_norm(i) for i in x]
    return x


@pytest.mark.parametrize("case", CASES, ids=lambda c: f"{c['method']}[{str(c['input'])[:40]}]")
def test_golden(case):
    method = case["method"]
    inp = case["input"]
    expected = case["expected"]
    actual = _py_call(method, inp)
    assert _norm(actual) == _norm(expected), (
        f"{method}({str(inp)[:60]})\n  C#: {expected!r}\n  PY: {actual!r}")