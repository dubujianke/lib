# -*- coding: utf-8 -*-
"""tests for novel_writer/implementations/tracking/snapshot_config.py"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from novel_writer.implementations.tracking.snapshot_config import (
    SnapshotConfig,
    DEFAULT_SNAPSHOT_CONFIG,
)


class TestDefaults:
    def test_default_values(self):
        cfg = SnapshotConfig()
        assert cfg.SnapshotMaxCharacterInject == 50
        assert cfg.SnapshotMaxLocationInject == 30
        assert cfg.SnapshotMaxConflictInject == 20
        assert cfg.SnapshotMaxForeshadowInject == 30
        assert cfg.SnapshotMaxSecretInject == 20
        assert cfg.SnapshotMaxPledgeInject == 15
        assert cfg.SnapshotMaxDeadlineInject == 15
        assert cfg.SnapshotMaxFactionInject == 30
        assert cfg.SnapshotMaxItemInject == 50
        assert cfg.SnapshotMaxTimelineInject == 5
        assert cfg.SnapshotMaxPlotInject == 15
        assert cfg.ActiveEntityWindowChapters == 8
        assert cfg.ActiveEntityWindowMaxCount == 25

    def test_module_default_singleton(self):
        assert isinstance(DEFAULT_SNAPSHOT_CONFIG, SnapshotConfig)
        assert DEFAULT_SNAPSHOT_CONFIG.SnapshotMaxTimelineInject == 5


class TestCustomValues:
    def test_custom_values_override_defaults(self):
        cfg = SnapshotConfig(
            SnapshotMaxCharacterInject=10,
            SnapshotMaxTimelineInject=2,
            ActiveEntityWindowChapters=4,
            ActiveEntityWindowMaxCount=5,
        )
        assert cfg.SnapshotMaxCharacterInject == 10
        assert cfg.SnapshotMaxTimelineInject == 2
        assert cfg.ActiveEntityWindowChapters == 4
        assert cfg.ActiveEntityWindowMaxCount == 5
        # untouched defaults remain
        assert cfg.SnapshotMaxConflictInject == 20

    def test_partial_custom_keeps_rest_defaults(self):
        cfg = SnapshotConfig(SnapshotMaxSecretInject=3)
        assert cfg.SnapshotMaxSecretInject == 3
        assert cfg.SnapshotMaxCharacterInject == 50

    def test_unknown_kwargs_ignored(self):
        cfg = SnapshotConfig(NotARealField=999)
        assert not hasattr(cfg, "NotARealField")
        assert cfg.SnapshotMaxCharacterInject == 50