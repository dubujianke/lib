# -*- coding: utf-8 -*-
"""tests for focus_context_service.py"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import time
import pytest
from unittest.mock import MagicMock, patch
from novel_writer.implementations.context.focus_context_service import FocusContextService
from novel_writer.models.context.focus_context import DesignFocusContext, GenerateFocusContext, FocusContext
from novel_writer.models.context.global_summary import GlobalSummary
from novel_writer.models.context.tracking_status import TrackingStatus


class MockProject:
    def __init__(self):
        self._data = {}

    def set_design(self, entity, data):
        self._data[entity] = data

    def load_design(self, entity):
        return self._data.get(entity, [])


class MockIndexService:
    def build_upstream_index(self, target_layer):
        return None

    def build_index_item(self, data):
        from novel_writer.models.index.index_item import IndexItem
        return IndexItem(Id=data.get("Id", ""), Name=data.get("Name", ""), Type=data.get("Type", ""))


class MockRelationStrengthService:
    def __init__(self):
        self._strengths = {}

    def set_strength(self, a, b, val):
        self._strengths[(a, b)] = val

    def get_strength(self, a, b):
        return self._strengths.get((a, b), 0)


class MockGlobalSummaryService:
    def __init__(self):
        self._summary = GlobalSummary()

    def set_summary(self, summary):
        self._summary = summary

    def get_global_summary(self):
        return self._summary


@pytest.fixture
def service():
    return FocusContextService(
        project=MockProject(),
        index_service=MockIndexService(),
        relation_strength_service=MockRelationStrengthService(),
        global_summary_service=MockGlobalSummaryService(),
    )


# --- init ---

def test_init(service):
    assert service is not None
    assert service._index_service is not None
    assert service._relation_strength_service is not None
    assert service._global_summary_service is not None


# --- get_design_context ---

def test_get_design_context_returns_design_focus_context(service):
    ctx = service.get_design_context("c1", "角色")
    assert isinstance(ctx, DesignFocusContext)
    assert isinstance(ctx.GlobalSummary, GlobalSummary)
    assert isinstance(ctx.TrackingStatus, TrackingStatus)
    assert isinstance(ctx.Focus, FocusContext)


def test_get_design_context_cache(service):
    ctx1 = service.get_design_context("c1", "角色")
    ctx2 = service.get_design_context("c1", "角色")
    assert ctx1 is ctx2  # same cached object


def test_get_design_context_cache_expiry(service):
    ctx1 = service.get_design_context("c1", "角色")
    service.CONTEXT_CACHE_EXPIRY_SECONDS = -1
    ctx2 = service.get_design_context("c1", "角色")
    assert ctx1 is not ctx2


def test_get_design_context_different_keys_different_cache(service):
    ctx1 = service.get_design_context("c1", "角色")
    ctx2 = service.get_design_context("c2", "角色")
    assert ctx1 is not ctx2


# --- get_generate_context ---

def test_get_generate_context_returns_generate_focus_context(service):
    ctx = service.get_generate_context("c1", "角色")
    assert isinstance(ctx, GenerateFocusContext)
    assert isinstance(ctx.GlobalSummary, GlobalSummary)
    assert isinstance(ctx.TrackingStatus, TrackingStatus)
    assert isinstance(ctx.Focus, FocusContext)


def test_get_generate_context_cache(service):
    ctx1 = service.get_generate_context("c1", "角色")
    ctx2 = service.get_generate_context("c1", "角色")
    assert ctx1 is ctx2


# --- _build_focus_context ---

def test_build_focus_context_empty_id(service):
    focus = service._build_focus_context("", "角色")
    assert focus.FocusId == ""
    assert focus.DirectRelations == []
    assert focus.IndirectRelations == []


def test_build_focus_context_with_relations(service):
    service.project.set_design("characters", [
        {"Id": "c1", "Name": "小明"},
        {"Id": "c2", "Name": "小红"},
        {"Id": "c3", "Name": "小刚"},
    ])
    svc = service
    svc._relation_strength_service.set_strength("c1", "c2", 2)  # Strong
    svc._relation_strength_service.set_strength("c1", "c3", 1)  # Medium
    focus = svc._build_focus_context("c1", "角色")
    assert len(focus.DirectRelations) == 1
    assert focus.DirectRelations[0].RelationStrength == "Strong"
    assert len(focus.IndirectRelations) == 1
    assert focus.IndirectRelations[0].RelationStrength == "Medium"


def test_build_focus_context_limits(service):
    service.project.set_design("characters", [
        {"Id": f"c{i}", "Name": f"Char{i}"} for i in range(10)
    ])
    svc = service
    for i in range(1, 10):
        svc._relation_strength_service.set_strength("c0", f"c{i}", 2)  # Strong
    focus = svc._build_focus_context("c0", "角色")
    assert len(focus.DirectRelations) <= 5
    assert len(focus.IndirectRelations) <= 10


# --- _get_all_character_ids ---

def test_get_all_character_ids(service):
    service.project.set_design("characters", [
        {"Id": "c1", "Name": "小明"},
        {"Id": "c2", "Name": "小红"},
    ])
    ids = service._get_all_character_ids()
    assert ids == ["c1", "c2"]


def test_get_all_character_ids_empty(service):
    ids = service._get_all_character_ids()
    assert ids == []


def test_get_all_character_ids_on_error(service):
    service.project.load_design = MagicMock(side_effect=Exception("error"))
    ids = service._get_all_character_ids()
    assert ids == []


# --- _get_global_summary ---

def test_get_global_summary_uses_service(service):
    gs = service._get_global_summary()
    assert isinstance(gs, GlobalSummary)


def test_get_global_summary_fallback():
    svc = FocusContextService(project=MockProject())
    gs = svc._get_global_summary()
    assert isinstance(gs, GlobalSummary)


# --- invalidate_cache ---

def test_invalidate_cache(service):
    ctx1 = service.get_design_context("c1", "角色")
    ctx2 = service.get_generate_context("c1", "角色")
    service.invalidate_cache()
    ctx3 = service.get_design_context("c1", "角色")
    ctx4 = service.get_generate_context("c1", "角色")
    assert ctx1 is not ctx3
    assert ctx2 is not ctx4


# --- get_design_context with no index_service ---

def test_get_design_context_no_index_service():
    svc = FocusContextService(project=MockProject())
    ctx = svc.get_design_context("c1", "角色")
    assert isinstance(ctx, DesignFocusContext)


# --- get_generate_context with no index_service ---

def test_get_generate_context_no_index_service():
    svc = FocusContextService(project=MockProject())
    ctx = svc.get_generate_context("c1", "角色")
    assert isinstance(ctx, GenerateFocusContext)


# ---- 追加测试 ----

class TestFocusContextServiceNewMethods:
    @pytest.fixture
    def service(self):
        return FocusContextService(
            project=MockProject(),
            index_service=MockIndexService(),
            relation_strength_service=MockRelationStrengthService(),
            global_summary_service=MockGlobalSummaryService(),
        )

    def test_build_cache_key(self, service):
        key = service._build_cache_key("Design", "c1", "角色")
        assert key == "Design|角色|c1"

    def test_load_relations_via_strength_service(self, service):
        from novel_writer.models.context.focus_context import FocusContext
        focus = FocusContext(FocusId="c1", FocusType="角色", Layer="角色")
        service._load_relations_via_strength_service(focus, "c1")
        assert isinstance(focus.DirectRelations, list)
        assert isinstance(focus.IndirectRelations, list)

    def test_build_tracking_status_realtime(self, service):
        status = service._build_tracking_status_realtime()
        from novel_writer.models.context.tracking_status import TrackingStatus
        assert isinstance(status, TrackingStatus)

    def test_map_progress_percent(self, service):
        assert service._map_progress_percent("resolved") == 100
        assert service._map_progress_percent("climax") == 80
        assert service._map_progress_percent("active") == 50
        assert service._map_progress_percent("") == 0
        assert service._map_progress_percent(None) == 0
        assert service._map_progress_percent("unknown") == 0

    def test_load_task_context(self, service):
        ctx = service._load_task_context("c1", "Blueprint")
        assert ctx is None  # no guide_context_service

    def test_get_characters_context(self, service):
        ctx = service.get_characters_context("c1")
        assert isinstance(ctx, DesignFocusContext)

    def test_get_content_context(self, service):
        ctx = service.get_content_context("c1")
        assert isinstance(ctx, GenerateFocusContext)

    def test_estimate_context_length(self, service):
        from novel_writer.models.context.focus_context import FocusContext
        from novel_writer.models.context.global_summary import GlobalSummary
        from novel_writer.models.index.upstream_index import UpstreamIndex
        ctx = type("Ctx", (), {"GlobalSummary": GlobalSummary(), "UpstreamIndex": UpstreamIndex()})()
        length = service._estimate_context_length(ctx)
        assert isinstance(length, int)

    def test_estimate_upstream_index_length(self, service):
        from novel_writer.models.index.upstream_index import UpstreamIndex
        from novel_writer.models.index.index_item import IndexItem
        index = UpstreamIndex()
        index.Characters = [IndexItem(Id="c1", Name="A", BriefSummary="Summary1")]
        length = service._estimate_upstream_index_length(index)
        assert length > 0
        assert service._estimate_upstream_index_length(None) == 0