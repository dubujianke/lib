# -*- coding: utf-8 -*-
"""tests for humanize_rules shim modules (data exports)"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from novel_writer.implementations.generation.humanize_rules.ai_fillers import AI_FILLER_PHRASES
from novel_writer.implementations.generation.humanize_rules.digits import (
    normalize_digits, DIGIT_TO_CHINESE, CHINESE_DECADE_MAP,
    DIGIT_YEAR_4_REGEX, DIGIT_YEAR_DECADE_REGEX, DIGIT_MONTH_REGEX, DIGIT_DAY_REGEX,
)
from novel_writer.implementations.generation.humanize_rules.phrases import (
    PHRASE_REPLACEMENTS, FORCED_PHRASE_REPLACEMENTS,
)
from novel_writer.implementations.generation.humanize_rules.words import WORD_REPLACEMENTS
from novel_writer.implementations.generation.humanize_rules.novel_artifacts import (
    NOVEL_ARTIFACT_REGEXES,
)
from novel_writer.implementations.generation.humanize_rules.novel_oral import (
    NOVEL_ORAL_PHRASES, NOVEL_ORAL_WORDS,
)
from novel_writer.implementations.generation.humanize_rules.high_risk_words import (
    HighRiskWords, HIGH_RISK_WORDS,
)


class TestAiFillers:
    def test_phrase_list_nonempty(self):
        assert len(AI_FILLER_PHRASES) > 0

    def test_phrases_are_strings(self):
        assert all(isinstance(p, str) for p in AI_FILLER_PHRASES)


class TestDigits:
    def test_digit_map_nonempty(self):
        assert len(DIGIT_TO_CHINESE) > 0
        assert len(CHINESE_DECADE_MAP) > 0

    def test_regexes_compiled(self):
        for rx in [DIGIT_YEAR_4_REGEX, DIGIT_YEAR_DECADE_REGEX, DIGIT_MONTH_REGEX, DIGIT_DAY_REGEX]:
            assert hasattr(rx, "findall")

    def test_normalize_digits_basic(self):
        result = normalize_digits("2024年")
        # Should convert the arabic digits to Chinese
        assert isinstance(result, str)


class TestPhrases:
    def test_phrase_replacements(self):
        assert len(PHRASE_REPLACEMENTS) > 0
        assert len(FORCED_PHRASE_REPLACEMENTS) > 0

    def test_forced_phrase_values_are_lists(self):
        for k, v in FORCED_PHRASE_REPLACEMENTS.items():
            assert isinstance(v, list)
            assert len(v) > 0


class TestWords:
    def test_word_replacements(self):
        assert len(WORD_REPLACEMENTS) > 0
        for k, v in WORD_REPLACEMENTS.items():
            assert isinstance(k, str)
            assert isinstance(v, list)


class TestNovelArtifacts:
    def test_artifact_regexes(self):
        # NOVEL_ARTIFACT_REGEXES may be strings or compiled patterns
        assert len(NOVEL_ARTIFACT_REGEXES) > 0
        for rx in NOVEL_ARTIFACT_REGEXES:
            assert isinstance(rx, str)


class TestNovelOral:
    def test_oral_phrases(self):
        assert len(NOVEL_ORAL_PHRASES) > 0
        assert len(NOVEL_ORAL_WORDS) > 0


class TestHighRiskWords:
    def test_high_risk_words_list(self):
        assert len(HIGH_RISK_WORDS) > 0

    def test_is_high_risk_known_word(self):
        sample = next(iter(HIGH_RISK_WORDS))
        assert HighRiskWords.IsHighRisk(sample)

    def test_is_not_high_risk_random(self):
        assert not HighRiskWords.IsHighRisk("完全随机的正常词xyz")