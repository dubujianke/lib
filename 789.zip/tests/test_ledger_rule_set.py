# -*- coding: utf-8 -*-
"""tests for novel_writer/implementations/tracking/rules/*"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest

from novel_writer.implementations.tracking.rules import (
    LedgerRuleSet,
    LedgerRuleSetProvider,
    build_ruleset_by_genre,
    XIANXIA_ABILITY_LOSS_KEYWORDS,
    URBAN_ABILITY_LOSS_KEYWORDS,
)


class TestLedgerRuleSet:
    def test_defaults(self):
        rs = LedgerRuleSet()
        assert rs.MaxTrustDelta == 30
        assert rs.EnableConflictFlowCheck is False
        assert rs.ConflictStatusSequence == []
        assert rs.EnableLevelRegressionCheck is False
        assert rs.LevelTextMap == {}
        assert rs.EnableAbilityLossRequiresEvent is False
        assert rs.AbilityLossKeywords == []
        assert rs.EnablePledgeConstraintCheck is False
        assert rs.EnableDeadlineConstraintCheck is False

    def test_create_universal_default(self):
        rs = LedgerRuleSet.create_universal_default()
        assert rs.MaxTrustDelta == 30
        assert rs.EnableConflictFlowCheck is True
        assert rs.ConflictStatusSequence == ["pending", "active", "climax", "resolved"]
        assert rs.EnableLevelRegressionCheck is True
        assert rs.LevelTextMap["SSS"] == 60
        assert rs.LevelTextMap["E"] == 0
        assert rs.LevelTextMap["Tier-5"] == 50
        assert rs.EnableAbilityLossRequiresEvent is False
        assert rs.EnablePledgeConstraintCheck is True
        assert rs.EnableDeadlineConstraintCheck is True


class TestBuildRuleSetByGenre:
    def test_none_returns_universal_default(self):
        rs = build_ruleset_by_genre(None)
        assert rs.EnablePledgeConstraintCheck is True

    def test_xianxia_genre(self):
        rs = build_ruleset_by_genre("玄幻")
        assert rs.EnableAbilityLossRequiresEvent is True
        assert rs.AbilityLossKeywords == list(XIANXIA_ABILITY_LOSS_KEYWORDS)

    def test_urban_genre(self):
        rs = build_ruleset_by_genre("都市")
        assert rs.EnableAbilityLossRequiresEvent is True
        assert rs.AbilityLossKeywords == list(URBAN_ABILITY_LOSS_KEYWORDS)

    def test_unrecognized_genre_returns_default(self):
        rs = build_ruleset_by_genre("科幻")
        assert rs.EnableAbilityLossRequiresEvent is False

    def test_whitespace_stripped(self):
        rs = build_ruleset_by_genre("  武侠  ")
        assert rs.EnableAbilityLossRequiresEvent is True

    def test_empty_string_returns_default(self):
        rs = build_ruleset_by_genre("")
        assert rs.EnableAbilityLossRequiresEvent is False


class FakeProject:
    def __init__(self, materials=None):
        self._materials = materials

    def load_design(self, name):
        return self._materials


class TestLedgerRuleSetProvider:
    def test_no_project_returns_default(self):
        p = LedgerRuleSetProvider(project=None)
        rs = p.get_ruleset_for_gate()
        assert rs.EnablePledgeConstraintCheck is True

    def test_no_materials_returns_default(self):
        p = LedgerRuleSetProvider(project=FakeProject(materials={}))
        rs = p.get_ruleset_for_gate()
        assert rs.EnablePledgeConstraintCheck is True

    def test_no_enabled_materials_returns_default(self):
        p = LedgerRuleSetProvider(project=FakeProject(materials={
            "items": [{"Genre": "玄幻", "IsEnabled": False}]
        }))
        rs = p.get_ruleset_for_gate()
        assert rs.EnableAbilityLossRequiresEvent is False

    def test_enabled_material_selects_genre(self):
        p = LedgerRuleSetProvider(project=FakeProject(materials={
            "items": [{"Genre": "玄幻", "IsEnabled": True, "ModifiedTime": "1"}]
        }))
        rs = p.get_ruleset_for_gate()
        assert rs.EnableAbilityLossRequiresEvent is True
        assert rs.AbilityLossKeywords == list(XIANXIA_ABILITY_LOSS_KEYWORDS)

    def test_newest_enabled_wins(self):
        p = LedgerRuleSetProvider(project=FakeProject(materials={
            "items": [
                {"Genre": "玄幻", "IsEnabled": True, "ModifiedTime": "1"},
                {"Genre": "都市", "IsEnabled": True, "ModifiedTime": "2"},
            ]
        }))
        rs = p.get_ruleset_for_gate()
        assert rs.AbilityLossKeywords == list(URBAN_ABILITY_LOSS_KEYWORDS)

    def test_materials_load_exception_returns_default(self):
        class Boom:
            def load_design(self, name):
                raise RuntimeError("boom")
        p = LedgerRuleSetProvider(project=Boom())
        rs = p.get_ruleset_for_gate()
        assert rs.EnablePledgeConstraintCheck is True

    def test_caches_ruleset_per_genre(self):
        p = LedgerRuleSetProvider(project=FakeProject(materials={
            "items": [{"Genre": "玄幻", "IsEnabled": True, "ModifiedTime": "1"}]
        }))
        rs1 = p.get_ruleset_for_gate()
        rs2 = p.get_ruleset_for_gate()
        assert rs1 is rs2

    def test_rebuilds_when_genre_changes(self):
        project = FakeProject(materials={
            "items": [{"Genre": "玄幻", "IsEnabled": True, "ModifiedTime": "1"}]
        })
        p = LedgerRuleSetProvider(project=project)
        rs1 = p.get_ruleset_for_gate()
        assert rs1.AbilityLossKeywords == list(XIANXIA_ABILITY_LOSS_KEYWORDS)

        project._materials["items"][0]["Genre"] = "都市"
        rs2 = p.get_ruleset_for_gate()
        assert rs2 is not rs1
        assert rs2.AbilityLossKeywords == list(URBAN_ABILITY_LOSS_KEYWORDS)


class TestKeywordSets:
    def test_xianxia_keywords_include_core(self):
        for kw in ("失去", "封印", "走火入魔", "反噬", "道伤"):
            assert kw in XIANXIA_ABILITY_LOSS_KEYWORDS

    def test_urban_keywords_include_core(self):
        for kw in ("解雇", "封号", "冻结", "吊销", "黑名单"):
            assert kw in URBAN_ABILITY_LOSS_KEYWORDS

    def test_keyword_sets_non_empty(self):
        assert len(XIANXIA_ABILITY_LOSS_KEYWORDS) > 0
        assert len(URBAN_ABILITY_LOSS_KEYWORDS) > 0