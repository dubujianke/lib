# -*- coding: utf-8 -*-
"""PackageHistoryService 单元测试 — 对标 Implementations/Packaging/PackageHistoryService.cs"""
import sys
import os
import tempfile
import json
import shutil

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock, AsyncMock

from novel_writer.implementations.packaging.package_history_service import PackageHistoryService


class FakeProject:
    def __init__(self, project_dir):
        self.dir = project_dir


@pytest.fixture
def svc():
    d = tempfile.mkdtemp(prefix="test_pkg_hist_")
    project = FakeProject(d)
    publish = MagicMock()
    publish.get_manifest.return_value = MagicMock(Version=1, PublishTime="2024-01-01T00:00:00")
    return PackageHistoryService(project, publish_service=publish), d


# =====================================================================
# build_enabled_summary（构建启用模块摘要）
# =====================================================================

def test_build_enabled_summary():
    summary = PackageHistoryService._build_enabled_summary({
        "Design": {"characters": True, "locations": False},
        "Generate": {"blueprint": True},
    })
    assert "Design(1/2)" in summary
    assert "Generate(1/1)" in summary


def test_build_enabled_summary_empty():
    assert PackageHistoryService._build_enabled_summary({}) == ""


def test_build_enabled_summary_all_enabled():
    summary = PackageHistoryService._build_enabled_summary({
        "Design": {"a": True, "b": True},
    })
    assert summary == "Design(2/2)"


# =====================================================================
# copy_directory（复制目录）— 使用 asyncio.run 测试 async 方法
# =====================================================================

def test_copy_directory():
    import asyncio
    src = tempfile.mkdtemp(prefix="test_cp_src_")
    dst = tempfile.mkdtemp(prefix="test_cp_dst_")
    with open(os.path.join(src, "a.txt"), "w") as f:
        f.write("a")
    os.makedirs(os.path.join(src, "sub"), exist_ok=True)
    with open(os.path.join(src, "sub", "b.txt"), "w") as f:
        f.write("b")
    asyncio.run(PackageHistoryService._copy_directory(src, dst))
    assert os.path.exists(os.path.join(dst, "a.txt"))
    assert os.path.exists(os.path.join(dst, "sub", "b.txt"))


def test_copy_directory_dest_does_not_exist():
    import asyncio
    src = tempfile.mkdtemp(prefix="test_cp_src2_")
    dst = os.path.join(tempfile.mkdtemp(prefix="test_cp_base_"), "new_dest")
    with open(os.path.join(src, "f.txt"), "w") as f:
        f.write("x")
    asyncio.run(PackageHistoryService._copy_directory(src, dst))
    assert os.path.exists(os.path.join(dst, "f.txt"))


def test_copy_directory_empty_source():
    import asyncio
    src = tempfile.mkdtemp(prefix="test_cp_empty_")
    dst = os.path.join(tempfile.mkdtemp(), "empty_dest")
    asyncio.run(PackageHistoryService._copy_directory(src, dst))
    assert os.path.exists(dst)


# =====================================================================
# save_current_to_history / get_all_history / restore_version / cleanup
# =====================================================================

def test_save_current_to_history(svc):
    s, d = svc
    assert s.save_current_to_history() is True
    assert os.path.exists(os.path.join(d, "history", "v1"))


def test_get_all_history_returns_entries(svc):
    s, d = svc
    s.save_current_to_history()
    entries = s.get_all_history()
    assert len(entries) >= 1


def test_restore_version_nonexistent(svc):
    s, d = svc
    assert s.restore_version(999) is False


def test_retain_count_property(svc):
    s, d = svc
    assert s.retain_count == 5
    s.retain_count = 3
    assert s.retain_count == 3
    s.retain_count = 0  # 应 clamp 到 1
    assert s.retain_count == 1


def test_get_version_diff(svc):
    s, d = svc
    diff = s.get_version_diff(1)
    assert diff.CurrentVersion == 1
    assert diff.HistoryVersion == 1