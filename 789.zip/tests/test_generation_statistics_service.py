# -*- coding: utf-8 -*-
"""tests for generation_statistics_service.py"""
import sys, os, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from novel_writer.implementations.generation.generation_statistics_service import (
    GenerationStatisticsService,
)


class MockProject:
    def __init__(self):
        self.dir = tempfile.mkdtemp(prefix="test_stats_")


class MockResult:
    def __init__(self):
        self.ChapterId = "vol1_ch1"
        self.Success = True
        self.total_attempts = 1
        self.RequiresManualIntervention = False
        self.Attempts = []
        self.FailureReasons = [] if not hasattr(self, 'get_last_failure_reasons') else None
    def get_last_failure_reasons(self):
        return []


def test_statistics_service_init():
    svc = GenerationStatisticsService(MockProject())
    assert svc is not None


def test_statistics_record_generation():
    svc = GenerationStatisticsService(MockProject())
    result = MockResult()
    svc.record_generation(result)
    stats = svc.get_statistics()
    assert stats.TotalGenerations == 1
    assert stats.FirstPassCount == 1


def test_statistics_summary():
    svc = GenerationStatisticsService(MockProject())
    result = MockResult()
    svc.record_generation(result)
    summary = svc.get_statistics_summary()
    assert "生成统计" in summary


def test_statistics_records():
    svc = GenerationStatisticsService(MockProject())
    result = MockResult()
    svc.record_generation(result)
    records = svc.get_recent_records(5)
    assert len(records) == 1
    assert records[0].ChapterId == "vol1_ch1"