# -*- coding: utf-8 -*-
"""SecretRevealService 单元测试 — 对标 4.1.1 SecretRevealService.cs"""
import sys
import os
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock

from novel_writer.implementations.tracking.secret_reveal_service import (
    SecretRevealService,
    compute_status,
)


class FakeStore:
    def __init__(self):
        self._data = {}

    def data(self):
        return self._data

    def set_all(self, data):
        self._data = data


class FakeProject:
    def __init__(self, **stores):
        self.dir = tempfile.mkdtemp(prefix="test_secret_")
        self._stores = dict(stores)

    def tracking(self, name):
        return self._stores.setdefault(name, FakeStore())


@pytest.fixture
def service():
    store = FakeStore()
    project = FakeProject(secret=store)
    return SecretRevealService(project), project, store


def make_change(**kwargs):
    change = MagicMock()
    change.SecretId = kwargs.get("SecretId", "S000000000001")
    change.SecretName = kwargs.get("SecretName", "")
    change.NewKnowerIds = kwargs.get("NewKnowerIds", ["C1"])
    change.Method = kwargs.get("Method", "")
    change.KeyEvent = kwargs.get("KeyEvent", "")
    change.Importance = kwargs.get("Importance", "")
    change.CausedBy = kwargs.get("CausedBy", "")
    return change


# =====================================================================
# get_secrets（查询秘密/提取快照）
# =====================================================================

def test_extract_snapshot_returns_known_secrets(service):
    svc, _, store = service
    sid = svc.update_secret_reveal("vol1_ch1", make_change(SecretId="S000000000001", NewKnowerIds=["C1"]))
    snap = svc.extract_snapshot()
    assert len(snap) == 1
    assert snap[0]["Id"] == sid
    assert snap[0]["KnowerIds"] == ["C1"]


def test_extract_snapshot_excludes_empty_knowers(service):
    svc, _, store = service
    svc.update_secret_reveal("vol1_ch1", make_change(SecretId="S000000000001", NewKnowerIds=["C1"]))
    store.data()["S000000000002"] = {"Name": "空", "KnowerIds": [], "CurrentStatus": "hidden"}
    assert len(svc.extract_snapshot()) == 1


def test_extract_snapshot_empty(service):
    svc, _, store = service
    store.data()["S000000000003"] = {"Name": "x", "KnowerIds": [], "CurrentStatus": "hidden"}
    assert svc.extract_snapshot() == []


# =====================================================================
# reveal_secret（更新/增加知情者）
# =====================================================================

def test_update_secret_reveal_creates_and_dedups_knowers(service):
    svc, _, store = service
    sid = svc.update_secret_reveal("vol1_ch1", make_change(NewKnowerIds=["C1", "C1", "C2"]))
    assert sid is not None
    assert store.data()[sid]["KnowerIds"] == ["C1", "C2"]


def test_update_secret_reveal_computes_status(service):
    svc, _, store = service
    sid = svc.update_secret_reveal("vol1_ch1", make_change(NewKnowerIds=["C1", "C2", "C3", "C4"]))
    assert store.data()[sid]["CurrentStatus"] == "widely_known"


def test_update_secret_reveal_guard_empty(service):
    svc, _, store = service
    assert svc.update_secret_reveal("vol1_ch1", make_change(SecretId="", SecretName="")) is None
    assert svc.update_secret_reveal("vol1_ch1", make_change(NewKnowerIds=[])) is None


def test_update_secret_reveal_merges_by_name(service):
    svc, _, store = service
    svc.update_secret_reveal("vol1_ch1", make_change(SecretId="S000000000001", SecretName="身世"))
    sid2 = svc.update_secret_reveal("vol1_ch2", make_change(SecretId="X", SecretName="身世",
                                                             NewKnowerIds=["C2"]))
    # 同一 Name 归并到已有 ID
    assert sid2 == "S000000000001"
    assert store.data()["S000000000001"]["KnowerIds"] == ["C1", "C2"]


# =====================================================================
# get_known_secrets（已揭示秘密列表）
# =====================================================================

def test_get_known_secrets_after_reveal(service):
    svc, _, store = service
    assert svc.extract_snapshot() == []
    svc.update_secret_reveal("vol1_ch1", make_change(NewKnowerIds=["C1"]))
    assert len(svc.extract_snapshot()) == 1


# =====================================================================
# compute_status（知情者数量分级）
# =====================================================================

def test_compute_status_levels():
    assert compute_status(0) == "hidden"
    assert compute_status(1) == "hidden"
    assert compute_status(2) == "partially_known"
    assert compute_status(3) == "partially_known"
    assert compute_status(4) == "widely_known"


# =====================================================================
# remove_chapter_data（删除历史 + 重建知情者 + 重算状态）
# =====================================================================

def test_remove_chapter_data_rebuilds_knowers(service):
    svc, _, store = service
    svc.update_secret_reveal("vol1_ch1", make_change(NewKnowerIds=["C1"]))
    svc.update_secret_reveal("vol1_ch2", make_change(NewKnowerIds=["C2"]))
    svc.remove_chapter_data("vol1_ch1")
    entry = store.data()["S000000000001"]
    assert entry["KnowerIds"] == ["C2"]
    assert entry["CurrentStatus"] == "hidden"


def test_remove_chapter_data_all_removed_returns_hidden(service):
    svc, _, store = service
    svc.update_secret_reveal("vol1_ch1", make_change(NewKnowerIds=["C1"]))
    assert svc.remove_chapter_data("vol1_ch1") == 1
    assert store.data()["S000000000001"]["CurrentStatus"] == "hidden"


def test_remove_chapter_data_no_match_returns_zero(service):
    svc, _, store = service
    svc.update_secret_reveal("vol1_ch1", make_change(NewKnowerIds=["C1"]))
    assert svc.remove_chapter_data("vol9_ch9") == 0