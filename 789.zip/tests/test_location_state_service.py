# -*- coding: utf-8 -*-
"""LocationStateService 单元测试 — 对标 4.1.1 LocationStateService.cs"""
import sys
import os
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock

from novel_writer.implementations.tracking.location_state_service import LocationStateService


class FakeStore:
    def __init__(self):
        self._data = {}

    def data(self):
        return self._data

    def set_all(self, data):
        self._data = data


class FakeProject:
    def __init__(self, **stores):
        self.dir = tempfile.mkdtemp(prefix="test_location_")
        self._stores = dict(stores)
        self.design = {}

    def tracking(self, name):
        return self._stores.setdefault(name, FakeStore())

    def load_design(self, entity):
        return self.design.get(entity, {})


@pytest.fixture
def service():
    store = FakeStore()
    project = FakeProject(location_state=store)
    return LocationStateService(project), project, store


def make_change(**kwargs):
    change = MagicMock()
    change.LocationId = kwargs.get("LocationId", "L1")
    change.LocationName = kwargs.get("LocationName", "")
    change.NewStatus = kwargs.get("NewStatus", "")
    change.Event = kwargs.get("Event", "")
    change.Importance = kwargs.get("Importance", "")
    return change


# =====================================================================
# get_all_location_states（合并全部地点）
# =====================================================================

def test_get_all_location_states_returns_entries(service):
    svc, _, store = service
    store.data()["L1"] = {"Name": "皇宫", "CurrentStatus": "contested"}
    store.data()["L2"] = {"Name": "江湖", "CurrentStatus": "normal"}
    assert set(svc.get_all_location_states().keys()) == {"L1", "L2"}


def test_get_all_location_states_skips_non_dict(service):
    svc, _, store = service
    store.data()["L1"] = "bad"
    store.data()["L2"] = {"Name": "江湖"}
    assert set(svc.get_all_location_states().keys()) == {"L2"}


def test_get_all_location_states_empty(service):
    svc, _, _ = service
    assert svc.get_all_location_states() == {}


# =====================================================================
# update_location_state（更新/注册地点状态）
# =====================================================================

def test_update_location_state_registers_with_name(service):
    svc, _, store = service
    entry = svc.update_location_state("vol1_ch1",
                                      make_change(LocationName="皇宫", NewStatus="contested"))
    assert entry["Name"] == "皇宫"
    assert entry["CurrentStatus"] == "contested"
    assert len(store.data()["L1"]["StateHistory"]) == 1


def test_update_location_state_resolves_name_when_no_hint(service):
    svc, project, store = service
    project.design["locations"] = {"items": [{"Id": "L1", "Name": "剑冢"}]}
    svc.update_location_state("vol1_ch1", make_change(NewStatus="normal"))
    assert store.data()["L1"]["Name"] == "剑冢"


def test_update_location_state_appends_history(service):
    svc, _, store = service
    svc.update_location_state("vol1_ch1", make_change())
    svc.update_location_state("vol1_ch2", make_change(NewStatus="contested"))
    assert len(store.data()["L1"]["StateHistory"]) == 2
    assert store.data()["L1"]["CurrentStatus"] == "contested"


# =====================================================================
# remove_chapter_data（删除历史 + 回填 CurrentStatus）
# =====================================================================

def test_remove_chapter_data_backfills_to_unknown(service):
    svc, _, store = service
    svc.update_location_state("vol1_ch1", make_change())
    assert svc.remove_chapter_data("vol1_ch1") == 1
    assert store.data()["L1"]["CurrentStatus"] == "unknown"


def test_remove_chapter_data_backfills_last_status(service):
    svc, _, store = service
    svc.update_location_state("vol1_ch1", make_change(NewStatus="normal"))
    svc.update_location_state("vol1_ch2", make_change(NewStatus="contested"))
    svc.remove_chapter_data("vol1_ch2")
    assert store.data()["L1"]["CurrentStatus"] == "normal"


def test_remove_chapter_data_no_match_returns_zero(service):
    svc, _, store = service
    svc.update_location_state("vol1_ch1", make_change())
    assert svc.remove_chapter_data("vol9_ch9") == 0


# =====================================================================
# try_resolve_display_name（解析地点名）
# =====================================================================

def test_try_resolve_display_name_found(service):
    svc, project, _ = service
    project.design["locations"] = {"items": [{"Id": "L1", "Name": "皇宫"}]}
    assert svc.try_resolve_display_name("L1") == "皇宫"


def test_try_resolve_display_name_not_found(service):
    svc, project, _ = service
    project.design["locations"] = {"items": [{"Id": "L1", "Name": "皇宫"}]}
    assert svc.try_resolve_display_name("L9") is None


def test_try_resolve_display_name_exception(service):
    svc, project, _ = service
    project.load_design = MagicMock(side_effect=Exception("boom"))
    assert svc.try_resolve_display_name("L1") is None