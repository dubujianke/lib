# -*- coding: utf-8 -*-
"""tests for chapter_changes_canonicalizer.py"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from novel_writer.implementations.generation.chapter_changes_canonicalizer import (
    ChapterChangesCanonicalizer, EntityMap,
)
from novel_writer.models import (
    FactSnapshot, ChapterChanges, CharacterStateChange, RelationshipChange,
    ConflictProgressChange, ForeshadowingAction, LocationStateChange,
    FactionStateChange, CharacterMovementChange, ItemTransferChange,
    SecretRevealChange, PledgeConstraintChange, DeadlineConstraintChange,
    CharacterStateEntry, LocationStateEntry, FactionStateEntry,
    ForeshadowingEntry, ConflictProgressEntry, ItemStateEntry,
    SecretEntry, PledgeEntry, DeadlineEntry,
    CharacterLocationEntry, CharacterDescription,
)

# Valid 13-char short IDs
C1 = "C000000000001"
C2 = "C000000000002"
L1 = "L000000000001"
F1 = "F000000000001"
CF1 = "CF000000000000"
FS1 = "FS00000000000"
S1 = "S000000000001"
PL1 = "PL00000000000"
DL1 = "DL00000000000"
I1 = "I000000000001"


def _make_snapshot(**kwargs):
    s = FactSnapshot()
    for k, v in kwargs.items():
        setattr(s, k, v)
    return s


def test_entity_map_add_and_contains():
    em = EntityMap()
    em.add(C1, "张三")
    em.add(L1, "北京")
    assert em.contains(C1)
    assert em.contains(L1)
    assert not em.contains("X000000000001")


def test_entity_map_ambiguous_names():
    em = EntityMap()
    em.add(C1, "张三")
    em.add(C2, "张三")  # duplicate name, different ID
    assert "张三" not in em.name_to_id  # removed due to ambiguity
    assert em.contains(C1)
    assert em.contains(C2)


def test_entity_map_add_no_name():
    em = EntityMap()
    em.add(C1, None)
    assert em.contains(C1)


class TestChapterChangesCanonicalizer:
    def test_is_forged_threshold(self):
        snapshot = _make_snapshot(CharacterStates=[])
        canon = ChapterChangesCanonicalizer(snapshot)
        canon.forged_count = 5
        canon.total_attempted = 6
        assert canon.is_forged()  # 5 >= 5 and 5*5=25 >= 6*4=24

    def test_is_forged_below_threshold(self):
        snapshot = _make_snapshot(CharacterStates=[])
        canon = ChapterChangesCanonicalizer(snapshot)
        canon.forged_count = 3
        canon.total_attempted = 10
        assert not canon.is_forged()

    def test_resolve_character_id_by_name(self):
        c1 = CharacterStateEntry(CharacterId=C1, Name="张三")
        snapshot = _make_snapshot(CharacterStates=[c1])
        canon = ChapterChangesCanonicalizer(snapshot)
        changes = ChapterChanges()
        changes.CharacterStateChanges = [CharacterStateChange(
            CharacterId="张三", KeyEvent="突破", NewLevel="筑基",
        )]
        result = canon.canonicalize(changes)
        assert result.CharacterStateChanges[0].CharacterId == C1

    def test_resolve_character_id_direct(self):
        c1 = CharacterStateEntry(CharacterId=C1, Name="张三")
        snapshot = _make_snapshot(CharacterStates=[c1])
        canon = ChapterChangesCanonicalizer(snapshot)
        changes = ChapterChanges()
        changes.CharacterStateChanges = [CharacterStateChange(
            CharacterId=C1, KeyEvent="突破",
        )]
        result = canon.canonicalize(changes)
        assert result.CharacterStateChanges[0].CharacterId == C1

    def test_resolve_location_id_create_new(self):
        snapshot = _make_snapshot(LocationStates=[], CharacterLocations=[])
        canon = ChapterChangesCanonicalizer(snapshot)
        changes = ChapterChanges()
        changes.LocationStateChanges = [LocationStateChange(
            LocationName="新地点", NewStatus="active",
        )]
        result = canon.canonicalize(changes)
        assert len(result.LocationStateChanges) > 0
        lid = result.LocationStateChanges[0].LocationId
        assert lid.startswith("L")
        assert len(lid) == 13

    def test_foreshadowing_state_machine_skip_redundant_setup(self):
        f1 = ForeshadowingEntry(ForeshadowId=FS1, Name="伏笔1", IsSetup=True, IsResolved=False)
        snapshot = _make_snapshot(ForeshadowingStatus=[f1])
        canon = ChapterChangesCanonicalizer(snapshot)
        changes = ChapterChanges()
        changes.ForeshadowingActions = [ForeshadowingAction(ForeshadowId=FS1, Action="setup")]
        result = canon.canonicalize(changes)
        assert len(result.ForeshadowingActions) == 0  # skipped

    def test_foreshadowing_state_machine_allow_payoff(self):
        f1 = ForeshadowingEntry(ForeshadowId=FS1, Name="伏笔1", IsSetup=True, IsResolved=False)
        snapshot = _make_snapshot(ForeshadowingStatus=[f1])
        canon = ChapterChangesCanonicalizer(snapshot)
        changes = ChapterChanges()
        changes.ForeshadowingActions = [ForeshadowingAction(ForeshadowId=FS1, Action="payoff")]
        result = canon.canonicalize(changes)
        assert len(result.ForeshadowingActions) == 1  # allowed

    def test_strip_by_primary_id_removes_non_id(self):
        snapshot = _make_snapshot(CharacterStates=[])
        canon = ChapterChangesCanonicalizer(snapshot)
        changes = ChapterChanges()
        changes.CharacterStateChanges = [CharacterStateChange(CharacterId="张三")]
        result = canon.canonicalize(changes)
        assert len(result.CharacterStateChanges) == 0  # stripped (name not a valid ID)

    def test_strip_empty_removes_blank_entries(self):
        snapshot = _make_snapshot(CharacterStates=[])
        canon = ChapterChangesCanonicalizer(snapshot)
        changes = ChapterChanges()
        changes.CharacterStateChanges = [CharacterStateChange(
            CharacterId=C1, KeyEvent="", NewLevel="", NewMentalState="",
            NewAbilities=[], LostAbilities=[], RelationshipChanges={},
        )]
        # C1 not in ledger (empty CharacterStates) -> stripped by primary id
        result = canon.canonicalize(changes)
        assert len(result.CharacterStateChanges) == 0

    def test_trust_delta_clamp(self):
        c1 = CharacterStateEntry(CharacterId=C1, Name="张三")
        c2 = CharacterStateEntry(CharacterId=C2, Name="李四")
        snapshot = _make_snapshot(CharacterStates=[c1, c2])
        canon = ChapterChangesCanonicalizer(snapshot)
        changes = ChapterChanges()
        changes.CharacterStateChanges = [CharacterStateChange(
            CharacterId=C1,
            RelationshipChanges={C2: RelationshipChange(TrustDelta=100)},
        )]
        result = canon.canonicalize(changes)
        assert len(result.CharacterStateChanges) > 0
        rel = result.CharacterStateChanges[0].RelationshipChanges
        assert list(rel.values())[0].TrustDelta == 30  # clamped to max

    def test_new_deterministic_id(self):
        eid = ChapterChangesCanonicalizer._new_deterministic_id("I", "ITEM|test_key")
        assert eid.startswith("I")
        assert len(eid) == 13

    def test_strip_annotations(self):
        result = ChapterChangesCanonicalizer._strip_annotations("张三（注释）")
        assert result == "张三"

    def test_blank(self):
        assert ChapterChangesCanonicalizer._blank("")
        assert ChapterChangesCanonicalizer._blank(None)
        assert ChapterChangesCanonicalizer._blank("   ")
        assert not ChapterChangesCanonicalizer._blank("a")