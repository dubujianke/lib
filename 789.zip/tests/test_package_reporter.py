# -*- coding: utf-8 -*-
"""PackageReporter 单元测试 — 对标 Implementations/Packaging/PackageReporter.cs"""
import sys
import os
import tempfile
import json

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock

from novel_writer.implementations.packaging.package_reporter import (
    PackageReporter,
    PackageReport,
    ChapterStat,
    VolumeStat,
)


class FakeProject:
    def __init__(self, project_dir):
        self.dir = project_dir

    def load_plan(self, entity):
        return {}


@pytest.fixture
def reporter():
    d = tempfile.mkdtemp(prefix="test_reporter_")
    # 创建 guide 文件供 _collect_chapter_stats 使用（第二个签名覆盖了第一个）
    guides_dir = os.path.join(d, "guides")
    os.makedirs(guides_dir, exist_ok=True)
    vol_guide = {"Chapters": {
        "vol1_ch1": {"Title": "第一章", "ContextIds": {"Characters": ["C1", "C2"], "Locations": ["L1"], "Factions": ["F1"]}, "Scenes": [{"id": "s1"}]},
        "vol1_ch2": {"Title": "第二章", "ContextIds": {"Characters": ["C1"]}, "Scenes": []},
    }}
    with open(os.path.join(guides_dir, "content_guide_vol1.json"), "w", encoding="utf-8") as f:
        json.dump(vol_guide, f)
    return PackageReporter(FakeProject(d)), d


# =====================================================================
# collect_chapter_stats（收集章节统计）
# =====================================================================

def test_collect_chapter_stats_collects(reporter):
    r, d = reporter
    report = PackageReport()
    # 第二个签名（带 config_base_path）被调用
    r._collect_chapter_stats(report, d)
    assert len(report.ChapterStats) > 0
    assert report.ChapterStats["vol1_ch1"].Characters == 2
    assert report.ChapterStats["vol1_ch1"].Scenes == 1


def test_collect_chapter_stats_from_guides(reporter):
    r, d = reporter
    guides_dir = os.path.join(d, "guides")
    os.makedirs(guides_dir, exist_ok=True)
    vol_guide = {"Chapters": {
        "vol1_ch1": {"Title": "第一章", "ContextIds": {"Characters": ["C1"]}, "Scenes": [{"id": "s1"}]},
    }}
    with open(os.path.join(guides_dir, "content_guide_vol1.json"), "w", encoding="utf-8") as f:
        json.dump(vol_guide, f)
    report = PackageReport()
    r._collect_chapter_stats(report, d)
    assert "vol1_ch1" in report.ChapterStats
    assert report.ChapterStats["vol1_ch1"].Characters == 1
    assert report.ChapterStats["vol1_ch1"].Scenes == 1


# =====================================================================
# count_array（统计数组长度）
# =====================================================================

def test_count_array_list():
    assert PackageReporter._count_array({"arr": [1, 2, 3]}, "arr") == 3


def test_count_array_not_list():
    assert PackageReporter._count_array({"arr": "not-list"}, "arr") == 0


def test_count_array_missing():
    assert PackageReporter._count_array({}, "arr") == 0


# =====================================================================
# append_anomaly（追加异常警告）
# =====================================================================

def test_append_anomaly_surge_from_zero(reporter):
    report = PackageReport()
    PackageReporter._append_anomaly(report, "ch1", "Characters", 0, 5)
    assert len(report.AnomalyWarnings) == 1
    assert "突增" in report.AnomalyWarnings[0]


def test_append_anomaly_drop_to_zero(reporter):
    report = PackageReport()
    PackageReporter._append_anomaly(report, "ch1", "Characters", 5, 0)
    assert len(report.AnomalyWarnings) == 1
    assert "锐减" in report.AnomalyWarnings[0]


def test_append_anomaly_large_ratio(reporter):
    report = PackageReport()
    PackageReporter._append_anomaly(report, "ch1", "Characters", 2, 10)
    assert len(report.AnomalyWarnings) == 1
    assert "大幅变化" in report.AnomalyWarnings[0]


def test_append_anomaly_small_diff_skips(reporter):
    report = PackageReport()
    PackageReporter._append_anomaly(report, "ch1", "Characters", 5, 6)
    assert len(report.AnomalyWarnings) == 0


def test_append_anomaly_zero_diff_skips(reporter):
    report = PackageReport()
    PackageReporter._append_anomaly(report, "ch1", "Characters", 3, 3)
    assert len(report.AnomalyWarnings) == 0


# =====================================================================
# save_report（保存报告）
# =====================================================================

def test_save_report_creates_file(reporter):
    r, d = reporter
    report = PackageReport()
    report.GeneratedAt = "2024-01-01T00:00:00"
    report.Version = 1
    report.Summary = "test"
    path = os.path.join(d, "report.json")
    PackageReporter._save_report(path, report)
    assert os.path.exists(path)
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    assert data["Version"] == 1
    assert data["Summary"] == "test"


def test_save_report_creates_intermediate_dirs(reporter):
    r, d = reporter
    report = PackageReport()
    report.GeneratedAt = "2024-01-01T00:00:00"
    report.Version = 2
    path = os.path.join(d, "sub", "nested", "report.json")
    PackageReporter._save_report(path, report)
    assert os.path.exists(path)


def test_save_report_includes_anomaly_warnings(reporter):
    r, d = reporter
    report = PackageReport()
    report.AnomalyWarnings = ["warn1"]
    path = os.path.join(d, "report.json")
    PackageReporter._save_report(path, report)
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    assert data["AnomalyWarnings"] == ["warn1"]


# =====================================================================
# run（完整运行）
# =====================================================================

def test_run_returns_report(reporter):
    r, d = reporter
    report = r.run(version=1)
    assert isinstance(report, PackageReport)
    assert report.Version == 1
    assert len(report.ChapterStats) == 2  # 两个章节


def test_run_with_previous_report(reporter):
    r, d = reporter
    prev_path = os.path.join(d, "prev.json")
    PackageReporter._save_report(prev_path, PackageReport())
    report = r.run(version=1, previous_report_path=prev_path)
    assert report is not None


def test_run_with_nonexistent_previous_report(reporter):
    r, d = reporter
    report = r.run(version=1, previous_report_path="/nonexistent/path.json")
    assert report is not None


# =====================================================================
# ChapterStat / VolumeStat to_dict
# =====================================================================

def test_chapter_stat_to_dict():
    stat = ChapterStat()
    stat.Title = "第一章"
    d = stat.to_dict()
    assert d["Title"] == "第一章"


def test_volume_stat_to_dict():
    stat = VolumeStat()
    stat.VolumeNumber = 1
    d = stat.to_dict()
    assert d["VolumeNumber"] == 1