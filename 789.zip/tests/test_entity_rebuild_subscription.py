# -*- coding: utf-8 -*-
"""tests for entity_rebuild_subscription.py"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from novel_writer.implementations.generation.entity_rebuild_subscription import (
    EntityRebuildSubscription,
)


class MockFirstChapterIndex:
    def __init__(self):
        self.entries = {"C000000000001"}
        self.invalidated = []

    def load(self):
        pass

    def contains(self, entity_id):
        return entity_id in self.entries

    def invalidate_by_entities(self, ids):
        self.invalidated.extend(ids)

    def save(self):
        pass


def test_subscription_init():
    sub = EntityRebuildSubscription()
    assert sub is not None


def test_subscription_no_first_chapter_index():
    sub = EntityRebuildSubscription()
    sub.on_entry_changed("C000000000001", "张三", "描述")
    # should not raise


def test_subscription_entry_changed_invalidates():
    idx = MockFirstChapterIndex()
    sub = EntityRebuildSubscription(first_chapter_index=idx)
    sub.on_entry_changed("C000000000001", "张三", "描述")
    assert "C000000000001" in idx.invalidated


def test_subscription_entry_changed_not_contained():
    idx = MockFirstChapterIndex()
    sub = EntityRebuildSubscription(first_chapter_index=idx)
    sub.on_entry_changed("C000000000002", "李四", "描述")
    assert len(idx.invalidated) == 0


def test_subscription_empty_id():
    sub = EntityRebuildSubscription()
    sub.on_entry_changed("", "张三", "描述")
    # should not raise