# -*- coding: utf-8 -*-
"""tests for generated_content_service.py"""
import sys, os, tempfile, asyncio
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from novel_writer.implementations.generation.generated_content_service import (
    GeneratedContentService,
)


class MockProject:
    """Mock Project for testing generated content service."""
    def __init__(self):
        self.dir = tempfile.mkdtemp(prefix="test_genct_")
        os.makedirs(os.path.join(self.dir, "generated"), exist_ok=True)
        os.makedirs(os.path.join(self.dir, "Generate", "Elements", "VolumeDesign"), exist_ok=True)
        self.generated_dir = os.path.join(self.dir, "generated")

    def load_chapter(self, chapter_id):
        path = os.path.join(self.generated_dir, f"{chapter_id}.md")
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        return ""

    def save_chapter(self, chapter_id, content):
        path = os.path.join(self.generated_dir, f"{chapter_id}.md")
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)


@pytest.fixture
def service():
    return GeneratedContentService(MockProject())


def test_service_init(service):
    assert service is not None


def test_chapter_exists_false(service):
    assert service.chapter_exists("vol1_ch1") is False


def test_save_and_get_chapter(service):
    service.save_chapter("vol1_ch1", "# 第一章\n\n内容")
    assert service.chapter_exists("vol1_ch1") is True
    content = service.get_chapter("vol1_ch1")
    assert content is not None
    assert "第一章" in content


def test_get_generated_chapters(service):
    service.save_chapter("vol1_ch1", "# 第一章\n\n内容1")
    service.save_chapter("vol1_ch2", "# 第二章\n\n内容2")
    chapters = service.get_generated_chapters()
    assert len(chapters) == 2


def test_delete_chapter(service):
    service.save_chapter("vol1_ch1", "# 第一章")
    assert service.chapter_exists("vol1_ch1") is True
    assert service.delete_chapter("vol1_ch1") is True
    assert service.chapter_exists("vol1_ch1") is False


def test_volume_exists_async(service):
    result = asyncio.run(service.volume_exists_async(1))
    assert result is False  # no volumes configured


def test_generate_next_chapter_id_invalid(service):
    with pytest.raises(ValueError, match="Invalid chapter ID"):
        asyncio.run(service.generate_next_chapter_id_from_source_async("invalid"))


def test_parse_chapter_id(service):
    vol, ch = service._parse_chapter_id("vol2_ch3")
    assert vol == 2
    assert ch == 3