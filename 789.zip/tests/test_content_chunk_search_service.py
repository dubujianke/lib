# -*- coding: utf-8 -*-
"""ContentChunkSearchService 单元测试 — 对标 Implementations/Indexing/ContentChunkSearchService.cs"""
import sys
import os
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock, patch

from novel_writer.implementations.indexing.content_chunk_search_service import (
    ContentChunkSearchService,
)


class FakeProject:
    def __init__(self, project_dir):
        self.dir = project_dir


@pytest.fixture
def search():
    project_dir = tempfile.mkdtemp(prefix="test_chunk_")
    project = FakeProject(project_dir)
    return ContentChunkSearchService(project), project_dir


# =====================================================================
# search（搜索查询）
# =====================================================================

def test_search_empty_query_returns_empty(search):
    svc, _ = search
    assert svc.search("", top_k=5) == []


def test_search_no_files_returns_empty(search):
    svc, project_dir = search
    assert svc.search("战斗", top_k=5) == []


def test_search_with_md_files_returns_results(search):
    svc, project_dir = search
    with open(os.path.join(project_dir, "vol1_ch1.md"), "w", encoding="utf-8") as f:
        f.write("这是关于战斗和修炼的章节\n\n内容很多\n\n" * 50)
    results = svc.search("战斗", top_k=3)
    assert len(results) > 0
    assert results[0]["chapter_id"] == "vol1_ch1"


# =====================================================================
# invalidate_chapter（失效某章节缓存）
# =====================================================================

def test_invalidate_chapter_removes_cache(search):
    svc, project_dir = search
    with open(os.path.join(project_dir, "vol1_ch1.md"), "w", encoding="utf-8") as f:
        f.write("正文内容\n\n" * 50)
    svc.search("正文", top_k=3)
    assert "vol1_ch1" in svc._fallback_chunk_cache
    svc.invalidate_chapter("vol1_ch1")
    assert "vol1_ch1" not in svc._fallback_chunk_cache


def test_invalidate_chapter_empty_does_nothing(search):
    svc, _ = search
    svc.invalidate_chapter("")  # 不报错


def test_invalidate_chapter_nonexistent(search):
    svc, _ = search
    svc.invalidate_chapter("NOPE")  # 不报错


# =====================================================================
# invalidate_cache（全局失效缓存）
# =====================================================================

def test_invalidate_cache_clears_all(search):
    svc, project_dir = search
    svc._fallback_chunk_cache["vol1_ch1"] = []
    svc._fallback_lru = ["vol1_ch1"]
    svc._cached_target_size = 500
    svc.invalidate_cache()
    assert svc._fallback_chunk_cache == {}
    assert svc._fallback_lru == []
    assert svc._cached_target_size == -1


# =====================================================================
# touch_fallback_lru（LRU 更新）
# =====================================================================

def test_touch_fallback_lru_moves_to_end(search):
    svc, _ = search
    svc._fallback_lru = ["a", "b", "c"]
    svc._touch_fallback_lru("a")
    assert svc._fallback_lru == ["b", "c", "a"]


def test_touch_fallback_lru_adds_new(search):
    svc, _ = search
    svc._touch_fallback_lru("new")
    assert svc._fallback_lru == ["new"]


# =====================================================================
# calculate_relevance（BM25 相关性计算）
# =====================================================================

def test_calculate_relevance_positive(search):
    score = ContentChunkSearchService._calculate_relevance(["战斗"], "战斗 修炼 战斗")
    assert score > 0


def test_calculate_relevance_zero_when_no_match(search):
    score = ContentChunkSearchService._calculate_relevance(["战斗"], "修炼 和平")
    assert score == 0.0


def test_calculate_relevance_empty_terms(search):
    assert ContentChunkSearchService._calculate_relevance([], "内容") == 0.0


def test_calculate_relevance_empty_content(search):
    assert ContentChunkSearchService._calculate_relevance(["战斗"], "") == 0.0


# =====================================================================
# count_occurrences（字频统计）
# =====================================================================

def test_count_occurrences_case_insensitive(search):
    count = ContentChunkSearchService._count_occurrences("AaA", "a")
    assert count == 3


def test_count_occurrences_zero(search):
    assert ContentChunkSearchService._count_occurrences("", "a") == 0
    assert ContentChunkSearchService._count_occurrences("内容", "x") == 0


def test_count_occurrences_empty_needle(search):
    assert ContentChunkSearchService._count_occurrences("内容", "") == 0