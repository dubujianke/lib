# -*- coding: utf-8 -*-
"""ChunkEmbeddingIndex 单元测试 — 对标 Implementations/Indexing/ChunkEmbeddingIndex.cs"""
import sys
import os
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock

from novel_writer.vector_index import ChunkEmbeddingIndex, VectorSearchHit


@pytest.fixture
def index():
    d = tempfile.mkdtemp(prefix="test_chunk_emb_")
    return ChunkEmbeddingIndex(d)


# =====================================================================
# upsert（插入/更新向量）
# =====================================================================

def test_upsert_adds_entry(index):
    assert index.upsert("vol1_ch1#0", [0.1, 0.2, 0.3]) is True
    assert index.count == 1


def test_upsert_empty_key_returns_false(index):
    assert index.upsert("", [0.1, 0.2]) is False


def test_upsert_empty_vector_returns_false(index):
    assert index.upsert("k1", []) is False


def test_upsert_dimension_mismatch_returns_false(index):
    index.upsert("k1", [0.1, 0.2])
    assert index.upsert("k2", [0.1]) is False  # 不同维度


# =====================================================================
# remove（删除条目）
# =====================================================================

def test_remove_existing(index):
    index.upsert("vol1_ch1#0", [0.1, 0.2])
    assert index.remove("vol1_ch1#0") is True
    assert index.count == 0


def test_remove_nonexistent_returns_false(index):
    assert index.remove("NOPE") is False


def test_remove_empty_key_returns_false(index):
    assert index.remove("") is False


# =====================================================================
# search（向量搜索）
# =====================================================================

def test_search_returns_top_k(index):
    index.upsert("a", [1.0, 0.0])
    index.upsert("b", [0.0, 1.0])
    results = index.search([1.0, 0.0], top_k=1)
    assert len(results) == 1
    assert results[0].key == "a"


def test_search_empty_index_returns_empty(index):
    assert index.search([1.0, 0.0], top_k=5) == []


def test_search_empty_query_returns_empty(index):
    index.upsert("a", [1.0, 0.0])
    assert index.search([], top_k=5) == []


def test_search_top_k_caps_results(index):
    index.upsert("a", [1.0, 0.0])
    index.upsert("b", [0.9, 0.1])
    index.upsert("c", [0.8, 0.2])
    assert len(index.search([1.0, 0.0], top_k=2)) == 2


# =====================================================================
# remove_sync（通过 remove_by_chapter 批量删除）
# =====================================================================

def test_remove_by_chapter_removes_all_chunks(index):
    index.upsert("vol1_ch1#0", [0.1, 0.2])
    index.upsert("vol1_ch1#1", [0.3, 0.4])
    index.upsert("vol1_ch2#0", [0.5, 0.6])
    assert index.remove_by_chapter("vol1_ch1") == 2
    assert index.count == 1


def test_remove_by_chapter_nonexistent(index):
    assert index.remove_by_chapter("NOPE") == 0


def test_remove_by_chapter_empty_returns_zero(index):
    assert index.remove_by_chapter("") == 0


# =====================================================================
# 额外：get_by_chapter / search_within_chapters
# =====================================================================

def test_get_by_chapter_returns_sorted(index):
    index.upsert("vol1_ch1#1", [0.3, 0.4])
    index.upsert("vol1_ch1#0", [0.1, 0.2])
    results = index.get_by_chapter("vol1_ch1")
    assert len(results) == 2
    assert results[0][1] == 0  # position 0 first
    assert results[1][1] == 1


def test_search_within_chapters_limits(index):
    index.upsert("vol1_ch1#0", [1.0, 0.0])
    index.upsert("vol1_ch2#0", [0.0, 1.0])
    results = index.search_within_chapters([1.0, 0.0], ["vol1_ch1"], top_k=5)
    assert len(results) == 1
    assert results[0].key == "vol1_ch1#0"