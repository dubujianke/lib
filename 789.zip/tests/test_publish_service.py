# -*- coding: utf-8 -*-
"""tests for publish_service.py"""
import sys, os, json, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock, patch
from novel_writer.implementations.packaging.publish_service import PublishService
from novel_writer.models.publishing.publish_result import PublishResult, ManifestInfo, StatisticsInfo


class MockProject:
    def __init__(self):
        self.dir = tempfile.mkdtemp(prefix="test_publish_")
        self.name = "TestProject"
        self._design = {}
        self._plan = {}
        self.design_dir = os.path.join(self.dir, "design")
        self.plan_dir = os.path.join(self.dir, "plan")
        os.makedirs(self.design_dir, exist_ok=True)
        os.makedirs(self.plan_dir, exist_ok=True)

    def set_design(self, entity, data):
        self._design[entity] = data

    def set_plan(self, entity, data):
        self._plan[entity] = data

    def load_design(self, entity):
        return self._design.get(entity, [])

    def load_plan(self, entity):
        return self._plan.get(entity, [])

    def make_module_data(self):
        """提供最小模块数据集（对标 C# Modules/{Type}/{SubModule}/{FunctionDir} 布局，
        Python 存储为 {dir}/{Type}/{SubModule}/{FunctionDir}），用于通过两道闸门。"""
        layout = {
            ("Design", "GlobalSettings"): {"WorldRules": [{"Id": "world_1", "Name": "低武", "IsEnabled": True}]},
            ("Design", "Elements"): {
                "CharacterRules": [{"Id": "char_1", "Name": "林动", "IsEnabled": True}],
                "FactionRules": [{"Id": "fac_1", "Name": "青阳镇", "IsEnabled": True}],
                "LocationRules": [{"Id": "loc_1", "Name": "青阳镇", "IsEnabled": True}],
                "PlotRules": [{"Id": "plot_1", "Name": "主线", "IsEnabled": True}],
            },
            ("Generate", "GlobalSettings"): {"Outline": [{"Id": "outline_1", "IsEnabled": True, "TotalChapterCount": 1}]},
            ("Generate", "Elements"): {
                "VolumeDesign": [{"Id": "vol_1", "VolumeNumber": 1, "VolumeTitle": "开端", "IsEnabled": True}],
                "Chapter": [{"Id": "vol1_ch1", "ChapterNumber": 1, "Volume": "第1卷",
                             "ChapterTitle": "第一章 启程", "IsEnabled": True}],
                "Blueprint": [{"Id": "bp_1", "ChapterId": "vol1_ch1", "IsEnabled": True}],
            },
        }
        for (module_type, sub_module), funcs in layout.items():
            for func_dir, items in funcs.items():
                d = os.path.join(self.dir, module_type, sub_module, func_dir)
                os.makedirs(d, exist_ok=True)
                with open(os.path.join(d, "data.json"), "w", encoding="utf-8") as f:
                    json.dump(items, f, ensure_ascii=False)
        # plan 数据（guide 生成/统计用；完整 build_* 链路要求 outline 有 Id）
        self.set_plan("outline", [{"Id": "outline_1", "IsEnabled": True, "TotalChapterCount": 1}])
        self.set_plan("volumes", [{"Id": "vol_1", "VolumeNumber": 1, "VolumeTitle": "开端", "IsEnabled": True}])
        self.set_plan("chapters", [{"Id": "vol1_ch1", "ChapterNumber": 1, "Volume": "第1卷",
                                    "ChapterTitle": "第一章 启程", "IsEnabled": True}])
        # design 数据（GuideIndexBuilder._load_all 走 load_design）
        self.set_design("characters", [{"Id": "char_1", "Name": "林动", "IsEnabled": True}])
        self.set_design("factions", [{"Id": "fac_1", "Name": "青阳镇", "IsEnabled": True}])
        self.set_design("locations", [{"Id": "loc_1", "Name": "青阳镇", "IsEnabled": True}])
        self.set_design("plot", [{"Id": "plot_1", "Name": "主线", "IsEnabled": True}])
        # 蓝图 plan 数据（build_blueprint_guide 经 load_plan('blueprints_{chapterId}') 汇总）
        self.set_plan("blueprints_vol1_ch1", [{"Id": "bp_1", "Name": "第1章蓝图",
                                               "ChapterId": "vol1_ch1", "IsEnabled": True}])


@pytest.fixture
def service():
    return PublishService(MockProject())


# --- init ---

def test_init(service):
    assert service is not None
    assert service._manifest_cache is None


# --- get_manifest with no manifest file ---

def test_get_manifest_no_file(service):
    manifest = service.get_manifest()
    assert manifest is None


# --- get_manifest with valid manifest file ---

def test_get_manifest_valid(service):
    manifest_data = {
        "ProjectName": "TestProject",
        "PublishTime": "2024-01-01T00:00:00",
        "Version": 3,
        "Files": {},
        "EnabledModules": {},
        "Statistics": {"TotalCharacters": 5, "TotalLocations": 3, "TotalChapters": 10, "TotalWords": 0},
    }
    path = os.path.join(service.project.dir, "manifest.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(manifest_data, f)
    manifest = service.get_manifest()
    assert manifest is not None
    assert manifest.ProjectName == "TestProject"
    assert manifest.Version == 3
    assert manifest.Statistics.TotalCharacters == 5


# --- get_manifest with corrupted file ---

def test_get_manifest_corrupted(service):
    path = os.path.join(service.project.dir, "manifest.json")
    with open(path, "w", encoding="utf-8") as f:
        f.write("not json")
    manifest = service.get_manifest()
    assert manifest is None


# --- get_manifest caching ---

def test_get_manifest_caching(service):
    manifest_data = {
        "ProjectName": "Test", "PublishTime": "", "Version": 1,
        "Files": {}, "EnabledModules": {}, "Statistics": {},
    }
    path = os.path.join(service.project.dir, "manifest.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(manifest_data, f)
    m1 = service.get_manifest()
    # remove file, cache should still return
    os.remove(path)
    m2 = service.get_manifest()
    assert m2 is not None
    assert m2.ProjectName == "Test"


# --- needs_republish ---

def test_needs_republish_no_manifest(service):
    assert service.needs_republish() is True


def test_needs_republish_with_manifest(service):
    manifest_data = {"ProjectName": "T", "PublishTime": "", "Version": 1, "Files": {}, "EnabledModules": {}, "Statistics": {}}
    path = os.path.join(service.project.dir, "manifest.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(manifest_data, f)
    # 对标 C# NeedsRepublish: GetChangedModules().Count > 0
    # 空项目下所有模块为 Never（视为已变更），需要重发布
    assert service.needs_republish() is True
    # 缓存 manifest 后仍以变更模块为准
    service.get_manifest()
    assert service.needs_republish() is True


# --- clear_cache ---

def test_clear_cache(service):
    manifest_data = {"ProjectName": "T", "PublishTime": "", "Version": 1, "Files": {}, "EnabledModules": {}, "Statistics": {}}
    path = os.path.join(service.project.dir, "manifest.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(manifest_data, f)
    service.get_manifest()
    service.clear_cache()
    assert service._manifest_cache is None
    os.remove(path)
    assert service.needs_republish() is True


# --- publish success ---

def test_publish_success(service):
    service.project.set_design("characters", [{"Name": "A"}, {"Name": "B"}])
    service.project.set_design("locations", [{"Name": "L1"}])
    service.project.set_plan("chapters", [{"Name": "Ch1"}])
    result = service.publish()
    assert result.IsSuccess is True
    assert result.Version == 1
    # verify manifest was written
    manifest_path = os.path.join(service.project.dir, "manifest.json")
    assert os.path.exists(manifest_path)
    with open(manifest_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    assert data["Version"] == 1
    assert data["Statistics"]["TotalCharacters"] == 2
    assert data["Statistics"]["TotalLocations"] == 1
    assert data["Statistics"]["TotalChapters"] == 1


# --- publish with version increment ---

def test_publish_version_increment(service):
    # create initial manifest
    manifest_data = {"ProjectName": "T", "PublishTime": "2024-01-01", "Version": 2, "Files": {}, "EnabledModules": {}, "Statistics": {}}
    path = os.path.join(service.project.dir, "manifest.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(manifest_data, f)
    service.get_manifest()  # populate cache
    result = service.publish()
    assert result.Version == 3


# --- publish with enabled_modules ---

def test_publish_with_enabled_modules(service):
    result = service.publish({"Design": {"world": True}})
    assert result.IsSuccess is True
    manifest_path = os.path.join(service.project.dir, "manifest.json")
    with open(manifest_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    assert data["EnabledModules"] == {"Design": {"world": True}}


# --- publish failure ---

def test_publish_failure(service):
    with patch.object(service, "_generate_guides", side_effect=Exception("disk error")):
        result = service.publish()
        assert result.IsSuccess is False
        assert "disk error" in result.Message or "打包失败" in result.Message


# --- _generate_guides creates directory ---

def test_generate_guides_creates_dir(service):
    service._generate_guides()
    guides_dir = os.path.join(service.project.dir, "guides")
    assert os.path.isdir(guides_dir)


# --- _build_statistics ---

def test_build_statistics(service):
    service.project.set_design("characters", [{"Name": "A"}, {"Name": "B"}, {"Name": "C"}])
    service.project.set_design("locations", [{"Name": "L1"}])
    service.project.set_plan("chapters", [{"Name": "Ch1"}, {"Name": "Ch2"}])
    stats = service._build_statistics()
    assert stats.TotalCharacters == 3
    assert stats.TotalLocations == 1
    assert stats.TotalChapters == 2
    assert stats.TotalWords == 0


# --- _load_design ---

def test_load_design_dict(service):
    service.project.set_design("world", {"items": [{"Name": "R1"}]})
    result = service._load_design("world")
    assert result == [{"Name": "R1"}]


def test_load_design_list(service):
    service.project.set_design("world", [{"Name": "R1"}])
    result = service._load_design("world")
    assert result == [{"Name": "R1"}]


# --- _load_plan ---

def test_load_plan_list(service):
    service.project.set_plan("chapters", [{"Name": "Ch1"}])
    result = service._load_plan("chapters")
    assert result == [{"Name": "Ch1"}]


def test_load_plan_dict(service):
    service.project.set_plan("chapters", {"chapters": [{"Name": "Ch1"}]})
    result = service._load_plan("chapters")
    assert result == [{"Name": "Ch1"}]


# --- _now ---

def test_now_format(service):
    now = service._now()
    assert "T" in now
    assert len(now) == 19  # YYYY-MM-DDTHH:MM:SS


# --- publish caches manifest ---

def test_publish_caches_manifest(service):
    result = service.publish()
    assert service._manifest_cache is not None
    assert service._manifest_cache.Version == 1


# --- _save_manifest atomic write ---

def test_save_manifest_atomic(service):
    stats = StatisticsInfo(TotalCharacters=0, TotalLocations=0, TotalChapters=0, TotalWords=0)
    manifest = ManifestInfo(ProjectName="Test", PublishTime="now", Version=1, Files={}, EnabledModules={}, Statistics=stats)
    service._save_manifest(manifest)
    path = os.path.join(service.project.dir, "manifest.json")
    tmp_path = path + ".tmp"
    assert os.path.exists(path)
    assert not os.path.exists(tmp_path)  # tmp should be cleaned up


# ---- 追加测试 ----

class TestPublishServiceNewMethods:
    @pytest.fixture
    def service(self):
        return PublishService(MockProject())

    def test_publish_all(self, service):
        result = service.publish_all()
        assert isinstance(result, dict) or hasattr(result, 'IsSuccess')

    def test_publish_all_empty_project_blocked_by_missing_data(self, service):
        # 空项目无任何模块数据 → 闸门1（缺失数据阻断）应拦截（对标 C# PublishAllInternalAsync 55-83）
        result = service.publish_all()
        assert result.IsSuccess is False
        assert "以下业务尚未构建数据" in result.Message

    def test_publish_all_with_minimal_data(self, service):
        service.project.make_module_data()
        result = service.publish_all()
        assert result.IsSuccess is True, f"{result.Message} / {result.ErrorDetail}"

    def test_publish_module(self, service):
        # 空项目无模块数据 → 闸门1 应阻断（对标 C# PublishModuleInternalAsync 256-285）
        result = service.publish_module("Design")
        assert hasattr(result, "IsSuccess") or hasattr(result, "Success")
        ok = getattr(result, "IsSuccess", None)
        if ok is None:
            ok = getattr(result, "Success", False)
        assert ok is False
        assert "以下业务尚未构建数据" in result.Message

    def test_publish_module_with_minimal_data(self, service):
        # 单模块打包基于已有 Config（对标 PrepareStagingConfigFromExistingAsync），
        # 且序后校验要求 4 件套齐全（对标 ValidateStagingIntegrityAsync 无条件检查），
        # 故先完成一次全量打包，再单独重打 Design。
        service.project.make_module_data()
        first = service.publish_all()
        assert first.IsSuccess is True, f"{first.Message} / {first.ErrorDetail}"
        result = service.publish_module("Design")
        assert result.IsSuccess is True, f"{result.Message} / {result.ErrorDetail}"

    def test_get_publish_status(self, service):
        status = service.get_publish_status()
        assert isinstance(status, dict)
        assert "is_published" in status
        assert "needs_republish" in status

    def test_refresh_service_caches(self, service):
        service._manifest_cache = {"fake": "cache"}
        service._refresh_service_caches()
        assert service._manifest_cache is None

    def test_notify_completeness_warnings(self, service):
        service._notify_completeness_warnings(None)  # should not raise
        service._notify_completeness_warnings(type("W", (), {"EmptyContextWarnings": ["a"], "ForeshadowingWarnings": [], "ConflictWarnings": []})())

    def test_check_end_chapter_configuration(self, service):
        result = service._check_end_chapter_configuration()
        assert result is None

    def test_check_volume_completeness_before_publish(self, service):
        result = service._check_volume_completeness_before_publish()
        assert result is None or isinstance(result, dict)

    def test_build_volume_category_name(self, service):
        name = service._build_volume_category_name({"VolumeNumber": 3, "VolumeTitle": "高潮"})
        assert "第3卷" in name
        assert "高潮" in name

    def test_build_volume_category_name_no_title(self, service):
        name = service._build_volume_category_name({"VolumeNumber": 1})
        assert "第1卷" in name

    def test_has_real_chapter_title(self, service):
        assert service._has_real_chapter_title("第一章 启程") is True
        assert service._has_real_chapter_title("第一章") is False
        assert service._has_real_chapter_title("") is False
        assert service._has_real_chapter_title(None) is False

    def test_run_preflight(self, service):
        result = service._run_preflight()
        assert result is None

    def test_package_module(self, service):
        result = service._package_module({}, "")
        assert result is None

    def test_update_manifest(self, service):
        manifest_path = os.path.join(service.project.dir, "manifest.json")
        version = service._update_manifest(manifest_path, service.project.dir)
        assert version > 0

    def test_count_words(self, service):
        count = service._count_words()
        assert isinstance(count, int)

    def test_count_chinese_words(self, service):
        assert service._count_chinese_words("你好世界") == 4
        assert service._count_chinese_words("hello") == 0
        assert service._count_chinese_words("") == 0
        assert service._count_chinese_words(None) == 0

    def test_count_characters(self, service):
        count = service._count_characters(service.project.dir)
        assert isinstance(count, int)

    def test_count_locations(self, service):
        count = service._count_locations(service.project.dir)
        assert isinstance(count, int)

    def test_create_backup(self, service):
        backup_path = service._create_backup()
        assert backup_path != ""

    def test_restore_backup(self, service):
        # create a backup first
        backup_path = service._create_backup()
        service._restore_backup(backup_path)  # should not raise
        assert not os.path.exists(backup_path)

    def test_copy_directory(self, service):
        src = os.path.join(service.project.dir, "src")
        dst = os.path.join(service.project.dir, "dst")
        os.makedirs(src, exist_ok=True)
        with open(os.path.join(src, "test.txt"), "w") as f:
            f.write("content")
        service._copy_directory(src, dst)
        assert os.path.exists(os.path.join(dst, "test.txt"))

    def test_ensure_directories_exist(self, service):
        service._ensure_directories_exist()
        assert os.path.exists(os.path.join(service.project.dir, "config", "Design"))
        assert os.path.exists(os.path.join(service.project.dir, "config", "Generate"))

    def test_prepare_staging_config(self, service):
        service._prepare_staging_config()
        staging = os.path.join(service.project.dir, "Config.staging")
        assert os.path.isdir(staging)
        assert os.path.isdir(os.path.join(staging, "Design"))

    def test_prepare_staging_config_from_existing(self, service):
        service._prepare_staging_config_from_existing()
        staging = os.path.join(service.project.dir, "Config.staging")
        assert os.path.isdir(staging)

    def test_promote_staging(self, service):
        service._prepare_staging_config()
        service._promote_staging()
        config_path = os.path.join(service.project.dir, "config")
        assert os.path.isdir(config_path)

    def test_cleanup_staging(self, service):
        service._prepare_staging_config()
        service._cleanup_staging()
        staging = os.path.join(service.project.dir, "Config.staging")
        assert not os.path.exists(staging)

    def test_collect_invalid_ids(self, service):
        errors = []
        service._collect_invalid_ids({"items": ["c1", "c2", "c3"]}, "items", {"c1", "c3"}, "ch1", "角色", errors)
        assert len(errors) == 1
        assert "c2" in errors[0]

    def test_collect_invalid_ids_no_invalid(self, service):
        errors = []
        service._collect_invalid_ids({"items": ["c1", "c2"]}, "items", {"c1", "c2"}, "ch1", "角色", errors)
        assert len(errors) == 0

    def test_generate_guide_files(self, service):
        config_base = os.path.join(service.project.dir, "config")
        os.makedirs(config_base, exist_ok=True)
        # 新行为（对标 C# 36-39 行）: 空项目无蓝图章节 → 抛"章节指导为空（0章）"
        with pytest.raises(RuntimeError, match="0章"):
            service._generate_guide_files(config_base)
        # guides 目录在生成前已创建
        assert os.path.exists(os.path.join(config_base, "guides"))

    def test_generate_guide_files_with_data(self, service):
        service.project.make_module_data()
        config_base = os.path.join(service.project.dir, "config")
        os.makedirs(config_base, exist_ok=True)
        service._generate_guide_files(config_base)
        guides = os.path.join(config_base, "guides")
        # 完整链路: outline/planning/blueprint/content 分片/伏笔
        for fn in ("outline_guide.json", "planning_guide.json", "blueprint_guide.json",
                   "content_guide_vol1.json", "foreshadowing_status_guide.json"):
            assert os.path.exists(os.path.join(guides, fn)), fn
        # 不应残留旧版未分片 content_guide.json
        assert not os.path.exists(os.path.join(guides, "content_guide.json"))

    def test_generate_guide_files_cleans_stale_shards(self, service):
        # 缺口2: 生成本次分片后，删除不在分片集合中的旧 content_guide_volN.json
        service.project.make_module_data()
        config_base = os.path.join(service.project.dir, "config")
        guides = os.path.join(config_base, "guides")
        os.makedirs(guides, exist_ok=True)
        stale = os.path.join(guides, "content_guide_vol9.json")
        with open(stale, "w", encoding="utf-8") as f:
            json.dump({"Chapters": {}}, f)
        service._generate_guide_files(config_base)
        assert not os.path.exists(stale)
        assert os.path.exists(os.path.join(guides, "content_guide_vol1.json"))

    def test_generate_guide_files_merges_existing_foreshadowing(self, service):
        # 缺口1: 既有伏笔追踪状态（5 字段）回填到新生成的 guide
        service.project.make_module_data()
        config_base = os.path.join(service.project.dir, "config")
        guides = os.path.join(service.project.dir, "guides")
        os.makedirs(guides, exist_ok=True)
        with open(os.path.join(guides, "foreshadowing_status_guide.json"), "w", encoding="utf-8") as f:
            json.dump({"Foreshadowings": {"plot_1": {
                "IsSetup": True, "IsResolved": True,
                "ActualSetupChapter": "vol1_ch1", "ActualPayoffChapter": "vol1_ch2",
                "IsOverdue": False}}}, f, ensure_ascii=False)
        service._generate_guide_files(config_base)
        with open(os.path.join(config_base, "guides", "foreshadowing_status_guide.json"),
                  "r", encoding="utf-8") as f:
            doc = json.load(f)
        entry = doc["Foreshadowings"]["plot_1"]
        assert entry["IsSetup"] is True
        assert entry["IsResolved"] is True
        assert entry["ActualSetupChapter"] == "vol1_ch1"
        assert entry["ActualPayoffChapter"] == "vol1_ch2"
        assert entry["IsOverdue"] is False

    def test_generate_guide_files_calls_ledger_trim(self, service):
        # 缺口3: 末尾调用 LedgerTrimService.trim_all()（非致命）
        service.project.make_module_data()
        called = []
        service._ledger_trim_service = type("M", (), {"trim_all": staticmethod(
            lambda: called.append(1))})()
        service._generate_guide_files(os.path.join(service.project.dir, "config"))
        assert len(called) == 1
        # trim 抛异常不阻断
        class Boom:
            def trim_all(self):
                called.append(2)
                raise RuntimeError("trim err")
        service._ledger_trim_service = Boom()
        service._generate_guide_files(os.path.join(service.project.dir, "config"))
        assert len(called) == 2

    def test_generate_guide_files_blocks_bad_story_phase(self, service):
        # 剧情规则 StoryPhase 形似章节ID但章节不存在 → Error 阻断
        service.project.make_module_data()
        bad = [{"Id": "plot_1", "Name": "主线", "StoryPhase": "vol9_ch99", "IsEnabled": True}]
        plot_dir = os.path.join(service.project.dir, "Design", "Elements", "PlotRules")
        with open(os.path.join(plot_dir, "plot_rules.json"), "w", encoding="utf-8") as f:
            json.dump(bad, f, ensure_ascii=False)
        service.project.set_design("plot", bad)
        with pytest.raises(RuntimeError, match="剧情规则章节归属校验失败"):
            service._generate_guide_files(os.path.join(service.project.dir, "config"))

    # ---- 闸门 1: 缺失数据阻断（对标 PublishAllInternalAsync 55-83 / PublishModuleInternalAsync 256-285）----

    def test_check_missing_build_data_all_present(self, service):
        service.project.make_module_data()
        mappings = service._get_package_mappings()
        assert service._check_missing_build_data(mappings) is None

    def test_check_missing_build_data_empty_project(self, service):
        mappings = service._get_package_mappings()
        missing = service._check_missing_build_data(mappings)
        assert missing is not None
        assert "全局设定/世界观规则" in missing
        assert "设计元素/角色规则" in missing

    def test_check_missing_build_data_partial(self, service):
        service.project.make_module_data()
        # 抽走 Design/Elements/PlotRules 数据
        d = os.path.join(service.project.dir, "Design", "Elements", "PlotRules")
        for fn in os.listdir(d):
            os.remove(os.path.join(d, fn))
        mappings = [m for m in service._get_package_mappings() if m["module_type"] == "Design"]
        missing = service._check_missing_build_data(mappings)
        assert missing == ["设计元素/剧情规则"]

    def test_package_mappings_have_sub_directories(self, service):
        mappings = service._get_package_mappings()
        assert len(mappings) == 4
        for m in mappings:
            assert "sub_directories" in m and m["sub_directories"]
        by_key = {(m["module_type"], m["sub_module"]): m for m in mappings}
        assert by_key[("Design", "Elements")]["sub_directories"] == [
            "CharacterRules", "FactionRules", "LocationRules", "PlotRules"]
        assert by_key[("Generate", "Elements")]["sub_directories"] == [
            "VolumeDesign", "Chapter", "Blueprint"]
        assert by_key[("Design", "GlobalSettings")]["sub_directories"] == ["WorldRules"]
        assert by_key[("Generate", "GlobalSettings")]["sub_directories"] == ["Outline"]

    # ---- 闸门 2: 序后完整性校验（对标 ValidateStagingIntegrityAsync）----

    def _make_staging(self, service):
        service.project.make_module_data()
        service._prepare_staging_config()
        staging = service._get_staging_config_path(service.project.dir)
        for mapping in service._get_package_mappings():
            service._package_module(mapping, staging, [])
        service._generate_guide_files(staging)
        return staging

    def test_validate_staging_integrity_pass(self, service):
        staging = self._make_staging(service)
        errors = service._validate_staging_integrity(staging)
        assert errors == []

    def test_validate_staging_integrity_missing_four_files(self, service):
        staging = os.path.join(service.project.dir, "Config.staging")
        os.makedirs(staging, exist_ok=True)
        errors = service._validate_staging_integrity(staging)
        assert errors == [
            "Design/globalsettings.json 缺失",
            "Design/elements.json 缺失",
            "Generate/globalsettings.json 缺失",
            "Generate/elements.json 缺失",
        ]

    def test_validate_staging_integrity_missing_guides(self, service):
        service.project.make_module_data()
        service._prepare_staging_config()
        staging = service._get_staging_config_path(service.project.dir)
        for mapping in service._get_package_mappings():
            service._package_module(mapping, staging, [])
        # 不生成 guides → 校验失败
        errors = service._validate_staging_integrity(staging)
        assert errors == ["guides/ 目录缺失"]

    def test_validate_staging_integrity_no_shard(self, service):
        service.project.make_module_data()
        service._prepare_staging_config()
        staging = service._get_staging_config_path(service.project.dir)
        for mapping in service._get_package_mappings():
            service._package_module(mapping, staging, [])
        os.makedirs(os.path.join(staging, "guides"), exist_ok=True)  # guides 存在但无分片
        errors = service._validate_staging_integrity(staging)
        assert errors == ["content_guide 分片文件未生成（应至少 1 个 content_guide_volN.json）"]

    def test_validate_staging_integrity_invalid_ids(self, service):
        staging = self._make_staging(service)
        # 在 content_guide 分片中注入无效角色 ID
        shard = os.path.join(staging, "guides", "content_guide_vol1.json")
        with open(shard, "r", encoding="utf-8") as f:
            doc = json.load(f)
        doc["Chapters"]["vol1_ch1"]["ContextIds"] = {"Characters": ["char_1", "ghost_id"]}
        with open(shard, "w", encoding="utf-8") as f:
            json.dump(doc, f, ensure_ascii=False)
        errors = service._validate_staging_integrity(staging)
        assert len(errors) == 1
        assert "vol1_ch1" in errors[0]
        assert "ghost_id" in errors[0]
        assert "角色" in errors[0]

    def test_validate_staging_integrity_case_insensitive_ids(self, service):
        staging = self._make_staging(service)
        shard = os.path.join(staging, "guides", "content_guide_vol1.json")
        with open(shard, "r", encoding="utf-8") as f:
            doc = json.load(f)
        # 大小写不同但 ID 一致 → 有效（对标 OrdinalIgnoreCase）
        doc["Chapters"]["vol1_ch1"]["ContextIds"] = {"Characters": ["CHAR_1"]}
        with open(shard, "w", encoding="utf-8") as f:
            json.dump(doc, f, ensure_ascii=False)
        errors = service._validate_staging_integrity(staging)
        assert errors == []

    def test_collect_ids_from_elements(self, service):
        elements_path = os.path.join(service.project.dir, "elements.json")
        payload = {"data": {"characterrules": {
            "characterrules": [{"Id": "Char_A"}, {"Id": "  "}, {"Name": "no-id"}, {"Id": "Char_B"}]}}}
        with open(elements_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False)
        ids = service._collect_ids_from_elements(elements_path, "CharacterRules")
        assert "char_a" in ids and "Char_A" in ids and "CHAR_A" in ids
        assert "Char_B" in ids

    def test_collect_ids_from_elements_missing_key(self, service):
        elements_path = os.path.join(service.project.dir, "elements.json")
        with open(elements_path, "w", encoding="utf-8") as f:
            json.dump({"data": {}}, f, ensure_ascii=False)
        ids = service._collect_ids_from_elements(elements_path, "characterrules")
        assert not ids

    def test_publish_all_integrity_failure_cleans_staging(self, service):
        # 数据齐全但 guide 分片含无效 ID → 闸门2 清理 staging 并 Failed
        service.project.make_module_data()
        orig = service._generate_guide_files

        def patched(config_base_path):
            orig(config_base_path)
            shard = os.path.join(config_base_path, "guides", "content_guide_vol1.json")
            with open(shard, "r", encoding="utf-8") as f:
                doc = json.load(f)
            doc["Chapters"]["vol1_ch1"]["ContextIds"] = {"Characters": ["ghost_id"]}
            with open(shard, "w", encoding="utf-8") as f:
                json.dump(doc, f, ensure_ascii=False)

        with patch.object(service, "_generate_guide_files", side_effect=patched):
            result = service.publish_all()
        assert result.IsSuccess is False
        assert "打包数据完整性校验未通过" in result.Message
        assert not os.path.exists(service._get_staging_config_path(service.project.dir))
        assert not os.path.exists(service._get_staging_manifest_path(service.project.dir))