# -*- coding: utf-8 -*-
"""tests for preflight_validator.py (the real one in novel_writer/preflight.py)"""
import sys, os, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from novel_writer.preflight import PreflightValidator


class MockProject:
    def __init__(self):
        self._design = {}
        self._plan = {}
        # 模拟真实 Project.plan_dir：blueprints_*.json 落盘，供 _load_all_blueprints 目录扫描
        self.plan_dir = tempfile.mkdtemp()

    def set_design(self, entity, data):
        self._design[entity] = data

    def set_plan(self, entity, data):
        self._plan[entity] = data
        if entity.startswith("blueprints_"):
            import json
            with open(os.path.join(self.plan_dir, f"{entity}.json"), "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)

    def load_design(self, entity):
        return self._design.get(entity, [])

    def load_plan(self, entity):
        return self._plan.get(entity, [])


@pytest.fixture
def validator():
    return PreflightValidator(MockProject())


# --- _split_names ---

def test_split_names_string(validator):
    result = validator._split_names("小明、小红, 小刚")
    assert "小明" in result
    assert "小红" in result
    assert "小刚" in result


def test_split_names_list(validator):
    result = validator._split_names(["小明", "小红", "小刚"])
    assert result == ["小明", "小红", "小刚"]


def test_split_names_ignores_ignored(validator):
    result = validator._split_names("无、小明、暂无、小红")
    assert "小明" in result
    assert "小红" in result
    assert "无" not in result
    assert "暂无" not in result


def test_split_names_empty(validator):
    assert validator._split_names("") == []
    assert validator._split_names(None) == []


# --- _build_index ---

def test_build_index(validator):
    entities = [
        {"Name": "小明", "Id": "c1"},
        {"Name": "小红", "Id": "c2"},
    ]
    idx = validator._build_index(entities)
    assert "小明" in idx["names"]
    assert "小红" in idx["names"]
    assert idx["name_to_id"]["小明"] == "c1"


def test_build_index_ignores_ignored(validator):
    entities = [{"Name": "无", "Id": "x1"}]
    idx = validator._build_index(entities)
    assert "无" not in idx["names"]


# --- run with no data ---

def test_run_empty(validator):
    assert validator.run() is True
    assert len(validator.errors) == 0


# --- run with valid data ---

def test_run_valid(validator):
    validator.project.set_design("characters", [{"Name": "小明", "Id": "c1"}])
    validator.project.set_design("factions", [{"Name": "光明教团", "Id": "f1"}])
    validator.project.set_design("locations", [{"Name": "森林", "Id": "l1"}])
    validator.project.set_plan("volumes", [{
        "VolumeNumber": 1, "Name": "序章",
        "ReferencedCharacterNames": "小明",
        "ReferencedFactionNames": "光明教团",
        "ReferencedLocationNames": "森林",
    }])
    validator.project.set_plan("chapters", [{
        "ChapterNumber": 1, "ChapterTitle": "开始",
        "Volume": "第1卷",
        "ReferencedCharacterNames": "小明",
        "ReferencedFactionNames": "",
        "ReferencedLocationNames": "",
    }])
    assert validator.run() is True


# --- run with unmatched reference ---

def test_run_unmatched_reference(validator):
    validator.project.set_plan("volumes", [{
        "VolumeNumber": 1, "Name": "序章",
        "ReferencedCharacterNames": "不存在的角色",
    }])
    validator.project.set_plan("chapters", [])
    assert validator.run() is False
    assert any("不存在的角色" in e for e in validator.errors)


# --- run with missing volume link ---

def test_run_missing_volume_link(validator):
    validator.project.set_plan("volumes", [{"VolumeNumber": 1, "Name": "序章"}])
    validator.project.set_plan("chapters", [{
        "ChapterNumber": 1, "ChapterTitle": "开始",
        "Volume": "",  # empty volume
    }])
    assert validator.run() is False
    assert any("所属卷" in e for e in validator.errors)


# --- run with hierarchy violation ---

def test_run_hierarchy_violation(validator):
    validator.project.set_design("characters", [{"Name": "小明", "Id": "c1"}, {"Name": "小红", "Id": "c2"}])
    validator.project.set_plan("volumes", [{
        "VolumeNumber": 1, "Name": "序章",
        "ReferencedCharacterNames": "小明",
    }])
    validator.project.set_plan("chapters", [{
        "ChapterNumber": 1, "ChapterTitle": "开始",
        "Volume": "第1卷",
        "ReferencedCharacterNames": "小红",
    }])
    assert validator.run() is False
    # 按 C# CheckSubset 语义修断言：越界项以名称（而非 ID）回显
    assert any("小红" in e for e in validator.errors)


# --- _validate_volume_chapter with matching volume ---

def test_validate_volume_chapter_valid(validator):
    volumes = [{"VolumeNumber": 1, "Name": "序章"}]
    chapters = [{"ChapterNumber": 1, "ChapterTitle": "开始", "Volume": "第1卷"}]
    validator._validate_volume_chapter(volumes, chapters)
    assert len(validator.errors) == 0


def test_validate_volume_chapter_invalid(validator):
    volumes = [{"VolumeNumber": 1, "Name": "序章"}]
    chapters = [{"ChapterNumber": 1, "ChapterTitle": "开始", "Volume": "第3卷"}]
    validator._validate_volume_chapter(volumes, chapters)
    assert len(validator.errors) > 0


# --- _normalize_names ---

def test_normalize_names(validator):
    index = {"names": {"小明": "c1"}, "name_to_id": {"小明": "c1"}}
    result = validator._normalize_names("小明", index)
    assert result == ["c1"]


def test_normalize_names_fallback(validator):
    index = {"names": set(), "name_to_id": {}}
    result = validator._normalize_names("小明", index)
    assert result == ["小明"]


# --- add_errors_and_warnings_on_run ---

def test_run_multiple_errors(validator):
    validator.project.set_design("characters", [{"Name": "小明", "Id": "c1"}])
    validator.project.set_plan("volumes", [{"VolumeNumber": 1, "Name": "序章", "ReferencedCharacterNames": "小红"}])
    validator.project.set_plan("chapters", [{"ChapterNumber": 1, "ChapterTitle": "开始", "Volume": "第1卷"}])
    assert validator.run() is False


def test_blueprint_reference_check(validator):
    validator.project.set_design("characters", [{"Name": "小明", "Id": "c1"}])
    validator.project.set_plan("chapters", [{"ChapterNumber": 1, "ChapterTitle": "开始", "Volume": "第1卷", "Id": "ch1"}])
    validator.project.set_plan("blueprints_ch1", [{"Name": "B1", "ReferencedCharacterNames": "小红"}])
    validator.project.set_plan("volumes", [{"VolumeNumber": 1, "Name": "序章"}])
    assert validator.run() is False
    # 按 C# BlueprintData 语义修断言：蓝图引用角色字段为 Cast（非 ReferencedCharacterNames），
    # 且 ChapterId 为空 → 报「关联章节ID」为空
    assert any("关联章节ID」为空" in e for e in validator.errors)


def test_blueprint_cast_reference_check(validator):
    """C# 语义：蓝图 Cast 未映射 + ChapterId 指向不存在章节"""
    validator.project.set_design("characters", [{"Name": "小明", "Id": "c1"}])
    validator.project.set_plan("chapters", [{"ChapterNumber": 1, "ChapterTitle": "开始", "Volume": "第1卷", "Id": "vol1_ch1"}])
    validator.project.set_plan("blueprints_vol1_ch1", [
        {"Name": "B1", "ChapterId": "vol1_ch1", "SceneNumber": 1, "Cast": "小红"}])
    validator.project.set_plan("volumes", [{"VolumeNumber": 1, "Name": "序章"}])
    assert validator.run() is False
    assert any("小红" in e for e in validator.errors)


def test_chapter_blueprint_relation_missing_chapter(validator):
    """C# 语义：蓝图 ChapterId 不在章节集合 → 报错"""
    validator.project.set_plan("chapters", [{"ChapterNumber": 1, "ChapterTitle": "开始", "Volume": "第1卷", "Id": "vol1_ch1"}])
    validator.project.set_plan("blueprints_vol1_ch9", [
        {"Name": "B1", "ChapterId": "vol1_ch9", "SceneNumber": 1, "SceneTitle": "场景X"}])
    validator.project.set_plan("volumes", [{"VolumeNumber": 1, "Name": "序章"}])
    assert validator.run() is False
    assert any("没有对应的章节设计" in e for e in validator.errors)


def test_chapter_blueprint_relation_bad_format(validator):
    """C# 语义：蓝图 ChapterId 格式错误 → 报错"""
    validator.project.set_plan("chapters", [])
    validator.project.set_plan("blueprints_x", [
        {"Name": "B1", "ChapterId": "abc", "SceneNumber": 1, "SceneTitle": "场景Y"}])
    validator.project.set_plan("volumes", [])
    assert validator.run() is False
    assert any("格式错误" in e for e in validator.errors)