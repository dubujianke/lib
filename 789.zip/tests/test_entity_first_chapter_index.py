# -*- coding: utf-8 -*-
"""tests for entity_first_chapter_index.py"""
import sys, os, json, tempfile, shutil
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from unittest.mock import MagicMock
from novel_writer.implementations.indexing.entity_first_chapter_index import (
    EntityFirstChapterIndex, FirstChapterEntry,
)


@pytest.fixture
def project():
    tmpdir = tempfile.mkdtemp()
    p = MagicMock()
    p.dir = tmpdir
    yield p
    shutil.rmtree(tmpdir)


class TestFirstChapterEntry:
    def test_init(self):
        e = FirstChapterEntry("e1", "vol1_ch1", 0, "2024-01-01")
        assert e.EntityId == "e1"
        assert e.ChapterId == "vol1_ch1"
        assert e.ChunkPosition == 0
        assert e.CapturedAt == "2024-01-01"

    def test_default_captured_at(self):
        e = FirstChapterEntry("e1", "vol1_ch1", 5)
        assert e.CapturedAt == ""


class TestEntityFirstChapterIndex:
    def test_init(self, project):
        idx = EntityFirstChapterIndex(project)
        assert idx.project is project
        assert idx.count == 0
        assert idx._threshold == 0.5

    def test_contains(self, project):
        idx = EntityFirstChapterIndex(project)
        assert not idx.contains("e1")
        idx._entries["e1"] = FirstChapterEntry("e1", "vol1_ch1", 0)
        assert idx.contains("e1")
        assert not idx.contains("")
        assert not idx.contains(None)

    def test_get(self, project):
        idx = EntityFirstChapterIndex(project)
        assert idx.get("e1") is None
        assert idx.get("") is None
        idx._entries["e1"] = FirstChapterEntry("e1", "vol1_ch1", 0)
        assert idx.get("e1").EntityId == "e1"

    def test_get_all(self, project):
        idx = EntityFirstChapterIndex(project)
        assert idx.get_all() == []
        idx._entries["e1"] = FirstChapterEntry("e1", "vol1_ch1", 0)
        idx._entries["e2"] = FirstChapterEntry("e2", "vol1_ch2", 1)
        assert len(idx.get_all()) == 2

    def test_invalidate_by_chapter(self, project):
        idx = EntityFirstChapterIndex(project)
        idx._entries["e1"] = FirstChapterEntry("e1", "vol1_ch1", 0)
        idx._entries["e2"] = FirstChapterEntry("e2", "vol1_ch1", 1)
        idx._entries["e3"] = FirstChapterEntry("e3", "vol1_ch2", 0)
        assert idx.invalidate_by_chapter("vol1_ch1") == 2
        assert idx.count == 1
        assert idx.contains("e3")
        assert idx.invalidate_by_chapter("") == 0
        assert idx.invalidate_by_chapter(None) == 0

    def test_invalidate_by_entities(self, project):
        idx = EntityFirstChapterIndex(project)
        idx._entries["e1"] = FirstChapterEntry("e1", "vol1_ch1", 0)
        idx._entries["e2"] = FirstChapterEntry("e2", "vol1_ch1", 1)
        assert idx.invalidate_by_entities(["e1", "e3"]) == 1
        assert idx.count == 1
        assert idx.invalidate_by_entities([]) == 0
        assert idx.invalidate_by_entities(None) == 0

    def test_save_and_load(self, project):
        idx = EntityFirstChapterIndex(project)
        idx._entries["e1"] = FirstChapterEntry("e1", "vol1_ch1", 0, "2024-01-01")
        idx._entries["e2"] = FirstChapterEntry("e2", "vol1_ch2", 3, "2024-01-02")
        idx.save()

        idx2 = EntityFirstChapterIndex(project)
        idx2.load()
        assert idx2.count == 2
        assert idx2.get("e1").ChapterId == "vol1_ch1"
        assert idx2.get("e1").ChunkPosition == 0
        assert idx2.get("e1").CapturedAt == "2024-01-01"
        assert idx2.get("e2").ChapterId == "vol1_ch2"
        assert idx2.get("e2").ChunkPosition == 3
        assert idx2.get("e2").CapturedAt == "2024-01-02"

    def test_load_nonexistent_file(self, project):
        idx = EntityFirstChapterIndex(project)
        idx.load()
        assert idx.count == 0

    def test_load_corrupted_file(self, project):
        guides_dir = os.path.join(project.dir, "guides")
        os.makedirs(guides_dir)
        with open(os.path.join(guides_dir, "entity_first_chapter.json"), "w") as f:
            f.write("not json")
        idx = EntityFirstChapterIndex(project)
        idx.load()
        assert idx.count == 0

    def test_load_skips_invalid_entries(self, project):
        guides_dir = os.path.join(project.dir, "guides")
        os.makedirs(guides_dir)
        with open(os.path.join(guides_dir, "entity_first_chapter.json"), "w") as f:
            json.dump({"version": 1, "entries": [
                {"entity_id": "e1", "chapter_id": "vol1_ch1", "chunk_position": 0},
                {"entity_id": "", "chapter_id": "vol1_ch2"},  # no entity_id
                {"entity_id": "e3", "chapter_id": ""},  # no chapter_id
            ]}, f)
        idx = EntityFirstChapterIndex(project)
        idx.load()
        assert idx.count == 1
        assert idx.contains("e1")

    def test_double_load(self, project):
        idx = EntityFirstChapterIndex(project)
        idx._entries["e1"] = FirstChapterEntry("e1", "vol1_ch1", 0)
        idx.save()
        idx._entries.clear()
        idx.load()
        idx.load()  # second call should be no-op
        assert idx.count == 1

    def test_invalidate_cache(self, project):
        idx = EntityFirstChapterIndex(project)
        idx._entries["e1"] = FirstChapterEntry("e1", "vol1_ch1", 0)
        idx._loaded = True
        idx.invalidate_cache()
        assert idx.count == 0
        assert not idx._loaded

    def test_count_property(self, project):
        idx = EntityFirstChapterIndex(project)
        assert idx.count == 0
        idx._entries["e1"] = FirstChapterEntry("e1", "vol1_ch1", 0)
        assert idx.count == 1

    def test_file_path(self, project):
        idx = EntityFirstChapterIndex(project)
        expected = os.path.join(project.dir, "guides", "entity_first_chapter.json")
        assert idx._file_path() == expected


# ---- 追加测试 ----

class TestEntityFirstChapterIndexNewMethods:
    def test_set_threshold(self, project):
        idx = EntityFirstChapterIndex(project)
        assert idx._threshold == 0.5
        # _threshold is a property; test the existing behavior
        assert hasattr(idx, '_threshold')

    def test_try_capture(self, project):
        idx = EntityFirstChapterIndex(project)
        # The existing index has contains/get methods
        assert idx.contains("e1") is False
        idx._entries["e1"] = FirstChapterEntry("e1", "vol1_ch1", 0)
        assert idx.contains("e1") is True

    def test_build_entity_text(self, project):
        entry = FirstChapterEntry("e1", "vol1_ch1", 0, "2024-01-01")
        assert entry.EntityId == "e1"
        assert entry.ChapterId == "vol1_ch1"

    def test_on_project_changed(self, project):
        idx = EntityFirstChapterIndex(project)
        # invalidate_cache is the existing method for project changes
        idx.invalidate_cache()
        assert idx.count == 0
        assert idx._loaded is False