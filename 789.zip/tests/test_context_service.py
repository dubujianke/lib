# -*- coding: utf-8 -*-
"""tests for context_service.py"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock
from novel_writer.implementations.context.context_service import ContextService, MaterialScope


class MockProject:
    def __init__(self):
        self._design = {}
        self._plan = {}

    def set_design(self, entity, data):
        self._design[entity] = data

    def set_plan(self, entity, data):
        self._plan[entity] = data

    def load_design(self, entity):
        return self._design.get(entity, [])

    def load_plan(self, entity):
        return self._plan.get(entity, [])

    def load_chapter(self, chapter_id):
        return None


@pytest.fixture
def service():
    return ContextService(MockProject())


# --- _load_design / _load_plan ---

def test_load_design_returns_items(service):
    service.project.set_design("world", {"items": [{"Name": "Rule1"}]})
    result = service._load_design("world")
    assert result == [{"Name": "Rule1"}]


def test_load_design_returns_list_direct(service):
    service.project.set_design("world", [{"Name": "Rule1"}])
    result = service._load_design("world")
    assert result == [{"Name": "Rule1"}]


def test_load_plan_returns_list(service):
    service.project.set_plan("chapters", [{"Name": "Ch1"}])
    result = service._load_plan("chapters")
    assert result == [{"Name": "Ch1"}]


def test_load_plan_returns_dict_items(service):
    service.project.set_plan("chapters", {"chapters": [{"Name": "Ch1"}]})
    result = service._load_plan("chapters")
    assert result == [{"Name": "Ch1"}]


# --- _load_function_data ---

def test_load_function_data_materials(service):
    service.project.set_design("materials", [{"Name": "Mat1"}])
    result = service._load_function_data("CreativeMaterials")
    assert result == [{"Name": "Mat1"}]


def test_load_function_data_outline(service):
    service.project.set_plan("outline", [{"Name": "Outline1"}])
    result = service._load_function_data("Outline")
    assert result == [{"Name": "Outline1"}]


# --- build_creative_materials_string ---

def test_build_creative_materials_string_empty(service):
    result = service.build_creative_materials_string(MaterialScope.PLOT)
    assert "<creative_materials_catalog>" in result
    assert "</creative_materials_catalog>" in result


def test_build_creative_materials_string_full(service):
    service.project.set_design("materials", [{
        "Name": "Mat1", "Category": "奇幻", "Genre": "西幻",
        "OverallIdea": "一个世界", "PlotStructure": "三幕式",
        "ConflictDesign": "正邪对抗", "ClimaxArrangement": "高潮",
        "ForeshadowingTechnique": "伏笔", "PlotHighlights": "亮点",
    }])
    result = service.build_creative_materials_string(MaterialScope.PLOT)
    assert "Mat1" in result
    assert "整体构思：一个世界" in result
    assert "三幕式" in result
    assert "正邪对抗" in result


def test_build_creative_materials_string_scope_worldview(service):
    service.project.set_design("materials", [{
        "Name": "Mat1", "Category": "奇幻",
        "WorldBuildingMethod": "自上而下",
        "PowerSystemDesign": "魔法",
        "EnvironmentDescription": "森林",
        "FactionDesign": "三大势力",
    }])
    result = service.build_creative_materials_string(MaterialScope.WORLDVIEW)
    assert "世界观搭建方法：自上而下" in result
    assert "力量体系设计：魔法" in result
    assert "环境描写：森林" in result
    assert "势力设计：三大势力" in result


def test_build_creative_materials_string_scope_character(service):
    service.project.set_design("materials", [{
        "Name": "Mat1", "Category": "奇幻",
        "ProtagonistDesign": "勇者", "SupportingRoles": "伙伴",
        "CharacterRelations": "友情", "GoldenFingerDesign": "神器",
        "CharacterHighlights": "成长",
    }])
    result = service.build_creative_materials_string(MaterialScope.CHARACTER)
    assert "主角塑造：勇者" in result
    assert "配角设计：伙伴" in result
    assert "人物关系：友情" in result
    assert "金手指设计：神器" in result


def test_build_creative_materials_string_disabled(service):
    service.project.set_design("materials", [
        {"Name": "Mat1", "Category": "奇幻", "IsEnabled": False, "PlotStructure": "三幕式"},
        {"Name": "Mat2", "Category": "科幻", "IsEnabled": True, "PlotStructure": "多线"},
    ])
    result = service.build_creative_materials_string(MaterialScope.PLOT)
    assert "Mat1" not in result
    assert "Mat2" in result


# --- build_worldview_string ---

def test_build_worldview_string_empty(service):
    result = service.build_worldview_string()
    assert "<worldview_rules>" in result
    assert "</worldview_rules>" in result


def test_build_worldview_string_full(service):
    service.project.set_design("world", [{
        "Name": "魔法的世界", "OneLineSummary": "魔法为核心",
        "PowerSystem": "元素魔法", "HardRules": "等价交换",
        "Cosmology": "多元宇宙", "SpecialLaws": "时间加速",
        "SoftRules": "魔力耗尽", "KeyEvents": "魔法战争",
    }])
    result = service.build_worldview_string()
    assert "魔法的世界" in result
    assert "魔法为核心" in result
    assert "元素魔法" in result
    assert "等价交换" in result
    assert "多元宇宙" in result
    assert "时间加速" in result
    assert "魔力耗尽" in result
    assert "魔法战争" in result


def test_build_worldview_string_skips_no_content(service):
    service.project.set_design("world", [{"Name": "", "OneLineSummary": "", "PowerSystem": "", "HardRules": ""}])
    result = service.build_worldview_string()
    assert ">" in result  # only XML tags


# --- build_volume_design_string ---

def test_build_volume_design_string(service):
    service.project.set_plan("volumes", [{
        "VolumeNumber": 1, "VolumeTitle": "序章", "VolumeTheme": "引入",
        "StageGoal": "介绍世界", "MainConflict": "无", "KeyEvents": "主角出发",
        "ChapterGenerationHints": "慢节奏",
    }])
    result = service.build_volume_design_string()
    assert "第1卷" in result
    assert "序章" in result
    assert "卷主题：引入" in result
    assert "阶段目标：介绍世界" in result


# --- build_character_summary_string ---

def test_build_character_summary_string(service):
    service.project.set_design("characters", [{
        "Name": "小明", "Identity": "勇者", "Want": "打败魔王",
        "Need": "找到自我", "CharacterType": "主角",
    }])
    result = service.build_character_summary_string()
    assert "小明" in result
    assert "角色类型：主角" in result
    assert "身份：勇者" in result
    assert "外在目标：打败魔王" in result


def test_build_character_summary_string_skips_no_content(service):
    service.project.set_design("characters", [{"Name": "", "Identity": "", "Want": "", "Need": ""}])
    result = service.build_character_summary_string()
    assert "character_rules" in result
    assert ">" in result


# --- build_character_arc_string ---

def test_build_character_arc_string(service):
    service.project.set_design("characters", [
        {"Id": "c1", "Name": "小红", "Identity": "法师", "Want": "学习魔法",
         "Need": "控制力量", "FlawBelief": "自负", "GrowthPath": "从傲慢到谦逊",
         "Personality": "聪明", "RelationshipType": "师徒", "EmotionDynamic": "崇拜",
         "Relationships": "导师", "TargetCharacterName": "c2"},
        {"Id": "c2", "Name": "大法师", "Identity": "导师", "Want": "教学", "Need": "传承"},
    ])
    result = service.build_character_arc_string()
    assert "小红" in result
    assert "核心缺陷：自负" in result
    assert "成长路径：从傲慢到谦逊" in result
    assert "性格：聪明" in result


def test_build_character_arc_string_resolves_id(service):
    service.project.set_design("characters", [
        {"Id": "c1", "Name": "小红", "Identity": "法师", "Want": "学习", "Need": "成长",
         "TargetCharacterName": "c2"},
        {"Id": "c2", "Name": "大法师", "Identity": "导师", "Want": "教学", "Need": "传承"},
    ])
    result = service.build_character_arc_string()
    assert "大法师" in result


# --- build_character_arc_string_for_volume ---

def test_build_character_arc_string_for_volume_filter(service):
    service.project.set_design("characters", [
        {"Id": "c1", "Name": "小明", "Identity": "勇者", "Want": "冒险", "Need": "成长"},
        {"Id": "c2", "Name": "小红", "Identity": "法师", "Want": "学习", "Need": "控制"},
    ])
    result = service.build_character_arc_string_for_volume(["小明"])
    assert "小明" in result
    assert "小红" not in result


def test_build_character_arc_string_for_volume_empty_filter(service):
    service.project.set_design("characters", [{"Id": "c1", "Name": "小明", "Identity": "勇者", "Want": "冒险", "Need": "成长"}])
    result = service.build_character_arc_string_for_volume(None)
    assert "小明" in result


def test_build_character_arc_string_for_volume_fallback(service):
    service.project.set_design("characters", [{"Id": "c1", "Name": "小明", "Identity": "勇者", "Want": "冒险", "Need": "成长"}])
    result = service.build_character_arc_string_for_volume(["不存在的角色"])
    assert "小明" in result


# --- build_character_structure_string ---

def test_build_character_structure_string(service):
    service.project.set_design("characters", [{
        "Name": "小明", "Identity": "勇者", "Want": "冒险", "Need": "成长",
        "FlawBelief": "自负", "GrowthPath": "成长",
    }])
    result = service.build_character_structure_string()
    assert "核心缺陷：自负" in result
    assert "成长路径：成长" in result


# --- build_faction_summary_string ---

def test_build_faction_summary_string(service):
    service.project.set_design("factions", [{
        "Id": "f1", "Name": "光明教团", "FactionType": "正派", "Goal": "维护和平",
        "Leader": "c1", "CoreMembers": "c2, c3", "StrengthTerritory": "大陆",
    }])
    service.project.set_design("characters", [{"Id": "c1", "Name": "教皇"}])
    result = service.build_faction_summary_string()
    assert "光明教团" in result
    assert "正派" in result
    assert "维护和平" in result


def test_build_faction_summary_string_resolves_ids(service):
    service.project.set_design("factions", [
        {"Id": "f1", "Name": "暗影", "FactionType": "反派", "Goal": "统治",
         "Leader": "c1", "CoreMembers": "c2",
         "Allies": "f2", "Enemies": "f3", "NeutralCompetitors": "f4"},
        {"Id": "f2", "Name": "盟友", "FactionType": "友方", "Goal": "互助"},
        {"Id": "f3", "Name": "敌人", "FactionType": "敌对", "Goal": "破坏"},
        {"Id": "f4", "Name": "中立者", "FactionType": "中立", "Goal": "观望"},
    ])
    service.project.set_design("characters", [{"Id": "c1", "Name": "暗王"}, {"Id": "c2", "Name": "将军"}])
    result = service.build_faction_summary_string()
    assert "暗王" in result
    assert "将军" in result
    assert "盟友" in result
    assert "敌人" in result
    assert "中立者" in result


# --- build_faction_minimal_string ---

def test_build_faction_minimal_string(service):
    service.project.set_design("factions", [{
        "Name": "帝国", "FactionType": "国家", "Goal": "统一",
        "StrengthTerritory": "全境",
    }])
    result = service.build_faction_minimal_string()
    assert "帝国" in result
    assert "类型：国家" in result
    assert "全境" in result


# --- build_location_summary_string ---

def test_build_location_summary_string(service):
    service.project.set_design("locations", [{
        "Name": "迷雾森林", "LocationType": "森林", "Description": "浓雾笼罩",
        "Dangers": ["迷路", "怪兽"],
    }])
    result = service.build_location_summary_string()
    assert "迷雾森林" in result
    assert "类型：森林" in result
    assert "描述：浓雾笼罩" in result
    assert "危险/禁忌：迷路、怪兽" in result


def test_build_location_summary_string_skips_no_content(service):
    service.project.set_design("locations", [{"Name": "", "Description": "", "Terrain": ""}])
    result = service.build_location_summary_string()
    assert "location_rules" in result


# --- build_plot_rules_string ---

def test_build_plot_rules_string(service):
    service.project.set_design("plot", [{
        "Name": "主线", "OneLineSummary": "勇者之旅", "Goal": "打败魔王",
        "EventType": "全卷贯穿", "StoryPhase": "开端",
        "Conflict": "正邪", "MainPlotPush": "推进", "CharacterGrowth": "成长",
        "Result": "胜利",
    }])
    result = service.build_plot_rules_string()
    assert "主线" in result
    assert "勇者之旅" in result
    assert "全卷贯穿" in result
    assert "正邪" in result
    assert "推进" in result
    assert "成长" in result
    assert "胜利" in result


def test_build_plot_rules_string_with_volume_filter(service):
    service.project.set_design("plot", [
        {"Name": "卷1主线", "OneLineSummary": "S1", "Goal": "G1", "AssignedVolume": "第1卷"},
        {"Name": "卷2主线", "OneLineSummary": "S2", "Goal": "G2", "AssignedVolume": "第2卷"},
    ])
    result = service.build_plot_rules_string("第1卷")
    assert "卷1主线" in result
    assert "卷2主线" not in result


# --- build_outline_string ---

def test_build_outline_string(service):
    service.project.set_plan("outline", [{
        "Name": "全书大纲", "TotalChapterCount": 100, "OneLineOutline": "冒险",
        "EmotionalTone": "热血", "Theme": "友情", "CoreConflict": "正义vs邪恶",
        "EndingState": "HE", "VolumeDivision": "3卷",
    }])
    result = service.build_outline_string()
    assert "全书大纲" in result
    assert "全书总章节数：100" in result
    assert "一句话大纲：冒险" in result
    assert "情感基调：热血" in result
    assert "核心思想：友情" in result
    assert "核心冲突：正义vs邪恶" in result
    assert "结局状态：HE" in result
    assert "卷划分：3卷" in result


# --- get_smart_parsing_context ---

def test_get_smart_parsing_context(service):
    service.project.set_plan("materials", [{"Name": "分析1"}])
    ctx = service.get_smart_parsing_context()
    assert ctx is not None


# --- get_templates_context ---

def test_get_templates_context(service):
    service.project.set_design("materials", [{"Name": "素材1"}])
    ctx = service.get_templates_context()
    assert ctx is not None


# --- static helpers ---

def test_has_content(service):
    assert ContextService._has_content({"Name": "X"}, ["Name"]) is True
    assert ContextService._has_content({"Name": ""}, ["Name"]) is False


def test_enabled(service):
    items = [{"Name": "A"}, {"Name": "B", "IsEnabled": False}]
    result = ContextService._enabled(items)
    assert len(result) == 1
    assert result[0]["Name"] == "A"


def test_resolve_id(service):
    m = {"id1": "小明"}
    assert ContextService._resolve_id("id1", m) == "小明"
    assert ContextService._resolve_id("unknown", m) == "unknown"
    assert ContextService._resolve_id("", m) == ""


def test_resolve_ids(service):
    m = {"c1": "小明", "c2": "小红"}
    result = ContextService._resolve_ids("c1, c2", m)
    assert "小明" in result
    assert "小红" in result


def test_extract_volume_number_from_text(service):
    assert ContextService._extract_volume_number_from_text("第1卷") == 1
    assert ContextService._extract_volume_number_from_text("第 2 卷") == 2
    assert ContextService._extract_volume_number_from_text("vol3") == 3
    assert ContextService._extract_volume_number_from_text("") == 0
    assert ContextService._extract_volume_number_from_text("abc") == 0


# --- get_worldview_context_string ---

def test_get_worldview_context_string(service):
    result = service.get_worldview_context_string()
    assert '<design_context for="worldview_rules">' in result
    assert "</design_context>" in result


# --- get_character_context_string ---

def test_get_character_context_string(service):
    result = service.get_character_context_string()
    assert '<design_context for="character_rules">' in result


# --- get_faction_context_string ---

def test_get_faction_context_string(service):
    result = service.get_faction_context_string()
    assert '<design_context for="faction_rules">' in result


# --- get_location_context_string ---

def test_get_location_context_string(service):
    result = service.get_location_context_string()
    assert '<design_context for="location_rules">' in result


# --- get_plot_context_string ---

def test_get_plot_context_string(service):
    result = service.get_plot_context_string()
    assert '<design_context for="plot_rules">' in result


# --- get_outline_context_string ---

def test_get_outline_context_string(service):
    result = service.get_outline_context_string()
    assert '<design_context for="outline">' in result


# --- get_chapter_context_string ---

def test_get_chapter_context_string(service):
    result = service.get_chapter_context_string()
    assert '<design_context for="chapter_planning">' in result


# --- get_core_design_context ---

def test_get_core_design_context(service):
    result = service.get_core_design_context()
    assert "<design_data>" in result
    assert "</design_data>" in result


# --- get_volume_design_list ---

def test_get_volume_design_list(service):
    service.project.set_plan("volumes", [{"VolumeNumber": 1, "VolumeTitle": "序章"}])
    result = service.get_volume_design_list()
    assert "第1卷" in result


# --- get_volume_design_context_string ---

def test_get_volume_design_context_string(service):
    result = service.get_volume_design_context_string()
    assert '<design_context for="volume_design">' in result


# --- build_adjacent_chapter_context ---

def test_build_adjacent_chapter_context_empty(service):
    assert service.build_adjacent_chapter_context(0, "") == ""


def test_build_adjacent_chapter_context_with_data(service):
    service.project.set_plan("chapters", [
        {"ChapterNumber": 2, "ChapterTitle": "启程", "Hook": "悬念",
         "Volume": "第1卷", "Category": "第1卷"},
        {"ChapterNumber": 3, "ChapterTitle": "冒险", "Hook": "危机",
         "MainPlotProgress": "成长", "Volume": "第1卷", "Category": "第1卷"},
        {"ChapterNumber": 4, "ChapterTitle": "决战", "ChapterTheme": "最终战",
         "MainGoal": "打败魔王", "Volume": "第1卷", "Category": "第1卷"},
    ])
    result = service.build_adjacent_chapter_context(3, "第1卷")
    assert "adjacent_chapters" in result
    assert "第2章" in result
    assert "第4章" in result


# --- get_chapter_context_with_volume_locator ---

def test_get_chapter_context_with_volume_locator(service):
    service.project.set_plan("volumes", [{
        "VolumeNumber": 1, "VolumeTitle": "序章", "CategoryId": "第1卷",
        "StageGoal": "介绍", "MainConflict": "无",
    }])
    result = service.get_chapter_context_with_volume_locator("第1卷")
    assert "volume_locator" in result


# --- get_blueprint_context_with_chapter_locator ---

def test_get_blueprint_context_with_chapter_locator(service):
    service.project.set_plan("chapters", [{
        "ChapterNumber": 1, "ChapterTitle": "开始", "Volume": "第1卷",
        "Category": "第1卷", "CategoryId": "第1卷",
    }])
    result = service.get_blueprint_context_with_chapter_locator("vol1_ch1")
    assert "chapter_locator" in result


# --- get_outline_structure_context ---

def test_get_outline_structure_context(service):
    result = service.get_outline_structure_context()
    assert '<design_context for="outline">' in result


# --- get_volume_design_structure_context ---

def test_get_volume_design_structure_context(service):
    result = service.get_volume_design_structure_context()
    assert '<design_context for="volume_design">' in result


# --- get_core_design_context_for_volume ---

def test_get_core_design_context_for_volume(service):
    service.project.set_plan("volumes", [{
        "VolumeNumber": 1, "VolumeTitle": "序章", "CategoryId": "第1卷",
    }])
    result = service.get_core_design_context_for_volume("第1卷")
    assert "<design_data>" in result


# --- get_core_design_context_for_entity_filter ---

def test_get_core_design_context_for_entity_filter(service):
    service.project.set_design("characters", [{"Id": "c1", "Name": "小明", "Identity": "勇者", "Want": "冒险", "Need": "成长"}])
    result = service.get_core_design_context_for_entity_filter(["小明"], None, None)
    assert "<design_data>" in result
    assert "小明" in result


# --- static content check helpers ---

def test_has_world_rules_content():
    assert ContextService.has_world_rules_content({"Name": "X"}) is True
    assert ContextService.has_world_rules_content({}) is False


def test_has_character_content():
    assert ContextService.has_character_content({"Name": "X"}) is True
    assert ContextService.has_character_content({}) is False


def test_has_faction_content():
    assert ContextService.has_faction_content({"Name": "X"}) is True
    assert ContextService.has_faction_content({}) is False


def test_has_location_content():
    assert ContextService.has_location_content({"Name": "X"}) is True
    assert ContextService.has_location_content({}) is False


def test_has_plot_content():
    assert ContextService.has_plot_content({"Name": "X"}) is True
    assert ContextService.has_plot_content({}) is False


# ---- 追加测试 ----

class TestContextServiceNewMethods:
    @pytest.fixture
    def service(self):
        proj = MockProject()
        proj.dir = os.path.join(os.path.dirname(__file__), "fixtures")
        return ContextService(proj)

    def test_get_project_config_path(self, service):
        import os as os_mod
        # Manually test the path logic
        path = os_mod.path.join(service.project.dir, "config", "Design")
        assert "config" in path
        assert "Design" in path

    def test_get_function_path(self, service):
        import os as os_mod
        path = os_mod.path.join(service.project.dir, "design", "outline")
        assert "design" in path
        assert "outline" in path.lower()

    def test_get_data_file_name_outline(self, service):
        name = service._get_data_file_name("Outline")
        assert name == "outline_data.json"

    def test_get_data_file_name_world(self, service):
        name = service._get_data_file_name("WorldRules")
        assert name == "world_rules.json"
        assert "data" not in name

    def test_to_snake_case(self, service):
        assert service._to_snake_case("HelloWorld") == "hello_world"
        assert service._to_snake_case("XMLParser") == "x_m_l_parser"  # matches C# behavior
        assert service._to_snake_case("") == ""
        assert service._to_snake_case(None) is None

    def test_load_packaged_design_data(self, service):
        data = service._load_packaged_design_data()
        assert data is not None
        assert hasattr(data, 'Templates')

    def test_build_packaged_cache_key(self, service):
        key = service._build_packaged_cache_key("Design")
        assert "PackagedContext" in key
        assert "Design" in key

    def test_load_generated_content(self, service):
        content = service._load_generated_content(1, 1)
        assert content is None or isinstance(content, str)