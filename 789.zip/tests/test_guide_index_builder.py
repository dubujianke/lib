# -*- coding: utf-8 -*-
"""tests for guide_index_builder.py"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock, patch
from novel_writer.implementations.guides.guide_index_builder import GuideIndexBuilder


class MockProject:
    def __init__(self):
        self._design = {}
        self._plan = {}
    def load_design(self, entity):
        return self._design.get(entity, [])
    def load_plan(self, entity):
        return self._plan.get(entity, [])
    def set_design(self, entity, data):
        self._design[entity] = data
    def set_plan(self, entity, data):
        self._plan[entity] = data


@pytest.fixture
def builder():
    return GuideIndexBuilder(MockProject())


# --- ensure_required_ids ---

def test_ensure_required_ids_all_present(builder):
    items = [{"Id": "c1", "Name": "小明"}, {"Id": "c2", "Name": "小红"}]
    builder.ensure_required_ids(items, lambda x: x.get("Id"), "角色", lambda x: x.get("Name"))


def test_ensure_required_ids_missing(builder):
    items = [{"Id": "", "Name": "小明"}, {"Id": "c2", "Name": "小红"}]
    with pytest.raises(ValueError, match="角色"):
        builder.ensure_required_ids(items, lambda x: x.get("Id"), "角色", lambda x: x.get("Name"))


def test_ensure_required_ids_no_name_selector(builder):
    items = [{"Id": "", "Name": "小明"}]
    with pytest.raises(ValueError, match="<unknown>"):
        builder.ensure_required_ids(items, lambda x: x.get("Id"), "test")


# --- build_character_index ---

def test_build_character_index(builder):
    builder.project.set_design("characters", [
        {"Name": "小明", "Id": "c1"},
        {"Name": "小红", "Id": "c2"},
    ])
    idx = builder.build_character_index()
    assert idx == {"小明": "c1", "小红": "c2"}


def test_build_character_index_empty(builder):
    assert builder.build_character_index() == {}


# --- build_location_index ---

def test_build_location_index(builder):
    builder.project.set_design("locations", [
        {"Name": "森林", "Id": "l1"},
    ])
    idx = builder.build_location_index()
    assert idx == {"森林": "l1"}


def test_build_location_index_empty(builder):
    assert builder.build_location_index() == {}


# --- build_faction_index ---

def test_build_faction_index(builder):
    builder.project.set_design("factions", [
        {"Name": "教团", "Id": "f1"},
    ])
    idx = builder.build_faction_index()
    assert idx == {"教团": "f1"}


def test_build_faction_index_empty(builder):
    assert builder.build_faction_index() == {}


# --- build_plot_index ---

def test_build_plot_index(builder):
    builder.project.set_design("plot", [
        {"Name": "主线", "Id": "p1"},
    ])
    idx = builder.build_plot_index()
    assert idx == {"主线": "p1"}


def test_build_plot_index_empty(builder):
    assert builder.build_plot_index() == {}


# --- build_world_index ---

def test_build_world_index(builder):
    builder.project.set_design("world", [
        {"Name": "世界观", "Id": "w1"},
    ])
    idx = builder.build_world_index()
    assert idx == {"世界观": "w1"}


def test_build_world_index_empty(builder):
    assert builder.build_world_index() == {}


# --- validate_plot_rules ---

def test_validate_plot_rules_all_valid(builder):
    rules = [{"Id": "p1", "Name": "主线"}, {"Id": "p2", "Name": "支线"}]
    errors = builder.validate_plot_rules(rules)
    assert errors == []


def test_validate_plot_rules_missing_id(builder):
    rules = [{"Id": "p1", "Name": "主线"}, {"Name": "支线"}]
    errors = builder.validate_plot_rules(rules)
    assert len(errors) == 1
    assert "支线" in errors[0]


def test_validate_plot_rules_empty(builder):
    assert builder.validate_plot_rules([]) == []


# --- 11 个 Build 方法（空数据返回空结构） ---

def test_build_outline_guide_empty(builder):
    guide = builder.build_outline_guide()
    assert guide["Module"] == "OutlineGuide"
    assert guide["Volumes"] == {}


def test_build_planning_guide_empty(builder):
    outline = builder.build_outline_guide()
    guide = builder.build_planning_guide(outline)
    assert guide["Module"] == "PlanningGuide"
    assert guide["Volumes"] == {}


def test_build_blueprint_guide_empty(builder):
    outline = builder.build_outline_guide()
    planning = builder.build_planning_guide(outline)
    guide = builder.build_blueprint_guide(planning)
    assert guide["Module"] == "BlueprintGuide"
    assert guide["Chapters"] == {}
    assert guide["ReverseIndex"] == {"ByCharacter": {}, "ByLocation": {}}


def test_build_content_guide_empty(builder):
    outline = builder.build_outline_guide()
    planning = builder.build_planning_guide(outline)
    blueprint = builder.build_blueprint_guide(planning)
    guide = builder.build_content_guide(blueprint)
    assert guide["Module"] == "ContentGuide"
    assert guide["Chapters"] == {}
    assert guide["ChapterSummaries"] == {}


def test_build_character_state_guide_empty(builder):
    guide = builder.build_character_state_guide()
    assert guide["Module"] == "CharacterStateGuide"
    assert guide["Characters"] == {}


def test_build_conflict_progress_guide_empty(builder):
    guide = builder.build_conflict_progress_guide()
    assert guide["Module"] == "ConflictProgressGuide"
    assert guide["Conflicts"] == {}


def test_build_foreshadowing_status_guide_empty(builder):
    guide = builder.build_foreshadowing_status_guide()
    assert guide["Module"] == "ForeshadowingStatusGuide"
    assert guide["Foreshadowings"] == {}
    assert guide["Summary"] == {"Total": 0, "Setup": 0, "Payoff": 0,
                                "Pending": 0, "CompletionRate": "0%"}


def test_build_location_state_guide_empty(builder):
    guide = builder.build_location_state_guide()
    assert guide["Module"] == "LocationStateGuide"
    assert guide["Locations"] == {}


def test_build_faction_state_guide_empty(builder):
    guide = builder.build_faction_state_guide()
    assert guide["Module"] == "FactionStateGuide"
    assert guide["Factions"] == {}


def test_build_timeline_guide_empty(builder):
    guide = builder.build_timeline_guide()
    assert guide["Module"] == "TimelineGuide"
    assert guide["ChapterTimeline"] == []
    assert guide["CharacterLocations"] == {}


def test_build_plot_points_index_empty(builder):
    guide = builder.build_plot_points_index()
    assert guide["Module"] == "PlotPointsIndex"
    assert guide["PlotPoints"] == []
    assert guide["Keywords"] == {}
    assert guide["ChapterIndex"] == {}


# --- 辅助方法 ---

def test_map_names_to_ids(builder):
    name_to_id = {"小明": "c1"}
    id_set = {"c2"}
    assert builder._map_names_to_ids(["小明", "c2", "未知"], name_to_id, id_set) == ["c1", "c2"]


def test_match_plot_rules_by_characters(builder):
    characters = [{"Id": "c1", "Name": "小明"}]
    plot_rules = [
        {"Id": "p1", "MainCharacters": "小明"},
        {"Id": "p2", "MainCharacters": "小红"},
        {"Id": "p3", "StoryPhase": "vol1_ch2"},
        {"Id": "p4", "StoryPhase": "vol1_ch3"},
    ]
    matched = builder._match_plot_rules_by_characters("vol1_ch2", ["c1"], characters, plot_rules)
    assert set(matched) == {"p1", "p3"}


def test_build_reverse_index(builder):
    chapters = {
        "vol1_ch1": {"ContextIds": {"Characters": ["c1"], "Locations": ["l1"]}},
        "vol1_ch2": {"ContextIds": {"Characters": ["c1"]}},
    }
    ri = builder._build_reverse_index(chapters)
    assert ri["ByCharacter"] == {"c1": ["vol1_ch1", "vol1_ch2"]}
    assert ri["ByLocation"] == {"l1": ["vol1_ch1"]}


def test_parse_volume_number_from_string(builder):
    assert builder._parse_volume_number_from_string("第3卷") == 3
    assert builder._parse_volume_number_from_string("vol2") == 2
    assert builder._parse_volume_number_from_string("第N卷") == -1
    assert builder._parse_volume_number_from_string("") == -1


def test_find_chapter_data(builder):
    exact = {"Id": "cp1"}
    fallback = {"Id": "cp2"}
    by_vol_num = {(1, 2): exact}
    by_num = {2: fallback, 5: {"Id": "cp5"}}
    assert builder._find_chapter_data("vol1_ch2", "", by_vol_num, by_num) is exact
    assert builder._find_chapter_data("vol3_ch5", "", by_vol_num, by_num) == {"Id": "cp5"}
    assert builder._find_chapter_data("bad", "", by_vol_num, by_num) is None


# --- 端到端（全链路带数据） ---

def _seed_full_project(builder):
    p = builder.project
    p.set_design("world", [{"Name": "世界观", "Id": "w1", "IsEnabled": True}])
    p.set_design("characters", [
        {"Name": "小明", "Id": "c1", "FlawBelief": "固执", "IsEnabled": True},
        {"Name": "小红", "Id": "c2", "IsEnabled": True},
    ])
    p.set_design("factions", [{"Name": "教团", "Id": "f1", "IsEnabled": True}])
    p.set_design("locations", [{"Name": "森林", "Id": "l1", "IsEnabled": True}])
    p.set_design("plot", [
        {"Name": "冲突1", "Id": "p1", "Conflict": "对抗", "EventType": "",
         "StoryPhase": "", "Result": "", "MainCharacters": "小明", "IsEnabled": True},
        {"Name": "伏笔1", "Id": "p2", "Conflict": "", "EventType": "",
         "StoryPhase": "vol1_ch1", "Result": "", "MainCharacters": "小红", "IsEnabled": True},
    ])
    p.set_design("materials", [])
    p.set_plan("outline", [{"Name": "全书大纲", "Id": "o1", "IsEnabled": True}])
    p.set_plan("volumes", [{
        "Name": "第一卷", "Id": "v1", "VolumeNumber": 1, "VolumeTitle": "初章",
        "VolumeTheme": "成长", "TargetChapterCount": 2,
        "ReferencedCharacterNames": ["小明", "小红"],
        "ReferencedFactionNames": ["教团"], "ReferencedLocationNames": ["森林"],
        "UpdatedAt": "2026-01-01", "IsEnabled": True,
    }])
    p.set_plan("chapters", [
        {"Name": "第1章", "Id": "cp1", "ChapterNumber": 1, "Volume": "第1卷",
         "ChapterTitle": "启程", "MainGoal": "离家", "ChapterTheme": "启",
         "KeyTurn": "遇袭", "Hook": "悬念", "WorldInfoDrop": "w", "CharacterArcProgress": "a",
         "Foreshadowing": "f", "ReferencedCharacterNames": ["小明"],
         "IsEnabled": True},
        {"Name": "第2章", "Id": "cp2", "ChapterNumber": 2, "Volume": "第1卷",
         "ChapterTitle": "森林", "MainGoal": "穿越", "IsEnabled": True},
    ])
    p.set_plan("blueprints_cp1", [{
        "Name": "场景1", "Id": "b1", "ChapterId": "vol1_ch1", "SceneNumber": 1,
        "SceneTitle": "开场", "OneLineStructure": "起", "PovCharacter": "小明",
        "Opening": "o", "Development": "d", "Turning": "t", "Ending": "e", "InfoDrop": "i",
        "Cast": "小明", "Locations": "森林", "Factions": "教团", "IsEnabled": True,
    }])


def test_full_chain_build_guides(builder):
    _seed_full_project(builder)
    outline = builder.build_outline_guide()
    assert set(outline["Volumes"]) == {"v1"}
    vol = outline["Volumes"]["v1"]
    assert vol["VolumeNumber"] == 1
    assert vol["Name"] == "初章"
    assert vol["PlannedChapters"] == 2
    assert vol["ContextIds"]["Characters"] == ["c1", "c2"]
    assert vol["ContextIds"]["Factions"] == ["f1"]
    assert vol["ContextIds"]["Locations"] == ["l1"]
    assert vol["ContextIds"]["TemplateIds"] == []
    assert vol["ContextIds"]["WorldRuleIds"] == ["w1"]

    planning = builder.build_planning_guide(outline)
    pv = planning["Volumes"]["v1"]
    assert set(pv["Chapters"]) == {"vol1_ch1", "vol1_ch2"}
    assert pv["Chapters"]["vol1_ch1"]["ChapterPlanId"] == "cp1"
    assert pv["Chapters"]["vol1_ch1"]["Synopsis"] == "离家"

    blueprint = builder.build_blueprint_guide(planning)
    assert set(blueprint["Chapters"]) == {"vol1_ch1"}
    entry = blueprint["Chapters"]["vol1_ch1"]
    assert entry["ContextIds"]["Characters"] == ["c1"]
    assert entry["ContextIds"]["Locations"] == ["l1"]
    assert entry["ContextIds"]["Factions"] == ["f1"]
    assert entry["ContextIds"]["BlueprintIds"] == ["b1"]
    assert entry["Scenes"][0]["SceneId"] == "b1"
    assert blueprint["ReverseIndex"]["ByCharacter"] == {"c1": ["vol1_ch1"]}

    content = builder.build_content_guide(blueprint)
    ce = content["Chapters"]["vol1_ch1"]
    assert ce["ChapterNumber"] == 1
    assert ce["Title"] == "启程"
    assert ce["Volume"] == "第1卷"
    assert ce["MainGoal"] == "离家"
    assert ce["ChapterTheme"] == "启"
    # p1（小明冲突）+ p2（StoryPhase=vol1_ch1 精确匹配）
    assert set(ce["ContextIds"]["PlotRules"]) == {"p1", "p2"}
    assert ce["ContextIds"]["Conflicts"] == ["p1"]
    assert ce["ContextIds"]["ForeshadowingSetups"] == ["p1", "p2"]
    assert ce["ContextIds"]["ForeshadowingPayoffs"] == []


def test_tracking_guides_with_data(builder):
    _seed_full_project(builder)
    chars = builder.build_character_state_guide()
    assert set(chars["Characters"]) == {"c1", "c2"}
    init_state = chars["Characters"]["c1"]["StateHistory"][0]
    assert init_state["Chapter"] == "init"
    assert init_state["MentalState"] == "固执"
    assert chars["Characters"]["c2"]["StateHistory"][0]["MentalState"] == "普通"

    conflicts = builder.build_conflict_progress_guide()
    assert set(conflicts["Conflicts"]) == {"p1"}
    assert conflicts["Conflicts"]["p1"]["InvolvedCharacters"] == ["小明"]
    assert conflicts["Conflicts"]["p1"]["Status"] == "pending"

    fs = builder.build_foreshadowing_status_guide()
    assert fs["Foreshadowings"]["p1"]["ExpectedSetupChapter"] == ""
    assert fs["Foreshadowings"]["p2"]["ExpectedSetupChapter"] == "vol1_ch1"
    assert fs["Summary"]["Total"] == 2
    assert fs["Summary"]["Setup"] == 1
    assert fs["Summary"]["Payoff"] == 0
    assert fs["Summary"]["Pending"] == 2
    assert fs["Summary"]["CompletionRate"] == "0.0%"

    locs = builder.build_location_state_guide()
    assert locs["Locations"] == {"l1": {"Name": "森林", "CurrentStatus": "normal",
                                        "StateHistory": [], "DriftWarnings": []}}

    facs = builder.build_faction_state_guide()
    assert facs["Factions"] == {"f1": {"Name": "教团", "CurrentStatus": "active",
                                       "StateHistory": [], "DriftWarnings": []}}

    tl = builder.build_timeline_guide()
    assert tl["ChapterTimeline"] == []
    assert tl["CharacterLocations"] == {}

    ppi = builder.build_plot_points_index()
    assert ppi["PlotPoints"] == []
    assert ppi["Keywords"] == {}
    assert ppi["ChapterIndex"] == {}


def test_blueprint_guide_blocks_unmapped_names(builder):
    _seed_full_project(builder)
    builder.project.set_plan("blueprints_cp1", [{
        "Name": "场景1", "Id": "b1", "ChapterId": "vol1_ch1", "SceneNumber": 1,
        "Cast": "不存在的人", "IsEnabled": True,
    }])
    builder.project.set_design("characters", [
        {"Name": "小明", "Id": "c1", "IsEnabled": True},
    ])
    builder._load_cache.clear()
    builder.project.set_plan("volumes", [{
        "Name": "第一卷", "Id": "v1", "VolumeNumber": 1, "VolumeTitle": "初章",
        "VolumeTheme": "成长", "TargetChapterCount": 2,
        "ReferencedCharacterNames": ["小明"],
        "ReferencedFactionNames": ["教团"], "ReferencedLocationNames": ["森林"],
        "UpdatedAt": "2026-01-01", "IsEnabled": True,
    }])
    outline = builder.build_outline_guide()
    planning = builder.build_planning_guide(outline)
    with pytest.raises(ValueError, match="未映射"):
        builder.build_blueprint_guide(planning)


def test_outline_guide_blocks_unmapped_volume_refs(builder):
    _seed_full_project(builder)
    builder.project.set_plan("volumes", [{
        "Name": "第二卷", "Id": "v2", "VolumeNumber": 2,
        "ReferencedCharacterNames": ["神秘人"],
        "IsEnabled": True,
    }])
    with pytest.raises(ValueError, match="未映射"):
        builder.build_outline_guide()