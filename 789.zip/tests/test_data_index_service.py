# -*- coding: utf-8 -*-
"""tests for data_index_service.py"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock, patch
from novel_writer.implementations.indexing.data_index_service import (
    DataIndexService, IndexEntry, EntityCategory
)


@pytest.fixture
def service():
    return DataIndexService()


# --- initialize ---

def test_initialize_normal(service):
    chars = [{"Id": "c1", "Name": "小明"}]
    locs = [{"Id": "l1", "Name": "森林"}]
    facs = [{"Id": "f1", "Name": "教团"}]
    plots = [{"Id": "p1", "Name": "主线"}]
    worlds = [{"Id": "w1", "Name": "世界观"}]
    service.initialize(chars, locs, facs, plots, worlds)
    assert service.is_initialized is True
    assert service.find_by_id("c1") is not None
    assert service.find_by_id("l1") is not None
    assert service.find_by_id("f1") is not None
    assert service.find_by_id("p1") is not None
    assert service.find_by_id("w1") is not None


def test_initialize_idempotent(service):
    service.initialize([{"Id": "c1", "Name": "小明"}])
    service.initialize([{"Id": "c2", "Name": "小红"}])
    assert service.find_by_id("c2") is None  # already initialized


def test_initialize_empty(service):
    service.initialize()
    assert service.is_initialized is True


def test_initialize_with_objects(service):
    class Obj:
        def __init__(self, id, name):
            self.Id = id
            self.Name = name
    service.initialize(characters=[Obj("c1", "小明")])
    assert service.find_by_id("c1") is not None


# --- clear ---

def test_clear(service):
    service.initialize([{"Id": "c1", "Name": "小明"}])
    assert service.is_initialized is True
    service.clear()
    assert service.is_initialized is False
    assert service.find_by_id("c1") is None


# --- add_entry (via initialize) ---

def test_add_entry_normal(service):
    service.initialize([{"Id": "c1", "Name": "小明"}])
    entry = service.find_by_id("c1")
    assert entry.Name == "小明"
    assert entry.Category == EntityCategory.CHARACTER


def test_add_entry_no_id(service):
    service.initialize([{"Id": "", "Name": "无名"}])
    assert service.find_by_id("") is None


# --- find_by_category ---

def test_find_by_category(service):
    service.initialize(
        characters=[{"Id": "c1", "Name": "小明"}, {"Id": "c2", "Name": "小红"}],
        locations=[{"Id": "l1", "Name": "森林"}],
    )
    ids = service.list_ids_by_category(EntityCategory.CHARACTER)
    assert sorted(ids) == ["c1", "c2"]
    loc_ids = service.list_ids_by_category(EntityCategory.LOCATION)
    assert loc_ids == ["l1"]


def test_find_by_category_empty(service):
    service.initialize()
    assert service.list_ids_by_category(EntityCategory.CHARACTER) == []


# --- search ---

def test_search_by_name(service):
    service.initialize(
        characters=[{"Id": "c1", "Name": "小明"}, {"Id": "c2", "Name": "小红"}],
    )
    result = service.find_by_name("小明")
    assert len(result) == 1
    assert result[0].Id == "c1"


def test_search_by_name_not_found(service):
    service.initialize()
    assert service.find_by_name("不存在") == []


def test_search_by_name_empty(service):
    assert service.find_by_name("") == []


def test_search_by_keyword(service):
    service.initialize(
        characters=[{"Id": "c1", "Name": "小明"}, {"Id": "c2", "Name": "小红"}],
    )
    result = service.search_by_name("明")
    assert len(result) == 1
    assert result[0].Id == "c1"


def test_search_by_keyword_empty(service):
    assert service.search_by_name("") == []


def test_search_by_category(service):
    service.initialize(
        characters=[{"Id": "c1", "Name": "小明"}, {"Id": "c2", "Name": "小红"}],
        locations=[{"Id": "l1", "Name": "森林"}],
    )
    result = service.search_by_category(EntityCategory.CHARACTER, "明")
    assert len(result) == 1
    assert result[0].Id == "c1"


def test_search_by_category_no_keyword(service):
    service.initialize(
        characters=[{"Id": "c1", "Name": "小明"}, {"Id": "c2", "Name": "小红"}],
    )
    result = service.search_by_category(EntityCategory.CHARACTER, "")
    assert len(result) == 2


# --- update_entry ---

def test_update_entry(service):
    service.initialize([{"Id": "c1", "Name": "小明"}])
    service.update_entry("c1", "小明新", EntityCategory.CHARACTER, {"new": True})
    entry = service.find_by_id("c1")
    assert entry.Name == "小明新"