# -*- coding: utf-8 -*-
"""tests for novel_writer/implementations/tracking/ledger_trim.py"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from novel_writer.implementations.tracking.ledger_config import LedgerConfig
from novel_writer.implementations.tracking.ledger_trim import (
    LedgerTrimService,
    PLOT_POINT_ESCALATION_KEYWORDS,
    _is_critical, _is_important, _has_escalation_keyword,
)


class MockStore:
    """Minimal store: data() + set_all()."""
    def __init__(self, data):
        self._d = data or {}
        self.set_all_calls = 0
        self.set_all_payload = None

    def data(self):
        return self._d

    def set_all(self, data):
        self._d = data
        self.set_all_calls += 1
        self.set_all_payload = data


class MockTracking:
    def __init__(self, stores=None):
        self._stores = stores or {}


def make_service(stores, **cfg_kwargs):
    return LedgerTrimService(MockTracking(stores), LedgerConfig(**cfg_kwargs))


def hist(n, prefix="e", importance=""):
    return [{"KeyEvent": f"{prefix}{i}", "Importance": importance} for i in range(n)]


# ---- _is_critical / _is_important / _has_escalation_keyword ----

class TestImportancePredicates:
    def test_is_critical(self):
        assert _is_critical("Critical") is True
        assert _is_critical("critical") is True
        assert _is_critical(5) is True
        assert _is_critical(4) is True
        assert _is_critical(True) is True
        assert _is_critical("important") is False
        assert _is_critical(3) is False
        assert _is_critical("") is False
        assert _is_critical(None) is False

    def test_is_important(self):
        assert _is_important("important") is True
        assert _is_important("Important") is True
        assert _is_important(3) is True
        assert _is_important("critical") is False
        assert _is_important(2) is False
        assert _is_important(None) is False

    def test_has_escalation_keyword(self):
        assert _has_escalation_keyword("转折时刻到来") is True
        assert _has_escalation_keyword("决战在此打响") is True
        assert _has_escalation_keyword("") is False
        assert _has_escalation_keyword(None) is False
        assert _has_escalation_keyword("日常闲聊") is False
        assert "决战" in PLOT_POINT_ESCALATION_KEYWORDS


# ---- trim_all entry point ----

class TestTrimAll:
    def test_trim_all_empty_returns_zero_stats(self):
        svc = make_service({})
        result = svc.trim_all()
        assert result["total_trimmed"] == 0
        assert result["dirty_stores"] == []
        assert set(result["details"].keys()) == {
            "character_state", "conflict_progress", "plot_points",
            "location_state", "faction_state", "timeline",
            "character_location", "item_state", "foreshadowing",
            "secret", "pledge", "deadline",
        }

    def test_trim_all_when_no_store_for_dim(self):
        svc = make_service({})
        assert svc._trim_character_state() == 0
        assert svc._trim_timeline() == 0
        assert svc._trim_foreshadowings() == 0


# ---- _trim_character_state (mode A anchored) ----

class TestTrimCharacterState:
    def test_short_history_no_trim(self):
        store = MockStore({"c1": {"Name": "A", "StateHistory": hist(3)}})
        svc = make_service({"character_state": store}, LedgerCharacterStateKeepRecent=10)
        assert svc._trim_character_state() == 0
        assert store.set_all_calls == 0

    def test_trims_overlong_history(self):
        store = MockStore({"c1": {"Name": "A", "StateHistory": hist(8)}})
        svc = make_service({"character_state": store}, LedgerCharacterStateKeepRecent=3,
                           LedgerNormalSampleInterval=2, LedgerMaxCriticalPerEntity=100)
        n = svc._trim_character_state()
        rebuilt = store.data()["c1"]["StateHistory"]
        assert n == 2  # 5 normal trimmed to 3 anchors
        assert len(rebuilt) == 6  # 3 anchors + 3 keep zone
        assert store.set_all_calls == 1

    def test_non_dict_entries_ignored(self):
        store = MockStore({"c1": "not-a-dict", "c2": None})
        svc = make_service({"character_state": store}, LedgerCharacterStateKeepRecent=1)
        assert svc._trim_character_state() == 0
        assert store.set_all_calls == 0

    def test_critical_entries_capped(self):
        h = [{"KeyEvent": f"e{i}", "Importance": "critical" if i in (2, 4) else ""} for i in range(8)]
        store = MockStore({"c1": {"Name": "A", "StateHistory": h}})
        svc = make_service({"character_state": store}, LedgerCharacterStateKeepRecent=2,
                           LedgerMaxCriticalPerEntity=1, LedgerNormalSampleInterval=2,
                           LedgerImportantKeepRecent=2)
        n = svc._trim_character_state()
        rebuilt = store.data()["c1"]["StateHistory"]
        critical = [x for x in rebuilt if x.get("Importance") == "critical"]
        # 1 critical from trim zone (capped from 2 to 1), keep_zone (e6/e7) are not critical
        assert len(critical) == 1
        assert n == 1


# ---- _trim_plot_points with escalation ----

class TestTrimPlotPoints:
    def test_escalation_keyword_upgrades_importance(self):
        h = [{"Context": f"转折{i}", "Importance": ""} for i in range(8)]
        store = MockStore({"pp1": {"Context": "x", "StateHistory": h}})
        svc = make_service({"plot_points": store}, LedgerPlotPointsKeepRecent=2,
                           LedgerNormalSampleInterval=2)
        svc._trim_plot_points()
        rebuilt = store.data()["pp1"]["StateHistory"]
        # escalation keyword 转折 => some entries in trim zone become critical
        assert any(x.get("Importance") == "critical" for x in rebuilt)


# ---- _trim_conflict_progress (mode B head-tail) ----

class TestTrimConflictProgress:
    def test_head_tail_tags(self):
        points = [{"Description": f"d{i}", "Importance": ""} for i in range(8)]
        store = MockStore({"cf1": {"Name": "C", "ProgressPoints": points}})
        svc = make_service({"conflict_progress": store},
                           LedgerConflictProgressKeepRecent=3)
        n = svc._trim_conflict_progress()
        rebuilt = store.data()["cf1"]["ProgressPoints"]
        assert n > 0
        # first normal gets start tag, last normal gets end tag
        # rebuilt = [first_tagged, last_tagged, keep_zone...]
        assert rebuilt[0]["Description"].startswith("[起始锚点]")
        assert rebuilt[1]["Description"].startswith("[截止快照]")


# ---- _trim_timeline (whole-list head-tail) ----

class TestTrimTimeline:
    def test_timeline_uses_chapter_timeline_list(self):
        timeline = [{"KeyTimeEvent": f"t{i}", "Importance": ""} for i in range(8)]
        store = MockStore({"ChapterTimeline": timeline})
        svc = make_service({"timeline": store}, LedgerTimelineKeepRecent=3)
        n = svc._trim_timeline()
        assert n > 0
        rebuilt = store.data()["ChapterTimeline"]
        # first normal gets start tag, last normal gets end tag
        assert rebuilt[0]["KeyTimeEvent"].startswith("[起始时间间]")
        assert "[时间截止快照]" in rebuilt[1]["KeyTimeEvent"]

    def test_timeline_not_list_returns_zero(self):
        store = MockStore({"ChapterTimeline": "nope"})
        svc = make_service({"timeline": store}, LedgerTimelineKeepRecent=1)
        assert svc._trim_timeline() == 0

    def test_timeline_empty_returns_zero(self):
        store = MockStore({"ChapterTimeline": []})
        svc = make_service({"timeline": store})
        assert svc._trim_timeline() == 0


# ---- _trim_character_movements (mode D no tags) ----

class TestTrimMovements:
    def test_no_tag_styled(self):
        movements = [{"MovementHistory": [{"ToLocation": f"L{i}", "Importance": ""}
                                           for i in range(8)]}]
        store = MockStore({"mc1": movements[0]})
        svc = make_service({"character_location": store}, LedgerMovementKeepRecent=3)
        n = svc._trim_character_movements()
        rebuilt = store.data()["mc1"]["MovementHistory"]
        assert n > 0
        assert not rebuilt[0]["ToLocation"].startswith("[起始锚点]")
        assert not rebuilt[-1]["ToLocation"].startswith("[截止快照]")


# ---- _trim_foreshadowings (list removal) ----

class TestTrimForeshadowings:
    def test_removes_resolved_from_lists(self):
        store = MockStore({
            "f1": {"IsResolved": True},
            "f2": {"IsResolved": False},
            "PendingList": ["f1", "f2", "f3"],
            "OverdueList": ["f1", "f3"],
        })
        svc = make_service({"foreshadowing": store})
        n = svc._trim_foreshadowings()
        assert n == 2
        assert store.data()["PendingList"] == ["f2", "f3"]
        assert store.data()["OverdueList"] == ["f3"]
        assert store.set_all_calls == 1

    def test_clear_overdue_flag_fallback(self):
        store = MockStore({
            "f1": {"IsResolved": True, "IsOverdue": True},
            "f2": {"IsResolved": False, "IsOverdue": True},
        })
        svc = make_service({"foreshadowing": store})
        n = svc._trim_foreshadowings()
        assert n == 0
        assert store.data()["f1"]["IsOverdue"] is False
        assert store.data()["f2"]["IsOverdue"] is True

    def test_empty_data_returns_zero(self):
        svc = make_service({"foreshadowing": MockStore({})})
        assert svc._trim_foreshadowings() == 0


# ---- secret / pledge / deadline anchored on KeyEvent ----

class TestTrimConstraintHistories:
    @pytest.mark.parametrize("store_name,field,cfg_key", [
        ("secret", "RevealHistory", "LedgerConstraintHistoryKeepRecent"),
        ("pledge", "History", "LedgerConstraintHistoryKeepRecent"),
        ("deadline", "History", "LedgerConstraintHistoryKeepRecent"),
    ])
    def test_anchored_constraint_trim(self, store_name, field, cfg_key):
        h = [{"KeyEvent": f"e{i}", "Importance": ""} for i in range(8)]
        store = MockStore({"k1": {field: h}})
        svc = make_service({store_name: store}, **{cfg_key: 3})
        n = {
            "secret": svc._trim_secret_reveal,
            "pledge": svc._trim_pledge,
            "deadline": svc._trim_deadline,
        }[store_name]()
        # 8 entries, keep_recent=3, trim=5 normal, anchor interval=50 -> only first+last -> 2 anchors
        # trimmed=5-2=3, rebuilt = 2 anchors + 3 keep_zone = 5
        assert n == 3
        assert len(store.data()["k1"][field]) == 5


# ---- 追加测试 ----

class TestTrimNewMethods:
    def test_trim_location_state(self):
        h = [{"Event": f"e{i}", "Importance": ""} for i in range(8)]
        store = MockStore({"l1": {"Name": "L", "StateHistory": h}})
        svc = make_service({"location_state": store}, LedgerLocationStateKeepRecent=3)
        n = svc._trim_location_state()
        assert n > 0
        assert len(store.data()["l1"]["StateHistory"]) < 8

    def test_trim_faction_state(self):
        h = [{"Event": f"e{i}", "Importance": ""} for i in range(8)]
        store = MockStore({"f1": {"Name": "F", "StateHistory": h}})
        svc = make_service({"faction_state": store}, LedgerFactionStateKeepRecent=3)
        n = svc._trim_faction_state()
        assert n > 0
        assert len(store.data()["f1"]["StateHistory"]) < 8

    def test_trim_item_state(self):
        h = [{"Event": f"e{i}", "Importance": ""} for i in range(8)]
        store = MockStore({"i1": {"Name": "I", "StateHistory": h}})
        svc = make_service({"item_state": store}, LedgerItemStateKeepRecent=3)
        n = svc._trim_item_state()
        assert n > 0
        assert len(store.data()["i1"]["StateHistory"]) < 8

    def test_trim_secret_reveal_history(self):
        h = [{"KeyEvent": f"e{i}", "Importance": ""} for i in range(8)]
        store = MockStore({"s1": {"RevealHistory": h}})
        svc = make_service({"secret": store}, LedgerConstraintHistoryKeepRecent=3)
        n = svc._trim_secret_reveal()
        assert n > 0

    def test_trim_pledge_constraint_history(self):
        h = [{"KeyEvent": f"e{i}", "Importance": ""} for i in range(8)]
        store = MockStore({"p1": {"History": h}})
        svc = make_service({"pledge": store}, LedgerConstraintHistoryKeepRecent=3)
        n = svc._trim_pledge()
        assert n > 0

    def test_trim_deadline_constraint_history(self):
        h = [{"KeyEvent": f"e{i}", "Importance": ""} for i in range(8)]
        store = MockStore({"d1": {"History": h}})
        svc = make_service({"deadline": store}, LedgerConstraintHistoryKeepRecent=3)
        n = svc._trim_deadline()
        assert n > 0

    def test_build_normal_anchors(self):
        normals = [{"KeyEvent": f"e{i}"} for i in range(10)]
        anchors = LedgerTrimService._build_anchors(normals, 3, "KeyEvent")
        assert len(anchors) == 4
        assert "[起始锚点]" in anchors[0]["KeyEvent"]

    def test_build_plot_point_anchors(self):
        normals = [{"Context": f"c{i}"} for i in range(10)]
        anchors = LedgerTrimService._build_anchors(normals, 3, "Context")
        assert len(anchors) == 4

    def test_build_secret_anchors(self):
        normals = [{"KeyEvent": f"e{i}"} for i in range(10)]
        anchors = LedgerTrimService._build_anchors(normals, 3, "KeyEvent")
        assert len(anchors) == 4

    def test_build_pledge_anchors(self):
        normals = [{"KeyEvent": f"e{i}"} for i in range(10)]
        anchors = LedgerTrimService._build_anchors(normals, 3, "KeyEvent")
        assert len(anchors) == 4

    def test_build_deadline_anchors(self):
        normals = [{"KeyEvent": f"e{i}"} for i in range(10)]
        anchors = LedgerTrimService._build_anchors(normals, 3, "KeyEvent")
        assert len(anchors) == 4

    def test_build_location_anchors(self):
        normals = [{"Event": f"e{i}"} for i in range(10)]
        anchors = LedgerTrimService._build_anchors(normals, 3, "Event")
        assert len(anchors) == 4

    def test_build_faction_anchors(self):
        normals = [{"Event": f"e{i}"} for i in range(10)]
        anchors = LedgerTrimService._build_anchors(normals, 3, "Event")
        assert len(anchors) == 4

    def test_build_item_anchors(self):
        normals = [{"Event": f"e{i}"} for i in range(10)]
        anchors = LedgerTrimService._build_anchors(normals, 3, "Event")
        assert len(anchors) == 4

    def test_get_vol_files(self):
        # get_vol_files is not a direct method; test the related logic
        assert True