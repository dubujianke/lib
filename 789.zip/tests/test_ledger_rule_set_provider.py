# -*- coding: utf-8 -*-
"""LedgerRuleSetProvider 单元测试 — 对标 4.1.1 Rules/LedgerRuleSetProvider.cs"""
import sys
import os
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock

from novel_writer.implementations.tracking.rules.ledger_rule_set_provider import (
    LedgerRuleSetProvider,
    build_ruleset_by_genre,
    XIANXIA_ABILITY_LOSS_KEYWORDS,
    URBAN_ABILITY_LOSS_KEYWORDS,
)
from novel_writer.implementations.tracking.rules.ledger_rule_set import LedgerRuleSet


# =====================================================================
# get_ruleset_for_gate（按题材缓存规则集）
# =====================================================================

def test_get_ruleset_for_gate_default():
    provider = LedgerRuleSetProvider()
    rs = provider.get_ruleset_for_gate()
    assert isinstance(rs, LedgerRuleSet)
    assert rs.MaxTrustDelta == 30


def test_get_ruleset_for_gate_caches():
    provider = LedgerRuleSetProvider()
    rs1 = provider.get_ruleset_for_gate()
    rs2 = provider.get_ruleset_for_gate()
    assert rs1 is rs2  # 同一缓存对象


def test_get_ruleset_for_gate_with_project():
    project = MagicMock()
    project.load_design.return_value = {"items": []}
    provider = LedgerRuleSetProvider(project)
    rs = provider.get_ruleset_for_gate()
    assert isinstance(rs, LedgerRuleSet)


# =====================================================================
# build_ruleset_by_genre（按题材构建规则集）
# =====================================================================

def test_build_ruleset_by_genre_xianxia():
    rs = build_ruleset_by_genre("玄幻")
    assert rs.EnableAbilityLossRequiresEvent is True
    assert len(rs.AbilityLossKeywords) > 0


def test_build_ruleset_by_genre_urban():
    rs = build_ruleset_by_genre("都市")
    assert rs.EnableAbilityLossRequiresEvent is True
    assert len(rs.AbilityLossKeywords) > 0


def test_build_ruleset_by_genre_universal_default():
    rs = build_ruleset_by_genre("历史")
    assert rs.EnableAbilityLossRequiresEvent is False
    assert rs.EnableConflictFlowCheck is True


def test_build_ruleset_by_genre_none():
    rs = build_ruleset_by_genre(None)
    assert isinstance(rs, LedgerRuleSet)
    assert rs.EnableConflictFlowCheck is True


# =====================================================================
# try_resolve_genre_from_enabled_creative_materials（题材解析）
# =====================================================================

def test_resolve_genre_from_creative_materials():
    project = MagicMock()
    project.load_design.return_value = {"items": [
        {"IsEnabled": True, "Genre": "玄幻", "ModifiedTime": "2024-01-01"},
        {"IsEnabled": False, "Genre": "都市", "ModifiedTime": "2024-02-01"},
    ]}
    provider = LedgerRuleSetProvider(project)
    genre = provider._resolve_genre_from_creative_materials()
    assert genre == "玄幻"


def test_resolve_genre_no_enabled_materials():
    project = MagicMock()
    project.load_design.return_value = {"items": [
        {"IsEnabled": False, "Genre": "玄幻"},
    ]}
    provider = LedgerRuleSetProvider(project)
    assert provider._resolve_genre_from_creative_materials() is None


def test_resolve_genre_no_materials():
    project = MagicMock()
    project.load_design.return_value = {}
    provider = LedgerRuleSetProvider(project)
    assert provider._resolve_genre_from_creative_materials() is None


def test_resolve_genre_exception():
    project = MagicMock()
    project.load_design.side_effect = Exception("boom")
    provider = LedgerRuleSetProvider(project)
    assert provider._resolve_genre_from_creative_materials() is None