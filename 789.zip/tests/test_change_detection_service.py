# -*- coding: utf-8 -*-
"""tests for change_detection_service.py"""
import sys, os, json, tempfile, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock, patch
from novel_writer.implementations.change_detection.change_detection_service import ChangeDetectionService
from novel_writer.models.change_detection.change_status import ChangeStatus, ChangeStatusType


class MockProject:
    def __init__(self):
        self.dir = tempfile.mkdtemp(prefix="test_changedet_")
        self._design = {}
        self._plan = {}

    def set_design(self, entity, data):
        self._design[entity] = data

    def set_plan(self, entity, data):
        self._plan[entity] = data

    def load_design(self, entity):
        return self._design.get(entity, [])

    def load_plan(self, entity):
        return self._plan.get(entity, [])


@pytest.fixture
def service():
    return ChangeDetectionService(MockProject())


# --- init ---

def test_init(service):
    assert service is not None
    assert service._last_package_time is None


# --- has_changes ---

def test_has_changes_returns_false_for_latest(service):
    service._status_cache["Design/全局设定"] = ChangeStatus(
        ModulePath="Design/全局设定", Status=ChangeStatusType.LATEST)
    assert service.has_changes("Design/全局设定") is False


def test_has_changes_returns_true_for_changed(service):
    service._status_cache["Design/全局设定"] = ChangeStatus(
        ModulePath="Design/全局设定", Status=ChangeStatusType.CHANGED)
    assert service.has_changes("Design/全局设定") is True


def test_has_changes_returns_true_for_never(service):
    service._status_cache["Design/全局设定"] = ChangeStatus(
        ModulePath="Design/全局设定", Status=ChangeStatusType.NEVER)
    assert service.has_changes("Design/全局设定") is True


# --- get_changed_modules ---

def test_get_changed_modules(service):
    service._status_cache["Design/全局设定"] = ChangeStatus(
        ModulePath="Design/全局设定", Status=ChangeStatusType.CHANGED)
    service._status_cache["Design/设计元素"] = ChangeStatus(
        ModulePath="Design/设计元素", Status=ChangeStatusType.LATEST)
    service._status_cache["Generate/全书设定"] = ChangeStatus(
        ModulePath="Generate/全书设定", Status=ChangeStatusType.NEVER)
    changed = service.get_changed_modules()
    assert "Design/全局设定" in changed
    assert "Generate/全书设定" in changed
    assert "Design/设计元素" not in changed


# --- get_status ---

def test_get_status_returns_unknown_status(service):
    status = service.get_status("NonExistent")
    assert status.ModulePath == "NonExistent"
    assert status.Status == ChangeStatusType.CHANGED


def test_get_status_caches_result(service):
    status1 = service.get_status("Design/全局设定")
    status2 = service.get_status("Design/全局设定")
    assert status1 is status2


# --- get_all_statuses ---

def test_get_all_statuses(service):
    statuses = service.get_all_statuses()
    assert len(statuses) > 0
    for s in statuses:
        assert s.ModulePath in ("Design/全局设定", "Design/设计元素", "Generate/全书设定", "Generate/创作元素")


# --- mark_as_packaged ---

def test_mark_as_packaged(service):
    service._status_cache["Design/全局设定"] = ChangeStatus(
        ModulePath="Design/全局设定", Status=ChangeStatusType.CHANGED)
    service.mark_as_packaged("Design/全局设定")
    assert service._status_cache["Design/全局设定"].Status == ChangeStatusType.LATEST
    assert service._status_cache["Design/全局设定"].LastPackaged is not None


def test_mark_as_packaged_unknown_module(service):
    service.mark_as_packaged("NonExistent")
    # should not crash


# --- mark_all_as_packaged ---

def test_mark_all_as_packaged(service):
    service._status_cache["Design/全局设定"] = ChangeStatus(
        ModulePath="Design/全局设定", Status=ChangeStatusType.CHANGED)
    service._status_cache["Generate/全书设定"] = ChangeStatus(
        ModulePath="Generate/全书设定", Status=ChangeStatusType.NEVER)
    service.mark_all_as_packaged()
    assert service._status_cache["Design/全局设定"].Status == ChangeStatusType.LATEST
    assert service._status_cache["Generate/全书设定"].Status == ChangeStatusType.LATEST
    assert service._last_package_time is not None


# --- _get_all_modules ---

def test_get_all_modules(service):
    modules = service._get_all_modules()
    assert len(modules) == 4
    paths = [m[0] for m in modules]
    assert "Design/全局设定" in paths
    assert "Design/设计元素" in paths
    assert "Generate/全书设定" in paths
    assert "Generate/创作元素" in paths


# --- _find_module ---

def test_find_module_found(service):
    m = service._find_module("Design/全局设定")
    assert m is not None
    assert m[0] == "Design/全局设定"


def test_find_module_not_found(service):
    m = service._find_module("NonExistent")
    assert m is None


# --- _refresh_module_status (no files) ---

def test_refresh_module_status_no_dir(service):
    module = ("Design/全局设定", "全局设定", "Design/全局设定")
    service._refresh_module_status(module)
    status = service._status_cache["Design/全局设定"]
    assert status.Status == ChangeStatusType.NEVER
    assert status.ItemCount == 0


# --- _refresh_module_status with files ---

def test_refresh_module_status_with_files(service):
    module_dir = os.path.join(service.project.dir, "Design", "全局设定")
    os.makedirs(module_dir, exist_ok=True)
    for i in range(3):
        with open(os.path.join(module_dir, f"file{i}.json"), "w") as f:
            f.write('["a"]')
    module = ("Design/全局设定", "全局设定", "Design/全局设定")
    service._refresh_module_status(module)
    status = service._status_cache["Design/全局设定"]
    assert status.ItemCount == 3
    assert status.Status == ChangeStatusType.NEVER  # no last_package_time


# --- _refresh_module_status with last_package_time ---

def test_refresh_module_status_with_package_time(service):
    service._last_package_time = "2099-01-01T00:00:00"
    module_dir = os.path.join(service.project.dir, "Design", "全局设定")
    os.makedirs(module_dir, exist_ok=True)
    with open(os.path.join(module_dir, "file.json"), "w") as f:
        f.write("{}")
    module = ("Design/全局设定", "全局设定", "Design/全局设定")
    service._refresh_module_status(module)
    status = service._status_cache["Design/全局设定"]
    assert status.Status == ChangeStatusType.LATEST  # file mtime < 2099


# --- _load_manifest_info ---

def test_load_manifest_info_no_file(service):
    service._load_manifest_info()
    assert service._last_package_time is None


def test_load_manifest_info_with_file(service):
    manifest_data = {"PublishTime": "2024-06-01T12:00:00"}
    path = os.path.join(service.project.dir, "manifest.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(manifest_data, f)
    service._load_manifest_info()
    assert service._last_package_time == "2024-06-01T12:00:00"


def test_load_manifest_info_corrupted(service):
    path = os.path.join(service.project.dir, "manifest.json")
    with open(path, "w", encoding="utf-8") as f:
        f.write("not json")
    service._load_manifest_info()
    assert service._last_package_time is None


# --- _now and _ts_to_str ---

def test_now_format(service):
    now = service._now()
    assert "T" in now
    assert len(now) == 19


def test_ts_to_str(service):
    result = service._ts_to_str(1000000000.0)
    assert "T" in result
    assert len(result) == 19


# --- get_status refreshes from filesystem ---

def test_get_status_refreshes_from_fs(service):
    # guarantee status not cached
    assert "Design/全局设定" not in service._status_cache
    module_dir = os.path.join(service.project.dir, "Design", "全局设定")
    os.makedirs(module_dir, exist_ok=True)
    with open(os.path.join(module_dir, "data.json"), "w") as f:
        f.write('["item"]')
    status = service.get_status("Design/全局设定")
    assert status.ItemCount == 1


# --- get_status preserves IsEnabled ---

def test_get_status_preserves_is_enabled(service):
    service._status_cache["Design/全局设定"] = ChangeStatus(
        ModulePath="Design/全局设定", Status=ChangeStatusType.LATEST, IsEnabled=False)
    module_dir = os.path.join(service.project.dir, "Design", "全局设定")
    os.makedirs(module_dir, exist_ok=True)
    with open(os.path.join(module_dir, "data.json"), "w") as f:
        f.write("{}")
    status = service.get_status("Design/全局设定")
    assert status.IsEnabled is False


# --- get_status fallback default ---

def test_get_status_fallback(service):
    status = service.get_status("NonExistent/Module")
    assert status.ModulePath == "NonExistent/Module"
    assert status.IsEnabled is True