# -*- coding: utf-8 -*-
"""ContextIdsCompletenessChecker 单元测试 — 对标 Implementations/Packaging/ContextIdsCompletenessChecker.cs"""
import sys
import os
import tempfile
import json

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock

from novel_writer.implementations.packaging.context_ids_completeness_checker import (
    ContextIdsCompletenessChecker,
    CompletenessWarnings,
    ForeshadowingWarning,
    ConflictWarning,
    EmptyContextWarning,
)


class FakeStore:
    def __init__(self, data=None):
        self._data = data or {}

    def data(self):
        return self._data


class FakeProject:
    def __init__(self, project_dir):
        self.dir = project_dir
        self._stores = {}

    def tracking(self, name):
        if name not in self._stores:
            self._stores[name] = FakeStore()
        return self._stores[name]


@pytest.fixture
def checker():
    d = tempfile.mkdtemp(prefix="test_ctx_check_")
    project = FakeProject(d)
    return ContextIdsCompletenessChecker(project), project, d


# =====================================================================
# run（运行完整性检查）
# =====================================================================

def test_run_returns_warnings(checker):
    svc, project, _ = checker
    warnings = svc.run()
    assert isinstance(warnings, CompletenessWarnings)
    assert warnings.Summary != ""


def test_run_detects_unresolved_foreshadowing(checker):
    svc, project, _ = checker
    project.tracking("foreshadowing")._data["FS1"] = {
        "Name": "身世", "IsSetup": True, "IsResolved": False, "Tier": "Tier-1",
        "ActualSetupChapter": "vol1_ch1",
    }
    warnings = svc.run()
    assert len(warnings.ForeshadowingWarnings) == 1
    assert warnings.ForeshadowingWarnings[0].Name == "身世"


def test_run_skips_resolved_foreshadowing(checker):
    svc, project, _ = checker
    project.tracking("foreshadowing")._data["FS1"] = {
        "Name": "身世", "IsSetup": True, "IsResolved": True, "Tier": "Tier-1",
    }
    warnings = svc.run()
    assert len(warnings.ForeshadowingWarnings) == 0


def test_run_detects_unresolved_conflict(checker):
    svc, project, _ = checker
    project.tracking("conflict_progress")._data["X1"] = {
        "Name": "宗门大战", "Status": "active", "Tier": "Tier-2",
    }
    warnings = svc.run()
    assert len(warnings.ConflictWarnings) == 1


def test_run_skips_resolved_conflict(checker):
    svc, project, _ = checker
    project.tracking("conflict_progress")._data["X1"] = {
        "Name": "宗门大战", "Status": "resolved",
    }
    warnings = svc.run()
    assert len(warnings.ConflictWarnings) == 0


def test_run_exception_safe(checker):
    svc, project, _ = checker
    project.tracking = MagicMock(side_effect=Exception("boom"))
    warnings = svc.run()
    assert isinstance(warnings, CompletenessWarnings)


# =====================================================================
# write_warnings（写入警告到文件）
# =====================================================================

def test_write_warnings_creates_file(checker):
    svc, project, d = checker
    warnings = CompletenessWarnings()
    warnings.Summary = "test"
    svc._write_warnings(warnings)
    path = os.path.join(d, "guides", "completeness_warnings.json")
    assert os.path.exists(path)
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    assert data["Summary"] == "test"


def test_write_warnings_with_content(checker):
    svc, project, d = checker
    warnings = CompletenessWarnings()
    fw = ForeshadowingWarning()
    fw.ForeshadowId = "FS1"
    fw.Name = "身世"
    fw.Tier = "Tier-1"
    fw.SetupChapter = "vol1_ch1"
    fw.Issue = "未回收"
    warnings.ForeshadowingWarnings.append(fw)
    cw = ConflictWarning()
    cw.ConflictId = "X1"
    cw.Name = "大战"
    cw.Status = "active"
    cw.Issue = "未解决"
    warnings.ConflictWarnings.append(cw)
    svc._write_warnings(warnings)
    path = os.path.join(d, "guides", "completeness_warnings.json")
    assert os.path.exists(path)
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    assert len(data["ForeshadowingWarnings"]) == 1
    assert len(data["ConflictWarnings"]) == 1


def test_write_warnings_creates_guides_dir(checker):
    svc, project, d = checker
    # 删除 guides 目录确保创建
    guides_dir = os.path.join(d, "guides")
    if os.path.exists(guides_dir):
        import shutil
        shutil.rmtree(guides_dir)
    svc._write_warnings(CompletenessWarnings())
    assert os.path.exists(guides_dir)


# =====================================================================
# conflict_progress_guide（常量）
# =====================================================================

def test_conflict_progress_guide():
    assert ContextIdsCompletenessChecker._conflict_progress_guide() == "conflict_progress_guide"


# =====================================================================
# CompletenessWarnings 默认值
# =====================================================================

def test_completeness_warnings_defaults():
    w = CompletenessWarnings()
    assert w.ForeshadowingWarnings == []
    assert w.ConflictWarnings == []
    assert w.EmptyContextWarnings == []
    assert w.Summary == ""


def test_forehadowing_warning_defaults():
    w = ForeshadowingWarning()
    assert w.ForeshadowId == ""
    assert w.Name == ""
    assert w.Issue == ""


def test_conflict_warning_defaults():
    w = ConflictWarning()
    assert w.ConflictId == ""
    assert w.Issue == ""


def test_empty_context_warning_defaults():
    w = EmptyContextWarning()
    assert w.ChapterId == ""
    assert w.Issue == ""