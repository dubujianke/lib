# -*- coding: utf-8 -*-
"""PledgeConstraintService 单元测试 — 对标 4.1.1 PledgeConstraintService.cs"""
import sys
import os
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock

from novel_writer.implementations.tracking.pledge_constraint_service import (
    PledgeConstraintService,
    _ACTION_STATUS,
)


class FakeStore:
    def __init__(self):
        self._data = {}

    def data(self):
        return self._data

    def set_all(self, data):
        self._data = data


class FakeProject:
    def __init__(self, **stores):
        self.dir = tempfile.mkdtemp(prefix="test_pledge_")
        self._stores = dict(stores)

    def tracking(self, name):
        return self._stores.setdefault(name, FakeStore())


@pytest.fixture
def service():
    store = FakeStore()
    project = FakeProject(pledge=store)
    return PledgeConstraintService(project), project, store


def make_change(**kwargs):
    change = MagicMock()
    change.PledgeId = kwargs.get("PledgeId", "P000000000001")
    change.PledgeName = kwargs.get("PledgeName", "")
    change.Action = kwargs.get("Action", "create")
    change.Type = kwargs.get("Type", "")
    change.PartyIds = kwargs.get("PartyIds", [])
    change.Condition = kwargs.get("Condition", "")
    change.Consequence = kwargs.get("Consequence", "")
    change.KeyEvent = kwargs.get("KeyEvent", "")
    change.Importance = kwargs.get("Importance", "")
    return change


# =====================================================================
# get_pledges（查询承诺/快照）
# =====================================================================

def test_extract_snapshot_returns_active_pledges(service):
    svc, _, store = service
    pid = svc.update_pledge("vol1_ch1", make_change(Action="create"))
    snap = svc.extract_snapshot()
    assert len(snap) == 1
    assert snap[0]["Id"] == pid
    assert snap[0]["Status"] == "active"


def test_extract_snapshot_excludes_non_active(service):
    svc, _, store = service
    svc.update_pledge("vol1_ch1", make_change(PledgeId="P000000000001", Action="create"))
    svc.update_pledge("vol1_ch2", make_change(PledgeId="P000000000001", Action="fulfill"))
    assert svc.extract_snapshot() == []


def test_extract_snapshot_empty(service):
    svc, _, store = service
    assert svc.extract_snapshot() == []


# =====================================================================
# add_pledge（创建/更新承诺）
# =====================================================================

def test_update_pledge_create_registers_entry(service):
    svc, _, store = service
    pid = svc.update_pledge("vol1_ch1", make_change(PledgeId="P000000000001", Action="create",
                                                    PledgeName="誓言", Type="oath", PartyIds=["C1"]))
    assert pid == "P000000000001"
    entry = store.data()[pid]
    assert entry["CurrentStatus"] == "active"
    assert entry["PartyIds"] == ["C1"]
    assert len(entry["History"]) == 1


def test_update_pledge_fulfill_sets_status(service):
    svc, _, store = service
    svc.update_pledge("vol1_ch1", make_change(PledgeId="P000000000001", Action="create"))
    svc.update_pledge("vol1_ch2", make_change(PledgeId="P000000000001", Action="fulfill"))
    assert store.data()["P000000000001"]["CurrentStatus"] == "fulfilled"


def test_update_pledge_update_appends_parties_dedup(service):
    svc, _, store = service
    svc.update_pledge("vol1_ch1", make_change(Action="create", PartyIds=["C1"]))
    svc.update_pledge("vol1_ch2", make_change(Action="update", PartyIds=["C1", "C2"]))
    assert store.data()["P000000000001"]["PartyIds"] == ["C1", "C2"]


def test_update_pledge_guard_empty(service):
    svc, _, store = service
    assert svc.update_pledge("vol1_ch1", make_change(PledgeId="", PledgeName="", Action="create")) is None
    assert svc.update_pledge("vol1_ch1", make_change(PledgeName="x", Action="")) is None


def test_update_pledge_merges_by_name(service):
    svc, _, store = service
    svc.update_pledge("vol1_ch1", make_change(PledgeId="P000000000001", PledgeName="誓言", Action="create"))
    sid = svc.update_pledge("vol1_ch2", make_change(PledgeId="ZZZ", PledgeName="誓言", Action="update"))
    assert sid == "P000000000001"


# =====================================================================
# resolve_pledge（动作 → 状态机：fulfill/break）
# =====================================================================

def test_resolve_pledge_action_mapping():
    assert _ACTION_STATUS["fulfill"] == "fulfilled"
    assert _ACTION_STATUS["break"] == "broken"


def test_update_pledge_break_sets_broken(service):
    svc, _, store = service
    svc.update_pledge("vol1_ch1", make_change(Action="create"))
    svc.update_pledge("vol1_ch2", make_change(Action="break"))
    assert store.data()["P000000000001"]["CurrentStatus"] == "broken"


def test_update_pledge_fulfill_sets_status(service):
    svc, _, store = service
    svc.update_pledge("vol1_ch1", make_change(PledgeId="P000000000001", Action="create"))
    svc.update_pledge("vol1_ch2", make_change(PledgeId="P000000000001", Action="fulfill"))
    assert store.data()["P000000000001"]["CurrentStatus"] == "fulfilled"


# =====================================================================
# refresh_overdue_status（按章距判定逾期）
# =====================================================================

def test_refresh_overdue_marks_overdue(service):
    svc, _, store = service
    svc.update_pledge("vol1_ch1", make_change(Action="create"))
    svc.refresh_overdue_status("vol1_ch11", max_dangling_chapters=10)
    assert store.data()["P000000000001"]["IsOverdue"] is True


def test_refresh_overdue_not_when_short(service):
    svc, _, store = service
    svc.update_pledge("vol1_ch1", make_change(Action="create"))
    svc.refresh_overdue_status("vol1_ch3", max_dangling_chapters=10)
    assert store.data()["P000000000001"]["IsOverdue"] is False


def test_refresh_overdue_invalid_max_disabled(service):
    svc, _, store = service
    svc.update_pledge("vol1_ch1", make_change(Action="create"))
    svc.refresh_overdue_status("vol9_ch9", max_dangling_chapters=0)
    assert store.data()["P000000000001"]["IsOverdue"] is False


# =====================================================================
# remove_chapter_data（删除历史 + 回填状态 + 清理空条目）
# =====================================================================

def test_remove_chapter_data_cleans_empty_entries(service):
    svc, _, store = service
    svc.update_pledge("vol1_ch1", make_change(Action="create"))
    svc.remove_chapter_data("vol1_ch1")
    assert "P000000000001" not in store.data()


def test_remove_chapter_data_backfills_status(service):
    svc, _, store = service
    svc.update_pledge("vol1_ch1", make_change(Action="create"))
    svc.update_pledge("vol1_ch2", make_change(Action="fulfill"))
    svc.update_pledge("vol1_ch3", make_change(Action="update"))
    svc.remove_chapter_data("vol1_ch3")
    assert store.data()["P000000000001"]["CurrentStatus"] == "fulfilled"


def test_remove_chapter_data_no_match_returns_zero(service):
    svc, _, store = service
    svc.update_pledge("vol1_ch1", make_change(Action="create"))
    assert svc.remove_chapter_data("vol9_ch9") == 0