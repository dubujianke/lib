# -*- coding: utf-8 -*-
"""tests for guide_serializer_context.py"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock, patch
from novel_writer.implementations.guides.guide_serializer_context import (
    GuideSerializerContext, GUIDE_SERIALIZABLE_TYPES
)


# --- options ---

def test_options_returns_dict():
    opts = GuideSerializerContext.options()
    assert isinstance(opts, dict)
    assert opts["PropertyNameCaseInsensitive"] is True
    assert opts["WriteIndented"] is True
    assert opts["indent"] == 2
    assert opts["ensure_ascii"] is False


def test_options_after_modifying_class():
    original = GuideSerializerContext.PROPERTY_NAME_CASE_INSENSITIVE
    GuideSerializerContext.PROPERTY_NAME_CASE_INSENSITIVE = False
    opts = GuideSerializerContext.options()
    assert opts["PropertyNameCaseInsensitive"] is False
    GuideSerializerContext.PROPERTY_NAME_CASE_INSENSITIVE = original


# --- dumps ---

def test_dumps_dict():
    data = {"name": "小明", "age": 25}
    result = GuideSerializerContext.dumps(data)
    assert '"name"' in result
    assert '"小明"' in result
    assert result.startswith("{")


def test_dumps_list():
    data = [1, 2, 3]
    result = GuideSerializerContext.dumps(data)
    assert "1" in result
    assert "2" in result
    assert "3" in result


def test_dumps_ensure_ascii_false():
    data = {"text": "中文"}
    result = GuideSerializerContext.dumps(data)
    assert "中文" in result


def test_dumps_indent():
    data = {"a": 1}
    result = GuideSerializerContext.dumps(data)
    assert "  " in result


# --- loads ---

def test_loads_normal():
    text = '{"name": "小明", "age": 25}'
    result = GuideSerializerContext.loads(text)
    assert result["name"] == "小明"
    assert result["age"] == 25


def test_loads_list():
    text = '[1, 2, 3]'
    result = GuideSerializerContext.loads(text)
    assert result == [1, 2, 3]


def test_loads_empty():
    result = GuideSerializerContext.loads("{}")
    assert result == {}


# --- GUIDE_SERIALIZABLE_TYPES ---

def test_guide_serializable_types_contains_expected():
    assert "CharacterStateGuide" in GUIDE_SERIALIZABLE_TYPES
    assert "ContentGuide" in GUIDE_SERIALIZABLE_TYPES
    assert "PlotPointsIndex" in GUIDE_SERIALIZABLE_TYPES


def test_guide_serializable_types_is_list():
    assert isinstance(GUIDE_SERIALIZABLE_TYPES, list)
    assert len(GUIDE_SERIALIZABLE_TYPES) == 12