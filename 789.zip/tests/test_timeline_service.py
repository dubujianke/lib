# -*- coding: utf-8 -*-
"""TimelineService 单元测试 — 对标 4.1.1 TimelineService.cs"""
import sys
import os
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock

from novel_writer.implementations.tracking.timeline_service import TimelineService


class FakeStore:
    def __init__(self):
        self._data = {}

    def data(self):
        return self._data

    def set_all(self, data):
        self._data = data


class FakeProject:
    def __init__(self, **stores):
        self.dir = tempfile.mkdtemp(prefix="test_timeline_")
        self._stores = dict(stores)

    def tracking(self, name):
        return self._stores.setdefault(name, FakeStore())


@pytest.fixture
def service():
    tl = FakeStore()
    loc = FakeStore()
    project = FakeProject(timeline=tl, character_location=loc)
    return TimelineService(project), project, tl, loc


def make_time_change(**kwargs):
    change = MagicMock()
    change.TimePeriod = kwargs.get("TimePeriod", "清晨")
    change.ElapsedTime = kwargs.get("ElapsedTime", "1天")
    change.KeyTimeEvent = kwargs.get("KeyTimeEvent", "")
    change.Importance = kwargs.get("Importance", "")
    return change


def make_move(**kwargs):
    move = MagicMock()
    move.CharacterId = kwargs.get("CharacterId", "C1")
    move.FromLocation = kwargs.get("FromLocation", "A")
    move.ToLocation = kwargs.get("ToLocation", "B")
    move.Importance = kwargs.get("Importance", "")
    return move


# =====================================================================
# get_recent_timeline（最近事件）
# =====================================================================

def test_get_recent_timeline_returns_sorted_latest(service):
    svc, _, tl, _ = service
    svc.update_time_progression("vol1_ch1", make_time_change())
    svc.update_time_progression("vol1_ch3", make_time_change())
    svc.update_time_progression("vol2_ch1", make_time_change())
    recent = svc.get_recent_timeline(count=2)
    assert [e["ChapterId"] for e in recent] == ["vol1_ch3", "vol2_ch1"]


def test_get_recent_timeline_caps_count(service):
    svc, _, tl, _ = service
    for i in range(1, 6):
        svc.update_time_progression(f"vol1_ch{i}", make_time_change())
    assert len(svc.get_recent_timeline(count=2)) == 2


def test_get_recent_timeline_empty(service):
    svc, _, tl, _ = service
    assert svc.get_recent_timeline() == []


# =====================================================================
# add_event（时间推进，按章去重）
# =====================================================================

def test_update_time_progression_adds_event(service):
    svc, _, tl, _ = service
    svc.update_time_progression("vol1_ch1", make_time_change(TimePeriod="清晨", ElapsedTime="1天"))
    assert len(tl.data()["ChapterTimeline"]) == 1


def test_update_time_progression_dedups_same_chapter(service):
    svc, _, tl, _ = service
    svc.update_time_progression("vol1_ch1", make_time_change(TimePeriod="清晨", ElapsedTime="1天"))
    svc.update_time_progression("vol1_ch1", make_time_change(TimePeriod="正午", ElapsedTime="半天"))
    assert len(tl.data()["ChapterTimeline"]) == 1
    assert tl.data()["ChapterTimeline"][0]["TimePeriod"] == "正午"


def test_update_time_progression_returns_none_on_empty(service):
    svc, _, tl, _ = service
    assert svc.update_time_progression("vol1_ch1", make_time_change(TimePeriod="", ElapsedTime="")) is None
    assert svc.update_time_progression("vol1_ch1", None) is None


# =====================================================================
# remove_events（删除章节时间线）
# =====================================================================

def test_remove_chapter_data_removes_timeline(service):
    svc, _, tl, loc = service
    svc.update_time_progression("vol1_ch1", make_time_change())
    removed = svc.remove_chapter_data("vol1_ch1")
    assert removed == 1
    assert tl.data().get("ChapterTimeline") == []


def test_remove_chapter_data_no_match_returns_zero(service):
    svc, _, tl, loc = service
    svc.update_time_progression("vol1_ch1", make_time_change())
    assert svc.remove_chapter_data("vol9_ch9") == 0


def test_remove_chapter_data_backfills_character_location(service):
    svc, _, tl, loc = service
    svc.update_character_movements("vol1_ch1", [make_move(ToLocation="B")])
    svc.update_character_movements("vol1_ch2", [make_move(ToLocation="C")])
    svc.remove_chapter_data("vol1_ch2")
    assert loc.data()["C1"]["CurrentLocation"] == "B"


# =====================================================================
# get_latest_event（最近一条事件）
# =====================================================================

def test_get_latest_event_returns_most_recent(service):
    svc, _, tl, _ = service
    svc.update_time_progression("vol1_ch1", make_time_change(ElapsedTime="1天"))
    svc.update_time_progression("vol2_ch1", make_time_change(ElapsedTime="7天"))
    timeline = svc.get_recent_timeline(count=1)
    assert timeline[0]["ElapsedTime"] == "7天"


def test_get_latest_event_empty(service):
    svc, _, tl, _ = service
    assert svc.get_recent_timeline(count=1) == []


# =====================================================================
# get_all_character_locations
# =====================================================================

def test_get_all_character_locations(service):
    svc, _, tl, loc = service
    svc.update_character_movements("vol1_ch1", [make_move(CharacterId="C1", ToLocation="B")])
    result = svc.get_all_character_locations()
    assert result["C1"]["CurrentLocation"] == "B"
    assert len(loc.data()["C1"]["MovementHistory"]) == 1


def test_get_all_character_locations_skips_non_dict(service):
    svc, _, tl, loc = service
    loc.data()["C1"] = "bad"
    assert svc.get_all_character_locations() == {}


# =====================================================================
# update_character_movements（角色移动）
# =====================================================================

def test_update_character_movements_registers_and_counts(service):
    svc, _, tl, loc = service
    moves = [make_move(), make_move(CharacterId="C2", ToLocation="D")]
    count = svc.update_character_movements("vol1_ch1", moves)
    assert count == 2
    assert set(loc.data().keys()) == {"C1", "C2"}


def test_update_character_movements_empty_list_returns_zero(service):
    svc, _, tl, loc = service
    assert svc.update_character_movements("vol1_ch1", []) == 0


def test_update_character_movements_skips_missing_to_location(service):
    svc, _, tl, loc = service
    moves = [make_move(ToLocation=""), make_move(ToLocation="B")]
    assert svc.update_character_movements("vol1_ch1", moves) == 1