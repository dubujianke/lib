# -*- coding: utf-8 -*-
"""tests for importance_corrector.py"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from novel_writer.implementations.generation.importance_corrector import (
    ImportanceCorrector,
)
from novel_writer.models import (
    ChapterChanges, CharacterStateChange, ConflictProgressChange,
    ForeshadowingAction, LocationStateChange, FactionStateChange,
    CharacterMovementChange, ItemTransferChange,
    SecretRevealChange, PledgeConstraintChange, DeadlineConstraintChange,
    Importance,
)


def test_corrector_init():
    c = ImportanceCorrector()
    assert c is not None


def test_correct_empty_changes():
    c = ImportanceCorrector()
    changes = ChapterChanges()
    c.correct(changes)
    # should not raise


def test_correct_character_importance():
    c = ImportanceCorrector()
    changes = ChapterChanges()
    changes.CharacterStateChanges = [CharacterStateChange(
        CharacterId="C001", Importance="normal",
    )]
    c.correct(changes)
    # should not raise


def test_correct_conflict_importance():
    c = ImportanceCorrector()
    changes = ChapterChanges()
    changes.ConflictProgress = [ConflictProgressChange(
        ConflictId="CF001", Importance="normal",
    )]
    c.correct(changes)
    # should not raise


def test_correct_foreshadowing_importance():
    c = ImportanceCorrector()
    changes = ChapterChanges()
    changes.ForeshadowingActions = [ForeshadowingAction(
        ForeshadowId="FS001",
    )]
    c.correct(changes)
    # should not raise


def test_correct_location_importance():
    c = ImportanceCorrector()
    changes = ChapterChanges()
    changes.LocationStateChanges = [LocationStateChange(
        LocationId="L001", Importance="normal",
    )]
    c.correct(changes)
    # should not raise


def test_correct_faction_importance():
    c = ImportanceCorrector()
    changes = ChapterChanges()
    changes.FactionStateChanges = [FactionStateChange(
        FactionId="F001", Importance="normal",
    )]
    c.correct(changes)
    # should not raise


def test_correct_movement_importance():
    c = ImportanceCorrector()
    changes = ChapterChanges()
    changes.CharacterMovements = [CharacterMovementChange(
        CharacterId="C001", Importance="normal",
    )]
    c.correct(changes)
    # should not raise


def test_correct_item_importance():
    c = ImportanceCorrector()
    changes = ChapterChanges()
    changes.ItemTransfers = [ItemTransferChange(
        ItemId="I001", Importance="normal",
    )]
    c.correct(changes)
    # should not raise


def test_correct_secret_importance():
    c = ImportanceCorrector()
    changes = ChapterChanges()
    changes.SecretRevealChanges = [SecretRevealChange(
        SecretId="S001", Importance="normal",
    )]
    c.correct(changes)
    # should not raise


def test_correct_pledge_importance():
    c = ImportanceCorrector()
    changes = ChapterChanges()
    changes.PledgeConstraintChanges = [PledgeConstraintChange(
        PledgeId="PL001", Importance="normal",
    )]
    c.correct(changes)
    # should not raise


def test_correct_deadline_importance():
    c = ImportanceCorrector()
    changes = ChapterChanges()
    changes.DeadlineConstraintChanges = [DeadlineConstraintChange(
        DeadlineId="DL001", Importance="normal",
    )]
    c.correct(changes)
    # should not raise