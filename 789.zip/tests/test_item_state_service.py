# -*- coding: utf-8 -*-
"""ItemStateService 单元测试 — 对标 4.1.1 ItemStateService.cs"""
import sys
import os
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock

from novel_writer.implementations.tracking.item_state_service import ItemStateService


class FakeStore:
    def __init__(self):
        self._data = {}

    def data(self):
        return self._data

    def set_all(self, data):
        self._data = data


class FakeProject:
    def __init__(self, **stores):
        self.dir = tempfile.mkdtemp(prefix="test_item_")
        self._stores = dict(stores)

    def tracking(self, name):
        return self._stores.setdefault(name, FakeStore())


@pytest.fixture
def service():
    store = FakeStore()
    project = FakeProject(item_state=store)
    return ItemStateService(project), project, store


def make_change(**kwargs):
    change = MagicMock()
    change.ItemId = kwargs.get("ItemId", "I000000000001")
    change.ItemName = kwargs.get("ItemName", "")
    change.FromHolder = kwargs.get("FromHolder", "")
    change.ToHolder = kwargs.get("ToHolder", "C1")
    change.NewStatus = kwargs.get("NewStatus", "active")
    change.Event = kwargs.get("Event", "")
    change.Importance = kwargs.get("Importance", "")
    change.CausedBy = kwargs.get("CausedBy", "")
    return change


# =====================================================================
# get_item（查询物品/获取全部物品状态）
# =====================================================================

def test_get_all_item_states_returns_entries(service):
    svc, _, store = service
    store.data()["I1"] = {"Name": "神剑", "CurrentHolder": "C1"}
    store.data()["I2"] = {"Name": "药", "CurrentHolder": "C2"}
    result = svc.get_all_item_states()
    assert set(result.keys()) == {"I1", "I2"}
    assert result["I1"]["CurrentHolder"] == "C1"


def test_get_all_item_states_skips_non_dict(service):
    svc, _, store = service
    store.data()["I1"] = "bad"
    store.data()["I2"] = {"Name": "x"}
    assert set(svc.get_all_item_states().keys()) == {"I2"}


def test_get_all_item_states_empty(service):
    svc, _, _ = service
    assert svc.get_all_item_states() == {}


# =====================================================================
# set_item（更新物品状态/创建）
# =====================================================================

def test_update_item_state_creates_and_returns_id(service):
    svc, _, store = service
    sid = svc.update_item_state("vol1_ch1", make_change(ItemId="I000000000001", ItemName="神剑",
                                                        ToHolder="C1", NewStatus="active"))
    assert sid is not None
    entry = store.data()[sid]
    assert entry["CurrentHolder"] == "C1"
    assert entry["CurrentStatus"] == "active"
    assert len(entry["StateHistory"]) == 1


def test_update_item_state_guard_empty_id(service):
    svc, _, store = service
    assert svc.update_item_state("vol1_ch1", make_change(ItemId="")) is None


def test_update_item_state_updates_holder(service):
    svc, _, store = service
    svc.update_item_state("vol1_ch1", make_change(ToHolder="C1"))
    svc.update_item_state("vol1_ch2", make_change(ToHolder="C2"))
    assert store.data()["I000000000001"]["CurrentHolder"] == "C2"


def test_update_item_state_clears_holder_on_inactive(service):
    svc, _, store = service
    svc.update_item_state("vol1_ch1", make_change(ToHolder="C1"))
    svc.update_item_state("vol1_ch2", make_change(ToHolder="", NewStatus="destroyed"))
    assert store.data()["I000000000001"]["CurrentHolder"] == ""


# =====================================================================
# transfer_item（转移物品到新持有者）
# =====================================================================

def test_transfer_item_changes_holder(service):
    svc, _, store = service
    svc.update_item_state("vol1_ch1", make_change(ToHolder="C1"))
    svc.update_item_state("vol1_ch2", make_change(ToHolder="C2"))
    assert store.data()["I000000000001"]["CurrentHolder"] == "C2"


# =====================================================================
# get_current_holder（当前持有者）
# =====================================================================

def test_get_current_holder_returns_current(service):
    svc, _, store = service
    svc.update_item_state("vol1_ch1", make_change(ToHolder="C1"))
    assert store.data()["I000000000001"]["CurrentHolder"] == "C1"


# =====================================================================
# remove_chapter_data（删除历史 + 回填）
# =====================================================================

def test_remove_chapter_data_backfills_last(service):
    svc, _, store = service
    svc.update_item_state("vol1_ch1", make_change(ToHolder="C1", NewStatus="active"))
    svc.update_item_state("vol1_ch2", make_change(ToHolder="C2"))
    svc.remove_chapter_data("vol1_ch2")
    entry = store.data()["I000000000001"]
    assert entry["CurrentHolder"] == "C1"
    assert entry["CurrentStatus"] == "active"


def test_remove_chapter_data_all_removed_goes_unknown(service):
    svc, _, store = service
    svc.update_item_state("vol1_ch1", make_change(ToHolder="C1"))
    svc.remove_chapter_data("vol1_ch1")
    entry = store.data()["I000000000001"]
    assert entry["CurrentHolder"] == ""
    assert entry["CurrentStatus"] == "unknown"


def test_remove_chapter_data_no_match_returns_zero(service):
    svc, _, store = service
    svc.update_item_state("vol1_ch1", make_change())
    assert svc.remove_chapter_data("vol9_ch9") == 0