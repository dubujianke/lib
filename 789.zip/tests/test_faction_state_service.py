# -*- coding: utf-8 -*-
"""FactionStateService 单元测试 — 对标 4.1.1 FactionStateService.cs"""
import sys
import os
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock

from novel_writer.implementations.tracking.faction_state_service import FactionStateService


class FakeStore:
    def __init__(self):
        self._data = {}

    def data(self):
        return self._data

    def set_all(self, data):
        self._data = data


class FakeProject:
    def __init__(self, **stores):
        self.dir = tempfile.mkdtemp(prefix="test_faction_")
        self._stores = dict(stores)
        self.design = {}

    def tracking(self, name):
        return self._stores.setdefault(name, FakeStore())

    def load_design(self, entity):
        return self.design.get(entity, {})


@pytest.fixture
def service():
    store = FakeStore()
    project = FakeProject(faction_state=store)
    return FactionStateService(project), project, store


def make_change(**kwargs):
    change = MagicMock()
    change.FactionId = kwargs.get("FactionId", "F1")
    change.NewStatus = kwargs.get("NewStatus", "")
    change.Event = kwargs.get("Event", "")
    change.Importance = kwargs.get("Importance", "")
    change.CausedBy = kwargs.get("CausedBy", "")
    return change


# =====================================================================
# get_all_faction_states（合并全部势力）
# =====================================================================

def test_get_all_faction_states_returns_entries(service):
    svc, _, store = service
    store.data()["F1"] = {"CurrentStatus": "rising", "Name": "剑宗"}
    store.data()["F2"] = {"CurrentStatus": "declining", "Name": "魔门"}
    result = svc.get_all_faction_states()
    assert set(result.keys()) == {"F1", "F2"}


def test_get_all_faction_states_skips_non_dict(service):
    svc, _, store = service
    store.data()["F1"] = "bad"
    store.data()["F2"] = {"CurrentStatus": "rising"}
    assert set(svc.get_all_faction_states().keys()) == {"F2"}


def test_get_all_faction_states_empty(service):
    svc, _, _ = service
    assert svc.get_all_faction_states() == {}


# =====================================================================
# update_faction_state（更新/注册势力状态）
# =====================================================================

def test_update_faction_state_registers_new(service):
    svc, _, store = service
    entry = svc.update_faction_state("vol1_ch1", make_change(NewStatus="rising", Event="扩张"))
    assert entry["CurrentStatus"] == "rising"
    assert len(store.data()["F1"]["StateHistory"]) == 1


def test_update_faction_state_resolves_name(service):
    svc, project, store = service
    project.design["factions"] = {"items": [{"Id": "F1", "Name": "剑宗"}]}
    svc.update_faction_state("vol1_ch1", make_change(NewStatus="rising"))
    assert store.data()["F1"]["Name"] == "剑宗"


def test_update_faction_state_appends_history_by_chapter(service):
    svc, _, store = service
    svc.update_faction_state("vol1_ch1", make_change(NewStatus="rising"))
    svc.update_faction_state("vol1_ch2", make_change(NewStatus="dominant"))
    assert len(store.data()["F1"]["StateHistory"]) == 2
    assert store.data()["F1"]["CurrentStatus"] == "dominant"


# =====================================================================
# remove_chapter_data（删除历史 + 回填 CurrentStatus）
# =====================================================================

def test_remove_chapter_data_backfills_to_unknown(service):
    svc, _, store = service
    svc.update_faction_state("vol1_ch1", make_change(NewStatus="rising"))
    assert svc.remove_chapter_data("vol1_ch1") == 1
    assert store.data()["F1"]["CurrentStatus"] == "unknown"


def test_remove_chapter_data_backfills_last_status(service):
    svc, _, store = service
    svc.update_faction_state("vol1_ch1", make_change(NewStatus="rising"))
    svc.update_faction_state("vol1_ch2", make_change(NewStatus="dominant"))
    svc.remove_chapter_data("vol1_ch2")
    assert store.data()["F1"]["CurrentStatus"] == "rising"


def test_remove_chapter_data_no_match_returns_zero(service):
    svc, _, store = service
    svc.update_faction_state("vol1_ch1", make_change())
    assert svc.remove_chapter_data("vol9_ch9") == 0


# =====================================================================
# try_resolve_display_name（解析势力名）
# =====================================================================

def test_try_resolve_display_name_found(service):
    svc, project, _ = service
    project.design["factions"] = {"items": [{"Id": "F1", "Name": "剑宗"}, {"Id": "F2", "Name": "魔门"}]}
    assert svc.try_resolve_display_name("F2") == "魔门"


def test_try_resolve_display_name_not_found(service):
    svc, project, _ = service
    project.design["factions"] = {"items": [{"Id": "F1", "Name": "剑宗"}]}
    assert svc.try_resolve_display_name("F9") is None


def test_try_resolve_display_name_empty_name(service):
    svc, project, _ = service
    project.design["factions"] = {"items": [{"Id": "F1", "Name": ""}]}
    assert svc.try_resolve_display_name("F1") is None


def test_try_resolve_display_name_exception(service):
    svc, project, _ = service
    project.load_design = MagicMock(side_effect=Exception("boom"))
    assert svc.try_resolve_display_name("F1") is None