# -*- coding: utf-8 -*-
"""tests for generation_gate.py"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from novel_writer.implementations.generation.generation_gate import (
    GenerationGate, GateResult, GateFailure,
)
from novel_writer.models import FactSnapshot


def test_gate_initialization():
    gate = GenerationGate()
    assert gate is not None


def test_gate_result_defaults():
    r = GateResult()
    assert r.Success is True
    assert len(r.Failures) == 0


def test_gate_result_add_failure():
    r = GateResult()
    r.add_failure("GATE1", ["错误1"])
    assert r.Success is False
    assert len(r.Failures) == 1
    assert "GATE1" in str(r.Failures[0])


def test_gate_failure_to_dict():
    f = GateFailure("GATE1", ["错误1", "错误2"])
    d = f.to_dict()
    assert d["Type"] == "GATE1"
    assert len(d["Errors"]) == 2


def test_gate_validate_empty_content():
    gate = GenerationGate()
    snapshot = FactSnapshot()
    # validate requires a LedgerRuleSet, which might not be importable
    # just test that it doesn't crash
    result = gate.validate("", snapshot)
    assert isinstance(result, GateResult)


def test_gate_validate_no_changes():
    gate = GenerationGate()
    snapshot = FactSnapshot()
    result = gate.validate("纯文本内容，没有CHANGES段", snapshot)
    assert isinstance(result, GateResult)


# ---- 追加测试 ----

def test_validate_required_fields():
    """测试 _validate_required_fields 间接通过 validate 触发"""
    from novel_writer.models import ChapterChanges
    gate = GenerationGate()
    snapshot = FactSnapshot()
    # 空内容应有 CHANGES 缺失
    result = gate.validate("", snapshot)
    assert isinstance(result, GateResult)


def test_has_property_ignore_case():
    """测试 _has_property_ignore_case 静态方法（间接通过 gate 内逻辑）"""
    from novel_writer.implementations.generation.generation_gate import _is_ally, _is_enemy
    assert _is_ally("盟友") is True
    assert _is_ally("敌人") is False
    assert _is_enemy("宿敌") is True
    assert _is_enemy("朋友") is False


def test_validate_short_id_fields():
    """测试 _validate_short_id_fields 间接通过 json_repair.validate_shortid_fields"""
    from novel_writer.json_repair import validate_shortid_fields
    errors = validate_shortid_fields('{"CharacterStateChanges": [{"CharacterId": "valid_id"}]}')
    assert isinstance(errors, list)


def test_validate_short_id_references():
    """测试 _validate_shortid_refs 方法"""
    from novel_writer.models import ChapterChanges
    gate = GenerationGate()
    snapshot = FactSnapshot()
    changes = ChapterChanges()
    errors = gate._validate_shortid_refs(changes, snapshot, [])
    assert isinstance(errors, list)


def test_count_forged_ids():
    """测试 is_forged 方法（通过 Canonicalizer）"""
    gate = GenerationGate()
    snapshot = FactSnapshot()
    from novel_writer.changes_parser import ChapterChangesCanonicalizer
    canon = ChapterChangesCanonicalizer(snapshot)
    # 无 changes 时不应伪造
    assert canon.is_forged() is False
    assert canon.forged_count == 0
    assert canon.total_attempted == 0


def test_count_changes_items():
    """测试 _is_entity_in_changes 间接通过 changes 内容"""
    from novel_writer.implementations.generation.generation_gate import _is_entity_in_changes, _contains_name
    assert _contains_name("你好世界", "你好") is True
    assert _contains_name("你好世界", "不") is False
    assert _contains_name("", "a") is False
    assert _contains_name(None, "a") is False
    assert _contains_name("text", "") is False


def test_count_name_in_content():
    """测试 _count_name in _design_presence_check 内部逻辑"""
    gate = GenerationGate()
    # 通过 _design_presence_check 间接测试
    errors = gate._design_presence_check("小明去上学", {"角色": ["小明", "小红"]})
    # 小红缺席，但只有2个元素，阈值=3，所以不会报错
    assert len(errors) == 0
    # 大量缺席
    errors2 = gate._design_presence_check("", {"角色": ["A", "B", "C", "D", "E"]})
    # 阈值 = max(3, 5//3=1) = 3, 缺席5个，超过3
    assert len(errors2) > 0


def test_contains_entity_name():
    """测试 _contains_name 函数"""
    from novel_writer.implementations.generation.generation_gate import _contains_name
    assert _contains_name("小明在森林", "小明") is True
    assert _contains_name("小红在森林", "小明") is False


def test_validate_changes_protocol():
    """测试 validate 方法中协议解析部分"""
    gate = GenerationGate()
    snapshot = FactSnapshot()
    # 带 CHANGES 段的内容
    content = """正文内容

<chapter_changes>
{"CharacterStateChanges": [{"CharacterId": "c1", "NewLevel": "筑基"}]}
</chapter_changes>"""
    result = gate.validate(content, snapshot)
    # 由于没有上下文快照，可能失败，但不会崩溃
    assert isinstance(result, GateResult)


def test_character_state_change():
    """测试 CharacterStateChange 创建和使用"""
    from novel_writer.models import CharacterStateChange
    c = CharacterStateChange(CharacterId="c1", NewLevel="金丹", KeyEvent="突破")
    assert c.CharacterId == "c1"
    assert c.NewLevel == "金丹"
    assert c.KeyEvent == "突破"


def test_try_get_string():
    """测试从 dict 中安全获取字符串"""
    d = {"name": "hello", "count": 42, "empty": ""}
    assert isinstance(d.get("name"), str)
    assert d.get("name") == "hello"


def test_try_get_int():
    """测试从 dict 中安全获取 int"""
    d = {"count": 42, "name": "hello"}
    assert isinstance(d.get("count"), int)
    assert d.get("count") == 42