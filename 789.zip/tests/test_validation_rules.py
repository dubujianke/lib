# -*- coding: utf-8 -*-
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from novel_writer.implementations.validation.validation_rules import (
    ALL_MODULE_NAMES, DISPLAY_NAMES, EXTENDED_DATA_SCHEMAS, VERIFICATION_TYPES,
    get_display_name, get_extended_data_schema, get_verification_type, total_rule_count,
)


def test_all_module_names_count():
    assert len(ALL_MODULE_NAMES) == 10


def test_display_names_cover_all():
    for m in ALL_MODULE_NAMES:
        assert m in DISPLAY_NAMES


def test_get_display_name_exists():
    assert get_display_name("StyleConsistency") == "文风模板一致性"


def test_get_display_name_fallback():
    assert get_display_name("UnknownModule") == "UnknownModule"


def test_extended_data_schemas_cover_all():
    for m in ALL_MODULE_NAMES:
        assert m in EXTENDED_DATA_SCHEMAS
        assert isinstance(EXTENDED_DATA_SCHEMAS[m], list)


def test_get_extended_data_schema():
    schema = get_extended_data_schema("CharacterConsistency")
    assert "CharacterName" in schema
    assert "CoreTraits" in schema


def test_get_extended_data_schema_fallback():
    assert get_extended_data_schema("Unknown") == []


def test_verification_types_cover_all():
    for m in ALL_MODULE_NAMES:
        assert m in VERIFICATION_TYPES


def test_get_verification_type():
    assert get_verification_type("WorldviewConsistency") == "世界观"


def test_get_verification_type_fallback():
    assert get_verification_type("Unknown") == "通用"


def test_total_rule_count():
    assert total_rule_count() == 10