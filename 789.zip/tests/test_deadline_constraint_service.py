# -*- coding: utf-8 -*-
"""DeadlineConstraintService 单元测试 — 对标 4.1.1 DeadlineConstraintService.cs"""
import sys
import os
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock

from novel_writer.implementations.tracking.deadline_constraint_service import (
    DeadlineConstraintService,
    _is_likely_id,
    _new_deadline_id,
)


class FakeStore:
    def __init__(self):
        self._data = {}

    def data(self):
        return self._data

    def set_all(self, data):
        self._data = data


class FakeProject:
    def __init__(self, **stores):
        self.dir = tempfile.mkdtemp(prefix="test_deadline_")
        self._stores = dict(stores)

    def tracking(self, name):
        return self._stores.setdefault(name, FakeStore())


@pytest.fixture
def service():
    store = FakeStore()
    project = FakeProject(deadline=store)
    return DeadlineConstraintService(project), project, store


def make_change(**kwargs):
    change = MagicMock()
    change.DeadlineId = kwargs.get("DeadlineId", "D000000000001")
    change.DeadlineName = kwargs.get("DeadlineName", "")
    change.Action = kwargs.get("Action", "create")
    change.Type = kwargs.get("Type", "")
    change.Deadline = kwargs.get("Deadline", "vol3_ch1")
    change.TriggerCondition = kwargs.get("TriggerCondition", "")
    change.Consequence = kwargs.get("Consequence", "")
    change.PartyIds = kwargs.get("PartyIds", [])
    change.KeyEvent = kwargs.get("KeyEvent", "")
    change.Importance = kwargs.get("Importance", "")
    return change


# =====================================================================
# get_deadlines（查询倒计时/快照）
# =====================================================================

def test_extract_snapshot_returns_active(service):
    svc, _, store = service
    did = svc.update_deadline("vol1_ch1", make_change(Action="create"))
    snap = svc.extract_snapshot()
    assert len(snap) == 1
    assert snap[0]["Id"] == did
    assert snap[0]["Status"] == "active"


def test_extract_snapshot_excludes_triggered(service):
    svc, _, store = service
    svc.update_deadline("vol1_ch1", make_change(Action="create"))
    svc.update_deadline("vol1_ch2", make_change(Action="trigger"))
    assert svc.extract_snapshot() == []


def test_extract_snapshot_empty(service):
    svc, _, store = service
    assert svc.extract_snapshot() == []


# =====================================================================
# add_deadline（创建/更新倒计时）
# =====================================================================

def test_update_deadline_creates_entry(service):
    svc, _, store = service
    did = svc.update_deadline("vol1_ch1", make_change(DeadlineId="D000000000001", Action="create",
                                                      DeadlineName="总攻", Deadline="vol3_ch1"))
    assert did == "D000000000001"
    entry = store.data()[did]
    assert entry["CurrentStatus"] == "active"
    assert entry["Deadline"] == "vol3_ch1"


def test_update_deadline_trigger_changes_status(service):
    svc, _, store = service
    svc.update_deadline("vol1_ch1", make_change(Action="create"))
    svc.update_deadline("vol1_ch2", make_change(Action="trigger"))
    assert store.data()["D000000000001"]["CurrentStatus"] == "triggered"


def test_update_deadline_update_appends_parties(service):
    svc, _, store = service
    svc.update_deadline("vol1_ch1", make_change(Action="create", PartyIds=["C1"]))
    svc.update_deadline("vol1_ch2", make_change(Action="update", PartyIds=["C1", "C2"]))
    assert store.data()["D000000000001"]["PartyIds"] == ["C1", "C2"]


def test_update_deadline_guard_empty(service):
    svc, _, store = service
    assert svc.update_deadline("vol1_ch1", make_change(DeadlineId="", DeadlineName="", Action="create")) is None
    assert svc.update_deadline("vol1_ch1", make_change(DeadlineName="x", Action="")) is None


def test_update_deadline_merges_by_name(service):
    svc, _, store = service
    svc.update_deadline("vol1_ch1", make_change(DeadlineId="D000000000001", DeadlineName="总攻", Action="create"))
    sid = svc.update_deadline("vol1_ch2", make_change(DeadlineId="ZZZ", DeadlineName="总攻", Action="update"))
    assert sid == "D000000000001"


# =====================================================================
# check_overdue（逾期判定）
# =====================================================================

def test_refresh_overdue_marks_overdue(service):
    svc, _, store = service
    svc.update_deadline("vol1_ch1", make_change(Action="create"))
    svc.refresh_overdue_status("vol1_ch11", max_dangling_chapters=10)
    assert store.data()["D000000000001"]["IsOverdue"] is True


def test_refresh_overdue_not_when_short(service):
    svc, _, store = service
    svc.update_deadline("vol1_ch1", make_change(Action="create"))
    svc.refresh_overdue_status("vol1_ch3", max_dangling_chapters=10)
    assert store.data()["D000000000001"]["IsOverdue"] is False


def test_refresh_overdue_clears_on_non_active(service):
    svc, _, store = service
    svc.update_deadline("vol1_ch1", make_change(Action="create"))
    svc.update_deadline("vol1_ch2", make_change(Action="trigger"))
    entry = store.data()["D000000000001"]
    entry["IsOverdue"] = True
    svc.refresh_overdue_status("vol1_ch3", max_dangling_chapters=10)
    assert entry["IsOverdue"] is False


# =====================================================================
# remove_chapter_data（删除历史 + 回填状态 + 清理空条目）
# =====================================================================

def test_remove_chapter_data_cleans_empty(service):
    svc, _, store = service
    svc.update_deadline("vol1_ch1", make_change(Action="create"))
    svc.remove_chapter_data("vol1_ch1")
    assert "D000000000001" not in store.data()


def test_remove_chapter_data_backfills_status(service):
    svc, _, store = service
    svc.update_deadline("vol1_ch1", make_change(Action="create"))
    svc.update_deadline("vol1_ch2", make_change(Action="trigger"))
    svc.remove_chapter_data("vol1_ch2")
    assert store.data()["D000000000001"]["CurrentStatus"] == "active"


def test_remove_chapter_data_no_match_returns_zero(service):
    svc, _, store = service
    svc.update_deadline("vol1_ch1", make_change(Action="create"))
    assert svc.remove_chapter_data("vol9_ch9") == 0


# =====================================================================
# 工具函数 _is_likely_id / _new_deadline_id
# =====================================================================

def test_is_likely_id():
    assert _is_likely_id("D000000000001") is True
    assert _is_likely_id("") is False
    assert _is_likely_id("short") is False
    assert _is_likely_id(123) is False


def test_new_deadline_id_format():
    did = _new_deadline_id()
    assert len(did) == 13
    assert did[0] == "D"