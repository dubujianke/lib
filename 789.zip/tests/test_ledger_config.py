# -*- coding: utf-8 -*-
"""tests for novel_writer/implementations/tracking/ledger_config.py"""
import sys, os, json, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from novel_writer.implementations.tracking.ledger_config import (
    LedgerConfig,
    DEFAULT_LEDGER_CONFIG,
)


class TestDefaults:
    def test_default_values(self):
        cfg = LedgerConfig()
        assert cfg.LedgerCharacterStateKeepRecent == 10000000
        assert cfg.LedgerConflictProgressKeepRecent == 2000000
        assert cfg.LedgerPlotPointsKeepRecent == 10000000
        assert cfg.LedgerLocationStateKeepRecent == 5000000
        assert cfg.LedgerFactionStateKeepRecent == 5000000
        assert cfg.LedgerTimelineKeepRecent == 10000000
        assert cfg.LedgerMovementKeepRecent == 5000000
        assert cfg.LedgerItemStateKeepRecent == 5000000
        assert cfg.LedgerConstraintHistoryKeepRecent == 5000000
        assert cfg.LedgerMaxCriticalPerEntity is None
        assert cfg.LedgerImportantKeepRecent == 2000000
        assert cfg.LedgerNormalSampleInterval == 50

    def test_module_default_singleton(self):
        assert isinstance(DEFAULT_LEDGER_CONFIG, LedgerConfig)
        assert DEFAULT_LEDGER_CONFIG.max_critical() is None


class TestMaxCritical:
    def test_max_critical_none_when_not_set(self):
        cfg = LedgerConfig()
        assert cfg.max_critical() is None

    def test_max_critical_returns_value(self):
        cfg = LedgerConfig(LedgerMaxCriticalPerEntity=10)
        assert cfg.max_critical() == 10
        assert cfg.LedgerMaxCriticalPerEntity == 10


class TestCustomValues:
    def test_custom_values_override_defaults(self):
        cfg = LedgerConfig(
            LedgerCharacterStateKeepRecent=5,
            LedgerNormalSampleInterval=1,
            LedgerImportantKeepRecent=7,
            LedgerMaxCriticalPerEntity=3,
        )
        assert cfg.LedgerCharacterStateKeepRecent == 5
        assert cfg.LedgerNormalSampleInterval == 1
        assert cfg.LedgerImportantKeepRecent == 7
        assert cfg.max_critical() == 3


class TestToDict:
    def test_to_dict_roundtrip(self):
        cfg = LedgerConfig(LedgerMovementKeepRecent=123, LedgerMaxCriticalPerEntity=4)
        d = cfg.to_dict()
        assert d["LedgerMovementKeepRecent"] == 123
        assert d["LedgerMaxCriticalPerEntity"] == 4
        assert d["LedgerNormalSampleInterval"] == 50
        # reconstruct from dict -> same values
        cfg2 = LedgerConfig(**d)
        assert cfg2.to_dict() == d

    def test_to_dict_contains_all_keys(self):
        d = LedgerConfig().to_dict()
        assert set(d.keys()) == {
            "LedgerCharacterStateKeepRecent",
            "LedgerConflictProgressKeepRecent",
            "LedgerPlotPointsKeepRecent",
            "LedgerLocationStateKeepRecent",
            "LedgerFactionStateKeepRecent",
            "LedgerTimelineKeepRecent",
            "LedgerMovementKeepRecent",
            "LedgerItemStateKeepRecent",
            "LedgerConstraintHistoryKeepRecent",
            "LedgerMaxCriticalPerEntity",
            "LedgerImportantKeepRecent",
            "LedgerNormalSampleInterval",
        }


class TestFromFile:
    def test_from_missing_path_uses_defaults(self):
        cfg = LedgerConfig.from_file("/nonexistent/path.json")
        assert cfg.LedgerNormalSampleInterval == 50

    def test_from_empty_path_uses_defaults(self):
        cfg = LedgerConfig.from_file("")
        assert isinstance(cfg, LedgerConfig)

    def test_from_valid_file(self):
        with tempfile.NamedTemporaryFile(
                "w", suffix=".json", delete=False, encoding="utf-8") as f:
            json.dump({"LedgerNormalSampleInterval": 7,
                       "LedgerMaxCriticalPerEntity": 9}, f)
            path = f.name
        try:
            cfg = LedgerConfig.from_file(path)
            assert cfg.LedgerNormalSampleInterval == 7
            assert cfg.max_critical() == 9
        finally:
            os.remove(path)

    def test_from_invalid_json_uses_defaults(self):
        with tempfile.NamedTemporaryFile(
                "w", suffix=".json", delete=False, encoding="utf-8") as f:
            f.write("{not valid json")
            path = f.name
        try:
            cfg = LedgerConfig.from_file(path)
            assert cfg.LedgerNormalSampleInterval == 50
        finally:
            os.remove(path)

    def test_from_file_ignores_none_values(self):
        with tempfile.NamedTemporaryFile(
                "w", suffix=".json", delete=False, encoding="utf-8") as f:
            json.dump({"LedgerNormalSampleInterval": None,  # treated as unset
                       "LedgerMovementKeepRecent": 3}, f)
            path = f.name
        try:
            cfg = LedgerConfig.from_file(path)
            # None filtered out, so default is kept
            assert cfg.LedgerNormalSampleInterval == 50
            assert cfg.LedgerMovementKeepRecent == 3
        finally:
            os.remove(path)