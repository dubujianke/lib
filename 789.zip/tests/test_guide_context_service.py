# -*- coding: utf-8 -*-
"""tests for guide_context_service.py"""
import sys, os, tempfile, shutil
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock, patch
from novel_writer.implementations.guides.guide_context_service import GuideContextService
from novel_writer.models.guides.context_id_collection import ContextIdCollection, ContextIdValidationResult


class MockProject:
    def __init__(self):
        self.dir = tempfile.mkdtemp(prefix="test_gcs_")
        self._design = {}
        self._plan = {}
    def load_design(self, entity):
        return self._design.get(entity, [])
    def load_plan(self, entity):
        return self._plan.get(entity, [])
    def set_design(self, entity, data):
        self._design[entity] = data
    def set_plan(self, entity, data):
        self._plan[entity] = data


@pytest.fixture
def project():
    p = MockProject()
    yield p
    shutil.rmtree(p.dir, ignore_errors=True)


@pytest.fixture
def service(project):
    return GuideContextService(project)


# --- initialize_cache / clear_cache ---

def test_initialize_cache(service, project):
    project.set_design("characters", [{"Id": "c1", "Name": "小明"}])
    project.set_design("locations", [{"Id": "l1", "Name": "森林"}])
    project.set_design("factions", [{"Id": "f1", "Name": "教团"}])
    service.initialize_cache()
    assert service._cache_initialized is True
    assert len(service._character_cache) == 1
    assert len(service._location_cache) == 1
    assert len(service._faction_cache) == 1


def test_initialize_cache_idempotent(service, project):
    project.set_design("characters", [{"Id": "c1", "Name": "小明"}])
    service.initialize_cache()
    service._character_cache["c2"] = {"Id": "c2", "Name": "小红"}
    service.initialize_cache()
    assert "c2" in service._character_cache


def test_clear_cache(service, project):
    project.set_design("characters", [{"Id": "c1", "Name": "小明"}])
    service.initialize_cache()
    assert service._cache_initialized is True
    service.clear_cache()
    assert service._cache_initialized is False
    assert len(service._character_cache) == 0


# --- extract_characters ---

def test_extract_characters_found(service, project):
    project.set_design("characters", [{"Id": "c1", "Name": "小明"}, {"Id": "c2", "Name": "小红"}])
    result = service.extract_characters(["c1"])
    assert len(result) == 1
    assert result[0]["Name"] == "小明"


def test_extract_characters_not_found(service):
    result = service.extract_characters(["nonexistent"])
    assert result == []


def test_extract_characters_empty_ids(service):
    result = service.extract_characters([])
    assert result == []


# --- get_all_characters ---

def test_get_all_characters(service, project):
    project.set_design("characters", [{"Id": "c1", "Name": "小明"}, {"Id": "c2", "Name": "小红"}])
    result = service.get_all_characters()
    assert len(result) == 2


def test_get_all_characters_empty(service):
    result = service.get_all_characters()
    assert result == []


# --- extract_locations ---

def test_extract_locations(service, project):
    project.set_design("locations", [{"Id": "l1", "Name": "森林"}])
    result = service.extract_locations(["l1"])
    assert len(result) == 1
    assert result[0]["Name"] == "森林"


# --- get_all_locations ---

def test_get_all_locations(service, project):
    project.set_design("locations", [{"Id": "l1", "Name": "森林"}])
    result = service.get_all_locations()
    assert len(result) == 1


# --- extract_factions ---

def test_extract_factions(service, project):
    project.set_design("factions", [{"Id": "f1", "Name": "教团"}])
    result = service.extract_factions(["f1"])
    assert len(result) == 1
    assert result[0]["Name"] == "教团"


# --- get_all_factions ---

def test_get_all_factions(service, project):
    project.set_design("factions", [{"Id": "f1", "Name": "教团"}])
    result = service.get_all_factions()
    assert len(result) == 1


# --- validate_context_ids ---

def test_validate_context_ids_valid(service, project):
    project.set_design("characters", [{"Id": "c1", "Name": "小明"}])
    project.set_plan("chapters", [{"Id": "ch1"}])
    ctx = ContextIdCollection(Characters=["c1"], ChapterPlanId="ch1")
    result = service.validate_context_ids(ctx)
    assert result.IsValid is True


def test_validate_context_ids_none(service):
    result = service.validate_context_ids(None)
    assert result.IsValid is True


def test_validate_context_ids_missing(service, project):
    ctx = ContextIdCollection(Characters=["c1", "c2"])
    result = service.validate_context_ids(ctx)
    assert result.IsValid is False
    assert "Characters" in result.MissingIds
    assert "c1" in result.MissingIds["Characters"]


# --- extract_fact_snapshot_for_chapter ---

def test_extract_fact_snapshot_for_chapter_with_extractor(service):
    mock_extractor = MagicMock()
    mock_extractor.extract.return_value = {"snapshot": "data"}
    service._fact_snapshot_extractor = mock_extractor
    result = service.extract_fact_snapshot_for_chapter("ch1", None)
    assert result == {"snapshot": "data"}


def test_extract_fact_snapshot_for_chapter_no_extractor(service):
    result = service.extract_fact_snapshot_for_chapter("ch1", None)
    assert result is None


# --- get_volume_max_chapter ---

def test_get_volume_max_chapter(service, project):
    project.set_plan("chapters", [
        {"Id": "ch1", "VolumeNumber": 1, "ChapterNumber": 3},
        {"Id": "ch2", "VolumeNumber": 1, "ChapterNumber": 5},
        {"Id": "ch3", "VolumeNumber": 2, "ChapterNumber": 1},
    ])
    assert service.get_volume_max_chapter(1) == 5
    assert service.get_volume_max_chapter(2) == 1
    assert service.get_volume_max_chapter(3) == 0