# -*- coding: utf-8 -*-
"""tests for milestone_condenser.py"""
import sys, os, tempfile, shutil
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock, patch
from novel_writer.implementations.guides.milestone_condenser import MilestoneCondenser


class MockProject:
    def __init__(self):
        self.dir = tempfile.mkdtemp(prefix="test_mc_")
    def __del__(self):
        shutil.rmtree(self.dir, ignore_errors=True)


@pytest.fixture
def project():
    p = MockProject()
    yield p
    shutil.rmtree(p.dir, ignore_errors=True)


@pytest.fixture
def condenser(project):
    return MilestoneCondenser(project, ai_call=MagicMock(return_value="浓缩后的文本"))


# --- 路径方法 ---

def test_get_milestones_dir(condenser):
    assert condenser.get_milestones_dir().endswith("guides\\milestones") or condenser.get_milestones_dir().endswith("guides/milestones")


def test_get_condensed_file_path(condenser):
    p = condenser.get_condensed_file_path(3)
    assert "vol3_condensed" in p


def test_get_original_file_path(condenser):
    p = condenser.get_original_file_path(3)
    assert "vol3.txt" in p


# --- get_effective_file_path ---

def test_get_effective_file_path_condensed_exists(condenser, project):
    condensed_dir = os.path.join(project.dir, "guides", "milestones")
    os.makedirs(condensed_dir, exist_ok=True)
    condensed_path = os.path.join(condensed_dir, "vol1_condensed.txt")
    with open(condensed_path, "w") as f:
        f.write("condensed")
    result = condenser.get_effective_file_path(1)
    assert result == condensed_path


def test_get_effective_file_path_condensed_missing(condenser):
    result = condenser.get_effective_file_path(999)
    assert result is None


# --- read_milestone ---

def test_read_milestone_condensed_exists(condenser, project):
    milestone_dir = os.path.join(project.dir, "guides", "milestones")
    os.makedirs(milestone_dir, exist_ok=True)
    with open(os.path.join(milestone_dir, "vol1_condensed.txt"), "w", encoding="utf-8") as f:
        f.write("浓缩内容")
    result = condenser.read_milestone(1)
    assert result == "浓缩内容"


def test_read_milestone_original_exists(condenser, project):
    milestone_dir = os.path.join(project.dir, "guides", "milestones")
    os.makedirs(milestone_dir, exist_ok=True)
    with open(os.path.join(milestone_dir, "vol1.txt"), "w", encoding="utf-8") as f:
        f.write("原始内容")
    result = condenser.read_milestone(1)
    assert result == "原始内容"


def test_read_milestone_condensed_fallback_to_original(condenser, project):
    milestone_dir = os.path.join(project.dir, "guides", "milestones")
    os.makedirs(milestone_dir, exist_ok=True)
    with open(os.path.join(milestone_dir, "vol1_condensed.txt"), "w", encoding="utf-8") as f:
        f.write("")
    with open(os.path.join(milestone_dir, "vol1.txt"), "w", encoding="utf-8") as f:
        f.write("原始内容")
    result = condenser.read_milestone(1)
    assert result == ""


def test_read_milestone_none_exists(condenser):
    result = condenser.read_milestone(999)
    assert result == ""


# --- try_condense_in_background ---

def test_try_condense_in_background_below_threshold(condenser, project):
    milestone_dir = os.path.join(project.dir, "guides", "milestones")
    os.makedirs(milestone_dir, exist_ok=True)
    original_path = os.path.join(milestone_dir, "vol1.txt")
    with open(original_path, "w", encoding="utf-8") as f:
        f.write("短文本")
    condenser.try_condense_in_background(1)
    condensed_path = os.path.join(milestone_dir, "vol1_condensed.txt")
    assert not os.path.exists(condensed_path)


def test_try_condense_in_background_above_threshold(condenser, project):
    milestone_dir = os.path.join(project.dir, "guides", "milestones")
    os.makedirs(milestone_dir, exist_ok=True)
    original_path = os.path.join(milestone_dir, "vol1.txt")
    long_text = "A" * (MilestoneCondenser.CONDENSE_THRESHOLD_CHARS + 1)
    with open(original_path, "w", encoding="utf-8") as f:
        f.write(long_text)
    condenser.try_condense_in_background(1)
    import time
    time.sleep(0.1)
    condensed_path = os.path.join(milestone_dir, "vol1_condensed.txt")
    assert os.path.exists(condensed_path)
    with open(condensed_path, "r", encoding="utf-8") as f:
        assert f.read() == "浓缩后的文本"


def test_try_condense_condensed_already_exists(condenser, project):
    milestone_dir = os.path.join(project.dir, "guides", "milestones")
    os.makedirs(milestone_dir, exist_ok=True)
    condensed_path = os.path.join(milestone_dir, "vol1_condensed.txt")
    with open(condensed_path, "w", encoding="utf-8") as f:
        f.write("已有浓缩")
    original_path = os.path.join(milestone_dir, "vol1.txt")
    long_text = "A" * (MilestoneCondenser.CONDENSE_THRESHOLD_CHARS + 1)
    with open(original_path, "w", encoding="utf-8") as f:
        f.write(long_text)
    condenser.try_condense_in_background(1)
    import time
    time.sleep(0.1)
    with open(condensed_path, "r", encoding="utf-8") as f:
        assert f.read() == "已有浓缩"


# --- condense ---

def test_condense_calls_ai(condenser):
    result = condenser.condense(1, "需要浓缩的里程碑文本")
    assert result == "浓缩后的文本"
    condenser.ai_call.assert_called_once()


def test_condense_ai_returns_none(condenser):
    condenser.ai_call = MagicMock(return_value=None)
    result = condenser.condense(1, "需要浓缩的文本")
    assert result == "需要浓缩的文本"


def test_condense_ai_raises_exception(condenser):
    condenser.ai_call = MagicMock(side_effect=Exception("AI故障"))
    result = condenser.condense(1, "需要浓缩的文本")
    assert result == "需要浓缩的文本"


def test_condense_no_ai_call(project):
    c = MilestoneCondenser(project, ai_call=None)
    result = c.condense(1, "原始文本")
    assert result == "原始文本"