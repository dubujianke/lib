# -*- coding: utf-8 -*-
"""FileBasedVectorIndex 单元测试 — 对标 Implementations/Indexing/FileBasedVectorIndex.cs"""
import sys
import os
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock

from novel_writer.vector_index import FileBasedVectorIndex, VectorSearchHit


@pytest.fixture
def index():
    d = tempfile.mkdtemp(prefix="test_fbvi_")
    path = os.path.join(d, "test_index.json")
    idx = FileBasedVectorIndex("Test", path)
    idx.load()
    return idx, d, path


# =====================================================================
# upsert（插入/更新向量）
# =====================================================================

def test_upsert_adds_entry(index):
    idx, _, _ = index
    assert idx.upsert("k1", [0.1, 0.2]) is True
    assert idx.count == 1


def test_upsert_empty_key_returns_false(index):
    idx, _, _ = index
    assert idx.upsert("", [0.1]) is False


def test_upsert_empty_vector_returns_false(index):
    idx, _, _ = index
    assert idx.upsert("k1", []) is False


def test_upsert_dimension_mismatch_returns_false(index):
    idx, _, _ = index
    idx.upsert("k1", [0.1, 0.2])
    assert idx.upsert("k2", [0.1]) is False


# =====================================================================
# search（向量搜索）
# =====================================================================

def test_search_returns_top_k(index):
    idx, _, _ = index
    idx.upsert("a", [1.0, 0.0])
    idx.upsert("b", [0.0, 1.0])
    results = idx.search([1.0, 0.0], top_k=1)
    assert len(results) == 1
    assert results[0].key == "a"


def test_search_empty_index_returns_empty(index):
    idx, _, _ = index
    assert idx.search([1.0], top_k=5) == []


def test_search_empty_query_returns_empty(index):
    idx, _, _ = index
    idx.upsert("a", [1.0])
    assert idx.search([], top_k=5) == []


def test_search_orders_by_score_desc(index):
    idx, _, _ = index
    idx.upsert("a", [1.0, 0.0])
    idx.upsert("b", [0.5, 0.5])
    results = idx.search([1.0, 0.0], top_k=2)
    assert results[0].score >= results[1].score


# =====================================================================
# remove（删除条目）
# =====================================================================

def test_remove_existing(index):
    idx, _, _ = index
    idx.upsert("k1", [0.1, 0.2])
    assert idx.remove("k1") is True
    assert idx.count == 0


def test_remove_nonexistent_returns_false(index):
    idx, _, _ = index
    assert idx.remove("NOPE") is False


def test_remove_empty_key_returns_false(index):
    idx, _, _ = index
    assert idx.remove("") is False


# =====================================================================
# on_project_changed / 持久化
# =====================================================================

def test_save_and_load_persists_entries(index):
    idx, d, path = index
    idx.upsert("k1", [0.1, 0.2, 0.3])
    idx.save()
    idx2 = FileBasedVectorIndex("Test2", path)
    idx2.load()
    assert idx2.count == 1
    assert idx2.exists("k1") is True


def test_load_from_nonexistent_path(index):
    idx, d, path = index
    idx.save()
    os.remove(path)
    idx.load()  # 不应报错
    assert idx.count == 0


def test_invalidate_cache_clears(index):
    idx, _, _ = index
    idx.upsert("k1", [0.1])
    idx.invalidate_cache()
    assert idx.count == 0
    assert idx._loaded is False


def test_exists_returns_correctly(index):
    idx, _, _ = index
    idx.upsert("k1", [0.1])
    assert idx.exists("k1") is True
    assert idx.exists("NOPE") is False


def test_get_all_keys(index):
    idx, _, _ = index
    idx.upsert("a", [0.1])
    idx.upsert("b", [0.2])
    assert set(idx.get_all_keys()) == {"a", "b"}


def test_try_get_vector(index):
    idx, _, _ = index
    idx.upsert("k1", [0.1, 0.2])
    vec = idx.try_get_vector("k1")
    assert vec == [0.1, 0.2]
    assert idx.try_get_vector("NOPE") is None


def test_remove_many_by_predicate(index):
    idx, _, _ = index
    idx.upsert("a1", [0.1])
    idx.upsert("a2", [0.2])
    idx.upsert("b1", [0.3])
    removed = idx.remove_many_by_predicate(lambda k: k.startswith("a"))
    assert removed == 2
    assert idx.count == 1


def test_upsert_batch(index):
    idx, _, _ = index
    items = [("k1", [0.1, 0.2]), ("k2", [0.3, 0.4])]
    assert idx.upsert_batch(items) is True
    assert idx.count == 2