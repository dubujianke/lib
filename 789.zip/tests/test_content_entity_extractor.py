# -*- coding: utf-8 -*-
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from unittest.mock import MagicMock
from novel_writer.implementations.validation.content_entity_extractor import (
    ContentEntityExtractor, _is_likely_name, _COMMON_WORDS,
)


class TestIsLikelyName:
    def test_valid_name(self):
        assert _is_likely_name("张三") is True
        assert _is_likely_name("林黛玉") is True
        assert _is_likely_name("哈利波特") is True

    def test_too_short(self):
        assert _is_likely_name("") is False
        assert _is_likely_name("张") is False

    def test_too_long(self):
        assert _is_likely_name("一二三四五六七") is False

    def test_has_punctuation(self):
        assert _is_likely_name("张三。") is False
        assert _is_likely_name("李四？") is False

    def test_has_digit(self):
        assert _is_likely_name("张3") is False

    def test_common_word(self):
        for w in ["什么", "我们", "好的", "真的"]:
            assert _is_likely_name(w) is False, f"'{w}' should be rejected"


class FakeFactSnapshot:
    def __init__(self, character_states=None, location_descriptions=None, character_descriptions=None):
        self.CharacterStates = character_states or []
        self.LocationDescriptions = location_descriptions or []
        self.CharacterDescriptions = character_descriptions or []


class FakeState:
    def __init__(self, name=""):
        self.Name = name


class FakeDesc:
    def __init__(self, name=""):
        self.Name = name


class TestContentEntityExtractor:
    def test_init_no_args(self):
        e = ContentEntityExtractor()
        assert list(e._known_entity_names) == []

    def test_init_with_known_names(self):
        e = ContentEntityExtractor(known_names=["张三", "李四"])
        assert "张三" in e._known_entity_names
        assert "李四" in e._known_entity_names

    def test_init_with_fact_snapshot(self):
        snap = FakeFactSnapshot(
            character_states=[FakeState("张三"), FakeState("李四")],
            location_descriptions=[FakeDesc("城堡")],
            character_descriptions=[FakeDesc("王五")],
        )
        e = ContentEntityExtractor(fact_snapshot=snap)
        assert "张三" in e._known_entity_names
        assert "城堡" in e._known_entity_names
        assert "王五" in e._known_entity_names

    def test_extract_mentioned_entities_empty(self):
        e = ContentEntityExtractor()
        assert e.extract_mentioned_entities("") == []
        assert e.extract_mentioned_entities(None) == []

    def test_extract_mentioned_entities_known(self):
        e = ContentEntityExtractor(known_names=["张三", "李四"])
        result = e.extract_mentioned_entities("张三和李四在说话")
        assert "张三" in result
        assert "李四" in result

    def test_extract_mentioned_entities_dialogue(self):
        e = ContentEntityExtractor()
        content = '“林黛玉”说道'
        result = e.extract_mentioned_entities(content)
        assert "[未知]林黛玉" in result

    def test_extract_mentioned_entities_common_word_not_extracted(self):
        e = ContentEntityExtractor()
        content = '“我们”说道'
        result = e.extract_mentioned_entities(content)
        # "我们" is in COMMON_WORDS, so not extracted
        unknown_entries = [r for r in result if r.startswith("[未知]")]
        assert len(unknown_entries) == 0

    def test_unknown_entities(self):
        e = ContentEntityExtractor(known_names=["张三"])
        content = '“李四”说道。张三也在。'
        result = e.get_unknown_entities(content)
        assert "李四" in result
        assert "张三" not in result

    def test_unknown_entities_empty(self):
        e = ContentEntityExtractor()
        assert e.get_unknown_entities("") == []