# -*- coding: utf-8 -*-
"""ConflictProgressService 单元测试 — 对标 4.1.1 ConflictProgressService.cs"""
import sys
import os
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock

from novel_writer.implementations.tracking.conflict_progress_service import ConflictProgressService


class FakeStore:
    def __init__(self):
        self._data = {}

    def data(self):
        return self._data

    def set_all(self, data):
        self._data = data


class FakeProject:
    def __init__(self, **stores):
        self.dir = tempfile.mkdtemp(prefix="test_conflict_")
        self._stores = dict(stores)
        self.design = {}

    def tracking(self, name):
        return self._stores.setdefault(name, FakeStore())

    def load_design(self, entity):
        return self.design.get(entity, {})


@pytest.fixture
def service():
    store = FakeStore()
    project = FakeProject(conflict_progress=store)
    return ConflictProgressService(project), project, store


def make_change(**kwargs):
    change = MagicMock()
    change.ConflictId = kwargs.get("ConflictId", "X1")
    change.NewStatus = kwargs.get("NewStatus", "")
    change.Event = kwargs.get("Event", "")
    change.Importance = kwargs.get("Importance", "")
    change.CausedBy = kwargs.get("CausedBy", "")
    return change


# =====================================================================
# get_conflict_progress（查询冲突）
# =====================================================================

def test_get_conflict_progress_returns_entry(service):
    svc, _, store = service
    store.data()["X1"] = {"Name": "宗门大战", "Status": "active"}
    entry = svc.get_conflict_progress("X1")
    assert entry["Status"] == "active"


def test_get_conflict_progress_missing_returns_none(service):
    svc, _, _ = service
    assert svc.get_conflict_progress("NOPE") is None


def test_get_conflict_progress_non_dict_returns_none(service):
    svc, _, store = service
    store.data()["X1"] = "not-a-dict"
    assert svc.get_conflict_progress("X1") is None


# =====================================================================
# update_conflict_progress（更新/注册冲突）
# =====================================================================

def test_update_conflict_progress_registers_new(service):
    svc, _, store = service
    entry = svc.update_conflict_progress("vol1_ch1", make_change(NewStatus="active", Event="开战"))
    assert entry["Status"] == "active"
    assert store.data()["X1"]["Name"] == "X1"
    assert len(store.data()["X1"]["ProgressPoints"]) == 1
    assert store.data()["X1"]["InvolvedChapters"] == ["vol1_ch1"]


def test_update_conflict_progress_appends_points_and_dedups_chapters(service):
    svc, _, store = service
    svc.update_conflict_progress("vol1_ch1", make_change(NewStatus="active"))
    svc.update_conflict_progress("vol1_ch1", make_change(NewStatus="climax"))
    entry = store.data()["X1"]
    assert len(entry["ProgressPoints"]) == 2
    assert entry["InvolvedChapters"] == ["vol1_ch1"]  # 去重


def test_update_conflict_progress_new_status_reflected(service):
    svc, _, store = service
    svc.update_conflict_progress("vol1_ch1", make_change(NewStatus="pending"))
    svc.update_conflict_progress("vol1_ch2", make_change(NewStatus="active"))
    assert store.data()["X1"]["Status"] == "active"


# =====================================================================
# get_active_conflicts（返回 active/climax 冲突）
# =====================================================================

def test_get_active_conflicts_filters(service):
    svc, _, store = service
    store.data()["A"] = {"Status": "active", "Name": "a"}
    store.data()["B"] = {"Status": "climax", "Name": "b"}
    store.data()["C"] = {"Status": "resolved", "Name": "c"}
    result = svc.get_active_conflicts()
    assert {e["Name"] for e in result} == {"a", "b"}


# =====================================================================
# remove_chapter_data（删除章节进度 + 回填 Status）
# =====================================================================

def test_remove_chapter_data_removes_and_backfills(service):
    svc, _, store = service
    svc.update_conflict_progress("vol1_ch1", make_change(NewStatus="active"))
    svc.update_conflict_progress("vol1_ch2", make_change(NewStatus="climax"))
    removed = svc.remove_chapter_data("vol1_ch2")
    assert removed == 1
    entry = store.data()["X1"]
    assert entry["Status"].lower() == "active"  # 回填最后有 Status 的点
    assert entry["InvolvedChapters"] == ["vol1_ch1"]


def test_remove_chapter_data_all_removed_returns_pending(service):
    svc, _, store = service
    svc.update_conflict_progress("vol1_ch1", make_change(NewStatus="active"))
    svc.remove_chapter_data("vol1_ch1")
    assert store.data()["X1"]["Status"] == "pending"


def test_remove_chapter_data_no_match_returns_zero(service):
    svc, _, store = service
    svc.update_conflict_progress("vol1_ch1", make_change())
    assert svc.remove_chapter_data("vol9_ch9") == 0


# =====================================================================
# try_resolve_display_name（解析冲突名）
# =====================================================================

def test_try_resolve_display_name_found(service):
    svc, project, _ = service
    project.design["plot"] = {"items": [{"Id": "X1", "Name": "宗门大战"}]}
    assert svc.try_resolve_display_name("X1") == "宗门大战"


def test_try_resolve_display_name_not_found(service):
    svc, project, _ = service
    project.design["plot"] = {"items": [{"Id": "X1", "Name": "宗门大战"}]}
    assert svc.try_resolve_display_name("X9") is None


def test_try_resolve_display_name_exception(service):
    svc, project, _ = service
    project.load_design = MagicMock(side_effect=Exception("boom"))
    assert svc.try_resolve_display_name("X1") is None