# -*- coding: utf-8 -*-
"""RelationStrengthService 单元测试 — 对标 4.1.1 RelationStrengthService.cs"""
import sys
import os
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock

from novel_writer.implementations.tracking.relation_strength_service import (
    RelationStrengthService,
    RelationStrengthIndex,
    determine_strength_by_relation_type,
    apply_strength_hint,
    get_pair_key,
    WEAK,
    MEDIUM,
    STRONG,
)


# =====================================================================
# RelationStrengthIndex
# =====================================================================

def test_relation_strength_index_add_and_get():
    idx = RelationStrengthIndex()
    idx.add_pair("C1", "C2", STRONG)
    assert idx.get_strength("C2", "C1") == STRONG


def test_relation_strength_index_ensure_min_strength():
    idx = RelationStrengthIndex()
    idx.ensure_min_strength("C3", "C4", MEDIUM)
    assert idx.get_strength("C3", "C4") == MEDIUM
    idx.ensure_min_strength("C3", "C4", STRONG)  # 已存在，不应覆盖
    assert idx.get_strength("C3", "C4") == MEDIUM


def test_relation_strength_index_upgrade_strength():
    idx = RelationStrengthIndex()
    idx.add_pair("C1", "C2", WEAK)
    idx.upgrade_strength("C1", "C2", STRONG)
    assert idx.get_strength("C1", "C2") == STRONG


def test_relation_strength_index_serialization():
    idx = RelationStrengthIndex()
    idx.add_pair("C1", "C2", STRONG)
    d = idx.to_dict()
    restored = RelationStrengthIndex.from_dict(d)
    assert restored.get_strength("C1", "C2") == STRONG


def test_relation_strength_index_unknown_pair_returns_weak():
    idx = RelationStrengthIndex()
    assert idx.get_strength("X", "Y") == WEAK


# =====================================================================
# get_relation（查询关系强度）
# =====================================================================

def test_get_strength_via_index():
    project = MagicMock()
    project.dir = tempfile.mkdtemp(prefix="test_rs_")
    svc = RelationStrengthService(project, use_cache=False)
    index = svc.build_strength_index()
    index.add_pair("C1", "C2", STRONG)
    svc._cached_index = index
    svc._index_loaded = True
    assert svc.get_strength("C1", "C2") == STRONG


def test_get_strength_realtime_when_no_index():
    project = MagicMock()
    project.dir = tempfile.mkdtemp(prefix="test_rs_")
    project.load_design.return_value = {}
    project.load_plan.return_value = {}
    svc = RelationStrengthService(project, use_cache=False)
    svc.invalidate_cache()
    assert svc.get_strength("C1", "C2") == WEAK


# =====================================================================
# set_relation（更新关系强度）
# =====================================================================

def test_build_strength_index_from_plot_rules():
    project = MagicMock()
    project.dir = tempfile.mkdtemp(prefix="test_rs_")
    project.load_design.return_value = {"items": [
        {"Id": "R1", "MainCharacters": ["C1", "C2"]},
    ]}
    project.load_plan.return_value = {}
    svc = RelationStrengthService(project, use_cache=False)
    index = svc.build_strength_index()
    assert index.get_strength("C1", "C2") == STRONG


def test_build_strength_index_from_blueprints():
    project = MagicMock()
    project.dir = tempfile.mkdtemp(prefix="test_rs_")
    project.load_design.return_value = {}
    project.load_plan.side_effect = lambda e: {"chapters": [{"Id": "C1"}]} if e == "chapters" else [{"Cast": ["C1", "C2"]}]
    svc = RelationStrengthService(project, use_cache=False)
    index = svc.build_strength_index()
    # blueprints 是 ensure_min_strength → MEDIUM
    assert index.get_strength("C1", "C2") == MEDIUM


# =====================================================================
# try_load_index（从文件加载索引）
# =====================================================================

def test_try_load_index_no_file():
    project = MagicMock()
    project.dir = tempfile.mkdtemp(prefix="test_rs_")
    svc = RelationStrengthService(project, use_cache=False)
    assert svc._try_load_index() is False


def test_try_load_index_from_file():
    import json
    project = MagicMock()
    project.dir = tempfile.mkdtemp(prefix="test_rs_")
    index_path = os.path.join(project.dir, "guides", "relation_strength_index.json")
    os.makedirs(os.path.join(project.dir, "guides"), exist_ok=True)
    with open(index_path, "w", encoding="utf-8") as f:
        json.dump({"Pairs": {"C1_C2": 2}}, f)
    svc = RelationStrengthService(project, use_cache=False)
    assert svc._try_load_index() is True
    assert svc._cached_index.get_strength("C1", "C2") == STRONG


# =====================================================================
# ensure_cache_loaded
# =====================================================================

def test_ensure_cache_loaded_loads_data():
    project = MagicMock()
    project.dir = tempfile.mkdtemp(prefix="test_rs_")
    project.load_design.return_value = {"items": []}
    project.load_plan.return_value = {}
    svc = RelationStrengthService(project, use_cache=True)
    svc._ensure_cache_loaded()
    assert svc._relationships_cache is not None


def test_ensure_cache_loaded_uses_cache():
    project = MagicMock()
    project.dir = tempfile.mkdtemp(prefix="test_rs_")
    svc = RelationStrengthService(project, use_cache=True)
    svc._cache_expiry = 9999999999.0  # 未过期
    svc._relationships_cache = []
    svc._ensure_cache_loaded()
    project.load_design.assert_not_called()


# =====================================================================
# extract_ids_from_text（从蓝图 Cast 提取 ID 列表）
# =====================================================================

def test_extract_ids_from_text_list():
    result = RelationStrengthService._extract_ids_from_text(["C1", "C2"])
    assert result == ["C1", "C2"]


def test_extract_ids_from_text_string():
    result = RelationStrengthService._extract_ids_from_text("C1, C2")
    assert "C1" in result
    assert "C2" in result


def test_extract_ids_from_text_empty():
    assert RelationStrengthService._extract_ids_from_text([]) == []


def test_extract_ids_from_text_none():
    assert RelationStrengthService._extract_ids_from_text(None) == []


# =====================================================================
# 辅助函数
# =====================================================================

def test_determine_strength_by_relation_type():
    assert determine_strength_by_relation_type("仇敌") == STRONG
    assert determine_strength_by_relation_type("同门") == MEDIUM
    assert determine_strength_by_relation_type("陌生人") == WEAK
    assert determine_strength_by_relation_type("") == WEAK


def test_apply_strength_hint():
    assert apply_strength_hint(WEAK, "Strong") == STRONG
    assert apply_strength_hint(WEAK, "Medium") == MEDIUM
    assert apply_strength_hint(STRONG, "Medium") == STRONG  # 不会降级


def test_get_pair_key():
    assert get_pair_key("B", "A") == "A_B"
    assert get_pair_key("A", "B") == "A_B"


def test_invalidate_cache():
    project = MagicMock()
    project.dir = tempfile.mkdtemp(prefix="test_rs_")
    svc = RelationStrengthService(project, use_cache=True)
    svc._cached_index = RelationStrengthIndex()
    svc._index_loaded = True
    svc.invalidate_cache()
    assert svc._cached_index is None
    assert svc._index_loaded is False
    assert svc._cache_expiry == 0.0