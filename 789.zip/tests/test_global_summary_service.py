# -*- coding: utf-8 -*-
"""tests for global_summary_service.py"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock
from novel_writer.implementations.summary.global_summary_service import GlobalSummaryService
from novel_writer.models.context.global_summary import GlobalSummary, ProgressInfo, UsedElementsIndex
from novel_writer.models.index.index_item import IndexItem


class MockProject:
    def __init__(self):
        self._design = {}
        self._plan = {}

    def set_design(self, entity, data):
        self._design[entity] = data

    def set_plan(self, entity, data):
        self._plan[entity] = data

    def load_design(self, entity):
        return self._design.get(entity, [])

    def load_plan(self, entity):
        return self._plan.get(entity, [])


@pytest.fixture
def service():
    return GlobalSummaryService(MockProject())


# --- init ---

def test_init(service):
    assert service is not None
    assert service._cached_summary is None


# --- get_global_summary ---

def test_get_global_summary_returns_global_summary(service):
    summary = service.get_global_summary()
    assert isinstance(summary, GlobalSummary)


def test_get_global_summary_caching(service):
    s1 = service.get_global_summary()
    s2 = service.get_global_summary()
    assert s1 is s2  # same cached object


def test_get_global_summary_cache_expiry(service):
    s1 = service.get_global_summary()
    service.CACHE_EXPIRY_SECONDS = -1
    s2 = service.get_global_summary()
    assert s1 is not s2


# --- invalidate_cache ---

def test_invalidate_cache(service):
    service.get_global_summary()
    service.invalidate_cache()
    assert service._cached_summary is None
    assert service._cache_time == 0.0


# --- compute_realtime ---

def test_compute_realtime_returns_summary(service):
    summary = service.compute_realtime()
    assert isinstance(summary, GlobalSummary)


def test_compute_realtime_handles_errors(service):
    service.project.load_design = MagicMock(side_effect=Exception("error"))
    summary = service.compute_realtime()
    assert isinstance(summary, GlobalSummary)


# --- _extract_core_rules ---

def test_extract_core_rules(service):
    service.project.set_design("world", [
        {"Id": "r1", "Name": "魔法规则", "Category": "魔法", "OneLineSummary": "魔力守恒"},
        {"Id": "r2", "Name": "物理规则", "Category": "物理", "OneLineSummary": "重力"},
    ])
    summary = GlobalSummary()
    service._extract_core_rules(summary)
    assert len(summary.CoreRules) == 2
    assert summary.CoreRules[0].Name == "魔法规则"
    assert summary.CoreRules[0].BriefSummary == "魔法规则(魔法)"
    assert summary.CoreRules[0].DeepSummary == "魔力守恒"


def test_extract_core_rules_filters_disabled(service):
    service.project.set_design("world", [
        {"Id": "r1", "Name": "规则1", "Category": "A", "IsEnabled": False},
        {"Id": "r2", "Name": "规则2", "Category": "B", "IsEnabled": True},
    ])
    summary = GlobalSummary()
    service._extract_core_rules(summary)
    assert len(summary.CoreRules) == 1
    assert summary.CoreRules[0].Name == "规则2"


def test_extract_core_rules_skips_no_id(service):
    service.project.set_design("world", [{"Name": "规则1", "Category": "A"}])
    summary = GlobalSummary()
    service._extract_core_rules(summary)
    assert len(summary.CoreRules) == 0


# --- _extract_core_factions ---

def test_extract_core_factions(service):
    service.project.set_design("factions", [
        {"Id": "f1", "Name": "光明教团", "FactionType": "正派", "Goal": "维护和平", "Leader": "教皇"},
    ])
    summary = GlobalSummary()
    service._extract_core_factions(summary)
    assert len(summary.CoreFactions) == 1
    assert summary.CoreFactions[0].Name == "光明教团"
    assert summary.CoreFactions[0].BriefSummary == "光明教团(正派)"
    assert "维护和平" in summary.CoreFactions[0].DeepSummary


# --- _extract_story_summary ---

def test_extract_story_summary_from_outline(service):
    service.project.set_plan("outline", [{"IsEnabled": True, "OneLineOutline": "勇者打败魔王拯救世界"}])
    summary = GlobalSummary()
    service._extract_story_summary(summary)
    assert summary.StorySummary == "勇者打败魔王拯救世界"


def test_extract_story_summary_fallback_to_plot(service):
    service.project.set_design("plot", [{"IsEnabled": True, "Name": "主线", "OneLineSummary": "勇者之旅"}])
    summary = GlobalSummary()
    service._extract_story_summary(summary)
    assert "主线" in summary.StorySummary


def test_extract_story_summary_empty(service):
    summary = GlobalSummary()
    service._extract_story_summary(summary)
    assert summary.StorySummary == ""


# --- _extract_main_conflict ---

def test_extract_main_conflict(service):
    service.project.set_design("plot", [{"IsEnabled": True, "Name": "终极冲突", "Conflict": "正义vs邪恶"}])
    summary = GlobalSummary()
    service._extract_main_conflict(summary)
    assert "终极冲突：正义vs邪恶" in summary.MainConflict


def test_extract_main_conflict_no_conflict(service):
    service.project.set_design("plot", [{"IsEnabled": True, "Name": "无冲突"}])
    summary = GlobalSummary()
    service._extract_main_conflict(summary)
    assert summary.MainConflict == ""


# --- _extract_used_elements ---

def test_extract_used_elements(service):
    service.project.set_design("plot", [
        {"EventType": "战斗"}, {"EventType": "推理"}, {"EventType": "战斗"},
    ])
    service.project.set_design("characters", [
        {"SpecialAbilities": ["火球术", "治愈术"]},
    ])
    summary = GlobalSummary()
    service._extract_used_elements(summary)
    assert len(summary.UsedElements.UsedPlotPatterns) == 2
    assert "战斗" in summary.UsedElements.UsedPlotPatterns
    assert "推理" in summary.UsedElements.UsedPlotPatterns
    assert "火球术" in summary.UsedElements.UsedAbilities
    assert "治愈术" in summary.UsedElements.UsedAbilities


# --- _extract_progress_info ---

def test_extract_progress_info(service):
    service.project.set_plan("chapters", [{"Name": "Ch1"}, {"Name": "Ch2"}])
    summary = GlobalSummary()
    service._extract_progress_info(summary)
    assert summary.Progress.TotalChapters == 2
    assert summary.Progress.CurrentPhase == "Design"


def test_extract_progress_info_empty(service):
    summary = GlobalSummary()
    service._extract_progress_info(summary)
    assert summary.Progress.TotalChapters == 0


# --- _truncate ---

def test_truncate_short(service):
    assert service._truncate("hello", 10) == "hello"


def test_truncate_long(service):
    result = service._truncate("hello world this is long", 10)
    assert result == "hello worl..."
    assert len(result) == 13  # 10 + "..."
    assert result.endswith("...")


def test_truncate_empty(service):
    assert service._truncate("", 10) == ""
    assert service._truncate(None, 10) == ""


# --- _load_design / _load_plan ---

def test_load_design(service):
    service.project.set_design("world", {"items": [{"Name": "R1"}]})
    assert service._load_design("world") == [{"Name": "R1"}]


def test_load_plan_list(service):
    service.project.set_plan("chapters", [{"Name": "Ch1"}])
    assert service._load_plan("chapters") == [{"Name": "Ch1"}]


def test_load_plan_dict(service):
    service.project.set_plan("chapters", {"chapters": [{"Name": "Ch1"}]})
    assert service._load_plan("chapters") == [{"Name": "Ch1"}]


# --- full integration: compute_realtime with data ---

def test_compute_realtime_full(service):
    service.project.set_design("world", [{"Id": "r1", "Name": "魔法", "Category": "A", "OneLineSummary": "魔力"}])
    service.project.set_design("factions", [{"Id": "f1", "Name": "教团", "FactionType": "正派", "Goal": "和平"}])
    service.project.set_plan("outline", [{"IsEnabled": True, "OneLineOutline": "勇者之旅"}])
    service.project.set_design("plot", [{"IsEnabled": True, "Name": "主线", "Conflict": "正邪"}])
    service.project.set_plan("chapters", [{"Name": "Ch1"}])
    summary = service.compute_realtime()
    assert len(summary.CoreRules) == 1
    assert len(summary.CoreFactions) == 1
    assert summary.StorySummary == "勇者之旅"
    assert "正邪" in summary.MainConflict
    assert summary.Progress.TotalChapters == 1


# ---- 追加测试 ----

class TestGlobalSummaryServiceNewMethods:
    def test_get_json_string(self):
        assert GlobalSummaryService._get_json_string({"name": "hello"}, "name") == "hello"
        assert GlobalSummaryService._get_json_string({"count": 42}, "name") == ""
        assert GlobalSummaryService._get_json_string({}, "name") == ""