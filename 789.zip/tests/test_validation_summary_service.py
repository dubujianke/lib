# -*- coding: utf-8 -*-
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from unittest.mock import MagicMock, patch
from novel_writer.implementations.validation.validation_summary_service import (
    ValidationSummaryData, ValidationSummaryCategory, ValidationSummaryService,
)


class TestValidationSummaryData:
    def test_defaults(self):
        d = ValidationSummaryData()
        assert d.Id == ""
        assert d.OverallResult == "未校验"
        assert d.ModuleResults == []
        assert d.SampledChapterIds == []

    def test_to_dict(self):
        d = ValidationSummaryData(Id="D123", Name="test", OverallResult="通过")
        raw = d.to_dict()
        assert raw["Id"] == "D123"
        assert raw["Name"] == "test"
        assert raw["OverallResult"] == "通过"

    def test_from_dict(self):
        raw = {"Id": "D999", "Name": "foo", "OverallResult": "警告"}
        d = ValidationSummaryData.from_dict(raw)
        assert d.Id == "D999"
        assert d.Name == "foo"
        assert d.OverallResult == "警告"


class TestValidationSummaryCategory:
    def test_defaults(self):
        c = ValidationSummaryCategory()
        assert c.Id == ""
        assert c.IsEnabled is True
        assert c.IsBuiltIn is False

    def test_custom(self):
        c = ValidationSummaryCategory(Id="C1", Name="cat", Order=1)
        assert c.Id == "C1"
        assert c.Order == 1


class TestValidationSummaryService:
    def test_init_no_project(self):
        svc = ValidationSummaryService()
        assert svc.project is None
        assert svc.get_all_data() == []

    def test_get_data_by_id_empty(self):
        svc = ValidationSummaryService()
        assert svc.get_data_by_id("") is None
        assert svc.get_data_by_id("nonexistent") is None

    def test_get_data_by_volume_number_empty(self):
        svc = ValidationSummaryService()
        assert svc.get_data_by_volume_number(1) is None

    @patch.object(ValidationSummaryService, "_load_data")
    def test_add_data(self, mock_load):
        svc = ValidationSummaryService()
        d = ValidationSummaryData(Name="test")
        svc.add_data(d)
        assert d.Id != ""
        assert d.CreatedTime != ""
        assert d.ModifiedTime != ""
        assert len(svc.get_all_data()) == 1

    @patch.object(ValidationSummaryService, "_load_data")
    def test_add_data_none(self, mock_load):
        svc = ValidationSummaryService()
        svc.add_data(None)
        assert len(svc.get_all_data()) == 0

    @patch.object(ValidationSummaryService, "_load_data")
    def test_delete_data(self, mock_load):
        svc = ValidationSummaryService()
        d = ValidationSummaryData(Name="del")
        svc.add_data(d)
        assert len(svc.get_all_data()) == 1
        svc.delete_data(d.Id)
        assert len(svc.get_all_data()) == 0

    @patch.object(ValidationSummaryService, "_load_data")
    def test_delete_data_empty_id(self, mock_load):
        svc = ValidationSummaryService()
        svc.delete_data("")
        assert len(svc.get_all_data()) == 0

    @patch.object(ValidationSummaryService, "_load_data")
    def test_update_data(self, mock_load):
        svc = ValidationSummaryService()
        d = ValidationSummaryData(Name="old")
        svc.add_data(d)
        d.Name = "new"
        svc.update_data(d)
        assert svc.get_data_by_id(d.Id).Name == "new"

    def test_parse_volume_number_static(self):
        assert ValidationSummaryService.parse_volume_number("第1卷 测试") == 1
        assert ValidationSummaryService.parse_volume_number("第12卷") == 12
        assert ValidationSummaryService.parse_volume_number("") == -1
        assert ValidationSummaryService.parse_volume_number("普通分类") == -1

    @patch.object(ValidationSummaryService, "_load_data")
    def test_get_all_categories_no_volume_service(self, mock_load):
        svc = ValidationSummaryService()
        cats = svc.get_all_categories()
        assert cats == []

    @patch.object(ValidationSummaryService, "_load_data")
    def test_get_all_categories_with_volume_service(self, mock_load):
        vol_svc = MagicMock()
        vol_svc.get_all_volume_designs.return_value = [
            {"Id": "V1", "VolumeNumber": 1, "VolumeTitle": "序章", "IsEnabled": True},
            {"Id": "V2", "VolumeNumber": 2, "VolumeTitle": "高潮", "IsEnabled": True},
        ]
        svc = ValidationSummaryService(volume_design_service=vol_svc)
        cats = svc.get_all_categories()
        assert len(cats) == 2
        assert cats[0].Order == 1
        assert "第1卷" in cats[0].Name

    @patch.object(ValidationSummaryService, "_load_data")
    def test_save_volume_validation_new(self, mock_load):
        vol_svc = MagicMock()
        vol_svc.get_all_volume_designs.return_value = [
            {"Id": "V1", "VolumeNumber": 1, "VolumeTitle": "序章", "IsEnabled": True},
        ]
        svc = ValidationSummaryService(volume_design_service=vol_svc)
        data = ValidationSummaryData(OverallResult="通过")
        svc.save_volume_validation(1, data)
        assert data.TargetVolumeNumber == 1
        assert data.Name == "第1卷 序章校验"
        assert data.LastValidatedTime != ""

    @patch.object(ValidationSummaryService, "_load_data")
    def test_save_volume_validation_existing(self, mock_load):
        vol_svc = MagicMock()
        vol_svc.get_all_volume_designs.return_value = [
            {"Id": "V1", "VolumeNumber": 1, "VolumeTitle": "序章", "IsEnabled": True},
        ]
        svc = ValidationSummaryService(volume_design_service=vol_svc)
        data1 = ValidationSummaryData(OverallResult="警告")
        svc.save_volume_validation(1, data1)
        first_id = data1.Id

        data2 = ValidationSummaryData(OverallResult="通过")
        svc.save_volume_validation(1, data2)
        assert data2.Id == first_id
        assert data2.CreatedTime == data1.CreatedTime


# ---- 追加测试 ----

class TestValidationSummaryServiceNewMethods:
    @patch.object(ValidationSummaryService, "_load_data")
    def test_on_volume_category_deleted(self, mock_load):
        svc = ValidationSummaryService()
        d = ValidationSummaryData(Name="test", Category="第1卷", CategoryId="V1")
        svc.add_data(d)
        svc._on_volume_category_deleted("第1卷", "V1")
        assert len(svc.get_all_data()) == 0

    @patch.object(ValidationSummaryService, "_load_data")
    def test_ensure_data_category_id(self, mock_load):
        vol_svc = MagicMock()
        vol_svc.get_all_volume_designs.return_value = [
            {"Id": "V1", "VolumeNumber": 1, "VolumeTitle": "序章", "IsEnabled": True},
        ]
        svc = ValidationSummaryService(volume_design_service=vol_svc)
        d = ValidationSummaryData(Name="test", Category="第1卷 序章")
        svc._ensure_data_category_id(d)
        assert d.CategoryId == "V1"

    @patch.object(ValidationSummaryService, "_load_data")
    def test_ensure_data_category_id_no_category(self, mock_load):
        svc = ValidationSummaryService()
        d = ValidationSummaryData(Name="test")
        svc._ensure_data_category_id(d)
        assert d.CategoryId == ""

    @patch.object(ValidationSummaryService, "_load_data")
    def test_ensure_data_category_id_already_set(self, mock_load):
        svc = ValidationSummaryService()
        d = ValidationSummaryData(Name="test", Category="cat", CategoryId="C1")
        svc._ensure_data_category_id(d)
        assert d.CategoryId == "C1"

    @patch.object(ValidationSummaryService, "_load_data")
    def test_enqueue_save_data_item(self, mock_load):
        svc = ValidationSummaryService()
        d = ValidationSummaryData(Name="test")
        svc.add_data(d)
        svc._enqueue_save_data_item(d)  # should not raise

    def test_load_data(self):
        svc = ValidationSummaryService()
        svc._load_data()  # should not raise

    @patch.object(ValidationSummaryService, "_load_data")
    def test_save_data_item(self, mock_load):
        svc = ValidationSummaryService()
        d = ValidationSummaryData(Name="test")
        svc._save_data_item(d)  # should not raise