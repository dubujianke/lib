# -*- coding: utf-8 -*-
"""EntityDriftFallbackPatcher 单元测试 — 对标 4.1.1 EntityDriftFallbackPatcher.cs"""
import sys
import os
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock, patch

from novel_writer.implementations.tracking.entity_drift.entity_drift_fallback_patcher import (
    EntityDriftFallbackPatcher,
)
from novel_writer.implementations.tracking.entity_drift.entity_drift_fallback_result import (
    EntityDriftFallbackResult,
)
from novel_writer.implementations.tracking.entity_drift.entity_dimension_descriptor import (
    EntityDimensionDescriptor,
    DriftEntityRecord,
    AUTO_PATCH,
    WARN_ONLY,
)
from novel_writer.implementations.tracking.entity_drift.entity_dimension_registry import (
    EntityDimensionRegistry,
)


# =====================================================================
# detect_and_apply（检测漂移 + 补录）
# =====================================================================

def test_detect_and_apply_empty_summary_returns_empty():
    project = MagicMock()
    patcher = EntityDriftFallbackPatcher(project)
    result = patcher.detect_and_apply("vol1_ch1", "", None)
    assert result.AutoPatchedCount == 0
    assert result.WarnOnlyCount == 0


def test_detect_and_apply_no_changes_returns_empty():
    project = MagicMock()
    patcher = EntityDriftFallbackPatcher(project)
    result = patcher.detect_and_apply("vol1_ch1", "正文内容", None)
    assert result.AutoPatchedCount == 0
    assert result.WarnOnlyCount == 0


def test_detect_and_apply_returns_result_object():
    project = MagicMock()
    tracking = MagicMock()
    tracking._stores = {}
    patcher = EntityDriftFallbackPatcher(project, tracking)
    result = patcher.detect_and_apply("vol1_ch1", "正文内容", {}, recent_volumes=5)
    assert isinstance(result, EntityDriftFallbackResult)


# =====================================================================
# has_any_drift（是否有漂移）
# =====================================================================

def test_has_any_drift_true_when_auto_patched():
    result = EntityDriftFallbackResult(AutoPatchedCount=2)
    assert result.HasAnyDrift is True


def test_has_any_drift_true_when_warn_only():
    result = EntityDriftFallbackResult(WarnOnlyCount=1)
    assert result.HasAnyDrift is True


def test_has_any_drift_false_when_none():
    result = EntityDriftFallbackResult()
    assert result.HasAnyDrift is False


def test_patched_changes_true_when_auto_patched():
    result = EntityDriftFallbackResult(AutoPatchedCount=1)
    assert result.PatchedChanges is True


def test_patched_changes_false_when_no_auto_patch():
    result = EntityDriftFallbackResult(AutoPatchedCount=0, WarnOnlyCount=3)
    assert result.PatchedChanges is False


def test_detect_and_apply_with_actual_entities():
    project = MagicMock()
    tracking = MagicMock()
    tracking._stores = {}
    # 构建真实的 EntityDimensionDescriptor
    fake_descriptor = EntityDimensionDescriptor(
        DimensionName="test",
        Strategy=WARN_ONLY,
        ExtractDeclaredIds=lambda changes: set(),
        LoadRecentEntities=lambda tracking, vols: [DriftEntityRecord(Id="E1", Name="阿明", VolumeNumber=1)],
        AppendDriftWarning=lambda tracking, vol, eid, name, msg, max_warn: None,
        AutoPatchAction=None,
    )
    with patch.object(EntityDimensionRegistry, "all", return_value=[fake_descriptor]):
        patcher = EntityDriftFallbackPatcher(project, tracking)
        result = patcher.detect_and_apply("vol1_ch1", "阿明", {}, recent_volumes=5)
        assert result.WarnOnlyCount >= 0