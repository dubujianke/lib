# -*- coding: utf-8 -*-
"""KeywordChapterIndexService 单元测试 — 对标 Implementations/Indexing/KeywordChapterIndexService.cs"""
import sys
import os
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import MagicMock, patch

from novel_writer.implementations.indexing.keyword_chapter_index_service import (
    KeywordChapterIndexService,
    MAX_CHAPTERS_PER_KEYWORD,
)


class FakeProject:
    def __init__(self, project_dir):
        self.dir = project_dir


@pytest.fixture
def index():
    project_dir = tempfile.mkdtemp(prefix="test_kw_")
    project = FakeProject(project_dir)
    return KeywordChapterIndexService(project), project_dir


# =====================================================================
# index_chapter_from_keywords（索引关键词章节映射）
# =====================================================================

def test_index_chapter_adds_keywords(index):
    svc, _ = index
    svc.index_chapter_from_keywords("vol1_ch1", ["战斗", "修炼"])
    svc.index_chapter_from_keywords("vol1_ch2", ["战斗"])
    result = svc.search(["战斗"])
    assert "vol1_ch1" in result
    assert "vol1_ch2" in result


def test_index_chapter_empty_keywords_skips(index):
    svc, _ = index
    svc.index_chapter_from_keywords("vol1_ch1", [])
    # 不应创建索引文件
    assert svc.get_indexed_chapter_ids() == set()


def test_index_chapter_dedup_same_chapter(index):
    svc, _ = index
    svc.index_chapter_from_keywords("vol1_ch1", ["战斗"])
    svc.index_chapter_from_keywords("vol1_ch1", ["战斗"])
    result = svc.search(["战斗"], top_k=10)
    assert result.count("vol1_ch1") == 1


# =====================================================================
# search（搜索关键词）
# =====================================================================

def test_search_empty_keywords_returns_empty(index):
    svc, _ = index
    assert svc.search([]) == []


def test_search_returns_sorted_by_hit_count(index):
    svc, _ = index
    svc.index_chapter_from_keywords("vol1_ch1", ["战斗", "修炼"])
    svc.index_chapter_from_keywords("vol1_ch2", ["战斗"])
    result = svc.search(["战斗", "修炼"])
    assert result[0] == "vol1_ch1"  # 命中2次


def test_search_top_k_limits(index):
    svc, _ = index
    for i in range(1, 10):
        svc.index_chapter_from_keywords(f"vol1_ch{i}", ["战斗"])
    assert len(svc.search(["战斗"], top_k=3)) == 3


# =====================================================================
# remove_chapter（删除章节索引）
# =====================================================================

def test_remove_chapter_removes_entries(index):
    svc, _ = index
    svc.index_chapter_from_keywords("vol1_ch1", ["战斗", "修炼"])
    svc.remove_chapter("vol1_ch1")
    assert svc.get_indexed_chapter_ids() == set()


def test_remove_chapter_empty_does_nothing(index):
    svc, _ = index
    svc.remove_chapter("")
    # 不报错即可


def test_remove_chapter_not_exist(index):
    svc, _ = index
    svc.index_chapter_from_keywords("vol1_ch1", ["战斗"])
    svc.remove_chapter("vol9_ch9")  # 不存在的章节
    assert len(svc.get_indexed_chapter_ids()) == 1


# =====================================================================
# get_indexed_chapter_ids（获取已索引章节 ID 集合）
# =====================================================================

def test_get_indexed_chapter_ids_empty(index):
    svc, _ = index
    assert svc.get_indexed_chapter_ids() == set()


def test_get_indexed_chapter_ids_after_indexing(index):
    svc, _ = index
    svc.index_chapter_from_keywords("vol1_ch1", ["战斗"])
    svc.index_chapter_from_keywords("vol1_ch2", ["修炼"])
    assert svc.get_indexed_chapter_ids() == {"vol1_ch1", "vol1_ch2"}


# =====================================================================
# invalidate_cache（失效缓存）
# =====================================================================

def test_invalidate_cache(index):
    svc, _ = index
    svc.index_chapter_from_keywords("vol1_ch1", ["战斗"])
    svc.invalidate_cache()
    assert svc._pending_invalidation is True
    assert svc._dirty is False
    # 失效后重新加载（从文件），数据仍然存在
    ids = svc.get_indexed_chapter_ids()
    assert "vol1_ch1" in ids


# =====================================================================
# normalize_keyword（关键词规范化）
# =====================================================================

def test_normalize_keyword_strips_and_lowers(index):
    svc, _ = index
    assert svc._normalize_keyword(" 战斗 ") == "战斗"
    assert svc._normalize_keyword("AbC") == "abc"


# =====================================================================
# get_index_file_path（索引文件路径）
# =====================================================================

def test_get_index_file_path(index):
    svc, project_dir = index
    path = svc._get_index_file_path()
    assert path == os.path.join(project_dir, "guides", "keyword_index.json")