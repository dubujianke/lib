# -*- coding: utf-8 -*-
"""EntityDriftFallbackResult 单元测试 — 对标 4.1.1 EntityDriftFallbackResult.cs"""
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest

from novel_writer.implementations.tracking.entity_drift.entity_drift_fallback_result import (
    EntityDriftFallbackResult,
)


# =====================================================================
# patched_changes（是否有自动补录）
# =====================================================================

def test_patched_changes_true():
    result = EntityDriftFallbackResult(AutoPatchedCount=1)
    assert result.PatchedChanges is True


def test_patched_changes_false():
    result = EntityDriftFallbackResult()
    assert result.PatchedChanges is False


def test_patched_changes_false_when_only_warn():
    result = EntityDriftFallbackResult(AutoPatchedCount=0, WarnOnlyCount=3)
    assert result.PatchedChanges is False


# =====================================================================
# has_any_drift（是否有任何漂移）
# =====================================================================

def test_has_any_drift_true_when_auto_patched():
    result = EntityDriftFallbackResult(AutoPatchedCount=2)
    assert result.HasAnyDrift is True


def test_has_any_drift_true_when_warn_only():
    result = EntityDriftFallbackResult(WarnOnlyCount=1)
    assert result.HasAnyDrift is True


def test_has_any_drift_false():
    result = EntityDriftFallbackResult()
    assert result.HasAnyDrift is False


def test_has_any_drift_both():
    result = EntityDriftFallbackResult(AutoPatchedCount=1, WarnOnlyCount=2)
    assert result.HasAnyDrift is True


# =====================================================================
# 字段默认值
# =====================================================================

def test_default_values():
    result = EntityDriftFallbackResult()
    assert result.AutoPatchedCount == 0
    assert result.WarnOnlyCount == 0
    assert result.DirtyGuideFiles == set()
    assert result.Details == []


def test_details_accumulate():
    result = EntityDriftFallbackResult()
    result.Details.append("[x] 测试")
    assert len(result.Details) == 1