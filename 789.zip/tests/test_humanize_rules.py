# -*- coding: utf-8 -*-
"""tests for novel_writer/implementations/generation/humanize_rules/*"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest

from novel_writer.implementations.generation.humanize_rules import (
    HighRiskWords,
    NGramScorer,
    ComputePerplexity,
    CandidatePicker,
    PickBestAsync,
    PickerScorers,
    PickerOptions,
    HIGH_RISK_WORDS,
)
from novel_writer.implementations.generation.humanize_rules import high_risk_words
from novel_writer.implementations.generation.humanize_rules import candidate_picker
from novel_writer.implementations.generation.humanize_rules import ngram_scorer


class TestHighRiskWords:
    def test_known_high_risk_word(self):
        assert HighRiskWords.IsHighRisk("应用") is True
        assert HighRiskWords.IsHighRisk("系统") is True

    def test_non_high_risk_word(self):
        assert HighRiskWords.IsHighRisk("你好") is False
        assert HighRiskWords.IsHighRisk("猫") is False

    def test_empty_and_none(self):
        assert HighRiskWords.IsHighRisk("") is False
        assert HighRiskWords.IsHighRisk(None) is False

    def test_frozenset_export(self):
        assert isinstance(HIGH_RISK_WORDS, frozenset)
        assert HighRiskWords.Set is HIGH_RISK_WORDS


class TestNGramScorer:
    def test_short_text_returns_zero(self):
        assert ComputePerplexity("天地") == 0.0
        assert ComputePerplexity("") == 0.0

    def test_long_text_returns_positive(self):
        text = "这个故事发生在遥远的大陆之上，英雄们踏上旅途"
        ppl = ComputePerplexity(text)
        assert isinstance(ppl, float)
        assert ppl >= 0

    def test_static_method_delegates(self):
        text = "风吹过山谷，山林里传来一声低沉的兽吼"
        assert NGramScorer.ComputePerplexity(text) == ComputePerplexity(text)

    def test_non_chinese_text_zero(self):
        # no CJK chars -> len(chars) < 5
        assert ComputePerplexity("hello world 123") == 0.0


class TestCandidatePicker:
    def _mk_text_with_anchor(self, key, cands, head="很久", tail="之后"):
        anchor_idx = len(head)
        return head + key + tail, anchor_idx

    def test_empty_avail_returns_key(self):
        assert PickBestAsync("测试文本", 1, "应用", []) == "应用"

    def test_single_avail_returns_it(self):
        assert PickBestAsync("测试文本", 1, "应用", ["方案"]) == "方案"

    def test_non_high_risk_not_single_returns_ngram_pick(self):
        # 非高风险词直接返回 ngram 最优，不触发 mlm/guard
        text = "这位英雄的名字传遍整个大陆"
        key = "英雄"
        anchor_idx = text.index(key)
        avail = ["高手", "武者"]
        chosen = PickBestAsync(text, anchor_idx, key, avail)
        assert chosen in avail

    def test_high_risk_with_mlm_unavailable_falls_back(self):
        text = "系统正在运行处理数据信息"
        key = "系统"
        anchor_idx = text.index(key)
        avail = ["平台", "盒子"]
        scorers = PickerScorers(mlm=None, guard=None)
        chosen = PickBestAsync(text, anchor_idx, key, avail, scorers=scorers)
        assert chosen in avail

    def test_high_risk_uses_mlm_best(self):
        # MLM 可用且给分，应返回得分最高的候选
        class FakeMlm:
            available = True
            def __init__(self, scores):
                self._scores = scores
            def score_candidates(self, text, anchor_idx, key, candidates):
                return list(self._scores)

        text = "系统正在运行处理数据信息"
        key = "系统"
        anchor_idx = text.index(key)
        avail = ["平台", "盒子"]
        mlm = FakeMlm([0.1, 0.9])
        scorers = PickerScorers(mlm=mlm, guard=None)
        chosen = PickBestAsync(text, anchor_idx, key, avail, scorers=scorers)
        assert chosen == "盒子"

    def test_guard_rejects_below_threshold(self):
        # guard IsReady=True 且余弦 < 阈值 -> 返回原始 key
        class Guard:
            IsReady = True
            def ComputeLocalCosine(self, text, ai, key, chosen, window):
                return 0.1

        text = "系统正在运行处理数据信息"
        key = "系统"
        anchor_idx = text.index(key)
        avail = ["平台", "盒子"]
        scorers = PickerScorers(
            mlm=FakeMlmUnavailable(),
            guard=Guard(),
            options=PickerOptions(guard_cosine_threshold=0.85),
        )
        chosen = PickBestAsync(text, anchor_idx, key, avail, scorers=scorers)
        assert chosen == key

    def test_guard_accepts_above_threshold(self):
        class Guard:
            IsReady = True
            def ComputeLocalCosine(self, text, ai, key, chosen, window):
                return 0.99

        class Mlm:
            available = True
            def score_candidates(self, text, anchor_idx, key, candidates):
                return [0.0, 1.0]

        text = "系统正在运行处理数据信息"
        key = "系统"
        anchor_idx = text.index(key)
        avail = ["平台", "盒子"]
        scorers = PickerScorers(
            mlm=Mlm(), guard=Guard(),
            options=PickerOptions(guard_cosine_threshold=0.85),
        )
        chosen = PickBestAsync(text, anchor_idx, key, avail, scorers=scorers)
        assert chosen == "盒子"

    def test_mlm_exception_falls_back(self):
        class BoomMlm:
            available = True
            def score_candidates(self, text, anchor_idx, key, candidates):
                raise RuntimeError("boom")

        text = "系统正在运行处理数据信息"
        key = "系统"
        anchor_idx = text.index(key)
        avail = ["平台", "盒子"]
        scorers = PickerScorers(mlm=BoomMlm(), guard=None)
        chosen = PickBestAsync(text, anchor_idx, key, avail, scorers=scorers)
        assert chosen in avail

    def test_candidate_picker_static_pick_best(self):
        text = "系统正在运行处理数据信息"
        key = "系统"
        anchor_idx = text.index(key)
        chosen = CandidatePicker.PickBest(text, anchor_idx, key, ["平台", "盒子"])
        assert chosen in ["平台", "盒子"]

    def test_options_defaults(self):
        opts = PickerOptions()
        assert opts.GuardWindowChars == 50
        assert opts.GuardCosineThreshold == 0.85

    def test_picker_scorers_defaults(self):
        s = PickerScorers()
        assert s.Mlm is None
        assert s.Guard is None
        assert s.Options.GuardWindowChars == 50


class FakeMlmUnavailable:
    available = False