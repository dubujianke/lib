# -*- coding: utf-8 -*-
"""拆书 v4.1.1 — 支持命令行参数

用法:
  python chaishu.py                          # book_id=1, 全流程含素材
  python chaishu.py 2                        # book_id=2
  python chaishu.py 1 --no-materials         # 跳过AI素材生成
  python chaishu.py 1 --export-only          # 只导出 novel_config 不跑完整拆书
  python chaishu.py 1 --genre 仙侠            # 指定素材题材
  python chaishu.py --list                   # 列出可用书籍
"""
import sys
import os
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from novel_writer.book_pipeline_v4 import ChaishuPipeline4, DATA_ROOT

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="拆书流水线")
    parser.add_argument("book_id", nargs="?", default="1", help="书籍ID (xiaoshuo_data子目录)")
    parser.add_argument("--no-materials", action="store_true", help="跳过AI创意素材生成")
    parser.add_argument("--export-only", action="store_true", help="已有拆书数据时仅重新导出novel_config")
    parser.add_argument("--genre", help="素材题材（默认从书籍信息读取）")
    parser.add_argument("--list", action="store_true", help="列出可用书籍")
    args = parser.parse_args()

    if args.list:
        root = DATA_ROOT
        if os.path.isdir(root):
            dirs = [d for d in os.listdir(root) if os.path.isdir(os.path.join(root, d))]
            print(f"可用书籍 ({len(dirs)}):")
            for d in sorted(dirs):
                info_path = os.path.join(root, d, "book_info.json")
                if os.path.exists(info_path):
                    import json
                    try:
                        with open(info_path, "r", encoding="utf-8") as f:
                            info = json.load(f)
                        title = info.get("title", "?")
                        author = info.get("author", "")
                        cat = info.get("category", "")
                        print(f"  [{d}] {title}  {author}  ({cat})")
                    except Exception:
                        print(f"  [{d}]")
                else:
                    print(f"  [{d}]")
        else:
            print(f"数据目录不存在: {root}")
        sys.exit(0)

    p = ChaishuPipeline4(args.book_id)

    if args.export_only:
        print(f"=== 仅导出 novel_config_{args.book_id}.json ===")
        p.export_to_novel_config(genre=args.genre)
    else:
        p.run(with_materials=not args.no_materials, material_genre=args.genre)
