# -*- coding: utf-8 -*-
"""章节规划生成器 — 对标 ChapterViewModel.AIGenerate.cs"""
import json
import os
import re
from typing import Callable, Dict, List, Optional, Set, Tuple

from .chapter_allocation_helper import ChapterAllocationHelper, VolumeChapterRange
from .entity_reference_helper import EntityNameNormalizeHelper, EntityReferencePromptHelper
from .outline_service import OutlineService
from .volume_design_service import VolumeDesignService
from .chapter_service import ChapterService
from .context_service import ContextService
from ..models.generate.chapter_planning.chapter_data import ChapterData
from ..models.generate.volume_design.volume_design_data import VolumeDesignData
from ..models.common import short_id, now_str


# 对标 ChapterViewModel 正则
_CH_NORM_LEADING_PREFIX_RE = re.compile(r"^.{0,30}?[-_—–\s]+(?=第\s*[\d一二三四五六七八九十百千零]+\s*章)")
_CH_NORM_ARABIC_RE = re.compile(r"^\s*第\s*\d+\s*章\s*[：:、\-—–_]*\s*")
_CH_NORM_CHINESE_RE = re.compile(r"^\s*第\s*[一二三四五六七八九十百千零]+\s*章\s*[：:、\-—–_]*\s*")
_CH_PUNCTUATION_ONLY_RE = re.compile(r"[\s!\"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~\u3000-\u303f\uff00-\uffef\u2000-\u206f\u2100-\u214f]+")


class ChapterGenerator:
    """对标 ChapterViewModel AIGenerate 逻辑"""

    # 对标 EntityFieldMeta.GetFieldKeyMap("chapter")
    OUTPUT_FIELDS = {
        "章节标题": "ChapterTitle",
        "章节目标": "MainGoal",
        "章节主题": "ChapterTheme",
        "读者体验目标": "ReaderExperienceGoal",
        "阻力来源": "ResistanceSource",
        "关键转折": "KeyTurn",
        "钩子": "Hook",
        "世界信息释放": "WorldInfoDrop",
        "角色弧推进": "CharacterArcProgress",
        "主线推进": "MainPlotProgress",
        "伏笔": "Foreshadowing",
        "出场角色": "ReferencedCharacterNames",
        "涉及势力": "ReferencedFactionNames",
        "涉及地点": "ReferencedLocationNames",
        "名称": "Name",
    }

    def __init__(
        self,
        ai_chat: Callable,
        outline_service: OutlineService,
        volume_service: VolumeDesignService,
        chapter_service: ChapterService,
        context_service: ContextService,
        character_service_get_names: Callable[[], List[str]],
        faction_service_get_names: Callable[[], List[str]],
        location_service_get_names: Callable[[], List[str]],
    ):
        self._ai = ai_chat
        self._outline_service = outline_service
        self._volume_service = volume_service
        self._chapter_service = chapter_service
        self._context_service = context_service
        self._get_char_names = character_service_get_names
        self._get_fac_names = faction_service_get_names
        self._get_loc_names = location_service_get_names
        # 批量状态
        self._batch_full_chapter_range: List[int] = []
        self._batch_pre_calculated_chapter_numbers: List[int] = []
        self._batch_chapter_index = 0
        self._current_batch_chapter_numbers: List[int] = []
        self._current_batch_chapter_numbers_all: List[int] = []

    # ---- 上下文构建 ----
    async def _build_context_async(
        self, category_name: str, volume_category: Optional[str] = None
    ) -> str:
        """对标 ContextProvider"""
        sb = []

        base_ctx = await self._context_service.get_chapter_context_with_volume_locator_async(
            category_name)
        if base_ctx:
            sb.append(base_ctx)
            sb.append("")

        # 获取实体池
        char_names = self._get_entity_pool_for_volume(volume_category or category_name, "char")
        fac_names = self._get_entity_pool_for_volume(volume_category or category_name, "fac")
        loc_names = self._get_entity_pool_for_volume(volume_category or category_name, "loc")

        if not char_names:
            char_names = self._get_char_names()
        if not fac_names:
            fac_names = self._get_fac_names()
        if not loc_names:
            loc_names = self._get_loc_names()

        if char_names:
            sb.append(EntityReferencePromptHelper.build_candidate_section(
                "可选角色", char_names,
                "「出场角色」必须从以下列表中选择，不得编造"))
        if fac_names:
            sb.append(EntityReferencePromptHelper.build_candidate_section(
                "可选势力", fac_names,
                "「涉及势力」必须从以下列表中选择，不得编造"))
        if loc_names:
            sb.append(EntityReferencePromptHelper.build_candidate_section(
                "可选地点", loc_names,
                "「涉及地点」必须从以下列表中选择，不得编造"))

        sb.append('<field_constraints mandatory="true">')
        sb.append('1. 「章节编号」由系统按批次顺序分配，AI不应生成此字段。')
        sb.append('2. 「章节标题」不要带"第X章"前缀（系统会自动规范化标题）。')
        sb.append('3. 「关键转折」「伏笔」「世界信息释放」如有多条，请在字符串内用换行分条。')
        sb.append('4. 「出场角色」「涉及势力」「涉及地点」必须从上方可选列表中选择，逗号/顿号分隔。')
        sb.append('</field_constraints>')
        sb.append("")

        return "\n".join(sb)

    def _get_previous_batch_info(self, category_name: str) -> str:
        chapters = sorted([
            c for c in self._chapter_service.get_all_chapters()
            if c.IsEnabled and (c.Category == category_name or c.Volume == category_name)
            and c.ChapterTheme and self._has_real_title(c.ChapterTitle)
        ], key=lambda c: c.ChapterNumber)

        if not chapters:
            return ""

        sb = []
        last_10 = chapters[-10:]
        titles = [f"第{c.ChapterNumber}章 {self._normalize_title(c.ChapterTitle)}：{c.ChapterTheme}" for c in last_10]
        if titles:
            sb.append("【上一批次标题】")
            sb.extend(titles)

        with_goal = [c for c in last_10 if c.MainGoal]
        if with_goal:
            sb.append("【上一批次摘要】")
            for c in with_goal:
                goal = c.MainGoal[:60] + "…" if len(c.MainGoal) > 60 else c.MainGoal
                sb.append(f"第{c.ChapterNumber}章目标：{goal}")

        with_fs = [c for c in chapters if c.Foreshadowing][-10:]
        if with_fs:
            sb.append("【已埋伏笔】")
            for c in with_fs:
                sb.append(f"第{c.ChapterNumber}章伏笔：{c.Foreshadowing}")

        with_hook = [c for c in chapters if c.Hook][-5:]
        if with_hook:
            sb.append("【末尾章节钩子（供衔接参考）】")
            for c in with_hook:
                sb.append(f"第{c.ChapterNumber}章钩子：{c.Hook}")

        return "\n".join(sb)

    async def _build_batch_prompt_async(
        self, base_prompt: str, category_name: str, chapter_numbers: List[int]
    ) -> str:
        """对标 BuildBatchGenerationPromptAsync: 添加章节分配 + 连续性锚点"""
        sb = [base_prompt, ""]

        prev_info = self._get_previous_batch_info(category_name)
        if prev_info:
            sb.append(prev_info)
            sb.append("")

        sb.append(f'<chapter_assignments mandatory="true">')
        sb.append(
            f"本批生成任务（输出数组长度必须 = {len(chapter_numbers)}，第i项对应第 i 个章节号）：")
        sb.append("、".join(f"第{n}章" for n in chapter_numbers))
        sb.append('要求：本批每个对象的 Name/ChapterTitle 必须各不相同，且标题需体现本章核心事件，禁止使用"第X章"前缀。')

        # 前后章节连续性
        all_existing = [
            c for c in self._chapter_service.get_all_chapters()
            if c.IsEnabled
            and (c.Category == category_name or c.Volume == category_name)
            and c.ChapterTheme
            and self._has_real_title(c.ChapterTitle)
        ]
        if all_existing:
            min_batch = min(chapter_numbers)
            max_batch = max(chapter_numbers)
            preceding = [c for c in all_existing if c.ChapterNumber < min_batch][-3:]
            following = [c for c in all_existing if c.ChapterNumber > max_batch][:3]

            if preceding or following:
                sb.append("")
                sb.append('<continuity_anchor note="本批为补全/续接生成，必须与前后已有章节保持叙事连贯">')
                if preceding:
                    sb.append("【前接章节（本批之前）】")
                    for ch in preceding:
                        sb.append(
                            f"  第{ch.ChapterNumber}章「{self._normalize_title(ch.ChapterTitle)}」"
                            f"主题={ch.ChapterTheme}，钩子={ch.Hook or '无'}")
                if following:
                    sb.append("【后续章节（本批之后）】")
                    for ch in following:
                        sb.append(
                            f"  第{ch.ChapterNumber}章「{self._normalize_title(ch.ChapterTitle)}」"
                            f"主题={ch.ChapterTheme}")
                sb.append("要求：本批章节必须承接前接章节的钩子/伏笔，并为后续章节做好铺垫，确保叙事无断裂。")
                sb.append("</continuity_anchor>")

        sb.append("</chapter_assignments>")
        return "\n".join(sb)

    # ---- 单章生成 ----
    async def generate_chapter_async(
        self, chapter_number: int, category_name: str, volume_title: str,
        volume_number: int, system_prompt: str
    ) -> ChapterData:
        context = await self._build_context_async(category_name, category_name)
        user_prompt = json.dumps(
            {cn: f"【{cn}】的值" for cn in self.OUTPUT_FIELDS},
            ensure_ascii=False, indent=2,
        )
        if context:
            system_prompt = system_prompt + "\n\n" + context

        text = self._ai(system_prompt, user_prompt, category="章节规划")
        data = self._extract_json(text) or {}

        return self._data_from_json(
            data, chapter_number, category_name, volume_title, volume_number
        )

    def _data_from_json(
        self, data: dict, chapter_number: int, category_name: str,
        volume_title: str, volume_number: int
    ) -> ChapterData:
        title = self._normalize_title(data.get("章节标题", ""))
        name = self._normalize_title(data.get("名称", ""))
        final_title = title or name or f"第{chapter_number}章"

        # 实体引用校验
        vol = self._find_volume_by_category(category_name)
        scoped_chars = vol.ReferencedCharacterNames if vol else []
        scoped_facs = vol.ReferencedFactionNames if vol else []
        scoped_locs = vol.ReferencedLocationNames if vol else []

        ref_chars = self._normalize_refs(
            data.get("出场角色", ""), scoped_chars, self._get_char_names())
        ref_facs = self._normalize_refs(
            data.get("涉及势力", ""), scoped_facs, self._get_fac_names())
        ref_locs = self._normalize_refs(
            data.get("涉及地点", ""), scoped_locs, self._get_loc_names())

        return ChapterData(
            Id=short_id("CP"),
            Name=name or final_title,
            Category=category_name,
            Volume=category_name,
            IsEnabled=True,
            CreatedAt=now_str(),
            UpdatedAt=now_str(),
            ChapterNumber=chapter_number,
            VolumeNumber=volume_number,
            ChapterTitle=final_title,
            ChapterTheme=data.get("章节主题", ""),
            ReaderExperienceGoal=data.get("读者体验目标", ""),
            MainGoal=data.get("章节目标", ""),
            ResistanceSource=data.get("阻力来源", ""),
            KeyTurn=data.get("关键转折", ""),
            Hook=data.get("钩子", ""),
            WorldInfoDrop=data.get("世界信息释放", ""),
            CharacterArcProgress=data.get("角色弧推进", ""),
            MainPlotProgress=data.get("主线推进", ""),
            Foreshadowing=data.get("伏笔", ""),
            ReferencedCharacterNames=ref_chars,
            ReferencedFactionNames=ref_facs,
            ReferencedLocationNames=ref_locs,
        )

    # ---- 批量生成 ----
    async def prepare_batch_async(
        self, category_name: str
    ) -> Optional[List[int]]:
        """对标 ShowBatchGenerationDialogAsync: 计算待生成章节号"""
        # 找到对应分卷
        volume = self._find_volume_by_category(category_name)
        if not volume:
            return None

        # 解析章节范围
        outlines = self._outline_service.get_all_outlines()
        volume_division = ""
        for o in outlines:
            if o.IsEnabled and o.VolumeDivision:
                volume_division = o.VolumeDivision
                break

        total_volumes = self._volume_service.get_all_volume_designs()
        max_vn = max((v.VolumeNumber for v in total_volumes if v.VolumeNumber > 0), default=1)
        # 从大纲获取总章节数
        total_chapters = 0
        for o in outlines:
            if o.IsEnabled and o.TotalChapterCount > 0:
                total_chapters = o.TotalChapterCount
                break

        if total_chapters <= 0:
            return None

        all_ranges: List[VolumeChapterRange] = []
        ok, parsed = ChapterAllocationHelper.try_parse_volume_division(
            volume_division, max_vn, total_chapters)
        if ok:
            all_ranges = parsed
        else:
            all_ranges = ChapterAllocationHelper.allocate(max_vn, total_chapters)

        current_range = None
        for r in all_ranges:
            if r.VolumeNumber == volume.VolumeNumber:
                current_range = r
                break

        if not current_range:
            return None

        full_range = list(range(current_range.StartChapter, current_range.EndChapter + 1))
        self._batch_full_chapter_range = full_range

        # 检查已有内容
        all_chapters = self._chapter_service.get_all_chapters()
        existing_nums = set()
        for c in all_chapters:
            if (c.Category == category_name or c.Volume == category_name) and c.IsEnabled:
                if c.ChapterTheme and self._has_real_title(c.ChapterTitle):
                    existing_nums.add(c.ChapterNumber)

        missing = [n for n in full_range if n not in existing_nums]
        self._batch_pre_calculated_chapter_numbers = missing
        self._batch_chapter_index = 0

        if not missing:
            self._batch_full_chapter_range = []
            self._batch_pre_calculated_chapter_numbers = []
            return None

        return missing

    def get_next_batch(self, batch_size: int = 10) -> Optional[List[int]]:
        if (self._batch_pre_calculated_chapter_numbers
                and self._batch_chapter_index < len(self._batch_pre_calculated_chapter_numbers)):
            remaining = self._batch_pre_calculated_chapter_numbers[self._batch_chapter_index:]
            take = min(batch_size, len(remaining))
            self._current_batch_chapter_numbers = remaining[:take]
            self._current_batch_chapter_numbers_all = list(self._current_batch_chapter_numbers)
            self._batch_chapter_index += take
            return self._current_batch_chapter_numbers
        return None

    def rollback_batch(self):
        if self._current_batch_chapter_numbers:
            self._batch_chapter_index = max(
                0, self._batch_chapter_index - len(self._current_batch_chapter_numbers))

    async def finalize_batch_async(
        self, category_name: str, success: bool, cancelled: bool
    ):
        if not self._batch_full_chapter_range:
            self._reset_batch()
            return

        if cancelled:
            self._cleanup_empty_shells(category_name)
        elif success:
            # 补缺占位
            valid_set = set(self._batch_full_chapter_range)
            for ch_num in self._batch_full_chapter_range:
                existing = None
                for c in self._chapter_service.get_all_chapters():
                    if c.ChapterNumber == ch_num and c.Category == category_name:
                        existing = c
                        break
                if not existing:
                    data = ChapterData(
                        Id=short_id("CP"),
                        Name=f"第{ch_num}章",
                        Category=category_name,
                        Volume=category_name,
                        IsEnabled=True,
                        CreatedAt=now_str(),
                        UpdatedAt=now_str(),
                        ChapterNumber=ch_num,
                        ChapterTitle=f"第{ch_num}章",
                    )
                    self._chapter_service.add_chapter(data)

        self._reset_batch()

    def _cleanup_empty_shells(self, category_name: str):
        for c in self._chapter_service.get_all_chapters():
            if c.Category == category_name:
                if (not self._has_real_title(c.ChapterTitle)
                        and not c.ChapterTheme
                        and not c.ReaderExperienceGoal
                        and not c.MainGoal):
                    self._chapter_service.delete_chapter(c.Id)

    def _reset_batch(self):
        self._batch_full_chapter_range = []
        self._batch_pre_calculated_chapter_numbers = []
        self._batch_chapter_index = 0
        self._current_batch_chapter_numbers = []
        self._current_batch_chapter_numbers_all = []

    # ---- 辅助方法 ----
    def _find_volume_by_category(self, category_name: str) -> Optional[VolumeDesignData]:
        for v in self._volume_service.get_all_volume_designs():
            expected = f"第{v.VolumeNumber}卷 {v.VolumeTitle}".strip() if v.VolumeNumber > 0 else v.Name
            if expected == category_name or v.Name == category_name:
                return v
        return None

    def _check_previous_volumes_complete(self, category_name: str, vol_num: int) -> bool:
        if vol_num <= 1:
            return True
        all_vols = self._volume_service.get_all_volume_designs()
        outlines = self._outline_service.get_all_outlines()
        total_chapters = 0
        for o in outlines:
            if o.IsEnabled and o.TotalChapterCount > 0:
                total_chapters = o.TotalChapterCount
                break
        if total_chapters <= 0:
            return True
        volume_division = ""
        for o in outlines:
            if o.IsEnabled and o.VolumeDivision:
                volume_division = o.VolumeDivision
                break
        max_vn = max((v.VolumeNumber for v in all_vols if v.VolumeNumber > 0), default=1)
        ok, all_ranges = ChapterAllocationHelper.try_parse_volume_division(volume_division, max_vn, total_chapters)
        if not ok:
            all_ranges = ChapterAllocationHelper.allocate(max_vn, total_chapters)

        all_chapters = self._chapter_service.get_all_chapters()
        for r in all_ranges:
            if r.VolumeNumber >= vol_num:
                break
            expected = set(range(r.StartChapter, r.EndChapter + 1))
            completed = set()
            for c in all_chapters:
                if c.ChapterNumber in expected and c.IsEnabled and c.ChapterTheme and self._has_real_title(c.ChapterTitle):
                    completed.add(c.ChapterNumber)
            if len(completed) < len(expected):
                return False
        return True

    def get_current_max_sequence(self, category_name: str) -> int:
        chapters = self._chapter_service.get_all_chapters()
        nums = [c.ChapterNumber for c in chapters if c.Category == category_name or c.Volume == category_name]
        return max(nums) if nums else 0

    def _get_entity_pool_for_volume(self, category_name: str, entity_type: str) -> List[str]:
        vol = self._find_volume_by_category(category_name)
        if not vol:
            return []
        if entity_type == "char":
            return [n for n in vol.ReferencedCharacterNames if n]
        elif entity_type == "fac":
            return [n for n in vol.ReferencedFactionNames if n]
        elif entity_type == "loc":
            return [n for n in vol.ReferencedLocationNames if n]
        return []

    def _normalize_refs(self, raw: str, scoped: List[str], global_list: List[str]) -> List[str]:
        if not raw:
            return []
        raw_resolved = self._filter_to_global(raw, global_list)
        if scoped:
            raw_resolved = EntityNameNormalizeHelper.filter_to_candidates(raw_resolved, scoped)
        if not raw_resolved:
            return []
        ref_list = [n.strip() for n in re.split(r"[、，,]", raw_resolved) if n.strip()]
        seen = set()
        result = []
        for n in ref_list:
            key = n.lower()
            if key not in seen:
                seen.add(key)
                result.append(n)
        return result

    def _filter_to_global(self, raw: str, global_list: List[str]) -> str:
        if not raw:
            return ""
        global_set = {n for n in global_list if n}
        parts = re.split(r"[、，,;；\n\r]", raw)
        kept = []
        for p in parts:
            p = p.strip()
            if not p or EntityNameNormalizeHelper.is_ignored_value(p):
                continue
            if p in global_set:
                kept.append(p)
        return "、".join(kept)

    @staticmethod
    def _normalize_title(title: str) -> str:
        if not title:
            return ""
        t = title.strip()
        t = _CH_NORM_LEADING_PREFIX_RE.sub("", t)
        t = _CH_NORM_ARABIC_RE.sub("", t)
        t = _CH_NORM_CHINESE_RE.sub("", t)
        return t.strip()

    @staticmethod
    def _has_real_title(title: str) -> bool:
        if not title:
            return False
        t = title.strip()
        t = _CH_NORM_ARABIC_RE.sub("", t)
        t = _CH_NORM_CHINESE_RE.sub("", t)
        if not t:
            return False
        return bool(_CH_PUNCTUATION_ONLY_RE.sub("", t).strip())

    @staticmethod
    def _extract_json(text: str):
        if not text:
            return None
        t = text.strip()
        if t.startswith("```"):
            t = re.sub(r"^```(?:json)?\s*\n?", "", t)
            t = re.sub(r"\n?\s*```\s*$", "", t)
        # 尝试解析数组
        if t.startswith("["):
            try:
                items = json.loads(t)
                if isinstance(items, list) and items:
                    return items[0]
            except json.JSONDecodeError:
                pass
        start = t.find("{")
        if start == -1:
            return None
        depth, in_str, esc = 0, 0, 0
        for i in range(start, len(t)):
            ch = t[i]
            if in_str:
                if esc:
                    esc = 0
                elif ch == "\\":
                    esc = 1
                elif ch == '"':
                    in_str = 0
                continue
            if ch == '"':
                in_str = 1
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(t[start:i + 1])
                    except json.JSONDecodeError:
                        pass
        try:
            return json.loads(t)
        except json.JSONDecodeError:
            return None