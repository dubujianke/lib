# -*- coding: utf-8 -*-
import sys, os
sys.path.insert(0, '.')
results = []

def check(name, fn):
    try:
        fn()
        results.append(("OK", name))
    except Exception as e:
        results.append(("FAIL", f"{name}: {e}"))

from novel_writer.implementations.generation.humanize_rules import HighRiskWords, NGramScorer, CandidatePicker, PickBestAsync
check("HighRiskWords", lambda: HighRiskWords.IsHighRisk('应用') == True and HighRiskWords.IsHighRisk('苹果') == False)
check("NGramScorer", lambda: NGramScorer.ComputePerplexity('这不是一个合理的例句这里进行测试') >= 0)
check("CandidatePicker", lambda: CandidatePicker.PickBest('他的xxx很厉害', 2, 'xxx', ['两招', '攻击']) in ['两招', '攻击'])
check("PickBestAsync", lambda: PickBestAsync('他觉得xxx很重要', 3, 'xxx', ['感觉', '认为', '理解']) in ['感觉', '认为', '理解'])

from novel_writer.implementations.tracking.ledger_consistency_checker import LedgerConsistencyChecker
from novel_writer.models import ChapterChanges
check("LedgerConsistencyChecker", lambda: LedgerConsistencyChecker().ValidateStructuralOnly(ChapterChanges()).Success == True)

from novel_writer.implementations.guides.guide_serializer_context import GuideSerializerContext
check("GuideSerializerContext", lambda: len(GuideSerializerContext.dumps({'k': 1})) > 0)

import novel_writer.interfaces as I
names = ["IChangeDetectionService", "IChunkEmbeddingIndex", "IContextService",
         "IEntityFirstChapterIndex", "IFocusContextService", "IGeneratedContentService",
         "IGuideContextService", "IIndexable", "IModuleEnabledService",
         "IPackageHistoryService", "IPublishService", "IUnifiedValidationService",
         "IValidationSummaryService", "IVectorIndex",
         "ChapterValidationResult", "VolumeValidationResult", "ValidationIssue"]
check("Interfaces", lambda: all(hasattr(I, n) for n in names))

for status, name in results:
    print(f"[{status}] {name}")
print(f"通过 {sum(1 for s,_ in results if s=='OK')}/{len(results)}")
if any(s == 'FAIL' for s, _ in results):
    sys.exit(1)
print("=== 全部功能验证通过 ===")