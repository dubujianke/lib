#include <stdio.h>
#define GLFW_INCLUDE_ES3
#define GLFW_INCLUDE_GLEXT
#include <GLFW/glfw3.h>
#include "nanovg.h"
#define NANOVG_GLES3_IMPLEMENTATION
#include "nanovg_gl.h"
#include "nanovg_gl_utils.h"
#include "demo.h"
#include "perf.h"


void errorcb(int error, const char* desc)
{
	printf("GLFW error %d: %s\n", error, desc);
}

int blowup = 0;
int screenshot = 0;
int premult = 0;

static void key(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	NVG_NOTUSED(scancode);
	NVG_NOTUSED(mods);
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		glfwSetWindowShouldClose(window, GL_TRUE);
	if (key == GLFW_KEY_SPACE && action == GLFW_PRESS)
		blowup = !blowup;
	if (key == GLFW_KEY_S && action == GLFW_PRESS)
		screenshot = 1;
	if (key == GLFW_KEY_P && action == GLFW_PRESS)
		premult = !premult;
}

int main()
{
	GLFWwindow* window;
	DemoData data;
	NVGcontext* vg = NULL;
	PerfGraph fps;
	double prevt = 0;

	if (!glfwInit()) {
		printf("Failed to init GLFW.");
		return -1;
	}

	initGraph(&fps, GRAPH_RENDER_FPS, "Frame Time");

	glfwSetErrorCallback(errorcb);

	glfwWindowHint(GLFW_CLIENT_API, GLFW_OPENGL_ES_API);
	glfwWindowHint(GLFW_CONTEXT_CREATION_API, GLFW_EGL_CONTEXT_API);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);

	window = glfwCreateWindow(1000, 600, "NanoVG", NULL, NULL);
	if (!window) {
		glfwTerminate();
		return -1;
	}

	glfwSetKeyCallback(window, key);

	glfwMakeContextCurrent(window);

	vg = nvgCreateGLES3(NVG_ANTIALIAS | NVG_STENCIL_STROKES | NVG_DEBUG);
	if (vg == NULL) {
		printf("Could not init nanovg.\n");
		return -1;
	}

	if (loadDemoData(vg, &data) == -1)
		return -1;

	glfwSwapInterval(0);

	glfwSetTime(0);
	prevt = glfwGetTime();

	while (!glfwWindowShouldClose(window))
	{
		double mx, my, t, dt;
		int winWidth, winHeight;
		int fbWidth, fbHeight;
		float pxRatio;

		t = glfwGetTime();
		dt = t - prevt;
		prevt = t;
		updateGraph(&fps, dt);

		glfwGetCursorPos(window, &mx, &my);
		glfwGetWindowSize(window, &winWidth, &winHeight);
		glfwGetFramebufferSize(window, &fbWidth, &fbHeight);
		// Calculate pixel ration for hi-dpi devices.
		pxRatio = (float)fbWidth / (float)winWidth;

		// Update and render
		glViewport(0, 0, fbWidth, fbHeight);
		if (premult)
			glClearColor(0, 0, 0, 0);
		else
			glClearColor(0.3f, 0.3f, 0.32f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glEnable(GL_CULL_FACE);
		glDisable(GL_DEPTH_TEST);

		nvgBeginFrame(vg, winWidth, winHeight, pxRatio);

		renderDemo(vg, mx, my, winWidth, winHeight, t, blowup, &data);
		//renderGraph(vg, 5, 5, &fps);

		nvgEndFrame(vg);

		glEnable(GL_DEPTH_TEST);

		if (screenshot) {
			screenshot = 0;
			saveScreenShot(fbWidth, fbHeight, premult, "dump.png");
		}

		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	freeDemoData(vg, &data);

	nvgDeleteGLES3(vg);

	glfwTerminate();
	return 0;
}


//#include <GLFW/glfw3.h>
//#include <GLES3/gl3.h>
//
//#include <iostream>
//#include <vector>
//
//#include "nanovg.h"
//#define NANOVG_GLES3_IMPLEMENTATION
//#include "nanovg_gl.h"
//#include "nanovg_gl_utils.h"
//#include "demo.h"
//#include "perf.h"
//
//// ---------------- Shader ----------------
//static const char* vsSrc = R"(#version 300 es
//layout(location = 0) in vec2 aPos;
//void main() {
//    gl_Position = vec4(aPos, 0.0, 1.0);
//}
//)";
//
//static const char* fsSrc = R"(#version 300 es
//precision mediump float;
//out vec4 FragColor;
//void main() {
//    FragColor = vec4(1.0, 0.0, 0.0, 1.0);
//}
//)";
//
//GLuint compileShader(GLenum type, const char* src) {
//    GLuint s = glCreateShader(type);
//    glShaderSource(s, 1, &src, nullptr);
//    glCompileShader(s);
//
//    GLint ok = GL_FALSE;
//    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
//    if (!ok) {
//        char log[512];
//        glGetShaderInfoLog(s, sizeof(log), nullptr, log);
//        std::cerr << log << std::endl;
//    }
//    return s;
//}
//
//int main() {
//    // ---------------- GLFW ----------------
//    if (!glfwInit())
//        return -1;
//
//
//    glfwWindowHint(GLFW_CLIENT_API, GLFW_OPENGL_ES_API);
//    glfwWindowHint(GLFW_CONTEXT_CREATION_API, GLFW_EGL_CONTEXT_API);
//    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
//    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
//
//
//    GLFWwindow* window =
//        glfwCreateWindow(800, 600, "VS2019 C++17 + GLFW + GLES3 Triangle", nullptr, nullptr);
//
//    if (!window) {
//        glfwTerminate();
//        return -1;
//    }
//
//    glfwMakeContextCurrent(window);
//    printf("API: %s\n", glGetString(GL_VERSION));
//    printf("Renderer: %s\n", glGetString(GL_RENDERER));
//    // ---------------- Program ----------------
//    GLuint vs = compileShader(GL_VERTEX_SHADER, vsSrc);
//    GLuint fs = compileShader(GL_FRAGMENT_SHADER, fsSrc);
//
//
//
//
//    GLuint program = glCreateProgram();
//    glAttachShader(program, vs);
//    glAttachShader(program, fs);
//    glLinkProgram(program);
//    glUseProgram(program);
//
//    // ---------------- Geometry ----------------
//    std::vector<float> vertices = {
//         0.0f,  0.6f,
//        -0.6f, -0.6f,
//         0.6f, -0.6f
//    };
//
//    GLuint vao = 0, vbo = 0;
//    glGenVertexArrays(1, &vao);
//    glGenBuffers(1, &vbo);
//
//    glBindVertexArray(vao);
//    glBindBuffer(GL_ARRAY_BUFFER, vbo);
//    glBufferData(GL_ARRAY_BUFFER,
//        vertices.size() * sizeof(float),
//        vertices.data(),
//        GL_STATIC_DRAW);
//
//    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), nullptr);
//    glEnableVertexAttribArray(0);
//
//    // ---------------- Loop ----------------
//    while (!glfwWindowShouldClose(window)) {
//        glViewport(0, 0, 800, 600);
//        glClearColor(0.12f, 0.12f, 0.18f, 1.0f);
//        glClear(GL_COLOR_BUFFER_BIT);
//
//        glUseProgram(program);
//        glBindVertexArray(vao);
//        glDrawArrays(GL_TRIANGLES, 0, 3);
//
//        glfwSwapBuffers(window);
//        glfwPollEvents();
//    }
//
//    glfwTerminate();
//    return 0;
//}
