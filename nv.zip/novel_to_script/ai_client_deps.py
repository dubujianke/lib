# -*- coding: utf-8 -*-
"""AI 客户端封装 - 调 OpenAI 兼容接口"""

import httpx
import json
import os
from dataclasses import dataclass
from typing import Optional


@dataclass
class AIConfig:
    api_key: str = "sk-fcb31ba465af4975bd47092c03c34309"
    base_url: str = "https://api.deepseek.com/v1"
    model: str = "deepseek-chat"
    timeout: int = 300

    def __post_init__(self):
        if not self.api_key:
            self.api_key = os.environ.get("LLM_API_KEY", "")
        if not self.api_key:
            print("⚠ 未设置 API Key！请在 ai_client.py 中配置或设置环境变量 LLM_API_KEY")


class AIClient:
    """封装 LLM 调用，支持 chat + 流式"""

    def __init__(self, config: Optional[AIConfig] = None):
        self.config = config or AIConfig()
        self._client = httpx.Client(http2=True, timeout=self.config.timeout)

    def chat(self, system: str, user: str, stream: bool = False) -> str:
        """调大模型，返回文本"""
        url = f"{self.config.base_url}/chat/completions"
        payload = {
            "model": self.config.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "stream": stream,
            "max_tokens": 16384,
        }
        headers = {
            "Authorization": f"Bearer {self.config.api_key}",
            "Content-Type": "application/json",
        }
        print(payload)
        resp = self._client.post(url, json=payload, headers=headers)
        if resp.status_code != 200:
            raise RuntimeError(f"API 错误 {resp.status_code}: {resp.text}")

        data = resp.json()
        return data["choices"][0]["message"]["content"]

    def close(self):
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
