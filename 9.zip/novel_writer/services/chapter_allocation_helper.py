# -*- coding: utf-8 -*-
"""章节分配算法 — 对标 ChapterAllocationHelper.cs"""
import re
from dataclasses import dataclass
from typing import List, Optional, Tuple


@dataclass
class VolumeChapterRange:
    VolumeNumber: int = 0
    StartChapter: int = 0
    EndChapter: int = 0
    TargetChapterCount: int = 0


class ChapterAllocationHelper:
    """对标 ChapterAllocationHelper: 解析 VolumeDivision / 算法分配"""

    VOLUME_DIVISION_PATTERN = re.compile(
        r"第\s*(\d+)\s*卷[：:]\s*第\s*(\d+)\s*[-~至到—–]\s*(\d+)\s*章"
    )

    @classmethod
    def try_parse_volume_division(
        cls, volume_division: Optional[str],
        total_volumes: int, total_chapters: int
    ) -> Tuple[bool, List[VolumeChapterRange]]:
        """对标 TryParseVolumeDivision: 尝试从 VolumeDivision 字符串解析

        格式要求: "第1卷：第1-80章\n第2卷：第81-160章\n..."
        """
        if not volume_division or not volume_division.strip():
            return False, []

        ranges = []
        for line in volume_division.split("\n"):
            line = line.strip()
            if not line:
                continue
            m = cls.VOLUME_DIVISION_PATTERN.search(line)
            if not m:
                return False, []
            vn = int(m.group(1))
            start = int(m.group(2))
            end = int(m.group(3))
            ranges.append(VolumeChapterRange(
                VolumeNumber=vn,
                StartChapter=start,
                EndChapter=end,
                TargetChapterCount=end - start + 1,
            ))

        if len(ranges) != total_volumes:
            return False, []

        # 验证连续性
        ranges.sort(key=lambda r: r.VolumeNumber)
        if ranges[0].StartChapter != 1:
            return False, ranges
        expected = ranges[0].StartChapter
        for r in ranges:
            if r.StartChapter != expected:
                return False, ranges
            expected = r.EndChapter + 1
        if expected - 1 != total_chapters:
            return False, ranges

        return True, ranges

    @classmethod
    def allocate(cls, total_volumes: int, total_chapters: int) -> List[VolumeChapterRange]:
        """对标 Allocate: 五幕式算法分配章节范围"""
        if total_volumes <= 0 or total_chapters <= 0:
            raise ValueError(f"总卷数({total_volumes})和总章节数({total_chapters})必须大于0")
        if total_chapters < total_volumes:
            raise ValueError(f"总章节数({total_chapters})不能小于总卷数({total_volumes})")

        ranges = []
        base = total_chapters // total_volumes
        remainder = total_chapters % total_volumes

        start = 1
        for vn in range(1, total_volumes + 1):
            count = base + (1 if vn <= remainder else 0)
            end = start + count - 1
            ranges.append(VolumeChapterRange(
                VolumeNumber=vn,
                StartChapter=start,
                EndChapter=end,
                TargetChapterCount=count,
            ))
            start = end + 1

        return ranges