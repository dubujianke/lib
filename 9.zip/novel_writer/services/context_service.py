# -*- coding: utf-8 -*-
"""上下文服务 — 对标 ContextService.cs

构建各层 AI 生成所需的结构化上下文（XML 格式）
"""
import json
import os
import re
from typing import List, Optional

from ..models.generate.strategic_outline.outline_data import OutlineData
from ..models.generate.volume_design.volume_design_data import VolumeDesignData
from ..models.generate.chapter_planning.chapter_data import ChapterData
from ..models.generate.chapter_blueprint.blueprint_data import BlueprintData
from .outline_service import OutlineService
from .volume_design_service import VolumeDesignService
from .chapter_service import ChapterService


class ContextService:
    """对标 ContextService: 构建各层上下文"""

    def __init__(
        self,
        outline_service: OutlineService,
        volume_design_service: VolumeDesignService,
        chapter_service: ChapterService,
    ):
        self._outline_service = outline_service
        self._volume_design_service = volume_design_service
        self._chapter_service = chapter_service

    # ---- 大纲上下文 ----
    async def get_outline_structure_context_async(self) -> str:
        """对标 GetOutlineStructureContextAsync: 返回大纲结构化上下文"""
        outlines = self._outline_service.get_all_outlines()
        if not outlines:
            return ""
        sb = []
        for o in outlines:
            if not o.IsEnabled:
                continue
            sb.append("<outline_structure>")
            sb.append(f"  名称: {o.Name}")
            if o.OneLineOutline:
                sb.append(f"  一句话大纲: {o.OneLineOutline}")
            if o.CoreConflict:
                sb.append(f"  核心冲突: {o.CoreConflict}")
            if o.Theme:
                sb.append(f"  主题思想: {o.Theme}")
            if o.VolumeDivision:
                sb.append(f"  卷/幕划分: {o.VolumeDivision}")
            if o.OutlineOverview:
                sb.append(f"  大纲总览: {o.OutlineOverview}")
            sb.append("</outline_structure>")
        return "\n".join(sb)

    async def get_volume_design_list_async(self) -> str:
        """对标 GetVolumeDesignListAsync: 返回已有分卷的 XML 列表"""
        vols = self._volume_design_service.get_all_volume_designs()
        if not vols:
            return ""
        sb = []
        for v in vols:
            sb.append(f"<item id=\"{v.Id}\">")
            sb.append(f"  第{v.VolumeNumber}卷：{v.VolumeTitle}")
            if v.StartChapter > 0 and v.EndChapter > 0:
                sb.append(f"  章节范围：第{v.StartChapter}章 ~ 第{v.EndChapter}章")
            sb.append(f"  主题：{v.VolumeTheme}")
            sb.append(f"  阶段目标：{v.StageGoal}")
            sb.append("</item>")
        return "\n".join(sb)

    # ---- 分卷设计上下文 ----
    async def get_volume_design_structure_context_async(self, volume_key: Optional[str] = None) -> str:
        """对标 GetVolumeDesignStructureContextAsync: 提供大纲上下文给分卷生成"""
        outlines = self._outline_service.get_all_outlines()
        sb = []
        for o in outlines:
            if not o.IsEnabled:
                continue
            sb.append("<outline_reference>")
            sb.append(f"  大纲名称: {o.Name}")
            sb.append(f"  核心冲突: {o.CoreConflict}")
            sb.append(f"  主题思想: {o.Theme}")
            sb.append(f"  卷/幕划分: {o.VolumeDivision}")
            sb.append(f"  大纲总览: {o.OutlineOverview}")
            sb.append("</outline_reference>")
        return "\n".join(sb)

    # ---- 章节上下文 ----
    async def get_chapter_context_with_volume_locator_async(self, category_name: str) -> str:
        """对标 GetChapterContextWithVolumeLocatorAsync: 提供分卷设计上下文给章节生成"""
        vols = self._volume_design_service.get_all_volume_designs()
        sb = []
        for v in vols:
            cat_name = f"第{v.VolumeNumber}卷 {v.VolumeTitle}".strip() if v.VolumeNumber > 0 else v.Name
            if cat_name != category_name:
                continue
            sb.append("<volume_design_reference>")
            sb.append(f"  卷标题: {v.VolumeTitle}")
            sb.append(f"  卷主题: {v.VolumeTheme}")
            sb.append(f"  阶段目标: {v.StageGoal}")
            sb.append(f"  主冲突: {v.MainConflict}")
            sb.append(f"  章节范围: 第{v.StartChapter}章 ~ 第{v.EndChapter}章")
            sb.append(f"  章节生成提示: {v.ChapterGenerationHints}")
            sb.append("</volume_design_reference>")
            break
        return "\n".join(sb)

    # ---- 蓝图上下文 ----
    async def get_blueprint_context_with_chapter_locator_async(self, chapter_id: str) -> str:
        """对标 GetBlueprintContextWithChapterLocatorAsync: 提供章节设计上下文给蓝图生成"""
        if not chapter_id:
            return ""
        m = re.match(r"vol(\d+)_ch(\d+)", chapter_id, re.IGNORECASE)
        if not m:
            return ""
        ch_num = int(m.group(2))
        chapters = self._chapter_service.get_all_chapters()
        sb = []
        for ch in chapters:
            if ch.ChapterNumber != ch_num:
                continue
            sb.append("<chapter_design_reference>")
            sb.append(f"  第{ch.ChapterNumber}章: {ch.ChapterTitle}")
            sb.append(f"  章节目标: {ch.MainGoal}")
            sb.append(f"  关键转折: {ch.KeyTurn}")
            sb.append(f"  钩子: {ch.Hook}")
            sb.append(f"  角色弧推进: {ch.CharacterArcProgress}")
            sb.append(f"  主线推进: {ch.MainPlotProgress}")
            sb.append(f"  伏笔: {ch.Foreshadowing}")
            sb.append("</chapter_design_reference>")
            break
        return "\n".join(sb)