# -*- coding: utf-8 -*-
"""重要性校正器 — 对标 Implementations/Generation/ImportanceCorrector.cs"""
from typing import List

CRITICAL_CHAR_KEYWORDS = [
    "死亡", "陨落", "殒命", "身死", "牺牲", "战死", "重伤",
    "濒死", "垂死", "重创", "残废", "残疾", "断臂", "失忆",
    "失去修为", "废功", "散功", "修为尽废", "境界崩塌", "道基破碎",
    "魂飞魄散", "神魂俱灭", "魂魄消散", "肉身毁灭", "肉身崩毁",
    "入魔", "走火入魔",
]

IMPORTANT_CHAR_KEYWORDS = [
    "突破", "晋级", "觉醒", "结契", "成婚", "背叛", "叛变", "出走",
    "决裂", "认主", "拜师", "收徒", "封印解除", "境界跌落",
    "升级", "破境", "晋升", "晋阶", "顿悟", "开辟", "入门", "出师",
    "结拜", "反目", "绝交", "和解", "重逢", "认亲", "复仇",
    "解封", "归隐", "堕魔", "黑化", "心境突破", "境界回落",
]

CRITICAL_FACTION_KEYWORDS = [
    "覆灭", "灭亡", "解散", "叛离", "并入", "被灭", "宗门覆灭",
    "灭门", "灭宗", "除名", "覆没", "瓦解", "分裂", "崩溃",
    "崩塌", "破产", "倒闭", "被吞并",
]

IMPORTANT_FACTION_KEYWORDS = [
    "成立", "合并", "结盟", "交战", "宣战", "投降",
    "扩张", "收缩", "迁移", "改名", "更名", "归附", "臣服",
    "停战", "议和", "开辟", "反叛", "背叛", "夺权", "换主",
    "改组", "重组", "招安", "联盟",
]

CONFLICT_IMPORTANT_STATUS_KEYWORDS = [
    "解决", "结束", "完结", "收束", "已结", "闭环", "落幕",
    "告终", "平息", "化解", "消弭", "了结", "失败", "破裂",
    "失控", "终止", "取消",
]

MAX_CRITICAL_PER_CHAPTER = 3

IMPORTANCE_VALUE_MAP = {
    "关键": "critical", "严重": "critical", "极重要": "critical",
    "至关重要": "critical", "决定性": "critical", "核心": "critical",
    "重要": "important", "较重要": "important", "重大": "important",
    "普通": "normal", "一般": "normal", "常规": "normal",
    "次要": "normal", "轻微": "normal", "不重要": "normal",
}


def _normalize_importance(importance: str) -> str:
    if not importance or not importance.strip():
        return "normal"
    trimmed = importance.strip()
    lower = trimmed.lower()
    if lower in ("critical", "important", "normal"):
        return lower
    return IMPORTANCE_VALUE_MAP.get(trimmed, "normal")


def _contains_any(text: str, keywords: List[str]) -> bool:
    return any(kw in text for kw in keywords)


class ImportanceCorrector:
    @staticmethod
    def correct(changes):
        if changes is None:
            return
        try:
            ImportanceCorrector._normalize_all(changes)
            ImportanceCorrector._correct_characters(changes)
            ImportanceCorrector._correct_conflicts(changes)
            ImportanceCorrector._correct_factions(changes)
            ImportanceCorrector._enforce_critical_cap(changes)
        except Exception:
            pass

    @staticmethod
    def _normalize_all(changes):
        for c in getattr(changes, "CharacterStateChanges", []) or []:
            c.Importance = _normalize_importance(c.Importance)
        for c in getattr(changes, "ConflictProgress", []) or []:
            c.Importance = _normalize_importance(c.Importance)
        for p in getattr(changes, "NewPlotPoints", []) or []:
            p.Importance = _normalize_importance(p.Importance)
        for l in getattr(changes, "LocationStateChanges", []) or []:
            l.Importance = _normalize_importance(l.Importance)
        for f in getattr(changes, "FactionStateChanges", []) or []:
            f.Importance = _normalize_importance(f.Importance)
        tp = getattr(changes, "TimeProgression", None)
        if tp is not None:
            tp.Importance = _normalize_importance(tp.Importance)
        for m in getattr(changes, "CharacterMovements", []) or []:
            m.Importance = _normalize_importance(m.Importance)
        for s in getattr(changes, "SecretRevealChanges", []) or []:
            s.Importance = _normalize_importance(s.Importance)
        for t in getattr(changes, "ItemTransfers", []) or []:
            t.Importance = _normalize_importance(t.Importance)
        for p in getattr(changes, "PledgeConstraintChanges", []) or []:
            p.Importance = _normalize_importance(p.Importance)
        for d in getattr(changes, "DeadlineConstraintChanges", []) or []:
            d.Importance = _normalize_importance(d.Importance)

    @staticmethod
    def _correct_characters(changes):
        for c in getattr(changes, "CharacterStateChanges", []) or []:
            if not c.KeyEvent:
                continue
            if _contains_any(c.KeyEvent, CRITICAL_CHAR_KEYWORDS):
                c.Importance = "critical"
            elif c.Importance != "critical" and _contains_any(c.KeyEvent, IMPORTANT_CHAR_KEYWORDS):
                c.Importance = "important"

    @staticmethod
    def _correct_conflicts(changes):
        for c in getattr(changes, "ConflictProgress", []) or []:
            if c.Importance == "critical":
                continue
            status = c.NewStatus or ""
            if (status.lower() in ("resolved", "failed", "ended", "done", "closed", "finished",
                                   "complete", "completed")
                    or _contains_any(status, CONFLICT_IMPORTANT_STATUS_KEYWORDS)):
                c.Importance = "important"

    @staticmethod
    def _correct_factions(changes):
        for f in getattr(changes, "FactionStateChanges", []) or []:
            if not f.Event:
                continue
            if _contains_any(f.Event, CRITICAL_FACTION_KEYWORDS):
                f.Importance = "critical"
            elif f.Importance != "critical" and _contains_any(f.Event, IMPORTANT_FACTION_KEYWORDS):
                f.Importance = "important"

    @staticmethod
    def _enforce_critical_cap(changes):
        criticals = []
        for c in getattr(changes, "CharacterStateChanges", []) or []:
            if c.Importance == "critical":
                criticals.append(c)
        for c in getattr(changes, "ConflictProgress", []) or []:
            if c.Importance == "critical":
                criticals.append(c)
        for f in getattr(changes, "FactionStateChanges", []) or []:
            if f.Importance == "critical":
                criticals.append(f)
        if len(criticals) > MAX_CRITICAL_PER_CHAPTER:
            for c in criticals[MAX_CRITICAL_PER_CHAPTER:]:
                c.Importance = "important"
