# -*- coding: utf-8 -*-
"""内容生成回调 — 对标 4.1.1 ContentGenerationCallback.cs（主文件 + 5 partial classes）

章节内容生成后的级联处理：落盘、校验、追踪更新、摘要、向量索引、账本裁剪等。
"""

import json
import os
import time
from typing import Any, Dict, List, Optional, Tuple

from ..guides.guide_manager import GuideManager
from ..tracking.ledger_trim import LedgerTrimService
from .generation_gate import GenerationGate
from .importance_corrector import ImportanceCorrector


class ContentGenerationCallback:
    """对标 ContentGenerationCallback（partial class）"""

    SUMMARY_MAX_CHARS = 1500

    def __init__(
        self,
        generation_gate: GenerationGate,
        guide_manager: GuideManager,
        ledger_trim: LedgerTrimService,
        summary_store: Any,  # ChapterSummaryStore
        milestone_store: Any,  # ChapterMilestoneStore
        character_state_service: Any,
        conflict_progress_service: Any,
        plot_points_index_service: Any,
        foreshadowing_status_service: Any,
        location_state_service: Any,
        faction_state_service: Any,
        timeline_service: Any,
        item_state_service: Any,
        secret_reveal_service: Any,
        pledge_constraint_service: Any,
        deadline_constraint_service: Any,
        changes_wal_store: Any,  # ChapterChangesWalStore
        key_event_store: Any,  # ChapterKeyEventStore
        drift_fallback_patcher: Any,  # EntityDriftFallbackPatcher
    ):
        self._generation_gate = generation_gate
        self._guide_manager = guide_manager
        self._ledger_trim = ledger_trim
        self._summary_store = summary_store
        self._milestone_store = milestone_store
        self._character_state_service = character_state_service
        self._conflict_progress_service = conflict_progress_service
        self._plot_points_index_service = plot_points_index_service
        self._foreshadowing_status_service = foreshadowing_status_service
        self._location_state_service = location_state_service
        self._faction_state_service = faction_state_service
        self._timeline_service = timeline_service
        self._item_state_service = item_state_service
        self._secret_reveal_service = secret_reveal_service
        self._pledge_constraint_service = pledge_constraint_service
        self._deadline_constraint_service = deadline_constraint_service
        self._changes_wal_store = changes_wal_store
        self._key_event_store = key_event_store
        self._drift_fallback_patcher = drift_fallback_patcher

        self._name_map_cache: Optional[Tuple[Dict[str, str], float]] = None
        self._json_options = json.JSONEncoder(indent=2, ensure_ascii=False)

    def clear_name_map_cache(self):
        self._name_map_cache = None

    # ================= Core =================

    async def on_content_generated_strict_async(
        self,
        chapter_id: str,
        raw_content: str,
        fact_snapshot: Any,
        gate_result: Optional[Any] = None,
        design_elements: Optional[Any] = None,
        context_ids: Optional[Any] = None,
    ):
        await self._on_content_generated_internal_async(
            chapter_id, raw_content, fact_snapshot,
            gate_result, design_elements, context_ids,
        )

    # ================= External Save =================

    async def on_external_content_saved_async(self, chapter_id: str, content: str):
        """对标 OnExternalContentSavedAsync"""
        correlation = getattr(self, "_correlation", "ext")
        self._log(f"[ContentCallback][{correlation}] 外部内容保存: {chapter_id}")

        content_with_changes = content
        external_changes = None
        protocol = self._generation_gate.validate_changes_protocol(content_with_changes)
        if not protocol["success"]:
            has_protocol_error = any(
                "未识别到CHANGES区域" not in e and "内容为空" not in e
                for e in protocol.get("errors", [])
            )
            if has_protocol_error:
                reasons = "; ".join(protocol.get("errors", [])[:3])
                raise RuntimeError(f"外部内容CHANGES协议无效: {reasons}")
        if protocol["success"] and protocol.get("changes") is not None:
            fact_snapshot = None
            try:
                guide_service = self._get_guide_context_service()
                content_guide = await guide_service.get_content_guide_async()
                if not content_guide or not content_guide.get("Chapters") or chapter_id not in content_guide["Chapters"]:
                    raise RuntimeError(f"未找到章节 {chapter_id} 的 ContextIds")
                entry = content_guide["Chapters"][chapter_id]
                ctx_valid = await guide_service.validate_context_ids_async(entry.get("ContextIds"))
                if not ctx_valid.get("is_valid"):
                    raise RuntimeError(f"ContextIds 校验失败: {ctx_valid.get('error_summary', '')}")
                fact_snapshot = await guide_service.extract_fact_snapshot_for_chapter_async(chapter_id, entry["ContextIds"])
            except Exception as ex:
                raise RuntimeError(f"外部内容一致性校验准备失败: {ex}")

            self._report_phase("validating", f"正在校验外部保存章节 {chapter_id}...")
            gate_result = await self._generation_gate.validate_async(
                chapter_id, content_with_changes, fact_snapshot,
                design_elements=None, context_ids=entry["ContextIds"],
            )
            if not gate_result["success"]:
                reasons = "; ".join(gate_result.get("human_readable_failures", [])[:5])
                raise RuntimeError(f"外部内容落盘前校验失败: {reasons}")

            external_changes = gate_result.get("parsed_changes")
            content = gate_result.get("content_without_changes") or protocol.get("content_without_changes") or content
            self._log(f"[ContentCallback][{correlation}] {chapter_id} 检测到CHANGES块，将同步追踪Guide")

            ImportanceCorrector.correct(external_changes)

            if external_changes is not None:
                await self._changes_wal_store.write_async(chapter_id, external_changes)

        persisted_content = await self._normalize_persisted_content_async(chapter_id, content)

        chapters_path = self._get_chapters_path()
        staging_path = os.path.join(chapters_path, ".staging")
        chapter_file = os.path.join(chapters_path, f"{chapter_id}.md")
        staging_file = os.path.join(staging_path, f"{chapter_id}.md")
        backup_file = chapter_file + ".bak"
        had_existing_file = os.path.exists(chapter_file)
        content_changed = True
        if had_existing_file:
            try:
                with open(chapter_file, "r", encoding="utf-8") as f:
                    old_persisted = f.read()
                content_changed = old_persisted != persisted_content
            except Exception as ex:
                self._log(f"[ContentCallback] {chapter_id} 比较旧正文失败（按已变更处理）: {ex}")
                content_changed = True

        summary = None
        name_map = None
        purged_first_idx_ids: List[str] = []
        guide_flushed = False
        try:
            os.makedirs(staging_path, exist_ok=True)
            self._report_phase("persisting", f"正在保存外部章节 {chapter_id}...")

            with open(staging_file, "w", encoding="utf-8") as f:
                f.write(persisted_content)

            if had_existing_file:
                import shutil
                shutil.copy2(chapter_file, backup_file)

            os.replace(staging_file, chapter_file)

            name_map = await self._build_entity_name_map_async() if external_changes is not None else None
            summary = (
                self._build_structured_summary(persisted_content, external_changes, name_map)
                if external_changes is not None
                else self._extract_summary(persisted_content)
            )

            if external_changes is not None:
                if had_existing_file:
                    purged_first_idx_ids = await self._remove_tracking_data_for_chapter_async(chapter_id)
                    self._log(f"[ContentCallback][{correlation}] {chapter_id} 外部重写：已清除旧追踪数据 (carry-over={len(purged_first_idx_ids)})")
                await self._update_tracking_guides_async(chapter_id, external_changes)
                self._log(f"[ContentCallback][{correlation}] {chapter_id} 外部CHANGES追踪已更新")
            elif had_existing_file and content_changed:
                self._log(f"[ContentCallback][{correlation}] {chapter_id} 未提供CHANGES，保留旧追踪数据（静默保存）")

            await self._guide_manager.flush_all_async()
            guide_flushed = True

            if external_changes is not None:
                if self._verify_commit_sync(chapter_id):
                    self._changes_wal_store.delete(chapter_id)
                else:
                    self._log(f"[ContentCallback][{correlation}] {chapter_id} 外部保存提交验证未通过，保留WAL")

            self._get_guide_context_service().invalidate_content_guide_cache()

            await self._update_chapter_summary_async(chapter_id, summary)

            await self._ledger_trim.trim_all_async()

            if os.path.exists(backup_file):
                os.remove(backup_file)

            self._log(f"[ContentCallback][{correlation}] {chapter_id} ext ok")
        except Exception as ex:
            self._log(f"[ContentCallback][{correlation}] {chapter_id} ext err: {ex}")
            if not guide_flushed:
                self._guide_manager.discard_dirty_and_evict()
            try:
                if os.path.exists(staging_file):
                    os.remove(staging_file)
                if not guide_flushed:
                    if had_existing_file and os.path.exists(backup_file):
                        import shutil
                        shutil.copy2(backup_file, chapter_file)
                        os.remove(backup_file)
                    elif not had_existing_file and os.path.exists(chapter_file):
                        os.remove(chapter_file)
                else:
                    if os.path.exists(backup_file):
                        os.remove(backup_file)
                    self._log(f"[ContentCallback] {chapter_id} partial ok")
            except Exception as rollback_ex:
                self._log(f"[ContentCallback] {chapter_id} 回滚失败: {rollback_ex}")
            if not guide_flushed:
                raise

        # 后置并行任务
        import asyncio

        async def run_keyword_index():
            if external_changes is None:
                return
            try:
                kw_service = self._get_keyword_chapter_index_service()
                await kw_service.index_chapter_async(chapter_id, external_changes)
            except Exception as ex:
                self._log(f"[ContentCallback] {chapter_id} 关键词索引更新失败（不影响正文）: {ex}")

        async def build_vectors():
            await self._rebuild_vector_indices_for_chapter_async(
                chapter_id, persisted_content, external_changes, name_map, purged_first_idx_ids,
            )

        await asyncio.gather(
            run_keyword_index(),
            self._try_update_volume_milestone_async(chapter_id, summary, is_rewrite=had_existing_file, changes=external_changes),
            build_vectors(),
        )

        self._report_phase("done", f"外部章节 {chapter_id} 保存完成")

    # ================= Internal Generate =================

    async def _on_content_generated_internal_async(
        self,
        chapter_id: str,
        raw_content: str,
        fact_snapshot: Any,
        gate_result: Optional[Any],
        design_elements: Optional[Any] = None,
        context_ids: Optional[Any] = None,
    ):
        self._report_phase("validating", "正在落盘前最终校验...")

        gate_result_final = await self._generation_gate.validate_async(
            chapter_id, raw_content, fact_snapshot, design_elements, context_ids=context_ids,
        )
        if not gate_result_final["success"]:
            errors = "; ".join(gate_result_final.get("human_readable_failures", [])[:5])
            err_msg = f"[ContentCallback] {chapter_id} 落盘前校验失败: {errors}"
            self._log(err_msg)
            raise RuntimeError(err_msg)

        changes = gate_result_final.get("parsed_changes")
        content = gate_result_final.get("content_without_changes") or raw_content
        self._log(f"[ContentCallback] {chapter_id} 校验通过")

        ImportanceCorrector.correct(changes)

        if changes is not None:
            await self._changes_wal_store.write_async(chapter_id, changes)

        content = await self._normalize_persisted_content_async(chapter_id, content)

        chapters_path = self._get_chapters_path()
        staging_path = os.path.join(chapters_path, ".staging")
        chapter_file = os.path.join(chapters_path, f"{chapter_id}.md")
        staging_file = os.path.join(staging_path, f"{chapter_id}.md")
        backup_file = chapter_file + ".bak"
        had_existing_file = os.path.exists(chapter_file)

        summary = None
        purged_first_idx_ids: List[str] = []
        guide_flushed = False
        try:
            os.makedirs(staging_path, exist_ok=True)

            self._report_phase("persisting", f"正在清洗并落盘章节 {chapter_id}...")

            with open(staging_file, "w", encoding="utf-8") as f:
                f.write(content)
            self._log(f"[ContentCallback] S1: {chapter_id}")

            if had_existing_file:
                import shutil
                shutil.copy2(chapter_file, backup_file)

            os.replace(staging_file, chapter_file)
            self._log(f"[ContentCallback] S2: {chapter_id}")

            strict_gate = True
            name_map = await self._build_entity_name_map_async() if changes is not None else None
            summary = (
                self._build_structured_summary(content, changes, name_map)
                if changes is not None
                else self._extract_summary(content)
            )

            if strict_gate and changes is not None and summary:
                try:
                    drift_result = await self._drift_fallback_patcher.detect_and_apply_async(
                        chapter_id, summary, changes,
                    )
                    if drift_result.get("patched_changes"):
                        summary = self._build_structured_summary(content, changes, name_map)
                    for dirty_file in drift_result.get("dirty_guide_files", []):
                        self._guide_manager.mark_dirty(dirty_file)
                except Exception as drift_ex:
                    self._log(f"[ContentCallback] 漂移兜底失败（非致命）: {drift_ex}")

            if had_existing_file and changes is not None:
                purged_first_idx_ids = await self._remove_tracking_data_for_chapter_async(chapter_id)

            if changes is not None:
                await self._update_tracking_guides_async(chapter_id, changes)
            else:
                self._log(f"[ContentCallback] {chapter_id} 无CHANGES，跳过追踪更新")

            await self._guide_manager.flush_all_async()
            guide_flushed = True

            if changes is not None:
                if self._verify_commit_sync(chapter_id):
                    self._changes_wal_store.delete(chapter_id)
                else:
                    self._log(f"[ContentCallback] {chapter_id} 提交验证未通过，保留WAL")

            self._get_guide_context_service().invalidate_content_guide_cache()

            import asyncio

            async def write_summary():
                await self._update_chapter_summary_async(chapter_id, summary)

            async def trim_ledger():
                await self._ledger_trim.trim_all_async()

            async def index_keyword():
                if changes is None:
                    return
                try:
                    kw = self._get_keyword_chapter_index_service()
                    await kw.index_chapter_async(chapter_id, changes)
                except Exception as ex:
                    self._log(f"[ContentCallback] 关键词索引更新失败（非致命）: {ex}")

            async def build_vectors():
                await self._rebuild_vector_indices_for_chapter_async(
                    chapter_id, content, changes, name_map, purged_first_idx_ids,
                )

            await asyncio.gather(write_summary(), trim_ledger(), index_keyword(), build_vectors())

            if os.path.exists(backup_file):
                os.remove(backup_file)

            self._log(f"[ContentCallback] {chapter_id} ok")
        except Exception as ex:
            self._log(f"[ContentCallback] {chapter_id} err: {ex}")
            if not guide_flushed:
                self._guide_manager.discard_dirty_and_evict()
            try:
                if os.path.exists(staging_file):
                    os.remove(staging_file)
                if not guide_flushed:
                    if had_existing_file and os.path.exists(backup_file):
                        import shutil
                        shutil.copy2(backup_file, chapter_file)
                        os.remove(backup_file)
                    elif not had_existing_file and os.path.exists(chapter_file):
                        os.remove(chapter_file)
                else:
                    if os.path.exists(backup_file):
                        os.remove(backup_file)
                    self._log(f"[ContentCallback] {chapter_id} partial ok (idx)")
            except Exception as rollback_ex:
                self._log(f"[ContentCallback] {chapter_id} 回滚失败: {rollback_ex}")
            if not guide_flushed:
                raise

        await self._try_update_volume_milestone_async(
            chapter_id, summary, is_rewrite=had_existing_file, changes=changes,
        )

        self._report_phase("done", f"章节 {chapter_id} 生成完成")

    # ================= Repair =================

    async def repair_tracking_from_wal_async(self, chapter_id: str, changes: Any) -> bool:
        """对标 RepairTrackingFromWalAsync"""
        self._log(f"[ContentCallback] WAL修复追踪开始: {chapter_id}")
        try:
            purged_first_idx_ids = await self._remove_tracking_data_for_chapter_async(chapter_id)
            await self._update_tracking_guides_async(chapter_id, changes)
            await self._guide_manager.flush_all_async()

            if self._verify_commit_sync(chapter_id):
                self._changes_wal_store.delete(chapter_id)
                self._log(f"[ContentCallback] WAL修复追踪完成: {chapter_id}")
            else:
                self._log(f"[ContentCallback] WAL修复后提交验证未通过，保留WAL: {chapter_id}")

            self._get_guide_context_service().invalidate_content_guide_cache()
            await self._rebuild_vector_indices_after_repair_async(chapter_id, changes, purged_first_idx_ids)
            return True
        except Exception as ex:
            self._log(f"[ContentCallback] WAL修复追踪失败 {chapter_id}: {ex}")
            self._guide_manager.discard_dirty_and_evict()
            return False

    async def rebuild_tracking_from_content_async(self, chapter_id: str, content_with_changes: str) -> Optional[str]:
        """对标 RebuildTrackingFromContentAsync，返回 None=成功，str=错误消息"""
        self._log(f"[ContentCallback] 重建追踪开始: {chapter_id}")

        protocol = self._generation_gate.validate_changes_protocol(content_with_changes)
        if not protocol["success"] or protocol.get("changes") is None:
            msg = "当前内容不含 CHANGES 块，无法重建追踪。请先确保内容包含有效的 CHANGES 区域。"
            self._log(f"[ContentCallback] 重建追踪失败: {chapter_id} 未找到CHANGES块")
            return msg

        struct_result = self._generation_gate.validate_structural_only(protocol["changes"])
        if not struct_result["success"]:
            issues = "; ".join(struct_result.get("issue_descriptions", [])[:5])
            msg = f"CHANGES 结构校验失败: {issues}"
            self._log(f"[ContentCallback] 重建追踪失败: {chapter_id} {msg}")
            return msg

        changes = None
        try:
            guide_service = self._get_guide_context_service()
            content_guide = await guide_service.get_content_guide_async()
            if not content_guide or not content_guide.get("Chapters") or chapter_id not in content_guide["Chapters"]:
                raise RuntimeError(f"未找到章节 {chapter_id} 的 ContextIds")
            entry = content_guide["Chapters"][chapter_id]
            ctx_valid = await guide_service.validate_context_ids_async(entry.get("ContextIds"))
            if not ctx_valid.get("is_valid"):
                raise RuntimeError(f"ContextIds 校验失败: {ctx_valid.get('error_summary', '')}")
            fact_snapshot = await guide_service.extract_fact_snapshot_for_chapter_async(chapter_id, entry["ContextIds"])
            gate_result = await self._generation_gate.validate_async(
                chapter_id, content_with_changes, fact_snapshot,
                design_elements=None, context_ids=entry["ContextIds"],
            )
            if not gate_result["success"]:
                reasons = "; ".join(gate_result.get("human_readable_failures", [])[:5])
                msg = f"重建追踪前校验失败: {reasons}"
                self._log(f"[ContentCallback] {chapter_id} {msg}")
                return msg
            changes = gate_result.get("parsed_changes") or protocol["changes"]
        except Exception as ex:
            msg = f"重建追踪一致性校验准备失败: {ex}"
            self._log(f"[ContentCallback] {chapter_id} {msg}")
            return msg

        try:
            purged_first_idx_ids = await self._remove_tracking_data_for_chapter_async(chapter_id)
            self._log(f"[ContentCallback] 重建追踪: {chapter_id} 旧数据已清除")

            await self._update_tracking_guides_async(chapter_id, changes)
            self._log(f"[ContentCallback] 重建追踪: {chapter_id} 新追踪已写入")

            await self._guide_manager.flush_all_async()
            self._get_guide_context_service().invalidate_content_guide_cache()

            try:
                kw = self._get_keyword_chapter_index_service()
                await kw.index_chapter_async(chapter_id, changes)
            except Exception as ex:
                self._log(f"[ContentCallback] 重建追踪: {chapter_id} 关键词索引更新失败（非致命）: {ex}")

            await self._rebuild_vector_indices_after_repair_async(chapter_id, changes, purged_first_idx_ids)
            self._log(f"[ContentCallback] 重建追踪完成: {chapter_id}")
            return None
        except Exception as ex:
            err_msg = f"重建追踪失败: {ex}"
            self._log(f"[ContentCallback] {chapter_id} {err_msg}")
            self._guide_manager.discard_dirty_and_evict()
            return err_msg

    async def on_chapter_deleted_async(self, chapter_id: str):
        """对标 OnChapterDeletedAsync"""
        self._log(f"[ContentCallback] 开始级联清理: {chapter_id}")

        self._changes_wal_store.delete(chapter_id)

        try:
            await self._summary_store.remove_summary_async(chapter_id)
        except Exception as ex:
            self._log(f"[ContentCallback] 清理摘要失败: {ex}")

        import asyncio

        async def safe_clean(coro, label):
            try:
                await coro
            except Exception as ex:
                self._log(f"[ContentCallback] 清理{label}失败: {ex}")

        await asyncio.gather(
            safe_clean(self._character_state_service.remove_chapter_data_async(chapter_id), "角色状态"),
            safe_clean(self._conflict_progress_service.remove_chapter_data_async(chapter_id), "冲突进度"),
            safe_clean(self._plot_points_index_service.remove_chapter_data_async(chapter_id), "情节索引"),
            safe_clean(self._foreshadowing_status_service.remove_chapter_data_async(chapter_id), "伏笔状态"),
            safe_clean(self._location_state_service.remove_chapter_data_async(chapter_id), "地点状态"),
            safe_clean(self._faction_state_service.remove_chapter_data_async(chapter_id), "势力状态"),
            safe_clean(self._timeline_service.remove_chapter_data_async(chapter_id), "时间线"),
            safe_clean(self._item_state_service.remove_chapter_data_async(chapter_id), "物品状态"),
            safe_clean(self._secret_reveal_service.remove_chapter_data_async(chapter_id), "秘密知情"),
            safe_clean(self._pledge_constraint_service.remove_chapter_data_async(chapter_id), "承诺/契约"),
            safe_clean(self._deadline_constraint_service.remove_chapter_data_async(chapter_id), "倒计时/时限"),
        )

        try:
            self._invalidate_relation_strength_cache()
        except Exception as ex:
            self._log(f"[ContentCallback] 关联强度缓存失效失败（非致命）: {ex}")

        try:
            await self._guide_manager.flush_all_async()
            self._get_guide_context_service().invalidate_content_guide_cache()
        except Exception as ex:
            self._log(f"[ContentCallback] guides刷盘失败: {ex}")

        try:
            kw = self._get_keyword_chapter_index_service()
            await kw.remove_chapter_async(chapter_id)
        except Exception as ex:
            self._log(f"[ContentCallback] 清理关键词索引失败（非致命）: {ex}")

        await self._clean_vector_indices_async(chapter_id)

        try:
            parsed = self._parse_chapter_id(chapter_id)
            if parsed:
                vol = parsed["volume_number"]
                current_summaries = await self._summary_store.get_volume_summaries_async(vol)
                await self._milestone_store.rebuild_volume_milestone_async(vol, current_summaries)
        except Exception as ex:
            self._log(f"[ContentCallback] 里程碑重建失败（非致命）: {ex}")

        try:
            archive_store = self._get_volume_fact_archive_store()
            parsed = self._parse_chapter_id(chapter_id)
            if parsed:
                await archive_store.delete_archive_async(parsed["volume_number"])
            else:
                archive_store.invalidate_cache()
        except Exception as ex:
            self._log(f"[ContentCallback] 存档联动清理失败（非致命）: {ex}")

        self._log(f"[ContentCallback] 级联清理完成: {chapter_id}")

    # ================= Summary =================

    def _build_structured_summary(self, content: str, changes: Any, name_map: Optional[Dict[str, str]] = None) -> str:
        """对标 BuildStructuredSummary"""
        def r(eid: str) -> str:
            if eid and name_map and eid in name_map:
                return name_map[eid]
            return eid

        lines = []
        lines.append(self._extract_summary(content, 200))

        for c in (changes.get("CharacterStateChanges") or []):
            if c.get("KeyEvent"):
                lines.append(f"[角色]{r(c.get('CharacterId'))}: {c['KeyEvent']}")

        for c in (changes.get("ConflictProgress") or []):
            if c.get("Event"):
                lines.append(f"[冲突]{r(c.get('ConflictId'))}: {c['Event']}→{c.get('NewStatus')}")

        for p in (changes.get("NewPlotPoints") or []):
            if p.get("Context"):
                lines.append(f"[情节]{p['Context']}")

        for f in (changes.get("ForeshadowingActions") or []):
            if f.get("ForeshadowId"):
                lines.append(f"[伏笔]{r(f['ForeshadowId'])}: {f.get('Action')}")

        for l in (changes.get("LocationStateChanges") or []):
            if l.get("Event"):
                lines.append(f"[地点]{r(l.get('LocationId'))}: {l['Event']}→{l.get('NewStatus')}")

        for fa in (changes.get("FactionStateChanges") or []):
            if fa.get("Event"):
                lines.append(f"[势力]{r(fa.get('FactionId'))}: {fa['Event']}→{fa.get('NewStatus')}")

        tp = changes.get("TimeProgression")
        if tp and tp.get("TimePeriod"):
            lines.append(f"[时间]{tp['TimePeriod']} 经过{tp.get('ElapsedTime')}")

        for m in (changes.get("CharacterMovements") or []):
            if m.get("ToLocation"):
                lines.append(f"[移动]{r(m.get('CharacterId'))}: {r(m.get('FromLocation'))}→{r(m.get('ToLocation'))}")

        for item in (changes.get("ItemTransfers") or []):
            if item.get("Event"):
                lines.append(f"[物品]{item.get('ItemName')}: {item['Event']} ({r(item.get('FromHolder'))}→{r(item.get('ToHolder'))})")

        for sr in (changes.get("SecretRevealChanges") or []):
            if sr.get("KeyEvent"):
                lines.append(f"[秘密]{r(sr.get('SecretId'))}: {sr.get('Method')} {sr['KeyEvent']}")

        for pc in (changes.get("PledgeConstraintChanges") or []):
            if pc.get("KeyEvent"):
                lines.append(f"[承诺]{r(pc.get('PledgeId'))}: {pc.get('Action')} {pc['KeyEvent']}")

        for dc in (changes.get("DeadlineConstraintChanges") or []):
            if dc.get("KeyEvent"):
                lines.append(f"[时限]{r(dc.get('DeadlineId'))}: {dc.get('Action')} {dc['KeyEvent']}")

        result = "\n".join(lines).strip()
        if len(result) > self.SUMMARY_MAX_CHARS:
            last_newline = result.rfind("\n", 0, self.SUMMARY_MAX_CHARS)
            if last_newline > self.SUMMARY_MAX_CHARS // 3:
                result = result[:last_newline].rstrip() + "\n[...摘要已截断]"
            else:
                result = result[:self.SUMMARY_MAX_CHARS] + "..."
            self._log(f"[ContentCallback] 摘要超长截断: {len(lines)} → {len(result)} chars")
        return result

    def _extract_summary(self, content: str, max_length: int = 500) -> str:
        """对标 ExtractSummary"""
        if not content:
            return ""
        cleaned = content.replace("\r\n", " ").replace("\n", " ").strip()
        if len(cleaned) <= max_length:
            return cleaned
        cut_region = cleaned[:max_length]
        last_sentence_end = max(
            cut_region.rfind(c) for c in ["。", "！", "？", "…", '"']
        )
        if last_sentence_end > max_length // 3:
            return cut_region[:last_sentence_end + 1] + "……"
        return cut_region + "……"

    async def _update_chapter_summary_async(self, chapter_id: str, summary: str):
        """对标 UpdateChapterSummaryAsync"""
        max_retries = 2
        for attempt in range(1, max_retries + 1):
            try:
                await self._summary_store.set_summary_async(chapter_id, summary)
                self._log(f"[ContentCallback] 已更新章节摘要: {chapter_id}")
                return
            except Exception as ex:
                if attempt < max_retries:
                    self._log(f"[ContentCallback] 摘要写入第{attempt}次失败，重试中: {ex}")
                    import asyncio
                    await asyncio.sleep(0.1)
                else:
                    self._log(f"[ContentCallback] [!] 摘要写入失败，将由启动对账修复: {chapter_id}: {ex}")

    @staticmethod
    def _verify_commit_sync(chapter_id: str) -> bool:
        """对标 VerifyCommitSync"""
        try:
            project_name = getattr(StoragePathHelper, "current_project_name", None)
            if not project_name:
                return True
            guides_dir = os.path.join(StoragePathHelper.get_storage_root(), "Projects", project_name, "Config", "guides")
            staging_dir = os.path.join(guides_dir, ".flush_staging")
            if os.path.isdir(staging_dir) and [f for f in os.listdir(staging_dir) if f.endswith(".json")]:
                return False
            return True
        except Exception as ex:
            self._log(f"[ContentCallback] VerifyCommit err: {ex}")
            return False

    # ================= Tracking =================

    async def _remove_tracking_data_for_chapter_async(self, chapter_id: str) -> List[str]:
        """对标 RemoveTrackingDataForChapterAsync"""
        purged_first_idx_ids: List[str] = []
        try:
            first_idx = self._get_entity_first_chapter_index()
            await first_idx.load_async()
            purged_first_idx_ids = [
                e["EntityId"] for e in first_idx.get_all()
                if e.get("ChapterId", "").lower() == chapter_id.lower()
            ]
        except Exception as ex:
            self._log(f"[ContentCallback] {chapter_id} 快照 firstIdx 本章条目失败（非致命）: {ex}")

        import asyncio

        async def safe_remove(coro, label):
            try:
                await coro
            except Exception as ex:
                self._log(f"[ContentCallback] {chapter_id} 清除{label}失败（重写前）: {ex}")

        await asyncio.gather(
            safe_remove(self._character_state_service.remove_chapter_data_async(chapter_id), "角色状态"),
            safe_remove(self._conflict_progress_service.remove_chapter_data_async(chapter_id), "冲突进度"),
            safe_remove(self._plot_points_index_service.remove_chapter_data_async(chapter_id), "情节索引"),
            safe_remove(self._foreshadowing_status_service.remove_chapter_data_async(chapter_id), "伏笔状态"),
            safe_remove(self._location_state_service.remove_chapter_data_async(chapter_id), "地点状态"),
            safe_remove(self._faction_state_service.remove_chapter_data_async(chapter_id), "势力状态"),
            safe_remove(self._timeline_service.remove_chapter_data_async(chapter_id), "时间线"),
            safe_remove(self._item_state_service.remove_chapter_data_async(chapter_id), "物品状态"),
            safe_remove(self._secret_reveal_service.remove_chapter_data_async(chapter_id), "秘密知情"),
            safe_remove(self._pledge_constraint_service.remove_chapter_data_async(chapter_id), "承诺/契约"),
            safe_remove(self._deadline_constraint_service.remove_chapter_data_async(chapter_id), "倒计时/时限"),
            safe_remove(self._get_keyword_chapter_index_service().remove_chapter_async(chapter_id), "关键词索引"),
        )

        try:
            self._invalidate_relation_strength_cache()
        except Exception as ex:
            self._log(f"[ContentCallback] {chapter_id} 关联强度缓存失效失败（重写前）: {ex}")

        await self._clean_vector_indices_async(chapter_id)

        self._log(f"[ContentCallback] 已清除 {chapter_id} 旧追踪数据（重写前），carry-over firstIdx 条目={len(purged_first_idx_ids)}")
        return purged_first_idx_ids

    async def _update_tracking_guides_async(self, chapter_id: str, changes: Any):
        """对标 UpdateTrackingGuidesAsync"""
        import asyncio

        async def update_char_states():
            count = len(changes.get("CharacterStateChanges") or [])
            for change in changes.get("CharacterStateChanges") or []:
                await self._character_state_service.update_character_state_async(chapter_id, change)
            if count > 0:
                self._log(f"[ContentCallback] {chapter_id} 更新角色状态: {count}条")

        async def update_conflicts():
            count = len(changes.get("ConflictProgress") or [])
            for change in changes.get("ConflictProgress") or []:
                await self._conflict_progress_service.update_conflict_progress_async(chapter_id, change)
            if count > 0:
                self._log(f"[ContentCallback] {chapter_id} 更新冲突进度: {count}条")

        async def update_plot_points():
            count = len(changes.get("NewPlotPoints") or [])
            for change in changes.get("NewPlotPoints") or []:
                await self._plot_points_index_service.add_plot_point_async(chapter_id, change)
            if count > 0:
                self._log(f"[ContentCallback] {chapter_id} 添加关键情节: {count}条")

        async def update_foreshadowing():
            count = len(changes.get("ForeshadowingActions") or [])
            for action in changes.get("ForeshadowingActions") or []:
                if action.get("Action", "").lower() == "setup":
                    await self._foreshadowing_status_service.mark_as_setup_async(action["ForeshadowId"], chapter_id)
                elif action.get("Action", "").lower() == "payoff":
                    await self._foreshadowing_status_service.mark_as_resolved_async(action["ForeshadowId"], chapter_id)
            if count > 0:
                self._log(f"[ContentCallback] {chapter_id} 更新伏笔状态: {count}条")

        async def update_locations():
            count = len(changes.get("LocationStateChanges") or [])
            for change in changes.get("LocationStateChanges") or []:
                await self._location_state_service.update_location_state_async(chapter_id, change)
            if count > 0:
                self._log(f"[ContentCallback] {chapter_id} 更新地点状态: {count}条")

        async def update_factions():
            count = len(changes.get("FactionStateChanges") or [])
            for change in changes.get("FactionStateChanges") or []:
                await self._faction_state_service.update_faction_state_async(chapter_id, change)
            if count > 0:
                self._log(f"[ContentCallback] {chapter_id} 更新势力状态: {count}条")

        async def update_timeline():
            tp = changes.get("TimeProgression")
            if tp is not None:
                await self._timeline_service.update_time_progression_async(chapter_id, tp)
                self._log(f"[ContentCallback] {chapter_id} 更新时间推进")
            movement_count = len(changes.get("CharacterMovements") or [])
            if movement_count > 0:
                await self._timeline_service.update_character_movements_async(chapter_id, changes["CharacterMovements"])
                self._log(f"[ContentCallback] {chapter_id} 更新角色位置: {movement_count}条")

        async def update_items():
            count = len(changes.get("ItemTransfers") or [])
            for change in changes.get("ItemTransfers") or []:
                await self._item_state_service.update_item_state_async(chapter_id, change)
            if count > 0:
                self._log(f"[ContentCallback] {chapter_id} 更新物品流转: {count}条")

        async def update_secrets():
            count = len(changes.get("SecretRevealChanges") or [])
            for change in changes.get("SecretRevealChanges") or []:
                await self._secret_reveal_service.update_secret_reveal_async(chapter_id, change)
            if count > 0:
                self._log(f"[ContentCallback] {chapter_id} 更新秘密知情: {count}条")

        async def update_pledges():
            count = len(changes.get("PledgeConstraintChanges") or [])
            for change in changes.get("PledgeConstraintChanges") or []:
                await self._pledge_constraint_service.update_pledge_async(chapter_id, change)
            if count > 0:
                self._log(f"[ContentCallback] {chapter_id} 更新承诺/契约: {count}条")

        async def update_deadlines():
            count = len(changes.get("DeadlineConstraintChanges") or [])
            for change in changes.get("DeadlineConstraintChanges") or []:
                await self._deadline_constraint_service.update_deadline_async(chapter_id, change)
            if count > 0:
                self._log(f"[ContentCallback] {chapter_id} 更新倒计时/时限: {count}条")

        await asyncio.gather(
            update_char_states(), update_conflicts(), update_plot_points(),
            update_foreshadowing(), update_locations(), update_factions(),
            update_timeline(), update_items(), update_secrets(),
            update_pledges(), update_deadlines(),
        )

        await self._foreshadowing_status_service.refresh_overdue_status_async(chapter_id)

        cfg = self._get_layered_context_config()
        import asyncio
        await asyncio.gather(
            self._pledge_constraint_service.refresh_overdue_status_async(chapter_id, cfg.get("PledgeMaxDanglingChapters", 10)),
            self._deadline_constraint_service.refresh_overdue_status_async(chapter_id, cfg.get("DeadlineMaxDanglingChapters", 10)),
        )

        self._log(f"[ContentCallback] {chapter_id} done")

    async def _try_update_volume_milestone_async(
        self, chapter_id: str, summary: Optional[str] = None,
        is_rewrite: bool = False, changes: Optional[Any] = None,
    ):
        """对标 TryUpdateVolumeMilestoneAsync"""
        try:
            parsed = self._parse_chapter_id(chapter_id)
            if not parsed:
                return
            volume_number = parsed["volume_number"]

            if summary:
                if is_rewrite:
                    current_summaries = await self._summary_store.get_volume_summaries_async(volume_number)
                    await self._milestone_store.rebuild_volume_milestone_async(volume_number, current_summaries)
                    self._log(f"[ContentCallback] {chapter_id} 重写场景，已全量重建第{volume_number}卷里程碑")
                else:
                    await self._milestone_store.append_chapter_milestone_async(volume_number, chapter_id, summary)

            if changes is not None:
                key_entry = self._extract_key_event_entry(chapter_id, volume_number, parsed["chapter_number"], changes)
                if key_entry is not None:
                    await self._key_event_store.upsert_async(volume_number, key_entry)

            await self._try_archive_volume_fact_async(chapter_id, volume_number)
        except Exception as ex:
            self._log(f"[ContentCallback] {chapter_id} 里程碑更新失败（不影响正文）: {ex}")

    @staticmethod
    def _extract_key_event_entry(chapter_id: str, volume_number: int, chapter_number: int, changes: Any) -> Optional[Dict]:
        """对标 ExtractKeyEventEntry"""
        entry = {
            "ChapterId": chapter_id,
            "VolumeNumber": volume_number,
            "ChapterNumber": chapter_number,
            "Characters": [],
            "Turnings": [],
            "Foreshadows": [],
            "Factions": [],
        }

        for c in changes.get("CharacterStateChanges") or []:
            if c.get("KeyEvent") and ContentGenerationCallback._is_high_importance(c.get("Importance")):
                entry["Characters"].append(f"{c['CharacterId']}:{c['KeyEvent']}")

        for p in changes.get("NewPlotPoints") or []:
            if p.get("Context") and ContentGenerationCallback._is_high_importance(p.get("Importance")):
                entry["Turnings"].append(p["Context"])

        for f in changes.get("ForeshadowingActions") or []:
            if f.get("ForeshadowId"):
                if f.get("Action", "").lower() == "payoff":
                    entry["Foreshadows"].append(f"{f['ForeshadowId']}:回收")
                elif f.get("Action", "").lower() == "setup":
                    entry["Foreshadows"].append(f"{f['ForeshadowId']}:埋设")

        for fa in changes.get("FactionStateChanges") or []:
            if fa.get("Event") and ContentGenerationCallback._is_high_importance(fa.get("Importance")):
                entry["Factions"].append(f"{fa.get('FactionId')}:{fa['Event']}→{fa.get('NewStatus')}")

        for cf in changes.get("ConflictProgress") or []:
            if cf.get("Event") and ContentGenerationCallback._is_high_importance(cf.get("Importance")):
                entry["Factions"].append(f"{cf.get('ConflictId')}:{cf['Event']}→{cf.get('NewStatus')}")

        if not any([entry["Characters"], entry["Turnings"], entry["Foreshadows"], entry["Factions"]]):
            return None
        return entry

    @staticmethod
    def _is_high_importance(importance: Optional[str]) -> bool:
        if importance is None:
            return False
        return importance.lower() in ("important", "critical")

    # ================= Name Map =================

    async def _build_entity_name_map_async(self) -> Dict[str, str]:
        """对标 BuildEntityNameMapAsync"""
        if self._name_map_cache is not None:
            cached_map, expires = self._name_map_cache
            if time.time() < expires:
                return cached_map

        name_map: Dict[str, str] = {}
        try:
            gm = self._guide_manager
            char_vols = gm.get_existing_volume_numbers("character_state_guide.json")
            conf_vols = gm.get_existing_volume_numbers("conflict_progress_guide.json")
            loc_vols = gm.get_existing_volume_numbers("location_state_guide.json")
            fac_vols = gm.get_existing_volume_numbers("faction_state_guide.json")
            pledge_vols = gm.get_existing_volume_numbers("pledge_constraint_guide.json")
            deadline_vols = gm.get_existing_volume_numbers("deadline_constraint_guide.json")
            secret_vols = gm.get_existing_volume_numbers("secret_reveal_guide.json")

            import asyncio
            tasks = []
            tasks.extend(gm.get_guide_async(GuideManager.get_volume_file_name("character_state_guide.json", v)) for v in char_vols)
            tasks.extend(gm.get_guide_async(GuideManager.get_volume_file_name("conflict_progress_guide.json", v)) for v in conf_vols)
            tasks.append(gm.get_guide_async("foreshadowing_status_guide.json"))
            tasks.extend(gm.get_guide_async(GuideManager.get_volume_file_name("location_state_guide.json", v)) for v in loc_vols)
            tasks.extend(gm.get_guide_async(GuideManager.get_volume_file_name("faction_state_guide.json", v)) for v in fac_vols)
            tasks.extend(gm.get_guide_async(GuideManager.get_volume_file_name("pledge_constraint_guide.json", v)) for v in pledge_vols)
            tasks.extend(gm.get_guide_async(GuideManager.get_volume_file_name("deadline_constraint_guide.json", v)) for v in deadline_vols)
            tasks.extend(gm.get_guide_async(GuideManager.get_volume_file_name("secret_reveal_guide.json", v)) for v in secret_vols)

            results = await asyncio.gather(*tasks, return_exceptions=True)

            idx = 0
            for v in char_vols:
                g = results[idx]; idx += 1
                if isinstance(g, Exception): continue
                for eid, entry in g.get("Characters", {}).items():
                    if entry.get("Name"):
                        name_map[eid] = entry["Name"]

            for v in conf_vols:
                g = results[idx]; idx += 1
                if isinstance(g, Exception): continue
                for eid, entry in g.get("Conflicts", {}).items():
                    if entry.get("Name"):
                        name_map[eid] = entry["Name"]

            g = results[idx]; idx += 1
            if not isinstance(g, Exception):
                for eid, entry in g.get("Foreshadowings", {}).items():
                    if entry.get("Name"):
                        name_map[eid] = entry["Name"]

            for v in loc_vols:
                g = results[idx]; idx += 1
                if isinstance(g, Exception): continue
                for eid, entry in g.get("Locations", {}).items():
                    if entry.get("Name"):
                        name_map[eid] = entry["Name"]

            for v in fac_vols:
                g = results[idx]; idx += 1
                if isinstance(g, Exception): continue
                for eid, entry in g.get("Factions", {}).items():
                    if entry.get("Name"):
                        name_map[eid] = entry["Name"]

            for v in pledge_vols:
                g = results[idx]; idx += 1
                if isinstance(g, Exception): continue
                for eid, entry in g.get("Pledges", {}).items():
                    if entry.get("Name"):
                        name_map[eid] = entry["Name"]

            for v in deadline_vols:
                g = results[idx]; idx += 1
                if isinstance(g, Exception): continue
                for eid, entry in g.get("Deadlines", {}).items():
                    if entry.get("Name"):
                        name_map[eid] = entry["Name"]

            for v in secret_vols:
                g = results[idx]; idx += 1
                if isinstance(g, Exception): continue
                for eid, entry in g.get("Secrets", {}).items():
                    if entry.get("Name"):
                        name_map[eid] = entry["Name"]
        except Exception as ex:
            self._log(f"[ContentCallback] BuildEntityNameMapAsync失败，将回退到ID: {ex}")

        self._name_map_cache = (name_map, time.time() + 60)
        return name_map

    # ================= Vector Index =================

    async def _rebuild_vector_indices_for_chapter_async(
        self,
        chapter_id: str,
        persisted_content: str,
        changes: Optional[Any],
        name_map: Optional[Dict[str, str]],
        carry_over_entity_ids: Optional[List[str]] = None,
    ):
        """对标 RebuildVectorIndicesForChapterAsync"""
        if not chapter_id:
            return

        try:
            emb = self._get_micro_embedding_service()
            if not emb.is_model_ready():
                self._log(f"[ContentCallback] {chapter_id} 向量模型未就绪，跳过三层索引建设（对账阶段补建）")
                return

            chapter_idx = self._get_chapter_embedding_index()
            chunk_idx = self._get_chunk_embedding_index()
            first_idx = self._get_entity_first_chapter_index()

            import asyncio
            await asyncio.gather(chapter_idx.load_async(), chunk_idx.load_async(), first_idx.load_async())

            try:
                max_chars = self._get_embedding_max_chars()
                head = persisted_content[:max_chars] if len(persisted_content) > max_chars else persisted_content
                if head.strip():
                    vec = await emb.encode_async(head, EmbeddingMode.PASSAGE)
                    if self._is_zero_vector(vec):
                        self._log(f"[ContentCallback] {chapter_id} 章节级 Encode 返回零向量（模型异常），跳过 Upsert（对账兜底）")
                    else:
                        await chapter_idx.upsert_async(chapter_id, vec)
            except Exception as ex:
                self._log(f"[ContentCallback] {chapter_id} 章节级向量建设失败（非致命）: {ex}")

            try:
                chunk_svc = self._get_content_chunk_search_service()
                await chunk_svc.invalidate_chapter_async(chapter_id)
                chunks = await chunk_svc.get_chunks_async(chapter_id)
                await chunk_idx.remove_by_chapter_async(chapter_id)
                if chunks:
                    texts = [c["Content"] for c in chunks]
                    vecs = await emb.encode_batch_async(texts, EmbeddingMode.PASSAGE)
                    if len(vecs) == len(chunks):
                        batch = []
                        zero_count = 0
                        for i, c in enumerate(chunks):
                            if self._is_zero_vector(vecs[i]):
                                zero_count += 1
                                continue
                            batch.append((ChunkKey.format(chunks[i]["ChapterId"], chunks[i]["Position"]), vecs[i]))
                        if zero_count > 0:
                            self._log(f"[ContentCallback] {chapter_id} 段落级 {zero_count}/{len(chunks)} 条零向量已过滤（模型异常，对账兜底）")
                        if batch:
                            await chunk_idx.upsert_batch_async(batch)
            except Exception as ex:
                self._log(f"[ContentCallback] {chapter_id} 段落级向量建设失败（非致命）: {ex}")

            # First chapter index
            try:
                if changes and changes.get("CharacterStateChanges"):
                    design_id_to_name = None
                    for cc in changes["CharacterStateChanges"]:
                        cid = cc.get("CharacterId")
                        if not cid:
                            continue
                        if first_idx.contains(cid):
                            continue
                        name = ""
                        if name_map and cid in name_map:
                            name = name_map[cid]
                        if not name:
                            if design_id_to_name is None:
                                design_id_to_name = ContentGenerationCallback._build_design_character_map()
                            if cid in design_id_to_name:
                                name = design_id_to_name[cid]["Name"]
                        if not name:
                            continue
                        await first_idx.try_capture_async(cid, name, "", chapter_id)

                if changes and carry_over_entity_ids:
                    declared_ids = set(
                        c["CharacterId"] for c in (changes.get("CharacterStateChanges") or [])
                        if c.get("CharacterId")
                    )
                    pending_carry = list(set(
                        eid for eid in carry_over_entity_ids
                        if eid and eid not in declared_ids and not first_idx.contains(eid)
                    ))
                    if pending_carry:
                        combined = await self._build_combined_character_map_async(chapter_id)
                        compensated = 0
                        for eid in pending_carry:
                            if eid not in combined:
                                continue
                            entry = combined[eid]
                            if not entry["Name"]:
                                continue
                            try:
                                if await first_idx.rebuild_async(eid, entry["Name"], entry["Identity"]):
                                    compensated += 1
                            except Exception as rebuild_ex:
                                self._log(f"[ContentCallback] {chapter_id} 重写补偿 Rebuild {eid} 失败（非致命）: {rebuild_ex}")
                        if compensated > 0:
                            self._log(f"[ContentCallback] {chapter_id} 重写路径补偿重建 {compensated}/{len(pending_carry)} 个 carry-over 角色首次描写")

                if changes is None:
                    affected = [
                        e["EntityId"] for e in first_idx.get_all()
                        if e.get("ChapterId", "").lower() == chapter_id.lower()
                    ]
                    if affected:
                        combined = await self._build_combined_character_map_async(chapter_id)
                        refreshed = 0
                        for eid in affected:
                            if eid not in combined:
                                continue
                            entry = combined[eid]
                            if not entry["Name"]:
                                continue
                            try:
                                if await first_idx.rebuild_async(eid, entry["Name"], entry["Identity"]):
                                    refreshed += 1
                            except Exception as rebuild_ex:
                                self._log(f"[ContentCallback] {chapter_id} 静默保存 Rebuild {eid} 失败（非致命）: {rebuild_ex}")
                        if refreshed > 0:
                            self._log(f"[ContentCallback] {chapter_id} 静默保存后刷新 {refreshed}/{len(affected)} 个角色的首次描写位置")
            except Exception as ex:
                self._log(f"[ContentCallback] {chapter_id} 首次描写捕获失败（非致命）: {ex}")

            import asyncio
            await asyncio.gather(
                chapter_idx.save_async(), chunk_idx.save_async(), first_idx.save_async(),
            )

            self._log(f"[ContentCallback] {chapter_id} 向量索引建设完成")
        except Exception as ex:
            self._log(f"[ContentCallback] {chapter_id} 向量索引建设异常（已吞，对账阶段补建）: {ex}")

    async def _rebuild_vector_indices_after_repair_async(
        self, chapter_id: str, changes: Any, carry_over_entity_ids: Optional[List[str]] = None,
    ):
        """对标 RebuildVectorIndicesAfterRepairAsync"""
        try:
            chapters_path = self._get_chapters_path()
            md_path = os.path.join(chapters_path, f"{chapter_id}.md")
            if not os.path.exists(md_path):
                self._log(f"[ContentCallback] {chapter_id} md 缺失，跳过向量重建（对账兜底）")
                return
            with open(md_path, "r", encoding="utf-8") as f:
                persisted_content = f.read()
            if not persisted_content.strip():
                self._log(f"[ContentCallback] {chapter_id} md 为空，跳过向量重建")
                return
            name_map = await self._build_entity_name_map_async() if changes is not None else None
            await self._rebuild_vector_indices_for_chapter_async(
                chapter_id, persisted_content, changes, name_map, carry_over_entity_ids,
            )
            self._log(f"[ContentCallback] {chapter_id} WAL/重建后向量索引补齐完成")
        except Exception as ex:
            self._log(f"[ContentCallback] {chapter_id} WAL/重建后向量补齐失败（非致命，对账兜底）: {ex}")

    async def _clean_vector_indices_async(self, chapter_id: str):
        """对标 CleanVectorIndicesAsync"""
        if not chapter_id:
            return
        try:
            chapter_idx = self._get_chapter_embedding_index()
            chunk_idx = self._get_chunk_embedding_index()
            first_idx = self._get_entity_first_chapter_index()

            import asyncio
            await asyncio.gather(chapter_idx.load_async(), chunk_idx.load_async(), first_idx.load_async())

            await asyncio.gather(
                chapter_idx.remove_async(chapter_id),
                chunk_idx.remove_by_chapter_async(chapter_id),
                first_idx.invalidate_by_chapter_async(chapter_id),
            )

            await asyncio.gather(
                chapter_idx.save_async(), chunk_idx.save_async(), first_idx.save_async(),
            )

            try:
                chunk_svc = self._get_content_chunk_search_service()
                await chunk_svc.invalidate_chapter_async(chapter_id)
            except Exception as lru_ex:
                self._log(f"[ContentCallback] {chapter_id} 失效 ContentChunkSearch LRU 失败（非致命）: {lru_ex}")

            self._log(f"[ContentCallback] {chapter_id} 向量索引清理完成")
        except Exception as ex:
            self._log(f"[ContentCallback] {chapter_id} 向量索引清理失败（非致命，下次对账补齐）: {ex}")

    @staticmethod
    def _is_zero_vector(vec: Optional[List[float]]) -> bool:
        if not vec:
            return True
        return all(v == 0.0 for v in vec)

    @staticmethod
    def _build_design_character_map() -> Dict[str, Dict[str, str]]:
        """对标 BuildDesignCharacterMap"""
        result: Dict[str, Dict[str, str]] = {}
        try:
            cr_svc = ServiceLocator.get("CharacterRulesService")
            for c in cr_svc.get_all_character_rules():
                if not c.get("Id") or not c.get("Name"):
                    continue
                result[c["Id"]] = {"Name": c["Name"], "Identity": c.get("Identity", "")}
        except Exception as ex:
            pass
        return result

    async def _build_combined_character_map_async(self, chapter_id: str) -> Dict[str, Dict[str, str]]:
        """对标 BuildCombinedCharacterMapAsync"""
        combined = dict(ContentGenerationCallback._build_design_character_map())
        try:
            cs_vols = self._guide_manager.get_existing_volume_numbers("character_state_guide.json")
            for v in cs_vols:
                g = await self._guide_manager.get_guide_async(
                    GuideManager.get_volume_file_name("character_state_guide.json", v),
                )
                for eid, entry in g.get("Characters", {}).items():
                    if eid in combined:
                        continue
                    n = entry.get("Name", "")
                    if not n:
                        continue
                    combined[eid] = {"Name": n, "Identity": ""}
        except Exception as guide_ex:
            self._log(f"[ContentCallback] {chapter_id} 合并角色映射读 Guide 失败（非致命,仅用 Design）: {guide_ex}")
        return combined

    # ================= Persistence =================

    async def _normalize_persisted_content_async(self, chapter_id: str, content: str) -> str:
        """对标 NormalizePersistedContentAsync"""
        normalized_body = self._strip_leading_headings(content)
        normalized_body = ContentCleanHelper.strip_model_artifacts(normalized_body)
        normalized_body = self._strip_leading_headings(normalized_body)

        packaged_title = await self._get_packaged_chapter_title_strict_async(chapter_id)
        canonical_title = self._build_canonical_title(chapter_id, packaged_title)
        if not normalized_body.strip():
            return f"# {canonical_title}"
        return f"# {canonical_title}\n\n{normalized_body}"

    @staticmethod
    async def _get_packaged_chapter_title_strict_async(chapter_id: str) -> str:
        """对标 GetPackagedChapterTitleStrictAsync"""
        try:
            guide_service = ServiceLocator.get("GuideContextService")
            guide = await guide_service.get_content_guide_async()
            if guide and guide.get("Chapters") and chapter_id in guide["Chapters"]:
                entry = guide["Chapters"][chapter_id]
                if entry.get("Title"):
                    return ChapterParserHelper.normalize_chapter_title(entry["Title"].strip())
        except Exception as ex:
            pass
        return ""

    @staticmethod
    def _build_canonical_title(chapter_id: str, title: str) -> str:
        parsed = ContentGenerationCallback._parse_chapter_id(chapter_id)
        chapter_num = parsed["chapter_number"] if parsed else 0
        if chapter_num > 0:
            return f"第{chapter_num}章 {title}" if title else f"第{chapter_num}章"
        return title if title else chapter_id

    @staticmethod
    def _strip_leading_headings(content: str) -> str:
        """对标 StripLeadingHeadings"""
        if not content:
            return ""
        import re
        chapter_title_re = re.compile(
            r"^第[一二三四五六七八九十百千万零壹贰叁肆伍陆柒捌玖拾佰仟萬两〇\d]+\s*(?:章节|章)(?:[:：、.\s\u3000]|$)"
        )
        text = content.strip()
        while text:
            first_line_end = text.find("\n")
            first_line = (text[:first_line_end] if first_line_end >= 0 else text).strip()
            is_heading = first_line.startswith("#") or bool(chapter_title_re.match(first_line))
            if not is_heading:
                break
            text = text[first_line_end + 1:].strip() if first_line_end >= 0 else ""
        return text.strip()

    @staticmethod
    def _parse_chapter_id(chapter_id: str) -> Optional[Dict]:
        """对标 ChapterParserHelper.ParseChapterId"""
        try:
            parts = chapter_id.split("_")
            if len(parts) >= 2:
                return {"volume_number": int(parts[0]), "chapter_number": int(parts[1])}
        except (ValueError, IndexError):
            pass
        return None

    # ================= Service Locator Helpers =================

    def _get_guide_context_service(self):
        return ServiceLocator.get("GuideContextService")

    def _get_keyword_chapter_index_service(self):
        return ServiceLocator.get("KeywordChapterIndexService")

    def _get_entity_first_chapter_index(self):
        return ServiceLocator.get("EntityFirstChapterIndex")

    def _get_chapter_embedding_index(self):
        return ServiceLocator.get("ChapterEmbeddingIndex")

    def _get_chunk_embedding_index(self):
        return ServiceLocator.get("ChunkEmbeddingIndex")

    def _get_micro_embedding_service(self):
        return ServiceLocator.get("MicroEmbeddingService")

    def _get_content_chunk_search_service(self):
        return ServiceLocator.get("ContentChunkSearchService")

    def _get_volume_fact_archive_store(self):
        return ServiceLocator.get("VolumeFactArchiveStore")

    def _get_layered_context_config(self) -> dict:
        return {}

    def _get_chapters_path(self) -> str:
        return StoragePathHelper.get_project_chapters_path()

    def _invalidate_relation_strength_cache(self):
        try:
            svc = ServiceLocator.get("RelationStrengthService")
            if svc:
                svc.invalidate_cache()
        except Exception:
            pass

    @staticmethod
    def _log(msg: str):
        print(msg)

    @staticmethod
    def _report_phase(phase: str, message: str):
        print(f"[{phase}] {message}")


class StoragePathHelper:
    """对标 StoragePathHelper"""
    current_project_name: Optional[str] = None

    @staticmethod
    def get_storage_root() -> str:
        return ""

    @staticmethod
    def get_project_chapters_path() -> str:
        return ""


class ContentCleanHelper:
    """对标 ContentCleanHelper"""

    @staticmethod
    def strip_model_artifacts(content: str) -> str:
        return content


class ChapterParserHelper:
    """对标 ChapterParserHelper"""

    @staticmethod
    def normalize_chapter_title(title: str) -> str:
        return title

    @staticmethod
    def parse_chapter_id(chapter_id: str):
        return ContentGenerationCallback._parse_chapter_id(chapter_id)


class EmbeddingMode:
    PASSAGE = "passage"
    QUERY = "query"


class ChunkKey:
    @staticmethod
    def format(chapter_id: str, position: int) -> str:
        return f"{chapter_id}:{position}"


class ServiceLocator:
    """对标 ServiceLocator — 简易服务定位器"""

    _services: Dict[str, Any] = {}

    @classmethod
    def register(cls, key: str, service: Any):
        cls._services[key] = service

    @classmethod
    def get(cls, key: str) -> Any:
        return cls._services.get(key)