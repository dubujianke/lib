# -*- coding: utf-8 -*-
"""Guide 索引构建器 — 对标 Implementations/Guides/GuideIndexBuilder.cs（partial 4 文件）

核心：打包时构建 Design/Generate/Tracking guide 的索引 + 校验
"""
from typing import List, Optional


class GuideIndexBuilder:
    def __init__(self, project, is_module_enabled=None):
        self.project = project
        self._is_module_enabled = is_module_enabled
        self._load_cache = {}

    def _load_design(self, entity: str) -> list:
        data = self.project.load_design(entity)
        if isinstance(data, dict):
            return data.get("items", [])
        return data or []

    def _load_plan(self, entity: str) -> list:
        data = self.project.load_plan(entity)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return data.get(entity, data.get("items", []))
        return []

    def ensure_required_ids(self, items, id_selector, label, name_selector=None) -> None:
        """对标 EnsureRequiredIds"""
        missing = [name_selector(item) if name_selector else "<unknown>"
                   for item in items if not id_selector(item)]
        if missing:
            raise ValueError(f"打包失败：{label} 缺失Id -> {'、'.join(set(missing))}")

    def build_character_index(self) -> dict:
        """构建角色索引（Name -> Id）"""
        chars = self._load_design("characters")
        return {c.get("Name", ""): c.get("Id", "") for c in chars if c.get("Id")}

    def build_location_index(self) -> dict:
        locs = self._load_design("locations")
        return {l.get("Name", ""): l.get("Id", "") for l in locs if l.get("Id")}

    def build_faction_index(self) -> dict:
        facs = self._load_design("factions")
        return {f.get("Name", ""): f.get("Id", "") for f in facs if f.get("Id")}

    def build_plot_index(self) -> dict:
        plots = self._load_design("plot")
        return {p.get("Name", ""): p.get("Id", "") for p in plots if p.get("Id")}

    def build_world_index(self) -> dict:
        worlds = self._load_design("world")
        return {w.get("Name", ""): w.get("Id", "") for w in worlds if w.get("Id")}

    def validate_plot_rules(self, plot_rules: List[dict]) -> List[str]:
        """对标 GuideIndexBuilder.PlotValidation.cs"""
        errors = []
        for p in plot_rules:
            if not p.get("Id"):
                errors.append(f"剧情规则缺失 Id: {p.get('Name', '<unknown>')}")
        return errors
