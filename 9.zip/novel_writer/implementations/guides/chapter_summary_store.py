# -*- coding: utf-8 -*-
"""章节摘要存储 — 对标 Implementations/Guides/ChapterSummaryStore.cs"""
import json
import os
import threading
from typing import Dict, List


class ChapterSummaryStore:
    SUMMARY_GUARD_MAX_CHARS = 1500

    def __init__(self, project):
        self.project = project
        self._volume_cache: Dict[int, Dict[str, str]] = {}
        self._write_lock = threading.Lock()

    def _summaries_dir(self) -> str:
        return os.path.join(self.project.dir, "guides", "summaries")

    def _volume_path(self, volume_number: int) -> str:
        return os.path.join(self._summaries_dir(), f"vol{volume_number}.json")

    @staticmethod
    def _volume_number(chapter_id: str) -> int:
        from ...character_state_service import parse_chapter_id
        vol, _ = parse_chapter_id(chapter_id)
        return vol or 1

    def _load_volume(self, volume_number: int) -> Dict[str, str]:
        if volume_number in self._volume_cache:
            return self._volume_cache[volume_number]
        path = self._volume_path(volume_number)
        if not os.path.exists(path):
            return {}
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self._volume_cache[volume_number] = data
            return data
        except Exception:
            return {}

    def _save_volume(self, volume_number: int, summaries: Dict[str, str]):
        dir_path = self._summaries_dir()
        os.makedirs(dir_path, exist_ok=True)
        path = self._volume_path(volume_number)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(summaries, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
        self._volume_cache[volume_number] = summaries

    def set_summary(self, chapter_id: str, summary: str):
        if summary and len(summary) > self.SUMMARY_GUARD_MAX_CHARS:
            summary = summary[:self.SUMMARY_GUARD_MAX_CHARS] + "..."
        vol = self._volume_number(chapter_id)
        with self._write_lock:
            existing = self._load_volume(vol)
            existing[chapter_id] = summary or ""
            self._save_volume(vol, existing)

    def remove_summary(self, chapter_id: str):
        vol = self._volume_number(chapter_id)
        with self._write_lock:
            existing = self._load_volume(vol)
            if chapter_id in existing:
                existing.pop(chapter_id)
                self._save_volume(vol, existing)

    def get_summary(self, chapter_id: str) -> str:
        vol = self._volume_number(chapter_id)
        return self._load_volume(vol).get(chapter_id, "")

    def get_volume_summaries(self, volume_number: int) -> Dict[str, str]:
        return dict(self._load_volume(volume_number))

    def get_all_summaries(self) -> Dict[str, str]:
        dir_path = self._summaries_dir()
        result = {}
        if not os.path.exists(dir_path):
            return result
        for f in os.listdir(dir_path):
            if not f.startswith("vol") or not f.endswith(".json"):
                continue
            vol = int(f[3:-5]) if f[3:-5].isdigit() else 0
            if vol:
                for k, v in self._load_volume(vol).items():
                    result.setdefault(k, v)
        return result

    def invalidate_cache(self):
        self._volume_cache.clear()

    def bulk_set(self, summaries: Dict[str, str]):
        if not summaries:
            return
        with self._write_lock:
            by_volume: Dict[int, Dict[str, str]] = {}
            for k, v in summaries.items():
                vol = self._volume_number(k)
                by_volume.setdefault(vol, {})[k] = v
            for vol, vol_summaries in by_volume.items():
                self._save_volume(vol, vol_summaries)
