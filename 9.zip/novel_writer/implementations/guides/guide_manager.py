# -*- coding: utf-8 -*-
"""Guide 管理器 — 对标 Implementations/Guides/GuideManager.cs（缓存 + 原子刷盘）"""
import json
import os
import threading
from typing import Dict, List


class GuideManager:
    FLUSH_THRESHOLD = 10
    COMMIT_MARKER = "_commit"
    MAX_CLEAN_CACHE_ENTRIES = 1000

    def __init__(self, project):
        self.project = project
        self._lock = threading.Lock()
        self._cache: Dict[str, object] = {}
        self._dirty_files = set()
        self._change_count = 0
        self._cache_access_order: Dict[str, int] = {}
        self._access_counter = 0
        self._save_lock = threading.Lock()
        self._loading_tasks: Dict[str, object] = {}
        self._cache_epoch = 0

    # ---- 实体变更事件 ----
    def raise_entry_changed(self, entity_id: str, entity_name: str, entity_description: str):
        pass

    # ---- 公开方法 ----

    def get_guide(self, file_name: str, guide_cls=None):
        """对标 GetGuideAsync<T>"""
        with self._lock:
            if file_name in self._cache:
                self._cache_access_order[file_name] = self._access_counter + 1
                self._access_counter += 1
                return self._cache[file_name]
        guide = self._load_from_file(file_name, guide_cls)
        with self._lock:
            self._cache[file_name] = guide
            self._access_counter += 1
            self._cache_access_order[file_name] = self._access_counter
        return guide

    def mark_dirty(self, file_name: str):
        with self._lock:
            self._dirty_files.add(file_name)
            self._change_count += 1

    def should_flush(self) -> bool:
        with self._lock:
            return self._change_count >= self.FLUSH_THRESHOLD

    def flush_all(self):
        with self._save_lock:
            self._flush_all_internal()

    def _flush_all_internal(self):
        with self._lock:
            if not self._dirty_files:
                return
            to_save = [(f, self._cache[f]) for f in self._dirty_files if f in self._cache]
            self._dirty_files.clear()

        guides_dir = self._guides_dir()
        os.makedirs(guides_dir, exist_ok=True)
        staging_dir = self._staging_dir(guides_dir)

        try:
            if os.path.exists(staging_dir):
                import shutil
                shutil.rmtree(staging_dir)
            os.makedirs(staging_dir)
            for file_name, guide in to_save:
                staging_path = os.path.join(staging_dir, file_name)
                with open(staging_path, "w", encoding="utf-8") as f:
                    if hasattr(guide, "to_dict"):
                        json.dump(guide.to_dict(), f, ensure_ascii=False, indent=2)
                    else:
                        json.dump(guide, f, ensure_ascii=False, indent=2)
            # 提交标记
            with open(os.path.join(staging_dir, self.COMMIT_MARKER), "w", encoding="utf-8") as f:
                f.write("ok")
            self._commit_staging_files(staging_dir, guides_dir)
        except Exception:
            with self._lock:
                for file_name, _ in to_save:
                    self._dirty_files.add(file_name)
            raise

        with self._lock:
            if not self._dirty_files:
                self._change_count = 0

    def recover_pending_flush(self):
        try:
            guides_dir = self._guides_dir()
            if not os.path.exists(guides_dir):
                return
            staging_dir = self._staging_dir(guides_dir)
            if not os.path.exists(staging_dir):
                return
            commit_marker = os.path.join(staging_dir, self.COMMIT_MARKER)
            if not os.path.exists(commit_marker):
                import shutil
                shutil.rmtree(staging_dir)
                return
            self._commit_staging_files(staging_dir, guides_dir)
        except Exception:
            pass

    def clear_cache(self):
        with self._lock:
            self._cache_epoch += 1
            self._cache.clear()
            self._cache_access_order.clear()
            self._loading_tasks.clear()
            self._dirty_files.clear()
            self._change_count = 0

    def discard_dirty_and_evict(self):
        with self._lock:
            self._cache_epoch += 1
            for key in list(self._dirty_files):
                self._cache.pop(key, None)
                self._cache_access_order.pop(key, None)
                self._loading_tasks.pop(key, None)
            self._dirty_files.clear()
            self._change_count = 0

    def get_stats(self):
        with self._lock:
            return (len(self._cache), len(self._dirty_files), self._change_count)

    @staticmethod
    def get_volume_file_name(base_file_name: str, volume_number: int) -> str:
        name, ext = os.path.splitext(base_file_name)
        return f"{name}_vol{volume_number}{ext}"

    def get_existing_volume_numbers(self, base_file_name: str) -> List[int]:
        guides_dir = self._guides_dir()
        if not os.path.exists(guides_dir):
            return []
        prefix = os.path.splitext(base_file_name)[0] + "_vol"
        result = []
        for f in os.listdir(guides_dir):
            if f.startswith(prefix) and f.endswith(".json"):
                num = f[len(prefix):-5]
                if num.isdigit():
                    result.append(int(num))
        result.sort()
        return result

    # ---- 私有方法 ----

    def _guides_dir(self) -> str:
        return os.path.join(self.project.dir, "guides")

    def _staging_dir(self, guides_dir: str) -> str:
        return os.path.join(guides_dir, ".flush_staging")

    def _load_from_file(self, file_name: str, guide_cls):
        path = os.path.join(self._guides_dir(), file_name)
        if not os.path.exists(path):
            return guide_cls() if guide_cls else {}
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if guide_cls and hasattr(guide_cls, "from_dict"):
                return guide_cls.from_dict(data)
            return data
        except Exception:
            return guide_cls() if guide_cls else {}

    def _commit_staging_files(self, staging_dir: str, guides_dir: str):
        os.makedirs(guides_dir, exist_ok=True)
        for f in os.listdir(staging_dir):
            if f.endswith(".json"):
                os.replace(os.path.join(staging_dir, f), os.path.join(guides_dir, f))
        import shutil
        shutil.rmtree(staging_dir, ignore_errors=True)
