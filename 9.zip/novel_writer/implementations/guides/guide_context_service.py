# -*- coding: utf-8 -*-
"""Guide 上下文服务 — 对标 Implementations/Guides/GuideContextService.cs（partial 8 文件）

核心：设计数据缓存 + 按 ID/全量抽取 + ContextIds 校验 + 事实快照抽取
"""
import os
import threading
from typing import Dict, List, Optional

from ...models.guides.context_id_collection import ContextIdCollection, ContextIdValidationResult
from ...models.context.expansion_config import ExpansionConfig
from ...ledger_config import LedgerConfig
from ...snapshot_config import SnapshotConfig


class LayeredContextConfig:
    """对标 LayeredContextConfig（聚合 Ledger + Snapshot 配置）"""

    def __init__(self, ledger_config=None, snapshot_config=None):
        self.ledger = ledger_config or LedgerConfig()
        self.snapshot = snapshot_config or SnapshotConfig()
        self.DriftWarningsMaxPerEntity = 100000
        self.DriftEscalateThreshold = 3
        self.DriftMinNameLength = 2
        self.PledgeMaxDanglingChapters = 100
        self.DeadlineMaxDanglingChapters = 50
        self.MilestoneAnchorInterval = 8
        self.VolumeMilestoneMaxChars = 20000
        self.MilestoneMaxPreviousVolumes = 12
        self.ArchiveMaxPreviousVolumes = 8

    def take_snapshot(self):
        return self


class GuideContextService:
    def __init__(self, project, fact_snapshot_extractor=None, summary_store=None, milestone_store=None):
        self.project = project
        self._fact_snapshot_extractor = fact_snapshot_extractor
        self._summary_store = summary_store
        self._milestone_store = milestone_store
        # 缓存
        self._character_cache: Dict[str, dict] = {}
        self._location_cache: Dict[str, dict] = {}
        self._plot_rules_cache: Dict[str, dict] = {}
        self._faction_cache: Dict[str, dict] = {}
        self._template_cache: Dict[str, dict] = {}
        self._world_rules_cache: Dict[str, dict] = {}
        self._volume_cache: Dict[str, dict] = {}
        self._chapter_plan_cache: Dict[str, dict] = {}
        self._blueprint_cache: Dict[str, dict] = {}
        self._volume_design_cache: Dict[str, dict] = {}
        self._cache_initialized = False
        self._cache_lock = threading.Lock()
        self._expansion_config = None

    # ---- 缓存初始化 ----

    def initialize_cache(self):
        if self._cache_initialized:
            return
        with self._cache_lock:
            if self._cache_initialized:
                return
            self._load_all_caches()
            self._cache_initialized = True

    def _load_all_caches(self):
        for entity, cache, key_field in [
            ("characters", self._character_cache, "Id"),
            ("locations", self._location_cache, "Id"),
            ("plot", self._plot_rules_cache, "Id"),
            ("factions", self._faction_cache, "Id"),
            ("materials", self._template_cache, "Id"),
            ("world", self._world_rules_cache, "Id"),
        ]:
            data = self.project.load_design(entity)
            items = data.get("items", []) if isinstance(data, dict) else (data or [])
            for item in items:
                if isinstance(item, dict) and item.get("Id"):
                    cache[item["Id"]] = item

        # 规划数据
        chapters = self._load_plan("chapters")
        for ch in chapters:
            if ch.get("Id"):
                self._chapter_plan_cache[ch["Id"]] = ch
        volumes = self._load_plan("volumes")
        for v in volumes:
            if v.get("Id"):
                self._volume_design_cache[v["Id"]] = v
            vn = v.get("VolumeNumber", 0)
            if vn and v.get("Id"):
                self._volume_cache[v["Id"]] = v

    def _load_plan(self, entity: str) -> list:
        data = self.project.load_plan(entity)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return data.get(entity, data.get("items", []))
        return []

    def clear_cache(self):
        with self._cache_lock:
            self._character_cache.clear()
            self._location_cache.clear()
            self._plot_rules_cache.clear()
            self._faction_cache.clear()
            self._template_cache.clear()
            self._world_rules_cache.clear()
            self._volume_cache.clear()
            self._chapter_plan_cache.clear()
            self._blueprint_cache.clear()
            self._volume_design_cache.clear()
            self._cache_initialized = False

    # ---- 抽取 ----

    def extract_characters(self, ids: List[str]) -> list:
        self.initialize_cache()
        return [self._character_cache[i] for i in ids if i in self._character_cache]

    def get_all_characters(self) -> list:
        self.initialize_cache()
        return list(self._character_cache.values())

    def extract_locations(self, ids: List[str]) -> list:
        self.initialize_cache()
        return [self._location_cache[i] for i in ids if i in self._location_cache]

    def get_all_locations(self) -> list:
        self.initialize_cache()
        return list(self._location_cache.values())

    def extract_plot_rules(self, ids: List[str]) -> list:
        self.initialize_cache()
        return [self._plot_rules_cache[i] for i in ids if i in self._plot_rules_cache]

    def get_all_plot_rules(self) -> list:
        self.initialize_cache()
        return list(self._plot_rules_cache.values())

    def extract_factions(self, ids: List[str]) -> list:
        self.initialize_cache()
        return [self._faction_cache[i] for i in ids if i in self._faction_cache]

    def get_all_factions(self) -> list:
        self.initialize_cache()
        return list(self._faction_cache.values())

    def extract_templates(self, ids: List[str]) -> list:
        self.initialize_cache()
        return [self._template_cache[i] for i in ids if i in self._template_cache]

    def get_all_templates(self) -> list:
        self.initialize_cache()
        return list(self._template_cache.values())

    def extract_world_rules(self, ids: List[str]) -> list:
        self.initialize_cache()
        return [self._world_rules_cache[i] for i in ids if i in self._world_rules_cache]

    def get_all_world_rules(self) -> list:
        self.initialize_cache()
        return list(self._world_rules_cache.values())

    # ---- ContextIds 校验 ----

    def validate_context_ids(self, context_ids: Optional[ContextIdCollection]) -> ContextIdValidationResult:
        if context_ids is None:
            return ContextIdValidationResult.success()
        self.initialize_cache()
        missing: Dict[str, List[str]] = {}
        checks = [
            ("Characters", context_ids.Characters, self._character_cache),
            ("Locations", context_ids.Locations, self._location_cache),
            ("Factions", context_ids.Factions, self._faction_cache),
            ("PlotRules", context_ids.PlotRules, self._plot_rules_cache),
            ("TemplateIds", context_ids.TemplateIds, self._template_cache),
            ("WorldRuleIds", context_ids.WorldRuleIds, self._world_rules_cache),
        ]
        for name, ids, cache in checks:
            if ids:
                miss = [i for i in ids if i not in cache]
                if miss:
                    missing[name] = miss
        if context_ids.ChapterPlanId and context_ids.ChapterPlanId not in self._chapter_plan_cache:
            missing["ChapterPlanId"] = [context_ids.ChapterPlanId]
        if missing:
            return ContextIdValidationResult.failed(missing)
        return ContextIdValidationResult.success()

    # ---- 事实快照 ----

    def extract_fact_snapshot_for_chapter(self, chapter_id: str, context_ids: ContextIdCollection):
        if self._fact_snapshot_extractor:
            return self._fact_snapshot_extractor.extract(chapter_id, 0)
        return None

    def get_volume_max_chapter(self, volume_number: int) -> int:
        chapters = self._load_plan("chapters")
        max_chapter = 0
        for ch in chapters:
            if ch.get("VolumeNumber", 0) == volume_number:
                max_chapter = max(max_chapter, ch.get("ChapterNumber", 0))
        return max_chapter
