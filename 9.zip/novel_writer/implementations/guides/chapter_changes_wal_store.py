# -*- coding: utf-8 -*-
"""章节 CHANGES WAL 存储 — 对标 Implementations/Guides/ChapterChangesWalStore.cs"""
import json
import os
from typing import List, Optional


class ChapterChangesWalStore:
    def __init__(self, project):
        self.project = project

    def _wal_dir(self) -> str:
        return os.path.join(self.project.dir, "guides", "changes_wal")

    def _file_path(self, chapter_id: str) -> str:
        return os.path.join(self._wal_dir(), f"{chapter_id}.json")

    def write(self, chapter_id: str, changes):
        try:
            os.makedirs(self._wal_dir(), exist_ok=True)
            path = self._file_path(chapter_id)
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(changes.to_dict(), f, ensure_ascii=False)
            os.replace(tmp, path)
        except Exception:
            pass

    def try_read(self, chapter_id: str):
        from ...models.tracking import ChapterChanges
        path = self._file_path(chapter_id)
        if not os.path.exists(path):
            return None
        try:
            with open(path, "r", encoding="utf-8") as f:
                return ChapterChanges.from_dict(json.load(f))
        except Exception:
            return None

    def delete(self, chapter_id: str):
        try:
            path = self._file_path(chapter_id)
            if os.path.exists(path):
                os.remove(path)
        except Exception:
            pass

    def get_all_chapter_ids(self) -> List[str]:
        try:
            if not os.path.exists(self._wal_dir()):
                return []
            return [f[:-5] for f in os.listdir(self._wal_dir()) if f.endswith(".json")]
        except Exception:
            return []

    def cleanup_orphan_tmp(self):
        try:
            if not os.path.exists(self._wal_dir()):
                return
            for f in os.listdir(self._wal_dir()):
                if f.endswith(".tmp"):
                    try:
                        os.remove(os.path.join(self._wal_dir(), f))
                    except Exception:
                        pass
        except Exception:
            pass
