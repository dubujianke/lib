# -*- coding: utf-8 -*-
"""里程碑浓缩器 — 对标 Implementations/Guides/MilestoneCondenser.cs"""
import os
from typing import Optional


class MilestoneCondenser:
    CONDENSE_THRESHOLD_CHARS = 10000
    CONDENSED_TARGET_CHARS = 3000

    def __init__(self, project):
        self.project = project

    def _milestones_dir(self) -> str:
        return os.path.join(self.project.dir, "guides", "milestones")

    def _condensed_path(self, volume_number: int) -> str:
        return os.path.join(self._milestones_dir(), f"vol{volume_number}_condensed.txt")

    def _original_path(self, volume_number: int) -> str:
        return os.path.join(self._milestones_dir(), f"vol{volume_number}.txt")

    def get_effective_file_path(self, volume_number: int) -> Optional:
        condensed = self._condensed_path(volume_number)
        return condensed if os.path.exists(condensed) else None

    def read_milestone(self, volume_number: int) -> str:
        condensed = self._condensed_path(volume_number)
        if os.path.exists(condensed):
            try:
                with open(condensed, "r", encoding="utf-8") as f:
                    return f.read()
            except Exception:
                pass
        original = self._original_path(volume_number)
        if os.path.exists(original):
            with open(original, "r", encoding="utf-8") as f:
                return f.read()
        return ""
