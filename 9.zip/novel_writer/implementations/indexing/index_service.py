# -*- coding: utf-8 -*-
"""索引服务 — 对标 Implementations/Indexing/IndexService.cs"""
from typing import Dict, List, Optional

from ...models.index.index_item import IndexItem
from ...models.index.upstream_index import UpstreamIndex

# 层级依赖（对标 C# LayerDependencies）
LAYER_DEPENDENCIES: Dict[str, List[str]] = {
    "SmartParsing": [],
    "Templates": ["SmartParsing"],
    "Worldview": ["Templates"],
    "Characters": ["Templates", "Worldview"],
    "Factions": ["Templates", "Worldview", "Characters"],
    "Locations": ["Templates", "Worldview", "Characters", "Factions"],
    "Plot": ["Templates", "Worldview", "Characters", "Factions", "Locations"],
    "Outline": ["Worldview", "Characters", "Factions", "Locations", "Plot"],
    "Planning": ["Worldview", "Characters", "Factions", "Locations", "Plot", "Outline"],
    "Blueprint": ["Worldview", "Characters", "Factions", "Locations", "Plot", "Outline", "Planning"],
    "Content": ["Worldview", "Characters", "Factions", "Locations", "Plot", "Outline", "Planning", "Blueprint"],
}

# 层级 → 设计/规划存储键（对标 C# LayerStoragePaths 的 Python 映射）
LAYER_STORAGE_KEYS: Dict[str, str] = {
    "SmartParsing": "materials",
    "Templates": "materials",
    "Worldview": "world",
    "Characters": "characters",
    "Factions": "factions",
    "Locations": "locations",
    "Plot": "plot",
    "Outline": "outline",
    "Planning": "chapters",
    "Blueprint": "blueprints",
}


class IndexService:
    UPSTREAM_INDEX_MAX_ITEMS_PER_LAYER = 200

    def __init__(self, project):
        self.project = project

    def build_upstream_index(self, target_layer: str) -> UpstreamIndex:
        index = UpstreamIndex()
        dependencies = LAYER_DEPENDENCIES.get(target_layer, [])
        for dep in dependencies:
            items = self._load_layer_items(dep, self.UPSTREAM_INDEX_MAX_ITEMS_PER_LAYER)
            index_items = [self.build_index_item(item) for item in items]
            self._set_index_property(index, dep, index_items)
        return index

    @staticmethod
    def build_index_item(item, use_deep_summary: bool = False) -> IndexItem:
        if isinstance(item, dict):
            return IndexItem(
                Id=item.get("Id", ""), Name=item.get("Name", ""),
                Type=item.get("Type", ""), BriefSummary=item.get("BriefSummary", ""),
                DeepSummary=item.get("DeepSummary", "") if use_deep_summary else "")
        return IndexItem(Id=getattr(item, "Id", ""), Name=getattr(item, "Name", ""),
                         Type="", BriefSummary="", DeepSummary="")

    def _load_layer_items(self, layer: str, max_items: int) -> List[dict]:
        if max_items <= 0:
            return []
        key = LAYER_STORAGE_KEYS.get(layer)
        if not key:
            return []
        try:
            data = self.project.load_design(key) if key in ("world", "characters", "factions", "locations", "plot", "materials") \
                else self.project.load_plan(key)
            items = data.get("items", []) if isinstance(data, dict) else (data or [])
            result = []
            for item in items[:max_items]:
                if isinstance(item, dict) and item.get("Id") and item.get("Name"):
                    result.append(self._convert_to_index_item(item, layer))
            return result
        except Exception:
            return []

    @staticmethod
    def _convert_to_index_item(data: dict, layer: str) -> dict:
        item_type = layer
        return {
            "Id": data.get("Id", ""),
            "Name": data.get("Name", ""),
            "Type": item_type,
            "BriefSummary": f"{data.get('Name', '')}({item_type})",
            "DeepSummary": data.get("OneLineSummary", "") or data.get("Goal", "") or "",
        }

    @staticmethod
    def _set_index_property(index: UpstreamIndex, layer: str, items: List[IndexItem]):
        mapping = {
            "SmartParsing": "SmartParsing", "Templates": "Templates", "Worldview": "Worldview",
            "Characters": "Characters", "Factions": "Factions", "Plot": "Plot",
            "Locations": "Locations", "Outline": "Outline", "Planning": "Planning",
            "Blueprint": "Blueprint",
        }
        attr = mapping.get(layer)
        if attr:
            setattr(index, attr, items)
