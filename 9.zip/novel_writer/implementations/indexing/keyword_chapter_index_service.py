# -*- coding: utf-8 -*-
from ...long_distance_recall import LongDistanceRecall as KeywordChapterIndexService
