# -*- coding: utf-8 -*-
"""焦点上下文服务 — 对标 Implementations/Context/FocusContextService.cs"""
import threading
import time
from typing import Dict, List, Optional

from ...models.context.focus_context import (
    FocusContext, DesignFocusContext, GenerateFocusContext,
)
from ...models.context.global_summary import GlobalSummary
from ...models.context.tracking_status import TrackingStatus


class FocusContextService:
    CONTEXT_CACHE_EXPIRY_SECONDS = 30

    def __init__(self, project, index_service=None, relation_strength_service=None,
                 guide_context_service=None, global_summary_service=None):
        self.project = project
        self._index_service = index_service
        self._relation_strength_service = relation_strength_service
        self._guide_context_service = guide_context_service
        self._global_summary_service = global_summary_service
        self._cache_lock = threading.Lock()
        self._design_context_cache: Dict[str, tuple] = {}
        self._generate_context_cache: Dict[str, tuple] = {}

    def get_design_context(self, focus_id: str, target_layer: str) -> DesignFocusContext:
        cache_key = f"Design|{target_layer}|{focus_id}"
        with self._cache_lock:
            cached = self._design_context_cache.get(cache_key)
            if cached and time.time() - cached[0] < self.CONTEXT_CACHE_EXPIRY_SECONDS:
                return cached[1]
        upstream = self._index_service.build_upstream_index(target_layer) if self._index_service else None
        focus = self._build_focus_context(focus_id, target_layer)
        focus.UpstreamIndex = upstream
        context = DesignFocusContext(
            GlobalSummary=self._get_global_summary(),
            TrackingStatus=self._get_tracking_status(),
            UpstreamIndex=upstream or (focus.UpstreamIndex if focus else None),
            Focus=focus)
        with self._cache_lock:
            self._design_context_cache[cache_key] = (time.time(), context)
        return context

    def get_generate_context(self, focus_id: str, target_layer: str) -> GenerateFocusContext:
        cache_key = f"Generate|{target_layer}|{focus_id}"
        with self._cache_lock:
            cached = self._generate_context_cache.get(cache_key)
            if cached and time.time() - cached[0] < self.CONTEXT_CACHE_EXPIRY_SECONDS:
                return cached[1]
        upstream = self._index_service.build_upstream_index(target_layer) if self._index_service else None
        focus = self._build_focus_context(focus_id, target_layer)
        focus.UpstreamIndex = upstream
        context = GenerateFocusContext(
            GlobalSummary=self._get_global_summary(),
            TrackingStatus=self._get_tracking_status(),
            UpstreamIndex=upstream,
            Focus=focus,
            TaskContext=None)
        with self._cache_lock:
            self._generate_context_cache[cache_key] = (time.time(), context)
        return context

    def _build_focus_context(self, focus_id: str, target_layer: str) -> FocusContext:
        focus = FocusContext(FocusId=focus_id, FocusType=target_layer, Layer=target_layer,
                             DirectRelations=[], IndirectRelations=[])
        if not focus_id:
            return focus
        # 通过关系强度服务填充
        if self._relation_strength_service and self._index_service:
            all_chars = self._get_all_character_ids()
            for char_id in all_chars:
                if char_id == focus_id:
                    continue
                strength = self._relation_strength_service.get_strength(focus_id, char_id)
                item = self._index_service.build_index_item({"Id": char_id, "Name": char_id, "Type": "角色"})
                if strength == 2 and len(focus.DirectRelations) < 5:  # Strong
                    item.RelationStrength = "Strong"
                    focus.DirectRelations.append(item)
                elif strength == 1 and len(focus.IndirectRelations) < 10:  # Medium
                    item.RelationStrength = "Medium"
                    focus.IndirectRelations.append(item)
        return focus

    def _get_all_character_ids(self) -> List[str]:
        try:
            data = self.project.load_design("characters")
            items = data.get("items", []) if isinstance(data, dict) else (data or [])
            return [c.get("Id", "") for c in items if c.get("Id")]
        except Exception:
            return []

    def _get_global_summary(self) -> GlobalSummary:
        if self._global_summary_service:
            return self._global_summary_service.get_global_summary()
        from ..summary.global_summary_service import GlobalSummaryService
        return GlobalSummaryService(self.project).get_global_summary()

    def _get_tracking_status(self) -> TrackingStatus:
        from ...models.context.tracking_status import TrackingStatus as TS
        status = TS()
        return status

    def invalidate_cache(self):
        with self._cache_lock:
            self._design_context_cache.clear()
            self._generate_context_cache.clear()
