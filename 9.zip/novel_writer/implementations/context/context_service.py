# -*- coding: utf-8 -*-
"""上下文服务 — 对标 Implementations/Context/ContextService.cs（partial 9 文件，约 2200 行）

核心：设计数据加载 + 各层上下文字符串构建（XML 格式给 AI）+ 字符预算降级
"""
import re
from typing import List, Optional

from ...models.contexts.aggregates.design_data import DesignData
from ...models.contexts.aggregates.generate_data import (
    GenerateData, OutlineDataAggregate, PlanningData, BlueprintDataAggregate,
    VolumeDesignDataAggregate,
)
from ...models.contexts.design.templates_context import TemplatesContext
from ...models.contexts.design.worldview_context import WorldviewContext
from ...models.contexts.design.character_context import CharacterContext
from ...models.contexts.design.factions_context import FactionsContext
from ...models.contexts.design.location_context import LocationContext
from ...models.contexts.design.plot_context import PlotContext
from ...models.contexts.design.smart_parsing_context import SmartParsingContext
from ...models.contexts.generate.outline_context import OutlineContext
from ...models.contexts.generate.planning_context import PlanningContext
from ...models.contexts.generate.blueprint_context import BlueprintContext
from ...models.contexts.validation_context import ValidationContext, ValidateRules


class MaterialScope:
    WORLDVIEW = "worldview"
    CHARACTER = "character"
    FACTION = "faction"
    LOCATION = "location"
    PLOT = "plot"


class ContextService:
    PACKAGED_CACHE_LAYER = "PackagedContext"
    FUNC_DATA_CACHE_LAYER = "FuncData"
    CONTEXT_CHAR_BUDGET = 33000

    # 正则（对标 C# 静态正则）
    _VOL_NUM_KEY_RE = re.compile(r"(?:第\s*)?(\d+)\s*卷")
    _VOL_PREFIX_RE = re.compile(r"^vol(\d+)", re.IGNORECASE)
    _VOL_CH_ID_RE = re.compile(r"vol(\d+)_ch(\d+)", re.IGNORECASE)

    def __init__(self, project, session_cache=None):
        self.project = project
        self._session_cache = session_cache

    # ============ 数据加载 ============

    def _load_design(self, entity: str) -> list:
        data = self.project.load_design(entity)
        if isinstance(data, dict):
            return data.get("items", [])
        return data or []

    def _load_plan(self, entity: str) -> list:
        data = self.project.load_plan(entity)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return data.get(entity, data.get("items", []))
        return []

    def _load_function_data(self, function_name: str) -> list:
        mapping = {
            "CreativeMaterials": "materials", "WorldRules": "world",
            "CharacterRules": "characters", "FactionRules": "factions",
            "LocationRules": "locations", "PlotRules": "plot",
            "BookAnalysis": "materials", "Outline": "outline",
            "Chapter": "chapters", "Blueprint": "blueprints",
            "VolumeDesign": "volumes",
        }
        entity = mapping.get(function_name, function_name.lower())
        if entity in ("materials", "world", "characters", "factions", "locations", "plot"):
            return self._load_design(entity)
        return self._load_plan(entity)

    # ============ Design 上下文（对象） ============

    def get_smart_parsing_context(self) -> SmartParsingContext:
        return SmartParsingContext(BookAnalyses=self._load_function_data("BookAnalysis"))

    def get_templates_context(self) -> TemplatesContext:
        return TemplatesContext(CreativeMaterials=self._load_function_data("CreativeMaterials"))

    def get_worldview_context(self) -> WorldviewContext:
        templates = TemplatesContext(CreativeMaterials=self._load_function_data("CreativeMaterials"))
        return WorldviewContext(Templates=templates, WorldRules=self._load_function_data("WorldRules"))

    def get_character_context(self) -> CharacterContext:
        templates = TemplatesContext(CreativeMaterials=self._load_function_data("CreativeMaterials"))
        worldview = WorldviewContext(Templates=templates, WorldRules=self._load_function_data("WorldRules"))
        return CharacterContext(Templates=templates, Worldview=worldview,
                                CharacterRules=self._load_function_data("CharacterRules"))

    def get_factions_context(self) -> FactionsContext:
        templates = TemplatesContext(CreativeMaterials=self._load_function_data("CreativeMaterials"))
        worldview = WorldviewContext(Templates=templates, WorldRules=self._load_function_data("WorldRules"))
        characters = CharacterContext(Templates=templates, Worldview=worldview,
                                      CharacterRules=self._load_function_data("CharacterRules"))
        return FactionsContext(Templates=templates, Worldview=worldview, Characters=characters,
                               FactionRules=self._load_function_data("FactionRules"))

    def get_locations_context(self) -> LocationContext:
        templates = TemplatesContext(CreativeMaterials=self._load_function_data("CreativeMaterials"))
        worldview = WorldviewContext(Templates=templates, WorldRules=self._load_function_data("WorldRules"))
        characters = CharacterContext(Templates=templates, Worldview=worldview,
                                      CharacterRules=self._load_function_data("CharacterRules"))
        factions = FactionsContext(Templates=templates, Worldview=worldview, Characters=characters,
                                   FactionRules=self._load_function_data("FactionRules"))
        return LocationContext(Templates=templates, Worldview=worldview, Characters=characters,
                               Factions=factions, LocationRules=self._load_function_data("LocationRules"))

    def get_plot_context(self) -> PlotContext:
        templates = TemplatesContext(CreativeMaterials=self._load_function_data("CreativeMaterials"))
        worldview = WorldviewContext(Templates=templates, WorldRules=self._load_function_data("WorldRules"))
        characters = CharacterContext(Templates=templates, Worldview=worldview,
                                      CharacterRules=self._load_function_data("CharacterRules"))
        factions = FactionsContext(Templates=templates, Worldview=worldview, Characters=characters,
                                   FactionRules=self._load_function_data("FactionRules"))
        locations = LocationContext(Templates=templates, Worldview=worldview, Characters=characters,
                                    Factions=factions, LocationRules=self._load_function_data("LocationRules"))
        return PlotContext(Templates=templates, Worldview=worldview, Characters=characters,
                           Factions=factions, Locations=locations,
                           PlotRules=self._load_function_data("PlotRules"))

    def get_design_context(self) -> DesignData:
        return self._build_design_data()

    def _build_design_data(self) -> DesignData:
        templates = TemplatesContext(CreativeMaterials=self._load_function_data("CreativeMaterials"))
        worldview = WorldviewContext(Templates=templates, WorldRules=self._load_function_data("WorldRules"))
        characters = CharacterContext(Templates=templates, Worldview=worldview,
                                      CharacterRules=self._load_function_data("CharacterRules"))
        factions = FactionsContext(Templates=templates, Worldview=worldview, Characters=characters,
                                   FactionRules=self._load_function_data("FactionRules"))
        locations = LocationContext(Templates=templates, Worldview=worldview, Characters=characters,
                                    Factions=factions, LocationRules=self._load_function_data("LocationRules"))
        plot = PlotContext(Templates=templates, Worldview=worldview, Characters=characters,
                           Factions=factions, Locations=locations,
                           PlotRules=self._load_function_data("PlotRules"))
        return DesignData(Templates=templates, Worldview=worldview, Characters=characters,
                          Factions=factions, Locations=locations, Plot=plot)

    # ============ Generate 上下文（对象） ============

    def get_outline_context(self) -> OutlineContext:
        return OutlineContext(Design=self._build_design_data(),
                              Outlines=self._load_function_data("Outline"))

    def get_planning_context(self) -> PlanningContext:
        return PlanningContext(Design=self._build_design_data(),
                               Outline=OutlineDataAggregate(Outlines=self._load_function_data("Outline")),
                               Chapters=self._load_function_data("Chapter"))

    def get_blueprint_context(self) -> BlueprintContext:
        return BlueprintContext(Design=self._build_design_data(),
                                Outline=OutlineDataAggregate(Outlines=self._load_function_data("Outline")),
                                Planning=PlanningData(Chapters=self._load_function_data("Chapter")),
                                Blueprints=self._load_function_data("Blueprint"))

    # ============ Validation 上下文 ============

    def get_validation_context(self, chapter_id: str) -> ValidationContext:
        from ...character_state_service import parse_chapter_id
        context = ValidationContext(Design=self._build_design_data(),
                                    Generate=self._load_packaged_generate_data(),
                                    Rules=ValidateRules(), ChapterId=chapter_id)
        vol, ch = parse_chapter_id(chapter_id)
        if vol and ch:
            context.VolumeNumber = vol
            context.ChapterNumber = ch
            content = self.project.load_chapter(chapter_id)
            if isinstance(content, dict):
                content = content.get("content", "")
            context.GeneratedContent = content or ""
        return context

    def _load_packaged_generate_data(self) -> GenerateData:
        return GenerateData(
            Outline=OutlineDataAggregate(Outlines=self._load_function_data("Outline")),
            Planning=PlanningData(Chapters=self._load_function_data("Chapter")),
            Blueprint=BlueprintDataAggregate(Blueprints=self._load_function_data("Blueprint")),
            VolumeDesign=VolumeDesignDataAggregate(VolumeDesigns=self._load_function_data("VolumeDesign")))

    # ============ 上下文字符串构建（对标 FullContext.cs + ContextBuilders.cs） ============

    @staticmethod
    def _enabled(items):
        return [i for i in items if i.get("IsEnabled", True)]

    @staticmethod
    def _has_content(data, fields):
        return any(data.get(f) for f in fields)

    @staticmethod
    def _resolve_id(id_or_name, map_dict):
        if not id_or_name:
            return ""
        return map_dict.get(id_or_name, id_or_name)

    @staticmethod
    def _resolve_ids(ids, map_dict):
        if not ids:
            return ""
        parts = [x.strip() for x in re.split(r"[,，、]", str(ids)) if x.strip()]
        return "、".join(ContextService._resolve_id(p, map_dict) for p in parts if p)

    def get_creative_materials_context(self) -> str:
        return self.build_creative_materials_string(MaterialScope.PLOT)

    def build_creative_materials_string(self, scope: str) -> str:
        """对标 BuildCreativeMaterialsStringAsync(scope): 按 scope 过滤字段"""
        sb = ["<creative_materials_catalog>"]
        for item in self._enabled(self._load_function_data("CreativeMaterials")):
            sb.append(f'<item name="{item.get("Name", "")}">')
            sb.append(f'分类：{item.get("Category", "")}')
            if item.get("Genre"): sb.append(f'创作类型：{item.get("Genre")}')
            if item.get("OverallIdea"): sb.append(f'整体构思：{item.get("OverallIdea")}')

            need_world_building = scope in (MaterialScope.WORLDVIEW, MaterialScope.LOCATION)
            need_power_system = True
            need_environment = scope in (MaterialScope.WORLDVIEW, MaterialScope.LOCATION)
            need_faction_design = scope in (MaterialScope.WORLDVIEW, MaterialScope.FACTION)

            if need_world_building and item.get("WorldBuildingMethod"):
                sb.append(f'世界观搭建方法：{item.get("WorldBuildingMethod")}')
            if need_power_system and item.get("PowerSystemDesign"):
                sb.append(f'力量体系设计：{item.get("PowerSystemDesign")}')
            if need_environment and item.get("EnvironmentDescription"):
                sb.append(f'环境描写：{item.get("EnvironmentDescription")}')
            if need_faction_design and item.get("FactionDesign"):
                sb.append(f'势力设计：{item.get("FactionDesign")}')
            if item.get("WorldviewHighlights"): sb.append(f'世界观亮点：{item.get("WorldviewHighlights")}')

            need_char_materials = scope in (MaterialScope.CHARACTER, MaterialScope.PLOT)
            if need_char_materials:
                if item.get("ProtagonistDesign"): sb.append(f'主角塑造：{item.get("ProtagonistDesign")}')
                if item.get("SupportingRoles"): sb.append(f'配角设计：{item.get("SupportingRoles")}')
                if item.get("CharacterRelations"): sb.append(f'人物关系：{item.get("CharacterRelations")}')
                if item.get("GoldenFingerDesign"): sb.append(f'金手指设计：{item.get("GoldenFingerDesign")}')
                if item.get("CharacterHighlights"): sb.append(f'角色亮点：{item.get("CharacterHighlights")}')

            if scope == MaterialScope.PLOT:
                if item.get("PlotStructure"): sb.append(f'情节结构：{item.get("PlotStructure")}')
                if item.get("ConflictDesign"): sb.append(f'冲突设计：{item.get("ConflictDesign")}')
                if item.get("ClimaxArrangement"): sb.append(f'高潮布局：{item.get("ClimaxArrangement")}')
                if item.get("ForeshadowingTechnique"): sb.append(f'伏笔技巧：{item.get("ForeshadowingTechnique")}')
                if item.get("PlotHighlights"): sb.append(f'剧情亮点：{item.get("PlotHighlights")}')
            sb.append("</item>")
            sb.append("")
        sb.append("</creative_materials_catalog>")
        return "\n".join(sb)

    def build_worldview_string(self) -> str:
        sb = ["<worldview_rules>"]
        for item in self._enabled(self._load_function_data("WorldRules")):
            if not self._has_content(item, ["Name", "OneLineSummary", "PowerSystem", "HardRules"]):
                continue
            sb.append(f'<item name="{item.get("Name", "")}">')
            if item.get("OneLineSummary"): sb.append(f'简介：{item.get("OneLineSummary")}')
            if item.get("PowerSystem"): sb.append(f'力量体系：{item.get("PowerSystem")}')
            if item.get("Cosmology"): sb.append(f'宇宙观：{item.get("Cosmology")}')
            if item.get("SpecialLaws"): sb.append(f'特殊法则：{item.get("SpecialLaws")}')
            if item.get("HardRules"): sb.append(f'硬规则：{item.get("HardRules")}')
            if item.get("SoftRules"): sb.append(f'软规则：{item.get("SoftRules")}')
            if item.get("KeyEvents"): sb.append(f'关键历史事件：{item.get("KeyEvents")}')
            sb.append("</item>")
            sb.append("")
        sb.append("</worldview_rules>")
        return "\n".join(sb)

    def build_volume_design_string(self) -> str:
        sb = ["<volume_designs>"]
        for item in self._enabled(self._load_function_data("VolumeDesign")):
            sb.append(f'<item name="第{item.get("VolumeNumber", "")}卷 {item.get("VolumeTitle", "")}">')
            if item.get("VolumeTheme"): sb.append(f'卷主题：{item.get("VolumeTheme")}')
            if item.get("StageGoal"): sb.append(f'阶段目标：{item.get("StageGoal")}')
            if item.get("MainConflict"): sb.append(f'核心冲突：{item.get("MainConflict")}')
            if item.get("KeyEvents"): sb.append(f'关键转折：{item.get("KeyEvents")}')
            if item.get("ChapterGenerationHints"): sb.append(f'章节生成提示：{item.get("ChapterGenerationHints")}')
            sb.append("</item>")
            sb.append("")
        sb.append("</volume_designs>")
        return "\n".join(sb)

    def _load_entity_maps(self):
        """对标 LoadEntityMapsAsync: 并行加载角色/势力/地点 + ID→Name 映射"""
        chars = self._enabled(self._load_function_data("CharacterRules"))
        factions = self._enabled(self._load_function_data("FactionRules"))
        locs = self._enabled(self._load_function_data("LocationRules"))
        char_map = {c.get("Id", ""): c.get("Name", "") for c in chars if c.get("Id")}
        faction_map = {f.get("Id", ""): f.get("Name", "") for f in factions if f.get("Id")}
        loc_map = {l.get("Id", ""): l.get("Name", "") for l in locs if l.get("Id")}
        return char_map, faction_map, loc_map, chars, factions, locs

    def build_character_summary_string(self, preloaded=None) -> str:
        sb = ["<character_rules>"]
        items = preloaded if preloaded is not None else self._enabled(self._load_function_data("CharacterRules"))
        for item in items:
            if not self._has_content(item, ["Name", "Identity", "Want", "Need"]):
                continue
            sb.append(f'<item name="{item.get("Name", "")}">')
            if item.get("CharacterType"): sb.append(f'角色类型：{item.get("CharacterType")}')
            if item.get("Identity"): sb.append(f'身份：{item.get("Identity")}')
            if item.get("Want"): sb.append(f'外在目标：{item.get("Want")}')
            sb.append("</item>")
            sb.append("")
        sb.append("</character_rules>")
        return "\n".join(sb)

    def build_character_arc_string(self, preloaded=None, char_id_to_name=None) -> str:
        sb = ["<character_rules>"]
        chars = preloaded if preloaded is not None else self._enabled(self._load_function_data("CharacterRules"))
        if char_id_to_name is None:
            char_id_to_name = {c.get("Id", ""): c.get("Name", "") for c in chars if c.get("Id")}
        for item in chars:
            if not self._has_content(item, ["Name", "Identity", "Want", "Need"]):
                continue
            sb.append(f'<item name="{item.get("Name", "")}">')
            if item.get("CharacterType"): sb.append(f'角色类型：{item.get("CharacterType")}')
            if item.get("Identity"): sb.append(f'身份：{item.get("Identity")}')
            if item.get("Want"): sb.append(f'外在目标：{item.get("Want")}')
            if item.get("Need"): sb.append(f'内在需要：{item.get("Need")}')
            if item.get("FlawBelief"): sb.append(f'核心缺陷：{item.get("FlawBelief")}')
            if item.get("GrowthPath"): sb.append(f'成长路径：{item.get("GrowthPath")}')
            if item.get("Personality"): sb.append(f'性格：{item.get("Personality")}')
            if item.get("TargetCharacterName"):
                tn = self._resolve_id(item.get("TargetCharacterName"), char_id_to_name)
                if tn: sb.append(f'关联角色：{tn}')
            if item.get("RelationshipType"): sb.append(f'关系类型：{item.get("RelationshipType")}')
            if item.get("EmotionDynamic"): sb.append(f'情感动态：{item.get("EmotionDynamic")}')
            if item.get("Relationships"): sb.append(f'关系：{item.get("Relationships")}')
            sb.append("</item>")
            sb.append("")
        sb.append("</character_rules>")
        return "\n".join(sb)

    def build_character_arc_string_for_volume(self, name_filter, preloaded=None, char_id_to_name=None) -> str:
        if not name_filter:
            return self.build_character_arc_string(preloaded, char_id_to_name)
        sb = ["<character_rules>"]
        all_chars = preloaded if preloaded is not None else self._enabled(self._load_function_data("CharacterRules"))
        if char_id_to_name is None:
            char_id_to_name = {c.get("Id", ""): c.get("Name", "") for c in all_chars if c.get("Id")}
        enabled_all = [i for i in all_chars if i.get("IsEnabled", True)]
        filtered = [i for i in enabled_all
                    if self._has_content(i, ["Name", "Identity", "Want", "Need"]) and
                    any(n.lower() == i.get("Name", "").lower() or n.lower() in i.get("Name", "").lower() or
                        i.get("Name", "").lower() in n.lower() for n in name_filter)]
        if not filtered:
            return self.build_character_arc_string(all_chars, char_id_to_name)
        for item in filtered:
            sb.append(f'<item name="{item.get("Name", "")}">')
            if item.get("CharacterType"): sb.append(f'角色类型：{item.get("CharacterType")}')
            if item.get("Identity"): sb.append(f'身份：{item.get("Identity")}')
            if item.get("Want"): sb.append(f'外在目标：{item.get("Want")}')
            if item.get("Need"): sb.append(f'内在需要：{item.get("Need")}')
            if item.get("FlawBelief"): sb.append(f'核心缺陷：{item.get("FlawBelief")}')
            if item.get("GrowthPath"): sb.append(f'成长路径：{item.get("GrowthPath")}')
            if item.get("Personality"): sb.append(f'性格：{item.get("Personality")}')
            if item.get("TargetCharacterName"):
                tn = self._resolve_id(item.get("TargetCharacterName"), char_id_to_name)
                if tn: sb.append(f'关联角色：{tn}')
            if item.get("RelationshipType"): sb.append(f'关系类型：{item.get("RelationshipType")}')
            if item.get("EmotionDynamic"): sb.append(f'情感动态：{item.get("EmotionDynamic")}')
            if item.get("Relationships"): sb.append(f'关系：{item.get("Relationships")}')
            sb.append("</item>")
            sb.append("")
        if len(filtered) < len(enabled_all):
            sb.append(f'<!-- 另有 {len(enabled_all) - len(filtered)} 个未涉及角色已过滤 -->')
        sb.append("</character_rules>")
        return "\n".join(sb)

    def build_character_structure_string(self) -> str:
        sb = ["<character_rules>"]
        for item in self._enabled(self._load_function_data("CharacterRules")):
            if not self._has_content(item, ["Name", "Identity", "Want", "Need"]):
                continue
            sb.append(f'<item name="{item.get("Name", "")}">')
            if item.get("CharacterType"): sb.append(f'角色类型：{item.get("CharacterType")}')
            if item.get("Identity"): sb.append(f'身份：{item.get("Identity")}')
            if item.get("Want"): sb.append(f'外在目标：{item.get("Want")}')
            if item.get("Need"): sb.append(f'内在需要：{item.get("Need")}')
            if item.get("FlawBelief"): sb.append(f'核心缺陷：{item.get("FlawBelief")}')
            if item.get("GrowthPath"): sb.append(f'成长路径：{item.get("GrowthPath")}')
            sb.append("</item>")
            sb.append("")
        sb.append("</character_rules>")
        return "\n".join(sb)

    def build_faction_summary_string(self, preloaded=None, char_id_to_name=None) -> str:
        sb = ["<faction_rules>"]
        factions = preloaded if preloaded is not None else self._enabled(self._load_function_data("FactionRules"))
        if char_id_to_name is None:
            chars = self._enabled(self._load_function_data("CharacterRules"))
            char_id_to_name = {c.get("Id", ""): c.get("Name", "") for c in chars if c.get("Id")}
        faction_id_to_name = {f.get("Id", ""): f.get("Name", "") for f in factions if f.get("Id")}
        for item in factions:
            if not self._has_content(item, ["Name", "Goal", "FactionType"]):
                continue
            sb.append(f'<item name="{item.get("Name", "")}">')
            if item.get("FactionType"): sb.append(f'类型：{item.get("FactionType")}')
            if item.get("Goal"): sb.append(f'势力目标：{item.get("Goal")}')
            if item.get("Leader"): sb.append(f'领袖：{self._resolve_id(item.get("Leader"), char_id_to_name)}')
            if item.get("CoreMembers"): sb.append(f'核心成员：{self._resolve_ids(item.get("CoreMembers"), char_id_to_name)}')
            if item.get("MemberTraits"): sb.append(f'成员特征：{item.get("MemberTraits")}')
            if item.get("StrengthTerritory"): sb.append(f'实力/地盘：{item.get("StrengthTerritory")}')
            if item.get("Allies"): sb.append(f'盟友：{self._resolve_ids(item.get("Allies"), faction_id_to_name)}')
            if item.get("Enemies"): sb.append(f'敌对：{self._resolve_ids(item.get("Enemies"), faction_id_to_name)}')
            if item.get("NeutralCompetitors"): sb.append(f'中立竞争者：{self._resolve_ids(item.get("NeutralCompetitors"), faction_id_to_name)}')
            sb.append("</item>")
            sb.append("")
        sb.append("</faction_rules>")
        return "\n".join(sb)

    def build_faction_summary_string_for_volume(self, name_filter, preloaded=None, char_id_to_name=None) -> str:
        if not name_filter:
            return self.build_faction_summary_string(preloaded, char_id_to_name)
        sb = ["<faction_rules>"]
        all_factions = preloaded if preloaded is not None else self._enabled(self._load_function_data("FactionRules"))
        if char_id_to_name is None:
            chars = self._enabled(self._load_function_data("CharacterRules"))
            char_id_to_name = {c.get("Id", ""): c.get("Name", "") for c in chars if c.get("Id")}
        enabled_all = [i for i in all_factions if i.get("IsEnabled", True)]
        faction_id_to_name = {f.get("Id", ""): f.get("Name", "") for f in all_factions if f.get("Id")}
        filtered = [i for i in enabled_all
                    if self._has_content(i, ["Name", "Goal", "FactionType"]) and
                    any(n.lower() == i.get("Name", "").lower() or n.lower() in i.get("Name", "").lower() or
                        i.get("Name", "").lower() in n.lower() for n in name_filter)]
        if not filtered:
            return self.build_faction_summary_string(all_factions, char_id_to_name)
        for item in filtered:
            sb.append(f'<item name="{item.get("Name", "")}">')
            if item.get("FactionType"): sb.append(f'类型：{item.get("FactionType")}')
            if item.get("Goal"): sb.append(f'势力目标：{item.get("Goal")}')
            if item.get("Leader"): sb.append(f'领袖：{self._resolve_id(item.get("Leader"), char_id_to_name)}')
            if item.get("CoreMembers"): sb.append(f'核心成员：{self._resolve_ids(item.get("CoreMembers"), char_id_to_name)}')
            if item.get("MemberTraits"): sb.append(f'成员特征：{item.get("MemberTraits")}')
            if item.get("StrengthTerritory"): sb.append(f'实力/地盘：{item.get("StrengthTerritory")}')
            if item.get("Allies"): sb.append(f'盟友：{self._resolve_ids(item.get("Allies"), faction_id_to_name)}')
            if item.get("Enemies"): sb.append(f'敌对：{self._resolve_ids(item.get("Enemies"), faction_id_to_name)}')
            if item.get("NeutralCompetitors"): sb.append(f'中立竞争者：{self._resolve_ids(item.get("NeutralCompetitors"), faction_id_to_name)}')
            sb.append("</item>")
            sb.append("")
        if len(filtered) < len(enabled_all):
            sb.append(f'<!-- 另有 {len(enabled_all) - len(filtered)} 个未涉及势力已过滤 -->')
        sb.append("</faction_rules>")
        return "\n".join(sb)

    def build_faction_minimal_string(self) -> str:
        sb = ["<faction_rules>"]
        for item in self._enabled(self._load_function_data("FactionRules")):
            if not self._has_content(item, ["Name", "Goal", "FactionType"]):
                continue
            sb.append(f'<item name="{item.get("Name", "")}">')
            if item.get("FactionType"): sb.append(f'类型：{item.get("FactionType")}')
            if item.get("Goal"): sb.append(f'势力目标：{item.get("Goal")}')
            if item.get("StrengthTerritory"): sb.append(f'实力/地盘：{item.get("StrengthTerritory")}')
            sb.append("</item>")
            sb.append("")
        sb.append("</faction_rules>")
        return "\n".join(sb)

    def build_location_summary_string(self, preloaded=None) -> str:
        sb = ["<location_rules>"]
        items = preloaded if preloaded is not None else self._enabled(self._load_function_data("LocationRules"))
        for item in items:
            if not self._has_content(item, ["Name", "Description", "Terrain"]):
                continue
            sb.append(f'<item name="{item.get("Name", "")}">')
            if item.get("LocationType"): sb.append(f'类型：{item.get("LocationType")}')
            if item.get("Description"): sb.append(f'描述：{item.get("Description")}')
            dangers = item.get("Dangers") or []
            if dangers: sb.append(f'危险/禁忌：{"、".join(str(d) for d in dangers)}')
            sb.append("</item>")
            sb.append("")
        sb.append("</location_rules>")
        return "\n".join(sb)

    def build_location_summary_string_for_volume(self, name_filter, preloaded=None) -> str:
        if not name_filter:
            return self.build_location_summary_string(preloaded)
        sb = ["<location_rules>"]
        all_locs = preloaded if preloaded is not None else self._enabled(self._load_function_data("LocationRules"))
        enabled_all = [i for i in all_locs if i.get("IsEnabled", True)]
        filtered = [i for i in enabled_all
                    if self._has_content(i, ["Name", "Description", "Terrain"]) and
                    any(n.lower() == i.get("Name", "").lower() or n.lower() in i.get("Name", "").lower() or
                        i.get("Name", "").lower() in n.lower() for n in name_filter)]
        if not filtered:
            return self.build_location_summary_string()
        for item in filtered:
            sb.append(f'<item name="{item.get("Name", "")}">')
            if item.get("LocationType"): sb.append(f'类型：{item.get("LocationType")}')
            if item.get("Description"): sb.append(f'描述：{item.get("Description")}')
            dangers = item.get("Dangers") or []
            if dangers: sb.append(f'危险/禁忌：{"、".join(str(d) for d in dangers)}')
            sb.append("</item>")
            sb.append("")
        if len(filtered) < len(enabled_all):
            sb.append(f'<!-- 另有 {len(enabled_all) - len(filtered)} 个未涉及地点已过滤 -->')
        sb.append("</location_rules>")
        return "\n".join(sb)

    def build_plot_rules_string(self, volume_filter=None) -> str:
        sb = []
        plot_rules = self._enabled(self._load_function_data("PlotRules"))
        chars = self._enabled(self._load_function_data("CharacterRules"))
        char_map = {c.get("Id", ""): c.get("Name", "") for c in chars if c.get("Id")}
        locs = self._enabled(self._load_function_data("LocationRules"))
        loc_map = {l.get("Id", ""): l.get("Name", "") for l in locs if l.get("Id")}
        enabled_rules = [i for i in plot_rules if self._has_content(i, ["Name", "OneLineSummary", "Goal"])]
        if not volume_filter:
            sb.append("<plot_rules>")
            for item in enabled_rules:
                self._append_plot_rule_full(sb, item, char_map, loc_map)
        else:
            filter_vol_num = self._extract_volume_number_from_text(volume_filter)
            injected = [r for r in enabled_rules
                        if r.get("EventType") == "全卷贯穿" or r.get("AssignedVolume") == "全书"
                        or not r.get("AssignedVolume")
                        or (r.get("AssignedVolume") or "").lower() == volume_filter.lower()
                        or (filter_vol_num > 0 and self._extract_volume_number_from_text(str(r.get("AssignedVolume", ""))) == filter_vol_num)]
            skipped = len(enabled_rules) - len(injected)
            sb.append(f'<plot_rules volume="{volume_filter}">')
            for item in injected:
                self._append_plot_rule_full(sb, item, char_map, loc_map)
            if skipped > 0:
                sb.append(f'<!-- 另有 {skipped} 个其他卷剧情未注入 -->')
        sb.append("</plot_rules>")
        return "\n".join(sb)

    def build_plot_rules_structure_string(self, volume_filter=None) -> str:
        sb = []
        plot_rules = self._enabled(self._load_function_data("PlotRules"))
        enabled_rules = [i for i in plot_rules if self._has_content(i, ["Name", "OneLineSummary", "Goal"])]
        if not volume_filter:
            sb.append("<plot_rules>")
            injected = enabled_rules
        else:
            filter_vol_num = self._extract_volume_number_from_text(volume_filter)
            injected = [r for r in enabled_rules
                        if r.get("EventType") == "全卷贯穿" or r.get("AssignedVolume") == "全书"
                        or not r.get("AssignedVolume")
                        or (r.get("AssignedVolume") or "").lower() == volume_filter.lower()
                        or (filter_vol_num > 0 and self._extract_volume_number_from_text(str(r.get("AssignedVolume", ""))) == filter_vol_num)]
            skipped = len(enabled_rules) - len(injected)
            sb.append(f'<plot_rules volume="{volume_filter}">')
            if skipped > 0:
                sb.append(f'<!-- 另有 {skipped} 个其他卷剧情未注入 -->')
        for item in injected:
            sb.append(f'<item name="{item.get("Name", "")}">')
            if item.get("OneLineSummary"): sb.append(f'简介：{item.get("OneLineSummary")}')
            if item.get("EventType"): sb.append(f'事件类型：{item.get("EventType")}')
            if item.get("StoryPhase"): sb.append(f'故事阶段：{item.get("StoryPhase")}')
            if item.get("Goal"): sb.append(f'目标：{item.get("Goal")}')
            if item.get("Conflict"): sb.append(f'冲突：{item.get("Conflict")}')
            if item.get("MainPlotPush"): sb.append(f'主线推动：{item.get("MainPlotPush")}')
            if item.get("CharacterGrowth"): sb.append(f'角色成长：{item.get("CharacterGrowth")}')
            if item.get("Result"): sb.append(f'结果：{item.get("Result")}')
            sb.append("</item>")
            sb.append("")
        sb.append("</plot_rules>")
        return "\n".join(sb)

    def build_plot_rules_outline_min_string(self, volume_filter=None) -> str:
        sb = []
        plot_rules = self._enabled(self._load_function_data("PlotRules"))
        enabled_rules = [i for i in plot_rules if self._has_content(i, ["Name", "OneLineSummary", "Goal"])]
        if not volume_filter:
            sb.append("<plot_rules>")
            injected = enabled_rules
        else:
            filter_vol_num = self._extract_volume_number_from_text(volume_filter)
            injected = [r for r in enabled_rules
                        if r.get("EventType") == "全卷贯穿" or r.get("AssignedVolume") == "全书"
                        or not r.get("AssignedVolume")
                        or (r.get("AssignedVolume") or "").lower() == volume_filter.lower()
                        or (filter_vol_num > 0 and self._extract_volume_number_from_text(str(r.get("AssignedVolume", ""))) == filter_vol_num)]
            skipped = len(enabled_rules) - len(injected)
            sb.append(f'<plot_rules volume="{volume_filter}">')
            if skipped > 0:
                sb.append(f'<!-- 另有 {skipped} 个其他卷剧情未注入 -->')
        for item in injected:
            sb.append(f'<item name="{item.get("Name", "")}">')
            if item.get("AssignedVolume"): sb.append(f'所属卷：{item.get("AssignedVolume")}')
            if item.get("EventType"): sb.append(f'事件类型：{item.get("EventType")}')
            if item.get("OneLineSummary"): sb.append(f'简介：{item.get("OneLineSummary")}')
            if item.get("Goal"): sb.append(f'目标：{item.get("Goal")}')
            if item.get("StoryPhase"): sb.append(f'故事阶段：{item.get("StoryPhase")}')
            sb.append("</item>")
            sb.append("")
        sb.append("</plot_rules>")
        return "\n".join(sb)

    @staticmethod
    def _extract_volume_number_from_text(text: str) -> int:
        if not text:
            return 0
        m = ContextService._VOL_NUM_KEY_RE.search(text)
        if m:
            return int(m.group(1))
        m = ContextService._VOL_PREFIX_RE.match(text)
        if m:
            return int(m.group(1))
        return 0

    @staticmethod
    def _append_plot_rule_full(sb, item, char_map, loc_map):
        sb.append(f'<item name="{item.get("Name", "")}">')
        if item.get("OneLineSummary"): sb.append(f'简介：{item.get("OneLineSummary")}')
        if item.get("EventType"): sb.append(f'事件类型：{item.get("EventType")}')
        if item.get("StoryPhase"): sb.append(f'故事阶段：{item.get("StoryPhase")}')
        if item.get("MainCharacters"): sb.append(f'主要角色：{ContextService._resolve_ids(item.get("MainCharacters"), char_map)}')
        if item.get("Location"): sb.append(f'地点：{ContextService._resolve_id(item.get("Location"), loc_map)}')
        if item.get("Goal"): sb.append(f'目标：{item.get("Goal")}')
        if item.get("Conflict"): sb.append(f'冲突：{item.get("Conflict")}')
        if item.get("Result"): sb.append(f'结果：{item.get("Result")}')
        if item.get("MainPlotPush"): sb.append(f'主线推动：{item.get("MainPlotPush")}')
        if item.get("CharacterGrowth"): sb.append(f'角色成长：{item.get("CharacterGrowth")}')
        sb.append("</item>")
        sb.append("")

    def build_outline_string(self) -> str:
        sb = ["<strategic_outline>"]
        for item in self._enabled(self._load_function_data("Outline")):
            sb.append(f'<item name="{item.get("Name", "")}">')
            if item.get("TotalChapterCount"): sb.append(f'全书总章节数：{item.get("TotalChapterCount")}')
            if item.get("OneLineOutline"): sb.append(f'一句话大纲：{item.get("OneLineOutline")}')
            if item.get("EmotionalTone"): sb.append(f'情感基调：{item.get("EmotionalTone")}')
            if item.get("Theme"): sb.append(f'核心思想：{item.get("Theme")}')
            if item.get("CoreConflict"): sb.append(f'核心冲突：{item.get("CoreConflict")}')
            if item.get("EndingState"): sb.append(f'结局状态：{item.get("EndingState")}')
            if item.get("VolumeDivision"): sb.append(f'卷划分：{item.get("VolumeDivision")}')
            sb.append("</item>")
            sb.append("")
        sb.append("</strategic_outline>")
        return "\n".join(sb)

    # ============ 组合方法（GetXxxContextStringAsync） ============

    def get_worldview_context_string(self) -> str:
        sb = ['<design_context for="worldview_rules">']
        sb.append(self.get_creative_materials_context())
        sb.append("")
        sb.append(self.build_worldview_string())
        sb.append("</design_context>")
        return "\n".join(sb)

    def get_character_context_string(self) -> str:
        sb = ['<design_context for="character_rules">']
        sb.append(self.get_creative_materials_context())
        sb.append("")
        sb.append(self.build_worldview_string())
        sb.append("</design_context>")
        return "\n".join(sb)

    def get_faction_context_string(self) -> str:
        sb = ['<design_context for="faction_rules">']
        sb.append(self.get_creative_materials_context())
        sb.append("")
        sb.append(self.build_worldview_string())
        sb.append("")
        sb.append(self.build_character_summary_string())
        sb.append("")
        sb.append(self.build_faction_minimal_string())
        sb.append("</design_context>")
        return "\n".join(sb)

    def get_location_context_string(self) -> str:
        sb = ['<design_context for="location_rules">']
        sb.append(self.get_creative_materials_context())
        sb.append("")
        sb.append(self.build_worldview_string())
        sb.append("")
        sb.append(self.build_faction_minimal_string())
        sb.append("</design_context>")
        return "\n".join(sb)

    def get_plot_context_string(self) -> str:
        sb = ['<design_context for="plot_rules">']
        sb.append(self.get_creative_materials_context())
        sb.append("")
        sb.append(self.build_worldview_string())
        sb.append("")
        sb.append(self.build_character_arc_string())
        sb.append("")
        sb.append(self.build_faction_summary_string())
        sb.append("")
        sb.append(self.build_location_summary_string())
        sb.append("</design_context>")
        return "\n".join(sb)

    def get_outline_context_string(self) -> str:
        sb = ['<design_context for="outline">']
        sb.append(self.get_core_design_context())
        sb.append("</design_context>")
        return "\n".join(sb)

    def get_outline_structure_context(self) -> str:
        """对标 GetOutlineStructureContextAsync: 大纲结构（含降级）"""
        materials = self.build_creative_materials_string(MaterialScope.PLOT)
        worldview = self.build_worldview_string()
        char_result = self.build_character_structure_string()
        faction_result = self.build_faction_minimal_string()
        plot_result = self.build_plot_rules_structure_string(None)
        total = len(materials) + len(worldview) + len(char_result) + len(faction_result) + len(plot_result)
        if total > self.CONTEXT_CHAR_BUDGET:
            plot_result = self.build_plot_rules_outline_min_string(None)
        sb = ['<design_context for="outline">']
        sb.append(materials)
        sb.append("")
        sb.append(worldview)
        sb.append(char_result)
        sb.append(faction_result)
        sb.append(plot_result)
        sb.append("</design_context>")
        return "\n".join(sb)

    def get_chapter_context_string(self) -> str:
        sb = ['<design_context for="chapter_planning">']
        sb.append(self.get_core_design_context())
        sb.append("")
        sb.append(self.build_outline_string())
        sb.append("")
        sb.append(self.build_volume_design_string())
        sb.append("</design_context>")
        return "\n".join(sb)

    def get_chapter_context_with_volume_locator(self, category_key: str) -> str:
        """对标 GetChapterContextWithVolumeLocatorAsync: 带卷定位器的章节上下文"""
        sb = []
        volume = self._get_volume_design_by_category(category_key)
        volume_filter = f"第{volume.get('VolumeNumber')}卷" if volume and volume.get("VolumeNumber") else None
        is_volume_name = category_key and category_key.startswith("第") and category_key.endswith("卷")
        effective_filter = volume_filter or (category_key if is_volume_name else None)
        core = (self.get_core_design_context_for_volume(effective_filter)
                if effective_filter else self.get_core_design_context())
        sb.append(core)
        sb.append("")
        sb.append(self.build_outline_string())
        if volume:
            sb.append("")
            sb.append("---")
            sb.append(f'<context_block type="volume_locator" title="{volume.get("VolumeTitle", "")}">')
            sb.append(f'- 卷序号：第{volume.get("VolumeNumber")}卷')
            if volume.get("StartChapter") and volume.get("EndChapter"):
                sb.append(f'- 章节范围：第{volume.get("StartChapter")}-{volume.get("EndChapter")}章')
            if volume.get("VolumeTheme"): sb.append(f'- 卷主题：{volume.get("VolumeTheme")}')
            if volume.get("StageGoal"): sb.append(f'- 阶段目标：{volume.get("StageGoal")}')
            if volume.get("MainConflict"): sb.append(f'- 核心冲突：{volume.get("MainConflict")}')
            if volume.get("KeyEvents"): sb.append(f'- 关键转折：{volume.get("KeyEvents")}')
            if volume.get("ChapterGenerationHints"): sb.append(f'- 章节生成提示：{volume.get("ChapterGenerationHints")}')
            sb.append("</context_block>")
        else:
            sb.append("")
            sb.append(self.build_volume_design_string())
        return "\n".join(sb)

    def get_blueprint_context_with_chapter_locator(self, chapter_id: str) -> str:
        """对标 GetBlueprintContextWithChapterLocatorAsync: 带章节定位器的蓝图上下文"""
        sb = []
        chapter = self._get_chapter_data_by_chapter_id(chapter_id)
        volume = None
        if chapter:
            v_key = chapter.get("CategoryId") or chapter.get("Category") or chapter.get("Volume") or ""
            volume = self._get_volume_design_by_category(v_key)
        volume_filter = f"第{volume.get('VolumeNumber')}卷" if volume and volume.get("VolumeNumber") else None
        char_filter = chapter.get("ReferencedCharacterNames") if chapter else None
        fac_filter = chapter.get("ReferencedFactionNames") if chapter else None
        loc_filter = chapter.get("ReferencedLocationNames") if chapter else None
        if char_filter or fac_filter or loc_filter:
            core = self.get_core_design_context_for_entity_filter(char_filter, fac_filter, loc_filter, volume_filter)
        elif volume_filter:
            core = self.get_core_design_context_for_volume(volume_filter)
        else:
            core = self.get_core_design_context()
        sb.append(core)
        sb.append("")
        sb.append(self.build_outline_string())
        sb.append("")
        if volume is None:
            sb.append(self.build_volume_design_string())
            sb.append("")
        adjacent = self.build_adjacent_chapter_context(
            chapter.get("ChapterNumber", 0) if chapter else 0,
            chapter.get("Category") or chapter.get("Volume") or "" if chapter else "")
        if adjacent:
            sb.append(adjacent)
            sb.append("")
        if chapter:
            sb.append("")
            sb.append("---")
            sb.append(f'<context_block type="chapter_locator" title="{chapter.get("ChapterTitle", "")}">')
            sb.append(f'- 章节序号：第{chapter.get("ChapterNumber")}章')
            if chapter.get("ChapterTheme"): sb.append(f'- 章节主题：{chapter.get("ChapterTheme")}')
            if chapter.get("MainGoal"): sb.append(f'- 章节目标：{chapter.get("MainGoal")}')
            if chapter.get("KeyTurn"): sb.append(f'- 关键转折：{chapter.get("KeyTurn")}')
            if chapter.get("Hook"): sb.append(f'- 结尾钩子：{chapter.get("Hook")}')
            if chapter.get("WorldInfoDrop"): sb.append(f'- 世界投送：{chapter.get("WorldInfoDrop")}')
            if chapter.get("Foreshadowing"): sb.append(f'- 伏笔埋设/回收：{chapter.get("Foreshadowing")}')
            sb.append("</context_block>")
            if volume:
                sb.append("")
                sb.append(f'<context_block type="parent_volume" title="{volume.get("VolumeTitle", "")}">')
                sb.append(f'- 卷序号：第{volume.get("VolumeNumber")}卷')
                if volume.get("StageGoal"): sb.append(f'- 阶段目标：{volume.get("StageGoal")}')
                if volume.get("MainConflict"): sb.append(f'- 核心冲突：{volume.get("MainConflict")}')
                sb.append("</context_block>")
        return "\n".join(sb)

    def _get_chapter_data_by_chapter_id(self, chapter_id):
        """对标 GetChapterDataByChapterIdAsync: 按 volX_chY 查章节"""
        if not chapter_id:
            return None
        m = self._VOL_CH_ID_RE.match(chapter_id)
        if not m:
            return None
        volume_number = int(m.group(1))
        chapter_number = int(m.group(2))
        chapters = self._enabled(self._load_function_data("Chapter"))
        volume_prefix = f"第{volume_number}卷"
        for c in chapters:
            if c.get("ChapterNumber") != chapter_number:
                continue
            vol = c.get("Volume", "")
            cat = c.get("Category", "")
            cat_id = c.get("CategoryId", "")
            if (vol == volume_prefix or vol.startswith(volume_prefix + " ")
                    or cat == volume_prefix or cat.startswith(volume_prefix + " ")
                    or cat_id == volume_prefix or cat_id.startswith(volume_prefix + " ")):
                return c
        return None

    def get_volume_design_list(self) -> str:
        """对标 GetVolumeDesignListAsync"""
        return self.build_volume_design_string()

    def get_volume_design_context_string(self) -> str:
        sb = ['<design_context for="volume_design">']
        sb.append(self.get_core_design_context())
        sb.append("")
        sb.append(self.build_outline_string())
        sb.append("")
        sb.append(self.build_volume_design_string())
        sb.append("</design_context>")
        return "\n".join(sb)

    def get_volume_design_structure_context(self, volume_key=None) -> str:
        """对标 GetVolumeDesignStructureContextAsync: 卷设计结构（含降级）"""
        materials = self.build_creative_materials_string(MaterialScope.PLOT)
        worldview = self.build_worldview_string()
        char_result = self.build_character_structure_string()
        faction_result = self.build_faction_minimal_string()
        loc_result = self.build_location_summary_string()
        plot_result = self.build_plot_rules_structure_string(volume_key)
        outline_result = self.build_outline_string()
        total = len(materials) + len(worldview) + len(char_result) + len(faction_result) + len(loc_result) + len(plot_result) + len(outline_result)
        if total > self.CONTEXT_CHAR_BUDGET:
            plot_result = self.build_plot_rules_outline_min_string(volume_key)
        sb = ['<design_context for="volume_design">']
        sb.append(materials)
        sb.append("")
        sb.append(worldview)
        sb.append(char_result)
        sb.append(faction_result)
        sb.append(loc_result)
        sb.append(plot_result)
        sb.append("")
        sb.append(outline_result)
        sb.append("</design_context>")
        return "\n".join(sb)

    def get_core_design_context(self) -> str:
        sb = ["<design_data>"]
        sb.append(self.get_creative_materials_context())
        sb.append("")
        sb.append(self.build_worldview_string())
        sb.append(self.build_character_arc_string())
        sb.append(self.build_faction_summary_string())
        sb.append(self.build_location_summary_string())
        sb.append(self.build_plot_rules_string())
        sb.append("</design_data>")
        return "\n".join(sb)

    def get_core_design_context_for_volume(self, volume_key: str) -> str:
        char_map, faction_map, loc_map, chars, factions, locs = self._load_entity_maps()
        volume = self._get_volume_design_by_category(volume_key)
        char_task = (self.build_character_arc_string_for_volume(volume.get("ReferencedCharacterNames", []), chars, char_map)
                     if volume and volume.get("ReferencedCharacterNames")
                     else self.build_character_arc_string(chars, char_map))
        faction_task = (self.build_faction_summary_string_for_volume(volume.get("ReferencedFactionNames", []), factions, char_map)
                        if volume and volume.get("ReferencedFactionNames")
                        else self.build_faction_summary_string(factions, char_map))
        loc_task = (self.build_location_summary_string_for_volume(volume.get("ReferencedLocationNames", []), locs)
                    if volume and volume.get("ReferencedLocationNames")
                    else self.build_location_summary_string(locs))
        sb = ["<design_data>"]
        sb.append(self.get_creative_materials_context())
        sb.append("")
        sb.append(self.build_worldview_string())
        sb.append(char_task)
        sb.append(faction_task)
        sb.append(loc_task)
        sb.append(self.build_plot_rules_string(volume_key if volume else None))
        sb.append("</design_data>")
        return "\n".join(sb)

    def get_core_design_context_for_entity_filter(self, char_filter, faction_filter, loc_filter,
                                                  volume_key_for_plot_rules=None) -> str:
        char_map, faction_map, loc_map, chars, factions, locs = self._load_entity_maps()
        char_result = (self.build_character_arc_string_for_volume(char_filter, chars, char_map)
                       if char_filter else self.build_character_arc_string(chars, char_map))
        faction_result = (self.build_faction_summary_string_for_volume(faction_filter, factions, char_map)
                          if faction_filter else self.build_faction_summary_string(factions, char_map))
        loc_result = (self.build_location_summary_string_for_volume(loc_filter, locs)
                      if loc_filter else self.build_location_summary_string(locs))
        sb = ["<design_data>"]
        sb.append(self.get_creative_materials_context())
        sb.append("")
        sb.append(self.build_worldview_string())
        sb.append(char_result)
        sb.append(faction_result)
        sb.append(loc_result)
        sb.append(self.build_plot_rules_string(volume_key_for_plot_rules))
        sb.append("</design_data>")
        return "\n".join(sb)

    def _get_volume_design_by_category(self, category_key):
        if not category_key:
            return None
        key = category_key.strip()
        volumes = self._enabled(self._load_function_data("VolumeDesign"))
        for v in volumes:
            if (v.get("CategoryId") == key or v.get("Category") == key or v.get("Id") == key
                    or v.get("Name") == key or v.get("VolumeTitle") == key):
                return v
        vol_num = self._extract_volume_number_from_text(key)
        if vol_num > 0:
            for v in volumes:
                if v.get("VolumeNumber") == vol_num:
                    return v
        return None

    def build_adjacent_chapter_context(self, current_chapter_number: int, volume_category: str) -> str:
        if current_chapter_number <= 0 or not volume_category:
            return ""
        sb = []
        chapters = self._enabled(self._load_function_data("Chapter"))
        key = volume_category.strip()
        key_vol_num = self._extract_volume_number_from_text(key)
        volume_chapters = sorted(
            [c for c in chapters if (c.get("Category") == key or c.get("CategoryId") == key
                                     or (c.get("Volume") and (c.get("Volume") == key or c.get("Volume", "").startswith(key + " ")))
                                     or (key_vol_num > 0 and self._extract_volume_number_from_text(str(c.get("Volume", ""))) == key_vol_num))],
            key=lambda c: c.get("ChapterNumber", 0))
        has_any = False
        injected = 0

        def append_item(prefix, ch, fields):
            nonlocal has_any, injected
            if not has_any:
                sb.append("<adjacent_chapters>")
                has_any = True
            sb.append(f'<item name="第{ch.get("ChapterNumber")}章 {ch.get("ChapterTitle", "")}{prefix}">')
            for label, field in fields:
                if ch.get(field):
                    sb.append(f'{label}：{ch.get(field)}')
            sb.append("</item>")
            injected += 1

        n2 = next((c for c in volume_chapters if c.get("ChapterNumber") == current_chapter_number - 2), None)
        n3 = next((c for c in volume_chapters if c.get("ChapterNumber") == current_chapter_number - 3), None)
        if n2 and n2.get("Hook"):
            append_item("（前两章）", n2, [("结尾钩子", "Hook")])
        elif n3 and n3.get("Hook"):
            append_item("（前三章）", n3, [("结尾钩子", "Hook")])
        n1 = next((c for c in volume_chapters if c.get("ChapterNumber") == current_chapter_number - 1), None)
        if n1 and (n1.get("Hook") or n1.get("MainPlotProgress")):
            append_item("（上一章）", n1, [("结尾钩子", "Hook"), ("主线推进点", "MainPlotProgress")])
        p1 = next((c for c in volume_chapters if c.get("ChapterNumber") == current_chapter_number + 1), None)
        if p1 and (p1.get("ChapterTheme") or p1.get("MainGoal")):
            append_item("（下一章）", p1, [("章节主题", "ChapterTheme"), ("章节目标", "MainGoal")])
        p2 = next((c for c in volume_chapters if c.get("ChapterNumber") == current_chapter_number + 2), None)
        if p2 and (p2.get("ChapterTheme") or p2.get("MainGoal")):
            append_item("（后两章）", p2, [("章节主题", "ChapterTheme"), ("章节目标", "MainGoal")])
        if has_any:
            sb.append("</adjacent_chapters>")
        return "\n".join(sb)

    # ============ 内容检查辅助 ============

    @staticmethod
    def has_world_rules_content(data) -> bool:
        return bool(data.get("Name") or data.get("OneLineSummary") or data.get("PowerSystem") or data.get("HardRules"))

    @staticmethod
    def has_character_content(data) -> bool:
        return bool(data.get("Name") or data.get("Identity") or data.get("Want") or data.get("Need"))

    @staticmethod
    def has_faction_content(data) -> bool:
        return bool(data.get("Name") or data.get("Goal") or data.get("FactionType"))

    @staticmethod
    def has_location_content(data) -> bool:
        return bool(data.get("Name") or data.get("Description") or data.get("Terrain"))

    @staticmethod
    def has_plot_content(data) -> bool:
        return bool(data.get("Name") or data.get("OneLineSummary") or data.get("Goal"))

    # ============ 辅助 ============

    @staticmethod
    def try_parse_chapter_id(chapter_id: str):
        from ...character_state_service import parse_chapter_id
        return parse_chapter_id(chapter_id)
