# -*- coding: utf-8 -*-
"""物品状态服务 — 对标 4.1.1 ItemStateService.cs（完整移植 153 行）

对齐功能:
- UpdateItemStateAsync（守卫 + ID归并 + create + 持有者/状态更新 + 完整快照）
- RemoveChapterDataAsync（删除历史 + 回填 Holder/Status）
- GetAllItemStatesAsync
- FindExistingItemId（按 ID/Name 归并）
"""

from typing import Dict, List, Optional

from .character_state_service import build_chapter_id, parse_chapter_id
from .deadline_constraint_service import _is_likely_id, _new_deadline_id


def _new_item_id() -> str:
    """对标 ShortIdGenerator.New("I"): 前缀首字符'I' + 12位 = 13位"""
    return _new_deadline_id().replace("D", "I", 1)


class ItemStateService:
    """对标 4.1.1 ItemStateService — 物品状态管理（独立类）"""

    BaseFileName = "item_state_guide.json"
    HISTORY_FIELD = "StateHistory"

    def __init__(self, project, tracking_manager=None):
        self.project = project
        self.tracking = tracking_manager
        self._store = None

    def _get_store(self):
        if self._store is None:
            if self.tracking is not None:
                self._store = self.tracking._stores["item_state"]
            else:
                self._store = self.project.tracking("item_state")
        return self._store

    # ---- ID 归并 ----

    @staticmethod
    def find_existing_item_id(data: dict, ai_item_id: str, ai_item_name: str) -> Optional[str]:
        """对标 FindExistingItemId: 按 ID 或 Name 匹配已有物品"""
        if ai_item_id and ai_item_id in data:
            return ai_item_id
        for iid, entry in data.items():
            if not isinstance(entry, dict):
                continue
            name = entry.get("Name", "")
            if name and str(name).lower() == str(ai_item_id).lower():
                return iid
            if ai_item_name and name and str(name).lower() == str(ai_item_name).lower():
                return iid
        return None

    # ---- 更新 ----

    def update_item_state(self, chapter_id: str, change) -> Optional[str]:
        """对标 UpdateItemStateAsync: 更新/创建物品状态

        change: ItemTransferChange（ItemId/ItemName/FromHolder/ToHolder/NewStatus/Event/Importance/CausedBy）
        """
        if not change.ItemId:
            return None

        store = self._get_store()
        data = store.data()

        system_id = self.find_existing_item_id(data, change.ItemId, change.ItemName)

        if system_id is None:
            system_id = change.ItemId if _is_likely_id(change.ItemId) else _new_item_id()
            display_name = change.ItemName if change.ItemName else change.ItemId
            if system_id not in data:
                data[system_id] = {
                    "Name": display_name,
                    "Description": "",
                    "CurrentHolder": change.ToHolder,
                    "CurrentStatus": change.NewStatus if change.NewStatus else "active",
                    self.HISTORY_FIELD: [],
                    "DriftWarnings": [],
                }

        entry = data[system_id]
        # 补齐默认字段
        entry.setdefault("Description", "")
        entry.setdefault("CurrentStatus", "active")
        entry.setdefault("DriftWarnings", [])
        history = entry.setdefault(self.HISTORY_FIELD, [])
        if not isinstance(history, list):
            history = []
            entry[self.HISTORY_FIELD] = history

        if change.ItemName:
            entry["Name"] = change.ItemName

        if change.ToHolder:
            entry["CurrentHolder"] = change.ToHolder
        elif change.NewStatus and str(change.NewStatus).lower() != "active":
            entry["CurrentHolder"] = ""

        if change.NewStatus:
            entry["CurrentStatus"] = change.NewStatus

        # 完整快照（对标 C# ItemStatePoint）
        holder = change.ToHolder if change.ToHolder else entry.get("CurrentHolder", "")
        status = change.NewStatus if change.NewStatus else entry.get("CurrentStatus", "")
        history.append({
            "Chapter": chapter_id,
            "Holder": holder,
            "Status": status,
            "Event": change.Event,
            "Importance": change.Importance if change.Importance else "normal",
            "CausedBy": change.CausedBy or "",
        })

        store.set_all(data)
        return system_id

    # ---- 删除章节 ----

    def remove_chapter_data(self, chapter_id: str) -> int:
        """对标 RemoveChapterDataAsync: 删除历史 + 回填 Holder/Status"""
        store = self._get_store()
        data = store.data()
        modified = False
        removed_total = 0

        for entry in list(data.values()):
            if not isinstance(entry, dict):
                continue
            history = entry.get(self.HISTORY_FIELD)
            if not isinstance(history, list):
                continue
            before = len(history)
            history[:] = [s for s in history
                          if not (s.get("Chapter", "") and s["Chapter"] == chapter_id)]
            removed = before - len(history)
            if removed > 0:
                modified = True
                removed_total += removed
                history.sort(key=lambda s: parse_chapter_id(s.get("Chapter", "")))
                if history:
                    last = history[-1]
                    entry["CurrentHolder"] = last.get("Holder", "")
                    entry["CurrentStatus"] = last.get("Status", "")
                else:
                    entry["CurrentHolder"] = ""
                    entry["CurrentStatus"] = "unknown"

        if modified:
            store.set_all(data)
        return removed_total

    # ---- 查询 ----

    def get_all_item_states(self) -> Dict[str, dict]:
        """对标 GetAllItemStatesAsync: 合并全部物品（单文件全量）"""
        store = self._get_store()
        data = store.data()
        return {iid: entry for iid, entry in data.items() if isinstance(entry, dict)}