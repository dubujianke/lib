# -*- coding: utf-8 -*-
"""秘密揭示服务 — 对标 4.1.1 SecretRevealService.cs（完整移植 174 行）

对齐功能:
- UpdateSecretRevealAsync（守卫 + ID归并 + create + KnowerIds去重 + ComputeStatus + 完整快照）
- RemoveChapterDataAsync（删除历史 + 重建 KnowerIds + 重算状态）
- ExtractSnapshotAsync（导出 KnowerIds>0 的秘密快照）
- FindExistingSecretId（按 ID/Name 归并）
- ComputeStatus（0/1→hidden, ≤3→partially_known, >3→widely_known）
"""

from typing import Dict, List, Optional

from .character_state_service import build_chapter_id, parse_chapter_id
from .deadline_constraint_service import _is_likely_id, _new_deadline_id


def _new_secret_id() -> str:
    """对标 ShortIdGenerator.New("S"): 前缀取首字符'S' + 12位 = 13位"""
    return _new_deadline_id().replace("D", "S", 1)


def compute_status(knower_count: int) -> str:
    """对标 ComputeStatus: 按知情者数量分级"""
    if knower_count == 0:
        return "hidden"
    if knower_count == 1:
        return "hidden"
    if knower_count <= 3:
        return "partially_known"
    return "widely_known"


class SecretRevealService:
    """对标 4.1.1 SecretRevealService — 秘密揭示管理（独立类）"""

    BaseFileName = "secret_reveal_guide.json"
    HISTORY_FIELD = "RevealHistory"

    def __init__(self, project, tracking_manager=None):
        self.project = project
        self.tracking = tracking_manager
        self._store = None

    def _get_store(self):
        if self._store is None:
            if self.tracking is not None:
                self._store = self.tracking._stores["secret"]
            else:
                self._store = self.project.tracking("secret")
        return self._store

    # ---- ID 归并 ----

    @staticmethod
    def find_existing_secret_id(data: dict, ai_secret_id: str, ai_secret_name: str) -> Optional[str]:
        """对标 FindExistingSecretId: 按 ID 或 Name 匹配已有秘密"""
        if ai_secret_id and ai_secret_id in data:
            return ai_secret_id
        for sid, entry in data.items():
            if not isinstance(entry, dict):
                continue
            name = entry.get("Name", "")
            if name and str(name).lower() == str(ai_secret_id).lower():
                return sid
            if ai_secret_name and name and str(name).lower() == str(ai_secret_name).lower():
                return sid
        return None

    # ---- 更新 ----

    def update_secret_reveal(self, chapter_id: str, change) -> Optional[str]:
        """对标 UpdateSecretRevealAsync: 更新/创建秘密揭示

        change: SecretRevealChange（SecretId/SecretName/NewKnowerIds/Method/KeyEvent/Importance/CausedBy）
        返回 systemId 或 None（守卫拦截）
        """
        if not change.SecretId and not change.SecretName:
            return None
        if not change.NewKnowerIds:
            return None

        store = self._get_store()
        data = store.data()

        system_id = self.find_existing_secret_id(data, change.SecretId, change.SecretName)

        if system_id is None:
            system_id = change.SecretId if _is_likely_id(change.SecretId) else _new_secret_id()
            display_name = (change.SecretName if change.SecretName
                            else (change.SecretId if change.SecretId else system_id))
            if system_id not in data:
                data[system_id] = {
                    "Name": display_name,
                    "KnowerIds": [],
                    "CurrentStatus": "hidden",
                    self.HISTORY_FIELD: [],
                    "DriftWarnings": [],
                }

        entry = data[system_id]
        # 补齐既有条目默认字段
        entry.setdefault("CurrentStatus", "hidden")
        entry.setdefault("DriftWarnings", [])
        knower = entry.setdefault("KnowerIds", [])
        if not isinstance(knower, list):
            knower = []
            entry["KnowerIds"] = knower
        history = entry.setdefault(self.HISTORY_FIELD, [])
        if not isinstance(history, list):
            history = []
            entry[self.HISTORY_FIELD] = history

        if change.SecretName:
            entry["Name"] = change.SecretName

        # KnowerIds 追加去重（对标 C# OrdinalIgnoreCase）
        for knower_id in change.NewKnowerIds:
            if knower_id and not any(str(k).lower() == str(knower_id).lower() for k in knower):
                knower.append(knower_id)

        entry["CurrentStatus"] = compute_status(len(knower))

        # RevealHistory 完整快照（对标 C# SecretRevealPoint）
        history.append({
            "Chapter": chapter_id,
            "NewKnowerIds": list(change.NewKnowerIds),
            "Method": change.Method,
            "KeyEvent": change.KeyEvent,
            "Importance": change.Importance if change.Importance else "normal",
            "CausedBy": change.CausedBy or "",
        })

        store.set_all(data)
        return system_id

    # ---- 删除章节 ----

    def remove_chapter_data(self, chapter_id: str) -> int:
        """对标 RemoveChapterDataAsync: 删除历史 + 重建 KnowerIds + 重算状态"""
        store = self._get_store()
        data = store.data()
        modified = False
        removed_total = 0

        for entry in list(data.values()):
            if not isinstance(entry, dict):
                continue
            history = entry.get(self.HISTORY_FIELD)
            if not isinstance(history, list):
                continue
            before = len(history)
            history[:] = [p for p in history
                          if not (p.get("Chapter", "") and p["Chapter"] == chapter_id)]
            removed = before - len(history)
            if removed > 0:
                # 重建 KnowerIds：从 RevealHistory 的 NewKnowerIds 去重
                seen = set()
                knower = []
                for p in history:
                    for kid in (p.get("NewKnowerIds") or []):
                        if kid and str(kid).lower() not in seen:
                            seen.add(str(kid).lower())
                            knower.append(kid)
                entry["KnowerIds"] = knower
                entry["CurrentStatus"] = compute_status(len(knower))
                modified = True
                removed_total += removed

        if modified:
            store.set_all(data)
        return removed_total

    # ---- 快照 ----

    def extract_snapshot(self, chapter_id: str = "") -> List[dict]:
        """对标 ExtractSnapshotAsync: 导出 KnowerIds>0 的秘密快照"""
        store = self._get_store()
        data = store.data()
        result = []
        seen = set()
        for sid, entry in data.items():
            if not isinstance(entry, dict):
                continue
            knower = entry.get("KnowerIds") or []
            if not knower:
                continue
            if str(sid).lower() in seen:
                continue
            seen.add(str(sid).lower())
            history = entry.get(self.HISTORY_FIELD)
            last_chapter = ""
            if isinstance(history, list) and history:
                last_chapter = history[-1].get("Chapter", "") or ""
            result.append({
                "Id": sid,
                "Name": entry.get("Name", ""),
                "KnowerIds": list(knower),
                "Status": entry.get("CurrentStatus", "hidden"),
                "ChapterId": last_chapter,
            })
        return result