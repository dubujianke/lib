# -*- coding: utf-8 -*-
"""势力状态服务 — 对标 4.1.1 FactionStateService.cs（完整移植 128 行）

对齐功能:
- UpdateFactionStateAsync（自动注册 + 完整快照 StateHistory）
- RemoveChapterDataAsync（删除历史 + 回填 CurrentStatus，否则 "unknown"）
- GetAllFactionStatesAsync（合并全部势力）
- TryResolveFactionDisplayNameAsync（从 factionrules 解析势力名）
"""

from typing import Dict, List, Optional

from .character_state_service import build_chapter_id, parse_chapter_id


class FactionStateService:
    """对标 4.1.1 FactionStateService — 势力状态管理（独立类）"""

    BaseFileName = "faction_state_guide.json"
    HISTORY_FIELD = "StateHistory"

    def __init__(self, project, tracking_manager=None):
        self.project = project
        self.tracking = tracking_manager
        self._store = None

    def _get_store(self):
        if self._store is None:
            if self.tracking is not None:
                self._store = self.tracking._stores["faction_state"]
            else:
                self._store = self.project.tracking("faction_state")
        return self._store

    # ---- 更新 ----

    def update_faction_state(self, chapter_id: str, change) -> dict:
        """对标 UpdateFactionStateAsync: 注册/更新势力状态并追加完整快照

        change: FactionStateChange（FactionId/NewStatus/Event/Importance/CausedBy）
        """
        store = self._get_store()
        data = store.data()

        # 自动注册（对标 C#: 无则注册 + TryResolveFactionDisplayNameAsync,
        #             CurrentStatus = change.NewStatus）
        if change.FactionId not in data:
            display_name = (self.try_resolve_display_name(change.FactionId)
                            or change.FactionId)
            data[change.FactionId] = {
                "Name": display_name,
                "CurrentStatus": change.NewStatus or "",
                self.HISTORY_FIELD: [],
                "DriftWarnings": [],
            }

        entry = data[change.FactionId]
        # 补齐既有条目默认字段
        entry.setdefault("CurrentStatus", "active")
        entry.setdefault("DriftWarnings", [])
        history = entry.setdefault(self.HISTORY_FIELD, [])
        if not isinstance(history, list):
            history = []
            entry[self.HISTORY_FIELD] = history

        if change.NewStatus:
            entry["CurrentStatus"] = change.NewStatus

        # 完整快照（对标 C# FactionStatePoint 各字段）
        history.append({
            "Chapter": chapter_id,
            "Status": change.NewStatus,
            "Event": change.Event,
            "Importance": change.Importance if change.Importance else "normal",
            "CausedBy": change.CausedBy or "",
        })

        store.set_all(data)
        return entry

    # ---- 删除章节 ----

    def remove_chapter_data(self, chapter_id: str) -> int:
        """对标 RemoveChapterDataAsync: 删除历史 + 回填 CurrentStatus（否则 "unknown"）"""
        store = self._get_store()
        data = store.data()
        modified = False
        removed_total = 0

        for entry in list(data.values()):
            if not isinstance(entry, dict):
                continue
            history = entry.get(self.HISTORY_FIELD)
            if not isinstance(history, list):
                continue
            before = len(history)
            history[:] = [s for s in history
                          if not (s.get("Chapter", "") and s["Chapter"] == chapter_id)]
            removed = before - len(history)
            if removed > 0:
                modified = True
                removed_total += removed
                history.sort(key=lambda s: parse_chapter_id(s.get("Chapter", "")))
                # 回填 CurrentStatus：最后有 Status 的点，否则 "unknown"
                last_status = ""
                for s in reversed(history):
                    st = s.get("Status")
                    if st:
                        last_status = st
                        break
                entry["CurrentStatus"] = last_status if last_status else "unknown"

        if modified:
            store.set_all(data)
        return removed_total

    # ---- 查询 ----

    def get_all_faction_states(self) -> Dict[str, dict]:
        """对标 GetAllFactionStatesAsync: 合并全部势力（单文件直接全量）"""
        store = self._get_store()
        data = store.data()
        merged = {}
        for fid, entry in data.items():
            if isinstance(entry, dict):
                merged[fid] = entry
        return merged

    # ---- 势力名解析 ----

    def try_resolve_display_name(self, faction_id: str) -> Optional[str]:
        """对标 TryResolveFactionDisplayNameAsync: 从设计库 factionrules 解析势力名"""
        try:
            design = self.project.load_design("factions")
            items = design.get("items", []) if isinstance(design, dict) else (design or [])
            for item in items:
                if not isinstance(item, dict):
                    continue
                if str(item.get("Id", "")).lower() == str(faction_id).lower():
                    name = item.get("Name", "")
                    return name if name else None
            return None
        except Exception:
            return None