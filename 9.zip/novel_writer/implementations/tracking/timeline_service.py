# -*- coding: utf-8 -*-
"""时间线服务 — 对标 4.1.1 TimelineService.cs（完整移植 162 行）

对齐功能:
- UpdateTimeProgressionAsync（按章去重 + 追加 ChapterTimeEntry）
- UpdateCharacterMovementsAsync（自动注册 + MovementHistory）
- RemoveChapterDataAsync（删除时间线 + 回填角色位置）
- GetRecentTimelineAsync（最近 N 条按章节排序）
- GetAllCharacterLocationsAsync
"""

from typing import Dict, List, Optional

from .character_state_service import build_chapter_id, compare_chapter_id, parse_chapter_id


class TimelineService:
    """对标 4.1.1 TimelineService — 时间推进与角色移动管理（独立类）"""

    BaseFileName = "timeline_guide.json"
    TIMELINE_FIELD = "ChapterTimeline"
    LOCATIONS_FIELD = "CharacterLocations"
    MOVEMENT_FIELD = "MovementHistory"

    def __init__(self, project, tracking_manager=None):
        self.project = project
        self.tracking = tracking_manager
        self._timeline_store = None
        self._location_store = None

    def _get_timeline_store(self):
        if self._timeline_store is None:
            if self.tracking is not None:
                self._timeline_store = self.tracking._stores["timeline"]
            else:
                self._timeline_store = self.project.tracking("timeline")
        return self._timeline_store

    def _get_location_store(self):
        if self._location_store is None:
            if self.tracking is not None:
                self._location_store = self.tracking._stores["character_location"]
            else:
                self._location_store = self.project.tracking("character_location")
        return self._location_store

    # ---- 时间推进 ----

    def update_time_progression(self, chapter_id: str, change) -> Optional[dict]:
        """对标 UpdateTimeProgressionAsync: 按章去重后追加时间条目

        change: TimeProgressionChange（TimePeriod/ElapsedTime/KeyTimeEvent/Importance）
        """
        if change is None:
            return None
        if not change.TimePeriod and not change.ElapsedTime:
            return None

        store = self._get_timeline_store()
        data = store.data()
        timeline = data.setdefault(self.TIMELINE_FIELD, [])
        if not isinstance(timeline, list):
            timeline = []
            data[self.TIMELINE_FIELD] = timeline

        # 移除同章旧条目（对标 C# RemoveAll(t.ChapterId == chapterId)）
        timeline[:] = [t for t in timeline
                       if not (t.get("ChapterId", "") and t["ChapterId"] == chapter_id)]

        timeline.append({
            "ChapterId": chapter_id,
            "TimePeriod": change.TimePeriod,
            "ElapsedTime": change.ElapsedTime,
            "KeyTimeEvent": change.KeyTimeEvent,
            "Importance": change.Importance if change.Importance else "normal",
        })

        store.set_all(data)
        return timeline[-1]

    # ---- 角色移动 ----

    def update_character_movements(self, chapter_id: str, movements: list) -> int:
        """对标 UpdateCharacterMovementsAsync: 注册/更新角色位置 + MovementHistory"""
        if not movements:
            return 0

        store = self._get_location_store()
        data = store.data()
        count = 0

        for move in movements:
            if not move.CharacterId or not move.ToLocation:
                continue

            # 自动注册（对标 C#: 解析角色名，否则用 CharacterId）
            if move.CharacterId not in data:
                resolved_name = self._resolve_character_name(move.CharacterId)
                data[move.CharacterId] = {
                    "Name": resolved_name,
                    "CurrentLocation": move.ToLocation,
                    "LastUpdatedChapter": chapter_id,
                    self.MOVEMENT_FIELD: [],
                }

            entry = data[move.CharacterId]
            entry["CurrentLocation"] = move.ToLocation
            entry["LastUpdatedChapter"] = chapter_id

            # MovementHistory 完整快照（对标 C# MovementRecord）
            history = entry.setdefault(self.MOVEMENT_FIELD, [])
            if not isinstance(history, list):
                history = []
                entry[self.MOVEMENT_FIELD] = history
            history.append({
                "Chapter": chapter_id,
                "FromLocation": move.FromLocation,
                "ToLocation": move.ToLocation,
                "Importance": move.Importance if move.Importance else "normal",
            })
            count += 1

        store.set_all(data)
        return count

    def _resolve_character_name(self, character_id: str) -> str:
        """对标 C#: 从 character_state 解析角色名"""
        try:
            cs_store = None
            if self.tracking is not None:
                cs_store = self.tracking._stores["character_state"]
            else:
                cs_store = self.project.tracking("character_state")
            entry = cs_store.data().get(character_id)
            if isinstance(entry, dict) and entry.get("Name"):
                return entry["Name"]
        except Exception:
            pass
        return character_id

    # ---- 删除章节 ----

    def remove_chapter_data(self, chapter_id: str) -> int:
        """对标 RemoveChapterDataAsync: 删除时间线 + 回填角色位置"""
        removed_total = 0

        # 时间线
        tl_store = self._get_timeline_store()
        tl_data = tl_store.data()
        timeline = tl_data.get(self.TIMELINE_FIELD, [])
        if isinstance(timeline, list):
            before = len(timeline)
            timeline[:] = [t for t in timeline
                           if not (t.get("ChapterId", "") and t["ChapterId"] == chapter_id)]
            removed_total += before - len(timeline)
            if before != len(timeline):
                tl_data[self.TIMELINE_FIELD] = timeline
                tl_store.set_all(tl_data)

        # 角色位置
        loc_store = self._get_location_store()
        loc_data = loc_store.data()
        modified = False
        for entry in loc_data.values():
            if not isinstance(entry, dict):
                continue
            history = entry.get(self.MOVEMENT_FIELD)
            if not isinstance(history, list):
                continue
            before = len(history)
            history[:] = [m for m in history
                          if not (m.get("Chapter", "") and m["Chapter"] == chapter_id)]
            moves_removed = before - len(history)
            if moves_removed > 0:
                modified = True
                removed_total += moves_removed
                history.sort(key=lambda m: parse_chapter_id(m.get("Chapter", "")))
                if history:
                    last_move = history[-1]
                    entry["CurrentLocation"] = last_move.get("ToLocation", "")
                    entry["LastUpdatedChapter"] = last_move.get("Chapter", "")
                else:
                    entry["CurrentLocation"] = ""
                    entry["LastUpdatedChapter"] = ""

        if modified:
            loc_store.set_all(loc_data)
        return removed_total

    # ---- 查询 ----

    def get_recent_timeline(self, count: int = 5) -> List[dict]:
        """对标 GetRecentTimelineAsync: 按章节排序取最近 N 条"""
        store = self._get_timeline_store()
        data = store.data()
        timeline = data.get(self.TIMELINE_FIELD, [])
        if not isinstance(timeline, list):
            return []
        timeline.sort(key=lambda t: parse_chapter_id(t.get("ChapterId", "")))
        return timeline[-count:]

    def get_all_character_locations(self) -> Dict[str, dict]:
        """对标 GetAllCharacterLocationsAsync: 合并全部角色位置（单文件全量）"""
        store = self._get_location_store()
        data = store.data()
        return {cid: entry for cid, entry in data.items() if isinstance(entry, dict)}