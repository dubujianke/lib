# -*- coding: utf-8 -*-
"""冲突进度服务 — 对标 4.1.1 ConflictProgressService.cs（完整移植 179 行）

对齐功能:
- GetConflictProgressAsync（查最新卷的冲突）
- UpdateConflictProgressAsync（自动注册 + 完整快照 ProgressPoints + InvolvedChapters 维护）
- RemoveChapterDataAsync（删除章节进度 + 回填 Status + 重建 InvolvedChapters）
- GetActiveConflictsAsync（返回 active/climax 冲突，取最近5卷）
- TryResolveConflictDisplayNameAsync（从 plotrules 解析冲突名）

章节ID约定：vol{卷号}_ch{章号}（对齐 C# ChapterParserHelper）。
"""

from typing import Dict, List, Optional

from .character_state_service import build_chapter_id, compare_chapter_id, parse_chapter_id


class ConflictProgressService:
    """对标 4.1.1 ConflictProgressService — 冲突进度管理（独立类）"""

    BaseFileName = "conflict_progress_guide.json"
    PROGRESS_FIELD = "ProgressPoints"
    INVOLVED_FIELD = "InvolvedChapters"

    def __init__(self, project, tracking_manager=None):
        self.project = project
        self.tracking = tracking_manager
        self._store = None

    def _get_store(self):
        if self._store is None:
            if self.tracking is not None:
                self._store = self.tracking._stores["conflict_progress"]
            else:
                self._store = self.project.tracking("conflict_progress")
        return self._store

    # ---- 查询 ----

    def get_conflict_progress(self, conflict_id: str) -> Optional[dict]:
        """对标 GetConflictProgressAsync: 从最新卷向下查（单文件直接查）"""
        store = self._get_store()
        data = store.data()
        entry = data.get(conflict_id)
        return entry if isinstance(entry, dict) else None

    def get_active_conflicts(self, limit_volumes: int = 5) -> List[dict]:
        """对标 GetActiveConflictsAsync: 返回 Status 为 active/climax 的冲突"""
        store = self._get_store()
        data = store.data()
        result = []
        for entry in data.values():
            if not isinstance(entry, dict):
                continue
            status = str(entry.get("Status", "")).lower()
            if status in ("active", "climax"):
                result.append(entry)
        return result

    # ---- 更新 ----

    def update_conflict_progress(self, chapter_id: str, change) -> dict:
        """对标 UpdateConflictProgressAsync: 注册/更新冲突并追加完整快照

        change: ConflictProgressChange（ConflictId/NewStatus/Event/Importance/CausedBy）
        """
        store = self._get_store()
        data = store.data()

        # 自动注册（对标 C#: 无则注册 + TryResolveConflictDisplayNameAsync, Status="pending", Tier="Tier-3"）
        if change.ConflictId not in data:
            display_name = (self.try_resolve_display_name(change.ConflictId)
                            or change.ConflictId)
            data[change.ConflictId] = {
                "Name": display_name,
                "Type": "",
                "Tier": "Tier-3",
                "Status": "pending",
                "LastEvent": "", "LastChapter": 0,
                "InvolvedCharacters": [],
                "DriftWarnings": [],
                self.PROGRESS_FIELD: [],
                self.INVOLVED_FIELD: [],
            }

        entry = data[change.ConflictId]
        # 补齐既有条目的默认字段（对标 C# 反序列化默认值）
        entry.setdefault("Type", "")
        entry.setdefault("Tier", "Tier-3")
        entry.setdefault("Status", "pending")
        entry.setdefault("InvolvedCharacters", [])
        entry.setdefault("DriftWarnings", [])
        old_status = entry.get("Status", "")

        if change.NewStatus:
            entry["Status"] = change.NewStatus

        # 追加完整快照（对标 C# ConflictProgressPoint 各字段）
        points = entry.setdefault(self.PROGRESS_FIELD, [])
        if not isinstance(points, list):
            points = []
            entry[self.PROGRESS_FIELD] = points
        points.append({
            "Chapter": chapter_id,
            "Event": change.Event,
            "Status": change.NewStatus,
            "Description": f"{old_status} → {change.NewStatus}",
            "Importance": change.Importance if change.Importance else "normal",
            "CausedBy": change.CausedBy or "",
        })

        # InvolvedChapters 去重追加（对标 C#）
        involved = entry.setdefault(self.INVOLVED_FIELD, [])
        if not isinstance(involved, list):
            involved = []
            entry[self.INVOLVED_FIELD] = involved
        if chapter_id not in involved:
            involved.append(chapter_id)

        # 同步顶层字段（最新状态镜像）
        entry["LastEvent"] = change.Event if change.Event else entry.get("LastEvent", "")
        entry["LastChapter"] = parse_chapter_id(chapter_id)[1]

        store.set_all(data)
        return entry

    # ---- 删除章节 ----

    def remove_chapter_data(self, chapter_id: str) -> int:
        """对标 RemoveChapterDataAsync: 删除章节进度 + 回填 Status + 重建 InvolvedChapters"""
        store = self._get_store()
        data = store.data()
        modified = False
        removed_total = 0

        for entry in list(data.values()):
            if not isinstance(entry, dict):
                continue
            points = entry.get(self.PROGRESS_FIELD)
            if not isinstance(points, list):
                continue
            before = len(points)
            points[:] = [p for p in points
                         if not (p.get("Chapter", "") and p["Chapter"] == chapter_id)]
            removed = before - len(points)
            if removed > 0:
                modified = True
                removed_total += removed

            involved = entry.get(self.INVOLVED_FIELD)
            if isinstance(involved, list) and chapter_id in involved:
                involved.remove(chapter_id)
                modified = True

            if removed > 0:
                # 重排（对标 C# Sort）
                points.sort(key=lambda p: parse_chapter_id(p.get("Chapter", "")))

                # 回填 Status：最后一个有 Status 的 ProgressPoint.Status，否则 pending
                last_status = ""
                for p in reversed(points):
                    s = p.get("Status")
                    if s:
                        last_status = s
                        break
                new_status = last_status if last_status else "pending"
                if str(entry.get("Status", "")).lower() != str(new_status).lower():
                    entry["Status"] = new_status
                    modified = True

                # 重建 InvolvedChapters：从 ProgressPoints 取去重排序的章节
                rebuilt = sorted(
                    {p.get("Chapter", "") for p in points
                     if p.get("Chapter") and str(p.get("Chapter", "")).strip()},
                    key=lambda c: parse_chapter_id(c))
                if len(involved) != len(rebuilt) or involved != rebuilt:
                    entry[self.INVOLVED_FIELD] = rebuilt
                    modified = True

        if modified:
            store.set_all(data)
        return removed_total

    # ---- 冲突名解析 ----

    def try_resolve_display_name(self, conflict_id: str) -> Optional[str]:
        """对标 TryResolveConflictDisplayNameAsync: 从设计库 plotrules 解析冲突名"""
        try:
            design = self.project.load_design("plot")
            items = design.get("items", []) if isinstance(design, dict) else (design or [])
            for item in items:
                if not isinstance(item, dict):
                    continue
                if str(item.get("Id", "")).lower() == str(conflict_id).lower():
                    name = item.get("Name", "")
                    return name if name else None
            return None
        except Exception:
            return None