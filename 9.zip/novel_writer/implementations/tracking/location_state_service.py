# -*- coding: utf-8 -*-
"""地点状态服务 — 对标 4.1.1 LocationStateService.cs（完整移植 129 行）

对齐功能:
- UpdateLocationStateAsync（自动注册 + 完整快照）
- RemoveChapterDataAsync（删除历史 + 回填 CurrentStatus，否则 "unknown"）
- GetAllLocationStatesAsync
- TryResolveLocationDisplayNameAsync（从 locationrules 解析地点名）
"""

from typing import Dict, List, Optional

from .character_state_service import build_chapter_id, parse_chapter_id


class LocationStateService:
    """对标 4.1.1 LocationStateService — 地点状态管理（独立类）"""

    BaseFileName = "location_state_guide.json"
    HISTORY_FIELD = "StateHistory"

    def __init__(self, project, tracking_manager=None):
        self.project = project
        self.tracking = tracking_manager
        self._store = None

    def _get_store(self):
        if self._store is None:
            if self.tracking is not None:
                self._store = self.tracking._stores["location_state"]
            else:
                self._store = self.project.tracking("location_state")
        return self._store

    # ---- 更新 ----

    def update_location_state(self, chapter_id: str, change) -> dict:
        """对标 UpdateLocationStateAsync: 注册/更新地点状态并追加完整快照

        change: LocationStateChange（LocationId/LocationName/NewStatus/Event/Importance）
        """
        store = self._get_store()
        data = store.data()

        # 自动注册（对标 C#: Name=change.LocationName 或解析名，CurrentStatus=NewStatus）
        if change.LocationId not in data:
            display_name = (change.LocationName if change.LocationName
                            else self.try_resolve_display_name(change.LocationId)
                            or change.LocationId)
            data[change.LocationId] = {
                "Name": display_name,
                "CurrentStatus": change.NewStatus or "",
                self.HISTORY_FIELD: [],
                "DriftWarnings": [],
            }

        entry = data[change.LocationId]
        # 补齐默认字段
        entry.setdefault("CurrentStatus", "normal")
        entry.setdefault("DriftWarnings", [])
        history = entry.setdefault(self.HISTORY_FIELD, [])
        if not isinstance(history, list):
            history = []
            entry[self.HISTORY_FIELD] = history

        if change.NewStatus:
            entry["CurrentStatus"] = change.NewStatus

        # 完整快照（对标 C# LocationStatePoint）
        history.append({
            "Chapter": chapter_id,
            "Status": change.NewStatus,
            "Event": change.Event,
            "Importance": change.Importance if change.Importance else "normal",
        })

        store.set_all(data)
        return entry

    # ---- 删除章节 ----

    def remove_chapter_data(self, chapter_id: str) -> int:
        """对标 RemoveChapterDataAsync: 删除历史 + 回填 CurrentStatus（否则 "unknown"）"""
        store = self._get_store()
        data = store.data()
        modified = False
        removed_total = 0

        for entry in list(data.values()):
            if not isinstance(entry, dict):
                continue
            history = entry.get(self.HISTORY_FIELD)
            if not isinstance(history, list):
                continue
            before = len(history)
            history[:] = [s for s in history
                          if not (s.get("Chapter", "") and s["Chapter"] == chapter_id)]
            removed = before - len(history)
            if removed > 0:
                modified = True
                removed_total += removed
                history.sort(key=lambda s: parse_chapter_id(s.get("Chapter", "")))
                last_status = ""
                for s in reversed(history):
                    st = s.get("Status")
                    if st:
                        last_status = st
                        break
                entry["CurrentStatus"] = last_status if last_status else "unknown"

        if modified:
            store.set_all(data)
        return removed_total

    # ---- 查询 ----

    def get_all_location_states(self) -> Dict[str, dict]:
        """对标 GetAllLocationStatesAsync: 合并全部地点（单文件全量）"""
        store = self._get_store()
        data = store.data()
        return {lid: entry for lid, entry in data.items() if isinstance(entry, dict)}

    # ---- 地点名解析 ----

    def try_resolve_display_name(self, location_id: str) -> Optional[str]:
        """对标 TryResolveLocationDisplayNameAsync: 从设计库 locationrules 解析地点名"""
        try:
            design = self.project.load_design("locations")
            items = design.get("items", []) if isinstance(design, dict) else (design or [])
            for item in items:
                if not isinstance(item, dict):
                    continue
                if str(item.get("Id", "")).lower() == str(location_id).lower():
                    name = item.get("Name", "")
                    return name if name else None
            return None
        except Exception:
            return None