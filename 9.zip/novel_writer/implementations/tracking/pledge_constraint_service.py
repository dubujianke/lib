# -*- coding: utf-8 -*-
"""承诺/契约约束服务 — 对标 4.1.1 PledgeConstraintService.cs（完整移植 258 行）

对齐功能:
- UpdatePledgeAsync（守卫 + ID归并 + create + 动作状态机 + History完整快照）
- RefreshOverdueStatusAsync（按章距判定逾期）
- RemoveChapterDataAsync（删除历史 + 回填状态 + 清理空条目）
- ExtractSnapshotAsync（导出 active 承诺快照）
- FindExistingPledgeId（按 ID/Name 归并）
"""

from typing import Dict, List, Optional

from .character_state_service import build_chapter_id, parse_chapter_id
from .deadline_constraint_service import _is_likely_id, _new_deadline_id


def _new_pledge_id() -> str:
    """对标 ShortIdGenerator.New("PL"): 前缀首字符'P' + 12位 = 13位"""
    return _new_deadline_id().replace("D", "P", 1)


# 对标 C# 动作 → 状态 映射
_ACTION_STATUS = {
    "fulfill": "fulfilled",
    "break": "broken",
}


class PledgeConstraintService:
    """对标 4.1.1 PledgeConstraintService — 承诺/契约约束管理（独立类）"""

    BaseFileName = "pledge_constraint_guide.json"
    HISTORY_FIELD = "History"

    def __init__(self, project, tracking_manager=None):
        self.project = project
        self.tracking = tracking_manager
        self._store = None

    def _get_store(self):
        if self._store is None:
            if self.tracking is not None:
                self._store = self.tracking._stores["pledge"]
            else:
                self._store = self.project.tracking("pledge")
        return self._store

    # ---- ID 归并 ----

    @staticmethod
    def find_existing_pledge_id(data: dict, ai_pledge_id: str,
                                ai_pledge_name: str) -> Optional[str]:
        """对标 FindExistingPledgeId: 按 ID 或 Name 匹配已有承诺"""
        if ai_pledge_id and ai_pledge_id in data:
            return ai_pledge_id
        for pid, entry in data.items():
            if not isinstance(entry, dict):
                continue
            name = entry.get("Name", "")
            if name and str(name).lower() == str(ai_pledge_id).lower():
                return pid
            if ai_pledge_name and name and str(name).lower() == str(ai_pledge_name).lower():
                return pid
        return None

    # ---- 更新 ----

    def update_pledge(self, chapter_id: str, change) -> Optional[str]:
        """对标 UpdatePledgeAsync: 更新/创建承诺

        change: PledgeConstraintChange（PledgeId/PledgeName/Action/Type/PartyIds/Condition/Consequence/KeyEvent/Importance）
        """
        if not change.PledgeId and not change.PledgeName:
            return None
        if not change.Action:
            return None

        store = self._get_store()
        data = store.data()

        system_id = self.find_existing_pledge_id(data, change.PledgeId, change.PledgeName)

        if system_id is None and str(change.Action).lower() == "create":
            system_id = change.PledgeId if _is_likely_id(change.PledgeId) else _new_pledge_id()
            display_name = (change.PledgeName if change.PledgeName
                            else (change.PledgeId if change.PledgeId else system_id))
            data[system_id] = {
                "Name": display_name,
                "Type": change.Type if change.Type else "pledge",
                "CurrentStatus": "active",
                "PartyIds": list(change.PartyIds or []),
                "Condition": change.Condition or "",
                "Consequence": change.Consequence or "",
                self.HISTORY_FIELD: [],
                "IsOverdue": False,
                "DriftWarnings": [],
            }

        if system_id is None:
            return None

        entry = data[system_id]
        # 补齐默认字段
        entry.setdefault("Type", "pledge")
        entry.setdefault("CurrentStatus", "active")
        entry.setdefault("PartyIds", [])
        entry.setdefault("Condition", "")
        entry.setdefault("Consequence", "")
        entry.setdefault("IsOverdue", False)
        entry.setdefault("DriftWarnings", [])
        history = entry.setdefault(self.HISTORY_FIELD, [])
        if not isinstance(history, list):
            history = []
            entry[self.HISTORY_FIELD] = history

        if change.PledgeName:
            entry["Name"] = change.PledgeName

        action = str(change.Action).lower()
        if action in _ACTION_STATUS:
            entry["CurrentStatus"] = _ACTION_STATUS[action]
        elif action == "update":
            if change.Condition:
                entry["Condition"] = change.Condition
            if change.Consequence:
                entry["Consequence"] = change.Consequence
            if change.PartyIds:
                party = entry["PartyIds"]
                if not isinstance(party, list):
                    party = []
                    entry["PartyIds"] = party
                for pid in change.PartyIds:
                    if pid and str(pid).strip() and not any(
                            str(p).lower() == str(pid).lower() for p in party):
                        party.append(pid)

        # History 完整快照（对标 C# PledgeConstraintPoint）
        history.append({
            "Chapter": chapter_id,
            "Action": change.Action,
            "KeyEvent": change.KeyEvent or "",
            "Importance": change.Importance if change.Importance else "normal",
        })

        store.set_all(data)
        return system_id

    # ---- 逾期刷新 ----

    def refresh_overdue_status(self, current_chapter_id: str, max_dangling_chapters: int) -> None:
        """对标 RefreshOverdueStatusAsync: 按章距判定 IsOverdue"""
        if max_dangling_chapters <= 0:
            return
        cp = parse_chapter_id(current_chapter_id)
        if cp == (0, 0):
            return

        store = self._get_store()
        data = store.data()
        modified = False

        for entry in data.values():
            if not isinstance(entry, dict):
                continue
            if str(entry.get("CurrentStatus", "")).lower() != "active":
                if entry.get("IsOverdue"):
                    entry["IsOverdue"] = False
                    modified = True
                continue

            history = entry.get(self.HISTORY_FIELD)
            first_point = history[0] if (isinstance(history, list) and history) else None
            if not first_point or not first_point.get("Chapter"):
                continue

            wp = parse_chapter_id(first_point["Chapter"])
            if wp == (0, 0):
                continue

            distance = (cp[0] - wp[0]) * 100 + (cp[1] - wp[1])
            should_overdue = distance >= max_dangling_chapters

            if bool(entry.get("IsOverdue", False)) != should_overdue:
                entry["IsOverdue"] = should_overdue
                modified = True

        if modified:
            store.set_all(data)

    # ---- 删除章节 ----

    def remove_chapter_data(self, chapter_id: str) -> int:
        """对标 RemoveChapterDataAsync: 删除历史 + 回填状态 + 清理空条目"""
        store = self._get_store()
        data = store.data()
        modified = False
        removed_total = 0
        to_remove = []

        for pid, entry in list(data.items()):
            if not isinstance(entry, dict):
                continue
            history = entry.get(self.HISTORY_FIELD)
            if not isinstance(history, list):
                continue
            before = len(history)
            history[:] = [p for p in history
                          if not (p.get("Chapter", "") and p["Chapter"] == chapter_id)]
            removed = before - len(history)
            if removed > 0:
                modified = True
                removed_total += removed
                if len(history) == 0:
                    to_remove.append(pid)
                else:
                    last_status_action = ""
                    for h in reversed(history):
                        a = str(h.get("Action", "")).lower()
                        if a != "update":
                            last_status_action = a
                            break
                    new_status = _ACTION_STATUS.get(last_status_action, "active")
                    if str(entry.get("CurrentStatus", "")).lower() != str(new_status).lower():
                        entry["CurrentStatus"] = new_status
                    if (str(entry.get("CurrentStatus", "")).lower() != "active"
                            and entry.get("IsOverdue")):
                        entry["IsOverdue"] = False

        for pid in to_remove:
            data.pop(pid, None)

        if modified:
            store.set_all(data)
        return removed_total

    # ---- 快照 ----

    def extract_snapshot(self, chapter_id: str = "") -> List[dict]:
        """对标 ExtractSnapshotAsync: 导出 active 承诺快照"""
        store = self._get_store()
        data = store.data()
        result = []
        seen = set()
        for pid, entry in data.items():
            if not isinstance(entry, dict):
                continue
            if str(entry.get("CurrentStatus", "")).lower() != "active":
                continue
            if str(pid).lower() in seen:
                continue
            seen.add(str(pid).lower())
            history = entry.get(self.HISTORY_FIELD)
            last_chapter = ""
            if isinstance(history, list) and history:
                last_chapter = history[-1].get("Chapter", "") or ""
            result.append({
                "Id": pid,
                "Name": entry.get("Name", ""),
                "Type": entry.get("Type", "pledge"),
                "Status": entry.get("CurrentStatus", "active"),
                "PartyIds": ",".join((entry.get("PartyIds") or [])[:20]),
                "Condition": entry.get("Condition", ""),
                "Consequence": entry.get("Consequence", ""),
                "ChapterId": last_chapter,
                "IsOverdue": bool(entry.get("IsOverdue", False)),
            })
        return result