# -*- coding: utf-8 -*-
"""账本一致性校验 — 对标 Implementations/Tracking/LedgerConsistencyChecker.cs

C# 中为独立类（V1-V8 一致性检查：伏笔/冲突态序/角色等级/誓言/倒计时/移动链/物品归属/势力关系）。
Python 中该逻辑内联于 GenerationGate（gate.py）的一致性关卡 `_consistency_check`（对标 V1-V8）。
本文件提供与 C# 一致的独立入口 API，保证目录结构一一对应。
"""
from ...gate import GenerationGate
from ...models import ChapterChanges, FactSnapshot


class ConsistencyIssue:
    """对标 ConsistencyIssue"""
    def __init__(self, entity_id="", issue_type="", expected="", actual=""):
        self.EntityId = entity_id
        self.IssueType = issue_type
        self.Expected = expected
        self.Actual = actual


class ConsistencyResult:
    """对标 ConsistencyResult"""
    def __init__(self):
        self.Issues = []
        self.Success = True

    @property
    def HasIssues(self) -> bool:
        return len(self.Issues) > 0

    def AddIssue(self, issue: ConsistencyIssue):
        self.Issues.append(issue)
        self.Success = False


class LedgerConsistencyChecker:
    """对标 LedgerConsistencyChecker：委托 GenerationGate 一致性关卡"""

    def __init__(self):
        self._gate = GenerationGate()

    def Validate(self, changes: ChapterChanges, fact_snapshot: FactSnapshot, rule_set=None) -> ConsistencyResult:
        """对标 Validate(ChapterChanges, FactSnapshot) 与三参重载"""
        result = ConsistencyResult()
        if changes is None:
            result.AddIssue(ConsistencyIssue(entity_id="", issue_type="NullChanges",
                                             expected="CHANGES对象不为空", actual="CHANGES对象为空"))
            return result
        errors = self._gate._consistency_check(changes, fact_snapshot,
                                               ruleset=rule_set if rule_set is not None else None)
        for err in errors:
            etype = "Consistency"
            expected, actual = "", ""
            if "不可回退" in err or "未埋设" in err or "同一章节" in err or "重复" in err:
                etype = "ForeshadowingConsistency"
            result.AddIssue(ConsistencyIssue(issue_type=etype, expected=expected, actual=err))
        result.Success = not result.HasIssues
        return result

    def ValidateStructuralOnly(self, changes: ChapterChanges) -> ConsistencyResult:
        """对标 ValidateStructuralOnly：不依赖完整快照的结构一致性"""
        result = ConsistencyResult()
        if changes is None:
            return result
        empty = FactSnapshot()
        errors = self._gate._consistency_check(changes, empty, ruleset=None)
        for err in errors:
            if any(k in err for k in ("先埋设", "不可回退", "路径", "持有者", "关系矛盾")):
                result.AddIssue(ConsistencyIssue(issue_type="StructuralConsistency",
                                                 expected="结构一致", actual=err))
        result.Success = not result.HasIssues
        return result