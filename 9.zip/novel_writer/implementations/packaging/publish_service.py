# -*- coding: utf-8 -*-
"""发布服务 — 对标 Implementations/Packaging/PublishService.cs（partial 4 文件）

核心：打包发布（构建 guide 文件 + 生成 manifest + 版本管理）
"""
import json
import os
from typing import Dict, List, Optional

from ...models.publishing.publish_result import (
    PublishResult, PublishStatus, ManifestInfo, StatisticsInfo,
)


class PublishService:
    def __init__(self, project, guide_index_builder=None):
        self.project = project
        self._guide_index_builder = guide_index_builder
        self._manifest_cache = None

    def get_manifest(self) -> Optional[ManifestInfo]:
        if self._manifest_cache is not None:
            return self._manifest_cache
        path = os.path.join(self.project.dir, "manifest.json")
        if not os.path.exists(path):
            return None
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self._manifest_cache = ManifestInfo.from_dict(data)
            return self._manifest_cache
        except Exception:
            return None

    def needs_republish(self) -> bool:
        manifest = self.get_manifest()
        return manifest is None

    def clear_cache(self):
        self._manifest_cache = None

    def publish(self, enabled_modules: Dict[str, Dict[str, bool]] = None) -> PublishResult:
        """对标 PublishAsync: 执行打包"""
        try:
            manifest = self.get_manifest()
            version = (manifest.Version + 1) if manifest else 1
            # 生成 guide 文件
            self._generate_guides()
            # 生成 manifest
            statistics = self._build_statistics()
            manifest = ManifestInfo(
                ProjectName=self.project.name,
                PublishTime=self._now(),
                Version=version,
                Files={},
                EnabledModules=enabled_modules or {},
                Statistics=statistics)
            self._save_manifest(manifest)
            self._manifest_cache = manifest
            return PublishResult.success(version, [])
        except Exception as e:
            return PublishResult.failed(f"打包失败: {e}")

    def _generate_guides(self):
        """对标 GuideGeneration: 生成 guide 文件"""
        guides_dir = os.path.join(self.project.dir, "guides")
        os.makedirs(guides_dir, exist_ok=True)

    def _build_statistics(self) -> StatisticsInfo:
        return StatisticsInfo(
            TotalCharacters=len(self._load_design("characters")),
            TotalLocations=len(self._load_design("locations")),
            TotalChapters=len(self._load_plan("chapters")),
            TotalWords=0)

    def _save_manifest(self, manifest: ManifestInfo):
        path = os.path.join(self.project.dir, "manifest.json")
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(manifest.to_dict(), f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)

    def _load_design(self, entity: str) -> list:
        data = self.project.load_design(entity)
        if isinstance(data, dict):
            return data.get("items", [])
        return data or []

    def _load_plan(self, entity: str) -> list:
        data = self.project.load_plan(entity)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return data.get(entity, data.get("items", []))
        return []

    @staticmethod
    def _now() -> str:
        import time
        return time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())
