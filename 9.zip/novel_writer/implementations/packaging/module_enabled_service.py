# -*- coding: utf-8 -*-
"""模块启用服务 — 对标 Implementations/Packaging/ModuleEnabledService.cs"""
import json
import os
from typing import Tuple


class ModuleEnabledService:
    def __init__(self, project):
        self.project = project

    def get_module_enabled(self, module_type: str, sub_module: str) -> bool:
        enabled, _ = self.get_module_enabled_stats(module_type, sub_module)
        return enabled > 0

    def get_module_enabled_stats(self, module_type: str, sub_module: str) -> Tuple[int, int]:
        total_enabled = 0
        total_count = 0
        design_dir = self.project.design_dir
        if os.path.exists(design_dir):
            for f in os.listdir(design_dir):
                if not f.endswith(".json"):
                    continue
                enabled, total = self._count_enabled_in_file(os.path.join(design_dir, f))
                total_enabled += enabled
                total_count += total
        return (total_enabled, total_count)

    def set_module_enabled(self, module_type: str, sub_module: str, enabled: bool) -> int:
        updated = 0
        design_dir = self.project.design_dir
        if os.path.exists(design_dir):
            for f in os.listdir(design_dir):
                if not f.endswith(".json"):
                    continue
                updated += self._set_enabled_in_file(os.path.join(design_dir, f), enabled)
        return updated

    def _count_enabled_in_file(self, file_path: str) -> Tuple[int, int]:
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            items = data.get("items", []) if isinstance(data, dict) else (data or [])
            enabled = sum(1 for i in items if isinstance(i, dict) and i.get("IsEnabled", True))
            return (enabled, len(items))
        except Exception:
            return (0, 0)

    def _set_enabled_in_file(self, file_path: str, enabled: bool) -> int:
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            items = data.get("items", []) if isinstance(data, dict) else (data or [])
            updated = 0
            for item in items:
                if isinstance(item, dict):
                    item["IsEnabled"] = enabled
                    updated += 1
            if isinstance(data, dict):
                data["items"] = items
            else:
                data = items
            tmp = file_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, file_path)
            return updated
        except Exception:
            return 0
