# -*- coding: utf-8 -*-
"""上下文完整性检查器 — 对标 Implementations/Packaging/ContextIdsCompletenessChecker.cs"""
import os
from typing import List


class ForeshadowingWarning:
    def __init__(self):
        self.ForeshadowId = ""
        self.Name = ""
        self.Tier = ""
        self.SetupChapter = ""
        self.Issue = ""


class ConflictWarning:
    def __init__(self):
        self.ConflictId = ""
        self.Name = ""
        self.Tier = ""
        self.Status = ""
        self.Issue = ""


class EmptyContextWarning:
    def __init__(self):
        self.ChapterId = ""
        self.Title = ""
        self.Issue = ""


class CompletenessWarnings:
    def __init__(self):
        self.GeneratedAt = ""
        self.Summary = ""
        self.ForeshadowingWarnings: List[ForeshadowingWarning] = []
        self.ConflictWarnings: List[ConflictWarning] = []
        self.EmptyContextWarnings: List[EmptyContextWarning] = []


class ContextIdsCompletenessChecker:
    def __init__(self, project, guide_context_service=None):
        self.project = project
        self._guide_context_service = guide_context_service

    def run(self) -> CompletenessWarnings:
        warnings = CompletenessWarnings()
        try:
            self._check(warnings)
            warnings.Summary = (f"伏笔孤立: {len(warnings.ForeshadowingWarnings)} 个 / "
                                f"冲突孤立: {len(warnings.ConflictWarnings)} 个 / "
                                f"空ContextIds章节: {len(warnings.EmptyContextWarnings)} 个")
        except Exception:
            pass
        return warnings

    def _check(self, warnings: CompletenessWarnings):
        # 伏笔未回收检测
        fs_data = self.project.tracking("foreshadowing").data()
        for fid, entry in fs_data.items():
            if not isinstance(entry, dict):
                continue
            if entry.get("IsSetup") and not entry.get("IsResolved") and entry.get("Name"):
                w = ForeshadowingWarning()
                w.ForeshadowId = fid
                w.Name = entry.get("Name", "")
                w.Tier = entry.get("Tier", "")
                w.SetupChapter = entry.get("ActualSetupChapter", "")
                w.Issue = "已埋设，但无任何章节的 ContextIds.ForeshadowingPayoffs 包含它"
                warnings.ForeshadowingWarnings.append(w)

        # 冲突未解决检测
        cp_data = self.project.tracking("conflict_progress").data()
        for cid, entry in cp_data.items():
            if not isinstance(entry, dict):
                continue
            if str(entry.get("Status", "")).lower() != "resolved" and entry.get("Name"):
                w = ConflictWarning()
                w.ConflictId = cid
                w.Name = entry.get("Name", "")
                w.Tier = entry.get("Tier", "")
                w.Status = entry.get("Status", "")
                w.Issue = "冲突仍活跃未 resolved，但无任何章节的 ContextIds.Conflicts 包含它"
                warnings.ConflictWarnings.append(w)
