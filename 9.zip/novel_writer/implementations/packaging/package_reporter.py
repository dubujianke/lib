# -*- coding: utf-8 -*-
"""打包报告器 — 对标 Implementations/Packaging/PackageReporter.cs"""
import json
import os
from typing import Dict, List


class ChapterStat:
    def __init__(self):
        self.Title = ""
        self.Characters = 0
        self.Locations = 0
        self.Factions = 0
        self.PlotRules = 0
        self.Conflicts = 0
        self.ForeshadowingSetups = 0
        self.ForeshadowingPayoffs = 0
        self.Scenes = 0

    def to_dict(self):
        return self.__dict__


class VolumeStat:
    def __init__(self):
        self.VolumeNumber = 0
        self.ChapterCount = 0
        self.TotalCharacters = 0
        self.TotalLocations = 0
        self.TotalFactions = 0
        self.UniqueCharacters = 0
        self.UniqueLocations = 0
        self.UniqueFactions = 0

    def to_dict(self):
        return self.__dict__


class PackageReport:
    def __init__(self):
        self.GeneratedAt = ""
        self.Version = 0
        self.Summary = ""
        self.ChapterStats: Dict[str, ChapterStat] = {}
        self.VolumeStats: Dict[str, VolumeStat] = {}
        self.AnomalyWarnings: List[str] = []


class PackageReporter:
    def __init__(self, project):
        self.project = project

    def run(self, version: int, previous_report_path: str = None) -> PackageReport:
        import time
        report = PackageReport()
        report.GeneratedAt = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())
        report.Version = version
        try:
            self._collect_chapter_stats(report)
            self._aggregate_volume_stats(report)
            if previous_report_path and os.path.exists(previous_report_path):
                self._detect_anomalies(previous_report_path, report)
            report.Summary = (f"版本 {version}：{len(report.ChapterStats)} 章节、{len(report.VolumeStats)} 卷；"
                              f"{len(report.AnomalyWarnings)} 项异常波动")
        except Exception:
            pass
        return report

    def _collect_chapter_stats(self, report: PackageReport):
        chapters = self._load_plan("chapters")
        for ch in chapters:
            stat = ChapterStat()
            stat.Title = ch.get("ChapterTitle", "")
            stat.Characters = len(ch.get("ReferencedCharacterNames") or [])
            stat.Locations = len(ch.get("ReferencedLocationNames") or [])
            stat.Factions = len(ch.get("ReferencedFactionNames") or [])
            report.ChapterStats[ch.get("Id", "")] = stat

    def _aggregate_volume_stats(self, report: PackageReport):
        from ...character_state_service import parse_chapter_id
        buckets = {}
        for ch in self._load_plan("chapters"):
            cid = ch.get("Id", "")
            vol, _ = parse_chapter_id(cid)
            if not vol:
                vol = ch.get("VolumeNumber", 1)
            if vol not in buckets:
                buckets[vol] = {"chapter_count": 0, "chars": set(), "locs": set(), "facs": set()}
            b = buckets[vol]
            b["chapter_count"] += 1
            b["chars"].update(ch.get("ReferencedCharacterNames") or [])
            b["locs"].update(ch.get("ReferencedLocationNames") or [])
            b["facs"].update(ch.get("ReferencedFactionNames") or [])
        for vol, b in buckets.items():
            stat = VolumeStat()
            stat.VolumeNumber = vol
            stat.ChapterCount = b["chapter_count"]
            stat.UniqueCharacters = len(b["chars"])
            stat.UniqueLocations = len(b["locs"])
            stat.UniqueFactions = len(b["facs"])
            report.VolumeStats[f"vol{vol}"] = stat

    def _detect_anomalies(self, previous_path: str, report: PackageReport):
        try:
            with open(previous_path, "r", encoding="utf-8") as f:
                prev = json.load(f)
        except Exception:
            return

    def _load_plan(self, entity: str) -> list:
        data = self.project.load_plan(entity)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return data.get(entity, data.get("items", []))
        return []
