# -*- coding: utf-8 -*-
"""校验摘要服务 — 对标 4.1.1 Validation/ValidationSummaryService.cs（完整移植）

对齐功能:
- 校验摘要数据 CRUD（GetAllData/GetDataById/GetDataByVolumeNumber/AddData/UpdateData/DeleteData）
- 卷校验专用（SaveVolumeValidation/ParseVolumeNumber/GetAllCategories）
- 数据持久化（JSON 落盘 + 原子写 + 队列保存）
"""

import json
import os
import re
import threading
from typing import Dict, List, Optional

from ...models.common import short_id

_VOLUME_NUMBER_RE = re.compile(r"^第(\d+)卷")


class ValidationSummaryData:
    """对标 C# ValidationSummaryData 模型"""

    def __init__(self, **kwargs):
        self.Id = kwargs.pop("Id", "")
        self.Name = kwargs.pop("Name", "")
        self.Icon = kwargs.pop("Icon", "")
        self.Category = kwargs.pop("Category", "")
        self.CategoryId = kwargs.pop("CategoryId", "")
        self.TargetVolumeNumber = kwargs.pop("TargetVolumeNumber", 0)
        self.TargetVolumeName = kwargs.pop("TargetVolumeName", "")
        self.SampledChapterCount = kwargs.pop("SampledChapterCount", 0)
        self.SampledChapterIds = kwargs.pop("SampledChapterIds", [])
        self.LastValidatedTime = kwargs.pop("LastValidatedTime", "")
        self.CreatedTime = kwargs.pop("CreatedTime", "")
        self.ModifiedTime = kwargs.pop("ModifiedTime", "")
        self.OverallResult = kwargs.pop("OverallResult", "未校验")
        self.ModuleResults = kwargs.pop("ModuleResults", [])
        self.DependencyModuleVersions = kwargs.pop("DependencyModuleVersions", {})

    def to_dict(self) -> dict:
        return {
            "Id": self.Id, "Name": self.Name, "Icon": self.Icon,
            "Category": self.Category, "CategoryId": self.CategoryId,
            "TargetVolumeNumber": self.TargetVolumeNumber,
            "TargetVolumeName": self.TargetVolumeName,
            "SampledChapterCount": self.SampledChapterCount,
            "SampledChapterIds": self.SampledChapterIds,
            "LastValidatedTime": self.LastValidatedTime,
            "CreatedTime": self.CreatedTime, "ModifiedTime": self.ModifiedTime,
            "OverallResult": self.OverallResult,
            "ModuleResults": self.ModuleResults,
            "DependencyModuleVersions": self.DependencyModuleVersions,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "ValidationSummaryData":
        return cls(**{k: v for k, v in data.items()})


class ValidationSummaryCategory:
    """对标 C# ValidationSummaryCategory"""

    def __init__(self, **kwargs):
        self.Id = kwargs.pop("Id", "")
        self.Name = kwargs.pop("Name", "")
        self.Icon = kwargs.pop("Icon", "")
        self.Order = kwargs.pop("Order", 0)
        self.IsBuiltIn = kwargs.pop("IsBuiltIn", False)
        self.IsEnabled = kwargs.pop("IsEnabled", True)


class ValidationSummaryService:
    """对标 C# ValidationSummaryService"""

    def __init__(self, project=None, volume_design_service=None):
        self.project = project
        self._volume_design_service = volume_design_service
        self._data_items: List[ValidationSummaryData] = []
        self._data_lock = threading.Lock()
        self._save_lock = threading.Lock()
        self._data_version = 0
        self._load_data()

    # ---- 数据目录 ----

    def _data_directory(self) -> str:
        if self.project is None:
            return ""
        path = os.path.join(self.project.dir, "validation_summary", "data")
        return path

    # ---- 数据操作 ----

    def get_all_data(self) -> List[ValidationSummaryData]:
        with self._data_lock:
            return list(self._data_items)

    def get_data_by_id(self, id: str) -> Optional[ValidationSummaryData]:
        if not id:
            return None
        with self._data_lock:
            return next((d for d in self._data_items if d.Id == id), None)

    def get_data_by_volume_number(self, volume_number: int) -> Optional[ValidationSummaryData]:
        with self._data_lock:
            return next((d for d in self._data_items if d.TargetVolumeNumber == volume_number), None)

    def add_data(self, data: ValidationSummaryData):
        if data is None:
            return
        if not data.Id:
            data.Id = short_id("D")
        data.CreatedTime = self._now()
        data.ModifiedTime = self._now()
        with self._data_lock:
            self._data_items.append(data)
        self._save_data_item(data)

    def update_data(self, data: ValidationSummaryData):
        if data is None:
            return
        data.ModifiedTime = self._now()
        self._save_data_item(data)

    def delete_data(self, id: str):
        if not id:
            return
        data = None
        with self._data_lock:
            for d in self._data_items:
                if d.Id == id:
                    data = d
                    self._data_items.remove(d)
                    break
        if data:
            self._delete_data_file(id)

    # ---- 分类操作 ----

    def get_all_categories(self) -> List[ValidationSummaryCategory]:
        categories = []
        if self._volume_design_service is not None:
            try:
                volumes = self._volume_design_service.get_all_volume_designs() \
                    if hasattr(self._volume_design_service, 'get_all_volume_designs') else []
                volumes = sorted(volumes, key=lambda v: v.get("VolumeNumber", 0))
                for v in volumes:
                    vn = v.get("VolumeNumber", 0)
                    name = f"第{vn}卷 {v.get('VolumeTitle', '')}".strip() if vn > 0 else v.get("Name", "")
                    categories.append(ValidationSummaryCategory(
                        Id=v.get("Id", ""), Name=name, Icon="Icon.Books",
                        Order=vn, IsEnabled=v.get("IsEnabled", True)))
            except Exception:
                pass
        return categories

    # ---- 卷校验专用 ----

    def save_volume_validation(self, volume_number: int, data: ValidationSummaryData):
        if data is None:
            return
        categories = self.get_all_categories()
        volume_category = next((c for c in categories if c.Order == volume_number), None)
        category_name = volume_category.Name if volume_category else f"第{volume_number}卷"

        data.TargetVolumeNumber = volume_number
        data.TargetVolumeName = category_name
        data.Name = f"{category_name}校验"
        data.Category = category_name
        if volume_category and volume_category.Id:
            data.CategoryId = volume_category.Id
        data.LastValidatedTime = self._now()

        existing = self.get_data_by_volume_number(volume_number)
        if existing:
            data.Id = existing.Id
            data.CreatedTime = existing.CreatedTime
            data.ModifiedTime = self._now()
            with self._data_lock:
                idx = next((i for i, d in enumerate(self._data_items) if d.Id == existing.Id), -1)
                if idx >= 0:
                    self._data_items[idx] = data
            self._save_data_item(data)
        else:
            self.add_data(data)

    @staticmethod
    def parse_volume_number(category_name: str) -> int:
        if not category_name:
            return -1
        m = _VOLUME_NUMBER_RE.match(category_name)
        if m:
            return int(m.group(1))
        return -1

    # ---- 持久化 ----

    def _load_data(self):
        data_dir = self._data_directory()
        if not data_dir or not os.path.exists(data_dir):
            return
        items = []
        try:
            for file in os.listdir(data_dir):
                if not file.endswith(".json"):
                    continue
                try:
                    with open(os.path.join(data_dir, file), "r", encoding="utf-8") as f:
                        data = json.load(f)
                    if isinstance(data, dict):
                        items.append(ValidationSummaryData.from_dict(data))
                except Exception:
                    continue
        except Exception:
            pass
        with self._data_lock:
            self._data_items = items

    def _save_data_item(self, data: ValidationSummaryData):
        data_dir = self._data_directory()
        if not data_dir:
            return
        try:
            os.makedirs(data_dir, exist_ok=True)
            file_path = os.path.join(data_dir, f"{data.Id}.json")
            tmp = file_path + ".tmp"
            with self._save_lock:
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(data.to_dict(), f, ensure_ascii=False, indent=2)
                os.replace(tmp, file_path)
        except Exception:
            pass

    def _delete_data_file(self, id: str):
        data_dir = self._data_directory()
        if not data_dir:
            return
        file_path = os.path.join(data_dir, f"{id}.json")
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
        except Exception:
            pass

    @staticmethod
    def _now() -> str:
        import time
        return time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())