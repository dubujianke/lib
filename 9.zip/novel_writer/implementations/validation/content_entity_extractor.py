# -*- coding: utf-8 -*-
"""正文实体提取器 — 对标 4.1.1 Validation/ContentEntityExtractor.cs（完整移植）

对齐功能:
- 从 FactSnapshot 构建已知实体名集合
- ExtractMentionedEntities（已知名匹配 + 引号对话名提取）
- GetUnknownEntities（返回未知名）
- IsLikelyName（排除常见词/标点/数字，2-6 字）
"""

import re
from typing import Iterable, List, Set

from ..tracking.entity_drift.entity_dimension_registry import name_exists_in_content

# 对标 C# QuotedDialogueRegex: "xxx"(说|道|问|答|笑|喊|叫|骂)
_QUOTED_DIALOGUE_RE = re.compile(r'["\u201c]([^"\u201d]{1,10}?)["\u201d](?:说|道|问|答|笑|喊|叫|骂)')

# 对标 C# IsLikelyName 的常见词黑名单
_COMMON_WORDS = {
    "什么", "怎么", "为什么", "这个", "那个", "他们", "我们", "你们",
    "是的", "不是", "好的", "可以", "没有", "知道", "应该", "可能",
    "不要", "不行", "别怕", "等等", "快走", "住手", "小心", "闭嘴",
    "是谁", "哪里", "如今", "现在", "以后", "罢了", "够了", "真的",
    "假的", "原来", "如此", "当然", "不必", "不许", "不能", "为何",
}


def _is_likely_name(text: str) -> bool:
    """对标 IsLikelyName: 2-6 字、无标点数字、非常见词"""
    if not text or len(text) > 6 or len(text) < 2:
        return False
    if any(c in "，。！？、；：""''（）【】《》" for c in text):
        return False
    if any(c.isdigit() for c in text):
        return False
    return text not in _COMMON_WORDS


class ContentEntityExtractor:
    """对标 C# ContentEntityExtractor"""

    def __init__(self, fact_snapshot=None, known_names: Iterable[str] = None):
        self._known_entity_names: Set[str] = set()

        if fact_snapshot is not None:
            for state in (fact_snapshot.CharacterStates or []):
                if state.Name:
                    self._known_entity_names.add(state.Name)
            for desc in (fact_snapshot.LocationDescriptions or []):
                if getattr(desc, "Name", ""):
                    self._known_entity_names.add(desc.Name)
            for desc in (fact_snapshot.CharacterDescriptions or []):
                if getattr(desc, "Name", ""):
                    self._known_entity_names.add(desc.Name)

        if known_names:
            for n in known_names:
                if n:
                    self._known_entity_names.add(n)

    def extract_mentioned_entities(self, content: str) -> Set[str]:
        """对标 ExtractMentionedEntities"""
        entities = set()
        if not content:
            return entities

        for name in self._known_entity_names:
            if name_exists_in_content(content, name):
                entities.add(name)

        for m in _QUOTED_DIALOGUE_RE.finditer(content):
            potential_name = m.group(1).strip()
            if potential_name not in self._known_entity_names and _is_likely_name(potential_name):
                entities.add(f"[未知]{potential_name}")

        return entities

    def get_unknown_entities(self, content: str) -> List[str]:
        """对标 GetUnknownEntities"""
        mentioned = self.extract_mentioned_entities(content)
        return [e.replace("[未知]", "") for e in mentioned if e.startswith("[未知]")]