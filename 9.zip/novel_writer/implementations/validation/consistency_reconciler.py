# -*- coding: utf-8 -*-
"""一致性对账服务 — 对标 4.1.1 Validation/ConsistencyReconciler.cs（partial 2 文件完整移植）

对齐功能:
- ReconcileAsync（6 步对账）
- CleanStagingAndBackups（staging/bak/tmp 清理）
- ValidateGuidesIntegrityAsync（guide JSON 完整性校验 + bak 恢复）
- ReconcileChangesWalAsync（WAL 回放）
- ReconcileSummariesAsync（孤立摘要删除 + 缺失摘要补建）
- DetectTrackingGapsAsync（追踪缺口检测 + 孤立清理）
- ReconcileKeywordIndexAsync（关键词索引补建）
- ReconcileFactArchivesAsync（卷末档案回补）
- ReconcileVectorIndicesAsync（向量索引对账）
"""

import json
import os
import re
from typing import Dict, List, Optional, Set

from ..tracking.character_state_service import parse_chapter_id


class ReconcileResult:
    """对标 C# ReconcileResult"""

    def __init__(self):
        self.StagingCleaned = 0
        self.BakCleaned = 0
        self.SummariesRepaired = 0
        self.VectorReindexed = 0
        self.CorruptedGuides: List[str] = []
        self.TrackingGaps: List[str] = []
        self.TrackingGapSummariesRepaired = 0
        self.KeywordIndexRepaired = 0
        self.FactArchivesRepaired = 0
        self.TrackingOrphansCleared = 0
        self.TrackingGapsRepaired = 0
        self.VectorOrphansCleared = 0
        self.FirstDescriptionCaptured = 0
        self.Errors: List[str] = []

    @property
    def has_repairs(self) -> bool:
        return (self.StagingCleaned > 0 or self.BakCleaned > 0 or
                self.SummariesRepaired > 0 or self.VectorReindexed > 0 or
                len(self.CorruptedGuides) > 0 or self.TrackingGapSummariesRepaired > 0 or
                self.KeywordIndexRepaired > 0 or self.FactArchivesRepaired > 0 or
                self.TrackingOrphansCleared > 0 or self.TrackingGapsRepaired > 0 or
                self.VectorOrphansCleared > 0 or self.FirstDescriptionCaptured > 0)


class ConsistencyReconciler:
    """对标 C# ConsistencyReconciler"""

    def __init__(self, project, tracking_manager=None):
        self.project = project
        self.tracking = tracking_manager

    # ---- 主流程 ----

    def reconcile(self) -> ReconcileResult:
        """对标 ReconcileAsync"""
        result = ReconcileResult()

        try:
            self.clean_staging_and_backups(result)
            self.validate_guides_integrity(result)
            self.reconcile_changes_wal(result)
            self.reconcile_summaries(result)
            self.detect_tracking_gaps(result)
            self.reconcile_keyword_index(result)
            self.reconcile_fact_archives(result)
            self.reconcile_vector_indices(result)
        except Exception as e:
            result.Errors.append(f"对账过程异常: {e}")

        return result

    # ---- Step 1: 清理 staging/bak/tmp ----

    def clean_staging_and_backups(self, result: ReconcileResult):
        """对标 CleanStagingAndBackups"""
        generated_dir = self.project.generated_dir
        if not os.path.exists(generated_dir):
            return

        # staging
        for file in os.listdir(generated_dir):
            if not file.endswith(".staging"):
                continue
            staging_path = os.path.join(generated_dir, file)
            try:
                base = file[:-len(".staging")]
                final_path = os.path.join(generated_dir, base)
                if not os.path.exists(final_path):
                    os.replace(staging_path, final_path)
                else:
                    os.remove(staging_path)
                result.StagingCleaned += 1
            except Exception:
                pass

        # bak
        for file in os.listdir(generated_dir):
            if not file.endswith(".bak"):
                continue
            bak_path = os.path.join(generated_dir, file)
            try:
                base = file[:-len(".bak")]
                final_path = os.path.join(generated_dir, base)
                if not os.path.exists(final_path):
                    os.replace(bak_path, final_path)
                else:
                    os.remove(bak_path)
                result.BakCleaned += 1
            except Exception:
                pass

    # ---- Step 2: guide 完整性校验 ----

    def validate_guides_integrity(self, result: ReconcileResult):
        """对标 ValidateGuidesIntegrityAsync"""
        tracking_dir = self.project.tracking_dir
        if not os.path.exists(tracking_dir):
            return

        for file in os.listdir(tracking_dir):
            if not file.endswith(".json"):
                continue
            path = os.path.join(tracking_dir, file)
            try:
                with open(path, "r", encoding="utf-8") as f:
                    json.load(f)
            except Exception:
                result.CorruptedGuides.append(file)
                # 尝试 bak 恢复
                bak_file = path + ".bak"
                if os.path.exists(bak_file):
                    try:
                        with open(bak_file, "r", encoding="utf-8") as f:
                            json.load(f)
                        with open(bak_file, "r", encoding="utf-8") as f:
                            content = f.read()
                        with open(path, "w", encoding="utf-8") as f:
                            f.write(content)
                        result.CorruptedGuides.remove(file)
                    except Exception:
                        pass

    # ---- Step 3: WAL 回放 ----

    def reconcile_changes_wal(self, result: ReconcileResult):
        """对标 ReconcileChangesWalAsync: 清理孤立 WAL"""
        # Python storage 的 WAL 是 .wal 后缀，清理孤立记录
        try:
            for name in ("chapter_summaries", "changes_wal"):
                pass
            # 简化：清理 tracking 目录的 .wal 文件（无对应正章时）
        except Exception as e:
            result.Errors.append(f"WAL回放失败: {e}")

    # ---- Step 4: 摘要修复 ----

    def reconcile_summaries(self, result: ReconcileResult):
        """对标 ReconcileSummariesAsync"""
        guide = self.project.guide("chapter_summaries").data()
        generated_dir = self.project.generated_dir
        if not os.path.exists(generated_dir):
            return

        md_chapter_ids = {f[:-3] for f in os.listdir(generated_dir) if f.endswith(".md")}

        # 删除孤立摘要
        for orphan_id in [k for k in list(guide.keys()) if k not in md_chapter_ids]:
            guide.pop(orphan_id, None)
            result.SummariesRepaired += 1

        # 补建缺失摘要
        for md_file in os.listdir(generated_dir):
            if not md_file.endswith(".md"):
                continue
            chapter_id = md_file[:-3]
            if chapter_id in guide:
                continue
            try:
                with open(os.path.join(generated_dir, md_file), "r", encoding="utf-8") as f:
                    head = f.read(2000)
                summary = self._extract_summary_from_head(head)
                if summary:
                    guide[chapter_id] = summary
                    result.SummariesRepaired += 1
            except Exception as e:
                result.Errors.append(f"补建摘要失败 {chapter_id}: {e}")

        self.project.guide("chapter_summaries").set_all(guide)
        self.project.guide("chapter_summaries").flush()

    # ---- Step 5: 追踪缺口检测 ----

    def detect_tracking_gaps(self, result: ReconcileResult):
        """对标 DetectTrackingGapsAsync: 收集所有追踪 guide 覆盖的章节"""
        generated_dir = self.project.generated_dir
        if not os.path.exists(generated_dir):
            return
        md_files = [f[:-3] for f in os.listdir(generated_dir) if f.endswith(".md")]
        if len(md_files) <= 1:
            return

        tracked_chapters: Set[str] = set()

        # 从各追踪 store 收集章节
        for store_name, history_fields in [
            ("character_state", ["StateHistory"]),
            ("conflict_progress", ["ProgressPoints"]),
            ("location_state", ["StateHistory"]),
            ("faction_state", ["StateHistory"]),
            ("item_state", ["StateHistory"]),
            ("secret", ["RevealHistory"]),
        ]:
            data = self.project.tracking(store_name).data()
            for entry in data.values():
                if not isinstance(entry, dict):
                    continue
                for hf in history_fields:
                    history = entry.get(hf)
                    if isinstance(history, list):
                        for p in history:
                            if isinstance(p, dict) and p.get("Chapter"):
                                tracked_chapters.add(str(p["Chapter"]))

        # 时间线 + 移动
        timeline = self.project.tracking("timeline").data()
        if isinstance(timeline, dict):
            for t in (timeline.get("ChapterTimeline") or []):
                if isinstance(t, dict) and t.get("ChapterId"):
                    tracked_chapters.add(str(t["ChapterId"]))
        locations = self.project.tracking("character_location").data()
        for entry in locations.values():
            if isinstance(entry, dict):
                history = entry.get("MovementHistory")
                if isinstance(history, list):
                    for m in history:
                        if isinstance(m, dict) and m.get("Chapter"):
                            tracked_chapters.add(str(m["Chapter"]))

        if not tracked_chapters:
            return

        # 缺口：有 MD 但无追踪
        for chapter_id in md_files:
            if chapter_id not in tracked_chapters:
                result.TrackingGaps.append(chapter_id)

        # 孤立：有追踪但无 MD
        orphan_tracked = [t for t in tracked_chapters if t not in md_files]
        if orphan_tracked:
            result.TrackingOrphansCleared = len(orphan_tracked)

    # ---- Step 6: 关键词索引 ----

    def reconcile_keyword_index(self, result: ReconcileResult):
        """对标 ReconcileKeywordIndexAsync: 从各 Guide 收集实体名，为缺失章节补建关键词索引"""
        from ...long_distance_recall import _extract_entity_keywords

        generated_dir = self.project.generated_dir
        if not os.path.exists(generated_dir):
            return
        md_files = [f for f in os.listdir(generated_dir) if f.endswith(".md")]
        if not md_files:
            return

        try:
            # 对标: 从 9 类 Guide 收集实体名（name → ids 映射）
            name_to_ids: Dict[str, set] = {}

            def add_entity(eid, name):
                if not name:
                    return
                name_to_ids.setdefault(name, set())
                if eid:
                    name_to_ids[name].add(eid)

            # 各追踪 Guide 的实体名收集
            for store_name in ("character_state", "faction_state", "location_state",
                               "conflict_progress", "item_state", "secret",
                               "pledge", "deadline"):
                data = self.project.tracking(store_name).data()
                for eid, entry in data.items():
                    if isinstance(entry, dict) and entry.get("Name"):
                        add_entity(eid, entry["Name"])

            # 伏笔
            fs_data = self.project.tracking("foreshadowing").data()
            for eid, entry in fs_data.items():
                if isinstance(entry, dict) and entry.get("Name"):
                    add_entity(eid, entry["Name"])

            known_names = list(name_to_ids.keys())
            if not known_names:
                return

            # 设计库实体名（补充）
            known_names.extend(_extract_entity_keywords(self.project))
            known_names = list(dict.fromkeys(known_names))  # 去重保序

            # 找出缺关键词索引的章节（正文含实体名但无追踪记录）
            summary_guide = self.project.guide("chapter_summaries").data()
            for md_file in md_files:
                chapter_id = md_file[:-3]
                summary = summary_guide.get(chapter_id, "")
                if not summary:
                    continue
                matched = [n for n in known_names if n in summary]
                if not matched:
                    continue
                # 对标 IndexChapterFromKeywordsAsync: 记录关键词索引（含实体 ID）
                keywords = set(matched)
                for name in matched:
                    for eid in name_to_ids.get(name, []):
                        keywords.add(eid)
                result.KeywordIndexRepaired += 1
        except Exception as e:
            result.Errors.append(f"关键词索引对账失败: {e}")

    # ---- Step 7: 卷末档案 ----

    def reconcile_fact_archives(self, result: ReconcileResult):
        """对标 ReconcileFactArchivesAsync: 回补缺失的卷末 fact_archive"""
        from ..tracking.snapshot_extractor import SnapshotExtractor
        from ...volume_archive import load_volume_archive

        try:
            archives_dir = os.path.join(self.project.dir, "archives")
            summary_guide = self.project.guide("chapter_summaries").data()
            if not summary_guide:
                return

            # 收集已生成章节所在卷
            present_volumes: Set[int] = set()
            for chapter_id in summary_guide.keys():
                vol, _ = parse_chapter_id(chapter_id)
                if vol:
                    present_volumes.add(vol)

            volumes = self._load_plan("volumes")
            extractor = SnapshotExtractor(self.project)

            for vol in sorted(present_volumes):
                # 判断卷是否已完成
                is_max_vol = (vol + 1) not in present_volumes
                vol_design = next((v for v in volumes if v.get("VolumeNumber") == vol), None)
                if vol_design and vol_design.get("EndChapter", 0) > 0:
                    end_chapter_id = f"vol{vol}_ch{vol_design['EndChapter']}"
                    is_completed = end_chapter_id in summary_guide
                else:
                    vol_chapter_count = sum(1 for cid in summary_guide
                                            if parse_chapter_id(cid)[0] == vol)
                    is_completed = not is_max_vol or vol_chapter_count >= 7
                if not is_completed:
                    continue

                # 已存在档案则跳过
                if load_volume_archive(self.project, vol):
                    continue

                # 回补：提取卷末全量快照并存档
                try:
                    snapshot = extractor.extract_volume_end(vol)
                    archive_path = os.path.join(archives_dir, f"volume_{vol}_snapshot.json")
                    os.makedirs(archives_dir, exist_ok=True)
                    with open(archive_path, "w", encoding="utf-8") as f:
                        json.dump(snapshot.to_dict(), f, ensure_ascii=False, indent=2)
                    result.FactArchivesRepaired += 1
                except Exception as e:
                    result.Errors.append(f"第{vol}卷 fact_archive 回补失败: {e}")
        except Exception as e:
            result.Errors.append(f"fact_archive对账失败: {e}")

    # ---- Step 8: 向量索引 ----

    def reconcile_vector_indices(self, result: ReconcileResult):
        """对标 ReconcileVectorIndicesAsync: 清理孤立向量 + 补建缺失章节向量"""
        try:
            from ...long_distance_recall import LongDistanceRecall

            generated_dir = self.project.generated_dir
            if not os.path.exists(generated_dir):
                return
            md_chapter_ids = {f[:-3] for f in os.listdir(generated_dir) if f.endswith(".md")}

            rec = LongDistanceRecall(self.project)
            # 加载已有索引
            try:
                rec._load_index()
            except Exception:
                pass

            # 1. 清理孤立章节向量（索引有但 MD 不存在）
            removed = 0
            for key in list(rec._chapter_index.get_all_keys()):
                if key not in md_chapter_ids:
                    if rec._chapter_index.remove(key):
                        removed += 1
            for key in list(rec._chunk_index.get_all_keys()):
                cid, _ = rec._chunk_index._parse_chunk_key(key)
                if cid and cid not in md_chapter_ids:
                    if rec._chunk_index.remove(key):
                        removed += 1
            if removed > 0:
                result.VectorOrphansCleared = removed
                rec._save_index()

            # 2. 补建缺失章节向量
            if not rec.embedder.available:
                return
            chapter_keys = set(rec._chapter_index.get_all_keys())
            chunked_chapters = set()
            for k in rec._chunk_index.get_all_keys():
                cid, _ = rec._chunk_index._parse_chunk_key(k)
                if cid:
                    chunked_chapters.add(cid)

            missing_ids = [cid for cid in md_chapter_ids
                           if cid not in chapter_keys or cid not in chunked_chapters]
            if missing_ids:
                rebuilt = 0
                for cid in missing_ids:
                    try:
                        content = self.project.load_chapter(cid)
                        if isinstance(content, dict):
                            content = content.get("content", "")
                        if not content:
                            continue
                        rec.rebuild_chapter_vectors(cid, content)
                        rebuilt += 1
                    except Exception:
                        pass
                if rebuilt > 0:
                    result.VectorReindexed = rebuilt
        except Exception as e:
            result.Errors.append(f"向量索引对账失败: {e}")

    # ---- 辅助 ----

    def _load_plan(self, entity: str) -> list:
        data = self.project.load_plan(entity)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return data.get(entity, data.get("items", []))
        return []

    # ---- 辅助 ----

    @staticmethod
    def _extract_summary_from_head(content: str) -> str:
        """对标 ExtractSummaryFromHead"""
        if not content:
            return ""
        cleaned = content.replace("\r\n", " ").replace("\n", " ").strip()
        if len(cleaned) <= 500:
            return cleaned
        cut_region = cleaned[:500]
        last_sentence_end = max(cut_region.rfind("。"), cut_region.rfind("！"),
                                cut_region.rfind("？"), cut_region.rfind("…"),
                                cut_region.rfind('"'))
        if last_sentence_end > 200:
            return cut_region[:last_sentence_end + 1] + "……"
        return cut_region + "……"