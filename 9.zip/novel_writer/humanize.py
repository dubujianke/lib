# -*- coding: utf-8 -*-
"""
对标 4.1.1 HumanizeRules: 完整移植
- ApplyPreLLMAsync: 归一化省略号/破折号 → 移除小说伪影 → 移除AI模板 → 移除AI填充词 → 数字汉化 → 口语短语/普通短语/口语词/普通词替换 → 强制替换
- ApplyPostLLMAsync: 数字汉化 → 强制替换 → 移除AI填充词 → 归一化省略号/破折号 → 移除AI模板 → 移除Markdown → 折叠空行+标点归一化
- MLM 候选评分 (RobertaTinyMlm.score_candidates)
"""
import os, json, re, random, threading
import numpy as np
from typing import Dict, List, Optional


class RobertaTinyMlm:
    """对标 IMicroMlmService: ScoreCandidatesAsync"""

    def __init__(self, model_dir: str = None):
        if not model_dir:
            model_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                     "chinese-roberta-tiny")
        model_path = os.path.join(model_dir, "model.onnx")
        vocab_path = os.path.join(model_dir, "vocab.txt")
        self._available = os.path.exists(model_path) and os.path.exists(vocab_path)
        if not self._available:
            return

        import onnxruntime as ort
        self._session = ort.InferenceSession(model_path)
        self._vocab = self._load_vocab(vocab_path)
        self._vocab_size = self._read_vocab_size(model_dir)
        self._discover_io()

    def _load_vocab(self, path: str) -> dict:
        vocab = {}
        with open(path, "r", encoding="utf-8") as f:
            for i, line in enumerate(f):
                vocab[line.strip()] = i
        return vocab

    def _read_vocab_size(self, model_dir: str) -> int:
        cfg = os.path.join(model_dir, "config.json")
        try:
            with open(cfg, "r") as f:
                return json.load(f).get("vocab_size", 21128)
        except Exception:
            return 21128

    def _discover_io(self):
        inputs = [i.name for i in self._session.get_inputs()]
        self._input_ids_name = next((n for n in inputs if "input" in n.lower()), inputs[0])
        self._attention_mask_name = next((n for n in inputs if "mask" in n.lower()), inputs[1])
        self._token_type_ids_name = next((n for n in inputs if "token_type" in n.lower()), None)
        outputs = [o.name for o in self._session.get_outputs()]
        self._output_logits_name = next((n for n in outputs if "logit" in n.lower()), outputs[0])

    def encode(self, text: str, max_len: int = 256) -> List[int]:
        """BERT tokenizer: 字符级 CJK 分词"""
        ids = []
        for ch in text[:max_len * 3]:
            ids.append(self._vocab.get(ch, self._vocab.get("[UNK]", 100)))
        if len(ids) > max_len - 2:
            ids = ids[:max_len - 2]
        cls_id = self._vocab.get("[CLS]", 101)
        sep_id = self._vocab.get("[SEP]", 102)
        return [cls_id] + ids + [sep_id]

    def score_candidates(self, text: str, anchor_idx: int, key: str, candidates: List[str]) -> List[float]:
        """对标 ScoreCandidatesAsync: MLM 评分候选替换词"""
        if not self._available or not candidates or len(key) == 0:
            return [0.0] * len(candidates)
        if anchor_idx < 0 or anchor_idx + len(key) > len(text):
            return [0.0] * len(candidates)

        n = len(candidates)
        prefix = text[:anchor_idx]
        suffix = text[anchor_idx + len(key):]

        token_lists = []
        max_len = 0
        for cand in candidates:
            full = prefix + cand + suffix
            ids = self.encode(full, 256)
            token_lists.append(ids)
            if len(ids) > max_len:
                max_len = len(ids)
        if max_len == 0:
            return [0.0] * n

        inp_ids = np.zeros((n, max_len), dtype=np.int64)
        attn_mask = np.zeros((n, max_len), dtype=np.int64)
        for i, toks in enumerate(token_lists):
            inp_ids[i, :len(toks)] = toks
            attn_mask[i, :len(toks)] = 1

        feed = {
            self._input_ids_name: inp_ids,
            self._attention_mask_name: attn_mask,
        }
        if self._token_type_ids_name:
            feed[self._token_type_ids_name] = np.zeros((n, max_len), dtype=np.int64)

        try:
            outputs = self._session.run([self._output_logits_name], feed)
            logits = outputs[0]  # (n, seq_len, vocab_size)
        except Exception:
            return [0.0] * n

        actual_vocab = logits.shape[2] if len(logits.shape) == 3 else self._vocab_size
        cand_start = 1 + anchor_idx  # [CLS] offset
        scores = []

        for b in range(n):
            cand_tokens = len(candidates[b])
            if cand_tokens <= 0:
                scores.append(float('-inf'))
                continue
            cand_end = min(cand_start + cand_tokens, len(token_lists[b]))
            actual = cand_end - cand_start
            if actual <= 0:
                scores.append(float('-inf'))
                continue
            total = 0.0
            for p in range(actual):
                pos = cand_start + p
                tid = token_lists[b][pos]
                total += logits[b, pos, min(tid, actual_vocab - 1)]
            scores.append(float(total / actual))
        return scores

    @property
    def available(self) -> bool:
        return self._available


# ==================== 数据字典（对标 HumanizeRules.*.cs）====================

# AI 填充词（对标 AiFillerPhrases）
AI_FILLER_PHRASES = [
    "综上所述", "值得注意的是", "不难发现", "总而言之", "不可否认", "毫无疑问",
    "显而易见", "众所周知", "由此可见", "需要指出的是", "值得一提的是", "不言而喻",
    "毋庸置疑", "事实上", "实际上", "严格来说", "换句话说", "从某种意义上说",
    "在一定程度上", "就目前来看", "总的来说", "概括来说", "归根结底", "不仅如此",
    "需要强调的是", "正如我们所知", "如前所述", "由此可以看出", "不得不说", "正因如此",
]

# AI 模板正则（对标 AiTemplateRegexes）
AI_TEMPLATE_REGEXES = [
    r"首先[，,].*?其次[，,].*?最后",
    r"一方面[，,].*?另一方面",
    r"第一[，,].*?第二[，,].*?第三",
    r"第一点.*?第二点.*?第三点",
    r"其一[，,].*?其二[，,].*?其三",
    r"虽然.*?但是.*?同时",
    r"一方面.*?另一方面.*?总的来说",
    r"既有.*?也有.*?更有",
    r"不仅.*?而且.*?更",
    r"优点.*?缺点.*?总体",
    r"随着.*?的(不断)?发展",
    r"在.*?的背景下",
    r"在当今.*?时代",
    r"作为.*?的重要(组成部分|环节|手段)",
    r"对于.*?而言[，,].*?至关重要",
    r"这不仅.*?更是",
    r"从.*?角度(来看|来说|而言)",
    r"无论是.*?还是.*?都",
    r"可以说[，,]",
    r"总的来说[，,]",
]

# 强制替换短语（对标 ForcedPhraseReplacements）
FORCED_PHRASE_REPLACEMENTS = {
    "赋能": ["帮助", "推动", "支持"],
    "赛道": ["领域", "方向", "路子"],
    "链路": ["流程", "脉络", "路径"],
    "创新驱动": ["新的办法", "新的思路", "改变的办法"],
    "顶层设计": ["整体安排", "整体规划", "总的安排"],
    "打通壁垒": ["破除阻碍", "消除隔阂", "扫清障碍"],
    "抓手": ["切入点", "突破口", "着力点"],
    "底层逻辑": ["根本原因", "核心逻辑", "本质"],
    "全方位": ["各方面", "多方面", "整体上"],
    "多维度": ["多个角度", "多方面", "各个层面"],
    "系统性地": ["整体地", "完整地", "综合地"],
    "系统性": ["整体", "完整", "综合"],
    "深度剖析": ["深入分析", "仔细看看", "拆解一下"],
    "深度融合": ["结合", "融入", "渗透到"],
    "闭环": ["完整流程", "一条龙", "前后呼应"],
    "数字化转型": ["信息化升级", "系统更新", "技术革新"],
    "协同增效": ["合力", "联动", "共同推进"],
    "降本增效": ["省钱省力", "提高效率", "精打细算"],
    "战略高度": ["大局上", "整体上", "长远来看"],
    "持续赋能": ["一直支持", "不断助推", "持续帮助"],
    "提质增效": ["提高质量与效率", "又好又快", "又快又好"],
    "立体化": ["多层次", "多角度", "全角度"],
    "躬身入局": ["亲自参与", "亲自下场", "投身其中"],
    "长期主义": ["长远眼光", "着眼长远", "长期视角"],
}

# 普通短语替换（对标 PhraseReplacements）
PHRASE_REPLACEMENTS = {
    "值得注意的是": ["注意", "要提醒的是", "特别说一下", "有个点"],
    "综上所述": ["总之", "说到底", "简单讲", "归结起来"],
    "不难发现": ["可以看到", "很明显", "你会发现"],
    "总而言之": ["总之", "总的来说", "一句话"],
    "与此同时": ["同时", "这时候", "另一边"],
    "在此基础上": ["基于这个", "在这上面", "以此为基础"],
    "由此可见": ["所以", "可见", "看得出"],
    "此外": ["另外", "还有", "再说"],
    "需要指出的是": ["要说的是", "需要注意", "提一嘴"],
    "值得一提的是": ["值得说的是", "还有一点", "顺带一提"],
    "全面升级": ["升级", "进步"],
    "实现高质量发展": ["发展得更好"],
    "高质量发展": ["更好地发展"],
    "从某种意义上说": ["可以说", "某种程度上"],
    "毫无疑问": ["肯定的是", "可以肯定"],
    "贡献力量": ["出一份力", "做点贡献"],
    "前所未有的": ["很大的", "巨大的"],
    "不可替代的": ["关键的", "重要的"],
    "一方面": ["一来"],
    "另一方面": ["二来"],
    "在智慧时代中": ["在这个时代"],
    "智慧时代": ["这个时代", "现在"],
    "助力": ["帮助", "推动", "促进", "支持"],
    "彰显": ["展现", "体现", "表现出"],
    "凸显": ["突出", "显示", "暴露出"],
    "焕发": ["展现", "释放", "激发"],
    "不可否认的是": ["确实", "不得不承认"],
    "触达": ["接触到", "覆盖", "达到"],
    "心智": ["认知", "印象", "想法"],
    "沉淀": ["积累", "总结", "留下"],
    "对齐": ["统一", "同步", "拉齐"],
    "拉通": ["打通", "贯穿", "串联"],
    "复盘": ["回顾", "总结", "反思"],
    "再次": ["另外", "还", "又"],
    "然后": ["接着", "随后", "之后"],
    "进而": ["接着", "跟着", "继而"],
    "从而": ["于是", "这样一来", "由此"],
    "因此": ["所以", "故", "于是", "由此"],
    "简而言之": ["简单说", "一句话", "一言以蔽之"],
    "具体而言": ["具体来说", "细说", "说具体点"],
    "具体来说": ["具体而言", "细说"],
    "换言之": ["换句话说", "也就是说"],
    "换句话说": ["换言之", "也就是说"],
    "不过是": ["只是", "只不过是", "仅是"],
    "相反": ["反之", "反过来", "相反地"],
    "相较而言": ["相比起来", "相比之下", "比起来"],
    "诚然": ["确实", "当然", "不错"],
    "近年来": ["这些年", "这几年", "最近这些年", "过去几年", "前些年"],
    "近几年": ["近两年", "最近这几年", "这两年", "这些年"],
    "在新时代": ["在这个时代", "如今这个阶段", "眼下这个阶段"],
    "在新形势下": ["眼下这种局势下", "现阶段", "当下"],
    "此时此刻": ["眼下", "这个时候", "此刻", "现在"],
    "新质生产力": ["新型生产力", "先进生产力"],
    "可能会": ["可能", "或许", "有可能", "大概会"],
    "如果您": ["如果你", "假如您", "要是您", "您若"],
    "建议您": ["建议", "建议你", "我觉得不妨"],
    "您可以": ["你可以", "可以"],
    "是一种": ["属于一种", "算是一种"],
    "可以尝试": ["不妨试试", "可以试", "试试"],
    "我无法": ["我不能", "我做不到"],
    "可以帮助": ["能帮", "可以帮"],
    "会导致": ["会引起", "会造成", "会带来"],
    "以帮助": ["来帮助", "以协助", "来协助"],
    "可能会导致": ["可能带来", "会引起", "可能引发", "可能造成"],
    "研究发现": ["研究观察到", "研究得出", "已有分析揭示"],
    "研究显示": ["研究反映", "分析揭示", "已有数据呈现"],
    "研究指出": ["研究强调", "已有文献明确", "相关研究突出"],
    "研究证实": ["研究印证", "研究验证", "已有分析确认"],
    "分析表明": ["分析揭示", "从分析来看", "已有分析得出"],
    "分析显示": ["分析反映", "从分析看", "相关分析揭示"],
    "结果显示": ["结果反映", "结果体现", "从结果看"],
    "结果表明": ["结果印证", "结果证明", "从结果可见"],
    "实验表明": ["实验得出", "实验验证", "相关实验印证"],
    "实验显示": ["实验反映", "实验呈现", "相关实验得出"],
    "数据显示": ["数据反映", "数据指向", "从数据来看"],
    "数据表明": ["数据印证", "数据揭示", "数据呈现"],
    "建议您咨询": ["建议问一下", "建议找", "不妨咨询"],
    "可能是由于": ["可能因为", "也许是", "大概是因为"],
    "您可以尝试": ["你可以试试", "不妨试试", "可以试试"],
    "这可能": ["这或许", "这也许", "这大概"],
    "也可能": ["或许", "也许", "说不定"],
    "咨询医生": ["问问医生", "找医生", "看医生"],
    "可能需要": ["可能要", "或许得", "大概需要"],
    "可以使用": ["可以用", "能用", "用得上"],
    "可以通过": ["通过", "借助", "靠"],
    "取决于": ["看", "要看", "视具体情况"],
    "通常是": ["一般是", "多半是", "通常"],
    "迭代": ["更新", "升级", "演进", "改进", "打磨"],
    "如果你": ["要是你", "假如你", "你若", "倘若你"],
    "情况下": ["场景里", "局面下", "时候", "条件下"],
    "为您提供": ["给到您", "为你带来", "给你备", "提供给你"],
    "可以考虑": ["不妨看看", "可以想想", "值得试试"],
    "尝试使用": ["不妨试试", "可以用", "可以上手", "用一下"],
    "希望这些": ["愿这些", "但愿能", "祝这些", "盼这些"],
    "很抱歉": ["不好意思", "抱歉", "不巧", "哎呀"],
    "有所不同": ["有差别", "不一样", "各有不同", "略有差异"],
    "以下步骤": ["下面的步骤", "下面这些", "按以下做", "接下来这几步"],
    "展望未来": ["往后看", "接下来的阶段", "从长远看", "再往前看"],
    "总的来说": ["综合来看", "大体上", "从整体看", "一言蔽之"],
    "尽管": ["虽然", "即便", "即使"],
    "与此相对": ["相反", "反过来", "对照起来"],
    "在此背景下": ["在这个基础上", "就这个情形", "对此"],
    "从上述分析可知": ["综合前文", "上述分析揭示", "回头看前面的分析"],
    "从表中可以看出": ["由表可见", "对照表格", "查看表格可知"],
    "面临诸多挑战": ["存在不少难题", "面对多项困难", "碰到多种问题", "面对的阻碍不少"],
    "诸多挑战": ["多项难题", "一些困难", "不少问题", "多种考验"],
    "在一定程度上": ["多少能", "某种程度上", "多少有些", "一定层面上"],
    "以下几个": ["下面几个", "以下这些", "几个层面", "几个方面"],
    "广泛关注": ["引发关注", "被看到", "广为人知", "被广泛讨论"],
    "广泛应用": ["用得广", "用得多", "使用广泛", "应用范围广"],
    "如何平衡": ["怎么平衡", "如何协调", "怎样拿捏", "如何把握"],
    "共同努力": ["通力协作", "共同推进", "齐心合力", "大家合力"],
    "全球范围内": ["世界各地", "全球各地", "全球性地", "放眼全球"],
    "未来展望": ["往后看", "未来会怎样", "展望之后", "后面展开"],
    "能够有效地": ["有效地", "妥善地", "稳妥地", "切实"],
    "能够有效": ["可以", "能够", "有能力", "能实在地"],
    "可能导致": ["可能引起", "或许招致", "可能造成", "可能带来"],
    "为了应对": ["应对", "面对", "处理", "为解决"],
    "取得了": ["做到了", "达成", "实现", "获得"],
    "小心翼翼地": ["仔细地", "谨慎地", "留神地"],
    "小心翼翼": ["仔细", "谨慎", "留神"],
    "就在这时": ["这个时候", "这时", "当下", "就此刻"],
    "带着一丝": ["带着些", "略带", "有种", "带着点"],
    "不仅仅是": ["不光是", "不只是", "不止是"],
    "这是一个": ["这算是", "这属于", "这是", "这算"],
    "一个关于": ["一个围绕", "一个有关", "一个讲", "一个涉及"],
    "技术的快速": ["技术的迅速", "技术的飞速", "这技术的"],
    "进行了观察": ["打量了一番", "看了看", "瞧了瞧"],
    "发出了声音": ["响了一声", "传来一阵声响"],
    "表现出了": ["流露出", "显出"],
    "实施攻击": ["出手", "动手"],
    "展开搜索": ["搜了起来", "四下找寻"],
    "感受到了": ["觉出", "察觉到"],
    "产生了": ["涌起", "升起", "冒出"],
    "呈现出": ["显出", "露出"],
    "进行战斗": ["交手", "厮杀"],
    "给予回应": ["回了一句", "应道"],
    "很安静": ["四下无声", "静得落针可闻"],
    "天很黑": ["夜色浓重", "四周伸手不见五指"],
    "天很冷": ["寒意刺骨", "冷风如刀"],
    "时间过去了": ["光阴流转", "不知过了多久"],
    "天亮了": ["晨曦微明", "第一缕晨光透进来"],
    "天黑了": ["暮色四合", "夜幕降下"],
    "很多人": ["人影绰绰", "三三两两"],
    "没有人": ["空无一人", "空荡荡的"],
    "很远": ["极目处", "天际尽头"],
    "很快": ["转瞬间", "须臾之间"],
}

# 单词替换（对标 WordReplacements）
WORD_REPLACEMENTS = {
    "因此": ["所以", "因而", "为此", "故而"],
    "然而": ["不过", "但", "可是", "只是"],
    "但是": ["不过", "可是", "只是", "然而"],
    "虽然": ["尽管", "即便", "就算", "纵然"],
    "所以": ["因此", "因而", "故而", "于是"],
    "而且": ["并且", "况且", "何况", "再说"],
    "或者": ["要么", "抑或", "或是", "还是"],
    "如果": ["倘若", "假如", "若是", "要是"],
    "因为": ["由于", "缘于", "出于", "鉴于"],
    "尽管": ["虽然", "即便", "纵使", "就算"],
    "能够": ["可以", "得以", "足以", "有能力"],
    "进行": ["开展", "实施", "做", "搞"],
    "实现": ["达成", "做到", "完成", "办到"],
    "提高": ["提升", "增强", "改善", "拉高"],
    "发展": ["推进", "进展", "演进", "推动"],
    "研究": ["探究", "考察", "审视", "钻研"],
    "表明": ["显示", "说明", "反映", "揭示"],
    "认为": ["觉得", "以为", "判断", "主张"],
    "需要": ["有必要", "须", "要", "得"],
    "使用": ["运用", "采用", "用", "动用"],
    "具有": ["带有", "拥有", "含有", "具备"],
    "导致": ["引发", "造成", "招致", "引起"],
    "提供": ["给出", "供给", "拿出", "呈上"],
    "分析": ["剖析", "解读", "拆解", "审视"],
    "促进": ["推动", "助推", "带动", "催动"],
    "利用": ["借用", "运用", "动用", "凭借"],
    "建立": ["搭建", "构筑", "组建", "创设"],
    "引起": ["招来", "激起", "触发", "挑起"],
    "采取": ["采用", "动用", "使出", "施行"],
    "包括": ["涵盖", "囊括", "含", "包含"],
    "产生": ["催生", "引出", "萌生", "冒出"],
    "增加": ["添加", "追加", "扩充", "加大"],
    "减少": ["缩减", "削减", "降低", "裁减"],
    "保持": ["维持", "守住", "留住", "持续"],
    "解决": ["化解", "处置", "破解", "攻克"],
    "改变": ["改动", "扭转", "调整", "变化"],
    "选择": ["挑选", "选定", "选用"],
    "支持": ["撑持", "扶持", "支撑"],
    "组成": ["构成", "拼成", "组合", "凑成"],
    "形成": ["催生", "铸成", "生成", "酿成"],
    "获得": ["取得", "赢得", "得到", "揽获"],
    "确定": ["敲定", "锁定", "明确", "定下"],
    "推动": ["驱动", "助推", "催动", "拉动"],
    "加强": ["强化", "增强", "夯实", "巩固"],
    "体现": ["彰显", "凸显", "映射", "折射"],
    "满足": ["达到", "契合", "符合", "迎合"],
    "属于": ["归属", "算是", "属", "归入"],
    "考虑": ["斟酌", "权衡", "琢磨", "思量"],
    "处理": ["打理", "应对", "料理", "处置"],
    "参与": ["加入", "介入", "参加", "投身"],
    "创造": ["缔造", "开创", "营造", "打造"],
    "描述": ["刻画", "勾勒", "叙述", "描绘"],
    "强调": ["着重", "突出", "力陈", "重申"],
    "反映": ["映射", "折射", "体现", "呈现"],
    "应用": ["运用", "采用", "使用", "施用"],
    "结合": ["融合", "配合", "糅合", "衔接"],
    "关注": ["留意", "聚焦", "在意", "着眼"],
    "涉及": ["牵涉", "关乎", "触及", "波及"],
    "依据": ["按照", "参照", "凭", "根据"],
    "采用": ["选用", "沿用", "取用", "引用"],
    "目前": ["眼下", "当前", "现阶段", "如今"],
    "同时": ["与此同时", "此外", "另外", "并且"],
    "通过": ["借助", "凭借", "经由", "依靠"],
    "根据": ["按照", "依据", "参照", "依照"],
    "基于": ["立足于", "依托", "以…为基础", "仰赖"],
    "对于": ["针对", "就", "关于", "面对"],
    "非常": ["极其", "十分", "很", "格外"],
    "已经": ["早已", "业已", "已", "早就"],
    "完全": ["彻底", "全然", "纯粹", "压根"],
    "不断": ["持续", "始终", "一再", "反复"],
    "逐渐": ["渐渐", "慢慢", "一步步", "日渐"],
    "主要": ["核心", "关键", "首要"],
    "一般": ["通常", "往常", "照例", "大抵"],
    "大量": ["海量", "大批", "众多", "成堆的"],
    "进一步": ["更", "再", "深入", "继续"],
    "充分": ["尽情", "透彻", "淋漓", "饱满"],
    "直接": ["径直", "当面", "立刻", "干脆"],
    "特别": ["尤其", "格外", "极", "分外"],
    "一定": ["某种", "相当", "一些", "多少"],
    "必须": ["得", "务必", "非得", "须"],
    "可能": ["也许", "兴许", "或许", "大概"],
    "重要": ["核心", "要紧", "紧要"],
    "显著": ["明显", "突出", "可观", "醒目"],
    "问题": ["难题", "麻烦", "症结"],
    "方面": ["层面", "维度", "领域"],
    "情况": ["状况", "形势", "境况", "局面"],
    "特点": ["特征", "属性", "标志", "特色"],
    "方法": ["办法", "手段", "途径", "招数"],
    "过程": ["历程", "进程", "流程", "经过"],
    "结果": ["成果", "产物", "结局"],
    "条件": ["前提", "条件", "要件", "门槛"],
    "作用": ["功用", "效用", "效能", "功能"],
    "内容": ["要素", "成分", "要点", "素材"],
    "程度": ["幅度", "力度", "地步", "深浅"],
    "原因": ["缘由", "根源", "起因", "来由"],
    "目标": ["目的", "指向", "靶心", "方向"],
    "水平": ["档次", "层次", "高度", "水准"],
    "范围": ["领域", "地带", "区间", "覆盖面"],
    "趋势": ["走向", "苗头", "势头", "倾向"],
    "能力": ["本事", "实力", "功底", "才干"],
    "优势": ["长处", "强项", "亮点", "好处"],
    "资源": ["物资", "储备", "要素"],
    "环境": ["氛围", "生态", "背景"],
    "系统": ["体系", "架构", "框架"],
    "策略": ["路线", "方案", "对策", "路子"],
    "囊括": ["包括", "涵盖", "包含"],
    "关于": ["有关于", "至于", "谈到"],
    "为了": ["为了能够", "以便", "是为了"],
    "符合": ["契合", "吻合", "满足"],
    "适合": ["适宜", "合适", "对路"],
    "极大地": ["极大程度上", "大幅"],
    "持续": ["不断", "继续", "接连"],
    "提升": ["拉高", "拔高", "增高", "抬升"],
    "降低": ["压低", "削减", "拉低"],
    "显著地": ["明显地", "突出地", "大幅"],
    "有效地": ["切实地", "有力地", "得体地"],
    "快速地": ["迅速", "飞快", "急速", "疾速"],
    "充分地": ["彻底地", "完全地", "尽情地"],
    "广泛地": ["遍及地", "普及地", "大范围地"],
    "积极地": ["主动地", "踊跃地", "投身地"],
}

# AI 黑名单（对标 AiBlacklist）
AI_BLACKLIST = {
    "全方位", "凸显", "出圈", "创新驱动", "加持", "助力", "协同增效", "复盘",
    "多维度", "对齐", "底层逻辑", "彰显", "心智", "愿景", "打通壁垒", "抓手",
    "拉通", "数字化转型", "智慧时代", "沉淀", "深度剖析", "深度融合", "焕发",
    "生态", "破圈", "系统性", "触达", "赋能", "赛道", "迭代", "链路", "闭环",
    "降本增效", "革新", "顶层设计", "颠覆", "变革", "重构", "新范式", "颗粒度",
    "打法", "组合拳", "护城河", "引爆", "风口", "新赛道",
}

# 小说黑名单（对标 NovelBlacklist）
NOVEL_BLACKLIST = {
    "业已", "亮点", "估摸着", "做", "做过", "兴许", "势头", "压根", "地带",
    "大抵", "好处", "家底", "干脆", "弄", "当面", "径直", "思量", "成堆的",
    "打法", "打理", "拉高", "招数", "挑", "揽获", "搞", "搞定", "摆平", "撑持",
    "敲定", "整", "料理", "施用", "早就", "最要紧的", "本事", "本钱", "来由",
    "架构", "框架", "档次", "段位", "琢磨", "症结", "约莫", "缘于", "缘由",
    "苗头", "门槛", "麻烦",
}

# 小说口语短语（对标 NovelOralPhrases）
NOVEL_ORAL_PHRASES = {
    "看了很久": ["看了很久很久"],
    "等了很久": ["已经等了很久很久了"],
    "深吸一口气": ["深深吸了一口气"],
    "就在这时": ["就在这个时候"],
    "第二天": ["到了第二天"],
    "深吸了一口气": ["深深吸了一口气"],
}

# 小说口语词（对标 NovelOralWords）
NOVEL_ORAL_WORDS = {
    "看": ["瞧"],
    "看见": ["瞧见"],
    "看到": ["瞧见", "瞧到"],
    "整齐地": ["齐刷刷地"],
    "漆黑": ["黑乎乎", "黑漆漆"],
    "寂静": ["死寂", "静悄悄"],
    "急促": ["又急又促"],
    "模糊": ["模模糊糊"],
    "清晰": ["真真切切"],
    "清楚": ["清清楚楚"],
    "慢慢": ["慢慢吞吞"],
    "然后": ["紧接着", "跟着"],
    "跑出": ["拔腿就跑"],
    "但是": ["可是", "可"],
    "猛然": ["猛地"],
    "突然": ["猛地", "冷不丁"],
    "声音": ["响动"],
    "立即": ["马上", "当下"],
    "立刻": ["马上", "当下"],
}

# 小说伪影正则（对标 NovelArtifactRegexes）
NOVEL_ARTIFACT_REGEXES = [
    r"我将按照您的",
    r"按照您的要求",
    r"根据您(供给|提供)的",
    r"以下是我(根据|为您|按照)",
    r"故事梗概",
    r"本次写作(重点|将|主要)",
    r"接下来故事(可能|将|会)",
    r"这是一个关于.{0,20}的故事",
]

# Markdown 正则（对标 NovelMarkdownRegexes）
NOVEL_MARKDOWN_REGEXES = [
    r"^\s*#{1,4}\s+",
    r"^\s*[-\*]\s+\*\*[^\*]+\*\*[:：]",
    r"^\s*(?:---+|\*\*\*+|===+)\s*$",
]

# 数字汉化映射（对标 Digits）
DIGIT_TO_CHINESE = {c: ch for c, ch in zip("0123456789", "零一二三四五六七八九")}
CHINESE_DECADE_MAP = {f"{d}0": DIGIT_TO_CHINESE[str(d)] + "十" for d in range(1, 10)}
DIGIT_YEAR_4_REGEX = re.compile(r"(?<!\d)((?:19|20)\d{2})(?=年)")
DIGIT_YEAR_DECADE_REGEX = re.compile(r"(?<!\d)(\d0)年代")
DIGIT_MONTH_REGEX = re.compile(r"(?<![\d年个])([1-9]|1[0-2])(?=月(?:\D|$))")
DIGIT_DAY_REGEX = re.compile(r"(?<![\d月])([1-9]|[12]\d|3[01])(?=[日号])")

# 标点归一化正则（对标 NormalizePunctuationArtifacts）
BLANK_LINE_COLLAPSER = re.compile(r"\n{3,}")
SENTENCE_COMMA_ARTIFACT = re.compile(r"([。！？])[,，]+")
COMMA_SENTENCE_ARTIFACT = re.compile(r"[,，]+([。！？])")
DUPLICATE_COMMA = re.compile(r"[,，]{2,}")
LEADING_COMMA = re.compile(r"(^|\n)[,，]+")
TRAILING_COMMA = re.compile(r"[,，]+(\n|$)")
DUPLICATE_SENTENCE_PUNCT = re.compile(r"([。！？])\1+")

# 省略号/破折号
ELLIPSIS_REGEX = re.compile(r"\.{3,}|\u2026+")
DASH_REGEX = re.compile(r"-{2,}|[\u2013\u2014\u2015]+")


# ==================== 工具函数 ====================

def _normalize_ellipsis(text: str) -> str:
    return ELLIPSIS_REGEX.sub("\u2026\u2026", text)


def _normalize_dash(text: str) -> str:
    return DASH_REGEX.sub("\u2014\u2014", text)


def _remove_paragraphs_matching(text: str, patterns: List[str]) -> str:
    paragraphs = text.replace("\r\n", "\n").split("\n\n")
    kept = []
    for p in paragraphs:
        if not any(re.search(rx, p) for rx in patterns):
            kept.append(p)
    return "\n\n".join(kept)


def _apply_digit_normalization(text: str) -> str:
    def digit_concat(digits: str) -> str:
        return "".join(DIGIT_TO_CHINESE.get(c, c) for c in digits)

    def small_num_to_chinese(s: str) -> str:
        try:
            n = int(s)
        except ValueError:
            return s
        if n <= 0:
            return s
        if n < 10:
            return DIGIT_TO_CHINESE.get(s[0], s)
        if n == 10:
            return "十"
        if n < 20:
            ones = str(n - 10)
            return "十" + DIGIT_TO_CHINESE.get(ones, ones)
        if n < 100:
            tens = str(n // 10)
            ones = n % 10
            prefix = DIGIT_TO_CHINESE.get(tens, tens) + "十"
            if ones == 0:
                return prefix
            one_char = str(ones)
            return prefix + DIGIT_TO_CHINESE.get(one_char, one_char)
        return s

    text = DIGIT_YEAR_4_REGEX.sub(lambda m: digit_concat(m.group(1)), text)
    text = DIGIT_YEAR_DECADE_REGEX.sub(
        lambda m: CHINESE_DECADE_MAP.get(m.group(1), m.group(0)) + "年代", text)
    text = DIGIT_MONTH_REGEX.sub(lambda m: small_num_to_chinese(m.group(1)), text)
    text = DIGIT_DAY_REGEX.sub(lambda m: small_num_to_chinese(m.group(1)), text)
    return text


def _collapse_blank_lines(text: str) -> str:
    return BLANK_LINE_COLLAPSER.sub("\n\n", text).strip()


def _normalize_punctuation_artifacts(text: str) -> str:
    if not text:
        return text
    text = SENTENCE_COMMA_ARTIFACT.sub(r"\1", text)
    text = COMMA_SENTENCE_ARTIFACT.sub(r"\1", text)
    text = DUPLICATE_COMMA.sub("，", text)
    text = LEADING_COMMA.sub(r"\1", text)
    text = TRAILING_COMMA.sub(r"\1", text)
    text = DUPLICATE_SENTENCE_PUNCT.sub(r"\1", text)
    return text


def _filter_safe_candidates(candidates: List[str]) -> List[str]:
    return [c for c in candidates if c not in AI_BLACKLIST and c not in NOVEL_BLACKLIST]


def _build_available(safe: List[str], used: set) -> List[str]:
    if not used:
        return safe
    avail = [c for c in safe if c not in used]
    if avail:
        return avail
    used.clear()
    return safe


class HumanizeRules:
    """对标 4.1.1 HumanizeRules: AI 味替换 + 语义守卫"""

    AI_PHRASE_RATE = 0.85
    WORD_RATE = 0.50
    NOVEL_ORAL_RATE = 0.50

    def __init__(self, mlm: RobertaTinyMlm = None):
        self.mlm = mlm or RobertaTinyMlm()

    def _apply_dictionary(self, text: str, dictionary: Dict[str, List[str]], rate: float,
                          bypass_picker: bool = False) -> str:
        """对标 ApplyDictionaryAsync: 逐词典替换，按 key 长度降序"""
        for key in sorted(dictionary.keys(), key=lambda k: -len(k)):
            if not key or key not in text:
                continue
            safe = _filter_safe_candidates(dictionary[key])
            if not safe:
                continue
            used = set()
            out = []
            pos = 0
            while pos < len(text):
                idx = text.find(key, pos)
                if idx < 0:
                    out.append(text[pos:])
                    break
                out.append(text[pos:idx])
                if random.random() < rate:
                    avail = _build_available(safe, used)
                    if bypass_picker:
                        chosen = avail[0] if avail else safe[0]
                    else:
                        scores = self.mlm.score_candidates(text, idx, key, avail)
                        if scores:
                            best_idx = int(np.argmax(scores))
                            chosen = avail[best_idx] if scores[best_idx] > -100 else avail[0]
                        else:
                            chosen = avail[0]
                    out.append(chosen)
                    used.add(chosen)
                else:
                    out.append(key)
                pos = idx + len(key)
            text = "".join(out)
        return text

    def apply_pre_llm(self, text: str, max_replaces: int = 20) -> str:
        """对标 ApplyPreLLMAsync"""
        if not text or not text.strip():
            return text

        text = _normalize_ellipsis(text)
        text = _normalize_dash(text)

        text = _remove_paragraphs_matching(text, NOVEL_ARTIFACT_REGEXES)
        for rx in NOVEL_MARKDOWN_REGEXES:
            text = re.sub(rx, "", text, flags=re.MULTILINE)
        text = _remove_paragraphs_matching(text, AI_TEMPLATE_REGEXES)

        for phrase in AI_FILLER_PHRASES:
            text = text.replace(phrase, "")

        text = _apply_digit_normalization(text)

        text = self._apply_dictionary(text, NOVEL_ORAL_PHRASES, self.NOVEL_ORAL_RATE)
        text = self._apply_dictionary(text, PHRASE_REPLACEMENTS, self.AI_PHRASE_RATE)
        text = self._apply_dictionary(text, NOVEL_ORAL_WORDS, self.NOVEL_ORAL_RATE)
        text = self._apply_dictionary(text, WORD_REPLACEMENTS, self.WORD_RATE)
        text = self._apply_dictionary(text, FORCED_PHRASE_REPLACEMENTS, 1.0, bypass_picker=True)

        return _collapse_blank_lines(_normalize_punctuation_artifacts(text))

    def apply_post_llm(self, text: str) -> str:
        """对标 ApplyPostLLMAsync"""
        if not text or not text.strip():
            return text

        text = _apply_digit_normalization(text)
        text = self._apply_dictionary(text, FORCED_PHRASE_REPLACEMENTS, 1.0, bypass_picker=True)

        for phrase in AI_FILLER_PHRASES:
            text = text.replace(phrase, "")

        text = _normalize_ellipsis(text)
        text = _normalize_dash(text)

        text = _remove_paragraphs_matching(text, AI_TEMPLATE_REGEXES)
        for rx in NOVEL_MARKDOWN_REGEXES:
            text = re.sub(rx, "", text, flags=re.MULTILINE)

        return _collapse_blank_lines(_normalize_punctuation_artifacts(text))

    def humanize(self, text: str, max_replaces: int = 20) -> str:
        """兼容旧接口：调用 apply_pre_llm"""
        return self.apply_pre_llm(text, max_replaces)

    def semantic_guard(self, original: str, humanized: str, threshold: float = 0.85) -> bool:
        """对标 ISemanticGuard: 语义相似度校验"""
        if not self.mlm.available:
            return True
        return True  # 简化：文本级不需要 guard