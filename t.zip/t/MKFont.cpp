#include "MKFont.h"
#include "mkmemory.h"
#include "Log.h"
//http://www.sdltutorials.com/sdl-ttf

MKFont::MKFont()
{
}

MKFont::~MKFont()
{
}

MKFontPtr MKFont::newInstance() {
	return make_shared<MKFont>();  
}

int MKFont::initFFT() {
	int status = 0;
	FT_Error error = FT_Init_FreeType( &library ); 
	if ( error ) {
		status = -1;
	}
	LogUtil::logInfo("font", "initFFT status:%d", status);
	return status;
}

void MKFont::unload() {
	 FT_Done_Face(face); 
	 FT_Done_FreeType(library); 
}

TTF_Font* MKFont::getFont(int size) {
	for(int i=0; i<fonts.size(); i++) {
		TTF_Font* pFont = fonts.at(i);
		if(pFont->fontSize==size) {
			return pFont;
		}
	}
	return NULL;
}

TTF_Font* MKFont::setFontSize(int ptsize) {

	TTF_Font* pFont = getFont(ptsize);
	if(pFont!=NULL) {
		this->font = *pFont;
		return pFont;
	}

	int status = 0;
	FT_Fixed scale;
	this->fontSize = ptsize;
	pFont = new TTF_Font();//&this->font;
	fonts.push_back(pFont);

	FT_Error error = 0;

	if ( FT_IS_SCALABLE(face) ) {
		LogUtil::logInfo("font", "FT_IS_SCALABLE");
	  	/* Set the character size and use default DPI (72) */
	  	error = FT_Set_Char_Size( face, 0, ptsize * 64, 0, 0 );
		if( error ) {
	    	FT_Done_Face( face );
	    	return 0;
		}

	  /* Get the scalable font metrics for this font */
	  scale = face->size->metrics.y_scale;
	  pFont->ascent  = FT_CEIL(FT_MulFix(face->ascender, scale));
	  pFont->descent = FT_CEIL(FT_MulFix(face->descender, scale));
	  pFont->height  = pFont->ascent - pFont->descent + /* baseline */ 1;
	  pFont->maxHeight = FT_CEIL(FT_MulFix(face->height, scale));
	  pFont->underline_offset = FT_FLOOR(FT_MulFix(face->underline_position, scale));
	  pFont->underline_height = FT_FLOOR(FT_MulFix(face->underline_thickness, scale));

	} else {
		LogUtil::logInfo("font", "!FT_IS_SCALABLE");
		/* Non-scalable font case.  ptsize determines which family
		 * or series of fonts to grab from the non-scalable format.
		 * It is not the point size of the font.
		 * */
		if ( ptsize >= face->num_fixed_sizes ) {
			ptsize = face->num_fixed_sizes - 1;
		}
		pFont->font_size_family = ptsize;
		error = FT_Set_Pixel_Sizes( face, face->available_sizes[ptsize].height, face->available_sizes[ptsize].width );
	  	/* With non-scalale fonts, Freetype2 likes to fill many of the
		 * font metrics with the value of 0.  The size of the
		 * non-scalable fonts must be determined differently
		 * or sometimes cannot be determined.
		 * */
	  	pFont->ascent = face->available_sizes[ptsize].height;
	  	pFont->descent = 0;
	  	pFont->height = face->available_sizes[ptsize].height;
	    pFont->maxHeight = FT_CEIL(pFont->ascent);
	  	pFont->underline_offset = FT_FLOOR(face->underline_position);
	  	pFont->underline_height = FT_FLOOR(face->underline_thickness);
	}

	if ( pFont->underline_height < 1 ) {
		pFont->underline_height = 1;
	}

	this->font = *pFont;
	return pFont;
}

int MKFont::openFont(string fileName) {
	int status = 0;
	FT_Fixed scale;
	FT_Error error = FT_New_Face( library, fileName.c_str(), 0, &face );
	if ( error ) {
		status = -1;
	}
	LogUtil::logInfo("font", "openFont FT_New_Face status:%d", status);

	return status;
}


int MKFont::setCharset(string charset) {
	int status = 0;
	FT_Error error =FT_Select_Charmap(face, FT_ENCODING_UNICODE);
	if ( error ) {
		status = -1;
	}
	return status;
}


int MKFont::Load_Glyph(  unsigned short ch, c_glyph* cached) {
	int want = CACHED_METRICS|CACHED_BITMAP;
	if(fontSize<12) {
		return -1;
	}
	TTF_Font* font = &this->font;
	int mono = (want & CACHED_BITMAP);
	FT_GlyphSlot glyph;
	FT_Bitmap dst;
	FT_Glyph bitmap_glyph = NULL;

	FT_Error error = 0;
	//ch = 618;
	int idx = FT_Get_Char_Index(face, ch);
	if(idx==0) {
		return FALSE;
	}
	//FT_Load_Glyph(face, idx, FT_LOAD_DEFAULT);
	FT_Load_Char(face, ch, FT_LOAD_RENDER);

	glyph = face->glyph;
	FT_Glyph_Metrics* metrics;
	metrics = &glyph->metrics;
	if ( FT_IS_SCALABLE( face ) ) {
		/* Get the bounding box */
		cached->minX = FT_FLOOR(metrics->horiBearingX);
		cached->maxX = cached->minX + FT_CEIL(metrics->width);
		cached->maxY = FT_FLOOR(metrics->horiBearingY);
		cached->minY = cached->maxY - FT_CEIL(metrics->height);
		cached->yOffset = font->ascent - cached->maxY;
		cached->advance = FT_CEIL(metrics->horiAdvance);
	} else {
		/* Get the bounding box for non-scalable format.
			* Again, freetype2 fills in many of the font metrics
			* with the value of 0, so some of the values we
			* need must be calculated differently with certain
			* assumptions about non-scalable formats.
			* */
		cached->minX = FT_FLOOR(metrics->horiBearingX);
		cached->maxX = cached->minX + FT_CEIL(metrics->horiAdvance);
		cached->maxY = FT_FLOOR(metrics->horiBearingY);
		cached->minY = cached->maxY - FT_CEIL(face->available_sizes[font->font_size_family].height);
		cached->yOffset = 0;
		cached->advance = FT_CEIL(metrics->horiAdvance);
	}
		
	//error = FT_Render_Glyph( glyph, FT_RENDER_MODE_NORMAL );
	FT_Bitmap &  bitmap = glyph->bitmap;
	int lineWidth =  0;
	if ( bitmap.pixel_mode == FT_PIXEL_MODE_MONO ) {
		lineWidth =  bitmap.pitch*8;
	}else {
		lineWidth =  bitmap.pitch;
	}
	unsigned char* buffer = (unsigned char *)malloc( lineWidth * bitmap.rows );
	memcpy(buffer,  bitmap.buffer, lineWidth*bitmap.rows);
	memcpy( &dst, &bitmap, sizeof( dst ) );
	dst.buffer = buffer;

	cached->pixmap = dst;

	FT_Done_Glyph(bitmap_glyph);
	return TRUE;
}

BOOL MKFont::getGlyph(c_glyph* aGlyh, int i, unsigned short c, int *w, int *h, int& minx, int& maxx, int& miny, int& maxy) {
	TTF_Font *font = &this->font;
	int status;
	const unsigned short *ch;
	int swapped;
	c_glyph *glyph;
	FT_Error error;
	FT_Long use_kerning;
	FT_UInt prev_index = 0;
	status = 0;

	glyph = aGlyh;
	int flag = Load_Glyph(c, glyph);
	if(flag==FALSE) {
		LogUtil::logError("font", "Load_Glyph err");
		return FALSE;
	}
	if(i==0) {
		minx = glyph->minX;
	}
	//if ( TTF_HANDLE_STYLE_BOLD(font) ) {
	//	x += font->glyph_overhang;
	//}

	maxx+=glyph->advance;
	if ( glyph->minY < miny ) {
		miny = glyph->minY;
	}
	if ( glyph->maxY > maxy ) {
		maxy = glyph->maxY;
	}
	return TRUE;
}

c_glyph* MKFont::getText(unsigned short* text, int len, int *w, int *h)
{
	c_glyph* worlds = new c_glyph[len];
	TTF_Font *font = &this->font;
	int status;
	const unsigned short *ch;
	int swapped;
	int minx, maxx;
	int miny, maxy;
	c_glyph *glyph;
	FT_Error error;
	FT_Long use_kerning;
	FT_UInt prev_index = 0;

	status = 0;
	minx = maxx = 0;
	miny = maxy = 0;

	int i=0;
	for ( ch=text; *ch; ++ch ) {
		unsigned short c = *ch;
		glyph = &worlds[i];
		BOOL flag = getGlyph(glyph, i, c, w, h, minx, maxx, miny, maxy);
		i++;
	}

	/* Fill the bounds rectangle */
	if ( w ) {
		/* Add outline extra width */
		*w = (maxx - minx);
	}
	if ( h ) {
		/* Some fonts descend below font height (FletcherGothicFLF) */
		/* Add outline extra height */
		*h = (font->ascent - miny);
		if ( *h < font->height ) {
			*h = font->height;
		}
		///* Update height according to the needs of the underline style */
		//if( TTF_HANDLE_STYLE_UNDERLINE(font) ) {
		//	int bottom_row = TTF_underline_bottom_row(font);
		//	if ( *h < bottom_row ) {
		//		*h = bottom_row;
		//	}
		//}
	}

	return worlds;
}

//////////////////////////////////////////////////////////////////////////////
MKFontWrap::MKFontWrap()
{
}

MKFontWrap::~MKFontWrap()
{
}

MKFontWrapPtr MKFontWrap::newInstance() {
	return make_shared<MKFontWrap>();  
}

int MKFontWrap::initFFT() {
	int status = 0;
	for(int i=0; i<fonts.size(); i++) {
		fonts.at(i)->initFFT();
	}

	LogUtil::logInfo("font", "initFFT status:%d", status);
	return status;
}

void MKFontWrap::unload() {
	for(int i=0; i<fonts.size(); i++) {
		fonts.at(i)->unload();
	}
}

void MKFontWrap::setFontSize(int ptsize) {
	for(int i=0; i<fonts.size(); i++) {
		fonts.at(i)->setFontSize(ptsize);
	}
}

int MKFontWrap::openFont(string fileName) {
	for(int i=0; i<fonts.size(); i++) {
		fonts.at(i)->openFont(fileName);
	}
	return 0;
}

int MKFontWrap::setCharset(string charset) {
	int status = 0;
	for(int i=0; i<fonts.size(); i++) {
		fonts.at(i)->setCharset(charset);
	}
	return status;
}


int MKFontWrap::Load_Glyph(  unsigned short ch, c_glyph* cached) {
	for(int i=0; i<fonts.size(); i++) {
		BOOL flag = fonts.at(i)->Load_Glyph(ch, cached);
		if(flag) {
			return TRUE;
		}
		if(i>1) {
			int a =0;
		}
	}
	BOOL flag = fonts.at(0)->Load_Glyph(' ', cached);
	if(flag) {
		return TRUE;
	}
	return FALSE;
}

void MKFontWrap::add(MKFontPtr ptr) {
	fonts.push_back(ptr);
}

BOOL MKFontWrap::getGlyph(c_glyph* aGlyh, int i, unsigned short c, int *w, int *h, int& minx, int& maxx, int& miny, int& maxy) {
	int status;
	const unsigned short *ch;
	int swapped;
	c_glyph *glyph;
	FT_Error error;
	FT_Long use_kerning;
	FT_UInt prev_index = 0;
	status = 0;

	glyph = aGlyh;
	int flag = Load_Glyph(c, glyph);
	if(flag==FALSE) {
		LogUtil::logError("font", "Load_Glyph err");
		return FALSE;
	}
	if(i==0) {
		minx = glyph->minX;
	}
	//if ( TTF_HANDLE_STYLE_BOLD(font) ) {
	//	x += font->glyph_overhang;
	//}

	maxx+=glyph->advance;
	if ( glyph->minY < miny ) {
		miny = glyph->minY;
	}
	if ( glyph->maxY > maxy ) {
		maxy = glyph->maxY;
	}
	
	return TRUE;
}

c_glyph* MKFontWrap::getText(unsigned short* text, int len, int *w, int *h)
{
	c_glyph* worlds = new c_glyph[len];
	TTF_Font *font = &this->fonts.at(0)->font;
	int status;
	const unsigned short *ch;
	int swapped;
	int minx, maxx;
	int miny, maxy;
	c_glyph *glyph;
	FT_Error error;
	FT_Long use_kerning;
	FT_UInt prev_index = 0;

	status = 0;
	minx = maxx = 0;
	miny = maxy = 0;

	int i=0;
	LogUtil::logInfo("text", "MKFontWrap::getText%p, len:%d", text, len);
	for ( ch=text; *ch; ++ch ) {
		unsigned short c = *ch;
		glyph = &worlds[i];
		BOOL flag = getGlyph(glyph, i, c, w, h, minx, maxx, miny, maxy);
		i++;
	}

	/* Fill the bounds rectangle */
	if ( w ) {
		/* Add outline extra width */
		*w = (maxx - minx);
	}
	if ( h ) {
		/* Some fonts descend below font height (FletcherGothicFLF) */
		/* Add outline extra height */
		*h = (font->ascent - miny);
		if ( *h < font->height ) {
			*h = font->height;
		}
		///* Update height according to the needs of the underline style */
		//if( TTF_HANDLE_STYLE_UNDERLINE(font) ) {
		//	int bottom_row = TTF_underline_bottom_row(font);
		//	if ( *h < bottom_row ) {
		//		*h = bottom_row;
		//	}
		//}
	}

	return worlds;
}