# -*- coding: utf-8 -*-
"""兼容 shim：转发到 .implementations.tracking.ledger_config"""
from .implementations.tracking.ledger_config import *
