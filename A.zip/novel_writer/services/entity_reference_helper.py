# -*- coding: utf-8 -*-
"""实体引用辅助 — 对标 EntityReferencePromptHelper.cs / EntityNameNormalizeHelper.cs"""
import re
from typing import List, Set


_IGNORED_VALUES: Set[str] = {
    "无", "暂无", "无特殊", "无明确", "无固定", "无特定",
    "无具体", "无其他", "无直接", "无相关", "无对应",
    "无显著", "无明显", "无此项", "无数据", "无信息",
    "无特别", "无限制", "无约束",
    "暂无特殊", "暂无明确", "暂无固定", "暂无特定",
    "暂无具体", "暂无其他", "暂无直接", "暂无相关",
    "暂无对应", "暂无显著", "暂无数据", "暂无信息",
    "无", "none", "None", "N/A", "n/a", "NA", "na",
    "", " ", "无", "无",
}


class EntityNameNormalizeHelper:
    """对标 EntityNameNormalizeHelper"""

    @staticmethod
    def is_ignored_value(value: str) -> bool:
        if not value or not value.strip():
            return True
        return value.strip() in _IGNORED_VALUES

    @staticmethod
    def filter_to_candidates(text: str, candidates: List[str]) -> str:
        """对标 FilterToCandidates: 只保留候选列表中的名称"""
        if not text or not candidates:
            return ""
        candidate_set = {c.strip() for c in candidates if c.strip()}
        parts = re.split(r"[、，,;；\n\r]", text)
        kept = []
        for p in parts:
            p = p.strip()
            if not p or EntityNameNormalizeHelper.is_ignored_value(p):
                continue
            if p in candidate_set:
                kept.append(p)
        return "、".join(kept)

    @staticmethod
    def filter_to_candidate(text: str, candidates: List[str]) -> str:
        """对标 FilterToCandidate: 单名称过滤"""
        if not text or not candidates:
            return ""
        candidate_set = {c.strip() for c in candidates if c.strip()}
        t = text.strip()
        if t in candidate_set:
            return t
        return ""

    @staticmethod
    def get_unmatched_names(text: str, candidates: List[str]) -> List[str]:
        """对标 GetUnmatchedNames: 返回不在候选列表中的名称"""
        if not text:
            return []
        candidate_set = {c.strip() for c in candidates if c.strip()}
        parts = re.split(r"[、，,;；\n\r]", text)
        unmatched = []
        for p in parts:
            p = p.strip()
            if not p or EntityNameNormalizeHelper.is_ignored_value(p):
                continue
            if p not in candidate_set:
                unmatched.append(p)
        return unmatched


class EntityReferencePromptHelper:
    """对标 EntityReferencePromptHelper: 构建候选实体 XML 段落"""

    @staticmethod
    def build_candidate_section(
        title: str,
        candidates: List[str],
        field_hint: str = "",
    ) -> str:
        """对标 BuildCandidateSection"""
        if not candidates:
            return ""
        sb = [f"<section name=\"{title}\">"]
        sb.append(field_hint)
        sb.append("、".join(candidates))
        sb.append("</section>")
        sb.append("")
        return "\n".join(sb)