# -*- coding: utf-8 -*-
"""分卷设计生成器 — 对标 VolumeDesignViewModel.AIGenerate.cs"""
import json
import os
import re
from typing import Callable, Dict, List, Optional, Tuple

from .chapter_allocation_helper import ChapterAllocationHelper, VolumeChapterRange
from .entity_reference_helper import EntityNameNormalizeHelper, EntityReferencePromptHelper
from .outline_service import OutlineService
from .volume_design_service import VolumeDesignService
from .context_service import ContextService
from ..models.generate.volume_design.volume_design_data import VolumeDesignData
from ..models.common import short_id, now_str


# 对标 VolumeTitlePrefixRegex
_VOLUME_TITLE_PREFIX_RE = re.compile(r"^第\s*\d+\s*卷(?:\s*[：:]\s*)?")


class VolumeDesignGenerator:
    """对标 VolumeDesignViewModel AIGenerate 逻辑

    负责:
    - 构建 AI 生成配置 (AIGenerationConfig)
    - 批量生成前的章节范围计算 (ShowBatchGenerationDialog)
    - 批量生成后的补缺/清尾 (ExecuteBatchAIGenerate)
    - 批量保存 (SaveBatchEntities)
    """

    # 对标 EntityFieldMeta.GetFieldKeyMap("volumedesign")
    OUTPUT_FIELDS = {
        "卷序号": "VolumeNumber",
        "卷标题": "VolumeTitle",
        "卷主题": "VolumeTheme",
        "卷阶段目标": "StageGoal",
        "卷主冲突": "MainConflict",
        "压力来源": "PressureSource",
        "关键转折": "KeyEvents",
        "卷开篇状态": "OpeningState",
        "卷收束状态": "EndingState",
        "章节分配总览": "ChapterAllocationOverview",
        "剧情分配": "PlotAllocation",
        "章节生成提示": "ChapterGenerationHints",
        "出场角色": "ReferencedCharacterNames",
        "涉及势力": "ReferencedFactionNames",
        "涉及地点": "ReferencedLocationNames",
        "名称": "Name",
    }

    def __init__(
        self,
        ai_chat: Callable,
        outline_service: OutlineService,
        volume_service: VolumeDesignService,
        context_service: ContextService,
        character_names: List[str],
        faction_names: List[str],
        location_names: List[str],
    ):
        self._ai = ai_chat
        self._outline_service = outline_service
        self._volume_service = volume_service
        self._context_service = context_service
        self._character_names = character_names
        self._faction_names = faction_names
        self._location_names = location_names
        # 批量状态
        self._batch_pre_calculated_ranges: List[VolumeChapterRange] = []
        self._batch_all_ranges: List[VolumeChapterRange] = []
        self._batch_expected_total_volumes = 0
        self._batch_range_index = 0

    # ---- 构建上下文 ----
    async def _build_context_async(
        self, volume_number: int, start_chapter: int, end_chapter: int,
        target_count: int
    ) -> str:
        """对标 ContextProvider"""
        volume_key = f"第{volume_number}卷" if volume_number > 0 else None
        sb = []

        base_ctx = await self._context_service.get_volume_design_structure_context_async(volume_key)
        if base_ctx:
            sb.append(base_ctx)
            sb.append("")

        if start_chapter > 0 and end_chapter > 0:
            sb.append(f'<section name="volume_chapter_range" locked="true">')
            sb.append(f"- 本卷为第{volume_number}卷，共 {target_count} 章")
            sb.append(f"- 章节范围：第 {start_chapter} 章 ～ 第 {end_chapter} 章")
            sb.append(f"- 「章节分配总览」「剧情分配」「章节生成提示」中所有章节编号必须严格在此范围内（{start_chapter}～{end_chapter}），不得使用此范围之外的任何章节编号。")
            sb.append("</section>")
            sb.append("")

        if self._character_names:
            sb.append(EntityReferencePromptHelper.build_candidate_section(
                "可选角色", self._character_names,
                "「出场角色」必须从以下列表中选择，不得编造"))
        if self._faction_names:
            sb.append(EntityReferencePromptHelper.build_candidate_section(
                "可选势力", self._faction_names,
                "「涉及势力」必须从以下列表中选择，不得编造"))
        if self._location_names:
            sb.append(EntityReferencePromptHelper.build_candidate_section(
                "可选地点", self._location_names,
                "「涉及地点」必须从以下列表中选择，不得编造"))

        sb.append('<field_constraints mandatory="true">')
        sb.append('1. 「卷序号」必须为整数（仅数字）。')
        sb.append('2. 「章节分配总览」「剧情分配」「章节生成提示」如有多条，请在字符串内用换行分条。')
        sb.append('3. 「起始章节」「结束章节」「目标章节数」由系统自动分配，无需在JSON中输出这三个字段。')
        sb.append('4. 「出场角色」「涉及势力」「涉及地点」必须从上方候选列表中精确选取，以字符串形式输出（不要用JSON数组）。')
        sb.append('</field_constraints>')
        sb.append("")

        return "\n".join(sb)

    # ---- 单卷生成 ----
    async def generate_volume_async(
        self, volume_number: int, start_chapter: int, end_chapter: int,
        target_count: int, system_prompt: str, category_name: str
    ) -> VolumeDesignData:
        """对标 AI 单次生成 + 表单填充"""
        context = await self._build_context_async(volume_number, start_chapter, end_chapter, target_count)
        user_prompt = json.dumps(
            {cn: f"【{cn}】的值" for cn in self.OUTPUT_FIELDS},
            ensure_ascii=False, indent=2,
        )
        if context:
            system_prompt = system_prompt + "\n\n" + context

        text = self._ai(system_prompt, user_prompt, category="分卷设计")
        data = self._extract_json(text) or {}

        return self._data_from_json(
            data, volume_number, start_chapter, end_chapter, target_count, category_name
        )

    def _data_from_json(
        self, data: dict, volume_number: int, start_chapter: int, end_chapter: int,
        target_count: int, category_name: str
    ) -> VolumeDesignData:
        """对标 SaveBatchEntitiesAsync / UpdateDataFromForm"""
        # 卷序号解析
        vn_raw = data.get("卷序号", volume_number)
        vn = int(vn_raw) if isinstance(vn_raw, (int, float)) else self._safe_parse_int(str(vn_raw) if vn_raw else "")
        if vn <= 0:
            vn = volume_number

        ref_chars = self._resolve_names(
            data.get("出场角色", ""), self._character_names)
        ref_facs = self._resolve_names(
            data.get("涉及势力", ""), self._faction_names)
        ref_locs = self._resolve_names(
            data.get("涉及地点", ""), self._location_names)

        return VolumeDesignData(
            Id=short_id("D"),
            Name=data.get("名称", f"第{volume_number}卷"),
            Category=category_name,
            IsEnabled=True,
            CreatedAt=now_str(),
            UpdatedAt=now_str(),
            VolumeNumber=vn,
            VolumeTitle=self._strip_volume_prefix(data.get("卷标题", "")),
            VolumeTheme=data.get("卷主题", ""),
            StageGoal=data.get("卷阶段目标", ""),
            TargetChapterCount=target_count,
            StartChapter=start_chapter,
            EndChapter=end_chapter,
            MainConflict=data.get("卷主冲突", ""),
            PressureSource=data.get("压力来源", ""),
            KeyEvents=self._split_lines(data.get("关键转折", "")),
            OpeningState=data.get("卷开篇状态", ""),
            EndingState=data.get("卷收束状态", ""),
            ChapterAllocationOverview=data.get("章节分配总览", ""),
            PlotAllocation=data.get("剧情分配", ""),
            ChapterGenerationHints=data.get("章节生成提示", ""),
            ReferencedCharacterNames=ref_chars,
            ReferencedFactionNames=ref_facs,
            ReferencedLocationNames=ref_locs,
        )

    # ---- 批量生成 ----
    async def prepare_batch_async(
        self, category_name: str, total_volumes: int, total_chapters: int
    ) -> Optional[List[VolumeChapterRange]]:
        """对标 ShowBatchGenerationDialogAsync: 计算待生成卷的章节范围"""
        # 从大纲解析卷划分
        outlines = self._outline_service.get_all_outlines()
        volume_division = ""
        for o in outlines:
            if o.IsEnabled and o.VolumeDivision:
                volume_division = o.VolumeDivision
                break

        all_ranges: List[VolumeChapterRange] = []
        ok, parsed = ChapterAllocationHelper.try_parse_volume_division(
            volume_division, total_volumes, total_chapters)
        if ok:
            all_ranges = parsed
        else:
            all_ranges = ChapterAllocationHelper.allocate(total_volumes, total_chapters)

        # 跳过已有内容的卷
        existing = self._volume_service.get_all_volume_designs()
        existing_with_content = {
            v.VolumeNumber for v in existing
            if v.VolumeTheme and v.MainConflict and v.Category == category_name
        }

        self._batch_all_ranges = all_ranges
        self._batch_expected_total_volumes = total_volumes
        self._batch_range_index = 0
        self._batch_pre_calculated_ranges = [
            r for r in all_ranges if r.VolumeNumber not in existing_with_content
        ]

        if not self._batch_pre_calculated_ranges:
            self._batch_pre_calculated_ranges = []
            self._batch_all_ranges = []
            self._batch_expected_total_volumes = 0
            return None

        return self._batch_pre_calculated_ranges

    def get_next_range(self) -> Optional[VolumeChapterRange]:
        """获取下一个待生成卷的范围"""
        if (self._batch_pre_calculated_ranges
                and self._batch_range_index < len(self._batch_pre_calculated_ranges)):
            r = self._batch_pre_calculated_ranges[self._batch_range_index]
            self._batch_range_index += 1
            return r
        return None

    async def finalize_batch_async(self, category_name: str, success: bool, cancelled: bool):
        """对标 ExecuteBatchAIGenerateAsync: 补缺/清尾"""
        if not self._batch_all_ranges:
            self._reset_batch()
            return

        if cancelled:
            # 删除空壳
            self._cleanup_empty_shells(category_name)
        elif success:
            # 补缺占位
            for r in self._batch_all_ranges:
                existing = None
                for v in self._volume_service.get_all_volume_designs():
                    if v.VolumeNumber == r.VolumeNumber and v.Category == category_name:
                        existing = v
                        break
                if existing:
                    existing.StartChapter = r.StartChapter
                    existing.EndChapter = r.EndChapter
                    existing.TargetChapterCount = r.TargetChapterCount
                    self._volume_service.update_volume_design(existing)
                else:
                    data = VolumeDesignData(
                        Id=short_id("D"),
                        Name=f"第{r.VolumeNumber}卷",
                        Category=category_name,
                        IsEnabled=True,
                        CreatedAt=now_str(),
                        UpdatedAt=now_str(),
                        VolumeNumber=r.VolumeNumber,
                        VolumeTitle=f"第{r.VolumeNumber}卷",
                        StartChapter=r.StartChapter,
                        EndChapter=r.EndChapter,
                        TargetChapterCount=r.TargetChapterCount,
                    )
                    self._volume_service.add_volume_design(data)

        self._reset_batch()

    def _cleanup_empty_shells(self, category_name: str):
        for v in self._volume_service.get_all_volume_designs():
            if v.Category == category_name and not v.VolumeTheme and not v.MainConflict:
                self._volume_service.delete_volume_design(v.Id)

    def _reset_batch(self):
        self._batch_pre_calculated_ranges = []
        self._batch_all_ranges = []
        self._batch_expected_total_volumes = 0
        self._batch_range_index = 0

    # ---- 实体引用校验 ----
    def _resolve_names(self, raw: str, candidates: List[str]) -> List[str]:
        if not raw:
            return []
        resolved = EntityNameNormalizeHelper.filter_to_candidates(raw, candidates)
        if not resolved:
            return []
        return [n.strip() for n in re.split(r"[、，,]", resolved) if n.strip()]

    @staticmethod
    def _safe_parse_int(text: str) -> int:
        if not text:
            return 0
        text = text.strip()
        try:
            return int(text)
        except ValueError:
            pass
        digits = "".join(re.findall(r"\d+", text))
        if digits:
            return int(digits)
        return 0

    @staticmethod
    def _strip_volume_prefix(title: str) -> str:
        if not title:
            return title
        return _VOLUME_TITLE_PREFIX_RE.sub("", title).strip()

    @staticmethod
    def _split_lines(text: str) -> List[str]:
        if not text:
            return []
        return [t.strip() for t in re.split(r"[、，,\n]", text) if t.strip()]

    @staticmethod
    def _extract_json(text: str):
        if not text:
            return None
        t = text.strip()
        if t.startswith("```"):
            t = re.sub(r"^```(?:json)?\s*\n?", "", t)
            t = re.sub(r"\n?\s*```\s*$", "", t)
        start = t.find("{")
        if start == -1:
            return None
        depth, in_str, esc = 0, 0, 0
        for i in range(start, len(t)):
            ch = t[i]
            if in_str:
                if esc:
                    esc = 0
                elif ch == "\\":
                    esc = 1
                elif ch == '"':
                    in_str = 0
                continue
            if ch == '"':
                in_str = 1
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(t[start:i + 1])
                    except json.JSONDecodeError:
                        pass
        try:
            return json.loads(t)
        except json.JSONDecodeError:
            return None