# -*- coding: utf-8 -*-
"""分卷设计服务 — 对标 VolumeDesignService.cs"""
import json
import os
from typing import List, Optional

from ..models.generate.volume_design.volume_design_data import VolumeDesignData
from ..models.generate.volume_design.volume_design_category import VolumeDesignCategory
from ..storage import _atomic_write, _read_json


class VolumeDesignService:
    """对标 VolumeDesignService: ModuleServiceBase<VolumeDesignCategory, VolumeDesignData>

    模块路径: Generate/Elements/VolumeDesign
    """

    def __init__(self, project_dir: str):
        self._project_dir = project_dir
        self._module_dir = os.path.join(project_dir, "Generate", "Elements", "VolumeDesign")
        self._categories_path = os.path.join(self._module_dir, "categories.json")
        self._data_path = os.path.join(self._module_dir, "volume_design_data.json")
        self._categories: List[VolumeDesignCategory] = []
        self._data: List[VolumeDesignData] = []
        self._initialized = False
        self._data_callbacks = []  # 对标 DataChanged event

    def on_data_changed(self, callback):
        self._data_callbacks.append(callback)

    def _raise_data_changed(self):
        for cb in self._data_callbacks:
            try:
                cb()
            except Exception:
                pass

    # ---- 初始化 ----
    def ensure_initialized(self):
        if not self._initialized:
            self._load()

    def initialize(self):
        self._load()

    def _load(self):
        os.makedirs(self._module_dir, exist_ok=True)
        raw_cats = _read_json(self._categories_path, [])
        self._categories = [VolumeDesignCategory.from_dict(c) for c in raw_cats] if raw_cats else []
        raw_data = _read_json(self._data_path, [])
        self._data = [VolumeDesignData.from_dict(d) for d in raw_data] if raw_data else []
        self._initialized = True

    def _save_categories(self):
        _atomic_write(self._categories_path, [c.to_dict() for c in self._categories])

    def _save_data(self):
        _atomic_write(self._data_path, [d.to_dict() for d in self._data])

    # ---- 分类 CRUD ----
    def get_all_categories(self) -> List[VolumeDesignCategory]:
        self.ensure_initialized()
        return list(self._categories)

    def add_category(self, category: VolumeDesignCategory) -> bool:
        self.ensure_initialized()
        if any(c.Name == category.Name for c in self._categories):
            return False
        self._categories.append(category)
        self._save_categories()
        return True

    def update_category(self, category: VolumeDesignCategory) -> bool:
        self.ensure_initialized()
        for i, c in enumerate(self._categories):
            if c.Id == category.Id:
                self._categories[i] = category
                self._save_categories()
                return True
        return False

    def delete_category(self, name: str):
        self.ensure_initialized()
        self._categories = [c for c in self._categories if c.Name != name]
        self._save_categories()

    # ---- 数据 CRUD ----
    def get_all_volume_designs(self) -> List[VolumeDesignData]:
        self.ensure_initialized()
        return list(self._data)

    def add_volume_design(self, data: VolumeDesignData):
        self.ensure_initialized()
        if data.VolumeNumber > 0 and any(v.VolumeNumber == data.VolumeNumber for v in self._data):
            return
        self._data.append(data)
        self._save_data()
        self._raise_data_changed()

    def update_volume_design(self, data: VolumeDesignData):
        self.ensure_initialized()
        for i, d in enumerate(self._data):
            if d.Id == data.Id:
                self._data[i] = data
                self._save_data()
                self._raise_data_changed()
                return

    def delete_volume_design(self, id_: str):
        self.ensure_initialized()
        self._data = [d for d in self._data if d.Id != id_]
        self._save_data()
        self._raise_data_changed()

    def clear_all_volume_designs(self) -> int:
        self.ensure_initialized()
        count = len(self._data)
        self._data.clear()
        self._save_data()
        self._raise_data_changed()
        return count

    # ---- 批量操作 ----
    def begin_batch_save(self):
        pass

    def end_batch_save(self):
        self._save_data()

    @staticmethod
    def has_content(data: VolumeDesignData) -> bool:
        return bool(data.VolumeTitle or data.VolumeTheme or data.StageGoal)

    @staticmethod
    def get_derived_category_name(data: VolumeDesignData) -> str:
        if data.VolumeNumber <= 0:
            return data.Name
        import re
        clean_title = re.sub(r"^第\s*\d+\s*卷\s*[：:]\s*", "", data.VolumeTitle.strip())
        return f"第{data.VolumeNumber}卷 {clean_title}".strip()