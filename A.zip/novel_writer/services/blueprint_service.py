# -*- coding: utf-8 -*-
"""蓝图服务 — 对标 BlueprintService.cs"""
import json
import os
from typing import List, Optional

from ..models.generate.chapter_blueprint.blueprint_data import BlueprintData
from ..models.generate.chapter_blueprint.blueprint_category import BlueprintCategory
from ..storage import _atomic_write, _read_json
from .volume_design_service import VolumeDesignService


class BlueprintService:
    """对标 BlueprintService: ModuleServiceBase<BlueprintCategory, BlueprintData>

    模块路径: Generate/Elements/Blueprint
    - 分类从 VolumeDesignService 订阅
    """

    def __init__(self, project_dir: str, volume_design_service: VolumeDesignService):
        self._project_dir = project_dir
        self._module_dir = os.path.join(project_dir, "Generate", "Elements", "Blueprint")
        self._categories_path = os.path.join(self._module_dir, "categories.json")
        self._data_path = os.path.join(self._module_dir, "blueprint_data.json")
        self._categories: List[BlueprintCategory] = []
        self._data: List[BlueprintData] = []
        self._volume_design_service = volume_design_service
        self._initialized = False

    # ---- 初始化 ----
    def ensure_initialized(self):
        if not self._initialized:
            self._load()

    def initialize(self):
        self._load()

    def _load(self):
        os.makedirs(self._module_dir, exist_ok=True)
        raw_cats = _read_json(self._categories_path, [])
        self._categories = [BlueprintCategory.from_dict(c) for c in raw_cats] if raw_cats else []
        raw_data = _read_json(self._data_path, [])
        self._data = [BlueprintData.from_dict(d) for d in raw_data] if raw_data else []
        self._initialized = True
        self._sync_categories()

    def _sync_categories(self):
        """对标 OnInitializedAsync: 从分卷设计同步分类"""
        self._volume_design_service.ensure_initialized()
        vols = self._volume_design_service.get_all_volume_designs()
        vols.sort(key=lambda v: v.VolumeNumber)
        volume_categories = []
        for v in vols:
            cat_name = f"第{v.VolumeNumber}卷 {v.VolumeTitle}".strip() if v.VolumeNumber > 0 else v.Name
            volume_categories.append(BlueprintCategory(
                Id=v.Id,
                Name=cat_name,
                Icon="Icon.Books",
                Order=v.VolumeNumber,
                IsBuiltIn=False,
                IsEnabled=v.IsEnabled,
            ))
        self._categories = volume_categories

    def _save_categories(self):
        _atomic_write(self._categories_path, [c.to_dict() for c in self._categories])

    def _save_data(self):
        _atomic_write(self._data_path, [d.to_dict() for d in self._data])

    # ---- 分类 ----
    def get_all_categories(self) -> List[BlueprintCategory]:
        self.ensure_initialized()
        return list(self._categories)

    # ---- 数据 CRUD ----
    def get_all_blueprints(self) -> List[BlueprintData]:
        self.ensure_initialized()
        return list(self._data)

    def add_blueprint(self, data: BlueprintData):
        self.ensure_initialized()
        self._ensure_category_id(data)
        self._data.append(data)
        self._save_data()

    def update_blueprint(self, data: BlueprintData):
        self.ensure_initialized()
        self._ensure_category_id(data)
        for i, d in enumerate(self._data):
            if d.Id == data.Id:
                self._data[i] = data
                self._save_data()
                return

    def delete_blueprint(self, id_: str):
        self.ensure_initialized()
        self._data = [d for d in self._data if d.Id != id_]
        self._save_data()

    def clear_all_blueprints(self) -> int:
        self.ensure_initialized()
        count = len(self._data)
        self._data.clear()
        self._save_data()
        return count

    def _ensure_category_id(self, data: BlueprintData):
        if data.CategoryId:
            return
        if not data.Category:
            return
        self._volume_design_service.ensure_initialized()
        for v in self._volume_design_service.get_all_volume_designs():
            expected = f"第{v.VolumeNumber}卷 {v.VolumeTitle}".strip() if v.VolumeNumber > 0 else v.Name
            if expected == data.Category or v.Name == data.Category:
                data.CategoryId = v.Id
                return

    # ---- 批量操作 ----
    def begin_batch_save(self):
        pass

    def end_batch_save(self):
        self._save_data()

    @staticmethod
    def has_content(data: BlueprintData) -> bool:
        return bool(data.ChapterId or data.OneLineStructure or data.SceneTitle)