# -*- coding: utf-8 -*-
"""章节服务 — 对标 ChapterService.cs"""
import json
import os
from typing import List, Optional

from ..models.generate.chapter_planning.chapter_data import ChapterData
from ..models.generate.chapter_planning.chapter_category import ChapterCategory
from ..storage import _atomic_write, _read_json
from .volume_design_service import VolumeDesignService


class ChapterService:
    """对标 ChapterService: ModuleServiceBase<ChapterCategory, ChapterData>

    模块路径: Generate/Elements/Chapter
    - 分类从 VolumeDesignService 订阅
    - 支持仿写分类 (RewriteCategory)
    """

    def __init__(self, project_dir: str, volume_design_service: VolumeDesignService):
        self._project_dir = project_dir
        self._module_dir = os.path.join(project_dir, "Generate", "Elements", "Chapter")
        self._categories_path = os.path.join(self._module_dir, "categories.json")
        self._data_path = os.path.join(self._module_dir, "chapter_data.json")
        self._categories: List[ChapterCategory] = []
        self._data: List[ChapterData] = []
        self._volume_design_service = volume_design_service
        self._initialized = False
        self._data_callbacks = []

    def on_data_changed(self, callback):
        self._data_callbacks.append(callback)

    def _raise_data_changed(self):
        for cb in self._data_callbacks:
            try:
                cb()
            except Exception:
                pass

    # ---- 初始化 ----
    def ensure_initialized(self):
        if not self._initialized:
            self._load()

    def initialize(self):
        self._load()

    def _load(self):
        os.makedirs(self._module_dir, exist_ok=True)
        raw_cats = _read_json(self._categories_path, [])
        self._categories = [ChapterCategory.from_dict(c) for c in raw_cats] if raw_cats else []
        raw_data = _read_json(self._data_path, [])
        self._data = [ChapterData.from_dict(d) for d in raw_data] if raw_data else []
        self._initialized = True
        # 同步分类（来自分卷设计）
        self._sync_categories()

    def _sync_categories(self):
        """对标 OnInitializedAsync: 从分卷设计同步分类"""
        self._volume_design_service.ensure_initialized()
        subscribed = self._get_subscribed_categories()
        rewrite = self._get_rewrite_categories()
        merged = subscribed + [r for r in rewrite
                               if not any(s.Name == r.Name for s in subscribed)]
        merged.sort(key=lambda c: c.Order)
        self._categories = merged

    def _get_subscribed_categories(self) -> List[ChapterCategory]:
        vols = self._volume_design_service.get_all_volume_designs()
        vols.sort(key=lambda v: v.VolumeNumber)
        result = []
        for v in vols:
            cat_name = f"第{v.VolumeNumber}卷 {v.VolumeTitle}".strip() if v.VolumeNumber > 0 else v.Name
            result.append(ChapterCategory(
                Id=v.Id,
                Name=cat_name,
                Icon="Icon.Books",
                Order=v.VolumeNumber,
                IsBuiltIn=True,
                IsEnabled=v.IsEnabled,
            ))
        return result

    def _get_rewrite_categories(self) -> List[ChapterCategory]:
        return [c for c in self._categories if not c.IsBuiltIn]

    def _save_categories(self):
        _atomic_write(self._categories_path, [c.to_dict() for c in self._categories])

    def _save_data(self):
        _atomic_write(self._data_path, [d.to_dict() for d in self._data])

    # ---- 分类 CRUD ----
    def get_all_categories(self) -> List[ChapterCategory]:
        self.ensure_initialized()
        return self._get_subscribed_categories() + self._get_rewrite_categories()

    def add_rewrite_category(self, category: ChapterCategory) -> bool:
        self.ensure_initialized()
        if any(c.Name == category.Name for c in self._categories):
            return False
        subscribed = self._get_subscribed_categories()
        if any(c.Name == category.Name for c in subscribed):
            return False
        category.IsBuiltIn = False
        self._categories.append(category)
        self._save_categories()
        self._raise_data_changed()
        return True

    def delete_rewrite_category(self, name: str):
        self.ensure_initialized()
        self._categories = [c for c in self._categories if c.Name != name or c.IsBuiltIn]
        self._save_categories()
        self._raise_data_changed()

    # ---- 数据 CRUD ----
    def get_all_chapters(self) -> List[ChapterData]:
        self.ensure_initialized()
        return list(self._data)

    def add_chapter(self, data: ChapterData):
        self.ensure_initialized()
        self._ensure_category_id(data)
        self._data.append(data)
        self._save_data()
        self._raise_data_changed()

    def update_chapter(self, data: ChapterData):
        self.ensure_initialized()
        self._ensure_category_id(data)
        for i, d in enumerate(self._data):
            if d.Id == data.Id:
                self._data[i] = data
                self._save_data()
                self._raise_data_changed()
                return

    def delete_chapter(self, id_: str):
        self.ensure_initialized()
        self._data = [d for d in self._data if d.Id != id_]
        self._save_data()
        self._raise_data_changed()

    def clear_all_chapters(self) -> int:
        self.ensure_initialized()
        count = len(self._data)
        self._data.clear()
        self._save_data()
        self._raise_data_changed()
        return count

    def _ensure_category_id(self, data: ChapterData):
        if data.CategoryId:
            return
        if not data.Category:
            return
        self._volume_design_service.ensure_initialized()
        for v in self._volume_design_service.get_all_volume_designs():
            expected = f"第{v.VolumeNumber}卷 {v.VolumeTitle}".strip() if v.VolumeNumber > 0 else v.Name
            if expected == data.Category or v.Name == data.Category:
                data.CategoryId = v.Id
                return

    # ---- 批量操作 ----
    def begin_batch_save(self):
        pass

    def end_batch_save(self):
        self._save_data()

    @staticmethod
    def has_content(data: ChapterData) -> bool:
        return bool(data.ChapterTitle or data.MainGoal or data.ChapterTheme)