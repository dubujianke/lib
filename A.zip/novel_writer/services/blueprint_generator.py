# -*- coding: utf-8 -*-
"""章节蓝图生成器 — 对标 BlueprintViewModel.AIGenerate.cs + Helpers + BatchExecution + DataOperations"""
import json
import re
from typing import Callable, Dict, List, Optional, Set, Tuple

from .chapter_allocation_helper import ChapterAllocationHelper, VolumeChapterRange
from .entity_reference_helper import EntityNameNormalizeHelper, EntityReferencePromptHelper
from .outline_service import OutlineService
from .volume_design_service import VolumeDesignService
from .chapter_service import ChapterService
from .context_service import ContextService
from ..models.generate.chapter_blueprint.blueprint_data import BlueprintData
from ..models.generate.volume_design.volume_design_data import VolumeDesignData
from ..models.generate.chapter_planning.chapter_data import ChapterData
from ..models.common import short_id, now_str


# 对标 BlueprintViewModel 正则
_VOL_CN_RE = re.compile(r"第\s*(\d+)\s*卷", re.IGNORECASE)
_VOL_CH_ID_RE = re.compile(r"vol(\d+)_ch(\d+)", re.IGNORECASE)
_VOL_CH_ID_PARTIAL_RE = re.compile(r"vol(\d+)_ch\d+", re.IGNORECASE)
_CATEGORY_VOL_NUM_RE = re.compile(r"第(\d+)卷", re.IGNORECASE)
_CHAPTER_SUFFIX_NUM_RE = re.compile(r"_ch(?P<ch>\d+)", re.IGNORECASE)
_VOL_INPUT_PARSE_RE = re.compile(r"vol\s*(\d+)", re.IGNORECASE)
_CH_INPUT_PARSE_RE = re.compile(r"ch\s*(\d+)|第\s*(\d+)\s*章|章\s*(\d+)", re.IGNORECASE)

# 标题清理正则
_CLEAN_NUM_RANGE_RE = re.compile(r"^\s*\d+\s*[-_－—–]\s*\d+\s*")
_CLEAN_VOL_CH_STR_RE = re.compile(r"^\s*vol\s*\d+\s*[_-]?ch\s*\d+\s*", re.IGNORECASE)
_CLEAN_CH_PREFIX_RE = re.compile(r"^\s*ch\s*\d+\s*", re.IGNORECASE)
_CLEAN_SCENE_BP_RE = re.compile(r"^\s*场景蓝图[-_]*", re.IGNORECASE)
_CLEAN_SCENE_NUM_RE = re.compile(r"^\s*场景\s*[-_]?\d+(?:-\d+)?\s*", re.IGNORECASE)
_CLEAN_VOL_CH_ARABIC_RE = re.compile(r"^\s*第\s*\d+\s*卷\s*[-_\s]*第\s*\d+\s*章\s*[-_\s]*")
_CLEAN_VOL_CH_CHINESE_RE = re.compile(
    r"^\s*第\s*[一二三四五六七八九十百千零]+\s*卷\s*[-_\s]*"
    r"第\s*[一二三四五六七八九十百千零]+\s*章\s*[-_\s]*")
_CLEAN_SCENE_REF_RE = re.compile(r"(^|[-_\s])scene\s*[-_]?\d+(?:-\d+)?", re.IGNORECASE)
_CLEAN_VOL_REF_RE = re.compile(r"(^|[-_\s])vol\d+(_?ch\d+)?(-\d+)?", re.IGNORECASE)
_CLEAN_VOL_NUM_RE = re.compile(r"(^|[-_\s])卷\d+[-_\s]*", re.IGNORECASE)
_CLEAN_CH_NUM_RE = re.compile(r"(^|[-_\s])章\d+[-_\s]*", re.IGNORECASE)

# 章节标题正则
_NORM_CH_VOL_ARABIC_RE = re.compile(r"^\s*第\s*\d+\s*卷\s*[：:、\-—–]*\s*第\s*\d+\s*章\s*[：:、\-—–]*\s*")
_NORM_CH_VOL_CHINESE_RE = re.compile(
    r"^\s*第\s*[一二三四五六七八九十百千零]+\s*卷\s*[：:、\-—–]*\s*"
    r"第\s*[一二三四五六七八九十百千零]+\s*章\s*[：:、\-—–]*\s*")
_NORM_CH_ARABIC_RE = re.compile(r"^\s*第\s*\d+\s*章\s*[：:、\-—–]*\s*")
_NORM_CH_CHINESE_RE = re.compile(r"^\s*第\s*[一二三四五六七八九十百千零]+\s*章\s*[：:、\-—–]*\s*")


class BlueprintGenerator:
    """对标 BlueprintViewModel AIGenerate + Helpers + BatchExecution"""

    # 对标 EntityFieldMeta.GetFieldKeyMap("blueprint")
    OUTPUT_FIELDS = {
        "场景标题": "SceneTitle",
        "一句话结构": "OneLineStructure",
        "节奏曲线": "PacingCurve",
        "视点角色": "PovCharacter",
        "开场": "Opening",
        "发展": "Development",
        "转折": "Turning",
        "结尾": "Ending",
        "信息释放": "InfoDrop",
        "物品线索": "ItemsClues",
        "出场角色": "Cast",
        "涉及地点": "Locations",
        "涉及势力": "Factions",
        "名称": "Name",
    }

    def __init__(
        self,
        ai_chat: Callable,
        outline_service: OutlineService,
        volume_service: VolumeDesignService,
        chapter_service: ChapterService,
        context_service: ContextService,
        character_service_get_names: Callable[[], List[str]],
        faction_service_get_names: Callable[[], List[str]],
        location_service_get_names: Callable[[], List[str]],
    ):
        self._ai = ai_chat
        self._outline_service = outline_service
        self._volume_service = volume_service
        self._chapter_service = chapter_service
        self._context_service = context_service
        self._get_char_names = character_service_get_names
        self._get_fac_names = faction_service_get_names
        self._get_loc_names = location_service_get_names
        # 批量状态
        self._batch_full_chapter_ids: List[str] = []
        self._batch_pre_calculated_chapter_ids: List[str] = []
        self._batch_chapter_id_index = 0
        self._current_batch_chapter_ids: List[str] = []
        self._current_batch_chapter_ids_all: List[str] = []

    # ---- 上下文构建 ----
    async def _build_context_async(
        self, category_name: str, chapter_id: str, is_batch: bool = False
    ) -> str:
        sb = []

        if is_batch and category_name:
            volume_context = await self._context_service.get_chapter_context_with_volume_locator_async(
                category_name)
            if volume_context:
                sb.append(volume_context)
                sb.append("")

            chapter_summary = self._build_volume_chapter_summary(category_name)
            if chapter_summary:
                sb.append('<section name="volume_chapter_plan">')
                sb.append(chapter_summary)
                sb.append("</section>")
                sb.append("")
        else:
            base_ctx = await self._context_service.get_blueprint_context_with_chapter_locator_async(
                chapter_id)
            if base_ctx:
                sb.append(base_ctx)
                sb.append("")

            chapter_ids = self._get_available_chapter_ids(category_name)
            if chapter_ids:
                sb.append('<section name="available_chapter_ids">')
                sb.append('关联章节ID必须从以下列表中选择，格式：vol{卷号}_ch{章号}')
                sb.append("、".join(chapter_ids))
                sb.append("</section>")
                sb.append("")

        # 实体池
        char_names, loc_names, fac_names = self._get_scoped_entity_pools(
            chapter_id, category_name)
        if not char_names:
            char_names = self._get_char_names()
        if not loc_names:
            loc_names = self._get_loc_names()
        if not fac_names:
            fac_names = self._get_fac_names()

        if char_names:
            sb.append(EntityReferencePromptHelper.build_candidate_section(
                "可选角色", char_names,
                "「出场角色」必须从以下列表中选择，不得编造"))
        if loc_names:
            sb.append(EntityReferencePromptHelper.build_candidate_section(
                "可选地点", loc_names,
                "「涉及地点」必须从以下列表中选择，不得编造"))
        if fac_names:
            sb.append(EntityReferencePromptHelper.build_candidate_section(
                "可选势力", fac_names,
                "「涉及势力」必须从以下列表中选择，不得编造"))

        if char_names:
            sb.append('<section name="available_pov_characters">')
            sb.append("视点角色必须从以下列表中选择")
            sb.append("、".join(char_names))
            sb.append("</section>")
            sb.append("")

        sb.append('<field_constraints mandatory="true">')
        sb.append('1. 「关联章节ID」由系统自动分配，AI不应生成此字段。')
        sb.append('2. 「视点角色」必须从上方可选角色列表中选择，填写单个角色名称；无则填写「暂无」。')
        sb.append('3. 「出场角色」「涉及地点」「涉及势力」必须从上方对应候选列表中选择，多个名称使用顿号分隔；无则填写「暂无」。')
        sb.append('</field_constraints>')
        sb.append("")

        # Golden chapter requirement (chapters 1-3)
        _ch_id_match = re.match(r"vol(\d+)_ch(\d+)", chapter_id, re.IGNORECASE) if chapter_id else None
        if _ch_id_match:
            ch_num = int(_ch_id_match.group(2))
            if 1 <= ch_num <= 3:
                golden_section = []
                golden_section.append('<golden_chapter_requirement priority="high">')
                golden_section.append(f"当前是第{ch_num}章（黄金三章阶段），蓝图设计必须额外满足：")
                golden_section.append("【开场】前200字内直接切入冲突或悬念，禁止慢热铺垫和背景堆砌")
                golden_section.append("【主角】本章必须有让读者立刻记住主角的高光时刻，展现核心特质")
                golden_section.append("【结尾钉子】悬念强度必须高于普通章节，直接驱动读者翻下一章")
                if ch_num == 1:
                    golden_section.append("【第1章专项】2分钟内让读者明白：故事背景、主角处境、核心矛盾是什么")
                if ch_num == 2:
                    golden_section.append("【第2章专项】激化第1章冲突，主角遭遇真正阻力，情绪曲线向下走")
                if ch_num == 3:
                    golden_section.append("【第3章专项】推向前期第一个小高潮，结尾是全书前三章最强悬念节点")
                golden_section.append("</golden_chapter_requirement>")
                golden_section.append("")
                sb.extend(golden_section)

        return "\n".join(sb)

    def _build_volume_chapter_summary(self, category_name: str) -> str:
        """对标 BuildVolumeChapterSummary"""
        chapters = [
            c for c in self._chapter_service.get_all_chapters()
            if c.IsEnabled and c.Category == category_name
        ]
        chapters.sort(key=lambda c: c.ChapterNumber)
        if not chapters:
            return ""

        sb = []
        for ch in chapters:
            vol_num = self._extract_volume_number(ch.Volume)
            if vol_num <= 0:
                vol_num = self._extract_volume_number(ch.Category)
            if vol_num <= 0:
                continue
            ch_id = f"vol{vol_num}_ch{ch.ChapterNumber}"
            sb.append(f'<item name="{ch_id} - 第{ch.ChapterNumber}章：{ch.ChapterTitle}">')
            if ch.MainGoal:
                sb.append(f"  章节主目标：{ch.MainGoal}")
            if ch.ResistanceSource:
                sb.append(f"  阻力来源：{ch.ResistanceSource}")
            if ch.KeyTurn:
                sb.append(f"  关键转折：{ch.KeyTurn}")
            if ch.Hook:
                sb.append(f"  结尾钉子：{ch.Hook}")
            if ch.WorldInfoDrop:
                sb.append(f"  世界观投放：{ch.WorldInfoDrop}")
            if ch.CharacterArcProgress:
                sb.append(f"  角色弧光推进：{ch.CharacterArcProgress}")
            if ch.MainPlotProgress:
                sb.append(f"  主线推进点：{ch.MainPlotProgress}")
            sb.append("</item>")
            sb.append("")
        return "\n".join(sb)

    # ---- 单蓝图生成 ----
    async def generate_blueprint_async(
        self, chapter_id: str, category_name: str, scene_number: int,
        system_prompt: str
    ) -> BlueprintData:
        context = await self._build_context_async(category_name, chapter_id)
        user_prompt = json.dumps(
            {cn: f"【{cn}】的值" for cn in self.OUTPUT_FIELDS},
            ensure_ascii=False, indent=2,
        )
        if context:
            system_prompt = system_prompt + "\n\n" + context

        text = self._ai(system_prompt, user_prompt, category="蓝图设计")
        data = self._extract_json(text) or {}

        return self._data_from_json(data, chapter_id, category_name, scene_number)

    def _data_from_json(
        self, data: dict, chapter_id: str, category_name: str, scene_number: int
    ) -> BlueprintData:
        title = self._clean_blueprint_title(data.get("场景标题", ""))
        name = self._clean_blueprint_title(data.get("名称", ""))
        final_title = title or name or f"蓝图_{chapter_id}"

        # 实体引用校验
        cast = self._resolve_entities(data.get("出场角色", ""), chapter_id, category_name, "char")
        locs = self._resolve_entities(data.get("涉及地点", ""), chapter_id, category_name, "loc")
        facs = self._resolve_entities(data.get("涉及势力", ""), chapter_id, category_name, "fac")
        pov = self._resolve_single_entity(data.get("视点角色", ""), chapter_id, category_name)

        # Chapter fallback for empty entity fields
        ch = self._find_chapter_by_id(chapter_id)
        if ch:
            if not cast and ch.ReferencedCharacterNames:
                cast = [n for n in ch.ReferencedCharacterNames if n]
            if not locs and ch.ReferencedLocationNames:
                locs = [n for n in ch.ReferencedLocationNames if n]
            if not facs and ch.ReferencedFactionNames:
                facs = [n for n in ch.ReferencedFactionNames if n]
            if not pov and ch.ReferencedCharacterNames:
                pov = ch.ReferencedCharacterNames[0]

        cast_str = "、".join(cast) if cast else ""
        locs_str = "、".join(locs) if locs else ""
        facs_str = "、".join(facs) if facs else ""
        items_str = data.get("物品线索", "")
        if isinstance(items_str, list):
            items_str = "、".join(items_str)

        return BlueprintData(
            Id=short_id("B"),
            Name=name or final_title,
            Category=category_name,
            IsEnabled=True,
            CreatedAt=now_str(),
            UpdatedAt=now_str(),
            ChapterId=chapter_id,
            ChapterNumber=self._parse_chapter_number(chapter_id),
            SceneNumber=scene_number,
            SceneTitle=final_title,
            OneLineStructure=data.get("一句话结构", ""),
            PacingCurve=data.get("节奏曲线", ""),
            PovCharacter=pov,
            Opening=data.get("开场", ""),
            Development=data.get("发展", ""),
            Turning=data.get("转折", ""),
            Ending=data.get("结尾", ""),
            InfoDrop=data.get("信息释放", ""),
            Cast=cast_str,
            Locations=locs_str,
            Factions=facs_str,
            ItemsClues=items_str,
        )

    # ---- 批量生成 ----
    async def prepare_batch_async(
        self, category_name: str
    ) -> Optional[List[str]]:
        """对标 ShowBatchGenerationDialogAsync"""
        volume = self._find_volume_by_category(category_name)
        if not volume:
            return None

        vol_num = volume.VolumeNumber

        # 解析章节范围
        outlines = self._outline_service.get_all_outlines()
        volume_division = ""
        for o in outlines:
            if o.IsEnabled and o.VolumeDivision:
                volume_division = o.VolumeDivision
                break

        all_vols = self._volume_service.get_all_volume_designs()
        max_vn = max((v.VolumeNumber for v in all_vols if v.VolumeNumber > 0), default=1)
        total_chapters = 0
        for o in outlines:
            if o.IsEnabled and o.TotalChapterCount > 0:
                total_chapters = o.TotalChapterCount
                break
        if total_chapters <= 0:
            return None

        all_ranges: List[VolumeChapterRange] = []
        ok, parsed = ChapterAllocationHelper.try_parse_volume_division(
            volume_division, max_vn, total_chapters)
        if ok:
            all_ranges = parsed
        else:
            all_ranges = ChapterAllocationHelper.allocate(max_vn, total_chapters)

        current_range = None
        for r in all_ranges:
            if r.VolumeNumber == vol_num:
                current_range = r
                break
        if not current_range:
            return None

        full_ids = [
            f"vol{vol_num}_ch{n}"
            for n in range(current_range.StartChapter, current_range.EndChapter + 1)
        ]
        self._batch_full_chapter_ids = full_ids

        # 检查已有蓝图
        expected_id_set = set(full_ids)
        existing = set()
        for b in self._get_all_blueprints_for_category(category_name):
            if b.ChapterId and b.OneLineStructure and b.ChapterId in expected_id_set:
                existing.add(b.ChapterId)

        self._batch_pre_calculated_chapter_ids = [
            ch_id for ch_id in full_ids if ch_id not in existing
        ]
        self._batch_chapter_id_index = 0

        if not self._batch_pre_calculated_chapter_ids:
            self._batch_full_chapter_ids = []
            self._batch_pre_calculated_chapter_ids = []
            return None

        return self._batch_pre_calculated_chapter_ids

    def get_next_batch(self, batch_size: int = 10) -> Optional[List[str]]:
        if (self._batch_pre_calculated_chapter_ids
                and self._batch_chapter_id_index < len(self._batch_pre_calculated_chapter_ids)):
            remaining = self._batch_pre_calculated_chapter_ids[self._batch_chapter_id_index:]
            take = min(batch_size, len(remaining))
            self._current_batch_chapter_ids = remaining[:take]
            self._current_batch_chapter_ids_all = list(self._current_batch_chapter_ids)
            self._batch_chapter_id_index += take
            return self._current_batch_chapter_ids
        return None

    def rollback_batch(self):
        if self._current_batch_chapter_ids:
            self._batch_chapter_id_index = max(
                0, self._batch_chapter_id_index - len(self._current_batch_chapter_ids))

    async def finalize_batch_async(
        self, category_name: str, success: bool, cancelled: bool
    ):
        if not self._batch_full_chapter_ids:
            self._reset_batch()
            return

        if cancelled:
            self._cleanup_empty_shells(category_name)
        elif success:
            valid_set = set(self._batch_full_chapter_ids)
            for ch_id in self._batch_full_chapter_ids:
                existing = None
                for b in self._get_all_blueprints_for_category(category_name):
                    if b.ChapterId == ch_id:
                        existing = b
                        break
                if not existing:
                    data = BlueprintData(
                        Id=short_id("B"),
                        Name=f"蓝图_{ch_id}",
                        Category=category_name,
                        IsEnabled=True,
                        CreatedAt=now_str(),
                        UpdatedAt=now_str(),
                        ChapterId=ch_id,
                        SceneTitle=f"蓝图_{ch_id}",
                    )
                    self._persist_blueprint(data)

            # Tail cleanup: delete blueprints outside the valid range
            for b in self._get_all_blueprints_for_category(category_name):
                if b.ChapterId and b.ChapterId not in valid_set:
                    self._delete_blueprint(b.Id)

        self._reset_batch()

    def _cleanup_empty_shells(self, category_name: str):
        for b in self._get_all_blueprints_for_category(category_name):
            if (not self._clean_blueprint_title(b.SceneTitle)
                    and not b.OneLineStructure
                    and not b.PacingCurve
                    and not b.Opening):
                self._delete_blueprint(b.Id)

    def _reset_batch(self):
        self._batch_full_chapter_ids = []
        self._batch_pre_calculated_chapter_ids = []
        self._batch_chapter_id_index = 0
        self._current_batch_chapter_ids = []
        self._current_batch_chapter_ids_all = []

    # ---- 实体引用 ----
    def _resolve_entities(
        self, raw: str, chapter_id: str, category_name: str, entity_type: str
    ) -> List[str]:
        if not raw:
            return []
        global_list = self._get_global_list(entity_type)
        raw_resolved = self._filter_to_global(raw, global_list)

        # 域内过滤
        scoped_chars, scoped_locs, scoped_facs = self._get_scoped_entity_pools(
            chapter_id, category_name)
        scoped = {"char": scoped_chars, "loc": scoped_locs, "fac": scoped_facs}.get(entity_type, [])
        if scoped:
            raw_resolved = EntityNameNormalizeHelper.filter_to_candidates(raw_resolved, scoped)

        if not raw_resolved:
            return []
        return [n.strip() for n in re.split(r"[、，,]", raw_resolved) if n.strip()]

    def _resolve_single_entity(
        self, raw: str, chapter_id: str, category_name: str
    ) -> str:
        if not raw:
            return ""
        global_list = self._get_global_list("char")
        t = raw.strip()
        if t not in {n for n in global_list if n}:
            return ""
        scoped_chars, _, _ = self._get_scoped_entity_pools(chapter_id, category_name)
        if scoped_chars:
            return EntityNameNormalizeHelper.filter_to_candidate(t, scoped_chars)
        return t

    def _get_scoped_entity_pools(
        self, chapter_id: str, category_name: str
    ) -> Tuple[List[str], List[str], List[str]]:
        """先尝试从章节获取，再回退到分卷"""
        # 从章节获取
        ch = self._find_chapter_by_id(chapter_id)
        if ch and (ch.ReferencedCharacterNames or ch.ReferencedLocationNames or ch.ReferencedFactionNames):
            return (
                ch.ReferencedCharacterNames,
                ch.ReferencedLocationNames,
                ch.ReferencedFactionNames,
            )
        # 从分卷获取
        vol = self._find_volume_by_category(category_name)
        if vol:
            return (
                vol.ReferencedCharacterNames,
                vol.ReferencedLocationNames,
                vol.ReferencedFactionNames,
            )
        return [], [], []

    def _find_chapter_by_id(self, chapter_id: str) -> Optional[ChapterData]:
        m = _VOL_CH_ID_RE.match(chapter_id)
        if not m:
            return None
        vol_num = int(m.group(1))
        ch_num = int(m.group(2))
        for c in self._chapter_service.get_all_chapters():
            if c.ChapterNumber == ch_num:
                # Also verify volume number matches
                c_vol = self._extract_volume_number(c.Volume)
                if c_vol <= 0:
                    c_vol = self._extract_volume_number(c.Category)
                if c_vol <= 0 or c_vol == vol_num:
                    return c
        return None

    def _find_volume_by_category(self, category_name: str) -> Optional[VolumeDesignData]:
        for v in self._volume_service.get_all_volume_designs():
            expected = f"第{v.VolumeNumber}卷 {v.VolumeTitle}".strip() if v.VolumeNumber > 0 else v.Name
            if expected == category_name or v.Name == category_name:
                return v
        return None

    def _get_global_list(self, entity_type: str) -> List[str]:
        if entity_type == "char":
            return self._get_char_names()
        elif entity_type == "loc":
            return self._get_loc_names()
        elif entity_type == "fac":
            return self._get_fac_names()
        return []

    def _filter_to_global(self, raw: str, global_list: List[str]) -> str:
        if not raw:
            return ""
        global_set = {n for n in global_list if n}
        parts = re.split(r"[、，,;；\n\r]", raw)
        kept = []
        for p in parts:
            p = p.strip()
            if not p or EntityNameNormalizeHelper.is_ignored_value(p):
                continue
            if p in global_set:
                kept.append(p)
        return "、".join(kept)

    # ---- 章节ID匹配 ----
    def match_chapter_id(self, ai_value: str, category_name: str) -> str:
        if not ai_value:
            return ""
        trimmed = ai_value.strip()
        available = self._get_available_chapter_ids(category_name)

        # 1. Exact match
        for aid in available:
            if aid.lower() == trimmed.lower():
                return aid

        # 2. Parse vol+ch
        m = re.match(r"vol\s*(\d+).*ch\s*(\d+)", trimmed, re.IGNORECASE)
        if m:
            constructed = f"vol{m.group(1)}_ch{m.group(2)}"
            if constructed in available:
                return constructed

        # 3. Parse chapter number only
        m = re.match(r"(?:ch\s*)?(\d+)|第\s*(\d+)\s*章", trimmed, re.IGNORECASE)
        if m:
            ch_num = m.group(1) or m.group(2)
            vol_num = self._extract_volume_number(category_name)
            if vol_num > 0:
                constructed = f"vol{vol_num}_ch{ch_num}"
                if constructed in available:
                    return constructed
            # suffix match
            for aid in available:
                if aid.endswith(f"_ch{ch_num}"):
                    return aid

        # 4. Plain number
        if trimmed.isdigit():
            constructed = f"vol1_ch{trimmed}"
            if constructed in available:
                return constructed

        return trimmed

    def _get_available_chapter_ids(self, category_name: str) -> List[str]:
        chapters = [
            c for c in self._chapter_service.get_all_chapters()
            if c.IsEnabled and (c.Category == category_name or c.Volume == category_name)
        ]
        chapters.sort(key=lambda c: c.ChapterNumber)
        ids = []
        vol_num = 0
        if chapters:
            vol_num = self._extract_volume_number(chapters[0].Volume)
            if vol_num <= 0:
                vol_num = self._extract_volume_number(chapters[0].Category)
        for ch in chapters:
            ids.append(f"vol{vol_num}_ch{ch.ChapterNumber}")
        return ids

    def _get_all_blueprints_for_category(self, category_name: str):
        # 子类会覆写此方法使用实际存储
        return []

    def _persist_blueprint(self, data: BlueprintData):
        # 子类会覆写
        pass

    def _delete_blueprint(self, id_: str):
        # 子类会覆写
        pass

    @staticmethod
    def _extract_volume_number(volume: str) -> int:
        if not volume:
            return 0
        m = _VOL_CN_RE.search(volume)
        if m:
            return int(m.group(1))
        try:
            return int(volume)
        except ValueError:
            pass
        cleaned = volume.replace("vol", "").replace("_", "").strip()
        try:
            return int(cleaned)
        except ValueError:
            return 0

    @staticmethod
    def _parse_chapter_number(chapter_id: str) -> int:
        m = _VOL_CH_ID_RE.match(chapter_id)
        if m:
            return int(m.group(2))
        return 0

    @staticmethod
    def _clean_blueprint_title(title: str) -> str:
        if not title:
            return ""
        t = title.strip()
        t = _CLEAN_NUM_RANGE_RE.sub("", t)
        t = _CLEAN_VOL_CH_STR_RE.sub("", t)
        t = _CLEAN_CH_PREFIX_RE.sub("", t)
        t = _CLEAN_SCENE_BP_RE.sub("", t)
        t = _CLEAN_SCENE_NUM_RE.sub("", t)
        t = _CLEAN_VOL_CH_ARABIC_RE.sub("", t)
        t = _CLEAN_VOL_CH_CHINESE_RE.sub("", t)
        t = _CLEAN_SCENE_REF_RE.sub(" ", t)
        t = _CLEAN_VOL_REF_RE.sub(" ", t)
        t = _CLEAN_VOL_NUM_RE.sub(" ", t)
        t = _CLEAN_CH_NUM_RE.sub(" ", t)
        t = t.replace("__", " ").replace("--", " ")
        t = t.strip(" -_")
        return t.strip()

    @staticmethod
    def _normalize_chapter_title(title: str) -> str:
        if not title:
            return ""
        t = title.strip()
        t = _NORM_CH_VOL_ARABIC_RE.sub("", t)
        t = _NORM_CH_VOL_CHINESE_RE.sub("", t)
        t = _NORM_CH_ARABIC_RE.sub("", t)
        t = _NORM_CH_CHINESE_RE.sub("", t)
        return t.strip()

    @staticmethod
    def _split_lines(text: str) -> List[str]:
        if not text:
            return []
        return [t.strip() for t in re.split(r"[、，,\n]", text) if t.strip()]

    @staticmethod
    def _extract_json(text: str):
        if not text:
            return None
        t = text.strip()
        if t.startswith("```"):
            t = re.sub(r"^```(?:json)?\s*\n?", "", t)
            t = re.sub(r"\n?\s*```\s*$", "", t)
        if t.startswith("["):
            try:
                items = json.loads(t)
                if isinstance(items, list) and items:
                    return items[0]
            except json.JSONDecodeError:
                pass
        start = t.find("{")
        if start == -1:
            return None
        depth, in_str, esc = 0, 0, 0
        for i in range(start, len(t)):
            ch = t[i]
            if in_str:
                if esc:
                    esc = 0
                elif ch == "\\":
                    esc = 1
                elif ch == '"':
                    in_str = 0
                continue
            if ch == '"':
                in_str = 1
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(t[start:i + 1])
                    except json.JSONDecodeError:
                        pass
        try:
            return json.loads(t)
        except json.JSONDecodeError:
            return None