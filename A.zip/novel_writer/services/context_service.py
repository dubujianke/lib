# -*- coding: utf-8 -*-
"""上下文服务 — 对标 ContextService.cs

构建各层 AI 生成所需的结构化上下文（XML 格式）
"""
import json
import os
import re
from typing import List, Optional

from ..models.generate.strategic_outline.outline_data import OutlineData
from ..models.generate.volume_design.volume_design_data import VolumeDesignData
from ..models.generate.chapter_planning.chapter_data import ChapterData
from ..models.generate.chapter_blueprint.blueprint_data import BlueprintData
from .outline_service import OutlineService
from .volume_design_service import VolumeDesignService
from .chapter_service import ChapterService
from ..storage import _read_json


class ContextService:
    """对标 ContextService: 构建各层上下文"""

    def __init__(
        self,
        outline_service: OutlineService,
        volume_design_service: VolumeDesignService,
        chapter_service: ChapterService,
    ):
        self._outline_service = outline_service
        self._volume_design_service = volume_design_service
        self._chapter_service = chapter_service
        self.outline_sources = {}

    # ---- 大纲上下文 ----
    async def get_outline_structure_context_async(self, include=None) -> str:
        include = include or {"materials", "worldview", "characters", "factions", "plot_rules"}
        sb = ["<design_context for=\"outline\">"]
        project_dir = self._outline_service._project_dir
        from ..storage import Project
        project = Project(os.path.basename(project_dir.rstrip("/\\")), os.path.dirname(project_dir))

        def enabled_items(entity):
            source = self.outline_sources.get(entity, "project")
            if source == "none":
                return []
            source_project = project
            if source.startswith("book:"):
                from ..book_pipeline_v4 import OUTPUT_ROOT
                source_dir = os.path.join(OUTPUT_ROOT, "CrawledBooks", source.split(":", 1)[1])
                source_project = Project(os.path.basename(source_dir), os.path.dirname(source_dir))
            if source.startswith("book:"):
                filename = "materials.json" if entity == "materials" else f"refined_{ {'world': 'worldrules', 'characters': 'characters', 'factions': 'factions', 'locations': 'locations', 'plot': 'plotrules'}[entity] }.json"
                path = os.path.join(source_project.dir, filename)
                raw = _read_json(path, [])
            else:
                raw = source_project.load_design(entity)
            items = raw.get("items", []) if isinstance(raw, dict) else (raw or [])
            return [item for item in items if item.get("IsEnabled", True)]

        def value_text(value):
            if isinstance(value, list):
                return "、".join(str(v) for v in value if v not in (None, ""))
            if isinstance(value, dict):
                return "；".join(f"{k}：{v}" for k, v in value.items() if v not in (None, ""))
            return str(value) if value not in (None, "") else ""

        def append_materials():
            sb.append("<creative_materials_catalog>")
            material_fields = [
                ("分类", "Category"), ("题材类型", "Genre"), ("整体构思", "OverallIdea"),
                ("世界观素材-构建手法", "WorldBuildingMethod"), ("世界观素材-力量体系", "PowerSystemDesign"),
                ("世界观素材-环境描写", "EnvironmentDescription"), ("世界观素材-势力设计", "FactionDesign"),
                ("世界观素材-亮点", "WorldviewHighlights"), ("角色素材-主角塑造", "ProtagonistDesign"),
                ("角色素材-配角设计", "SupportingRoles"), ("角色素材-人物关系", "CharacterRelations"),
                ("角色素材-金手指", "GoldenFingerDesign"), ("角色素材-角色亮点", "CharacterHighlights"),
                ("剧情素材-情节结构", "PlotStructure"), ("剧情素材-冲突设计", "ConflictDesign"),
                ("剧情素材-高潮布局", "ClimaxArrangement"), ("剧情素材-伏笔设计", "ForeshadowingTechnique"),
                ("剧情素材-剧情亮点", "PlotHighlights"),
            ]
            for item in enabled_items("materials"):
                sb.append(f"<item name=\"{item.get('Name', '')}\">")
                for label, key in material_fields:
                    value = value_text(item.get(key, ""))
                    if value:
                        sb.append(f"{label}：{value}")
                content = value_text(item.get("Content", ""))
                if content:
                    sb.append(f"内容：{content}")
                sb.append("</item>")
                sb.append("")
            sb.append("</creative_materials_catalog>")

        def append_rules(tag, entity, fields):
            sb.append(f"<{tag}>")
            for item in enabled_items(entity):
                sb.append(f"<item name=\"{item.get('Name', '')}\">")
                for label, key in fields:
                    value = value_text(item.get(key, ""))
                    if value:
                        sb.append(f"{label}：{value}")
                sb.append("</item>")
                sb.append("")
            sb.append(f"</{tag}>")

        if "materials" in include:
            append_materials()
        if "worldview" in include:
            append_rules("worldview_rules", "world", [
            ("一句话总结", "OneLineSummary"), ("力量体系", "PowerSystem"), ("宇宙观", "Cosmology"),
            ("特殊法则", "SpecialLaws"), ("硬规则", "HardRules"), ("软规则", "SoftRules"),
            ("远古时代", "AncientEra"), ("关键事件", "KeyEvents"), ("现代历史", "ModernHistory"), ("现状", "StatusQuo")])
        if "characters" in include:
            append_rules("character_rules", "characters", [
            ("角色类型", "CharacterType"), ("身份", "Identity"), ("外在目标", "Want"), ("内在需求", "Need"),
            ("致命缺点", "FlawBelief"), ("成长路径", "GrowthPath"), ("关系", "Relationships")])
        if "factions" in include:
            append_rules("faction_rules", "factions", [
            ("类型", "FactionType"), ("理念目标", "Goal"), ("实力/地盘", "StrengthTerritory")])
        if "plot_rules" in include:
            append_rules("plot_rules", "plot", [
            ("全书总卷数", "TargetVolume"), ("所属卷", "AssignedVolume"), ("简介", "OneLineSummary"),
            ("事件类型", "EventType"), ("所属阶段", "StoryPhase"), ("目标", "Goal"), ("冲突", "Conflict"),
            ("主线推动", "MainPlotPush"), ("角色成长", "CharacterGrowth"), ("结果", "Result")])
        sb.append("</design_context>")
        return "\n".join(sb)

    async def get_volume_design_list_async(self) -> str:
        """对标 GetVolumeDesignListAsync: 返回已有分卷的 XML 列表"""
        vols = self._volume_design_service.get_all_volume_designs()
        if not vols:
            return ""
        sb = []
        for v in vols:
            sb.append(f"<item id=\"{v.Id}\">")
            sb.append(f"  第{v.VolumeNumber}卷：{v.VolumeTitle}")
            if v.StartChapter > 0 and v.EndChapter > 0:
                sb.append(f"  章节范围：第{v.StartChapter}章 ~ 第{v.EndChapter}章")
            sb.append(f"  主题：{v.VolumeTheme}")
            sb.append(f"  阶段目标：{v.StageGoal}")
            sb.append("</item>")
        return "\n".join(sb)

    # ---- 分卷设计上下文 ----
    async def get_volume_design_structure_context_async(self, volume_key: Optional[str] = None) -> str:
        """对标 GetVolumeDesignStructureContextAsync: 提供大纲上下文给分卷生成"""
        outlines = self._outline_service.get_all_outlines()
        sb = []
        for o in outlines:
            if not o.IsEnabled:
                continue
            sb.append("<outline_reference>")
            sb.append(f"  大纲名称: {o.Name}")
            sb.append(f"  核心冲突: {o.CoreConflict}")
            sb.append(f"  主题思想: {o.Theme}")
            sb.append(f"  卷/幕划分: {o.VolumeDivision}")
            sb.append(f"  大纲总览: {o.OutlineOverview}")
            sb.append("</outline_reference>")
        return "\n".join(sb)

    # ---- 章节上下文 ----
    async def get_chapter_context_with_volume_locator_async(self, category_name: str) -> str:
        """对标 GetChapterContextWithVolumeLocatorAsync: 提供完整设计与分卷上下文给章节生成"""
        sb = ["<design_context for=\"chapter_planning\">"]
        core = await self.get_outline_structure_context_async()
        if core:
            sb.append(core)

        project_dir = self._outline_service._project_dir
        from ..storage import Project
        project = Project(os.path.basename(project_dir.rstrip("/\\")), os.path.dirname(project_dir))
        raw_locations = project.load_design("locations")
        locations = raw_locations.get("items", []) if isinstance(raw_locations, dict) else (raw_locations or [])
        enabled_locations = [item for item in locations if item.get("IsEnabled", True)]
        if enabled_locations:
            sb.append("<location_rules>")
            for item in enabled_locations:
                sb.append(f"<item name=\"{item.get('Name', '')}\">")
                for label, key in [("类型", "LocationType"), ("描述", "Description"), ("地形", "Terrain"), ("危险", "Dangers")]:
                    value = item.get(key, "")
                    if isinstance(value, list):
                        value = "、".join(str(v) for v in value)
                    if value:
                        sb.append(f"{label}：{value}")
                sb.append("</item>")
            sb.append("</location_rules>")
        sb.append("</design_context>")

        outlines = self._outline_service.get_all_outlines()
        if outlines:
            sb.append("<outline_structure>")
            for outline in outlines:
                if not outline.IsEnabled:
                    continue
                sb.append(f"  名称: {outline.Name}")
                sb.append(f"  一句话大纲: {outline.OneLineOutline}")
                sb.append(f"  核心冲突: {outline.CoreConflict}")
                sb.append(f"  主题思想: {outline.Theme}")
                sb.append(f"  结局/目标状态: {outline.EndingState}")
                sb.append(f"  卷/幕划分: {outline.VolumeDivision}")
                sb.append(f"  大纲总览: {outline.OutlineOverview}")
            sb.append("</outline_structure>")

        vols = self._volume_design_service.get_all_volume_designs()
        if vols:
            sb.append("<volume_design_list>")
            for volume in vols:
                if not volume.IsEnabled:
                    continue
                sb.append(f"<item id=\"{volume.Id}\">")
                sb.append(f"  第{volume.VolumeNumber}卷：{volume.VolumeTitle}")
                sb.append(f"  章节范围：第{volume.StartChapter}章 ~ 第{volume.EndChapter}章")
                sb.append(f"  卷主题：{volume.VolumeTheme}")
                sb.append(f"  阶段目标：{volume.StageGoal}")
                sb.append(f"  主冲突：{volume.MainConflict}")
                sb.append(f"  压力来源：{volume.PressureSource}")
                sb.append(f"  关键转折：{volume.KeyEvents}")
                sb.append(f"  章节分配总览：{volume.ChapterAllocationOverview}")
                sb.append(f"  剧情分配：{volume.PlotAllocation}")
                sb.append(f"  章节生成提示：{volume.ChapterGenerationHints}")
                sb.append("</item>")
            sb.append("</volume_design_list>")

        for v in vols:
            cat_name = f"第{v.VolumeNumber}卷 {v.VolumeTitle}".strip() if v.VolumeNumber > 0 else v.Name
            if cat_name != category_name:
                continue
            sb.append("<volume_design_reference>")
            sb.append(f"  卷标题: {v.VolumeTitle}")
            sb.append(f"  卷主题: {v.VolumeTheme}")
            sb.append(f"  阶段目标: {v.StageGoal}")
            sb.append(f"  主冲突: {v.MainConflict}")
            sb.append(f"  章节范围: 第{v.StartChapter}章 ~ 第{v.EndChapter}章")
            sb.append(f"  章节生成提示: {v.ChapterGenerationHints}")
            sb.append("</volume_design_reference>")
            break
        return "\n".join(sb)

    # ---- 蓝图上下文 ----
    async def get_blueprint_context_with_chapter_locator_async(self, chapter_id: str) -> str:
        """对标 GetBlueprintContextWithChapterLocatorAsync: 提供章节设计上下文给蓝图生成"""
        if not chapter_id:
            return ""
        m = re.match(r"vol(\d+)_ch(\d+)", chapter_id, re.IGNORECASE)
        if not m:
            return ""
        ch_num = int(m.group(2))
        chapters = self._chapter_service.get_all_chapters()
        sb = []
        for ch in chapters:
            if ch.ChapterNumber != ch_num:
                continue
            sb.append("<chapter_design_reference>")
            sb.append(f"  第{ch.ChapterNumber}章: {ch.ChapterTitle}")
            sb.append(f"  章节目标: {ch.MainGoal}")
            sb.append(f"  关键转折: {ch.KeyTurn}")
            sb.append(f"  钩子: {ch.Hook}")
            sb.append(f"  角色弧推进: {ch.CharacterArcProgress}")
            sb.append(f"  主线推进: {ch.MainPlotProgress}")
            sb.append(f"  伏笔: {ch.Foreshadowing}")
            sb.append("</chapter_design_reference>")
            break
        return "\n".join(sb)