# -*- coding: utf-8 -*-
"""章节分配算法 — 对标 ChapterAllocationHelper.cs"""
import re
from dataclasses import dataclass
from typing import List, Optional, Tuple


@dataclass
class VolumeChapterRange:
    VolumeNumber: int = 0
    StartChapter: int = 0
    EndChapter: int = 0
    TargetChapterCount: int = 0


class ChapterAllocationHelper:
    """对标 ChapterAllocationHelper: 解析 VolumeDivision / 算法分配"""

    # 对标 C# 完整正则: 可选卷号 + 中文/阿拉伯 + 多种范围符号
    VOLUME_DIVISION_PATTERN = re.compile(
        r"(?:(?:第?\s*(?P<vol>\d+)\s*卷|(?P<vol2>\d+))\s*[：:]\s*)?第?\s*(?P<start>\d+)\s*(?:章)?\s*[-~～—–－至到]\s*第?\s*(?P<end>\d+)\s*(?:章)?"
    )

    # 对标 C# FiveActWeights
    FIVE_ACT_WEIGHTS = (2.0, 2.0, 3.0, 2.0, 1.0)

    @classmethod
    def try_parse_volume_division(
        cls, volume_division: Optional[str],
        total_volumes: int, total_chapters: int
    ) -> Tuple[bool, List[VolumeChapterRange]]:
        """对标 TryParseVolumeDivision（完整移植）:
        - 每行可含多个范围匹配；卷号缺省时按上一卷+1 隐式递增
        - 卷号必须 1..N 连续无重复；范围必须从1开始、首尾相接、总和等于总章数
        """
        if not volume_division or not total_volumes or not total_chapters:
            return False, []

        parsed = []  # (vol, start, end)
        implicit_vol = 1
        for raw_line in volume_division.split("\n"):
            line = raw_line.strip()
            if not line:
                continue
            matches = cls.VOLUME_DIVISION_PATTERN.findall(line) if hasattr(cls.VOLUME_DIVISION_PATTERN, "findall") else []
            for m in cls.VOLUME_DIVISION_PATTERN.finditer(line):
                vol_raw = m.group("vol") or m.group("vol2")
                vol = int(vol_raw) if vol_raw else implicit_vol
                s = int(m.group("start"))
                e = int(m.group("end"))
                if s > e or s <= 0:
                    continue
                parsed.append((vol, s, e))
                implicit_vol = vol + 1

        if not parsed:
            return False, []

        parsed.sort(key=lambda x: x[0])
        ranges = [VolumeChapterRange(VolumeNumber=v, StartChapter=s, EndChapter=e,
                                     TargetChapterCount=e - s + 1) for v, s, e in parsed]

        if len(ranges) != total_volumes:
            return False, ranges

        seen = set()
        for r in ranges:
            if r.VolumeNumber <= 0 or r.VolumeNumber > total_volumes:
                return False, ranges
            if r.VolumeNumber in seen:
                return False, ranges
            seen.add(r.VolumeNumber)
        for v in range(1, total_volumes + 1):
            if v not in seen:
                return False, ranges
        for i, r in enumerate(ranges):
            if r.VolumeNumber != i + 1:
                return False, ranges

        # 不变式: 第1卷起始=1、卷卷相接、末卷结束=总章数（对标 C# 失败时清空 ranges）
        if ranges[0].StartChapter != 1:
            return False, []
        for i in range(1, len(ranges)):
            if ranges[i].StartChapter != ranges[i - 1].EndChapter + 1:
                return False, []
        if ranges[-1].EndChapter != total_chapters:
            return False, []

        return True, ranges

    @classmethod
    def allocate(cls, total_volumes: int, total_chapters: int) -> List[VolumeChapterRange]:
        """对标 Allocate: 五幕式权重分配（2,2,3,2,1）+ 线性插值 + 最大余数法"""
        if total_volumes <= 0:
            raise ValueError("总卷数必须大于0")
        if total_chapters < total_volumes:
            raise ValueError("总章节数不能少于总卷数")

        weights = cls._build_weights(total_volumes)
        counts = cls._distribute_chapters(weights, total_chapters)

        ranges = []
        current_start = 1
        for i, count in enumerate(counts):
            end = current_start + count - 1
            ranges.append(VolumeChapterRange(
                VolumeNumber=i + 1, StartChapter=current_start,
                EndChapter=end, TargetChapterCount=count,
            ))
            current_start = end + 1

        cls._assert_invariants(ranges, total_chapters)
        return ranges

    @classmethod
    def _build_weights(cls, total_volumes: int) -> List[float]:
        n = len(cls.FIVE_ACT_WEIGHTS)
        if total_volumes == n:
            return list(cls.FIVE_ACT_WEIGHTS)
        if total_volumes < n:
            return [cls.FIVE_ACT_WEIGHTS[i] for i in range(total_volumes)]
        # 超过5卷: 线性插值
        weights = []
        for i in range(total_volumes):
            t = i / (total_volumes - 1) * (n - 1)
            lo = int(t)
            hi = min(lo + 1, n - 1)
            frac = t - lo
            weights.append(cls.FIVE_ACT_WEIGHTS[lo] * (1 - frac) + cls.FIVE_ACT_WEIGHTS[hi] * frac)
        return weights

    @staticmethod
    def _distribute_chapters(weights: List[float], total_chapters: int) -> List[int]:
        import math
        n = len(weights)
        weight_sum = sum(weights)
        exact = [w / weight_sum * total_chapters for w in weights]

        counts = []
        remainders = []
        allocated = 0
        for e in exact:
            c = max(1, math.floor(e))
            counts.append(c)
            allocated += c
            remainders.append(e - c)

        remaining = total_chapters - allocated
        if remaining > 0:
            # 余数大的优先 +1（余数并列时先高索引，对齐 C# Array.Sort 观测行为）
            indices = sorted(range(n), key=lambda i: (-remainders[i], -i))
            for k in range(min(remaining, n)):
                counts[indices[k]] += 1
        elif remaining < 0:
            # 余数小的优先 -1（保底1章）
            indices = sorted(range(n), key=lambda i: remainders[i])
            for k in range(min(-remaining, n)):
                if counts[indices[k]] > 1:
                    counts[indices[k]] -= 1
        return counts

    @staticmethod
    def _assert_invariants(ranges: List[VolumeChapterRange], total_chapters: int):
        if not ranges:
            return
        if ranges[0].StartChapter != 1:
            raise ValueError(f"不变式违反：第1卷StartChapter={ranges[0].StartChapter}，应为1")
        if ranges[-1].EndChapter != total_chapters:
            raise ValueError(f"不变式违反：末卷EndChapter={ranges[-1].EndChapter}，应为{total_chapters}")
        for i in range(1, len(ranges)):
            if ranges[i].StartChapter != ranges[i - 1].EndChapter + 1:
                raise ValueError(f"不变式违反：第{i + 1}卷StartChapter={ranges[i].StartChapter}，应为{ranges[i - 1].EndChapter + 1}")