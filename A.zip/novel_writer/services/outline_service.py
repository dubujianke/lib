# -*- coding: utf-8 -*-
"""大纲服务 — 对标 OutlineService.cs"""
import json
import os
from typing import List, Optional

from ..models.generate.strategic_outline.outline_data import OutlineData
from ..models.generate.strategic_outline.outline_category import OutlineCategory
from ..models.common import short_id
from ..storage import _atomic_write, _read_json


class OutlineService:
    """对标 OutlineService: ModuleServiceBase<OutlineCategory, OutlineData>

    模块路径: Generate/GlobalSettings/Outline
    """

    def __init__(self, project_dir: str):
        self._project_dir = project_dir
        self._module_dir = os.path.join(project_dir, "Generate", "GlobalSettings", "Outline")
        self._categories_path = os.path.join(self._module_dir, "categories.json")
        self._data_path = os.path.join(self._module_dir, "outline_data.json")
        self._categories: List[OutlineCategory] = []
        self._data: List[OutlineData] = []
        self._initialized = False

    # ---- 初始化 ----
    def ensure_initialized(self):
        if not self._initialized:
            self._load()

    def initialize(self):
        self._load()

    def _load(self):
        os.makedirs(self._module_dir, exist_ok=True)
        raw_cats = _read_json(self._categories_path, [])
        self._categories = [OutlineCategory.from_dict(c) for c in raw_cats] if raw_cats else []
        raw_data = _read_json(self._data_path, [])
        self._data = [OutlineData.from_dict(d) for d in raw_data] if raw_data else []
        self._initialized = True

    def _save_categories(self):
        _atomic_write(self._categories_path, [c.to_dict() for c in self._categories])

    def _save_data(self):
        _atomic_write(self._data_path, [d.to_dict() for d in self._data])

    # ---- 分类 CRUD ----
    def get_all_categories(self) -> List[OutlineCategory]:
        self.ensure_initialized()
        return list(self._categories)

    def add_category(self, category: OutlineCategory) -> bool:
        self.ensure_initialized()
        if any(c.Name == category.Name for c in self._categories):
            return False
        self._categories.append(category)
        self._save_categories()
        return True

    def update_category(self, category: OutlineCategory) -> bool:
        self.ensure_initialized()
        for i, c in enumerate(self._categories):
            if c.Id == category.Id:
                if c.IsBuiltIn:
                    return False
                self._categories[i] = category
                self._save_categories()
                return True
        return False

    def delete_category(self, name: str) -> bool:
        self.ensure_initialized()
        cat = next((c for c in self._categories if c.Name == name), None)
        if cat is None:
            return False
        if cat.IsBuiltIn:
            return False
        self._categories = [c for c in self._categories if c.Name != name]
        self._save_categories()
        # 级联删除该分类下的所有大纲数据
        self._data = [d for d in self._data if d.Category != name]
        self._save_data()
        return True

    # ---- 数据 CRUD ----
    def get_all_outlines(self) -> List[OutlineData]:
        self.ensure_initialized()
        return list(self._data)

    def add_outline(self, data: OutlineData):
        self.ensure_initialized()
        if not data.Id:
            data.Id = short_id("D")
        if not data.CategoryId:
            cat = next((c for c in self._categories if c.Name == data.Category), None)
            if cat:
                data.CategoryId = cat.Id
        self._data.append(data)
        self._save_data()

    async def add_outline_async(self, data: OutlineData):
        self.add_outline(data)

    def update_outline(self, data: OutlineData):
        self.ensure_initialized()
        for i, d in enumerate(self._data):
            if d.Id == data.Id:
                if not data.CategoryId:
                    cat = next((c for c in self._categories if c.Name == data.Category), None)
                    if cat:
                        data.CategoryId = cat.Id
                self._data[i] = data
                self._save_data()
                return

    async def update_outline_async(self, data: OutlineData):
        self.update_outline(data)

    def delete_outline(self, id_: str):
        self.ensure_initialized()
        self._data = [d for d in self._data if d.Id != id_]
        self._save_data()

    async def delete_outline_async(self, id_: str):
        self.delete_outline(id_)

    def clear_all_outlines(self) -> int:
        self.ensure_initialized()
        count = len(self._data)
        self._data.clear()
        self._save_data()
        return count

    # ---- 批量操作 ----
    def begin_batch_save(self):
        pass

    def end_batch_save(self):
        self._save_data()

    @staticmethod
    def has_content(data: OutlineData) -> bool:
        return bool(data.Name or data.OneLineOutline or data.Theme
                    or data.OutlineOverview or data.VolumeDivision)