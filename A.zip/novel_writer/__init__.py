# -*- coding: utf-8 -*-
"""novel_writer 包：天命 AI 网文创作引擎（Python 移植版）"""

from .ai_service import AIService
from .prompt_library import PromptLibrary
from .pipeline import NovelPipeline
from .storage import Project, create_project
from .gate import GenerationGate
from .writer import ChapterWriter
from .book_reader import BookReader
from .book_pipeline_v4 import ChaishuPipeline4

__version__ = "1.0.0"
