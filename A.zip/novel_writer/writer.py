# -*- coding: utf-8 -*-
"""章节生成闭环：写前读取 → AI 写作 → 门禁校验 → 正文落地 → 状态回写"""

import json
import os
import time
from typing import Dict, List, Optional

from .models import (
    ChapterChanges, FactSnapshot, ChapterData, BlueprintData, short_id, now_str,
)
from .prompt_library import PromptLibrary, build_system_prompt
from .prompt_builder import (
    build_chapter_task_prompt, format_fact_snapshot,
    split_content_and_changes,
)
from .ai_service import AIService
from .snapshot_extractor import SnapshotExtractor
from .gate import GenerationGate, GateResult
from .tracking_services import TrackingManager
from .storage import Project
from .gen_stats import get_word_count_tolerance


class ChapterWriter:
    """负责单章生成的完整闭环"""

    def __init__(self, project: Project, ai: AIService, library: PromptLibrary,
                 max_rewrite_attempts: int = 3):
        self.project = project
        self.ai = ai
        self.library = library
        self.gate = GenerationGate()
        self.snapshot_extractor = SnapshotExtractor(project)
        self.tracking = TrackingManager(project)
        self._volume_map = {}
        self.max_rewrite_attempts = max_rewrite_attempts
        self._build_volume_map()

    def _build_volume_map(self):
        """构建 章号→卷号 映射（对标 VolumeFileName 按卷归档）"""
        try:
            volumes = self.project.load_plan("volumes")
            if isinstance(volumes, dict):
                volumes = volumes.get("volumes", [])
            vol_map = {}
            for vol in volumes or []:
                if not isinstance(vol, dict):
                    continue
                vn = vol.get("VolumeNumber", 0)
                start = int(vol.get("StartChapter", 0) or 0)
                end = int(vol.get("EndChapter", 0) or 0)
                if vn and start and end:
                    for ch in range(start, end + 1):
                        vol_map[ch] = vn
            self._volume_map = vol_map
            self.tracking.set_volume_map(vol_map)
        except Exception:
            pass

    # ---- 写前读取 ----
    def build_context(self, chapter: ChapterData, blueprints: List[BlueprintData],
                      volume: dict, outline: dict, world: dict, characters: List[dict],
                      factions: List[dict], locations: List[dict], plot: dict,
                      materials: List[dict]) -> tuple:
        """返回 (snapshot, context_ids, prev_tail, summaries, milestones, recall_fragments,
                key_events, volume_archive, consistency_warnings, creative_template, creative_materials)"""
        snapshot = self.snapshot_extractor.extract(chapter.Id, chapter.ChapterNumber)
        context_ids = {
            "角色": chapter.ReferencedCharacterNames,
            "地点": chapter.ReferencedLocationNames,
            "势力": chapter.ReferencedFactionNames,
        }
        prev_id = self._find_previous_chapter(chapter)
        prev_tail = ""
        if prev_id:
            prev_tail = self.project.load_chapter(prev_id)
        summaries = self._get_summaries(chapter)
        milestones = ""

        # 对标 CreativeMaterialsViewModel: 从拆书素材提取 15 维注入
        creative_materials = self._get_creative_materials(materials)

        # 对标关键事件索引
        key_events = self._get_key_events(chapter)

        # 对标前卷存档
        volume_archive = self._get_volume_archive(volume)

        # 对标一致性警告
        consistency_warnings = self._get_consistency_warnings(chapter, snapshot)

        # 对标创作模板
        creative_template = self._get_creative_template(world)

        # 对标 PopulateLongDistanceRecallAsync: TF-IDF + 关键词召回
        recall = self._get_long_distance_recall(chapter, characters, snapshot)
        return (snapshot, context_ids, prev_tail, summaries, milestones, recall,
                key_events, volume_archive, consistency_warnings, creative_template, creative_materials)

    def _get_creative_materials(self, materials: List[dict]) -> str:
        """对标 CreativeMaterialsViewModel.ContextProvider: 将拆书素材 15 维注入写作上下文"""
        if not materials:
            return ""
        # 取最近一个素材（优先使用拆书来源的）
        material = materials[-1] if isinstance(materials, list) else materials
        if isinstance(material, dict):
            material = material
        elif hasattr(material, 'to_dict'):
            material = material.to_dict()
        else:
            return ""

        parts = ['<section name="creative_materials" source="book_analysis">']
        parts.append("以下创作素材来源于拆书分析，仅供借鉴写作技法，所有设定必须完全原创：")
        parts.append("")

        worldview_fields = [
            ("WorldBuildingMethod", "世界构建手法"), ("PowerSystemDesign", "力量体系设计"),
            ("EnvironmentDescription", "环境描写技巧"), ("FactionDesign", "势力设计技巧"),
            ("WorldviewHighlights", "世界观亮点"),
        ]
        has_wv = any(material.get(f) for f, _ in worldview_fields)
        if has_wv:
            parts.append('<section name="worldview_materials">')
            for f, label in worldview_fields:
                val = material.get(f, "")
                if val:
                    parts.append(f"【{label}】{val}")
            parts.append("</section>")
            parts.append("")

        char_fields = [
            ("ProtagonistDesign", "主角塑造手法"), ("SupportingRoles", "配角设计技巧"),
            ("CharacterRelations", "人物关系设计"), ("GoldenFingerDesign", "金手指设计"),
            ("CharacterHighlights", "角色塑造亮点"),
        ]
        has_ch = any(material.get(f) for f, _ in char_fields)
        if has_ch:
            parts.append('<section name="character_materials">')
            for f, label in char_fields:
                val = material.get(f, "")
                if val:
                    parts.append(f"【{label}】{val}")
            parts.append("</section>")
            parts.append("")

        plot_fields = [
            ("PlotStructure", "情节结构技巧"), ("ConflictDesign", "冲突设计手法"),
            ("ClimaxArrangement", "高潮布局技巧"), ("ForeshadowingTechnique", "伏笔技巧"),
            ("PlotHighlights", "剧情设计亮点"),
        ]
        has_pl = any(material.get(f) for f, _ in plot_fields)
        if has_pl:
            parts.append('<section name="plot_materials">')
            for f, label in plot_fields:
                val = material.get(f, "")
                if val:
                    parts.append(f"【{label}】{val}")
            parts.append("</section>")

        parts.append("</section>")
        return "\n".join(parts)

    def _get_key_events(self, chapter) -> str:
        """对标关键事件索引: 最近发生的关键剧情事件"""
        try:
            guide = self.project.guide("key_events").data()
            if not guide:
                return ""
            out = []
            for cid, evts in list(guide.items())[:10]:
                if isinstance(evts, list):
                    for e in evts[:3]:
                        if isinstance(e, dict) and e.get("Context"):
                            out.append(f"• {e.get('Context')}")
            return "\n".join(out)
        except Exception:
            return ""

    def _get_volume_archive(self, volume: dict) -> str:
        """对标前卷存档: 前卷事实档案"""
        try:
            if not volume:
                return ""
            vn = volume.get("VolumeNumber", 0)
            if vn <= 1:
                return ""
            from .volume_archive import VolumeArchiver
            archiver = VolumeArchiver(self.project)
            archive = archiver.load_archive(vn - 1)
            if isinstance(archive, dict):
                return json.dumps(archive, ensure_ascii=False)[:2000]
            return ""
        except Exception:
            return ""

    def _get_consistency_warnings(self, chapter, snapshot) -> str:
        """对标一致性警告: 逾期伏笔、未回收伏笔"""
        warnings = []
        if snapshot and snapshot.ForeshadowingStatus:
            for f in snapshot.ForeshadowingStatus:
                if f.IsOverdue and not f.IsResolved:
                    warnings.append(f"伏笔「{f.Name}」已逾期未回收")
                elif f.IsSetup and not f.IsResolved and f.IsOverdue:
                    warnings.append(f"伏笔「{f.Name}」已超预期回收章")
        return "\n".join(warnings) if warnings else ""

    def _get_creative_template(self, world: dict) -> str:
        """对标创作模板: 世界观核心设定"""
        try:
            if not world:
                return ""
            return world.get("OneLineSummary", "")[:200]
        except Exception:
            return ""

    def _get_long_distance_recall(self, chapter, characters, snapshot) -> str:
        ctx = {
            "ChapterTitle": chapter.ChapterTitle,
            "MainGoal": chapter.MainGoal,
            "ChapterTheme": chapter.ChapterTheme,
            "KeyTurn": chapter.KeyTurn,
            "Foreshadowing": chapter.Foreshadowing,
            "chapter_id": chapter.Id,
            "characters": [{"Name": c.get("Name", ""), "Id": c.get("Id", ""), "Identity": c.get("Identity", "")}
                           for c in (characters or [])[:5]],
            "foreshadowings": [
                {"IsSetup": f.IsSetup, "IsResolved": f.IsResolved, "Name": f.Name,
                 "ForeshadowId": f.ForeshadowId}
                for f in (snapshot.ForeshadowingStatus or [])
                if f.IsSetup and not f.IsResolved
            ][:5] if snapshot and snapshot.ForeshadowingStatus else [],
        }
        from .long_distance_recall import LongDistanceRecall
        rec = LongDistanceRecall(self.project)
        return rec.search_by_buckets(ctx, chapter_id=chapter.Id)

    def _find_previous_chapter(self, chapter: ChapterData) -> str:
        plans = self.project.load_plan("chapters")
        chapters = plans if isinstance(plans, list) else plans.get("chapters", [])
        target = chapter.ChapterNumber - 1
        for c in chapters:
            if c.get("ChapterNumber") == target:
                return c.get("Id", "")
        return ""

    def _get_summaries(self, chapter: ChapterData) -> str:
        """前 3 章递进式摘要"""
        guide = self.project.guide("chapter_summaries").data()
        plans = self.project.load_plan("chapters")
        chapters = plans if isinstance(plans, list) else plans.get("chapters", [])
        out = []
        for n in range(max(1, chapter.ChapterNumber - 3), chapter.ChapterNumber):
            for c in chapters:
                if c.get("ChapterNumber") == n:
                    summary = guide.get(c.get("Id", ""), "")
                    if summary:
                        out.append(f"第{n}章: {summary}")
        return "\n".join(out)

    # ---- 主流程 ----
    def write_chapter(self, chapter: ChapterData, blueprints: List[BlueprintData],
                      volume: dict, outline: dict, world: dict, characters: List[dict],
                      factions: List[dict], locations: List[dict], plot: dict,
                      materials: List[dict], genre: str, creative_spec: str = "",
                      word_count: int = 3500, verbose: bool = True) -> dict:
        (snapshot, context_ids, prev_tail, summaries, milestones, recall_fragments,
         key_events, volume_archive, consistency_warnings, creative_template, creative_materials) = self.build_context(
            chapter, blueprints, volume, outline, world, characters, factions, locations, plot, materials)

        # 组装系统提示词（含 CHANGES 协议）
        from .prompt_builder import changes_requirement_block
        system = build_system_prompt(genre, self.library, creative_spec)
        system += "\n\n" + changes_requirement_block(context_ids, snapshot)

        # 组装任务提示词
        user = build_chapter_task_prompt(
            chapter_number=chapter.ChapterNumber,
            chapter_title=chapter.ChapterTitle,
            chapter_plan=chapter.to_dict(),
            blueprints=[b.to_dict() for b in blueprints],
            snapshot=snapshot,
            context_ids=context_ids,
            creative_spec=creative_spec,
            previous_tail=prev_tail,
            summaries=summaries,
            volume_design=self._fmt(volume),
            outline=self._fmt(outline),
            characters=self._fmt_list(characters, max_items=30),
            factions=self._fmt_list(factions, max_items=20),
            locations=self._fmt_list(locations, max_items=30),
            plot_rules=self._fmt(plot),
            word_count=word_count,
            recall_fragments=recall_fragments,
            key_events=key_events,
            volume_archive=volume_archive,
            consistency_warnings=consistency_warnings,
            creative_template=creative_template,
        )
        if creative_materials:
            user += "\n\n" + creative_materials
        cleaned = self._strip_prompt_echo(cleaned)
        content = self._clean_content(cleaned, chapter)

        # 对标 ContentGenerationCallback: 实体漂移兜底补录（在 tracking 写入前，补录到 CHANGES）
        try:
            from .entity_drift import EntityDriftFallbackPatcher
            from .character_state_service import build_chapter_id
            vn = self._volume_map.get(chapter.ChapterNumber, 1)
            cid = build_chapter_id(vn, chapter.ChapterNumber)
            patcher = EntityDriftFallbackPatcher(self.project, self.tracking)
            drift_result = patcher.detect_and_apply(cid, content, changes)
            if drift_result.HasAnyDrift:
                for dirty in drift_result.DirtyGuideFiles:
                    store = self.tracking._stores.get(dirty)
                    if store:
                        store.flush()
        except Exception:
            pass

        # 落盘（原子写 + WAL）
        self.tracking.update(chapter.ChapterNumber, changes, snapshot)
        self.project.save_chapter(chapter.Id, content)
        # 可读文件名副本
        safe_title = chapter.ChapterTitle[:20].replace("/", "_").replace("\\", "_").replace(":", "_")
        self.project.save_chapter_text(f"ch{chapter.ChapterNumber:03d}_{safe_title}.md", content)
        # 摘要
        self._save_summary(chapter, changes)

        # 对标 UpdateForeshadowingOverdueStatusAsync: 刷新伏笔逾期状态
        self.tracking.refresh_overdue_status(chapter.ChapterNumber)

        # 对标 LedgerTrimService: 账本裁剪
        self.tracking.trim_ledger(chapter.ChapterNumber)

        # 对标 ContentGenerationCallback.RebuildVectorIndicesForChapterAsync: 章节生成后自动重建索引
        self._rebuild_vector_index()

        return {
            "chapter_id": chapter.Id,
            "chapter_number": chapter.ChapterNumber,
            "content": content,
            "changes": changes,
            "new_entities": self._last_new_entities,
        }

    def _generate_with_retry(self, system: str, user: str, snapshot: FactSnapshot,
                             context_ids: dict, chapter: ChapterData, word_count: int,
                             prev_tail: str = "", verbose: bool = True) -> tuple:
        # 对标 GenerateInBusinessSession: 创建会话保留历史
        session_key = f"ch{chapter.ChapterNumber}_{int(time.time())}"
        session = self.ai.create_session(session_key, system)
        design_names = {
            "角色": chapter.ReferencedCharacterNames,
            "视角角色": [chapter.ReferencedCharacterNames[0]] if chapter.ReferencedCharacterNames else [],
            "势力": chapter.ReferencedFactionNames,
            "地点": chapter.ReferencedLocationNames,
        }
        target_words = word_count
        if target_words < 100:
            target_words = 3000
        min_words, max_words_limit = get_word_count_tolerance(target_words)
        max_words = max_words_limit

        previous_failures = []
        original_content = ""    # 首次通过门禁的正文（CHANGES-only 保留用）
        changes_only = False
        word_count_issue = False
        repetition_issue = False
        last_raw = ""

        for attempt in range(self.max_rewrite_attempts):
            if verbose:
                print(f"    [AI 写作] 第 {attempt + 1}/{self.max_rewrite_attempts} 次尝试...")

            # 构建 prompt：首次用原文，后续用反馈
            prompt = user
            if attempt > 0 and previous_failures:
                fail_list = previous_failures[:5]  # 对标 MaxFailureReasonsPerRewrite=5
                fail_text = "\n".join(f"  - {f}" for f in fail_list)
                if changes_only:
                    prompt = user + (
                        f"\n\n（打回重写 #{attempt}）以下问题只需修正 CHANGES JSON，正文内容保留不变：\n"
                        f"{fail_text}\n请重新输出完整的正文+CHANGES。")
                elif word_count_issue:
                    prompt = user + (
                        f"\n\n（打回重写 #{attempt}）字数问题：需要 {target_words} 字。"
                        f"请重新生成正文，确保字数达标。")
                elif repetition_issue:
                    prompt = user + (
                        f"\n\n（打回重写 #{attempt}）检测到正文重复或与上章高度相似。"
                        f"请重新生成不同内容的正文。")
                else:
                    # 对标 BuildRewriteFeedback + AppendValidEntityHint: 注入合法实体列表
                    entity_hints = ""
                    if snapshot and previous_failures:
                        valid_chars = [f"{c.Name}({c.CharacterId})" for c in snapshot.CharacterStates[:10] if c.Name]
                        valid_locs = [f"{l.Name}({l.LocationId})" for l in snapshot.LocationStates[:5] if l.Name]
                        valid_facs = [f"{f.Name}({f.FactionId})" for f in snapshot.FactionStates[:5] if f.Name]
                        if valid_chars or valid_locs or valid_facs:
                            entity_hints = "\n\n⚠ 本章合法实体列表（优先使用括号内的ShortId，不确定写名称）：\n"
                            if valid_chars:
                                entity_hints += f"  角色：{'、'.join(valid_chars)}\n"
                            if valid_locs:
                                entity_hints += f"  地点：{'、'.join(valid_locs)}\n"
                            if valid_facs:
                                entity_hints += f"  势力：{'、'.join(valid_facs)}\n"
                    prompt = user + (
                        f"\n\n（打回重写 #{attempt}）门禁校验失败原因：\n{fail_text}\n"
                        "请修正后重新完整输出。") + entity_hints

            raw = self.ai.generate_in_session(session, prompt, category=f"chapter_{chapter.ChapterNumber}")
            last_raw = raw

            # 模型拒绝检测
            if self._detect_refusal(raw):
                previous_failures.append("模型拒绝生成（尝试切换题材参数重试）")
                continue

            # 前置 CHANGES 检测
            from .gate import GenerationGate
            if not self._has_changes(raw):
                changes_only = True
                original_content = raw
                previous_failures.append("缺少 CHANGES 区域")
                continue

            # 门禁校验
            result = self.gate.validate(raw, snapshot, design_names, context_ids, chapter.Id)
            if not result.Success:
                # 区分 failure 类型
                changes_issues = [f for f in result.Failures if f.Type in ("协议解析", "引用校验")]
                if changes_issues and len(changes_issues) == len(result.Failures):
                    changes_only = True
                    if original_content:
                        raw_merged = self._strip_changes(original_content) + "\n\n---CHANGES---\n" + self._extract_changes(raw)
                        result2 = self.gate.validate(raw_merged, snapshot, design_names, context_ids, chapter.Id)
                        if result2.Success:
                            result = result2
                            raw = raw_merged
                        else:
                            previous_failures = [e for f in result.Failures for e in f.Errors]
                            continue
                previous_failures = [e for f in result.Failures for e in f.Errors]
                if verbose:
                    for f in result.Failures:
                        print(f"    ⚠ 门禁打回 [{f.Type}]: {'; '.join(f.Errors[:2])}")
                continue

            # 门禁通过→正文重复检测（含上章尾部重叠）
            content, _, _fmt = split_content_and_changes(raw)
            if self._detect_repetition(content) or self._detect_repetition_with_tail(content, prev_tail):
                repetition_issue = True
                previous_failures.append("正文段落重复度过高或与上章尾部重叠")
                continue

            # 对标 Pre-Polish Word Count: 偏差>30%跳过润色
            wc = len(content.replace("\n", "").replace(" ", ""))
            pre_off = abs(wc - target_words) / max(1, target_words)
            if pre_off <= 0.30 and wc >= min_words:
                # 润色 + 重验
                from .polisher import ContentPolisher
                polisher = ContentPolisher(self.ai)
                polished_raw, polished_content, polish_ok = polisher.polish(raw, verbose)
                if polish_ok:
                    polished_result = self.gate.validate(polished_raw, snapshot, design_names, context_ids, chapter.Id)
                    if polished_result.Success:
                        raw = polished_raw
                        result = polished_result
                        content = polished_content
                        wc = len(polished_content.replace("\n", "").replace(" ", ""))
                        if verbose:
                            print(f"    [润色] 门禁通过，采用润色版")

            # 字数检测
            if wc < min_words:
                word_count_issue = True
                previous_failures.append(f"字数不足（{wc}/{target_words}）")
                if verbose:
                    print(f"    ⚠ 字数不足 {wc}/{target_words}")
                continue
            if wc > max_words * 2:
                word_count_issue = True
                previous_failures.append(f"字数严重超限（{wc}/{target_words}）")
                continue

            # 蓝图合规已在门禁 Post-gate 中检测

            self._last_new_entities = result.NewEntities
            self.ai.end_session(session_key)
            return raw, result.ParsedChanges

        self.ai.end_session(session_key)
        raise RuntimeError(f"第{chapter.ChapterNumber}章生成失败：{self.max_rewrite_attempts}次尝试均未通过")

    @staticmethod
    def _detect_refusal(text: str) -> bool:
        """对标 4.1.1 DetectModelRefusal: 32种模式"""
        patterns = [
            "I'm sorry, but I cannot", "I cannot provide", "I am unable to",
            "I apologize, but I", "As an AI", "I'm not able",
            "I'm not capable", "I cannot fulfill", "I can't assist",
            "I'm afraid I can't", "I can't generate", "I won't be able",
            "content policy", "safety guidelines", "I can't write",
            "i'm unable to", "i am unable to", "i cannot help", "i can't help",
            "i'm not able to", "i am not able to",
            "i must decline", "i need to decline", "i'm not comfortable",
            "sorry, i cannot", "sorry, i'm unable",
            "我无法协助", "我无法满足", "不能提供", "无法生成",
            "抱歉，我无法", "对不起，我无法", "这个要求超出了",
            "很抱歉，我不能", "我无法完成", "我不能提供",
            "作为AI助手", "内容政策", "安全准则",
            "由于内容限制", "我无法创建", "我无法为您",
            "我无法继续",
            "我不能协助", "我无法协助", "我需要拒绝", "我必须拒绝",
            "很抱歉，我无法", "很抱歉，我不能",
            "对不起，我无法", "对不起，我不能",
            "这种请求违反", "违反我的使用条款", "违反使用政策",
            "I'm unable to", "I am unable to", "I cannot help",
            "I must decline", "I need to decline", "I'm not comfortable",
        ]
        text_lower = text.lower()
        return any(p.lower() in text_lower for p in patterns)

    @staticmethod
    def _has_changes(text: str) -> bool:
        return "CHANGES---" in text or "chapter_changes>" in text

    @staticmethod
    def _detect_repetition(content: str) -> bool:
        """对标 DetectContentRepetition: bigram Jaccard"""
        lines = [l.strip() for l in content.split("\n") if l.strip()]
        if len(lines) < 4:
            return False
        paras = []
        current = []
        for l in lines:
            if len(l) < 10:
                current.append(l)
            else:
                if current:
                    paras.append("".join(current))
                    current = []
                paras.append(l)
        if len(paras) < 3:
            return False
        # 相邻段 bigram Jaccard
        for i in range(len(paras) - 1):
            if len(paras[i]) < 20 or len(paras[i + 1]) < 20:
                continue
            bg1 = set(paras[i][j:j + 2] for j in range(len(paras[i]) - 1))
            bg2 = set(paras[i + 1][j:j + 2] for j in range(len(paras[i + 1]) - 1))
            if not bg1 or not bg2:
                continue
            intersection = len(bg1 & bg2)
            union = len(bg1 | bg2)
            if union > 0 and intersection / union > 0.6:
                return True
        # 前/后半段相似度
        mid = len(content) // 2
        first, second = content[:mid], content[mid:]
        if len(first) > 100 and len(second) > 100:
            bg1 = set(first[j:j + 2] for j in range(len(first) - 1))
            bg2 = set(second[j:j + 2] for j in range(len(second) - 1))
            if bg1 and bg2:
                jac = len(bg1 & bg2) / max(1, len(bg1 | bg2))
                if jac > 0.5:
                    return True
        return False

    @staticmethod
    def _detect_repetition_with_tail(content: str, prev_tail: str = "") -> bool:
        """对标上章尾部重叠检测: 开头与上章尾部 bigram Jaccard > 0.4"""
        if not prev_tail or len(prev_tail) < 100 or len(content) < 100:
            return False
        tail = prev_tail[-300:] if len(prev_tail) > 300 else prev_tail
        head = content[:min(500, len(content))]
        bg_tail = set(tail[k:k + 2] for k in range(len(tail) - 1))
        bg_head = set(head[k:k + 2] for k in range(len(head) - 1))
        if not bg_tail or not bg_head:
            return False
        return len(bg_tail & bg_head) / max(1, len(bg_tail | bg_head)) > 0.4

    @staticmethod
    def _strip_changes(text: str) -> str:
        content, _, _fmt = split_content_and_changes(text)
        return content.strip()

    @staticmethod
    def _extract_changes(text: str) -> str:
        _, changes, _fmt = split_content_and_changes(text)
        return changes.strip()

    @staticmethod
    def _strip_leading_title(raw: str, chapter) -> str:
        """对标 StripLeadingTitle: 移除 AI 重复输出的标题行"""
        content, changes, _fmt = split_content_and_changes(raw)
        lines = content.split("\n")
        if len(lines) >= 2:
            expected = f"# 第{chapter.ChapterNumber}章"
            alt = f"# 第{chapter.ChapterNumber}章 {chapter.ChapterTitle}"
            if lines[0].strip() == alt or lines[0].strip() == expected:
                lines = lines[1:]
        if changes:
            return "\n".join(lines).strip() + "\n\n" + changes
        return "\n".join(lines).strip()

    @staticmethod
    def _strip_prompt_echo(text: str) -> str:
        """对标 StripPromptEchoKeepChanges: 移除 AI 回显的系统提示词片段"""
        markers = [
            "<output_requirements", "<changes_protocol", "<final_checklist",
            "<changes_template", "<changes_id_ref", "<entity_checklist",
            "<section name=", "<task_context>", "<chapter_task>",
        ]
        lines = text.split("\n")
        cleaned = []
        skip_block = False
        for line in lines:
            if any(m in line for m in markers):
                skip_block = True
                continue
            if skip_block and line.strip().startswith("</"):
                skip_block = False
                continue
            if not skip_block:
                cleaned.append(line)
        return "\n".join(cleaned)

    def _clean_content(self, raw: str, chapter: ChapterData) -> str:
        content, _, _fmt = split_content_and_changes(raw)
        content = content.strip()
        # 规范标题
        lines = content.split("\n")
        if lines and not lines[0].startswith("#"):
            content = f"# 第{chapter.ChapterNumber}章 {chapter.ChapterTitle}\n\n" + content
        return content

    def _save_summary(self, chapter: ChapterData, changes: ChapterChanges):
        """对标 BuildStructuredSummary: 基于 CHANGES 的结构化摘要"""
        parts = []
        # 正文开头 200 字
        content = self.project.load_chapter(chapter.Id)
        if isinstance(content, dict):
            content = content.get("content", "")
        if content:
            cleaned = content.replace("\r\n", " ").replace("\n", " ").strip()
            parts.append(cleaned[:200])

        for c in changes.CharacterStateChanges:
            if c.KeyEvent:
                parts.append(f"[角色] {c.CharacterId}: {c.KeyEvent}")
        for c in changes.ConflictProgress:
            if c.Event:
                parts.append(f"[冲突] {c.ConflictId}: {c.Event}→{c.NewStatus}")
        for p in changes.NewPlotPoints:
            if p.Context:
                parts.append(f"[情节] {p.Context}")
        for f in changes.ForeshadowingActions:
            if f.ForeshadowId:
                parts.append(f"[伏笔] {f.ForeshadowId}: {f.Action}")
        for l in changes.LocationStateChanges:
            if l.Event:
                parts.append(f"[地点] {l.LocationId}: {l.Event}→{l.NewStatus}")
        for fa in changes.FactionStateChanges:
            if fa.Event:
                parts.append(f"[势力] {fa.FactionId}: {fa.Event}→{fa.NewStatus}")
        if changes.TimeProgression and changes.TimeProgression.TimePeriod:
            parts.append(f"[时间] {changes.TimeProgression.TimePeriod} 经过{changes.TimeProgression.ElapsedTime}")
        for m in changes.CharacterMovements:
            if m.ToLocation:
                parts.append(f"[移动] {m.CharacterId}: {m.FromLocation}→{m.ToLocation}")
        for item in changes.ItemTransfers:
            if item.Event:
                parts.append(f"[物品] {item.ItemName}: {item.Event}")
        for sr in changes.SecretRevealChanges:
            if sr.KeyEvent:
                parts.append(f"[秘密] {sr.SecretId}: {sr.Method} {sr.KeyEvent}")
        for pc in changes.PledgeConstraintChanges:
            if pc.KeyEvent:
                parts.append(f"[承诺] {pc.PledgeId}: {pc.Action} {pc.KeyEvent}")
        for dc in changes.DeadlineConstraintChanges:
            if dc.KeyEvent:
                parts.append(f"[时限] {dc.DeadlineId}: {dc.Action} {dc.KeyEvent}")

        summary = "；".join(p for p in parts if p) or "本章无重大事件。"
        if len(summary) > 1500:
            summary = summary[:1500] + "..."
        guide = self.project.guide("chapter_summaries")
        guide.set(chapter.Id, summary)
        guide.flush()

    @staticmethod
    def _fmt(d: Optional[dict]) -> str:
        if not d:
            return ""
        return json.dumps(d, ensure_ascii=False)[:2000]

    def _rebuild_vector_index(self):
        """对标 ContentGenerationCallback.RebuildVectorIndicesForChapterAsync: 章节生成后重建向量索引"""
        try:
            from .long_distance_recall import LongDistanceRecall
            rec = LongDistanceRecall(self.project)
            rec.build_index()
        except Exception as e:
            print(f"    ⚠ 向量索引重建失败（非致命）: {e}")

    @staticmethod
    def _fmt_list(items: List[dict], max_items: int) -> str:
        if not items:
            return ""
        return json.dumps(items[:max_items], ensure_ascii=False)[:3000]
