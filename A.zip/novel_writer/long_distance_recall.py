# -*- coding: utf-8 -*-
"""
严格对标 4.1.1 PopulateLongDistanceRecallAsync:
- 块级 RRF (AddChunk + AddChapter)
- bestChunk 精确定位 + bestTfContent 双重跟踪
- PickBestContentAsync 三层回退
- 每路径分数归一化 Score / pathMax
- 排除当前/前章
"""
import os, re, math, json, heapq
import numpy as np
from collections import defaultdict
from typing import Dict, List, Optional, Tuple

from .vector_index import ChapterEmbeddingIndex, ChunkEmbeddingIndex

QUERY_PREFIX = "为这个句子生成表示以用于检索相关文章："


class BgeEmbedder:
    def __init__(self, model_path: str = None):
        if not model_path:
            base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            for sub in ["bge-small-zh-v1.5", ""]:
                mp = os.path.join(base, sub, "model.onnx")
                vp = os.path.join(base, sub, "vocab.txt")
                if os.path.exists(mp) and os.path.exists(vp):
                    model_path = mp; break
        model_dir = os.path.dirname(model_path) if model_path else ""
        vp = os.path.join(model_dir, "vocab.txt") if model_dir else ""
        self._available = os.path.exists(model_path) and os.path.exists(vp) if model_path else False
        if not self._available:
            self._tokenizer = None
            self._session = None
            self._dim = 512
            return
        # 对标 TryReadDimensionFromConfig: 从 config.json 读取 hidden_size
        self._dim = self._read_dimension(model_dir)
        import onnxruntime as ort
        self._session = ort.InferenceSession(model_path)
        # 使用 tokenizers 库的 BertWordPieceTokenizer
        from tokenizers import BertWordPieceTokenizer
        self._tokenizer = BertWordPieceTokenizer(vp, lowercase=False)
        self._tokenizer.enable_truncation(max_length=512)
        self._tokenizer.enable_padding(pad_id=0, pad_token="[PAD]", length=512)

    @staticmethod
    def _read_dimension(model_dir: str) -> int:
        """对标 BgeSmallZhEmbeddingService.TryReadDimensionFromConfig"""
        cfg = os.path.join(model_dir, "config.json")
        if os.path.exists(cfg):
            try:
                with open(cfg, encoding="utf-8") as f:
                    d = json.load(f)
                if "hidden_size" in d:
                    return int(d["hidden_size"])
            except Exception:
                pass
        return 512

    def tokenize(self, text: str, max_len: int = 512) -> dict:
        if self._tokenizer is None:
            return {"input_ids": np.zeros((1, max_len), dtype=np.int64),
                    "attention_mask": np.zeros((1, max_len), dtype=np.int64),
                    "token_type_ids": np.zeros((1, max_len), dtype=np.int64)}
        enc = self._tokenizer.encode(text)
        ids = enc.ids[:max_len]
        mask = [1] * len(ids)
        while len(ids) < max_len: ids.append(0); mask.append(0)
        return {"input_ids": np.array([ids], dtype=np.int64),
                "attention_mask": np.array([mask], dtype=np.int64),
                "token_type_ids": np.zeros((1, max_len), dtype=np.int64)}

    def encode(self, text: str, mode: str = "passage") -> Optional[np.ndarray]:
        if not self._available or not text or len(text.strip()) < 2: return None
        if mode == "query":
            text = QUERY_PREFIX + text
        inp = self.tokenize(text)
        out = self._session.run(None, {k: inp[k] for k in inp})[0][0]
        vec = out[0]
        norm = np.linalg.norm(vec)
        if norm > 1e-8: vec = vec / norm
        return vec

    def encode_batch(self, texts, mode: str = "passage"):
        if not texts:
            return []
        if mode == "query":
            texts = [QUERY_PREFIX + t for t in texts]
        inputs = [self.tokenize(t) for t in texts]
        batch = len(inputs)
        max_len = max((inp["input_ids"].shape[1] for inp in inputs), default=1)
        input_ids = np.zeros((batch, max_len), dtype=np.int64)
        attention_mask = np.zeros((batch, max_len), dtype=np.int64)
        token_type_ids = np.zeros((batch, max_len), dtype=np.int64)
        for i, inp in enumerate(inputs):
            ids = inp["input_ids"][0]
            mask = inp["attention_mask"][0]
            tt = inp["token_type_ids"][0]
            input_ids[i, :len(ids)] = ids
            attention_mask[i, :len(mask)] = mask
            token_type_ids[i, :len(tt)] = tt
        out = self._session.run(None, {"input_ids": input_ids, "attention_mask": attention_mask, "token_type_ids": token_type_ids})[0]
        results = []
        for i in range(batch):
            vec = out[i, 0]
            norm = np.linalg.norm(vec)
            if norm > 1e-8: vec = vec / norm
            results.append(vec)
        return results

    @property
    def available(self): return self._available


# ====== 对标 BuildVectorSearchQuery ======
def build_vector_search_query(ctx: dict) -> str:
    parts = []
    plan = ctx.get("chapter_plan", ctx)
    if plan:
        if plan.get("ChapterTitle", ""): parts.append(f"「{plan['ChapterTitle']}」")
        if plan.get("MainGoal", ""): parts.append(f"本章目标是{plan['MainGoal']}")
        elif plan.get("ChapterTheme", ""): parts.append(f"本章主题是{plan['ChapterTheme']}")
        if plan.get("KeyTurn", ""): parts.append(f"，关键转折为{plan['KeyTurn']}")
    chars = ctx.get("characters", [])
    if chars:
        names = [c.get("Name", "") for c in chars[:5] if c.get("Name")]
        if names: parts.append(f"{'，涉及' if parts else '涉及'}{'、'.join(names)}")
    fss = ctx.get("foreshadowings", [])
    unresolved = [f.get("Name", "") for f in fss if f.get("IsSetup") and not f.get("IsResolved") and f.get("Name")][:5]
    if unresolved: parts.append(f"{'，需要呼应伏笔' if parts else '需要呼应伏笔'}{'、'.join(unresolved)}")
    if plan and plan.get("Foreshadowing", ""):
        ft = plan["Foreshadowing"]; parts.append(f"，伏笔安排：{ft[:80]}")
    rules = ctx.get("plot_rules", [])
    if rules:
        rnames = [r.get("Name", "") for r in rules[:3] if r.get("Name")]
        if rnames: parts.append(f"{'，遵循' if parts else '遵循'}{'、'.join(rnames)}")
    q = "".join(parts); return q[:400] if len(q) > 400 else q


def collect_query_ids(ctx: dict) -> List[str]:
    ids = []
    for c in ctx.get("characters", [])[:5]:
        if c.get("Id"): ids.append(c["Id"])
    for f in ctx.get("foreshadowings", [])[:5]:
        if f.get("IsSetup") and not f.get("IsResolved") and f.get("ForeshadowId"):
            ids.append(f["ForeshadowId"])
    for p in ctx.get("plot_rules", [])[:3]:
        if p.get("Id"): ids.append(p["Id"])
    for l in ctx.get("locations", [])[:3]:
        if l.get("Id"): ids.append(l["Id"])
    for fac in ctx.get("factions", [])[:3]:
        if fac.get("Id"): ids.append(fac["Id"])
    return ids


class LongDistanceRecall:
    """严格对标 PopulateLongDistanceRecallAsync"""

    K = 60  # 对标 SemanticRrfK

    # 对标 ContentChunkSearchService.FallbackChapterCacheSize: 12 章 LRU
    CHUNK_CACHE_SIZE = 12
    # 对标 ChunkContent: targetSize / overlap
    CHUNK_TARGET_SIZE = 500
    CHUNK_OVERLAP = 50

    def __init__(self, project, embedder=None):
        self.project = project
        self.embedder = embedder or BgeEmbedder()
        self._chunks = []       # [{chapter_id, position, content}]
        self._keyword_index = defaultdict(set)
        self._dirty = True
        # 对标 FileBasedVectorIndex: int8量化 + Base64 JSON 持久化
        self._chapter_index = ChapterEmbeddingIndex(project.dir)
        self._chunk_index = ChunkEmbeddingIndex(project.dir)
        # 对标 ContentChunkSearchService LRU 缓存: 12 章块缓存
        self._chunk_cache = {}          # chapter_id → List[dict]
        self._chunk_cache_order = []    # LRU 顺序: 尾部 = 最近使用

    # ---- 持久化（对标 FileBasedVectorIndex.SaveAsync / LoadAsync） ----
    def _save_index(self):
        """对标 FileBasedVectorIndex.SaveAsync: int8量化 + Base64 JSON + .bak"""
        try:
            self._chapter_index.save()
            self._chunk_index.save()
        except Exception:
            pass

    def _load_index(self) -> bool:
        """对标 FileBasedVectorIndex.LoadAsync: 从持久化恢复向量索引"""
        try:
            self._chapter_index.load()
            self._chunk_index.load()
            return self._chapter_index.count > 0 or self._chunk_index.count > 0
        except Exception:
            return False

    # ---- LRU 块缓存（对标 ContentChunkSearchService 12章 LRU） ----

    def _touch_chunk_lru(self, chapter_id: str):
        """对标 TouchFallbackLru: 将章节移至 LRU 尾部（最近使用）"""
        if chapter_id in self._chunk_cache_order:
            self._chunk_cache_order.remove(chapter_id)
        self._chunk_cache_order.append(chapter_id)

    def _evict_chunk_lru(self):
        """对标 LRU eviction: 驱逐头部（最少使用）直到 <= CHUNK_CACHE_SIZE"""
        while len(self._chunk_cache_order) > self.CHUNK_CACHE_SIZE:
            evicted = self._chunk_cache_order.pop(0)
            self._chunk_cache.pop(evicted, None)

    def _chunk_text(self, chapter_id: str, text: str) -> List[dict]:
        """对标 ChunkContent: 将文本切分为带重叠的块"""
        paragraphs = [p.strip() for p in re.split(r"\n\n+", text) if p.strip()]
        if not paragraphs:
            paragraphs = [text[:self.CHUNK_TARGET_SIZE]]
        chunks = []
        pos, sb, sb_len = 0, [], 0
        for para in paragraphs:
            if sb_len > 0:
                sb.append('\n')
                sb_len += 1
            sb.append(para)
            sb_len += len(para)
            if sb_len >= self.CHUNK_TARGET_SIZE:
                chunk_text = "".join(sb)
                chunks.append({"chapter_id": chapter_id, "position": pos, "content": chunk_text})
                overlap_start = max(0, len(chunk_text) - self.CHUNK_OVERLAP)
                sb = [chunk_text[overlap_start:]]
                sb_len = len(sb[0])
                pos += 1
        if sb_len > 0:
            chunks.append({"chapter_id": chapter_id, "position": pos, "content": "".join(sb)})
        return chunks

    def get_or_load_chunks(self, chapter_id: str) -> List[dict]:
        """对标 GetOrLoadFallbackChunksAsync: LRU 缓存读取/加载"""
        if chapter_id in self._chunk_cache:
            self._touch_chunk_lru(chapter_id)
            return self._chunk_cache[chapter_id]

        text = self.project.load_chapter(chapter_id)
        if isinstance(text, dict):
            text = text.get("content", "")
        if not text or len(text) < 100:
            return []

        chunks = self._chunk_text(chapter_id, text)
        self._chunk_cache[chapter_id] = chunks
        self._touch_chunk_lru(chapter_id)
        self._evict_chunk_lru()
        return chunks

    def invalidate_chapter_cache(self, chapter_id: str):
        """对标 InvalidateChapterAsync: 清除单章 LRU 缓存"""
        self._chunk_cache.pop(chapter_id, None)
        if chapter_id in self._chunk_cache_order:
            self._chunk_cache_order.remove(chapter_id)

    def invalidate_chunk_cache(self):
        """对标 InvalidateCache: 清除全部 LRU 缓存"""
        self._chunk_cache.clear()
        self._chunk_cache_order.clear()

    # ---- 自动索引重建（对标 ContentGenerationCallback.Vector.cs） ----

    def rebuild_chapter_vectors(self, chapter_id: str, content: str = ""):
        """对标 RebuildVectorIndicesForChapterAsync:
        保存章节后自动重建向量索引（仅重建该章，不重建全库）
        """
        if not self.embedder.available:
            return
        if not content:
            content = self.project.load_chapter(chapter_id)
            if isinstance(content, dict):
                content = content.get("content", "")
        if not content or len(content) < 100:
            return

        # 1. 清除 LRU 缓存（对标 InvalidateChapterAsync）
        self.invalidate_chapter_cache(chapter_id)

        # 2. 编码章级向量 → upsert ChapterEmbeddingIndex
        vec = self.embedder.encode(content[:self.CHUNK_TARGET_SIZE])
        if vec is not None:
            norm = np.linalg.norm(vec)
            if norm > 1e-8:
                self._chapter_index.upsert(chapter_id, (vec / norm).tolist())

        # 3. 移除旧块索引，重新切分 + 编码
        self._chunk_index.remove_by_chapter(chapter_id)
        chunks = self._chunk_text(chapter_id, content)
        if chunks:
            # 也需要更新全局 _chunks（保持 keyword_index 一致）
            self._chunks = [c for c in self._chunks if c['chapter_id'] != chapter_id]
            self._chunks.extend(chunks)
            # 编码并写入 ChunkEmbeddingIndex
            chunk_texts = [c['content'] for c in chunks]
            vecs = self.embedder.encode_batch(chunk_texts)
            for chunk, v in zip(chunks, vecs):
                if v is not None:
                    norm = np.linalg.norm(v)
                    if norm > 1e-8:
                        v = v / norm
                    key = self._chunk_index._format_chunk_key(chapter_id, chunk['position'])
                    self._chunk_index.upsert(key, v.tolist())

        # 4. 持久化
        self._save_index()
        self._dirty = False

    def clean_chapter_vectors(self, chapter_id: str):
        """对标 CleanVectorIndicesAsync: 删除章节时清理向量索引 + 缓存"""
        self._chapter_index.remove(chapter_id)
        self._chunk_index.remove_by_chapter(chapter_id)
        self.invalidate_chapter_cache(chapter_id)
        self._chunks = [c for c in self._chunks if c['chapter_id'] != chapter_id]
        self._save_index()
        self._dirty = True

    def build_index(self):
        """对标 ChapterEmbeddingIndex.LoadAsync + ChunkEmbeddingIndex.LoadAsync"""
        # 先尝试从持久化加载向量（避免每次重启重建）
        if not self._chunks and self._load_index():
            self._dirty = False
            return
        chs = self._load_chapters()
        if not chs: return
        self._chunks.clear(); self._keyword_index.clear()
        self._chapter_index.invalidate_cache()
        self._chunk_index.invalidate_cache()
        self.invalidate_chunk_cache()  # 对标 InvalidateCache: 清空 LRU
        embed_texts = []

        for ch in chs:
            cid = ch.get("Id", "")
            if not cid: continue
            text = self.project.load_chapter(cid)
            if isinstance(text, dict): text = text.get("content", "")
            if not text or len(text) < 100: continue

            # 对标 ChunkContent: 使用公共方法并存入 LRU
            chunk_entries = self._chunk_text(cid, text)
            self._chunks.extend(chunk_entries)
            self._chunk_cache[cid] = chunk_entries  # 填入 LRU
            embed_texts.extend(c['content'] for c in chunk_entries)

            if self.embedder.available:
                vec = self.embedder.encode(text)
                if vec is not None:
                    norm = np.linalg.norm(vec)
                    if norm > 1e-8: vec = vec / norm
                    self._chapter_index.upsert(cid, vec.tolist())

        # 填充 LRU 顺序（按章节 ID）
        self._chunk_cache_order = list(self._chunk_cache.keys())
        self._evict_chunk_lru()  # 超过 12 驱逐

        # 对标 ExtractKeywords: 从设计数据提取实体名作为索引词
        entity_keywords = _extract_entity_keywords(self.project)
        for chunk in self._chunks:
            for kw in entity_keywords:
                if kw in chunk['content']:
                    self._keyword_index[kw].add(chunk['chapter_id'])

        if self.embedder.available and embed_texts:
            vecs = self.embedder.encode_batch(embed_texts)
            for i, (chunk, vec) in enumerate(zip(self._chunks, vecs)):
                if vec is not None:
                    norm = np.linalg.norm(vec)
                    if norm > 1e-8: vec = vec / norm
                    chunk_key = f"{chunk['chapter_id']}|{chunk['position']}"
                    self._chunk_index.upsert(chunk_key, vec.tolist())
        self._dirty = False
        self._save_index()

    def search_by_buckets(self, ctx: dict, chapter_id: str = "", prev_chapter_id: str = "",
                          top_k: int = 5) -> str:
        """对标 PopulateLongDistanceRecallAsync 完整流程"""
        if self._dirty: self.build_index()

        query_text = build_vector_search_query(ctx)
        if not query_text: return ""

        # 对标: nameTerms + idTerms 合并 → 关键词索引查询
        name_terms = [t for t in re.split(r"\s+", query_text) if len(t) >= 2]
        id_terms = collect_query_ids(ctx)
        query_keywords = list(set(name_terms + id_terms))

        # 对标: 4路并行检索
        tf_hits = self._chunk_search(query_text, top_k=10)        # TF chunk hits
        kw_hits = self._keyword_search(query_keywords, top_k=10)  # KW chapter IDs

        # 对标 BuildBucketQueries + 3桶向量（对标 EncodeBatchAsync 一次编码）
        fs_text = "。".join(f.get("Name", "") for f in ctx.get("foreshadowings", [])
                            if f.get("IsSetup") and not f.get("IsResolved"))
        char_text = "。".join(
            f"{c.get('Name','')}：{c.get('Identity','')}" if c.get("Identity") else c.get("Name", "")
            for c in ctx.get("characters", [])[:5])
        gen_text = "。".join(p for p in [
            ctx.get("MainGoal", ""), ctx.get("KeyTurn", ""),
            ctx.get("Summary", ""), ctx.get("ChapterTitle", "")
        ] if p)

        # 对标 EncodeBatchAsync: 批量编码 3 个桶查询
        vec_f, vec_c, vec_g = [], [], []
        query_texts = [fs_text, char_text, gen_text]
        valid_queries = [(i, t) for i, t in enumerate(query_texts) if t.strip()]
        if valid_queries:
            batch_vecs = self.embedder.encode_batch([t for _, t in valid_queries], mode="query")
            for (idx, _), vec in zip(valid_queries, batch_vecs):
                if vec is not None:
                    norm = np.linalg.norm(vec)
                    if norm > 1e-8:
                        vec = vec / norm
                    if idx == 0 and fs_text.strip():
                        vec_f = self._vector_chunks_from_vec(vec, 5)
                    elif idx == 1 and char_text.strip():
                        vec_c = self._vector_chunks_from_vec(vec, 3)
                    elif idx == 2 and gen_text.strip():
                        vec_g = self._vector_chunks_from_vec(vec, 5)

        from_cid = ctx.get("chapter_id", chapter_id)
        prev_cid = ctx.get("previous_chapter_id", prev_chapter_id)

        # ====== RRF 融合 (对标 AddChunk + AddChapter) ======
        rrf = defaultdict(float)
        best_chunk_hit = {}   # chapter_id → ChunkHit (highest scoring chunk per chapter)
        best_tf_content = {}  # chapter_id → string (TF content)
        cats = {}             # chapter_id → category

        def safe_max(hits, sel=lambda h: h['score'], default=1.0):
            m = max((sel(h) for h in hits), default=0)
            return m if m > 0 else default

        # TF-IDF 路径: AddChunk(chId, pos, score/tfMax, rank, General, tfContent)
        tf_max = safe_max(tf_hits)
        for rank, h in enumerate(tf_hits):
            cid = h['chapter_id']; pos = h['position']
            if cid == from_cid or cid == prev_cid: continue
            rrf[cid] += _rrf_score(rank)
            norm_score = h['score'] / tf_max
            _update_best_chunk(best_chunk_hit, cid, pos, norm_score)
            cats.setdefault(cid, RecallCats.GENERAL)
            if 'content' in h and cid not in best_tf_content:
                best_tf_content[cid] = h['content']

        # 关键词路径: AddChapter(chId, rank, General)
        for rank, cid in enumerate(kw_hits):
            if cid == from_cid or cid == prev_cid: continue
            rrf[cid] += _rrf_score(rank)
            if cid not in cats: cats[cid] = RecallCats.GENERAL

        # 向量3路径: AddChunk(chId, pos, score/pathMax, rank, category)
        for hits, cat in [(vec_f, RecallCats.FORESHADOWING), (vec_c, RecallCats.CHARACTER),
                            (vec_g, RecallCats.GENERAL)]:
            path_max = safe_max(hits)
            for rank, h in enumerate(hits):
                cid = h['chapter_id']; pos = h.get('position', 0)
                if cid == from_cid or cid == prev_cid: continue
                rrf[cid] += _rrf_score(rank)
                norm_score = h['score'] / path_max
                _update_best_chunk(best_chunk_hit, cid, pos, norm_score, cat)

        # 对标 PickByCategoryQuota: F:2 C:1 G:2
        sorted_ids = sorted(rrf.keys(), key=lambda cid: -rrf[cid])
        quota = []; fc = cc = gc = 0
        for cid in sorted_ids:
            cat = cats.get(cid, RecallCats.GENERAL)
            if cat == RecallCats.FORESHADOWING and fc < 2: fc += 1; quota.append(cid)
            elif cat == RecallCats.CHARACTER and cc < 1: cc += 1; quota.append(cid)
            elif gc < 2: gc += 1; quota.append(cid)
            if fc >= 2 and cc >= 1 and gc >= 2: break

        if not quota: return ""

        # 对标 PickBestContentAsync: ①bestTfContent → ②chunk位置 → ③fallback
        lines = []
        for cid in quota[:top_k]:
            content = ""
            if cid in best_tf_content:
                content = best_tf_content[cid]
            elif cid in best_chunk_hit:
                pos = best_chunk_hit[cid].position
                content = self._pick_by_position(cid, pos)
            if not content:
                content = self._pick_first(cid)
            if not content: continue
            cat = cats.get(cid, RecallCats.GENERAL)
            lines.append(f"[{cat}] Ch{cid[:8]} score={rrf[cid]:.4f}:")
            lines.append(f"  {content[:350]}")
        return "\n".join(lines)

    # ---- 检索方法 ----
    def _chunk_search(self, query: str, top_k: int) -> List[dict]:
        """对标 ContentChunkSearchService.SearchAsync: BM25 + 堆 TopK"""
        q_terms = [t for t in _tokenize(query) if len(t) >= 2]
        if not q_terms: return []

        # BM25 参数 (对标 k1=1.5, b=0.75)
        K1, B = 1.5, 0.75
        total_len = sum(len(c['content']) for c in self._chunks)
        n_chunks = max(1, len(self._chunks))
        avg_len = max(100, total_len / n_chunks)

        heap = []
        for chunk in self._chunks:
            doc_len = len(chunk['content'])
            len_norm = 1.0 - B + B * doc_len / avg_len
            score = 0.0
            for t in q_terms:
                tf = chunk['content'].count(t)
                if tf > 0:
                    score += (tf * (K1 + 1)) / (tf + K1 * len_norm)
            if score > 0:
                item = (score, chunk['chapter_id'], chunk['position'], chunk['content'][:500])
                if len(heap) < top_k:
                    heapq.heappush(heap, item)
                elif score > heap[0][0]:
                    heapq.heapreplace(heap, item)
        return [{"chapter_id": cid, "position": pos, "score": sc, "content": ct}
                for sc, cid, pos, ct in sorted(heap, key=lambda x: -x[0])]

    def _keyword_search(self, query_keywords: List[str], top_k: int) -> List[str]:
        """对标 KeywordChapterIndexService.SearchAsync"""
        if not query_keywords: return []
        scores = defaultdict(int)
        for kw in query_keywords:
            for cid in self._keyword_index.get(kw, set()):
                scores[cid] += 1
        return [k for k, _ in sorted(scores.items(), key=lambda x: -x[1])][:top_k]

    def _vector_chunks(self, query: str, top_k: int) -> List[dict]:
        """对标 HybridSearchWithVecAsync: 粗排(章级)→精排(块级)"""
        q_vec = self._encode_query_vector(query)
        if q_vec is None:
            return []
        return self._vector_chunks_from_vec(q_vec, top_k)

    def _encode_query_vector(self, query: str) -> Optional[np.ndarray]:
        """编码查询文本为归一化向量"""
        if not self.embedder.available:
            return None
        vec = self.embedder.encode(query, mode="query")
        if vec is None:
            return None
        norm = np.linalg.norm(vec)
        if norm < 1e-8:
            return None
        return vec / norm

    def _vector_chunks_from_vec(self, q_vec: np.ndarray, top_k: int) -> List[dict]:
        """对标 HybridSearchWithVecAsync: 粗排(章级)→精排(块级)，接收预编码向量"""
        if not self.embedder.available or self._chapter_index.count == 0:
            return []
        q_list = q_vec.tolist()
        coarse_n = min(max(top_k * 3, 10), 30)

        # 粗排: 章级 dot product
        coarse_hits = self._chapter_index.search(q_list, coarse_n)
        candidates = {h.key for h in coarse_hits}

        # 精排: 块级 dot product（限制在候选章节内）
        fine_hits = self._chunk_index.search_within_chapters(q_list, list(candidates), top_k)
        chunk_hits = []
        for hit in fine_hits:
            cid, pos = self._chunk_index._parse_chunk_key(hit.key)
            if pos < 0:
                continue
            chunk_hits.append({"chapter_id": cid, "position": pos, "score": hit.score})
        return chunk_hits

    # ---- 内容检索 (对标 PickBestContentAsync) ----
    def _pick_by_position(self, chapter_id: str, position: int) -> str:
        for c in self._chunks:
            if c['chapter_id'] == chapter_id and c['position'] == position:
                return c['content'][:500]
        return ""

    def _pick_first(self, chapter_id: str) -> str:
        for c in self._chunks:
            if c['chapter_id'] == chapter_id:
                return c['content'][:300]
        return ""

    def _load_chapters(self) -> list:
        plans = self.project.load_plan("chapters")
        if isinstance(plans, list): return plans
        if isinstance(plans, dict): return plans.get("chapters", [])
        return []


# ====== 对标 RecallCategory ======
class RecallCats:
    GENERAL = "General"
    CHARACTER = "Character"
    FORESHADOWING = "Foreshadowing"


def _rrf_score(rank: int) -> float:
    return 1.0 / (LongDistanceRecall.K + rank)


def _update_best_chunk(best: dict, cid: str, pos: int, score: float, cat: str = None):
    """对标 AddChunk: 跟踪每章最高分块"""
    if cid not in best or score > best[cid].score:
        best[cid] = ChunkHit(cid, pos, score)


class ChunkHit:
    def __init__(self, chapter_id: str, position: int, score: float):
        self.chapter_id = chapter_id
        self.position = position
        self.score = score


def _tokenize(text: str) -> List[str]:
    text = re.sub(r"[^\u4e00-\u9fff]", "", text)
    tokens = []
    for w in [2, 3]:
        for i in range(len(text) - w + 1):
            tokens.append(text[i:i + w])
    return tokens


def _extract_entity_keywords(project) -> List[str]:
    """对标 KeywordChapterIndexService.ExtractKeywords: 从设计数据提取实体名"""
    kws = set()
    for entity in ["characters", "factions", "locations", "world", "plot"]:
        data = project.load_design(entity)
        items = data.get("items", []) if isinstance(data, dict) else (data or [])
        if isinstance(items, dict): items = [items]
        for item in items:
            if not isinstance(item, dict): continue
            for key in ("Name", "Id", "CharacterType", "FactionType", "LocationType",
                        "SpecialAbilities", "CombatSkills", "SignatureItems",
                        "Goal", "Conflict", "CoreMembers", "Leader",
                        "Landmarks", "OneLineSummary"):
                val = item.get(key, "")
                if isinstance(val, str) and len(val) >= 2:
                    kws.add(val.strip())
                    for seg in re.findall(r"[\u4e00-\u9fff]{2,6}", val):
                        if len(seg) >= 2: kws.add(seg)
            for list_key in ("HardRules", "KeyEvents", "CombatSkills", "SpecialAbilities",
                             "SignatureItems", "Allies", "Enemies"):
                for v in (item.get(list_key, []) or []):
                    if isinstance(v, str) and len(v) >= 2: kws.add(v.strip())
    return [k for k in kws if k and len(k) >= 2][:200]
