# -*- coding: utf-8 -*-
"""
对标 DegradeContext: 6级上下文降级 + Token估算
"""
from typing import Dict


def count_tokens(text: str) -> int:
    """简单 token 估算: 中文字符≈1 token, 英文≈0.3 token per char"""
    if not text:
        return 0
    chars = len(text)
    # 粗略: 纯中文→1:1, 混合→0.8:1
    chinese = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
    other = chars - chinese
    return chinese + int(other * 0.3)


def estimate_context_tokens(system_prompt: str, user_prompt: str, context_window: int = 256000) -> int:
    """对标 TokenEstimator: 返回预估总 token 数"""
    return count_tokens(system_prompt) + count_tokens(user_prompt)


def _estimate_tokens(text: str) -> int:
    return count_tokens(text)


def degrade_context(ctx: dict, system_prompt: str, user_prompt: str,
                    context_window: int = 256000) -> dict:
    """对标 DegradeContext: 6级降级"""
    ctx = dict(ctx)
    safe_limit = int(context_window * 0.9)
    current = lambda: _estimate_tokens(system_prompt) + _estimate_tokens(user_prompt)

    # Tier 1: 长距召回
    if ctx.get("recall_fragments"):
        removed = _estimate_tokens(ctx["recall_fragments"])
        ctx["recall_fragments"] = ""
        if current() <= safe_limit: return ctx

    # Tier 2: 里程碑→后3条
    milestones = ctx.get("milestones", "")
    if milestones and isinstance(milestones, str) and len(milestones) > 200:
        parts = milestones.split("\n")
        ctx["milestones"] = "\n".join(parts[-3:]) if len(parts) > 3 else milestones[:500]
        if current() <= safe_limit: return ctx

    # Tier 3: 摘要→后5章
    summaries = ctx.get("summaries", "")
    if summaries and isinstance(summaries, str) and len(summaries) > 500:
        lines = summaries.split("\n")
        ctx["summaries"] = "\n".join(lines[-5:]) if len(lines) > 5 else summaries[-500:]
        if current() <= safe_limit: return ctx

    # Tier 4: 裁剪实体
    for key, limit in [("characters", ""), ("factions", ""), ("locations", ""),
                        ("world_rules", ""), ("plot_rules", "")]:
        val = ctx.get(key, "")
        if isinstance(val, str) and len(val) > 1000:
            ctx[key] = val[:1000]
    if current() <= safe_limit: return ctx

    # Tier 5: 清除历史/召回
    ctx["milestones"] = ""
    ctx["recall_fragments"] = ""
    ctx["summaries"] = "\n".join(ctx.get("summaries", "").split("\n")[-3:])
    if current() <= safe_limit: return ctx

    # Tier 6: 最小
    ctx["milestones"] = ""
    ctx["summaries"] = ""
    ctx["recall_fragments"] = ""
    ctx["characters"] = ctx.get("characters", "")[:500]
    ctx["factions"] = ctx.get("factions", "")[:200]
    ctx["locations"] = ctx.get("locations", "")[:200]
    return ctx
