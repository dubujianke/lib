import json


def normalize_book_info(primary, fallback):
    return primary or fallback or {}


def build_tagged_chapter(number, title, label, content):
    chapter_title = title or f"第{number}章"
    label_text = f" [{label}]" if label else ""
    return f"### 第{number}章 {chapter_title}{label_text}\n\n{content}"


def required_analysis_files(output_dir):
    return [
        name for name in (
            "essence_chapters.json", "analysis.json", "refined_worldrules.json",
            "refined_characters.json", "refined_factions.json", "refined_locations.json",
            "refined_plotrules.json",
        ) if not (output_dir / name).exists()
    ]


def build_dependency_context(output_dir, dependencies):
    parts = []
    for module, label in dependencies:
        path = output_dir / f"refined_{module}.json"
        if path.exists():
            parts.append(f"【{label}已提炼实体】\n" + json.dumps(json.loads(path.read_text(encoding="utf-8")), ensure_ascii=False))
    return "\n\n".join(parts)
