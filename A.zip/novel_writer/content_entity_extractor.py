# -*- coding: utf-8 -*-
"""兼容 shim：转发到 .implementations.validation.content_entity_extractor"""
from .implementations.validation.content_entity_extractor import *
