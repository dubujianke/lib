# -*- coding: utf-8 -*-
"""存储层：项目配置、实体 JSON 落盘、Guide 状态、WAL"""

import json
import os
import shutil
import threading
import time

_PROJECT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "projects")
_WAL_SUFFIX = ".wal"


def _atomic_write(path: str, data):
    """先写 staging → 备份 .bak → 原子替换"""
    dirname = os.path.dirname(path)
    os.makedirs(dirname, exist_ok=True)
    staging = path + ".staging"
    with open(staging, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    if os.path.exists(path):
        bak = path + ".bak"
        try:
            shutil.copyfile(path, bak)
        except OSError:
            pass
    os.replace(staging, path)


def _read_json(path: str, default=None):
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return default


class GuideStore:
    """单 JSON 文件存储，带缓存与 WAL 保护"""

    def __init__(self, path: str):
        self.path = path
        self._lock = threading.Lock()
        self._data = None
        self._dirty = False

    def _ensure(self):
        if self._data is None:
            self._data = _read_json(self.path, {})
        return self._data

    def get(self, key: str, default=None):
        d = self._ensure()
        return d.get(key, default)

    def set(self, key: str, value):
        with self._lock:
            self._ensure()[key] = value
            self._dirty = True

    def set_all(self, data: dict):
        with self._lock:
            self._data = data
            self._dirty = True

    def data(self) -> dict:
        return self._ensure()

    def write_wal(self, chapter_id: str, changes: dict, content: str = ""):
        """落盘前写 WAL，崩溃后可从 WAL 恢复"""
        with self._lock:
            wal_path = self.path + _WAL_SUFFIX
            record = {
                "chapter_id": chapter_id,
                "changes": changes,
                "content": content,
                "time": time.time(),
            }
            _atomic_write(wal_path, record)

    def recover_from_wal(self):
        """恢复 WAL 中待提交的变更，返回 (chapter_id, changes, content) 或 None"""
        wal_path = self.path + _WAL_SUFFIX
        if not os.path.exists(wal_path):
            return None
        record = _read_json(wal_path)
        if record:
            self.set(record["chapter_id"], record["changes"])
        try:
            os.remove(wal_path)
        except OSError:
            pass
        return (record or {}).get("chapter_id"), (record or {}).get("changes"), (record or {}).get("content", "")

    def clear_wal(self):
        try:
            wal_path = self.path + _WAL_SUFFIX
            if os.path.exists(wal_path):
                os.remove(wal_path)
        except OSError:
            pass

    def flush(self):
        with self._lock:
            if self._dirty:
                _atomic_write(self.path, self._data)
                self._dirty = False


class Project:
    """一个小说项目的完整存储容器"""

    def __init__(self, name: str, root: str = None):
        self.name = name
        self.root = root or _PROJECT_DIR
        self.dir = os.path.join(self.root, name)
        self.design_dir = os.path.join(self.dir, "design")
        self.plan_dir = os.path.join(self.dir, "plan")
        self.generated_dir = os.path.join(self.dir, "generated")
        self.guides_dir = os.path.join(self.dir, "guides")
        self.tracking_dir = os.path.join(self.dir, "tracking")
        # 对标 ContentGenerationCallback: 章节保存后回调
        self._save_callbacks = []  # List[callable(chapter_id, content)]

    def ensure(self):
        for d in [self.dir, self.design_dir, self.plan_dir, self.generated_dir,
                  self.guides_dir, self.tracking_dir]:
            os.makedirs(d, exist_ok=True)

    def on_chapter_saved(self, callback):
        """对标 ContentGenerationCallback: 注册章节保存后回调

        callback(chapter_id: str, content: str) -> None
        """
        self._save_callbacks.append(callback)

    # ---- 设计数据 ----
    def design_path(self, entity: str) -> str:
        return os.path.join(self.design_dir, f"{entity}.json")

    def load_design(self, entity: str):
        return _read_json(self.design_path(entity), {})

    def save_design(self, entity: str, data):
        _atomic_write(self.design_path(entity), data)

    # ---- 规划数据 ----
    def plan_path(self, entity: str) -> str:
        return os.path.join(self.plan_dir, f"{entity}.json")

    def load_plan(self, entity: str):
        return _read_json(self.plan_path(entity), {})

    def save_plan(self, entity: str, data):
        _atomic_write(self.plan_path(entity), data)

    # ---- 生成内容 ----
    def chapter_path(self, chapter_id: str) -> str:
        return os.path.join(self.generated_dir, f"{chapter_id}.md")

    def save_chapter(self, chapter_id: str, content: str):
        """对标原版：存纯文本 .md（非 JSON 包裹）"""
        dirname = os.path.dirname(self.chapter_path(chapter_id))
        os.makedirs(dirname, exist_ok=True)
        staging = self.chapter_path(chapter_id) + ".staging"
        with open(staging, "w", encoding="utf-8") as f:
            f.write(content)
        if os.path.exists(self.chapter_path(chapter_id)):
            try:
                os.replace(self.chapter_path(chapter_id), self.chapter_path(chapter_id) + ".bak")
            except OSError:
                pass
        os.replace(staging, self.chapter_path(chapter_id))
        # 对标 ContentGenerationCallback: 通知回调（如向量索引重建）
        for cb in self._save_callbacks:
            try:
                cb(chapter_id, content)
            except Exception:
                pass

    def load_chapter(self, chapter_id: str):
        path = self.chapter_path(chapter_id)
        if not os.path.exists(path):
            return ""
        try:
            with open(path, "r", encoding="utf-8") as f:
                text = f.read()
            # 兼容旧 JSON 格式
            if text.startswith("{"):
                import json
                return json.loads(text).get("content", text)
            return text
        except (OSError, json.JSONDecodeError):
            return ""

    def save_chapter_text(self, filename: str, content: str):
        """保存可读文件名的纯文本 .md"""
        import shutil
        path = os.path.join(self.generated_dir, filename)
        staging = path + ".staging"
        os.makedirs(self.generated_dir, exist_ok=True)
        with open(staging, "w", encoding="utf-8") as f:
            f.write(content)
        if os.path.exists(path):
            try:
                os.replace(path, path + ".bak")
            except OSError:
                pass
        os.replace(staging, path)

    # ---- Guide 状态存储 ----
    def guide(self, name: str) -> GuideStore:
        return GuideStore(os.path.join(self.guides_dir, f"{name}.json"))

    def tracking(self, name: str) -> GuideStore:
        return GuideStore(os.path.join(self.tracking_dir, f"{name}.json"))


def get_projects(root: str = None) -> list:
    root = root or _PROJECT_DIR
    if not os.path.exists(root):
        return []
    return [d for d in os.listdir(root)
            if os.path.isdir(os.path.join(root, d)) and not d.startswith("_")]


def create_project(name: str, root: str = None) -> Project:
    p = Project(name, root)
    p.ensure()
    return p
