# -*- coding: utf-8 -*-
"""对标 GenerationStatistics + WordCountTolerance"""
import time


class GenerationStats:
    """对标 GenerationStatistics: 跟踪尝试记录"""
    def __init__(self, chapter_id: str):
        self.chapter_id = chapter_id
        self.attempts = []
        self.start_time = time.time()
        self.success = False

    def add_attempt(self, attempt: int, success: bool, reason: str, failures: list = None):
        self.attempts.append({
            "attempt": attempt,
            "success": success,
            "reason": reason,
            "failures": failures or [],
            "elapsed": round(time.time() - self.start_time, 2),
        })

    def elapsed(self) -> float:
        return round(time.time() - self.start_time, 2)


def get_word_count_tolerance(target: int) -> tuple:
    """对标 WordCountTolerance.GetMinWordCount/GetMaxWordCount"""
    if target <= 0:
        return 0, 0
    if target <= 500:
        return int(target * 0.6), int(target * 2.0)
    if target <= 2000:
        return int(target * 0.65), int(target * 1.6)
    if target <= 5000:
        return int(target * 0.7), int(target * 1.4)
    return int(target * 0.75), int(target * 1.3)
