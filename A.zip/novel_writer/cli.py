# -*- coding: utf-8 -*-
"""命令行交互入口：python -m novel_writer.cli 或 python cli.py"""

import os
import sys
import json

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ai_client import AIClient
from novel_writer.ai_service import AIService
from novel_writer.prompt_library import PromptLibrary
from novel_writer.pipeline import NovelPipeline
from novel_writer.storage import Project, get_projects, create_project
from novel_writer.unified_validation import UnifiedValidation
from novel_writer.book_reader import BookReader
from novel_writer.book_pipeline_v4 import ChaishuPipeline4, DATA_ROOT


def _bold(s): return f"\033[1m{s}\033[0m"


def _err(s): return f"\033[31m{s}\033[0m"


def _ok(s): return f"\033[32m{s}\033[0m"


class CLI:
    def __init__(self, genre: str = None, root: str = None):
        self.ai = AIService()
        self.library = PromptLibrary()
        self.genre = genre or (self.library.genres[0] if self.library.genres else "玄幻")
        self.root = root

    # ---------- 交互 ----------
    def run(self):
        print(_bold("\n=== 天命 · AI 网文创作引擎 (Python 移植版) ==="))
        print(f"可用题材 ({len(self.library.genres)}): {'、'.join(self.library.genres)}\n")
        self.genre = self._ask(f"选择题材（默认 {self.genre}）", self.genre, self.library.genres)

        while True:
            self._menu()
            choice = input("\n> ").strip()
            if choice == "1":
                self._new_project()
            elif choice == "2":
                self._open_project()
            elif choice == "3":
                self._generate_design()
            elif choice == "4":
                self._generate_plan()
            elif choice == "5":
                self._generate_chapters()
            elif choice == "6":
                self._validate()
            elif choice == "7":
                self._view_chapter()
            elif choice == "8":
                self._one_click()
            elif choice == "9":
                self._book_analysis_menu()
            elif choice in ("0", "q", "exit"):
                print("再见！")
                self.ai.close()
                break
            else:
                print("无效选项")

    def _menu(self):
        print("\n" + _bold("主菜单"))
        print(" 1. 新建项目")
        print(" 2. 打开项目")
        print(" 3. 生成五维设定")
        print(" 4. 生成四层规划（大纲→分卷→章节→蓝图）")
        print(" 5. 逐章生成")
        print(" 6. 统一校验")
        print(" 7. 查看章节")
        print(" 8. 一键生成（全流程）")
        print(" 9. 智能拆书")
        print(" 0. 退出")

    def _ask(self, prompt: str, default: str = "", options: list = None):
        if options:
            print(f"可选: {'、'.join(options)}")
        val = input(f"{prompt}: ").strip()
        if not val:
            return default
        return val

    # ---------- 项目 ----------
    def _new_project(self):
        name = self._ask("项目名（英文或数字）", f"novel_{len(get_projects(self.root)) + 1}")
        self.project = create_project(name, self.root)
        self.pipeline = NovelPipeline(self.project, self.ai, self.library)
        self.validator = UnifiedValidation(self.project)
        print(_ok(f"项目 '{name}' 已创建。"))
        self._project_context()

    def _open_project(self):
        projects = get_projects(self.root)
        if not projects:
            print(_err("没有已存在的项目，请先新建。"))
            return
        print(f"已有项目: {'、'.join(projects)}")
        name = self._ask("输入项目名")
        if name not in projects:
            print(_err(f"项目 '{name}' 不存在。"))
            return
        self.project = Project(name, self.root)
        self.pipeline = NovelPipeline(self.project, self.ai, self.library)
        self.validator = UnifiedValidation(self.project)
        print(_ok(f"已打开项目 '{name}'。"))
        self._project_context()

    def _project_context(self):
        print(f"  当前题材: {self.genre}")

    # ---------- 生成 ----------
    def _generate_design(self):
        if not self._require_project():
            return
        concept = self._ask("一句话创作概念（如：废柴少年逆天改命）")
        vols = int(self._ask("总卷数", "3"))
        chapters = int(self._ask("总章节数", "30"))
        chars = int(self._ask("核心角色数", "3"))
        print()
        self.pipeline.generate_design(self.genre, concept, vols, chapters, chars)
        print(_ok("五维设定生成完毕。"))

    def _generate_plan(self):
        if not self._require_project():
            return
        chapters = int(self._ask("总章节数", "30"))
        print()
        self.pipeline.generate_plan(self.genre, chapters)
        print(_ok("四层规划生成完毕。"))

    def _generate_chapters(self):
        if not self._require_project():
            return
        start = int(self._ask("起始章节", "1"))
        end = self._ask("结束章节（留空=全部）")
        end = int(end) if end else None
        words = int(self._ask("每章目标字数", "3500"))
        self.pipeline.generate_all_chapters(self.genre, start, end,
                                            word_count=words, verbose=True)
        print(_ok("章节生成完毕。"))

    def _validate(self):
        if not self._require_project():
            return
        report = self.validator.validate_all()
        print(_bold(f"\n统一校验报告（共 {report['total']} 章）"))
        print(f"  通过: {report['passed']}")
        for w in report["warnings"]:
            print(f"  ⚠ {w}")
        for f in report["failed"]:
            print(_err(f"  ✗ 第{f['chapter_number']}章《{f['chapter']}》: "
                       f"{'; '.join(e for fail in f['failures'] for e in fail.get('Errors', []))}"))
        issues = self.validator.check_consistency()
        if issues:
            print(_bold("\n跨章节一致性隐患:"))
            for i in issues:
                print(f"  ⚠ {i['chapter']}: {i['expected']}")
        if not report["failed"] and not report["warnings"]:
            print(_ok("  全书校验通过，无一致性问题。"))

    def _view_chapter(self):
        if not self._require_project():
            return
        num = int(self._ask("章节号"))
        plans = self.project.load_plan("chapters")
        chapters = plans.get("chapters", []) if isinstance(plans, dict) else plans
        for c in chapters:
            if c.get("ChapterNumber") == num:
                content = self.project.load_chapter(c.get("Id", ""))
                print(_bold(f"\n=== 第{num}章《{c.get('ChapterTitle')}》==="))
                print(content[:1500])
                return
        print(_err("未找到该章节。"))

    def _one_click(self):
        if not self._require_project():
            return
        concept = self._ask("一句话创作概念")
        vols = int(self._ask("总卷数", "2"))
        chapters = int(self._ask("总章节数", "10"))
        chars = int(self._ask("核心角色数", "3"))
        words = int(self._ask("每章目标字数", "3000"))
        print(_bold("\n=== 一键生成开始 ==="))
        self.pipeline.generate_design(self.genre, concept, vols, chapters, chars)
        self.pipeline.generate_plan(self.genre, chapters)
        self.pipeline.generate_all_chapters(self.genre, 1, None, word_count=words)
        print(_ok("\n=== 一键生成完成 ==="))

    # ========== 拆书模块 ==========

    def _book_analysis_menu(self):
        if not self._require_project():
            return
        while True:
            print("\n" + _bold("智能拆书"))
            print(" 1. 列出本地小说")
            print(" 2. 拆书一本小说")
            print(" 3. 查看拆书结果目录")
            print(" 0. 返回主菜单")
            choice = input("\n> ").strip()
            if choice == "1":
                self._list_local_books()
            elif choice == "2":
                self._run_local_book_analysis()
            elif choice == "3":
                self._view_book_analysis_output()
            elif choice in ("0", "q", "exit"):
                break
            else:
                print("无效选项")

    def _list_local_books(self):
        reader = BookReader(DATA_ROOT)
        books = reader.list_books()
        if not books:
            print(_err(f"  本地目录 {DATA_ROOT} 下没有小说"))
            return
        print(f"  本地小说共 {len(books)} 本，前 20 条如下：")
        for b in books[:20]:
            info = b.get("info", {}) or {}
            title = info.get("title", "") or b["id"]
            author = info.get("author", "")
            chapter_count = b.get("chapter_count", 0)
            print(f"  - {b['id']}: {title} / {author} / {chapter_count}章")

    def _run_local_book_analysis(self):
        book_id = self._ask("输入小说ID（如 1）")
        if not book_id:
            return
        pipeline = ChaishuPipeline4(book_id)
        with_materials = self._ask("是否同时生成创作素材？(y/n)", "y").lower() == "y"
        genre = self._ask("素材题材（留空=书籍分类）", "")
        print(_bold("\n=== 开始拆书 ==="))
        try:
            result = pipeline.run(with_materials=with_materials, material_genre=genre or None)
            print(_ok(f"  拆书完成，输出目录：{result.get('storage', '')}"))
        except Exception as e:
            print(_err(f"  拆书失败: {e}"))

    def _view_book_analysis_output(self):
        book_id = self._ask("输入小说ID（如 1）")
        if not book_id:
            return
        out = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "books_data", "CrawledBooks", str(book_id))
        if not os.path.exists(out):
            print(_err("  未找到拆书输出目录"))
            return
        print(f"  输出目录: {out}")
        for name in sorted(os.listdir(out)):
            path = os.path.join(out, name)
            print(f"  - {name} ({os.path.getsize(path)} bytes)")

    def _require_project(self) -> bool:
        if hasattr(self, "project") and self.project:
            return True
        print(_err("请先新建或打开项目。"))
        return False


def main():
    import argparse
    parser = argparse.ArgumentParser(description="天命 AI 网文创作引擎 (Python 版)")
    parser.add_argument("--genre", help="小说题材")
    parser.add_argument("--project-root", help="项目存储根目录")
    parser.add_argument("--config", "-c", help="创作配置文件路径 (如 novel_config.json)，非交互模式一键生成")
    parser.add_argument("--design-only", action="store_true", help="配合 --config，只生成五维设定和四层规划")
    parser.add_argument("--start-chapter", type=int, default=None, help="配合 --config，指定起始章节（跳过已生成的）")
    args = parser.parse_args()

    if args.config:
        _run_config_mode(args)
    else:
        cli = CLI(genre=args.genre, root=args.project_root)
        cli.run()


def _run_config_mode(args):
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from ai_client import AIClient
    from novel_writer.ai_service import AIService
    from novel_writer.prompt_library import PromptLibrary
    from novel_writer.pipeline import NovelPipeline
    from novel_writer.storage import create_project, get_projects, Project
    from novel_writer.config_loader import load_config, build_creative_spec
    from novel_writer.unified_validation import UnifiedValidation
    from novel_writer.book_pipeline_v4 import ChaishuPipeline4, DATA_ROOT, OUTPUT_ROOT

    cfg = load_config(args.config)
    genre = cfg.get("题材", args.genre or "玄幻")
    concept = cfg.get("创作概念", " ")
    gen_cfg = cfg.get("生成控制", {})
    vols = gen_cfg.get("总卷数", 2)
    chapters = gen_cfg.get("总章节数", 10)
    chars = gen_cfg.get("核心角色数", 3)
    words = gen_cfg.get("每章字数", 3000)
    creative_spec = build_creative_spec(cfg)
    proj_name = gen_cfg.get("项目名", "novel_" + genre)

    # 拆书配置
    book_analysis = cfg.get("拆书分析", {})
    book_id = book_analysis.get("小说ID", "")

    ai = AIService()
    lib = PromptLibrary()
    project = create_project(proj_name, root=args.project_root)
    pipeline = NovelPipeline(project, ai, lib)

    if book_id:
        print(_bold("\n=== 0. 智能拆书 ==="))
        with_materials = book_analysis.get("生成素材", True)
        genre_override = book_analysis.get("素材题材", "")
        print(f"  小说ID: {book_id}")
        bp = ChaishuPipeline4(str(book_id))
        try:
            bp.run(with_materials=with_materials, material_genre=genre_override or None)
            print(_ok(f"  拆书完成"))
        except Exception as e:
            print(_err(f"  拆书失败: {e}"))

    print(_bold(f"\n=== 配置模式：一键生成 ==="))
    print(f"  题材: {genre} | 概念: {concept[:50]}...")
    print(f"  卷数: {vols} | 章节: {chapters} | 角色: {chars} | 字数: {words}")
    print(f"  项目目录: {project.dir}\n")

    print(_bold("=== 1. 五维设定 ==="))
    design = pipeline.generate_design(genre, concept, vols, chapters, chars)
    print(f"  世界观: {design['world'].OneLineSummary[:60]}...")
    print(f"  角色: {', '.join(c.Name for c in design['characters'])}")

    print(_bold("\n=== 2. 四层规划 ==="))
    plan = pipeline.generate_plan(genre, chapters)
    ch_list = plan["chapters"]
    print(f"  章节: {' → '.join(c.ChapterTitle for c in ch_list[:5])}...")

    if args.design_only:
        print(_ok("\n=== 设定+规划完成（--design-only）==="))
        ai.close()
        return

    print(_bold(f"\n=== 3. 逐章生成 ({len(ch_list)}章) ==="))
    start = args.start_chapter or 1
    results = []
    for c in ch_list:
        num = c.ChapterNumber
        if num < start:
            continue
        try:
            r = pipeline.generate_chapter(genre, num, creative_spec=creative_spec,
                                          word_count=words, verbose=True)
            results.append(r)
            print(f"  ✓ 第{num}章《{c.ChapterTitle}》完成，{len(r['content'])}字")
        except Exception as e:
            print(_err(f"  ✗ 第{num}章失败: {e}"))
            continue

    print(_bold("\n=== 4. 统一校验 ==="))
    validator = UnifiedValidation(project)
    report = validator.validate_all()
    print(f"  通过: {report['passed']}/{report['total']}")
    for f in report["failed"]:
        print(_err(f"  ✗ 第{f['chapter_number']}章: {f['failures']}"))

    ai.close()
    print(_ok(f"\n=== 完成！文件在: {project.dir} ==="))


if __name__ == "__main__":
    main()
