# -*- coding: utf-8 -*-
"""兼容 shim：转发到 .implementations.tracking.foreshadowing_status_service"""
from .implementations.tracking.foreshadowing_status_service import *
