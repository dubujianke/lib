# -*- coding: utf-8 -*-
"""兼容 shim：转发到 implementations.tracking.rules"""
from .implementations.tracking.rules import (
    LedgerRuleSet, LedgerRuleSetProvider, build_ruleset_by_genre,
    XIANXIA_ABILITY_LOSS_KEYWORDS, URBAN_ABILITY_LOSS_KEYWORDS,
)

__all__ = [
    "LedgerRuleSet", "LedgerRuleSetProvider", "build_ruleset_by_genre",
    "XIANXIA_ABILITY_LOSS_KEYWORDS", "URBAN_ABILITY_LOSS_KEYWORDS",
]
