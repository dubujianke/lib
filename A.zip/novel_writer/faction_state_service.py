# -*- coding: utf-8 -*-
"""兼容 shim：转发到 .implementations.tracking.faction_state_service"""
from .implementations.tracking.faction_state_service import *
