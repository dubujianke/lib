# -*- coding: utf-8 -*-
"""生成内容服务 — 对标 Implementations/Generation/GeneratedContentService.cs"""
import os
import re
import threading
from typing import List, Optional


class GeneratedContentService:
    def __init__(self, project):
        self.project = project
        self._meta_cache = {}
        self._meta_cache_lock = threading.Lock()

    @property
    def chapters_directory(self) -> str:
        return self.project.generated_dir

    def get_chapter(self, chapter_id: str) -> Optional[str]:
        if not chapter_id:
            return None
        content = self.project.load_chapter(chapter_id)
        if isinstance(content, dict):
            content = content.get("content", "")
        return content if content else None

    def save_chapter(self, chapter_id: str, content: str):
        if not chapter_id:
            raise ValueError("章节ID不能为空")
        self.project.save_chapter(chapter_id, content)

    def get_generated_chapters(self) -> List:
        from ...models.generated.chapter_info import ChapterInfo
        chapters = []
        if not os.path.exists(self.chapters_directory):
            return chapters
        files = [f for f in os.listdir(self.chapters_directory) if f.endswith(".md")]
        for file in files:
            chapter_id = file[:-3]
            content = self.get_chapter(chapter_id) or ""
            title, word_count = self._read_chapter_meta(content)
            vol, ch = self._parse_chapter_id(chapter_id)
            chapters.append(ChapterInfo(
                Id=chapter_id, Title=title, VolumeNumber=vol, ChapterNumber=ch,
                WordCount=word_count, FilePath=os.path.join(self.chapters_directory, file)))
        chapters.sort(key=lambda c: (c.VolumeNumber, c.ChapterNumber))
        return chapters

    def delete_chapter(self, chapter_id: str) -> bool:
        if not chapter_id:
            return False
        path = os.path.join(self.chapters_directory, f"{chapter_id}.md")
        if not os.path.exists(path):
            return False
        try:
            os.remove(path)
            return True
        except Exception:
            return False

    def chapter_exists(self, chapter_id: str) -> bool:
        if not chapter_id:
            return False
        return os.path.exists(os.path.join(self.chapters_directory, f"{chapter_id}.md"))

    @staticmethod
    def _parse_chapter_id(chapter_id: str):
        from ...character_state_service import parse_chapter_id
        return parse_chapter_id(chapter_id)

    @staticmethod
    def _read_chapter_meta(content: str):
        if not content:
            return "未命名章节", 0
        lines = content.split("\n")
        title = None
        for line in lines[:10]:
            trimmed = line.strip()
            if trimmed.startswith("# "):
                title = trimmed[2:].strip()
                break
            elif trimmed.startswith("## "):
                title = trimmed[3:].strip()
                break
        if not title:
            first = next((l.strip() for l in lines if l.strip()), "")
            title = (first[:50] + "...") if len(first) > 50 else first or "未命名章节"
        word_count = len(content.replace("\n", "").replace(" ", ""))
        return title, word_count

    async def volume_exists_async(self, volume_number: int) -> bool:
        from ...services.volume_design_service import VolumeDesignService
        svc = VolumeDesignService(self.project.dir)
        vols = svc.get_all_volume_designs()
        return any(v.VolumeNumber == volume_number for v in vols)

    async def generate_next_chapter_id_from_source_async(self, source_chapter_id: str) -> str:
        m = re.match(r"vol(\d+)_ch(\d+)", source_chapter_id, re.IGNORECASE)
        if not m:
            raise ValueError(f"Invalid chapter ID format: {source_chapter_id}")
        vol_num = int(m.group(1))
        ch_num = int(m.group(2))

        if not await self.volume_exists_async(vol_num):
            raise ValueError(f"Volume {vol_num} does not exist")

        next_id = f"vol{vol_num}_ch{ch_num + 1}"
        if not self.chapter_exists(next_id):
            return next_id

        next_vol = vol_num + 1
        if await self.volume_exists_async(next_vol):
            return f"vol{next_vol}_ch1"

        raise ValueError(f"Cannot generate next chapter after {source_chapter_id}")
