# -*- coding: utf-8 -*-
"""CHANGES 归一化：ID 解析、自动创建、状态机防护 — 对标 ChapterChangesCanonicalizer.cs

对标 C# 完整逻辑：
- Resolve（ShortId→括号提取→名称→去注释→自动创建）
- StripByPrimaryId（剔除主ID仍为名称的条目）
- StripEmpty（剔除值字段全空的预填条目）
- ResolveOrCreateLocationId（位置自动注册 + 补充 LocationStateChange）
- 链式修正（同章多次移动/物品转移 FromLocation/FromHolder 自动补值）
- 状态机防护（伏笔/冲突/TrustDelta）
"""

import copy
import hashlib
import re
from itertools import groupby
from typing import Dict, List, Optional, Tuple

from ...models import (
    ChapterChanges, FactSnapshot, is_likely_id,
    CharacterStateChange, ConflictProgressChange, PlotPointChange,
    ForeshadowingAction, LocationStateChange, FactionStateChange,
    CharacterMovementChange, ItemTransferChange,
    SecretRevealChange, PledgeConstraintChange, DeadlineConstraintChange,
)


class EntityMap:
    """轻量级实体映射（对标 C# EntityLookup 内部类）"""

    def __init__(self):
        self.id_set = set()
        self.name_to_id = {}
        self._ambiguous = set()

    def add(self, eid: str, name: str):
        if not eid:
            return
        self.id_set.add(eid)
        if not name:
            return
        n = name.strip()
        if n in self._ambiguous:
            return
        if n in self.name_to_id and self.name_to_id[n] != eid:
            del self.name_to_id[n]
            self._ambiguous.add(n)
        elif n not in self.name_to_id:
            self.name_to_id[n] = eid

    def contains(self, eid: str) -> bool:
        return eid in self.id_set


class ChapterChangesCanonicalizer:
    """归一化：解析 ID、自动创建实体、状态机防护。对标 4.1.1 Canonicalize"""

    _TRUST_DELTA_MAX = 30
    _DEFAULT_CONFLICT_STATUS_SEQUENCE = ["pending", "active", "climax", "resolved"]

    def __init__(self, snapshot: FactSnapshot):
        self.snapshot = snapshot
        self.new_entities = []      # (type, name) 自动创建记录
        self.ambiguous_fields = []  # 名称无法解析的歧义标记（不拦截，仅告警）
        self.patch_log = []         # 规范化操作日志
        self.total_attempted = 0    # 总尝试解析次数
        self.forged_count = 0       # 疑似伪造计数

    def canonicalize(self, changes: ChapterChanges) -> ChapterChanges:
        """对标 Canonicalize 入口：DeepCopy + 9类解析 + 状态机防护 + 多轮清洗"""
        canonical = copy.deepcopy(changes)

        char_map = self._build_map("char")
        loc_map = self._build_map("loc")
        faction_map = self._build_map("faction")
        item_map = self._build_map("item")
        conflict_map = self._build_map("conflict")
        foreshadow_map = self._build_map("foreshadow")
        secret_map = self._build_map("secret")
        pledge_map = self._build_map("pledge")
        deadline_map = self._build_map("deadline")

        char_current_loc = self._build_char_current_loc_map()
        item_current_holder = self._build_item_current_holder_map()

        # ---- 9类解析 ----
        for ch in canonical.CharacterStateChanges:
            ch.CharacterId = self._resolve("CharacterStateChanges.CharacterId", ch.CharacterId, char_map)
            if ch.RelationshipChanges:
                rebuilt = {}
                for key, val in (ch.RelationshipChanges or {}).items():
                    resolved_key = self._resolve("CharacterStateChanges.RelationshipChanges.Key", key, char_map)
                    if not is_likely_id(resolved_key):
                        self.patch_log.append(f"[Canonicalize] RelationshipChanges: 剔除key仍为名称的关系 '{resolved_key}'")
                        continue
                    if char_map.id_set and resolved_key not in char_map.id_set:
                        self.patch_log.append(f"[Canonicalize] RelationshipChanges: 剔除key不在账本中的关系 '{resolved_key}'")
                        continue
                    rebuilt[resolved_key] = val
                ch.RelationshipChanges = rebuilt

        for cp in canonical.ConflictProgress:
            cp.ConflictId = self._resolve("ConflictProgress.ConflictId", cp.ConflictId, conflict_map)

        for fa in canonical.ForeshadowingActions:
            fa.ForeshadowId = self._resolve("ForeshadowingActions.ForeshadowId", fa.ForeshadowId, foreshadow_map)

        for lc in canonical.LocationStateChanges:
            lc.LocationId = self._resolve("LocationStateChanges.LocationId", lc.LocationId, loc_map)

        for fc in canonical.FactionStateChanges:
            fc.FactionId = self._resolve("FactionStateChanges.FactionId", fc.FactionId, faction_map)

        # ---- 角色移动链式修正 ----
        last_loc = {}
        for mv in canonical.CharacterMovements:
            mv.CharacterId = self._resolve("CharacterMovements.CharacterId", mv.CharacterId, char_map)

            if mv.FromLocation:
                mv.FromLocation = self._resolve("CharacterMovements.FromLocation", mv.FromLocation, loc_map)

            if (not self._is_valid_id(mv.FromLocation) or (mv.FromLocation and mv.FromLocation not in loc_map.id_set)) and mv.CharacterId:
                if mv.CharacterId in last_loc:
                    self.patch_log.append(f"[Canonicalize] CharacterMovements.FromLocation 同章补值: {mv.CharacterId} → {last_loc[mv.CharacterId]}")
                    mv.FromLocation = last_loc[mv.CharacterId]
                elif mv.CharacterId in char_current_loc and self._is_valid_id(char_current_loc[mv.CharacterId]):
                    self.patch_log.append(f"[Canonicalize] CharacterMovements.FromLocation 账本补值: {mv.CharacterId} → {char_current_loc[mv.CharacterId]}")
                    mv.FromLocation = char_current_loc[mv.CharacterId]
                elif not self._is_valid_id(mv.FromLocation) or (mv.FromLocation and mv.FromLocation not in loc_map.id_set):
                    self.patch_log.append(f"[Canonicalize] CharacterMovements.FromLocation '{mv.FromLocation}' 不在已注册地点中，按未知出发地处理")
                    self.ambiguous_fields = [a for a in self.ambiguous_fields if "CharacterMovements.FromLocation" not in a]
                    mv.FromLocation = ""

            mv.ToLocation = self._resolve("CharacterMovements.ToLocation", mv.ToLocation, loc_map)
            if mv.CharacterId and self._is_valid_id(mv.ToLocation):
                last_loc[mv.CharacterId] = mv.ToLocation

        # ---- 物品转移链式修正 ----
        last_holder = {}
        for it in canonical.ItemTransfers:
            it.ItemId = self._resolve("ItemTransfers.ItemId", it.ItemId, item_map)

            if it.FromHolder:
                it.FromHolder = self._resolve("ItemTransfers.FromHolder", it.FromHolder, char_map)

            if it.FromHolder and (not self._is_valid_id(it.FromHolder) or it.FromHolder not in char_map.id_set):
                if it.ItemId and it.ItemId in last_holder:
                    self.patch_log.append(f"[Canonicalize] ItemTransfers.FromHolder 同章补值: {it.ItemId} → {last_holder[it.ItemId]}")
                    it.FromHolder = last_holder[it.ItemId]
                elif it.ItemId and it.ItemId in item_current_holder and item_current_holder[it.ItemId] in char_map.id_set:
                    self.patch_log.append(f"[Canonicalize] ItemTransfers.FromHolder 账本补值: {it.ItemId} → {item_current_holder[it.ItemId]}")
                    it.FromHolder = item_current_holder[it.ItemId]
                elif it.FromHolder and (not self._is_valid_id(it.FromHolder) or it.FromHolder not in char_map.id_set):
                    self.patch_log.append(f"[Canonicalize] ItemTransfers.FromHolder 无法解析，已清空: '{it.FromHolder}'")
                    self.ambiguous_fields = [a for a in self.ambiguous_fields if "ItemTransfers.FromHolder" not in a]
                    it.FromHolder = ""

            it.ToHolder = self._resolve("ItemTransfers.ToHolder", it.ToHolder, char_map)
            if it.ToHolder and (not self._is_valid_id(it.ToHolder) or it.ToHolder not in char_map.id_set):
                self.patch_log.append(f"[Canonicalize] ItemTransfers.ToHolder 无法解析，已清空: '{it.ToHolder}'")
                self.ambiguous_fields = [a for a in self.ambiguous_fields if "ItemTransfers.ToHolder" not in a]
                it.ToHolder = ""

            if it.ItemId and self._is_valid_id(it.ToHolder):
                last_holder[it.ItemId] = it.ToHolder

        # ---- NewPlotPoints 角色处理 ----
        for pp in canonical.NewPlotPoints:
            for i in range(len(pp.InvolvedCharacters)):
                pp.InvolvedCharacters[i] = self._resolve("NewPlotPoints.InvolvedCharacters", pp.InvolvedCharacters[i], char_map)

        # ---- SecretRevealChanges ----
        for sr in canonical.SecretRevealChanges:
            sr.SecretId = self._resolve("SecretRevealChanges.SecretId", sr.SecretId, secret_map)
            for i in range(len(sr.NewKnowerIds)):
                sr.NewKnowerIds[i] = self._resolve("SecretRevealChanges.NewKnowerIds", sr.NewKnowerIds[i], char_map)

        # ---- PledgeConstraintChanges ----
        for pc in canonical.PledgeConstraintChanges:
            pc.PledgeId = self._resolve("PledgeConstraintChanges.PledgeId", pc.PledgeId, pledge_map)
            for i in range(len(pc.PartyIds)):
                pc.PartyIds[i] = self._resolve("PledgeConstraintChanges.PartyIds", pc.PartyIds[i], char_map)

        # ---- DeadlineConstraintChanges ----
        for dc in canonical.DeadlineConstraintChanges:
            dc.DeadlineId = self._resolve("DeadlineConstraintChanges.DeadlineId", dc.DeadlineId, deadline_map)
            for i in range(len(dc.PartyIds)):
                dc.PartyIds[i] = self._resolve("DeadlineConstraintChanges.PartyIds", dc.PartyIds[i], char_map)

        # ---- 状态机防护 ----
        canonical.ForeshadowingActions = self._canonicalize_foreshadowing_actions(
            canonical.ForeshadowingActions, self._build_foreshadow_state_map())
        canonical.ConflictProgress = self._canonicalize_conflict_progress(
            canonical.ConflictProgress, self._build_conflict_current_status_map())

        # ---- 名称→ID自动生成（新实体） ----
        new_item_ids_by_name = {}
        for it in canonical.ItemTransfers:
            item_id_raw = (it.ItemId or "").strip()
            if self._is_valid_id(item_id_raw) and item_map.contains(item_id_raw):
                continue
            if it.ItemName:
                existing_id = self._resolve("ItemTransfers.ItemName", it.ItemName, item_map)
                if self._is_valid_id(existing_id) and item_map.contains(existing_id):
                    if it.ItemId != existing_id:
                        self.patch_log.append(f"[Canonicalize] ItemTransfers.ItemId 按名称命中: {it.ItemName} → {existing_id}")
                    it.ItemId = existing_id
                    continue
            name_key = (it.ItemName or item_id_raw or "").strip()
            if not name_key:
                continue
            if not it.ItemName:
                it.ItemName = name_key
            seed_key = self._strip_annotations(name_key).strip().lower()
            if not seed_key:
                seed_key = name_key.strip().lower()
            if name_key not in new_item_ids_by_name:
                new_item_ids_by_name[name_key] = self._new_deterministic_id("I", f"ITEM|{seed_key}")
            new_id = new_item_ids_by_name[name_key]
            if it.ItemId != new_id:
                self.patch_log.append(f"[Canonicalize] ItemTransfers.ItemId 自动生成: {name_key} → {new_id}")
            it.ItemId = new_id
            self.ambiguous_fields = [a for a in self.ambiguous_fields if name_key not in a]

        new_secret_ids_by_name = {}
        for sr in canonical.SecretRevealChanges:
            secret_id_raw = (sr.SecretId or "").strip()
            if self._is_valid_id(secret_id_raw) and secret_map.contains(secret_id_raw):
                continue
            if sr.SecretName:
                existing_id = self._resolve("SecretRevealChanges.SecretName", sr.SecretName, secret_map)
                if self._is_valid_id(existing_id) and secret_map.contains(existing_id):
                    if sr.SecretId != existing_id:
                        self.patch_log.append(f"[Canonicalize] SecretRevealChanges.SecretId 按名称命中: {sr.SecretName} → {existing_id}")
                    sr.SecretId = existing_id
                    continue
            name_key = (sr.SecretName or secret_id_raw or "").strip()
            if not name_key:
                continue
            if not sr.SecretName:
                sr.SecretName = name_key
            seed_key = self._strip_annotations(name_key).strip().lower()
            if not seed_key:
                seed_key = name_key.strip().lower()
            if name_key not in new_secret_ids_by_name:
                new_secret_ids_by_name[name_key] = self._new_deterministic_id("S", f"SECRET|{seed_key}")
            new_id = new_secret_ids_by_name[name_key]
            if sr.SecretId != new_id:
                self.patch_log.append(f"[Canonicalize] SecretRevealChanges.SecretId 自动生成: {name_key} → {new_id}")
            sr.SecretId = new_id
            self.ambiguous_fields = [a for a in self.ambiguous_fields if name_key not in a]

        new_pledge_ids_by_name = {}
        for pc in canonical.PledgeConstraintChanges:
            if (pc.Action or "").lower() != "create":
                continue
            pledge_id_raw = (pc.PledgeId or "").strip()
            if self._is_valid_id(pledge_id_raw) and pledge_map.contains(pledge_id_raw):
                continue
            if pc.PledgeName:
                existing_id = self._resolve("PledgeConstraintChanges.PledgeName", pc.PledgeName, pledge_map)
                if self._is_valid_id(existing_id) and pledge_map.contains(existing_id):
                    if pc.PledgeId != existing_id:
                        self.patch_log.append(f"[Canonicalize] PledgeConstraintChanges.PledgeId 按名称命中: {pc.PledgeName} → {existing_id}")
                    pc.PledgeId = existing_id
                    continue
            name_key = (pc.PledgeName or pledge_id_raw or "").strip()
            if not name_key:
                continue
            if not pc.PledgeName:
                pc.PledgeName = name_key
            seed_key = self._strip_annotations(name_key).strip().lower()
            if not seed_key:
                seed_key = name_key.strip().lower()
            if name_key not in new_pledge_ids_by_name:
                new_pledge_ids_by_name[name_key] = self._new_deterministic_id("PL", f"PLEDGE|{seed_key}")
            new_id = new_pledge_ids_by_name[name_key]
            if pc.PledgeId != new_id:
                self.patch_log.append(f"[Canonicalize] PledgeConstraintChanges.PledgeId 自动生成: {name_key} → {new_id}")
            pc.PledgeId = new_id
            self.ambiguous_fields = [a for a in self.ambiguous_fields if name_key not in a]

        new_deadline_ids_by_name = {}
        for dc in canonical.DeadlineConstraintChanges:
            if (dc.Action or "").lower() != "create":
                continue
            deadline_id_raw = (dc.DeadlineId or "").strip()
            if self._is_valid_id(deadline_id_raw) and deadline_map.contains(deadline_id_raw):
                continue
            if dc.DeadlineName:
                existing_id = self._resolve("DeadlineConstraintChanges.DeadlineName", dc.DeadlineName, deadline_map)
                if self._is_valid_id(existing_id) and deadline_map.contains(existing_id):
                    if dc.DeadlineId != existing_id:
                        self.patch_log.append(f"[Canonicalize] DeadlineConstraintChanges.DeadlineId 按名称命中: {dc.DeadlineName} → {existing_id}")
                    dc.DeadlineId = existing_id
                    continue
            name_key = (dc.DeadlineName or deadline_id_raw or "").strip()
            if not name_key:
                continue
            if not dc.DeadlineName:
                dc.DeadlineName = name_key
            seed_key = self._strip_annotations(name_key).strip().lower()
            if not seed_key:
                seed_key = name_key.strip().lower()
            if name_key not in new_deadline_ids_by_name:
                new_deadline_ids_by_name[name_key] = self._new_deterministic_id("DL", f"DEADLINE|{seed_key}")
            new_id = new_deadline_ids_by_name[name_key]
            if dc.DeadlineId != new_id:
                self.patch_log.append(f"[Canonicalize] DeadlineConstraintChanges.DeadlineId 自动生成: {name_key} → {new_id}")
            dc.DeadlineId = new_id
            self.ambiguous_fields = [a for a in self.ambiguous_fields if name_key not in a]

        # ---- ResolveOrCreateLocationId（位置自动注册 + 补充 LocationStateChange） ----
        new_loc_ids_by_name = {}
        for lc in canonical.LocationStateChanges:
            resolved = self._resolve_or_create_location_id(
                lc.LocationId, lc.LocationName, "LocationStateChanges", loc_map, new_loc_ids_by_name)
            if resolved:
                lc.LocationId = resolved
                if not lc.LocationName:
                    name_key = (lc.LocationName or lc.LocationId or "").strip()
                    if name_key and not self._is_valid_id(name_key):
                        lc.LocationName = name_key
        for mv in canonical.CharacterMovements:
            resolved = self._resolve_or_create_location_id(
                mv.ToLocation, mv.ToLocationName, "CharacterMovements.ToLocation", loc_map, new_loc_ids_by_name)
            if resolved:
                mv.ToLocation = resolved
                if not mv.ToLocationName:
                    name_key = (mv.ToLocationName or mv.ToLocation or "").strip()
                    if name_key and not self._is_valid_id(name_key):
                        mv.ToLocationName = name_key

        if new_loc_ids_by_name:
            existing_loc_ids = set()
            for lc in canonical.LocationStateChanges:
                if lc.LocationId:
                    existing_loc_ids.add(lc.LocationId)
            for name, eid in new_loc_ids_by_name.items():
                if eid not in existing_loc_ids:
                    canonical.LocationStateChanges.append(LocationStateChange(
                        LocationId=eid,
                        LocationName=name,
                        NewStatus="active",
                        Event="",
                        Importance="normal",
                    ))
                    self.patch_log.append(f"[Canonicalize] 自动补充 LocationStateChange 以确保名称入账: {name} → {eid}")

        # ---- StripByPrimaryId（剔除主ID仍为名称的条目） ----
        canonical.CharacterStateChanges = self._strip_by_primary_id(
            canonical.CharacterStateChanges, lambda x: x.CharacterId, "CharacterStateChanges", char_map.id_set)
        canonical.ConflictProgress = self._strip_by_primary_id(
            canonical.ConflictProgress, lambda x: x.ConflictId, "ConflictProgress", conflict_map.id_set)
        canonical.ForeshadowingActions = self._strip_by_primary_id(
            canonical.ForeshadowingActions, lambda x: x.ForeshadowId, "ForeshadowingActions", foreshadow_map.id_set)
        canonical.LocationStateChanges = self._strip_by_primary_id(
            canonical.LocationStateChanges, lambda x: x.LocationId, "LocationStateChanges")
        canonical.FactionStateChanges = self._strip_by_primary_id(
            canonical.FactionStateChanges, lambda x: x.FactionId, "FactionStateChanges", faction_map.id_set)
        canonical.CharacterMovements = self._strip_by_primary_id(
            canonical.CharacterMovements, lambda x: x.CharacterId, "CharacterMovements", char_map.id_set)
        canonical.ItemTransfers = self._strip_by_primary_id(
            canonical.ItemTransfers, lambda x: x.ItemId, "ItemTransfers")
        canonical.SecretRevealChanges = self._strip_by_primary_id(
            canonical.SecretRevealChanges, lambda x: x.SecretId, "SecretRevealChanges")
        canonical.PledgeConstraintChanges = self._strip_by_primary_id(
            canonical.PledgeConstraintChanges, lambda x: x.PledgeId, "PledgeConstraintChanges")
        canonical.DeadlineConstraintChanges = self._strip_by_primary_id(
            canonical.DeadlineConstraintChanges, lambda x: x.DeadlineId, "DeadlineConstraintChanges")

        # ---- CharacterMovements ToLocation 格式校验 ----
        canonical.CharacterMovements = [
            mv for mv in canonical.CharacterMovements
            if self._is_valid_id((mv.ToLocation or "").strip())
        ]

        # ---- 多移动链式校正 ----
        if len(canonical.CharacterMovements) > 1:
            sorted_movs = sorted(canonical.CharacterMovements, key=lambda x: x.CharacterId or "")
            for cid, grp in groupby(sorted_movs, key=lambda x: x.CharacterId):
                movs = list(grp)
                for i in range(1, len(movs)):
                    prev = movs[i - 1]
                    if self._is_valid_id(prev.ToLocation) and movs[i].FromLocation != prev.ToLocation:
                        self.patch_log.append(f"[Canonicalize] CharacterMovements 链修正 {movs[i].CharacterId}[{i}]: FromLocation '{movs[i].FromLocation}'→'{prev.ToLocation}'")
                        movs[i].FromLocation = prev.ToLocation

        # ---- TrustDelta 夹断 ----
        for ch in canonical.CharacterStateChanges:
            if not ch.RelationshipChanges:
                continue
            for key, rel in ch.RelationshipChanges.items():
                if rel.TrustDelta and abs(rel.TrustDelta) > self._TRUST_DELTA_MAX:
                    clamped = self._TRUST_DELTA_MAX if rel.TrustDelta > 0 else -self._TRUST_DELTA_MAX
                    self.patch_log.append(f"[Canonicalize] TrustDelta 夹断 {ch.CharacterId}→{key}: {rel.TrustDelta}→{clamped}")
                    rel.TrustDelta = clamped

        # ---- NewPlotPoints/SecretRevealChanges/PledgeConstraints/DeadlineConstraints 角色过滤 ----
        char_ledger_has_ids = len(char_map.id_set) > 0
        for pp in canonical.NewPlotPoints:
            pp.InvolvedCharacters = [
                self._resolve("NewPlotPoints.InvolvedCharacters", cid, char_map)
                for cid in pp.InvolvedCharacters
                if self._is_valid_id(self._resolve("NewPlotPoints.InvolvedCharacters", cid, char_map))
                and (not char_ledger_has_ids or self._resolve("NewPlotPoints.InvolvedCharacters", cid, char_map) in char_map.id_set)
            ]
        for sr in canonical.SecretRevealChanges:
            sr.NewKnowerIds = [
                self._resolve("SecretRevealChanges.NewKnowerIds", cid, char_map)
                for cid in sr.NewKnowerIds
                if self._is_valid_id(self._resolve("SecretRevealChanges.NewKnowerIds", cid, char_map))
                and (not char_ledger_has_ids or self._resolve("SecretRevealChanges.NewKnowerIds", cid, char_map) in char_map.id_set)
            ]
        for pc in canonical.PledgeConstraintChanges:
            pc.PartyIds = [
                self._resolve("PledgeConstraintChanges.PartyIds", cid, char_map)
                for cid in pc.PartyIds
                if self._is_valid_id(self._resolve("PledgeConstraintChanges.PartyIds", cid, char_map))
                and (not char_ledger_has_ids or self._resolve("PledgeConstraintChanges.PartyIds", cid, char_map) in char_map.id_set)
            ]
        for dc in canonical.DeadlineConstraintChanges:
            dc.PartyIds = [
                self._resolve("DeadlineConstraintChanges.PartyIds", cid, char_map)
                for cid in dc.PartyIds
                if self._is_valid_id(self._resolve("DeadlineConstraintChanges.PartyIds", cid, char_map))
                and (not char_ledger_has_ids or self._resolve("DeadlineConstraintChanges.PartyIds", cid, char_map) in char_map.id_set)
            ]

        # ---- StripEmpty（剔除值字段全空的预填条目） ----
        stripped = 0
        stripped += self._strip_empty(canonical.CharacterStateChanges, lambda c:
            self._blank(c.KeyEvent) and self._blank(c.NewLevel) and self._blank(c.NewMentalState)
            and (not c.NewAbilities or len(c.NewAbilities) == 0)
            and (not c.LostAbilities or len(c.LostAbilities) == 0)
            and (not c.RelationshipChanges or len(c.RelationshipChanges) == 0))
        stripped += self._strip_empty(canonical.ConflictProgress, lambda c: self._blank(c.NewStatus) and self._blank(c.Event))
        stripped += self._strip_empty(canonical.LocationStateChanges, lambda c: self._blank(c.NewStatus) and self._blank(c.Event))
        stripped += self._strip_empty(canonical.FactionStateChanges, lambda c: self._blank(c.NewStatus) and self._blank(c.Event))
        stripped += self._strip_empty(canonical.CharacterMovements, lambda c: self._blank(c.ToLocation))
        stripped += self._strip_empty(canonical.ForeshadowingActions, lambda c: self._blank(c.Action))
        stripped += self._strip_empty(canonical.NewPlotPoints, lambda c: self._blank(c.Context) and (not c.Keywords or len(c.Keywords) == 0))
        if stripped > 0:
            self.patch_log.append(f"[Canonicalize] 剔除{stripped}条值字段全空的预填条目")

        return canonical

    def is_forged(self) -> bool:
        """对标 CountForgedIds: >=5 且 >=80%"""
        return self.forged_count >= 5 and self.forged_count * 5 >= self.total_attempted * 4

    # ---- 内部方法 ----

    def _resolve(self, field: str, value, lookup: EntityMap) -> str:
        """对标 C# Resolve 方法：ShortId→括号提取→名称→去注释"""
        self.total_attempted += 1
        if not value:
            return ""
        v = str(value).strip()
        if not v:
            return ""

        if is_likely_id(v) and lookup.contains(v):
            return v

        m = re.search(r"\(([A-Z][0-9A-Za-z]{12})\)", v)
        if m:
            extracted = m.group(1)
            if lookup.contains(extracted):
                self.patch_log.append(f"[Canonicalize] {field}: 括号提取 '{v}' → '{extracted}'")
                return extracted

        by_name = lookup.name_to_id.get(v)
        if by_name:
            self.patch_log.append(f"[Canonicalize] {field}: 名称→ID '{v}' → '{by_name}'")
            return by_name

        stripped = self._strip_annotations(v)
        if stripped != v:
            by_stripped = lookup.name_to_id.get(stripped)
            if by_stripped:
                self.patch_log.append(f"[Canonicalize] {field}: 去注释→ID '{v}' → '{by_stripped}'")
                return by_stripped

        if is_likely_id(v):
            self.ambiguous_fields.append(f"{field}: '{v}' 格式正确但不在账本中（可能为伪造ID）")
            self.forged_count += 1
        else:
            self.ambiguous_fields.append(f"{field}: '{v}' 无名称匹配")
        return v

    def _resolve_or_create_location_id(
        self, id_raw: str, location_name: str, field_label: str,
        loc_map: EntityMap, new_loc_ids_by_name: dict
    ) -> str:
        """对标 C# ResolveOrCreateLocationId"""
        eid = (id_raw or "").strip()
        if self._is_valid_id(eid) and loc_map.contains(eid):
            return eid

        if location_name:
            existing_id = self._resolve(f"{field_label}.LocationName", location_name, loc_map)
            if self._is_valid_id(existing_id) and loc_map.contains(existing_id):
                if eid != existing_id:
                    self.patch_log.append(f"[Canonicalize] {field_label} 按名称命中: {location_name} → {existing_id}")
                return existing_id

        name_key = (location_name or eid or "").strip()
        if not name_key:
            return ""

        if not location_name and self._is_valid_id(eid):
            self.patch_log.append(f"[Canonicalize] {field_label} 拒绝自动生成: ID '{eid}' 为 ShortId 格式但不在账本且未提供 Name，保留原值")
            return ""

        seed_key = self._strip_annotations(name_key).strip().lower()
        if not seed_key:
            seed_key = name_key.strip().lower()

        if name_key not in new_loc_ids_by_name:
            new_id = self._new_deterministic_id("L", f"LOCATION|{seed_key}")
            new_loc_ids_by_name[name_key] = new_id
            loc_map.id_set.add(new_id)

        self.patch_log.append(f"[Canonicalize] {field_label} 自动生成: {name_key} → {new_loc_ids_by_name[name_key]}")
        self.ambiguous_fields = [a for a in self.ambiguous_fields if name_key not in a]
        return new_loc_ids_by_name[name_key]

    def _canonicalize_foreshadowing_actions(self, actions, state_map: dict):
        """对标 CanonicalizeForeshadowingActions"""
        kept = []
        for fa in actions:
            eid = (fa.ForeshadowId or "").strip()
            if not self._is_valid_id(eid) or eid not in state_map:
                kept.append(fa)
                continue
            st = state_map[eid]
            act = (fa.Action or "").lower()
            if st.IsResolved and act == "setup":
                self.patch_log.append(f"[Canonicalize] ForeshadowingActions: 剔除已揭示伏笔的 re-setup {eid}")
                continue
            if st.IsSetup and act == "setup":
                self.patch_log.append(f"[Canonicalize] ForeshadowingActions: 剔除已埋设伏笔的重复 setup {eid}")
                continue
            if not st.IsSetup and act == "payoff":
                self.patch_log.append(f"[Canonicalize] ForeshadowingActions: 剔除未埋设伏笔的 payoff {eid}")
                continue
            kept.append(fa)
        return kept

    def _canonicalize_conflict_progress(self, progresses, current_status_map: dict):
        """对标 CanonicalizeConflictProgress"""
        seq_idx = {s: i for i, s in enumerate(self._DEFAULT_CONFLICT_STATUS_SEQUENCE)}
        kept = []
        for cp in progresses:
            eid = (cp.ConflictId or "").strip()
            if not self._is_valid_id(eid) or eid not in current_status_map:
                kept.append(cp)
                continue
            cur = current_status_map[eid].lower()
            ns = (cp.NewStatus or "").strip().lower()
            if cur in seq_idx and ns in seq_idx and seq_idx[ns] < seq_idx[cur]:
                self.patch_log.append(f"[Canonicalize] ConflictProgress: 剔除状态回退 {eid} {cur}→{ns}")
                continue
            kept.append(cp)
        return kept

    def _strip_by_primary_id(self, items, get_id, list_name, known_ids=None):
        """对标 StripByPrimaryId"""
        if not items:
            return []
        kept = []
        for item in items:
            eid = (get_id(item) or "").strip()
            if not eid or not self._is_valid_id(eid):
                self.patch_log.append(f"[Canonicalize] {list_name}: 剔除主ID仍为名称的条目 '{eid}'")
            elif known_ids is not None and eid not in known_ids:
                reason = "账本无追踪记录" if not known_ids else "可能为伪造ShortId"
                self.patch_log.append(f"[Canonicalize] {list_name}: 剔除主ID不在账本中的条目 '{eid}'（{reason}）")
            else:
                kept.append(item)
        return kept

    @staticmethod
    def _strip_empty(items, is_empty):
        """对标 StripEmpty"""
        if not items:
            return 0
        before = len(items)
        items[:] = [x for x in items if not is_empty(x)]
        return before - len(items)

    @staticmethod
    def _blank(s) -> bool:
        return not s or not str(s).strip()

    @staticmethod
    def _is_valid_id(v) -> bool:
        return bool(v) and is_likely_id(v.strip())

    @staticmethod
    def _strip_annotations(v: str) -> str:
        """对标 StripAnnotations: 去除括号内容"""
        r = re.sub(r"[（(][^)）]*[)）]", "", v).strip()
        return r if r else v

    @staticmethod
    def _new_deterministic_id(prefix: str, seed: str) -> str:
        """对标 ShortIdGenerator.NewDeterministic"""
        h = hashlib.sha256(seed.encode()).hexdigest()[:12]
        return prefix + h.upper()

    def _build_map(self, kind: str) -> EntityMap:
        """构建实体映射表"""
        em = EntityMap()
        s = self.snapshot
        if kind == "char":
            for e in s.CharacterStates:
                em.add(e.CharacterId, e.Name)
            for e in s.CharacterDescriptions:
                em.add(e.CharacterId, e.Name)
            for cl in s.CharacterLocations:
                if cl.CharacterId:
                    em.add(cl.CharacterId, cl.CharacterName)
        elif kind == "loc":
            for e in s.LocationStates:
                em.add(e.LocationId, e.Name)
            for e in s.LocationDescriptions:
                em.add(e.LocationId, e.Name)
            for cl in s.CharacterLocations:
                if cl.CurrentLocation:
                    em.add(cl.CurrentLocation, None)
        elif kind == "faction":
            for e in s.FactionStates:
                em.add(e.FactionId, e.Name)
        elif kind == "item":
            for e in s.ItemStates:
                em.add(e.ItemId, e.Name)
        elif kind == "conflict":
            for e in s.ConflictProgress:
                em.add(e.ConflictId, e.Name)
        elif kind == "foreshadow":
            for e in s.ForeshadowingStatus:
                em.add(e.ForeshadowId, e.Name)
        elif kind == "secret":
            for e in s.SecretStates:
                em.add(e.SecretId, e.Name)
        elif kind == "pledge":
            for e in s.PledgeStates:
                em.add(e.PledgeId, e.Name)
        elif kind == "deadline":
            for e in s.DeadlineStates:
                em.add(e.DeadlineId, e.Name)
        return em

    def _build_char_current_loc_map(self) -> dict:
        d = {}
        for cl in self.snapshot.CharacterLocations:
            if cl.CharacterId and cl.CurrentLocation:
                d.setdefault(cl.CharacterId, cl.CurrentLocation)
        return d

    def _build_item_current_holder_map(self) -> dict:
        d = {}
        for item in self.snapshot.ItemStates:
            if item.ItemId and item.CurrentHolder:
                d.setdefault(item.ItemId, item.CurrentHolder)
        return d

    def _build_foreshadow_state_map(self) -> dict:
        d = {}
        for f in self.snapshot.ForeshadowingStatus:
            if f.ForeshadowId:
                d[f.ForeshadowId] = f
        return d

    def _build_conflict_current_status_map(self) -> dict:
        d = {}
        for c in self.snapshot.ConflictProgress:
            if c.ConflictId and c.Status:
                d[c.ConflictId] = c.Status
        return d