# -*- coding: utf-8 -*-
"""AI填充词规则 — 对标 HumanizeRules.AiFillers.cs

提供 AI_FILLER_PHRASES: 需要移除的 AI 填充词列表。
"""
from ....humanize import AI_FILLER_PHRASES as AI_FILLER_PHRASES

__all__ = ["AI_FILLER_PHRASES"]