# -*- coding: utf-8 -*-
"""引号规则 — 对标 HumanizeRules.Quotes.cs

当前 humanize.py 中无独立引号数据，保留为占位模块。
"""
# 暂无独立数据，所有引号处理在 humanize.py 的标点归一化中完成
__all__ = []