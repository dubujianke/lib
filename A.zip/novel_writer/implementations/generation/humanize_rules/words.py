# -*- coding: utf-8 -*-
"""单词替换规则 — 对标 HumanizeRules.Words.cs

提供 WORD_REPLACEMENTS: 单词级替换字典。
"""
from ....humanize import WORD_REPLACEMENTS as WORD_REPLACEMENTS

__all__ = ["WORD_REPLACEMENTS"]