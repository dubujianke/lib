# -*- coding: utf-8 -*-
"""HumanizeRules 主入口 — 对标 HumanizeRules.cs

提供 HumanizeRules 类，包含 AI 味替换 + 语义守卫。
"""
from ....humanize import HumanizeRules

__all__ = ["HumanizeRules"]