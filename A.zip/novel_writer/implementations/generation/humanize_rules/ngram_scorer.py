# -*- coding: utf-8 -*-
"""中文 N-gram 困惑度评分 — 对标 HumanizeRules/NGramScorer.cs

使用内嵌 NGramFreqCn.json（unigrams/bigrams/trigrams）计算 PPL，
用于候选词选取的首次粗筛。
"""
import json
import math
import os

_RESOURCE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "NGramFreqCn.json")

_UNIGRAMS = {}
_BIGRAMS = {}
_TRIGRAMS = {}
_VOCAB_SIZE = 1

_SMOOTHING_K = 0.01
_TRIGRAM_LAMBDA = 0.6
_UNSEEN_FLOOR = -20.0

_CHINESE_CHAR_LOW = 0x4E00
_CHINESE_CHAR_HIGH = 0x9FFF


def _load():
    global _UNIGRAMS, _BIGRAMS, _TRIGRAMS, _VOCAB_SIZE
    try:
        with open(_RESOURCE_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        _UNIGRAMS = data.get("unigrams", {})
        _BIGRAMS = data.get("bigrams", {})
        _TRIGRAMS = data.get("trigrams", {})
        _VOCAB_SIZE = max(len(_UNIGRAMS), 1000)
    except Exception:
        _UNIGRAMS = _BIGRAMS = _TRIGRAMS = {}
        _VOCAB_SIZE = 1000


_load()


def _extract_chinese(text):
    chars = []
    for ch in text:
        if ord(ch) >= _CHINESE_CHAR_LOW and ord(ch) <= _CHINESE_CHAR_HIGH:
            chars.append(ch)
    return chars


def _bigram_log_prob(c1, c2):
    bi_key = c1 + c2
    uni_key = c1
    bi_count = _BIGRAMS.get(bi_key, 0)
    uni_count = _UNIGRAMS.get(uni_key, 0)
    prob = (bi_count + _SMOOTHING_K) / (uni_count + _SMOOTHING_K * _VOCAB_SIZE)
    return math.log2(prob) if prob > 0 else _UNSEEN_FLOOR


def _trigram_log_prob(c1, c2, c3):
    tri_key = c1 + c2 + c3
    bi_ctx_key = c1 + c2
    tri_count = _TRIGRAMS.get(tri_key, 0)
    bi_ctx_count = _BIGRAMS.get(bi_ctx_key, 0)
    p_tri = (tri_count + _SMOOTHING_K) / (bi_ctx_count + _SMOOTHING_K * _VOCAB_SIZE)

    p_bi_log = _bigram_log_prob(c2, c3)
    p_bi = math.pow(2, p_bi_log)

    p_interp = _TRIGRAM_LAMBDA * p_tri + (1 - _TRIGRAM_LAMBDA) * p_bi
    return math.log2(p_interp) if p_interp > 0 else _UNSEEN_FLOOR


def ComputePerplexity(text) -> float:
    """对标 ComputePerplexity(ReadOnlySpan<char>)"""
    chars = _extract_chinese(text or "")
    if len(chars) < 5:
        return 0.0

    sum_log_prob = 0.0
    count = 0
    for i in range(2, len(chars)):
        sum_log_prob += _trigram_log_prob(chars[i - 2], chars[i - 1], chars[i])
        count += 1

    if count == 0:
        return 0.0
    avg_lp = sum_log_prob / count
    return math.pow(2, -avg_lp)


class NGramScorer:
    """对标 NGramScorer 静态类"""

    @staticmethod
    def ComputePerplexity(text: str) -> float:
        return ComputePerplexity(text)