# -*- coding: utf-8 -*-
"""短语替换规则 — 对标 HumanizeRules.Phrases.cs

提供:
  - PHRASE_REPLACEMENTS: 普通短语替换字典
  - FORCED_PHRASE_REPLACEMENTS: 强制短语替换字典
"""
from ....humanize import (
    PHRASE_REPLACEMENTS as PHRASE_REPLACEMENTS,
    FORCED_PHRASE_REPLACEMENTS as FORCED_PHRASE_REPLACEMENTS,
)

__all__ = ["PHRASE_REPLACEMENTS", "FORCED_PHRASE_REPLACEMENTS"]