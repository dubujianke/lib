# -*- coding: utf-8 -*-
"""数字汉化规则 — 对标 HumanizeRules.Digits.cs

提供:
  - _apply_digit_normalization: 将阿拉伯数字转为中文数字
  - DIGIT_TO_CHINESE / CHINESE_DECADE_MAP: 数字映射表
  - DIGIT_YEAR_4_REGEX / DIGIT_MONTH_REGEX / DIGIT_DAY_REGEX: 正则
"""
from ....humanize import (
    _apply_digit_normalization as normalize_digits,
    DIGIT_TO_CHINESE as DIGIT_TO_CHINESE,
    CHINESE_DECADE_MAP as CHINESE_DECADE_MAP,
    DIGIT_YEAR_4_REGEX as DIGIT_YEAR_4_REGEX,
    DIGIT_YEAR_DECADE_REGEX as DIGIT_YEAR_DECADE_REGEX,
    DIGIT_MONTH_REGEX as DIGIT_MONTH_REGEX,
    DIGIT_DAY_REGEX as DIGIT_DAY_REGEX,
)

__all__ = [
    "normalize_digits",
    "DIGIT_TO_CHINESE",
    "CHINESE_DECADE_MAP",
    "DIGIT_YEAR_4_REGEX",
    "DIGIT_YEAR_DECADE_REGEX",
    "DIGIT_MONTH_REGEX",
    "DIGIT_DAY_REGEX",
]