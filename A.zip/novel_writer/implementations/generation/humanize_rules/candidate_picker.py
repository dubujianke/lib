# -*- coding: utf-8 -*-
"""候选词选取 — 对标 HumanizeRules/CandidatePicker.cs

流程：N-gram 困惑度粗筛 → 高风险词用 MLM 精选 → 语义守门（可选，需 SemanticGuard/Embedding）
"""
import math
from contextlib import contextmanager

from .high_risk_words import HighRiskWords
from .ngram_scorer import ComputePerplexity


class PickerOptions:
    """对标 PickerOptions"""
    def __init__(self, guard_window_chars: int = 50, guard_cosine_threshold: float = 0.85):
        self.GuardWindowChars = guard_window_chars
        self.GuardCosineThreshold = guard_cosine_threshold


class PickerScorers:
    """对标 PickerScorers"""
    def __init__(self, mlm=None, guard=None, options=None):
        self.Mlm = mlm
        self.Guard = guard
        self.Options = options or PickerOptions()


def _compute_ngram_scored(text: str, anchor_idx: int, key: str, avail):
    prefix = text[:anchor_idx]
    suffix = text[anchor_idx + len(key):]
    scored = []
    for cand in avail:
        new_text = prefix + cand + suffix
        scored.append([cand, ComputePerplexity(new_text)])
    return scored


def _pick_with_mlm(text, anchor_idx, key, top2, ngram_best, scorers):
    mlm = (scorers or {}).Mlm if scorers else None
    if mlm is None or not getattr(mlm, "available", False):
        return ngram_best
    try:
        mlm_scores = mlm.score_candidates(text, anchor_idx, key, top2)
        if not mlm_scores or len(mlm_scores) != len(top2):
            return ngram_best
        best_idx = 0
        best_score = mlm_scores[0]
        for i in range(1, len(mlm_scores)):
            if mlm_scores[i] > best_score:
                best_score = mlm_scores[i]
                best_idx = i
        return top2[best_idx]
    except Exception:
        return ngram_best


def PickBestAsync(text: str, anchor_idx: int, key: str, avail, scorers=None, ct=None):
    """对标 CandidatePicker.PickBestAsync"""
    if not avail:
        return key
    if len(avail) == 1:
        return avail[0]

    scored = _compute_ngram_scored(text, anchor_idx, key, avail)
    scored.sort(key=lambda s: s[1])

    ngram_best = scored[-1][0] if len(scored) <= 2 else scored[-2][0]

    if not HighRiskWords.IsHighRisk(key):
        return ngram_best

    if len(scored) <= 2:
        top2 = [scored[0][0], scored[1][0]]
    else:
        top2 = [scored[-2][0], scored[-1][0]]

    chosen = _pick_with_mlm(text, anchor_idx, key, top2, ngram_best, scorers)

    guard = (scorers or {}).Guard if scorers else None
    if guard is not None and getattr(guard, "IsReady", False):
        try:
            opts = ((scorers or {}).Options) if scorers else None
            window = (opts or PickerOptions()).GuardWindowChars
            threshold = (opts or PickerOptions()).GuardCosineThreshold
            cos = guard.ComputeLocalCosine(text, anchor_idx, key, chosen, window)
            if cos < threshold:
                return key
        except Exception:
            pass

    return chosen


class CandidatePicker:
    """对标 CandidatePicker 静态类"""
    @staticmethod
    def PickBest(text, anchor_idx, key, avail, scorers=None):
        return PickBestAsync(text, anchor_idx, key, avail, scorers)