# -*- coding: utf-8 -*-
"""小说口语规则 — 对标 HumanizeRules.NovelOral.cs

提供:
  - NOVEL_ORAL_PHRASES: 短语级口语化替换字典
  - NOVEL_ORAL_WORDS: 单词级口语化替换字典
"""
from ....humanize import (
    NOVEL_ORAL_PHRASES as NOVEL_ORAL_PHRASES,
    NOVEL_ORAL_WORDS as NOVEL_ORAL_WORDS,
)

__all__ = ["NOVEL_ORAL_PHRASES", "NOVEL_ORAL_WORDS"]