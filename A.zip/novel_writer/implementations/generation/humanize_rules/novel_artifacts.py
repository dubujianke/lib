# -*- coding: utf-8 -*-
"""小说伪影规则 — 对标 HumanizeRules.NovelArtifacts.cs

提供:
  - NOVEL_ARTIFACT_REGEXES: 匹配小说生成痕迹的正则列表
  - _remove_paragraphs_matching: 按正则移除匹配段落
"""
from ....humanize import (
    NOVEL_ARTIFACT_REGEXES as NOVEL_ARTIFACT_REGEXES,
    _remove_paragraphs_matching as remove_artifact_paragraphs,
)

__all__ = ["NOVEL_ARTIFACT_REGEXES", "remove_artifact_paragraphs"]