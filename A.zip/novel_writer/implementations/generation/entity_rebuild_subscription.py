# -*- coding: utf-8 -*-
"""实体重建订阅 — 对标 Implementations/Generation/EntityRebuildSubscription.cs"""
import threading


class EntityRebuildSubscription:
    def __init__(self, guide_manager=None, first_chapter_index=None):
        self.guide_manager = guide_manager
        self.first_chapter_index = first_chapter_index
        self._entity_locks = {}

    def on_entry_changed(self, entity_id: str, entity_name: str, entity_description: str):
        if not entity_id:
            return
        sem = self._entity_locks.setdefault(entity_id, threading.Semaphore(1))
        with sem:
            try:
                if self.first_chapter_index is None:
                    return
                self.first_chapter_index.load()
                if not self.first_chapter_index.contains(entity_id):
                    return
                self.first_chapter_index.invalidate_by_entities([entity_id])
                self.first_chapter_index.save()
            except Exception:
                pass
