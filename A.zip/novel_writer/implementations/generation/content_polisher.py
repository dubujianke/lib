# -*- coding: utf-8 -*-
"""对标 4.1.1 ContentPolisher: AI 润色 + 门禁重验"""
import re
from ...prompt_builder import split_content_and_changes

POLISH_SYSTEM = """<role>你是文学润色专家。核心任务：**严格按 <polish_rules> 中的技巧对中文小说正文进行风格润色**，让语言更自然流畅、更贴近人类写作习惯。</role>

<polish_rules priority="primary">

### 1. 增加冗余与解释性
将简洁的动词或动词短语替换为更长的、带有动作过程描述的短语。
-   "管理" → "开展...的管理工作" 或 "进行管理"
-   "交互" → "进行交互" 或 "开展交互"
-   "配置" → "进行配置"
-   "处理" → "去处理...工作"
-   "恢复" → "进行恢复"
-   "实现" → "得以实现" 或 "来实现"
-   "分析" → "对…进行分析"
-   "验证" → "开展相关的验证工作"

在句子中添加语法上允许但非必需的词语，使句子更饱满。
-   适当增加 "了"、"的"、"地"、"所"、"会"、"可以"、"这个"、"方面"、"当中" 等。
-   "提供功能" → "有...功能" 或 "拥有...的功能"

### 4. 括号内容处理
对于原文中用于解释、举例或说明缩写的括号 `(...)` 或 `（...）`：
-   **优先整合:** 尝试将括号内的信息自然地融入句子，使用 "也就是"、"即"、"比如"、"像" 等引导词。
    -   示例：`ORM（对象关系映射）` → `对象关系映射即ORM` 或 `ORM也就是对象关系映射`
    -   示例：`功能（如ORM、Admin）` → `功能，比如ORM、Admin` 或 `功能，像ORM、Admin等`
-   **谨慎省略:** 如果整合后语句极其冗长或别扭，并且括号内容并非核心关键信息，可以考虑省略。

-   示例：`视图 (views.py) 中` → `视图文件views.py中`
-   示例：`权限类 (admin_panel.permissions)` → `权限类 admin_panel.permissions`

### 5. "把"字句 + "给"字结构高频化
凡有动作对象的句子，优先重写为 "把…给…" 结构。
-   "他拉下电闸" → "他去把电闸给拉了下来"
-   "锁上门" → "把门给锁上了"
-   "掏出手机" → "把手机给掏了出来"
-   "撕下一张报纸" → "把其中一张给撕了下来"
-   "打开所有的灯" → "把所有的灯都给打开了"

### 6. 虚词、副词、语气词的自然堆叠
让句子从"精炼"变"啰嗦"，但节奏受控：
-   连接词：增加 "就"、"都"、"倒"、"还"、"也"、"可"
-   时态词：句末补 "了"，如 "已经发黄" → "已经发黄了"
-   语气词：句末加 "罢了"、"呢"、"嘛"，如 "运气好" → "纯粹是运气好罢了"
-   指示词：增加 "那个"、"那些"、"这个"，如 "老妇人" → "那个老妇人"
-   补语词："下来"、"起来"、"出来"、"过去"，如 "亮了" → "亮了起来"
-   程度词："有"、"有点"、"差不多"、"左右"，如 "几秒" → "有几秒钟"

### 7. 重复强调的节奏控制
将单次描述改为重复强调，模拟反复斟酌感。**不可以滥用，在关键场景增加重量**：
-   选择最有情绪强度的词做重复，避免每段都用
-   示例："他点点头"、"她笑了笑"、"沉默了沉默"
-   示例："黑乎乎的" → "黑乎乎的一片"

### 8. 句子拆短 + 心理代偿短语
将 "短促 + 信息密度高" 重写为 "稍长 + 信息密度低"，加入心理代偿性短语：
-   "告诉自己那是老鼠" → "在心底里头跟自己说那准是老鼠"
-   "他知道她在笑" → "可他心里头清楚得很，她一定在笑"
-   "决定先去主卧" → "就决定先去二楼主卧那边把行李给整理一下"
-   "他认为" → "他还觉得" / "他心里头不这么认为了"

### 9. 句式微调与自然化
-   **使用"把"字句:** 在合适的场景下，倾向于使用"把"字句。
    -   示例："会将对象移动" → "会把这个对象移动"
-   **条件句式转换:** 将较书面的条件句式改为稍口语化的形式。
    -   示例："若…，则…" → "要是...，那就..." 或 "如果...，就..."
-   **结构切换:** 进行名词化与动词化结构的相互转换。
    -   示例："为了将…解耦" → "为了实现...的解耦"
-   **增加连接词:** 在句首或句中适时添加"那么"、"这样一来"、"同时"等词。
---
以上只是基本举例，如果文章中有和以上例子相似的，也要根据例子灵活修改

</polish_rules>

<strict_rules>
1. 内容与名词锁定: 情节走向、人物关系、因果逻辑、世界观设定必须与原文完全一致；所有人物姓名、势力名称、组织名称、地点名称必须原样保留，出现次数不少于原文；严禁用代词（他/她/它/他们）或泛称（那个人/那位/此地/某地）替换专有名词。
2. 人称保持: 保持原文的叙事人称不变（原文是第一人称就保持第一人称，第三人称同理）。
3. 字数控制: 修改后的总字数{WORD_COUNT_HINT}必须与原文保持一致，偏差不超过 ±5%。<polish_rules> 中的技巧优先用于「替换」原表达，而不是「叠加」在原文上。
4. 输出约束: 维持原文段落划分不变，不遗漏任何段落或情节；只输出修改后的完整正文，不附加任何解释、注释或标签。
</strict_rules>"""


class ContentPolisher:
    """对标 4.1.1 ContentPolisher: 分离正文→AI润色→合并CHANGES→重验"""

    def __init__(self, ai_client):
        self.ai = ai_client

    def polish(self, raw_content: str, polish_model: int = 0, verbose: bool = True) -> tuple:
        """润色正文。对标: 本地正则降AI → 分离CHANGES → AI润色 → 合并 → 返回

        polish_model: 0=local-only（跳过AI调用，直接返回预润色结果）, 1=AI润色
        """
        # 分离正文和 CHANGES
        separator_idx = _find_changes_start(raw_content)
        if separator_idx < 0:
            content_part = raw_content.strip()
            changes_part = ""
        else:
            content_part = raw_content[:separator_idx].strip()
            changes_part = raw_content[separator_idx:]

        # 对标 ApplyPreLLMAsync: 本地 MLM 仿人化
        pre_len = len(content_part.replace("\n", "").replace(" ", ""))
        try:
            from ...humanize import HumanizeRules
            h = HumanizeRules()
            content_part = h.humanize(content_part, max_replaces=15)
        except Exception:
            pass

        if len(content_part.replace("\n", "").replace(" ", "")) < 50:
            return raw_content, content_part, True  # 太短不润

        # 本地模式：跳过 AI 调用，直接返回预润色结果
        if polish_model == 0:
            if changes_part:
                full = content_part + "\n\n" + changes_part
            else:
                full = content_part
            return full, content_part, True

        wc = len(content_part.replace("\n", "").replace(" ", ""))
        word_hint = f"（约 {wc} 字）"
        prompt = POLISH_SYSTEM.replace("{WORD_COUNT_HINT}", word_hint)
        prompt += f"\n\n<source_text>\n{content_part}\n</source_text>"

        if verbose:
            print(f"    [润色] AI 润色中...")
        polished_text = ""
        # 对标超时降级 + 字数超限重试
        for attempt in range(2):
            try:
                polished_text = self.ai.chat(prompt, "", category="润色")
            except Exception:
                if verbose:
                    print(f"    [润色] 第{attempt+1}次调用失败，降级使用本地处理")
                break
            polished_text = polished_text.strip()
            new_wc_check = len(polished_text.replace("\n", "").replace(" ", ""))
            # 字数超限重试（偏差 > 50% 时重试一次）
            if new_wc_check > wc * 1.5 and attempt == 0:
                if verbose:
                    print(f"    [润色] 字数超限({wc}→{new_wc_check})，重试...")
                prompt = prompt + f"\n\n注意：字数不要超过 {wc} 字，保持紧凑。"
                continue
            break
        if not polished_text:
            return raw_content, content_part, False
        # 清洗残留的 XML 标签
        polished_text = re.sub(r"</?source_text>", "", polished_text).strip()
        polished_text = re.sub(r"</?polish_rules>", "", polished_text).strip()

        # 对标 ApplyPostLLMAsync: 润后正则（数字汉化、强制替换、AI填充词移除、标点归一化、空行折叠）
        try:
            from ...humanize import HumanizeRules
            h = HumanizeRules()
            polished_text = h.apply_post_llm(polished_text)
        except Exception:
            pass

        # 字数检查：偏差 > 20% 视为失败
        new_wc = len(polished_text.replace("\n", "").replace(" ", ""))
        if wc > 100 and (new_wc < wc * 0.5 or new_wc > wc * 1.5):
            if verbose:
                print(f"    [润色] 字数偏差过大({wc}→{new_wc})，使用原文")
            return raw_content, content_part, False

        # 合并 CHANGES
        if changes_part:
            full = polished_text + "\n\n" + changes_part
        else:
            full = polished_text

        if verbose:
            print(f"    [润色] 完成 ({wc}→{new_wc} 字)")
        return full, polished_text, True


def _find_changes_start(text: str) -> int:
    """找 CHANGES 区域起始位置"""
    # XML 标签
    idx = text.find("<chapter_changes>")
    if idx != -1:
        return idx
    # ---CHANGES---
    idx = text.find("---CHANGES---")
    if idx != -1:
        return idx
    return -1