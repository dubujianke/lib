# -*- coding: utf-8 -*-
"""生成统计服务 — 对标 Implementations/Generation/GenerationStatisticsService.cs"""
import json
import os
import threading
from typing import List

from ...models.tracking.generation_statistics import (
    GenerationStatistics, ConsistencyIssueStatistics, GenerationRecord, AttemptRecord,
)


class GenerationStatisticsService:
    MAX_RECENT_RECORDS = 100

    def __init__(self, project):
        self.project = project
        self._statistics = GenerationStatistics()
        self._recent_records: List[GenerationRecord] = []
        self._statistics_lock = threading.Lock()
        self._records_lock = threading.Lock()
        self._save_lock = threading.Lock()
        self._load_statistics()

    def record_generation(self, result):
        rewrite_count = result.total_attempts - 1
        record = GenerationRecord(
            ChapterId=result.ChapterId, Success=result.Success,
            TotalAttempts=result.total_attempts, RewriteCount=rewrite_count,
            RequiresManualIntervention=result.RequiresManualIntervention,
            FailureReasons=result.get_last_failure_reasons())
        for attempt in result.Attempts:
            ar = AttemptRecord(AttemptNumber=attempt.AttemptNumber, Success=attempt.Success,
                               FailureReasons=attempt.FailureReasons)
            if not attempt.Success and attempt.FailureReasons:
                first = attempt.FailureReasons[0] or ""
                if "[Protocol]" in first:
                    ar.FailureType = "Protocol"
                elif "[Consistency]" in first:
                    ar.FailureType = "Consistency"
                if ar.FailureType:
                    record.FailureStages.append(f"Attempt{attempt.AttemptNumber}:{ar.FailureType}")
            record.Attempts.append(ar)

        with self._statistics_lock:
            self._statistics.TotalGenerations += 1
            if result.Success:
                if result.total_attempts == 1:
                    self._statistics.FirstPassCount += 1
                else:
                    self._statistics.RewritePassCount += 1
            elif result.RequiresManualIntervention:
                self._statistics.FinalFailureCount += 1
            self._statistics.RewriteDistribution[rewrite_count] = \
                self._statistics.RewriteDistribution.get(rewrite_count, 0) + 1
            for attempt in result.Attempts:
                if not attempt.Success and attempt.FailureReasons:
                    first = attempt.FailureReasons[0] or ""
                    if "[Protocol]" in first:
                        self._statistics.ProtocolFailureCount += 1
                    elif "[Consistency]" in first:
                        self._statistics.ConsistencyFailureCount += 1

        with self._records_lock:
            self._recent_records.append(record)
            if len(self._recent_records) > self.MAX_RECENT_RECORDS:
                self._recent_records = self._recent_records[-self.MAX_RECENT_RECORDS:]

        self._save_statistics()

    def record_consistency_issue(self, issue_type: str):
        with self._statistics_lock:
            stats = self._statistics.ConsistencyIssues
            if issue_type == "CharacterStateConflict":
                stats.CharacterStateConflict += 1
            elif issue_type in ("ForeshadowingEarlyPayoff", "PayoffBeforeSetup"):
                stats.ForeshadowingEarlyPayoff += 1
            elif issue_type == "ForeshadowingRollback":
                stats.ForeshadowingRollback += 1
            elif issue_type == "ConflictStatusSkip":
                stats.ConflictStatusSkip += 1
            elif issue_type == "CharacterNotInvolved":
                stats.CharacterNotInvolved += 1

    def parse_consistency_issues(self, reasons: List[str]):
        """对标 ParseConsistencyIssues：从失败原因文本统计各一致性问题"""
        if not reasons:
            return
        with self._statistics_lock:
            stats = self._statistics.ConsistencyIssues
            for reason in reasons:
                reason = reason or ""
                if "PayoffBeforeSetup" in reason or "提前揭示" in reason:
                    stats.ForeshadowingEarlyPayoff += 1
                elif "ForeshadowingRollback" in reason or "回退" in reason:
                    stats.ForeshadowingRollback += 1
                elif "ConflictStatusSkip" in reason or "跳级" in reason:
                    stats.ConflictStatusSkip += 1
                elif "CharacterNotInvolved" in reason or "未登记" in reason:
                    stats.CharacterNotInvolved += 1
                elif "CharacterState" in reason or "角色状态" in reason:
                    stats.CharacterStateConflict += 1

    def get_statistics(self) -> GenerationStatistics:
        with self._statistics_lock:
            return self._statistics

    def get_recent_records(self, count: int = 10) -> List[GenerationRecord]:
        with self._records_lock:
            return self._recent_records[-count:]

    def get_statistics_summary(self) -> str:
        s = self.get_statistics()
        return (f"生成统计: 总数={s.TotalGenerations}, 首次通过={s.FirstPassCount}({s.first_pass_rate:.1f}%), "
                f"重写通过={s.RewritePassCount}, 最终失败={s.FinalFailureCount}, "
                f"协议失败={s.ProtocolFailureCount}, 一致性失败={s.ConsistencyFailureCount}")

    def _file_path(self) -> str:
        return os.path.join(self.project.dir, "generation_statistics.json")

    def get_statistics_file_path(self) -> str:
        """对标 GetStatisticsFilePath"""
        return self._file_path()

    def _load_statistics(self):
        try:
            path = self._file_path()
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                from ...models.tracking.generation_statistics import GenerationStatistics as GS
                with self._statistics_lock:
                    self._statistics = GS.from_dict(data)
        except Exception:
            pass

    def _save_statistics(self):
        try:
            path = self._file_path()
            tmp = path + ".tmp"
            with self._statistics_lock:
                data = self._statistics.to_dict()
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, path)
        except Exception:
            pass
