# -*- coding: utf-8 -*-
"""全局摘要服务 — 对标 Implementations/Summary/GlobalSummaryService.cs"""
import threading
import time
from typing import Optional

from ...models.context.global_summary import GlobalSummary, ProgressInfo
from ...models.index.index_item import IndexItem


class GlobalSummaryService:
    CACHE_EXPIRY_SECONDS = 300

    def __init__(self, project):
        self.project = project
        self._cached_summary: Optional[GlobalSummary] = None
        self._cache_time = 0.0

    def get_global_summary(self) -> GlobalSummary:
        if self._cached_summary is not None and time.time() - self._cache_time < self.CACHE_EXPIRY_SECONDS:
            return self._cached_summary
        computed = self.compute_realtime()
        self._cached_summary = computed
        self._cache_time = time.time()
        return computed

    def compute_realtime(self) -> GlobalSummary:
        summary = GlobalSummary()
        try:
            self._extract_core_rules(summary)
            self._extract_core_factions(summary)
            self._extract_story_summary(summary)
            self._extract_main_conflict(summary)
            self._extract_used_elements(summary)
            self._extract_progress_info(summary)
        except Exception:
            pass
        return summary

    def invalidate_cache(self):
        self._cached_summary = None
        self._cache_time = 0.0

    # ---- 抽取 ----

    def _load_design(self, entity: str) -> list:
        data = self.project.load_design(entity)
        if isinstance(data, dict):
            return data.get("items", [])
        return data or []

    def _extract_core_rules(self, summary: GlobalSummary):
        rules = self._load_design("world")
        summary.CoreRules = [
            IndexItem(Id=r.get("Id", ""), Name=r.get("Name", ""), Type=r.get("Category", ""),
                      BriefSummary=f"{r.get('Name', '')}({r.get('Category', '')})",
                      DeepSummary=self._truncate(r.get("OneLineSummary", ""), 80))
            for r in rules if r.get("IsEnabled", True) and r.get("Id")
        ]

    def _extract_core_factions(self, summary: GlobalSummary):
        factions = self._load_design("factions")
        summary.CoreFactions = [
            IndexItem(Id=f.get("Id", ""), Name=f.get("Name", ""), Type=f.get("FactionType", ""),
                      BriefSummary=f"{f.get('Name', '')}({f.get('FactionType', '')})",
                      DeepSummary=self._truncate(" ".join([f.get("Goal", ""), f.get("Leader", "")]), 80))
            for f in factions if f.get("IsEnabled", True) and f.get("Id")
        ]

    def _extract_story_summary(self, summary: GlobalSummary):
        outlines = self._load_plan("outline")
        outline = None
        for o in outlines:
            if o.get("IsEnabled", True):
                outline = o
                break
        text = outline.get("OneLineOutline", "") if outline else ""
        if text:
            summary.StorySummary = self._truncate(text, 100)
            return
        plot_rules = self._load_design("plot")
        item = next((p for p in plot_rules if p.get("IsEnabled", True)), None)
        if item:
            brief = item.get("OneLineSummary") or item.get("Goal") or item.get("Conflict") or ""
            if brief:
                summary.StorySummary = f"{item.get('Name', '')}：{self._truncate(brief, 100)}"

    def _extract_main_conflict(self, summary: GlobalSummary):
        plot_rules = self._load_design("plot")
        conflict = next((p for p in plot_rules if p.get("IsEnabled", True) and p.get("Conflict")), None)
        if conflict:
            summary.MainConflict = f"{conflict.get('Name', '')}：{self._truncate(conflict.get('Conflict', ''), 80)}"

    def _extract_used_elements(self, summary: GlobalSummary):
        plot_rules = self._load_design("plot")
        summary.UsedElements.UsedPlotPatterns = list({
            p.get("EventType", "") for p in plot_rules if p.get("EventType")})[:20]
        chars = self._load_design("characters")
        summary.UsedElements.UsedAbilities = list({
            self._truncate(a, 20) for c in chars
            for a in (c.get("SpecialAbilities") or []) if a})[:20]

    def _extract_progress_info(self, summary: GlobalSummary):
        chapters = self._load_plan("chapters")
        summary.Progress.TotalChapters = len(chapters)
        summary.Progress.CurrentPhase = "Design"

    def _load_plan(self, entity: str) -> list:
        data = self.project.load_plan(entity)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return data.get(entity, data.get("items", []))
        return []

    @staticmethod
    def _truncate(text: str, max_length: int) -> str:
        if not text:
            return ""
        return text if len(text) <= max_length else text[:max_length] + "..."

    @staticmethod
    def _get_json_string(d: dict, key: str) -> str:
        value = d.get(key)
        return value if isinstance(value, str) else ""
