# -*- coding: utf-8 -*-
"""伏笔状态服务 — 对标 4.1.1 ForeshadowingStatusService.cs（完整移植 215 行）

对齐功能:
- MarkAsSetupAsync / MarkAsResolvedAsync（自动注册 + 状态标记）
- RefreshOverdueStatusAsync（按章节ID比较判定逾期）
- GetStatisticsAsync（总览统计 + 分 Tier 统计）
- GetOverdueForeshadowingsAsync（逾期列表按预期回收章排序）
- RemoveChapterDataAsync（回退章节 + 重算逾期）
- GetLatestExistingChapterId（从已生成章节文件取最新章）
"""

import os
from typing import Dict, List, Optional

from .character_state_service import compare_chapter_id, parse_chapter_id

# 对标 C# ForeshadowingStatusGuide
GUIDE_FILE = "foreshadowing_status_guide.json"


class ForeshadowingStatusService:
    """对标 4.1.1 ForeshadowingStatusService — 伏笔状态管理（独立类）

    调用链与 C# 完全一致（单文件 GuideFileName，不分卷）：
    - 读: GuideManager.GetGuideAsync<ForeshadowingStatusGuide>(GuideFileName)
    - 写: GuideManager.MarkDirty(GuideFileName)
    """

    GuideFileName = GUIDE_FILE
    GUIDE_FIELD = "Foreshadowings"

    def __init__(self, project, tracking_manager=None, guide_manager=None):
        self.project = project
        self.tracking = tracking_manager
        self._store = None
        # 对标 C# _guideManager（未提供时延迟创建）
        self._guide_manager = guide_manager

    def _get_guide_manager(self):
        if self._guide_manager is None:
            try:
                from ..guides.guide_manager import GuideManager
                self._guide_manager = GuideManager(self.project)
            except Exception:
                return None
        return self._guide_manager

    def _get_store(self):
        if self._store is None:
            if self.tracking is not None:
                self._store = self.tracking._stores["foreshadowing"]
            else:
                self._store = self.project.tracking("foreshadowing")
        return self._store

    # ---- 辅助 ----

    @staticmethod
    def _get_latest_existing_chapter_id(project) -> str:
        """对标 GetLatestExistingChapterId: 从章节规划取最新章 ID（volX_chY）"""
        try:
            chapters = project.load_plan("chapters")
            chapters_list = chapters.get("chapters", []) if isinstance(chapters, dict) else (chapters or [])
            if not chapters_list:
                return ""
            latest_key = (0, 0)
            for c in chapters_list:
                if not isinstance(c, dict):
                    continue
                vn = int(c.get("VolumeNumber", 0) or 0)
                cn = int(c.get("ChapterNumber", 0) or 0)
                if (vn, cn) > latest_key:
                    latest_key = (vn, cn)
            if latest_key == (0, 0):
                return ""
            return f"vol{latest_key[0]}_ch{latest_key[1]}"
        except Exception:
            return ""

    @staticmethod
    def get_latest_existing_chapter_id_from_files(project) -> str:
        """对标 C# GetLatestExistingChapterId: 从已生成章节 .md 文件取最新章 ID"""
        try:
            chapters_path = os.path.join(project.dir, "chapters")
            if not os.path.isdir(chapters_path):
                return ""
            files = [f for f in os.listdir(chapters_path) if f.endswith(".md")]
            if not files:
                return ""
            latest = ""
            for f in files:
                fid = os.path.splitext(f)[0]
                if not fid:
                    continue
                if not latest or compare_chapter_id(fid, latest) > 0:
                    latest = fid
            return latest
        except Exception:
            return ""

    # ---- 标记 ----

    def mark_as_setup(self, foreshadow_id: str, chapter_id: str):
        """对标 MarkAsSetupAsync"""
        store = self._get_store()
        data = store.data()
        if foreshadow_id not in data or not isinstance(data[foreshadow_id], dict):
            data[foreshadow_id] = {
                "Name": foreshadow_id, "Tier": "Tier-3", "IsSetup": False, "IsResolved": False,
                "IsOverdue": False, "ExpectedSetupChapter": "", "ExpectedPayoffChapter": "",
                "ActualSetupChapter": "", "ActualPayoffChapter": "", "DriftWarnings": [],
            }
        entry = data[foreshadow_id]
        entry.setdefault("Tier", "Tier-3")
        entry.setdefault("DriftWarnings", [])
        entry["IsSetup"] = True
        entry["ActualSetupChapter"] = chapter_id
        store.set_all(data)

        # 对标 C#: var guide = GetGuideAsync(GuideFileName) ... MarkDirty(GuideFileName)
        gm = self._get_guide_manager()
        if gm is not None:
            try:
                guide = gm.get_guide(self.GuideFileName)
                # 同步到 guide（Foreshadowings 字典）
                if isinstance(guide, dict):
                    foreshadowings = guide.setdefault(self.GUIDE_FIELD, {})
                    foreshadowings[foreshadow_id] = dict(entry)
                    gm.mark_dirty(self.GuideFileName)
            except Exception:
                pass

    def mark_as_resolved(self, foreshadow_id: str, chapter_id: str):
        """对标 MarkAsResolvedAsync: IsResolved + IsOverdue=false + ActualPayoff"""
        store = self._get_store()
        data = store.data()
        if foreshadow_id not in data or not isinstance(data[foreshadow_id], dict):
            data[foreshadow_id] = {
                "Name": foreshadow_id, "Tier": "Tier-3", "IsSetup": False, "IsResolved": False,
                "IsOverdue": False, "ExpectedSetupChapter": "", "ExpectedPayoffChapter": "",
                "ActualSetupChapter": "", "ActualPayoffChapter": "", "DriftWarnings": [],
            }
        entry = data[foreshadow_id]
        entry.setdefault("Tier", "Tier-3")
        entry.setdefault("DriftWarnings", [])
        entry["IsResolved"] = True
        entry["IsOverdue"] = False
        entry["ActualPayoffChapter"] = chapter_id
        store.set_all(data)

        # 对标 C#: var guide = GetGuideAsync(GuideFileName) ... MarkDirty(GuideFileName)
        gm = self._get_guide_manager()
        if gm is not None:
            try:
                guide = gm.get_guide(self.GuideFileName)
                # 同步到 guide（Foreshadowings 字典）
                if isinstance(guide, dict):
                    foreshadowings = guide.setdefault(self.GUIDE_FIELD, {})
                    foreshadowings[foreshadow_id] = dict(entry)
                    gm.mark_dirty(self.GuideFileName)
            except Exception:
                pass

    # ---- 逾期刷新 ----

    def refresh_overdue_status(self, current_chapter_id: str):
        """对标 RefreshOverdueStatusAsync: CompareChapterId(当前, 预期) > 0 → overdue"""
        parsed_current = parse_chapter_id(current_chapter_id)
        if parsed_current == (0, 0):
            return
        store = self._get_store()
        data = store.data()
        modified = False
        for fid, entry in list(data.items()):
            if not isinstance(entry, dict):
                continue
            if entry.get("IsResolved"):
                if entry.get("IsOverdue"):
                    entry["IsOverdue"] = False
                    modified = True
                continue
            expected = entry.get("ExpectedPayoffChapter", "")
            if not expected or parse_chapter_id(expected) == (0, 0):
                continue
            should_overdue = compare_chapter_id(current_chapter_id, expected) > 0
            if bool(entry.get("IsOverdue", False)) != should_overdue:
                entry["IsOverdue"] = should_overdue
                modified = True
        if modified:
            store.set_all(data)
            # 对标 C#: 修改后 _guideManager.MarkDirty(GuideFileName)
            gm = self._get_guide_manager()
            if gm is not None:
                try:
                    guide = gm.get_guide(self.GuideFileName)
                    if isinstance(guide, dict):
                        foreshadowings = guide.setdefault(self.GUIDE_FIELD, {})
                        for fid, entry in data.items():
                            if isinstance(entry, dict):
                                foreshadowings[fid] = dict(entry)
                        gm.mark_dirty(self.GuideFileName)
                except Exception:
                    pass

    # ---- 统计 ----

    def get_statistics(self) -> dict:
        """对标 GetStatisticsAsync: 总览 + 分 Tier 统计"""
        store = self._get_store()
        data = store.data()
        foreshadowings = {k: v for k, v in data.items() if isinstance(v, dict)}

        def tier_stats(tier):
            items = [e for e in foreshadowings.values() if e.get("Tier") == tier]
            return {
                "Total": len(items),
                "Setup": sum(1 for e in items if e.get("IsSetup")),
                "Resolved": sum(1 for e in items if e.get("IsResolved")),
                "Overdue": sum(1 for e in items if e.get("IsOverdue")),
            }

        return {
            "TotalCount": len(foreshadowings),
            "SetupCount": sum(1 for e in foreshadowings.values() if e.get("IsSetup")),
            "ResolvedCount": sum(1 for e in foreshadowings.values() if e.get("IsResolved")),
            "OverdueCount": sum(1 for e in foreshadowings.values() if e.get("IsOverdue")),
            "Tier1Stats": tier_stats("Tier-1"),
            "Tier2Stats": tier_stats("Tier-2"),
            "Tier3Stats": tier_stats("Tier-3"),
        }

    # ---- 逾期列表 ----

    def get_overdue_foreshadowings(self) -> List[dict]:
        """对标 GetOverdueForeshadowingsAsync: 逾期按预期回收章排序"""
        store = self._get_store()
        data = store.data()
        result = [e for e in data.values()
                  if isinstance(e, dict) and e.get("IsOverdue")]
        result.sort(key=lambda e: parse_chapter_id(e.get("ExpectedPayoffChapter", "")))
        return result

    # ---- 删除章节 ----

    def remove_chapter_data(self, chapter_id: str):
        """对标 RemoveChapterDataAsync: 回退章节 + 重算逾期"""
        store = self._get_store()
        data = store.data()
        modified = False

        latest_chapter_id = self._get_latest_existing_chapter_id(self.project)
        can_compare_latest = bool(latest_chapter_id) and parse_chapter_id(latest_chapter_id) != (0, 0)

        for entry in list(data.values()):
            if not isinstance(entry, dict):
                continue
            if str(entry.get("ActualSetupChapter", "")) == chapter_id:
                entry["IsSetup"] = False
                entry["ActualSetupChapter"] = ""
                modified = True
            if str(entry.get("ActualPayoffChapter", "")) == chapter_id:
                entry["IsResolved"] = False
                entry["ActualPayoffChapter"] = ""
                modified = True

            should_overdue = False
            if (not entry.get("IsResolved") and can_compare_latest
                    and entry.get("ExpectedPayoffChapter")
                    and parse_chapter_id(entry.get("ExpectedPayoffChapter", "")) != (0, 0)):
                should_overdue = compare_chapter_id(
                    latest_chapter_id, entry.get("ExpectedPayoffChapter", "")) > 0

            if bool(entry.get("IsOverdue", False)) != should_overdue:
                entry["IsOverdue"] = should_overdue
                modified = True

        if modified:
            store.set_all(data)
            # 对标 C#: 修改后 _guideManager.MarkDirty(GuideFileName)
            gm = self._get_guide_manager()
            if gm is not None:
                try:
                    guide = gm.get_guide(self.GuideFileName)
                    if isinstance(guide, dict):
                        foreshadowings = guide.setdefault(self.GUIDE_FIELD, {})
                        for fid, entry in data.items():
                            if isinstance(entry, dict):
                                foreshadowings[fid] = dict(entry)
                        gm.mark_dirty(self.GuideFileName)
                except Exception:
                    pass