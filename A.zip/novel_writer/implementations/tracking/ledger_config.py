# -*- coding: utf-8 -*-
"""账本裁剪配置 — 对标 4.1.1 LayeredContextConfig（Ledger* 系列参数）

默认值对齐原版 GuideContextService.cs:
- LedgerCharacterStateKeepRecent = 10000000
- LedgerConflictProgressKeepRecent = 2000000
- LedgerPlotPointsKeepRecent = 10000000
- LedgerLocationStateKeepRecent = 5000000
- LedgerFactionStateKeepRecent = 5000000
- LedgerTimelineKeepRecent = 10000000
- LedgerMovementKeepRecent = 5000000
- LedgerItemStateKeepRecent = 5000000
- LedgerConstraintHistoryKeepRecent = 5000000
- LedgerMaxCriticalPerEntity = int.MaxValue
- LedgerImportantKeepRecent = 2000000
- LedgerNormalSampleInterval = 50
"""

import json
import os


class LedgerConfig:
    """账本裁剪配置快照（对标 LayeredContextConfigSnapshot）"""

    def __init__(self, **kwargs):
        # 各维度"保留最近 N 条历史"阈值
        self.LedgerCharacterStateKeepRecent = kwargs.pop("LedgerCharacterStateKeepRecent", 10000000)
        self.LedgerConflictProgressKeepRecent = kwargs.pop("LedgerConflictProgressKeepRecent", 2000000)
        self.LedgerPlotPointsKeepRecent = kwargs.pop("LedgerPlotPointsKeepRecent", 10000000)
        self.LedgerLocationStateKeepRecent = kwargs.pop("LedgerLocationStateKeepRecent", 5000000)
        self.LedgerFactionStateKeepRecent = kwargs.pop("LedgerFactionStateKeepRecent", 5000000)
        self.LedgerTimelineKeepRecent = kwargs.pop("LedgerTimelineKeepRecent", 10000000)
        self.LedgerMovementKeepRecent = kwargs.pop("LedgerMovementKeepRecent", 5000000)
        self.LedgerItemStateKeepRecent = kwargs.pop("LedgerItemStateKeepRecent", 5000000)
        self.LedgerConstraintHistoryKeepRecent = kwargs.pop("LedgerConstraintHistoryKeepRecent", 5000000)
        # 每实体关键条目上限（原版 int.MaxValue ≈ 不限制）
        self.LedgerMaxCriticalPerEntity = kwargs.pop("LedgerMaxCriticalPerEntity", None)
        # important 保留最近条数
        self.LedgerImportantKeepRecent = kwargs.pop("LedgerImportantKeepRecent", 2000000)
        # normal 锚点采样间隔
        self.LedgerNormalSampleInterval = kwargs.pop("LedgerNormalSampleInterval", 50)

    def max_critical(self) -> int:
        """返回每实体关键条数上限；None/int.MaxValue 表示不限制"""
        if self.LedgerMaxCriticalPerEntity is None:
            return None
        return self.LedgerMaxCriticalPerEntity

    def to_dict(self) -> dict:
        return {
            "LedgerCharacterStateKeepRecent": self.LedgerCharacterStateKeepRecent,
            "LedgerConflictProgressKeepRecent": self.LedgerConflictProgressKeepRecent,
            "LedgerPlotPointsKeepRecent": self.LedgerPlotPointsKeepRecent,
            "LedgerLocationStateKeepRecent": self.LedgerLocationStateKeepRecent,
            "LedgerFactionStateKeepRecent": self.LedgerFactionStateKeepRecent,
            "LedgerTimelineKeepRecent": self.LedgerTimelineKeepRecent,
            "LedgerMovementKeepRecent": self.LedgerMovementKeepRecent,
            "LedgerItemStateKeepRecent": self.LedgerItemStateKeepRecent,
            "LedgerConstraintHistoryKeepRecent": self.LedgerConstraintHistoryKeepRecent,
            "LedgerMaxCriticalPerEntity": self.LedgerMaxCriticalPerEntity,
            "LedgerImportantKeepRecent": self.LedgerImportantKeepRecent,
            "LedgerNormalSampleInterval": self.LedgerNormalSampleInterval,
        }

    @classmethod
    def from_file(cls, path: str) -> "LedgerConfig":
        """从 ledger_config.json 读取（可选，不存在则用默认值）"""
        if not path or not os.path.exists(path):
            return cls()
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                return cls(**{k: v for k, v in data.items() if v is not None})
        except Exception:
            pass
        return cls()


# 模块级默认配置（对标 LayeredContextConfig 静态单例）
DEFAULT_LEDGER_CONFIG = LedgerConfig()