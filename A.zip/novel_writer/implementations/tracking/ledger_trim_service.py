# -*- coding: utf-8 -*-
"""对标 Tracking/LedgerTrimService.cs

实现文件为 ledger_trim.py（LedgerTrimService，账本裁剪），
本文件提供与 C# 文件名一致的入口。
"""
from .ledger_trim import LedgerTrimService

__all__ = ["LedgerTrimService"]