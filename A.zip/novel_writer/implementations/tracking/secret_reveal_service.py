# -*- coding: utf-8 -*-
"""秘密揭示服务 — 对标 4.1.1 SecretRevealService.cs（完整移植 174 行）

对齐功能:
- UpdateSecretRevealAsync（守卫 + ID归并 + create + KnowerIds去重 + ComputeStatus + 完整快照）
- RemoveChapterDataAsync（删除历史 + 重建 KnowerIds + 重算状态）
- ExtractSnapshotAsync（导出 KnowerIds>0 的秘密快照）
- FindExistingSecretId（按 ID/Name 归并）
- ComputeStatus（0/1→hidden, ≤3→partially_known, >3→widely_known）
"""

from typing import Dict, List, Optional

from .character_state_service import build_chapter_id, parse_chapter_id
from .deadline_constraint_service import _is_likely_id, _new_deadline_id


def _new_secret_id() -> str:
    """对标 ShortIdGenerator.New("S"): 前缀取首字符'S' + 12位 = 13位"""
    return _new_deadline_id().replace("D", "S", 1)


def compute_status(knower_count: int) -> str:
    """对标 ComputeStatus: 按知情者数量分级"""
    if knower_count == 0:
        return "hidden"
    if knower_count == 1:
        return "hidden"
    if knower_count <= 3:
        return "partially_known"
    return "widely_known"


class SecretRevealService:
    """对标 4.1.1 SecretRevealService — 秘密揭示管理（独立类）

    调用链与 C# 完全一致：
    - 读: GuideManager.GetExistingVolumeNumbers + GetVolumeFileName + GetGuideAsync<SecretRevealGuide>
    - 写: GuideManager.MarkDirty(volFile)
    """

    BaseFileName = "secret_reveal_guide.json"
    GUIDE_FIELD = "Secrets"
    HISTORY_FIELD = "RevealHistory"

    def __init__(self, project, tracking_manager=None, guide_manager=None):
        self.project = project
        self.tracking = tracking_manager
        self._store = None
        # 对标 C# _guideManager（未提供时延迟创建）
        self._guide_manager = guide_manager

    def _get_guide_manager(self):
        if self._guide_manager is None:
            try:
                from ..guides.guide_manager import GuideManager
                self._guide_manager = GuideManager(self.project)
            except Exception:
                return None
        return self._guide_manager

    @classmethod
    def _volume_file_name(cls, chapter_id: str) -> str:
        """对标 C# VolumeFileName(chapterId): GuideManager.GetVolumeFileName(BaseFileName, vol)"""
        from ..guides.guide_manager import GuideManager
        vol, _ = parse_chapter_id(chapter_id)
        return GuideManager.get_volume_file_name(cls.BaseFileName, vol)

    def _get_store(self):
        if self._store is None:
            if self.tracking is not None:
                self._store = self.tracking._stores["secret"]
            else:
                self._store = self.project.tracking("secret")
        return self._store

    # ---- ID 归并 ----

    @staticmethod
    def find_existing_secret_id(data: dict, ai_secret_id: str, ai_secret_name: str) -> Optional[str]:
        """对标 FindExistingSecretId: 按 ID 或 Name 匹配已有秘密"""
        if ai_secret_id and ai_secret_id in data:
            return ai_secret_id
        for sid, entry in data.items():
            if not isinstance(entry, dict):
                continue
            name = entry.get("Name", "")
            if name and str(name).lower() == str(ai_secret_id).lower():
                return sid
            if ai_secret_name and name and str(name).lower() == str(ai_secret_name).lower():
                return sid
        return None

    # ---- 更新 ----

    def update_secret_reveal(self, chapter_id: str, change) -> Optional[str]:
        """对标 UpdateSecretRevealAsync: 更新/创建秘密揭示

        change: SecretRevealChange（SecretId/SecretName/NewKnowerIds/Method/KeyEvent/Importance/CausedBy）
        返回 systemId 或 None（守卫拦截）
        """
        if not change.SecretId and not change.SecretName:
            return None
        if not change.NewKnowerIds:
            return None

        store = self._get_store()
        data = store.data()

        system_id = self.find_existing_secret_id(data, change.SecretId, change.SecretName)

        if system_id is None:
            system_id = change.SecretId if _is_likely_id(change.SecretId) else _new_secret_id()
            display_name = (change.SecretName if change.SecretName
                            else (change.SecretId if change.SecretId else system_id))
            if system_id not in data:
                data[system_id] = {
                    "Name": display_name,
                    "KnowerIds": [],
                    "CurrentStatus": "hidden",
                    self.HISTORY_FIELD: [],
                    "DriftWarnings": [],
                }

        entry = data[system_id]
        # 补齐既有条目默认字段
        entry.setdefault("CurrentStatus", "hidden")
        entry.setdefault("DriftWarnings", [])
        knower = entry.setdefault("KnowerIds", [])
        if not isinstance(knower, list):
            knower = []
            entry["KnowerIds"] = knower
        history = entry.setdefault(self.HISTORY_FIELD, [])
        if not isinstance(history, list):
            history = []
            entry[self.HISTORY_FIELD] = history

        if change.SecretName:
            entry["Name"] = change.SecretName

        # KnowerIds 追加去重（对标 C# OrdinalIgnoreCase）
        for knower_id in change.NewKnowerIds:
            if knower_id and not any(str(k).lower() == str(knower_id).lower() for k in knower):
                knower.append(knower_id)

        entry["CurrentStatus"] = compute_status(len(knower))

        # RevealHistory 完整快照（对标 C# SecretRevealPoint）
        history.append({
            "Chapter": chapter_id,
            "NewKnowerIds": list(change.NewKnowerIds),
            "Method": change.Method,
            "KeyEvent": change.KeyEvent,
            "Importance": change.Importance if change.Importance else "normal",
            "CausedBy": change.CausedBy or "",
        })

        store.set_all(data)

        # 对标 C#: var guide = GetGuideAsync(volFile) ... _guideManager.MarkDirty(volFile)
        gm = self._get_guide_manager()
        if gm is not None:
            try:
                vol_file = self._volume_file_name(chapter_id)
                guide = gm.get_guide(vol_file)
                # 同步到分卷 guide（Secrets 字典 + RevealHistory）
                if isinstance(guide, dict):
                    secrets = guide.setdefault(self.GUIDE_FIELD, {})
                    g_entry = secrets.get(system_id)
                    if not isinstance(g_entry, dict):
                        secrets[system_id] = {
                            "Name": entry.get("Name", ""),
                            "KnowerIds": list(entry.get("KnowerIds") or []),
                            "CurrentStatus": entry.get("CurrentStatus", "hidden"),
                            "DriftWarnings": list(entry.get("DriftWarnings") or []),
                            self.HISTORY_FIELD: [history[-1]],
                        }
                    else:
                        g_entry["Name"] = entry.get("Name", g_entry.get("Name", ""))
                        g_entry["KnowerIds"] = list(entry.get("KnowerIds") or [])
                        g_entry["CurrentStatus"] = entry.get("CurrentStatus", "hidden")
                        g_history = g_entry.setdefault(self.HISTORY_FIELD, [])
                        g_history.append(history[-1])
                    gm.mark_dirty(vol_file)
            except Exception:
                pass

        return system_id

    # ---- 删除章节 ----

    def remove_chapter_data(self, chapter_id: str) -> int:
        """对标 RemoveChapterDataAsync: 删除历史 + 重建 KnowerIds + 重算状态"""
        store = self._get_store()
        data = store.data()
        modified = False
        removed_total = 0

        for entry in list(data.values()):
            if not isinstance(entry, dict):
                continue
            history = entry.get(self.HISTORY_FIELD)
            if not isinstance(history, list):
                continue
            before = len(history)
            history[:] = [p for p in history
                          if not (p.get("Chapter", "") and p["Chapter"] == chapter_id)]
            removed = before - len(history)
            if removed > 0:
                # 重建 KnowerIds：从 RevealHistory 的 NewKnowerIds 去重
                seen = set()
                knower = []
                for p in history:
                    for kid in (p.get("NewKnowerIds") or []):
                        if kid and str(kid).lower() not in seen:
                            seen.add(str(kid).lower())
                            knower.append(kid)
                entry["KnowerIds"] = knower
                entry["CurrentStatus"] = compute_status(len(knower))
                modified = True
                removed_total += removed

        if modified:
            store.set_all(data)
            # 对标 C#: 修改后 _guideManager.MarkDirty(volFile)
            gm = self._get_guide_manager()
            if gm is not None:
                try:
                    vol_file = self._volume_file_name(chapter_id)
                    guide = gm.get_guide(vol_file)
                    if isinstance(guide, dict):
                        g_modified = False
                        for g_entry in (guide.get(self.GUIDE_FIELD) or {}).values():
                            if not isinstance(g_entry, dict):
                                continue
                            g_history = g_entry.get(self.HISTORY_FIELD)
                            if not isinstance(g_history, list):
                                continue
                            before = len(g_history)
                            g_history[:] = [p for p in g_history
                                            if p.get("Chapter", "") != chapter_id]
                            if len(g_history) < before:
                                g_modified = True
                                # 重建 KnowerIds（对标 C# SelectMany + Distinct）
                                seen = set()
                                knower = []
                                for p in g_history:
                                    for kid in (p.get("NewKnowerIds") or []):
                                        if kid and str(kid).lower() not in seen:
                                            seen.add(str(kid).lower())
                                            knower.append(kid)
                                g_entry["KnowerIds"] = knower
                                g_entry["CurrentStatus"] = compute_status(len(knower))
                        if g_modified:
                            gm.mark_dirty(vol_file)
                except Exception:
                    pass
        return removed_total

    # ---- 快照 ----

    def extract_snapshot(self, chapter_id: str = "") -> List[dict]:
        """对标 ExtractSnapshotAsync: 优先走分卷 guide（KnowerIds>0），回退 store"""
        gm = self._get_guide_manager()
        if gm is not None:
            try:
                # 对标: var volNumbers = _guideManager.GetExistingVolumeNumbers(BaseFileName)
                vol_numbers = gm.get_existing_volume_numbers(self.BaseFileName)
                if vol_numbers:
                    result = []
                    seen = set()
                    for vol in vol_numbers:
                        vol_file = gm.get_volume_file_name(self.BaseFileName, vol)
                        guide = gm.get_guide(vol_file)
                        if not isinstance(guide, dict):
                            continue
                        for sid, entry in (guide.get(self.GUIDE_FIELD) or {}).items():
                            if not isinstance(entry, dict):
                                continue
                            knower = entry.get("KnowerIds") or []
                            if not knower:
                                continue
                            if str(sid).lower() in seen:
                                continue
                            seen.add(str(sid).lower())
                            history = entry.get(self.HISTORY_FIELD)
                            last_chapter = ""
                            if isinstance(history, list) and history:
                                last_chapter = history[-1].get("Chapter", "") or ""
                            result.append({
                                "Id": sid,
                                "Name": entry.get("Name", ""),
                                "KnowerIds": list(knower),
                                "Status": entry.get("CurrentStatus", "hidden"),
                                "ChapterId": last_chapter,
                            })
                    return result
                # 分卷未找到时回退 store
            except Exception:
                pass
        store = self._get_store()
        data = store.data()
        result = []
        seen = set()
        for sid, entry in data.items():
            if not isinstance(entry, dict):
                continue
            knower = entry.get("KnowerIds") or []
            if not knower:
                continue
            if str(sid).lower() in seen:
                continue
            seen.add(str(sid).lower())
            history = entry.get(self.HISTORY_FIELD)
            last_chapter = ""
            if isinstance(history, list) and history:
                last_chapter = history[-1].get("Chapter", "") or ""
            result.append({
                "Id": sid,
                "Name": entry.get("Name", ""),
                "KnowerIds": list(knower),
                "Status": entry.get("CurrentStatus", "hidden"),
                "ChapterId": last_chapter,
            })
        return result