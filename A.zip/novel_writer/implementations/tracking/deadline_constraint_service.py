# -*- coding: utf-8 -*-
"""倒计时/时限约束服务 — 对标 4.1.1 DeadlineConstraintService.cs（完整移植 266 行）

对齐功能:
- UpdateDeadlineAsync（守卫 + ID归并 + create + 动作状态机 + History完整快照）
- RefreshOverdueStatusAsync（按章距判定逾期）
- RemoveChapterDataAsync（删除历史 + 回填状态 + 清理空条目）
- ExtractSnapshotAsync（导出 active 倒计时快照）
- FindExistingDeadlineId（按 ID/Name 归并）
"""

from typing import Dict, List, Optional

from .character_state_service import build_chapter_id, parse_chapter_id

# 对标 C# ShortIdGenerator: Alphabet 去掉 I/L/O/U，IdLength=12，前缀只取首字符
_DEADLINE_ID_CHARS = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"


def _new_deadline_id() -> str:
    """对标 ShortIdGenerator.New("DL"): 前缀取首字符'D' + 12位 = 13位"""
    import random, time
    ts = int(time.time() * 1000) & ((1 << 41) - 1)
    rnd = random.getrandbits(19)
    val = (ts << 19) | rnd
    chars = []
    for _ in range(12):
        chars.append(_DEADLINE_ID_CHARS[val & 31])
        val >>= 5
    return "D" + "".join(reversed(chars))


def _is_likely_id(value) -> bool:
    """对标 ShortIdGenerator.IsLikelyId: 长度13 且首字符大写 即视为合法 ID"""
    if not isinstance(value, str):
        return False
    if len(value) == 13 and value[0].isupper():
        return True
    return False


# 对标 C# 动作 → 状态 映射
_ACTION_STATUS = {
    "trigger": "triggered",
    "expire": "expired",
    "cancel": "cancelled",
}


class DeadlineConstraintService:
    """对标 4.1.1 DeadlineConstraintService — 倒计时/时限约束管理（独立类）

    调用链与 C# 完全一致：
    - 读: GuideManager.GetExistingVolumeNumbers + GetVolumeFileName + GetGuideAsync<DeadlineConstraintGuide>
    - 写: GuideManager.MarkDirty(volFile)
    """

    BaseFileName = "deadline_constraint_guide.json"
    GUIDE_FIELD = "Deadlines"
    HISTORY_FIELD = "History"

    def __init__(self, project, tracking_manager=None, guide_manager=None):
        self.project = project
        self.tracking = tracking_manager
        self._store = None
        # 对标 C# _guideManager（未提供时延迟创建）
        self._guide_manager = guide_manager

    def _get_guide_manager(self):
        if self._guide_manager is None:
            try:
                from ..guides.guide_manager import GuideManager
                self._guide_manager = GuideManager(self.project)
            except Exception:
                return None
        return self._guide_manager

    @classmethod
    def _volume_file_name(cls, chapter_id: str) -> str:
        """对标 C# VolumeFileName(chapterId): GuideManager.GetVolumeFileName(BaseFileName, vol)"""
        from ..guides.guide_manager import GuideManager
        vol, _ = parse_chapter_id(chapter_id)
        return GuideManager.get_volume_file_name(cls.BaseFileName, vol)

    def _get_store(self):
        if self._store is None:
            if self.tracking is not None:
                self._store = self.tracking._stores["deadline"]
            else:
                self._store = self.project.tracking("deadline")
        return self._store

    # ---- ID 归并 ----

    @staticmethod
    def find_existing_deadline_id(data: dict, ai_deadline_id: str,
                                  ai_deadline_name: str) -> Optional[str]:
        """对标 FindExistingDeadlineId: 按 ID 或 Name 匹配已有倒计时"""
        if ai_deadline_id and ai_deadline_id in data:
            return ai_deadline_id
        for did, entry in data.items():
            if not isinstance(entry, dict):
                continue
            name = entry.get("Name", "")
            if name and str(name).lower() == str(ai_deadline_id).lower():
                return did
            if ai_deadline_name and name and str(name).lower() == str(ai_deadline_name).lower():
                return did
        return None

    # ---- 更新 ----

    def update_deadline(self, chapter_id: str, change) -> Optional[str]:
        """对标 UpdateDeadlineAsync: 更新/创建倒计时

        change: DeadlineConstraintChange
        返回 systemId 或 None（守卫拦截）
        """
        if not change.DeadlineId and not change.DeadlineName:
            return None
        if not change.Action:
            return None

        store = self._get_store()
        data = store.data()

        system_id = self.find_existing_deadline_id(data, change.DeadlineId, change.DeadlineName)

        # create（对标 C#: 无匹配且 Action=create 才创建）
        if system_id is None and str(change.Action).lower() == "create":
            system_id = change.DeadlineId if _is_likely_id(change.DeadlineId) else _new_deadline_id()
            display_name = (change.DeadlineName if change.DeadlineName
                            else (change.DeadlineId if change.DeadlineId else system_id))
            data[system_id] = {
                "Name": display_name,
                "Type": change.Type if change.Type else "countdown",
                "CurrentStatus": "active",
                "Deadline": change.Deadline or "",
                "TriggerCondition": change.TriggerCondition or "",
                "Consequence": change.Consequence or "",
                "PartyIds": list(change.PartyIds or []),
                self.HISTORY_FIELD: [],
                "IsOverdue": False,
                "DriftWarnings": [],
            }

        if system_id is None:
            return None

        entry = data[system_id]
        # 补齐既有条目默认字段
        entry.setdefault("Type", "countdown")
        entry.setdefault("CurrentStatus", "active")
        entry.setdefault("Deadline", "")
        entry.setdefault("TriggerCondition", "")
        entry.setdefault("Consequence", "")
        entry.setdefault("PartyIds", [])
        entry.setdefault("DriftWarnings", [])
        entry.setdefault("IsOverdue", False)
        history = entry.setdefault(self.HISTORY_FIELD, [])
        if not isinstance(history, list):
            history = []
            entry[self.HISTORY_FIELD] = history

        if change.DeadlineName:
            entry["Name"] = change.DeadlineName

        action = str(change.Action).lower()
        if action in _ACTION_STATUS:
            entry["CurrentStatus"] = _ACTION_STATUS[action]
        elif action == "update":
            if change.Deadline:
                entry["Deadline"] = change.Deadline
            if change.TriggerCondition:
                entry["TriggerCondition"] = change.TriggerCondition
            if change.Consequence:
                entry["Consequence"] = change.Consequence
            if change.PartyIds:
                party = entry["PartyIds"]
                if not isinstance(party, list):
                    party = []
                    entry["PartyIds"] = party
                for pid in change.PartyIds:
                    if pid and str(pid).strip() and not any(
                            str(p).lower() == str(pid).lower() for p in party):
                        party.append(pid)

        # History 完整快照（对标 C# DeadlineConstraintPoint）
        history.append({
            "Chapter": chapter_id,
            "Action": change.Action,
            "KeyEvent": change.KeyEvent or "",
            "Importance": change.Importance if change.Importance else "normal",
        })

        store.set_all(data)

        # 对标 C#: var guide = GetGuideAsync(volFile) ... _guideManager.MarkDirty(volFile)
        gm = self._get_guide_manager()
        if gm is not None:
            try:
                vol_file = self._volume_file_name(chapter_id)
                guide = gm.get_guide(vol_file)
                # 同步到分卷 guide（Deadlines 字典 + History）
                if isinstance(guide, dict):
                    deadlines = guide.setdefault(self.GUIDE_FIELD, {})
                    g_entry = deadlines.get(system_id)
                    if not isinstance(g_entry, dict):
                        deadlines[system_id] = {
                            "Name": entry.get("Name", ""),
                            "Type": entry.get("Type", "countdown"),
                            "CurrentStatus": entry.get("CurrentStatus", "active"),
                            "Deadline": entry.get("Deadline", ""),
                            "TriggerCondition": entry.get("TriggerCondition", ""),
                            "Consequence": entry.get("Consequence", ""),
                            "PartyIds": list(entry.get("PartyIds") or []),
                            "IsOverdue": bool(entry.get("IsOverdue", False)),
                            "DriftWarnings": list(entry.get("DriftWarnings") or []),
                            self.HISTORY_FIELD: [history[-1]],
                        }
                    else:
                        g_entry["Name"] = entry.get("Name", g_entry.get("Name", ""))
                        g_entry["Type"] = entry.get("Type", g_entry.get("Type", "countdown"))
                        g_entry["CurrentStatus"] = entry.get("CurrentStatus",
                                                             g_entry.get("CurrentStatus", "active"))
                        g_entry["Deadline"] = entry.get("Deadline", "")
                        g_entry["TriggerCondition"] = entry.get("TriggerCondition", "")
                        g_entry["Consequence"] = entry.get("Consequence", "")
                        g_entry["PartyIds"] = list(entry.get("PartyIds") or [])
                        g_entry["IsOverdue"] = bool(entry.get("IsOverdue", False))
                        g_history = g_entry.setdefault(self.HISTORY_FIELD, [])
                        g_history.append(history[-1])
                    gm.mark_dirty(vol_file)
            except Exception:
                pass

        return system_id

    # ---- 逾期刷新 ----

    def refresh_overdue_status(self, current_chapter_id: str, max_dangling_chapters: int) -> None:
        """对标 RefreshOverdueStatusAsync: 按章距判定 IsOverdue

        距离 = (当前卷-首次卷)*100 + (当前章-首次章) ≥ maxDanglingChapters → overdue
        """
        if max_dangling_chapters <= 0:
            return
        cp = parse_chapter_id(current_chapter_id)
        if cp == (0, 0):
            return

        store = self._get_store()
        data = store.data()
        modified = False

        for entry in data.values():
            if not isinstance(entry, dict):
                continue
            if str(entry.get("CurrentStatus", "")).lower() != "active":
                if entry.get("IsOverdue"):
                    entry["IsOverdue"] = False
                    modified = True
                continue

            history = entry.get(self.HISTORY_FIELD)
            first_point = history[0] if (isinstance(history, list) and history) else None
            if not first_point or not first_point.get("Chapter"):
                continue

            wp = parse_chapter_id(first_point["Chapter"])
            if wp == (0, 0):
                continue

            distance = (cp[0] - wp[0]) * 100 + (cp[1] - wp[1])
            should_overdue = distance >= max_dangling_chapters

            if bool(entry.get("IsOverdue", False)) != should_overdue:
                entry["IsOverdue"] = should_overdue
                modified = True

        if modified:
            store.set_all(data)
            # 对标 C#: 遍历各卷修改后 _guideManager.MarkDirty(volFile)
            gm = self._get_guide_manager()
            if gm is not None:
                try:
                    vol_numbers = gm.get_existing_volume_numbers(self.BaseFileName)
                    for vol in vol_numbers:
                        vol_file = gm.get_volume_file_name(self.BaseFileName, vol)
                        guide = gm.get_guide(vol_file)
                        if not isinstance(guide, dict):
                            continue
                        g_modified = False
                        for g_entry in (guide.get(self.GUIDE_FIELD) or {}).values():
                            if not isinstance(g_entry, dict):
                                continue
                            if str(g_entry.get("CurrentStatus", "")).lower() != "active":
                                if g_entry.get("IsOverdue"):
                                    g_entry["IsOverdue"] = False
                                    g_modified = True
                                continue
                            g_history = g_entry.get(self.HISTORY_FIELD)
                            first_point = g_history[0] if (isinstance(g_history, list) and g_history) else None
                            if not first_point or not first_point.get("Chapter"):
                                continue
                            wp = parse_chapter_id(first_point["Chapter"])
                            if wp == (0, 0):
                                continue
                            distance = (cp[0] - wp[0]) * 100 + (cp[1] - wp[1])
                            g_should_overdue = distance >= max_dangling_chapters
                            if bool(g_entry.get("IsOverdue", False)) != g_should_overdue:
                                g_entry["IsOverdue"] = g_should_overdue
                                g_modified = True
                        if g_modified:
                            gm.mark_dirty(vol_file)
                except Exception:
                    pass

    # ---- 删除章节 ----

    def remove_chapter_data(self, chapter_id: str) -> int:
        """对标 RemoveChapterDataAsync: 删除历史 + 回填状态 + 清理空条目"""
        store = self._get_store()
        data = store.data()
        modified = False
        removed_total = 0
        to_remove = []

        for did, entry in list(data.items()):
            if not isinstance(entry, dict):
                continue
            history = entry.get(self.HISTORY_FIELD)
            if not isinstance(history, list):
                continue
            before = len(history)
            history[:] = [p for p in history
                          if not (p.get("Chapter", "") and p["Chapter"] == chapter_id)]
            removed = before - len(history)
            if removed > 0:
                modified = True
                removed_total += removed
                if len(history) == 0:
                    to_remove.append(did)
                else:
                    # 回填状态：最后非 update 动作
                    last_status_action = ""
                    for h in reversed(history):
                        a = str(h.get("Action", "")).lower()
                        if a != "update":
                            last_status_action = a
                            break
                    new_status = _ACTION_STATUS.get(last_status_action, "active")
                    if str(entry.get("CurrentStatus", "")).lower() != str(new_status).lower():
                        entry["CurrentStatus"] = new_status
                    if (str(entry.get("CurrentStatus", "")).lower() != "active"
                            and entry.get("IsOverdue")):
                        entry["IsOverdue"] = False

        for did in to_remove:
            data.pop(did, None)

        if modified:
            store.set_all(data)
            # 对标 C#: 修改后 _guideManager.MarkDirty(volFile)
            gm = self._get_guide_manager()
            if gm is not None:
                try:
                    vol_file = self._volume_file_name(chapter_id)
                    guide = gm.get_guide(vol_file)
                    if isinstance(guide, dict):
                        g_modified = False
                        deadlines = guide.setdefault(self.GUIDE_FIELD, {})
                        g_to_remove = []
                        for gdid, g_entry in list(deadlines.items()):
                            if not isinstance(g_entry, dict):
                                continue
                            g_history = g_entry.get(self.HISTORY_FIELD)
                            if not isinstance(g_history, list):
                                continue
                            before = len(g_history)
                            g_history[:] = [p for p in g_history
                                            if p.get("Chapter", "") != chapter_id]
                            if len(g_history) < before:
                                g_modified = True
                                if len(g_history) == 0:
                                    g_to_remove.append(gdid)
                                else:
                                    last_status_action = ""
                                    for h in reversed(g_history):
                                        a = str(h.get("Action", "")).lower()
                                        if a != "update":
                                            last_status_action = a
                                            break
                                    g_entry["CurrentStatus"] = _ACTION_STATUS.get(last_status_action, "active")
                                    if (str(g_entry.get("CurrentStatus", "")).lower() != "active"
                                            and g_entry.get("IsOverdue")):
                                        g_entry["IsOverdue"] = False
                        for gdid in g_to_remove:
                            deadlines.pop(gdid, None)
                        if g_modified:
                            gm.mark_dirty(vol_file)
                except Exception:
                    pass
        return removed_total

    # ---- 快照 ----

    def extract_snapshot(self, chapter_id: str = "") -> List[dict]:
        """对标 ExtractSnapshotAsync: 优先走分卷 guide（active 倒计时），回退 store"""
        gm = self._get_guide_manager()
        if gm is not None:
            try:
                # 对标: var volNumbers = _guideManager.GetExistingVolumeNumbers(BaseFileName)
                vol_numbers = gm.get_existing_volume_numbers(self.BaseFileName)
                if vol_numbers:
                    result = []
                    seen = set()
                    for vol in vol_numbers:
                        vol_file = gm.get_volume_file_name(self.BaseFileName, vol)
                        guide = gm.get_guide(vol_file)
                        if not isinstance(guide, dict):
                            continue
                        for did, entry in (guide.get(self.GUIDE_FIELD) or {}).items():
                            if not isinstance(entry, dict):
                                continue
                            if str(entry.get("CurrentStatus", "")).lower() != "active":
                                continue
                            if str(did).lower() in seen:
                                continue
                            seen.add(str(did).lower())
                            history = entry.get(self.HISTORY_FIELD)
                            last_chapter = ""
                            if isinstance(history, list) and history:
                                last_chapter = history[-1].get("Chapter", "") or ""
                            result.append({
                                "Id": did,
                                "Name": entry.get("Name", ""),
                                "Type": entry.get("Type", "countdown"),
                                "Status": entry.get("CurrentStatus", "active"),
                                "Deadline": entry.get("Deadline", ""),
                                "TriggerCondition": entry.get("TriggerCondition", ""),
                                "Consequence": entry.get("Consequence", ""),
                                "PartyIds": ",".join((entry.get("PartyIds") or [])[:20]),
                                "ChapterId": last_chapter,
                                "IsOverdue": bool(entry.get("IsOverdue", False)),
                            })
                    return result
                # 分卷未找到时回退 store
            except Exception:
                pass
        store = self._get_store()
        data = store.data()
        result = []
        seen = set()
        for did, entry in data.items():
            if not isinstance(entry, dict):
                continue
            if str(entry.get("CurrentStatus", "")).lower() != "active":
                continue
            if str(did).lower() in seen:
                continue
            seen.add(str(did).lower())
            history = entry.get(self.HISTORY_FIELD)
            last_chapter = ""
            if isinstance(history, list) and history:
                last_chapter = history[-1].get("Chapter", "") or ""
            result.append({
                "Id": did,
                "Name": entry.get("Name", ""),
                "Type": entry.get("Type", "countdown"),
                "Status": entry.get("CurrentStatus", "active"),
                "Deadline": entry.get("Deadline", ""),
                "TriggerCondition": entry.get("TriggerCondition", ""),
                "Consequence": entry.get("Consequence", ""),
                "PartyIds": ",".join((entry.get("PartyIds") or [])[:20]),
                "ChapterId": last_chapter,
                "IsOverdue": bool(entry.get("IsOverdue", False)),
            })
        return result