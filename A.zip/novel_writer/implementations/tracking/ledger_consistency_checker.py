# -*- coding: utf-8 -*-
"""账本一致性校验 — 对标 Implementations/Tracking/LedgerConsistencyChecker.cs

C# 中为独立类（V1-V8 一致性检查：伏笔/冲突态序/角色等级/誓言/倒计时/移动链/物品归属/势力关系）。
Python 中该逻辑内联于 GenerationGate（gate.py）的一致性关卡 `_consistency_check`（对标 V1-V8）。
本文件提供与 C# 一致的独立入口 API，保证目录结构一一对应。
"""
import re
from ...gate import GenerationGate
from ...models import ChapterChanges, FactSnapshot


class ConsistencyIssue:
    """对标 ConsistencyIssue"""
    def __init__(self, entity_id="", issue_type="", expected="", actual=""):
        self.EntityId = entity_id
        self.IssueType = issue_type
        self.Expected = expected
        self.Actual = actual


class ConsistencyResult:
    """对标 ConsistencyResult"""
    def __init__(self):
        self.Issues = []
        self.Success = True

    @property
    def HasIssues(self) -> bool:
        return len(self.Issues) > 0

    def AddIssue(self, issue: ConsistencyIssue):
        self.Issues.append(issue)
        self.Success = False


_tier_number_re = re.compile(r"tier\s*[-_]?\s*(\d+)", re.IGNORECASE)
_plain_digits_re = re.compile(r"\d+")
_roman_numeral_re = re.compile(r"\b[IVXLCDM]+\b", re.IGNORECASE)
_chinese_number_re = re.compile(r"[零一二三四五六七八九十百千万两]+")


class LedgerConsistencyChecker:
    """对标 LedgerConsistencyChecker：委托 GenerationGate 一致性关卡"""

    def __init__(self):
        self._gate = GenerationGate()

    def Validate(self, changes: ChapterChanges, fact_snapshot: FactSnapshot, rule_set=None) -> ConsistencyResult:
        """对标 Validate(ChapterChanges, FactSnapshot) 与三参重载"""
        result = ConsistencyResult()
        if changes is None:
            result.AddIssue(ConsistencyIssue(entity_id="", issue_type="NullChanges",
                                             expected="CHANGES对象不为空", actual="CHANGES对象为空"))
            return result
        errors = self._gate._consistency_check(changes, fact_snapshot,
                                               ruleset=rule_set if rule_set is not None else None)
        for err in errors:
            etype = "Consistency"
            expected, actual = "", ""
            if "不可回退" in err or "未埋设" in err or "同一章节" in err or "重复" in err:
                etype = "ForeshadowingConsistency"
            result.AddIssue(ConsistencyIssue(issue_type=etype, expected=expected, actual=err))
        result.Success = not result.HasIssues
        return result

    def ValidateStructuralOnly(self, changes: ChapterChanges) -> ConsistencyResult:
        """对标 ValidateStructuralOnly：不依赖完整快照的结构一致性"""
        result = ConsistencyResult()
        if changes is None:
            return result
        empty = FactSnapshot()
        errors = self._gate._consistency_check(changes, empty, ruleset=None)
        for err in errors:
            if any(k in err for k in ("先埋设", "不可回退", "路径", "持有者", "关系矛盾")):
                result.AddIssue(ConsistencyIssue(issue_type="StructuralConsistency",
                                                 expected="结构一致", actual=err))
        result.Success = not result.HasIssues
        return result

    # ====== 私有方法（对标 C# 同名静态方法） ======

    # 对标 C# IsAllyRelation (LedgerConsistencyChecker.cs 765 行): 22 个盟友关键词
    _ALLY_KEYWORDS = (
        "盟友", "同盟", "结盟", "挚友", "知己", "朋友",
        "好友", "友人", "亲友", "兄弟", "姐妹", "手足",
        "恋人", "爱人", "夫妻", "伙伴", "同伴", "战友",
        "心腹", "亲信", "ally", "friend",
    )

    # 对标 C# IsEnemyRelation (LedgerConsistencyChecker.cs 777 行): 14 个仇敌关键词
    _ENEMY_KEYWORDS = (
        "仇敌", "敌对", "宿敌", "敌人", "死敌", "仇人",
        "对头", "政敌", "寇仇", "冤家", "反目", "决裂",
        "enemy", "hostile",
    )

    @staticmethod
    def is_ally_relation(relation: str) -> bool:
        if not relation or not relation.strip():
            return False
        r = relation.lower()
        return any(k in r for k in LedgerConsistencyChecker._ALLY_KEYWORDS)

    @staticmethod
    def is_enemy_relation(relation: str) -> bool:
        if not relation or not relation.strip():
            return False
        r = relation.lower()
        return any(k in r for k in LedgerConsistencyChecker._ENEMY_KEYWORDS)

    @staticmethod
    def build_status_index_map(sequence: list) -> dict:
        map = {}
        if not sequence or len(sequence) < 2:
            return map
        for item in sequence:
            s = LedgerConsistencyChecker.normalize_conflict_status(item)
            if not s:
                continue
            if s not in map:
                map[s] = len(map)
        return map

    @staticmethod
    def normalize_conflict_status(status: str) -> str:
        if not status or not status.strip():
            return ""
        s = status.strip().lower()

        if s in ("pending", "todo", "new", "open"):
            return "pending"
        if s in ("active", "ongoing", "running", "inprogress", "in_progress"):
            return "active"
        if s in ("climax", "peak", "burst", "explosion"):
            return "climax"
        if s in ("resolved", "done", "closed", "finished", "complete", "completed"):
            return "resolved"

        if "未" in status and any(k in status for k in ("开始", "触发", "启动", "发生")):
            return "pending"
        if any(k in status for k in ("进行", "推进", "发展", "展开", "激活", "触发", "开启", "进展", "持续", "继续", "升级")):
            return "active"
        if any(k in status for k in ("高潮", "爆发", "决战", "决裂", "临界", "白热化", "最高点", "紧要关头", "危急")):
            return "climax"
        if any(k in status for k in ("解决", "结束", "完结", "收束", "已结", "闭环", "落幕", "告终", "平息", "化解", "消弭", "了结")):
            return "resolved"

        return s

    @staticmethod
    def parse_level_number(level: str, level_map: dict) -> int:
        if not level or not level.strip():
            return -1
        text = level.strip()

        m = _tier_number_re.search(text)
        if m:
            tier_num = int(m.group(1))
            key = f"Tier-{tier_num}"
            if level_map and key in level_map:
                return level_map[key]
            return tier_num

        m = _plain_digits_re.search(text)
        if m:
            return int(m.group(0))

        m = _roman_numeral_re.search(text)
        if m:
            val = LedgerConsistencyChecker.try_parse_roman_numeral(m.group(0))
            if val is not None:
                return val

        m = _chinese_number_re.search(text)
        if m:
            val = LedgerConsistencyChecker.try_parse_chinese_number(m.group(0))
            if val is not None:
                return val

        # Grade level match
        grade_match = re.search(r"\b(SSS|SS|S|A|B|C|D|E|F)\b", text, re.IGNORECASE)
        if grade_match:
            g = grade_match.group(1).upper()
            if level_map and g in level_map:
                return level_map[g]

        if level_map:
            for k, v in level_map.items():
                if k.lower() in text.lower():
                    return v

        return -1

    @staticmethod
    def try_parse_roman_numeral(text: str):
        if not text or not text.strip():
            return None
        values = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
        total = 0
        prev = 0
        for c in text.strip().upper():
            cur = values.get(c)
            if cur is None:
                return None
            if cur > prev:
                total += cur - 2 * prev
            else:
                total += cur
            prev = cur
        return total if total > 0 else None

    @staticmethod
    def try_parse_chinese_number(text: str):
        if not text or not text.strip():
            return None
        digits = {'零': 0, '一': 1, '二': 2, '两': 2, '三': 3, '四': 4,
                  '五': 5, '六': 6, '七': 7, '八': 8, '九': 9}
        units = {'十': 10, '百': 100, '千': 1000, '万': 10000}
        result = 0
        section = 0
        number = 0
        for c in text.strip():
            if c in digits:
                number = digits[c]
                continue
            unit = units.get(c)
            if unit is None:
                return None
            if unit == 10000:
                section += number
                result += section * 10000
                section = 0
                number = 0
            else:
                section += (number if number != 0 else 1) * unit
                number = 0
        val = result + section + number
        return val if val > 0 else None