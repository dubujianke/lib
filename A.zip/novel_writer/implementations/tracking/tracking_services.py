# -*- coding: utf-8 -*-
"""状态回写：CHANGES → 15 维追踪 Guide（11 个 Tracking Service）"""

import concurrent.futures
import json
from typing import Dict, List

from ...models import ChapterChanges, FactSnapshot, is_likely_id
from ...storage import Project
from ...models.common import short_id
from .ledger_config import DEFAULT_LEDGER_CONFIG


# 各追踪 Guide 的"历史字段"名称（对标 C# 各 Guide 的 StateHistory/ProgressPoints/RevealHistory）
# 与"importance 字段"名称（用于裁剪时按重要度分层）
TRACKING_HISTORY_FIELD = {
    "character_state": "StateHistory",
    "conflict_progress": "ProgressPoints",
    "foreshadowing": "StateHistory",
    "plot_points": "StateHistory",
    "location_state": "StateHistory",
    "faction_state": "StateHistory",
    "timeline": "StateHistory",
    "character_location": "MovementHistory",
    "item_state": "StateHistory",
    "secret": "RevealHistory",
    "pledge": "History",
    "deadline": "History",
}

# 各实体"重要性"字段（字符串标签 critical/important 或留空）
TRACKING_IMPORTANCE_FIELD = {
    "character_state": "Importance",
    "conflict_progress": "Importance",
    "foreshadowing": "Importance",
    "plot_points": "Importance",
    "location_state": "Importance",
    "faction_state": "Importance",
    "timeline": "Importance",
    "character_location": "Importance",
    "item_state": "Importance",
    "secret": "Importance",
    "pledge": "Importance",
    "deadline": "Importance",
}


class TrackingManager:
    """统一入口：将归一化后的 CHANGES 写入各追踪 Guide"""

    def __init__(self, project: Project, ledger_config=None):
        self.project = project
        self.ledger_config = ledger_config or DEFAULT_LEDGER_CONFIG
        self._volume_map = {}
        self._stores = {
            "character_state": project.tracking("character_state"),
            "conflict_progress": project.tracking("conflict_progress"),
            "foreshadowing": project.tracking("foreshadowing"),
            "plot_points": project.tracking("plot_points"),
            "location_state": project.tracking("location_state"),
            "faction_state": project.tracking("faction_state"),
            "timeline": project.tracking("timeline"),
            "character_location": project.tracking("character_location"),
            "item_state": project.tracking("item_state"),
            "secret": project.tracking("secret"),
            "pledge": project.tracking("pledge"),
            "deadline": project.tracking("deadline"),
        }

    def set_volume_map(self, volume_map: Dict[int, int]):
        """设置 章号→卷号 映射（供 CharacterStateService 构造 volX_chY ID）"""
        self._volume_map = volume_map or {}

    # ---- 历史记录辅助 ----

    @staticmethod
    def _append_history(entry: dict, history_field: str, record: dict):
        """向实体追加一条历史记录（对标 C# 各 Guide 的 StateHistory 列表）"""
        history = entry.setdefault(history_field, [])
        if not isinstance(history, list):
            history = []
            entry[history_field] = history
        # 去重：与最后一条相同则跳过（避免重复快照）
        if history and history[-1] == record:
            return
        history.append(record)

    @staticmethod
    def _importance_label(importance) -> str:
        """把重要性转成字符串标签 critical/important/其余"""
        if importance is None:
            return ""
        if isinstance(importance, str):
            imp = importance.strip().lower()
            if imp in ("critical", "important"):
                return imp
            return ""
        # int: 原版 4=critical 3=important
        try:
            imp = int(importance)
        except (TypeError, ValueError):
            return ""
        if imp >= 4:
            return "critical"
        if imp == 3:
            return "important"
        return ""

    def update(self, chapter_number: int, changes: ChapterChanges, snapshot: FactSnapshot):
        """对标 UpdateTrackingGuidesAsync: 11维并行写入"""
        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
            futures = [
                pool.submit(self._update_characters, chapter_number, changes, snapshot),
                pool.submit(self._update_conflicts, chapter_number, changes),
                pool.submit(self._update_foreshadowings, chapter_number, changes),
                pool.submit(self._update_plot_points, chapter_number, changes),
                pool.submit(self._update_locations, chapter_number, changes, snapshot),
                pool.submit(self._update_factions, chapter_number, changes),
                pool.submit(self._update_timeline, chapter_number, changes),
                pool.submit(self._update_movements, chapter_number, changes),
                pool.submit(self._update_items, chapter_number, changes, snapshot),
                pool.submit(self._update_secrets, chapter_number, changes, snapshot),
                pool.submit(self._update_pledges, chapter_number, changes),
                pool.submit(self._update_deadlines, chapter_number, changes),
            ]
            for f in concurrent.futures.as_completed(futures):
                f.result()  # raise if any failed
        self.flush()

    def flush(self):
        for store in self._stores.values():
            store.flush()

    # ---- 角色状态（对标 CharacterStateService.UpdateCharacterStateAsync） ----
    def _update_characters(self, chapter_number: int, changes: ChapterChanges, snapshot: FactSnapshot,
                           volume_map: Dict[int, int] = None):
        from .character_state_service import CharacterStateService, build_chapter_id
        svc = CharacterStateService(self.project, self)
        volume_map = volume_map or self._volume_map or {}
        name_by_id = {c.CharacterId: c.Name for c in snapshot.CharacterStates} if snapshot else {}
        for ch in changes.CharacterStateChanges:
            vn = volume_map.get(chapter_number, 1)
            cid = build_chapter_id(vn, chapter_number)
            svc.update_character_state(cid, ch, name_hint=name_by_id.get(ch.CharacterId))

    # ---- 冲突 ----
    def _update_conflicts(self, chapter_number: int, changes: ChapterChanges,
                          volume_map: Dict[int, int] = None):
        """对标 ConflictProgressService.UpdateConflictProgressAsync"""
        from .conflict_progress_service import ConflictProgressService, build_chapter_id
        svc = ConflictProgressService(self.project, self)
        volume_map = volume_map or self._volume_map or {}
        for c in changes.ConflictProgress:
            vn = volume_map.get(chapter_number, 1)
            cid = build_chapter_id(vn, chapter_number)
            svc.update_conflict_progress(cid, c)

    # ---- 伏笔（对标 ForeshadowingStatusService.MarkAsSetup/Resolved） ----
    def _update_foreshadowings(self, chapter_number: int, changes: ChapterChanges,
                               volume_map: Dict[int, int] = None):
        from .foreshadowing_status_service import ForeshadowingStatusService
        from .character_state_service import build_chapter_id
        svc = ForeshadowingStatusService(self.project, self)
        volume_map = volume_map or self._volume_map or {}
        store = self._stores["foreshadowing"]
        data = store.data()
        # 维护 PendingList/OverdueList（对标 C# Guide 结构）
        if "PendingList" not in data:
            data["PendingList"] = []
        if "OverdueList" not in data:
            data["OverdueList"] = []
        pending = data["PendingList"]
        overdue = data["OverdueList"]
        for f in changes.ForeshadowingActions:
            fid = f.ForeshadowId
            vn = volume_map.get(chapter_number, 1)
            cid = build_chapter_id(vn, chapter_number)
            if f.Action == "setup":
                svc.mark_as_setup(fid, cid)
                if fid not in pending:
                    pending.append(fid)
            elif f.Action == "payoff":
                svc.mark_as_resolved(fid, cid)
                if fid in pending:
                    pending.remove(fid)
                if fid in overdue:
                    overdue.remove(fid)
        store.set_all(data)

    # ---- 剧情节点 ----
    def _update_plot_points(self, chapter_number: int, changes: ChapterChanges):
        store = self._stores["plot_points"]
        data = store.data()
        hf = TRACKING_HISTORY_FIELD["plot_points"]
        for p in changes.NewPlotPoints:
            pid = short_id("PP")
            imp_label = "critical" if p.Importance == "critical" else ("important" if p.Importance == "important" else "")
            entry = {
                "Keywords": p.Keywords, "Context": p.Context,
                "InvolvedCharacters": p.InvolvedCharacters, "Storyline": p.Storyline,
                "Chapter": chapter_number, "Importance": 3 if p.Importance in ("critical", "important") else 1,
            }
            data[pid] = entry
            # 情节点本身即为一条历史记录
            self._append_history(entry, hf, {
                "Chapter": chapter_number,
                "Context": p.Context,
                "Importance": imp_label,
            })
        store.set_all(data)

    # ---- 地点状态（对标 LocationStateService.UpdateLocationStateAsync） ----
    def _update_locations(self, chapter_number: int, changes: ChapterChanges, snapshot: FactSnapshot,
                          volume_map: Dict[int, int] = None):
        from .location_state_service import LocationStateService, build_chapter_id
        svc = LocationStateService(self.project, self)
        volume_map = volume_map or self._volume_map or {}
        for l in changes.LocationStateChanges:
            vn = volume_map.get(chapter_number, 1)
            cid = build_chapter_id(vn, chapter_number)
            svc.update_location_state(cid, l)

    # ---- 势力状态（对标 FactionStateService.UpdateFactionStateAsync） ----
    def _update_factions(self, chapter_number: int, changes: ChapterChanges,
                         volume_map: Dict[int, int] = None):
        from .faction_state_service import FactionStateService, build_chapter_id
        svc = FactionStateService(self.project, self)
        volume_map = volume_map or self._volume_map or {}
        for f in changes.FactionStateChanges:
            vn = volume_map.get(chapter_number, 1)
            cid = build_chapter_id(vn, chapter_number)
            svc.update_faction_state(cid, f)

    # ---- 时间线（对标 TimelineService.UpdateTimeProgressionAsync） ----
    def _update_timeline(self, chapter_number: int, changes: ChapterChanges,
                         volume_map: Dict[int, int] = None):
        from .timeline_service import TimelineService, build_chapter_id
        svc = TimelineService(self.project, self)
        volume_map = volume_map or self._volume_map or {}
        for t in changes.TimeProgression:
            vn = volume_map.get(chapter_number, 1)
            cid = build_chapter_id(vn, chapter_number)
            svc.update_time_progression(cid, t)

    # ---- 角色移动（对标 TimelineService.UpdateCharacterMovementsAsync） ----
    def _update_movements(self, chapter_number: int, changes: ChapterChanges,
                          volume_map: Dict[int, int] = None):
        from .timeline_service import TimelineService, build_chapter_id
        svc = TimelineService(self.project, self)
        volume_map = volume_map or self._volume_map or {}
        cid = build_chapter_id(volume_map.get(chapter_number, 1), chapter_number)
        svc.update_character_movements(cid, changes.CharacterMovements)

    # ---- 物品（对标 ItemStateService.UpdateItemStateAsync） ----
    def _update_items(self, chapter_number: int, changes: ChapterChanges, snapshot: FactSnapshot,
                      volume_map: Dict[int, int] = None):
        from .item_state_service import ItemStateService, build_chapter_id
        svc = ItemStateService(self.project, self)
        volume_map = volume_map or self._volume_map or {}
        for i in changes.ItemTransfers:
            vn = volume_map.get(chapter_number, 1)
            cid = build_chapter_id(vn, chapter_number)
            svc.update_item_state(cid, i)

    # ---- 秘密（对标 SecretRevealService.UpdateSecretRevealAsync） ----
    def _update_secrets(self, chapter_number: int, changes: ChapterChanges, snapshot: FactSnapshot,
                        volume_map: Dict[int, int] = None):
        from .secret_reveal_service import SecretRevealService, build_chapter_id
        svc = SecretRevealService(self.project, self)
        volume_map = volume_map or self._volume_map or {}
        for s in changes.SecretRevealChanges:
            vn = volume_map.get(chapter_number, 1)
            cid = build_chapter_id(vn, chapter_number)
            svc.update_secret_reveal(cid, s)

    # ---- 誓约（对标 PledgeConstraintService.UpdatePledgeAsync） ----
    def _update_pledges(self, chapter_number: int, changes: ChapterChanges,
                        volume_map: Dict[int, int] = None):
        from .pledge_constraint_service import PledgeConstraintService, build_chapter_id
        svc = PledgeConstraintService(self.project, self)
        volume_map = volume_map or self._volume_map or {}
        for p in changes.PledgeConstraintChanges:
            vn = volume_map.get(chapter_number, 1)
            cid = build_chapter_id(vn, chapter_number)
            svc.update_pledge(cid, p)

    # ---- 倒计时（对标 DeadlineConstraintService.UpdateDeadlineAsync） ----
    def _update_deadlines(self, chapter_number: int, changes: ChapterChanges,
                          volume_map: Dict[int, int] = None):
        from .deadline_constraint_service import DeadlineConstraintService, build_chapter_id
        svc = DeadlineConstraintService(self.project, self)
        volume_map = volume_map or self._volume_map or {}
        for d in changes.DeadlineConstraintChanges:
            vn = volume_map.get(chapter_number, 1)
            cid = build_chapter_id(vn, chapter_number)
            svc.update_deadline(cid, d)

    # ---- 逾期刷新（对标 ForeshadowingStatusService.RefreshOverdueStatusAsync） ----
    def refresh_overdue_status(self, chapter_number: int):
        """刷新伏笔逾期状态：按章节ID比较判定（已回收取消逾期，超过预期回收章标记逾期）"""
        from .foreshadowing_status_service import ForeshadowingStatusService
        from .character_state_service import build_chapter_id
        vn = self._volume_map.get(chapter_number, 1)
        cid = build_chapter_id(vn, chapter_number)
        svc = ForeshadowingStatusService(self.project, self)
        svc.refresh_overdue_status(cid)
        # 同步 OverdueList（对标 C# OverdueList）
        fs_store = self._stores["foreshadowing"]
        fs_data = fs_store.data()
        if "OverdueList" not in fs_data:
            fs_data["OverdueList"] = []
        overdue = fs_data["OverdueList"]
        modified = False
        for fid, entry in list(fs_data.items()):
            if fid in ("PendingList", "OverdueList") or not isinstance(entry, dict):
                continue
            if entry.get("IsOverdue") and fid not in overdue:
                overdue.append(fid)
                modified = True
            elif not entry.get("IsOverdue") and fid in overdue:
                overdue.remove(fid)
                modified = True
        if modified:
            fs_store.set_all(fs_data)

    # ---- 账本裁剪（对标 LedgerTrimService.TrimAllAsync） ----
    def trim_ledger(self, chapter_number: int = 0):
        """完整 12 维账本裁剪，含锚点采样与情节点升级（对标 C# LedgerTrimService）

        调用时机：每章生成后（由 writer.py 触发）
        """
        from .ledger_trim import LedgerTrimService
        svc = LedgerTrimService(self, self.ledger_config)
        result = svc.trim_all()
        if result["total_trimmed"] > 0:
            for store_name in result["dirty_stores"]:
                store = self._stores.get(store_name)
                if store:
                    store.flush()
        return result
