# -*- coding: utf-8 -*-
"""账本规则集 — 对标 4.1.1 Rules/LedgerRuleSet.cs（完整移植）

对齐功能:
- LedgerRuleSet.CreateUniversalDefault（通用默认规则）
- MaxTrustDelta / EnableConflictFlowCheck / ConflictStatusSequence
- EnableLevelRegressionCheck / LevelTextMap
- EnableAbilityLossRequiresEvent / AbilityLossKeywords
- EnablePledgeConstraintCheck / EnableDeadlineConstraintCheck
"""

from typing import Dict, List


class LedgerRuleSet:
    """对标 C# LedgerRuleSet"""

    def __init__(self):
        self.MaxTrustDelta: int = 30
        self.EnableConflictFlowCheck: bool = False
        self.ConflictStatusSequence: List[str] = []
        self.EnableLevelRegressionCheck: bool = False
        self.LevelTextMap: Dict[str, int] = {}
        self.EnableAbilityLossRequiresEvent: bool = False
        self.AbilityLossKeywords: List[str] = []
        self.EnablePledgeConstraintCheck: bool = False
        self.EnableDeadlineConstraintCheck: bool = False

    @staticmethod
    def create_universal_default() -> "LedgerRuleSet":
        """对标 CreateUniversalDefault"""
        rs = LedgerRuleSet()
        rs.MaxTrustDelta = 30
        rs.EnableConflictFlowCheck = True
        rs.ConflictStatusSequence = ["pending", "active", "climax", "resolved"]
        rs.EnableLevelRegressionCheck = True
        rs.LevelTextMap = {
            "SSS": 60, "SS": 50, "S": 40, "A": 30, "B": 20,
            "C": 10, "D": 0, "E": 0, "F": 0,
            "Tier-1": 10, "Tier-2": 20, "Tier-3": 30, "Tier-4": 40, "Tier-5": 50,
        }
        rs.EnableAbilityLossRequiresEvent = False
        rs.AbilityLossKeywords = []
        rs.EnablePledgeConstraintCheck = True
        rs.EnableDeadlineConstraintCheck = True
        return rs