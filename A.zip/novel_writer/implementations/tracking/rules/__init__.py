# -*- coding: utf-8 -*-
"""账本规则集子包 — 对标 4.1.1 Tracking/Rules 目录

- LedgerRuleSet（规则集模型 + 通用默认）
- LedgerRuleSetProvider（按题材构建规则集）
- build_ruleset_by_genre（按题材规则）
"""

from .ledger_rule_set import LedgerRuleSet
from .ledger_rule_set_provider import (
    LedgerRuleSetProvider, build_ruleset_by_genre,
    XIANXIA_ABILITY_LOSS_KEYWORDS, URBAN_ABILITY_LOSS_KEYWORDS,
)

__all__ = [
    "LedgerRuleSet", "LedgerRuleSetProvider", "build_ruleset_by_genre",
    "XIANXIA_ABILITY_LOSS_KEYWORDS", "URBAN_ABILITY_LOSS_KEYWORDS",
]