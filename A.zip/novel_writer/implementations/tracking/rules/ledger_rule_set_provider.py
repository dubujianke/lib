# -*- coding: utf-8 -*-
"""账本规则集提供器 — 对标 4.1.1 Rules/LedgerRuleSetProvider.cs（完整移植）

对齐功能:
- GetRuleSetForGateAsync（按题材缓存规则集）
- TryResolveGenreFromEnabledCreativeMaterialsAsync（题材解析）
- BuildRuleSetByGenre（玄幻/都市关键词集）
"""

from typing import List, Optional

from .ledger_rule_set import LedgerRuleSet

# 对标 C# BuildRuleSetByGenre: 玄幻/奇幻/仙侠/武侠 → 修炼系关键词
XIANXIA_ABILITY_LOSS_KEYWORDS = [
    "失去", "丧失", "消散", "失效",
    "封印", "封禁", "封锁",
    "剥夺", "废除", "废功", "自废", "散功",
    "退化", "降级", "削弱", "削减",
    "代价", "反噬", "牺牲", "透支", "燃烧", "燃血", "燃魂",
    "重创", "重伤", "受创", "道伤", "损伤", "损耗",
    "走火入魔", "心魔", "夺走", "抽离", "抽取",
]

# 对标 C# BuildRuleSetByGenre: 都市/现实 → 职场系关键词
URBAN_ABILITY_LOSS_KEYWORDS = [
    "失去", "丧失", "失效", "作废", "禁用",
    "封号", "封禁", "冻结",
    "停职", "撤职", "革职", "解雇", "辞退",
    "权限回收", "取消资格", "剥夺", "降级",
    "注销", "吊销", "取缔", "罢免",
    "解约", "解聘", "解除", "终止",
    "黑名单", "出局", "代价", "牺牲",
]


def _contains_any(text: str, *keywords) -> bool:
    if not text:
        return False
    low = text.lower()
    for k in keywords:
        if k and k.lower() in low:
            return True
    return False


def build_ruleset_by_genre(genre: Optional[str]) -> LedgerRuleSet:
    """对标 BuildRuleSetByGenre: 按题材构建规则集"""
    if not genre:
        return LedgerRuleSet.create_universal_default()
    g = genre.strip()

    if _contains_any(g, "玄幻", "奇幻", "仙侠", "武侠"):
        rs = LedgerRuleSet.create_universal_default()
        rs.EnableAbilityLossRequiresEvent = True
        rs.AbilityLossKeywords = list(XIANXIA_ABILITY_LOSS_KEYWORDS)
        return rs

    if _contains_any(g, "都市", "现实"):
        rs = LedgerRuleSet.create_universal_default()
        rs.EnableAbilityLossRequiresEvent = True
        rs.AbilityLossKeywords = list(URBAN_ABILITY_LOSS_KEYWORDS)
        return rs

    return LedgerRuleSet.create_universal_default()


class LedgerRuleSetProvider:
    """对标 C# LedgerRuleSetProvider: 按题材缓存规则集"""

    def __init__(self, project=None):
        self.project = project
        self._cached_genre: Optional[str] = None
        self._cached_ruleset: Optional[LedgerRuleSet] = None

    def _resolve_genre_from_creative_materials(self) -> Optional[str]:
        """对标 TryResolveGenreFromEnabledCreativeMaterialsAsync"""
        try:
            if self.project is None:
                return None
            materials = self.project.load_design("materials")
            if isinstance(materials, dict):
                items = materials.get("items", [])
            else:
                items = materials or []
            enabled = [i for i in items if isinstance(i, dict) and i.get("IsEnabled")]
            if not enabled:
                return None
            # 对标 OrderByDescending(ModifiedTime).FirstOrDefault()
            enabled.sort(key=lambda i: str(i.get("ModifiedTime", "")), reverse=True)
            genre = enabled[0].get("Genre", "")
            return genre.strip() if genre else None
        except Exception:
            return None

    def get_ruleset_for_gate(self) -> LedgerRuleSet:
        """对标 GetRuleSetForGateAsync"""
        try:
            genre = self._resolve_genre_from_creative_materials()
            if self._cached_ruleset is not None and genre == self._cached_genre:
                return self._cached_ruleset
            ruleset = build_ruleset_by_genre(genre)
            self._cached_genre = genre
            self._cached_ruleset = ruleset
            return ruleset
        except Exception:
            return LedgerRuleSet.create_universal_default()