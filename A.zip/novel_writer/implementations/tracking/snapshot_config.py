# -*- coding: utf-8 -*-
"""快照注入配置 — 对标 4.1.1 GuideContextService.SnapshotMax*（默认值对齐）"""


class SnapshotConfig:
    """对标 LayeredContextConfigSnapshot 的快照注入上限"""

    def __init__(self, **kwargs):
        # 对标 GuideContextService.cs 默认值
        self.SnapshotMaxCharacterInject = kwargs.pop("SnapshotMaxCharacterInject", 50)
        self.SnapshotMaxLocationInject = kwargs.pop("SnapshotMaxLocationInject", 30)
        self.SnapshotMaxConflictInject = kwargs.pop("SnapshotMaxConflictInject", 20)
        self.SnapshotMaxForeshadowInject = kwargs.pop("SnapshotMaxForeshadowInject", 30)
        self.SnapshotMaxSecretInject = kwargs.pop("SnapshotMaxSecretInject", 20)
        self.SnapshotMaxPledgeInject = kwargs.pop("SnapshotMaxPledgeInject", 15)
        self.SnapshotMaxDeadlineInject = kwargs.pop("SnapshotMaxDeadlineInject", 15)
        # 补充（C# 也定义，默认值 GuideContextService.cs:65-67）
        self.SnapshotMaxFactionInject = kwargs.pop("SnapshotMaxFactionInject", 30)
        self.SnapshotMaxItemInject = kwargs.pop("SnapshotMaxItemInject", 50)
        self.SnapshotMaxTimelineInject = kwargs.pop("SnapshotMaxTimelineInject", 5)
        self.SnapshotMaxPlotInject = kwargs.pop("SnapshotMaxPlotInject", 15)
        # 活跃实体窗口（GuideContextService.cs:29-31）
        self.ActiveEntityWindowChapters = kwargs.pop("ActiveEntityWindowChapters", 8)
        self.ActiveEntityWindowMaxCount = kwargs.pop("ActiveEntityWindowMaxCount", 25)


DEFAULT_SNAPSHOT_CONFIG = SnapshotConfig()