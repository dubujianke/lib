# -*- coding: utf-8 -*-
"""角色状态服务 — 对标 4.1.1 CharacterStateService.cs（独立类，完整移植 276 行）

对齐功能:
- GetCharacterStateAtAsync + BinarySearchState（按章二分查询历史）
- CompareChapterId / ParseChapterIdOrDefault / BuildChapterId（章节ID解析比较）
- UpdateCharacterStateAsync（自动注册 + Phase推导 + MergeAbilities + MergeRelationships + 自动升级 + 排序）
- RemoveChapterDataAsync（删除某章状态并重排）
- GetPhaseFromChapter（起承转合）
- MergeAbilities / MergeRelationships
- TryResolveCharacterDisplayNameAsync
- _escalationKeywords 自动升级（27个关键词）

章节ID约定：vol{卷号}_ch{章号}（对齐 C# ChapterParserHelper），
由 ChapterData.VolumeNumber + ChapterNumber 构造。
"""

import re
from typing import Dict, List, Optional

# 对标 C# _escalationKeywords（自动升级为 important）
_ESCALATION_KEYWORDS = [
    "首次", "第一次", "突破", "觉醒", "死亡", "牺牲", "背叛", "结盟",
    "失忆", "失去", "变心", "决裂", "和解", "永久", "不可逆",
    "升级", "破境", "化神", "晋升", "晋级", "反目", "绝交", "重逢",
    "拜师", "出师", "入门", "逐出", "认主", "解封", "归隐",
]

# ---- 章节ID解析（对标 ChapterParserHelper） ----

_VOL_CH_RE = re.compile(r"vol(\d+)_ch(\d+)", re.IGNORECASE)
_VC_RE = re.compile(r"v(\d+)_c(\d+)", re.IGNORECASE)
_NUM_NUM_RE = re.compile(r"(\d+)_(\d+)")


def parse_chapter_id(chapter_id: str) -> tuple:
    """对标 ParseChapterIdOrDefault: 解析章节ID → (卷号, 章号)，失败返回 (0,0)"""
    if not chapter_id:
        return (0, 0)
    m = _VOL_CH_RE.match(chapter_id)
    if m:
        return (int(m.group(1)), int(m.group(2)))
    m = _VC_RE.match(chapter_id)
    if m:
        return (int(m.group(1)), int(m.group(2)))
    m = _NUM_NUM_RE.match(chapter_id)
    if m:
        return (int(m.group(1)), int(m.group(2)))
    return (0, 0)


def compare_chapter_id(a: str, b: str) -> int:
    """对标 CompareChapterId: 卷号优先，其次章号"""
    va, ca = parse_chapter_id(a)
    vb, cb = parse_chapter_id(b)
    if va != vb:
        return (va > vb) - (va < vb)
    return (ca > cb) - (ca < cb)


def build_chapter_id(volume_number: int, chapter_number: int) -> str:
    """对标 BuildChapterId: vol{vol}_ch{ch}"""
    return f"vol{volume_number}_ch{chapter_number}"


class CharacterStateService:
    """对标 4.1.1 CharacterStateService — 角色状态历史管理（独立类）

    调用链与 C# 完全一致：
    - 读: GuideManager.GetExistingVolumeNumbers + GetVolumeFileName + GetGuideAsync<CharacterStateGuide>
    - 写: GuideManager.MarkDirty(volFile)
    """

    BaseFileName = "character_state_guide.json"
    HISTORY_FIELD = "StateHistory"

    def __init__(self, project, tracking_manager=None, guide_manager=None):
        self.project = project
        self.tracking = tracking_manager
        self._store = None
        # 对标 C# _guideManager（未提供时延迟创建）
        self._guide_manager = guide_manager

    def _get_guide_manager(self):
        if self._guide_manager is None:
            try:
                from ..guides.guide_manager import GuideManager
                self._guide_manager = GuideManager(self.project)
            except Exception:
                return None
        return self._guide_manager

    @classmethod
    def _volume_file_name(cls, chapter_id: str) -> str:
        """对标 C# VolumeFileName(chapterId): GuideManager.GetVolumeFileName(BaseFileName, vol)"""
        from ..guides.guide_manager import GuideManager
        vol, _ = parse_chapter_id(chapter_id)
        return GuideManager.get_volume_file_name(cls.BaseFileName, vol)

    # ---- store 访问（兼容旧路径） ----
    # 对标 C# GuideManager.GetGuideAsync<CharacterStateGuide>(VolumeFileName)

    def _get_store(self):
        if self._store is None:
            if self.tracking is not None:
                self._store = self.tracking._stores["character_state"]
            else:
                self._store = self.project.tracking("character_state")
        return self._store

    # ---- 按章查询 ----

    def get_character_state_at(self, character_id: str, chapter_id: str) -> Optional[dict]:
        """对标 GetCharacterStateAtAsync: 先走 GuideManager 分卷（倒序），回退 store"""
        gm = self._get_guide_manager()
        if gm is not None:
            try:
                # 对标: var volNumbers = _guideManager.GetExistingVolumeNumbers(BaseFileName)
                vol_numbers = gm.get_existing_volume_numbers(self.BaseFileName)
                target_vol, _ = parse_chapter_id(chapter_id)
                for vol in sorted((v for v in vol_numbers if v <= target_vol), reverse=True):
                    vol_file = gm.get_volume_file_name(self.BaseFileName, vol)
                    guide = gm.get_guide(vol_file)
                    if not isinstance(guide, dict):
                        continue
                    entry = (guide.get("Characters") or {}).get(character_id)
                    if not isinstance(entry, dict):
                        continue
                    history = entry.get(self.HISTORY_FIELD)
                    if not isinstance(history, list) or not history:
                        continue
                    state = self._binary_search_state(history, chapter_id)
                    if state is not None:
                        return state
                # 分卷文件中未找到时回退 store
            except Exception:
                pass
        store = self._get_store()
        data = store.data()
        entry = data.get(character_id)
        if not isinstance(entry, dict):
            return None
        history = entry.get(self.HISTORY_FIELD)
        if not isinstance(history, list) or not history:
            return None
        return self._binary_search_state(history, chapter_id)

    @staticmethod
    def _binary_search_state(history: list, target_chapter_id: str) -> Optional[dict]:
        """对标 BinarySearchState: 二分查找 <= target 的最新历史记录"""
        left, right = 0, len(history) - 1
        result_index = -1
        while left <= right:
            mid = (left + right) // 2
            cmp_result = compare_chapter_id(history[mid].get("Chapter", ""), target_chapter_id)
            if cmp_result <= 0:
                result_index = mid
                left = mid + 1
            else:
                right = mid - 1
        return history[result_index] if result_index >= 0 else None

    # ---- 更新状态 ----

    def update_character_state(self, chapter_id: str, change, name_hint: str = None) -> dict:
        """对标 UpdateCharacterStateAsync: 更新/注册角色状态并追加完整快照

        change: CharacterStateChange（CharacterId/NewLevel/NewAbilities/LostAbilities/
                RelationshipChanges/NewMentalState/KeyEvent/Importance/CausedBy）
        chapter_id: vol{卷号}_ch{章号} 格式
        name_hint: 角色名兜底（来自写前快照），优先于 ID
        """
        store = self._get_store()
        data = store.data()

        # 自动注册新角色（对标 C#: 无则注册 + TryResolveCharacterDisplayNameAsync）
        if change.CharacterId not in data:
            display_name = (name_hint or self.try_resolve_display_name(change.CharacterId)
                            or change.CharacterId)
            data[change.CharacterId] = {
                "Name": display_name, "Level": "", "Phase": "", "Abilities": [],
                "LostAbilities": [], "MentalState": "", "KeyEvent": "", "LastChapter": 0,
                "Importance": 0, "Relationships": {},
            }

        entry = data[change.CharacterId]
        history = entry.setdefault(self.HISTORY_FIELD, [])
        if not isinstance(history, list):
            history = []
            entry[self.HISTORY_FIELD] = history

        last_state = history[-1] if history else None

        # 构建完整快照（对标 C# CharacterState 各字段）
        new_state = {
            "Chapter": chapter_id,
            "Phase": self.get_phase_from_chapter(chapter_id),
            "Level": change.NewLevel if change.NewLevel else (last_state.get("Level", "") if last_state else ""),
            "Abilities": self.merge_abilities(
                last_state.get("Abilities") if last_state else None,
                change.NewAbilities,
                change.LostAbilities),
            "Relationships": self.merge_relationships(
                last_state.get("Relationships") if last_state else None,
                change.RelationshipChanges),
            "MentalState": change.NewMentalState if change.NewMentalState else (last_state.get("MentalState", "") if last_state else ""),
            "KeyEvent": change.KeyEvent,
            "Importance": change.Importance if change.Importance else "normal",
            "CausedBy": change.CausedBy or "",
        }

        # 自动升级（对标 C#: KeyEvent>=20字 且命中关键词 → important）
        if (new_state["Importance"] == "normal"
                and new_state.get("KeyEvent")
                and len(new_state["KeyEvent"]) >= 20
                and any(k in new_state["KeyEvent"] for k in _ESCALATION_KEYWORDS)):
            new_state["Importance"] = "important"

        history.append(new_state)

        # 追加后按章排序（对标 C#: 新章 < 前章 时 Sort）
        if len(history) > 1 and compare_chapter_id(new_state["Chapter"], history[-2]["Chapter"]) < 0:
            history.sort(key=lambda h: parse_chapter_id(h.get("Chapter", "")))

        # 同步顶层字段（最新状态镜像，供 snapshot_extractor 等读取）
        entry["Level"] = new_state["Level"]
        entry["Phase"] = new_state["Phase"]
        entry["Abilities"] = list(new_state["Abilities"])
        entry["MentalState"] = new_state["MentalState"]
        entry["KeyEvent"] = new_state["KeyEvent"]
        entry["LastChapter"] = parse_chapter_id(chapter_id)[1]
        entry["Importance"] = max(int(entry.get("Importance", 0) or 0),
                                  4 if new_state["Importance"] == "critical"
                                  else (3 if new_state["Importance"] == "important" else 0))
        entry["Relationships"] = new_state["Relationships"]

        store.set_all(data)

        # 对标 C#: _guideManager.MarkDirty(volFile)
        gm = self._get_guide_manager()
        if gm is not None:
            try:
                vol_file = self._volume_file_name(chapter_id)
                guide = gm.get_guide(vol_file)
                # 同步到分卷 guide（Characters 字典 + StateHistory）
                if isinstance(guide, dict):
                    characters = guide.setdefault("Characters", {})
                    entry = characters.get(change.CharacterId)
                    if not isinstance(entry, dict):
                        characters[change.CharacterId] = {"Name": data[change.CharacterId].get("Name", ""), self.HISTORY_FIELD: [new_state]}
                    else:
                        history = entry.setdefault(self.HISTORY_FIELD, [])
                        history.append(new_state)
                        if len(history) > 1 and compare_chapter_id(new_state["Chapter"], history[-2].get("Chapter", "")) < 0:
                            history.sort(key=lambda h: parse_chapter_id(h.get("Chapter", "")))
                    gm.mark_dirty(vol_file)
            except Exception:
                pass

        return new_state

    # ---- 删除章节数据 ----

    def remove_chapter_data(self, chapter_id: str) -> int:
        """对标 RemoveChapterDataAsync: 删除指定章节的所有角色状态记录并重排"""
        store = self._get_store()
        data = store.data()
        modified = False
        removed_total = 0
        for entry in list(data.values()):
            if not isinstance(entry, dict):
                continue
            history = entry.get(self.HISTORY_FIELD)
            if not isinstance(history, list) or not history:
                continue
            before = len(history)
            history[:] = [s for s in history
                          if not (s.get("Chapter", "") and s["Chapter"] == chapter_id)]
            removed = before - len(history)
            if removed > 0:
                modified = True
                removed_total += removed
                history.sort(key=lambda h: parse_chapter_id(h.get("Chapter", "")))
        if modified:
            store.set_all(data)
            # 对标 C#: _guideManager.MarkDirty(volFile)
            gm = self._get_guide_manager()
            if gm is not None:
                try:
                    vol_file = self._volume_file_name(chapter_id)
                    guide = gm.get_guide(vol_file)
                    if isinstance(guide, dict):
                        g_modified = False
                        for entry in (guide.get("Characters") or {}).values():
                            if not isinstance(entry, dict):
                                continue
                            history = entry.get(self.HISTORY_FIELD)
                            if not isinstance(history, list):
                                continue
                            before = len(history)
                            history[:] = [s for s in history if s.get("Chapter", "") != chapter_id]
                            if len(history) < before:
                                g_modified = True
                                history.sort(key=lambda h: parse_chapter_id(h.get("Chapter", "")))
                        if g_modified:
                            gm.mark_dirty(vol_file)
                except Exception:
                    pass
        return removed_total

    # ---- Phase 推导 ----

    def get_phase_from_chapter(self, chapter_id: str) -> str:
        """对标 GetPhaseFromChapter: 按卷号/总卷数比例返回 起承转合"""
        vol, _ = parse_chapter_id(chapter_id)
        try:
            volumes = self.project.load_plan("volumes")
            if isinstance(volumes, dict):
                volumes = volumes.get("volumes", [])
            total_vols = len(volumes) if volumes else 0
            if total_vols <= 0:
                total_vols = 4
            ratio = vol / total_vols
            if ratio <= 0.25:
                return "起"
            if ratio <= 0.50:
                return "承"
            if ratio <= 0.75:
                return "转"
            return "合"
        except Exception:
            return {1: "起", 2: "承", 3: "转"}.get(vol, "合")

    # ---- 合并（对标 C# MergeAbilities / MergeRelationships） ----

    @staticmethod
    def merge_abilities(existing: Optional[list], new_abilities: Optional[list],
                        lost_abilities: Optional[list]) -> List[str]:
        """对标 MergeAbilities: HashSet(OrdinalIgnoreCase) 加新删旧 + Trim"""
        # 用小写做大小写不敏感去重，先到优先（保留首次出现的大小写）
        result = {}
        for ability in (existing or []):
            if ability and str(ability).strip():
                key = str(ability).strip().lower()
                if key not in result:
                    result[key] = str(ability).strip()
        if new_abilities:
            for ability in new_abilities:
                if ability and str(ability).strip():
                    key = str(ability).strip().lower()
                    if key not in result:
                        result[key] = str(ability).strip()
        if lost_abilities:
            for ability in lost_abilities:
                if ability and str(ability).strip():
                    result.pop(str(ability).strip().lower(), None)
        return list(result.values())

    @staticmethod
    def merge_relationships(existing: Optional[dict], changes: Optional[dict]) -> Dict[str, dict]:
        result = dict(existing or {})
        if changes:
            for target_id, change in changes.items():
                if target_id in result:
                    cur = result[target_id]
                    if not isinstance(cur, dict):
                        cur = {"Relation": "", "Trust": 0, "EmotionPhase": ""}
                        result[target_id] = cur
                    if change.Relation:
                        cur["Relation"] = change.Relation
                    cur["Trust"] = int(cur.get("Trust", 0)) + int(change.TrustDelta or 0)
                    if change.EmotionPhase:
                        cur["EmotionPhase"] = change.EmotionPhase
                else:
                    result[target_id] = {
                        "Relation": change.Relation,
                        "Trust": int(change.TrustDelta or 0),
                        "EmotionPhase": change.EmotionPhase,
                    }
        return result

    # ---- 角色名解析（对标 TryResolveCharacterDisplayNameAsync） ----

    def try_resolve_display_name(self, character_id: str) -> Optional[str]:
        try:
            design = self.project.load_design("characters")
            items = design.get("items", []) if isinstance(design, dict) else (design or [])
            for item in items:
                if not isinstance(item, dict):
                    continue
                if str(item.get("Id", "")).lower() == str(character_id).lower():
                    name = item.get("Name", "")
                    return name if name else None
            return None
        except Exception:
            return None