# -*- coding: utf-8 -*-
"""对标 Tracking/FactSnapshotExtractor.cs（含各 partial 分片合并实现）

实现文件为 snapshot_extractor.py（SnapshotExtractor，15维快照并行抽取），
本文件提供与 C# 主文件名一致的入口，保证目录结构一一对应。
"""
from .snapshot_extractor import SnapshotExtractor

__all__ = ["SnapshotExtractor"]