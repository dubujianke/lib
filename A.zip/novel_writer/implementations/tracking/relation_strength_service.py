# -*- coding: utf-8 -*-
"""关系强度服务 — 对标 4.1.1 RelationStrengthService.cs（完整移植 499 行）

对齐功能:
- GetStrengthAsync（先查索引，否则实时计算）
- BuildStrengthIndexAsync（剧情 Strong + 蓝图 Medium 构建索引）
- ComputeStrengthRealtimeAsync（显式关系/剧情/蓝图合并）
- RelationStrengthIndex（Pairs 索引 + Upgrade/EnsureMin/Get）
- 缓存机制（30s 过期 + epoch 失效 + 锁）
- DetermineStrengthByRelationType / ApplyStrengthHint / GetPairKey
"""

import json
import os
import threading
import time
from typing import Dict, List, Optional

from .deadline_constraint_service import _is_likely_id

# 对标 C# RelationStrength 枚举
WEAK = 0
MEDIUM = 1
STRONG = 2

# 对标 C#: 显式关系类型 → 基础强度
_STRONG_RELATION_TYPES = {"仇敌", "师徒", "恋人", "血亲", "宿敌"}
_MEDIUM_RELATION_TYPES = {"同门", "战友", "同阵营", "朋友"}


def determine_strength_by_relation_type(relation_type: str) -> int:
    """对标 DetermineStrengthByRelationType"""
    if not relation_type:
        return WEAK
    if relation_type in _STRONG_RELATION_TYPES:
        return STRONG
    if relation_type in _MEDIUM_RELATION_TYPES:
        return MEDIUM
    return WEAK


def apply_strength_hint(base_strength: int, strength_hint: Optional[str]) -> int:
    """对标 ApplyStrengthHint: "Strong"→Strong, "Medium"且base<Medium→Medium, 否则不变"""
    if not strength_hint:
        return base_strength
    hint = strength_hint.strip()
    if hint == "Strong":
        return STRONG
    if hint == "Medium" and base_strength < MEDIUM:
        return MEDIUM
    return base_strength


def get_pair_key(id1: str, id2: str) -> str:
    """对标 GetPairKey: 字典序小的在前"""
    return f"{id1}_{id2}" if id1 < id2 else f"{id2}_{id1}"


class RelationStrengthIndex:
    """对标 C# RelationStrengthIndex — 角色对强度索引"""

    def __init__(self, pairs: Optional[Dict[str, int]] = None):
        self.Pairs: Dict[str, int] = pairs or {}

    def add_pair(self, id1: str, id2: str, strength: int):
        self.Pairs[get_pair_key(id1, id2)] = strength

    def upgrade_strength(self, id1: str, id2: str, new_strength: int):
        """对标 UpgradeStrength: 取较大值"""
        key = get_pair_key(id1, id2)
        cur = self.Pairs.get(key, WEAK)
        if cur < new_strength:
            self.Pairs[key] = new_strength

    def ensure_min_strength(self, id1: str, id2: str, min_strength: int):
        """对标 EnsureMinStrength: 不存在才设置保底"""
        key = get_pair_key(id1, id2)
        if key not in self.Pairs:
            self.Pairs[key] = min_strength

    def get_strength(self, id1: str, id2: str) -> int:
        return self.Pairs.get(get_pair_key(id1, id2), WEAK)

    def to_dict(self) -> dict:
        return {"Pairs": self.Pairs}

    @classmethod
    def from_dict(cls, data: dict) -> "RelationStrengthIndex":
        pairs = data.get("Pairs", {}) if isinstance(data, dict) else {}
        return cls({str(k): int(v) for k, v in pairs.items()})


def split_names(text: Optional[str]) -> List[str]:
    """对标 SplitNames: 按常见分隔符拆分 + 去重"""
    if not text:
        return []
    import re
    parts = re.split(r"[,，、;；\n]", text)
    result = []
    seen = set()
    for p in parts:
        t = p.strip()
        if t and t.lower() not in seen:
            seen.add(t.lower())
            result.append(t)
    return result


class RelationStrengthService:
    """对标 4.1.1 RelationStrengthService — 关系强度计算（独立类）"""

    CACHE_DURATION_SECONDS = 30.0

    def __init__(self, project, use_cache: bool = True):
        self.project = project
        self.use_cache = use_cache
        # 索引缓存
        self._cached_index: Optional[RelationStrengthIndex] = None
        self._index_loaded = False
        self._index_load_lock = threading.Lock()
        # 数据源缓存
        self._relationships_cache: Optional[List[dict]] = None
        self._explicit_relations_cache: Optional[Dict[str, dict]] = None
        self._plot_rules_cache: Optional[List[dict]] = None
        self._blueprints_cache: Optional[List[dict]] = None
        self._cache_expiry = 0.0
        self._cache_load_lock = threading.Lock()
        self._epoch = 0

    # ---- 数据源加载 ----

    def _load_plot_rules(self) -> List[dict]:
        """对标 LoadPlotRulesAsync: 设计库 plot"""
        try:
            design = self.project.load_design("plot")
            items = design.get("items", []) if isinstance(design, dict) else (design or [])
            return [i for i in items if isinstance(i, dict)]
        except Exception:
            return []

    def _load_blueprints(self) -> List[dict]:
        """对标 LoadBlueprintsAsync: plan/blueprints_{chapterId}"""
        try:
            plans = self.project.load_plan("chapters")
            chapters = plans.get("chapters", []) if isinstance(plans, dict) else (plans or [])
            result = []
            for c in chapters:
                cid = c.get("Id", "")
                if not cid:
                    continue
                data = self.project.load_plan(f"blueprints_{cid}")
                if isinstance(data, list):
                    result.extend([b for b in data if isinstance(b, dict)])
            return result
        except Exception:
            return []

    def _load_character_relationships(self) -> List[dict]:
        """对标 LoadCharacterRelationshipsAsync: 设计库 characters"""
        try:
            design = self.project.load_design("characters")
            items = design.get("items", []) if isinstance(design, dict) else (design or [])
            return [i for i in items if isinstance(i, dict)]
        except Exception:
            return []

    # ---- 显式关系构建 ----

    @staticmethod
    def _extract_ids_from_text(cast: object) -> List[str]:
        """对标 ExtractIdsFromText: 蓝图 Cast → ID 列表

        Python BlueprintData.Cast 已是 ID 列表；兼容字符串形式。
        """
        if isinstance(cast, list):
            return [str(x) for x in cast if x and str(x).strip()]
        if isinstance(cast, str):
            return split_names(cast)
        return []

    def build_explicit_relations(self, character_rules: Optional[List[dict]]) -> Dict[str, dict]:
        """对标 BuildExplicitRelations: 从角色规则构建显式关系映射"""
        result: Dict[str, dict] = {}
        if not character_rules:
            return result

        for data in character_rules:
            char_id = str(data.get("Id", "") or "")
            target = str(data.get("TargetCharacterName", "") or "")
            if not char_id or not target:
                continue
            rel_type = str(data.get("RelationshipType", "") or "")
            base_strength = determine_strength_by_relation_type(rel_type)
            if base_strength <= WEAK:
                continue
            # 目标必须是合法短 ID（对标 C# IsLikelyId）
            if not _is_likely_id(target):
                continue

            key = get_pair_key(char_id, target)
            existing = result.get(key)
            if existing:
                existing_strength = determine_strength_by_relation_type(existing.get("RelationType", ""))
                if existing_strength >= base_strength:
                    continue
            result[key] = {"RelationType": rel_type, "StrengthHint": None}

        return result

    @staticmethod
    def get_participants(plot_rule: dict) -> List[str]:
        """对标 GetParticipants: 剧情规则的 MainCharacters → 参与角色 ID 列表"""
        mc = plot_rule.get("MainCharacters")
        if isinstance(mc, list):
            return [str(x).strip() for x in mc if x and str(x).strip()]
        if isinstance(mc, str):
            return split_names(mc)
        return []

    # ---- 缓存 ----

    def _ensure_cache_loaded(self):
        """对标 EnsureCacheLoadedAsync: 30s 过期 + 锁 + epoch 校验"""
        if self.use_cache and self._cache_expiry > time.time():
            return
        with self._cache_load_lock:
            if self.use_cache and self._cache_expiry > time.time():
                return
            epoch = self._epoch
            relationships = self._load_character_relationships()
            self._plot_rules_cache = self._load_plot_rules()
            self._blueprints_cache = self._load_blueprints()
            self._relationships_cache = relationships
            self._explicit_relations_cache = self.build_explicit_relations(relationships)
            if self.use_cache:
                self._cache_expiry = time.time() + self.CACHE_DURATION_SECONDS

    def invalidate_cache(self):
        """对标 InvalidateCache: 递增 epoch + 清空全部缓存"""
        self._epoch += 1
        self._cached_index = None
        self._index_loaded = False
        self._cache_expiry = 0.0
        self._plot_rules_cache = None
        self._blueprints_cache = None
        self._relationships_cache = None
        self._explicit_relations_cache = None

    # ---- 索引 ----

    def _try_load_index(self) -> bool:
        """对标 TryLoadIndexAsync: 从 guides/relation_strength_index.json 加载"""
        if self._index_loaded:
            return self._cached_index is not None
        with self._index_load_lock:
            if self._index_loaded:
                return self._cached_index is not None
            index_path = os.path.join(self.project.dir, "guides", "relation_strength_index.json")
            try:
                if os.path.exists(index_path):
                    with open(index_path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    self._cached_index = RelationStrengthIndex.from_dict(data)
                    self._index_loaded = True
                    return self._cached_index is not None
            except Exception:
                pass
            self._index_loaded = True
            return False

    def build_strength_index(self) -> RelationStrengthIndex:
        """对标 BuildStrengthIndexAsync: 剧情共现 Strong + 蓝图共现 Medium"""
        index = RelationStrengthIndex()
        try:
            plot_rules = self._load_plot_rules()
            blueprints = self._load_blueprints()

            # 剧情规则：同一剧情参与角色两两 → Strong
            for rule in plot_rules:
                participants = self.get_participants(rule)
                n = len(participants)
                for i in range(n):
                    for j in range(i + 1, n):
                        index.upgrade_strength(participants[i], participants[j], STRONG)

            # 蓝图：Cast 角色两两 → Medium（保底）
            for bp in blueprints:
                characters = self._extract_ids_from_text(bp.get("Cast", []))
                n = len(characters)
                for i in range(n):
                    for j in range(i + 1, n):
                        index.ensure_min_strength(characters[i], characters[j], MEDIUM)

            # 持久化（对标索引落盘）
            try:
                guides_dir = os.path.join(self.project.dir, "guides")
                os.makedirs(guides_dir, exist_ok=True)
                with open(os.path.join(guides_dir, "relation_strength_index.json"), "w", encoding="utf-8") as f:
                    json.dump(index.to_dict(), f, ensure_ascii=False, indent=2)
                self._cached_index = index
                self._index_loaded = True
            except Exception:
                pass
        except Exception:
            pass
        return index

    # ---- 查询 ----

    def get_strength(self, id1: str, id2: str) -> int:
        """对标 GetStrengthAsync: 先索引，否则实时计算"""
        if self._try_load_index():
            index = self._cached_index
            if index is not None:
                return index.get_strength(id1, id2)
        return self.compute_strength_realtime(id1, id2)

    def compute_strength_realtime(self, id1: str, id2: str) -> int:
        """对标 ComputeStrengthRealtimeAsync: 显式关系/剧情/蓝图合并"""
        self._ensure_cache_loaded()

        explicit_strength = None
        if self._explicit_relations_cache is not None:
            key = get_pair_key(id1, id2)
            info = self._explicit_relations_cache.get(key)
            if info:
                base = determine_strength_by_relation_type(info.get("RelationType", ""))
                final = apply_strength_hint(base, info.get("StrengthHint"))
                if final == STRONG:
                    return STRONG
                explicit_strength = final

        # 剧情规则共现 → Strong
        if self._plot_rules_cache:
            for rule in self._plot_rules_cache:
                participants = self.get_participants(rule)
                if id1 in participants and id2 in participants:
                    return STRONG

        # 蓝图共现 → Medium
        if self._blueprints_cache:
            for bp in self._blueprints_cache:
                cast_ids = self._extract_ids_from_text(bp.get("Cast", []))
                if id1 in cast_ids and id2 in cast_ids:
                    return MEDIUM

        # 显式关系 > Weak → 返回
        if explicit_strength is not None and explicit_strength > WEAK:
            return explicit_strength

        return WEAK