# -*- coding: utf-8 -*-
"""账本裁剪服务 — 对标 4.1.1 LedgerTrimService.cs（逐方法精确对齐）

原版 784 行，12 个独立裁剪方法，各维度裁剪模式不完全相同：
- 锚点采样模式（起始+间隔+截止）: 角色/情节点/地点/势力/物品/秘密/承诺/倒计时
- 首尾保留模式 + [起始锚点]/[截止快照] on Description: 冲突
- 首尾保留模式 + [起始时间间]/[时间截止快照] on KeyTimeEvent: 时间线
- 首尾保留模式，无标记: 移动
- 列表移除模式（PendingList/OverdueList）: 伏笔
"""

import re
from typing import Any, Dict, List, Optional

from .ledger_config import LedgerConfig

# 对标 C# PlotPointEscalationKeywords（60+ 关键词）
PLOT_POINT_ESCALATION_KEYWORDS = {
    "转折", "揭示", "决战", "牺牲", "死亡", "背叛", "觉醒", "终章",
    "最终", "真相", "关键", "逆转", "崩溃", "覆灭", "重生", "突破",
    "心理", "内心", "心境", "转变", "暗线", "隐线", "伏线", "暗示",
    "预兆", "推进", "心魔", "执念", "动摇", "崩塌", "觉察", "发现",
    "危机", "危急", "绝境", "抉择", "选择", "誓言", "羁绊", "信念",
    "契机", "机缘", "顿悟", "历劫", "渡劫", "天劫", "重逢", "告别",
    "承诺", "复仇", "复活", "陨落", "继承", "传承", "秘密", "线索",
}


def _is_critical(importance: Any) -> bool:
    if importance is None:
        return False
    if isinstance(importance, str):
        return importance.strip().lower() == "critical"
    if isinstance(importance, bool):
        return importance
    if isinstance(importance, (int, float)):
        return importance >= 4
    return False


def _is_important(importance: Any) -> bool:
    if importance is None:
        return False
    if isinstance(importance, str):
        return importance.strip().lower() == "important"
    if isinstance(importance, bool):
        return importance
    if isinstance(importance, (int, float)):
        return importance >= 3
    return False


def _has_escalation_keyword(context: str) -> bool:
    if not context:
        return False
    for kw in PLOT_POINT_ESCALATION_KEYWORDS:
        if kw in context:
            return True
    return False


def _copy(entry: dict) -> dict:
    return dict(entry)


class LedgerTrimService:
    """对标 4.1.1 LedgerTrimService — 12 维裁剪"""

    def __init__(self, tracking_manager, config: LedgerConfig, guide_manager=None):
        self.tracking = tracking_manager
        self.cfg = config
        # 对标 C# _guideManager（未提供时延迟创建）
        self._guide_manager = guide_manager

    def _get_guide_manager(self):
        if self._guide_manager is None:
            try:
                project = getattr(self.tracking, "project", None)
                if project is None:
                    return None
                from ..guides.guide_manager import GuideManager
                self._guide_manager = GuideManager(project)
            except Exception:
                return None
        return self._guide_manager

    def _get_vol_files(self, base_file: str) -> List[str]:
        """对标 C# GetVolFiles: GetExistingVolumeNumbers + GuideManager.GetVolumeFileName"""
        gm = self._get_guide_manager()
        if gm is None:
            return []
        try:
            vols = gm.get_existing_volume_numbers(base_file)
            return [gm.get_volume_file_name(base_file, v) for v in vols]
        except Exception:
            return []

    # ---- 分卷 guide 同步（对标 C# 各 Trim*Async 直接裁剪 guide + MarkDirty） ----

    def _sync_entity_guides(self, base_file: str, guide_field: str, history_field: str, data: dict):
        """把裁剪后的实体历史写回对应分卷 guide，有变更时 MarkDirty（静默回退）"""
        gm = self._get_guide_manager()
        if gm is None:
            return
        try:
            for vol_file in self._get_vol_files(base_file):
                try:
                    guide = gm.get_guide(vol_file)
                except Exception:
                    continue
                if not isinstance(guide, dict):
                    continue
                section = guide.get(guide_field)
                if not isinstance(section, dict):
                    continue
                modified = False
                for entity_id, entry in section.items():
                    if not isinstance(entry, dict):
                        continue
                    src = data.get(entity_id)
                    if isinstance(src, dict) and isinstance(src.get(history_field), list):
                        if entry.get(history_field) != src.get(history_field):
                            entry[history_field] = src.get(history_field)
                            modified = True
                if modified:
                    gm.mark_dirty(vol_file)
        except Exception:
            pass

    def _sync_timeline_guides(self, data: dict):
        """把裁剪后的 ChapterTimeline 写回 timeline_guide 分卷（静默回退）"""
        gm = self._get_guide_manager()
        if gm is None:
            return
        try:
            rebuilt = data.get("ChapterTimeline")
            if not isinstance(rebuilt, list):
                return
            for vol_file in self._get_vol_files("timeline_guide.json"):
                try:
                    guide = gm.get_guide(vol_file)
                except Exception:
                    continue
                if isinstance(guide, dict) and guide.get("ChapterTimeline") != rebuilt:
                    guide["ChapterTimeline"] = rebuilt
                    gm.mark_dirty(vol_file)
        except Exception:
            pass

    def _sync_foreshadowing_guide(self, data: dict):
        """把伏笔清理结果写回 foreshadowing_status_guide.json（单文件，静默回退）"""
        gm = self._get_guide_manager()
        if gm is None:
            return
        try:
            file_name = "foreshadowing_status_guide.json"
            guide = gm.get_guide(file_name)
            if not isinstance(guide, dict):
                return
            modified = False
            section = guide.get("Foreshadowings")
            if isinstance(section, dict):
                for fid, entry in section.items():
                    if not isinstance(entry, dict):
                        continue
                    src = data.get(fid)
                    if isinstance(src, dict) and entry.get("IsOverdue") != src.get("IsOverdue"):
                        entry["IsOverdue"] = src.get("IsOverdue")
                        modified = True
            for list_field in ("PendingList", "OverdueList"):
                new_list = data.get(list_field)
                if isinstance(new_list, list) and guide.get(list_field) != new_list:
                    guide[list_field] = new_list
                    modified = True
            if modified:
                gm.mark_dirty(file_name)
        except Exception:
            pass

    # ================= 通用工具 =================

    def _trim_zone(self, history: list, keep_recent: int):
        """返回 (trimZone, keepZone)；超限才裁剪，否则 (None, None)"""
        if len(history) <= keep_recent:
            return None, None
        trim_count = len(history) - keep_recent
        return history[:trim_count], history[trim_count:]

    def _critical_capped(self, entries: list) -> list:
        """critical 全保留，超上限取最后 N 条"""
        max_critical = self.cfg.max_critical()
        if max_critical is not None and len(entries) > max_critical:
            return entries[-max_critical:]
        return entries

    def _important_recent(self, entries: list) -> list:
        """important 保留最近 N 条"""
        n = self.cfg.LedgerImportantKeepRecent
        if n <= 0:
            return []
        return entries[-n:] if len(entries) > n else entries

    def _split_by_importance(self, trim_zone: list, importance_field: str = "Importance"):
        """把 trimZone 分成 critical/important/normal 三类"""
        critical = [p for p in trim_zone if _is_critical(p.get(importance_field, ""))]
        critical = self._critical_capped(critical)
        important = [p for p in trim_zone if _is_important(p.get(importance_field, ""))]
        important = self._important_recent(important)
        normal = [p for p in trim_zone
                  if not _is_critical(p.get(importance_field, ""))
                  and not _is_important(p.get(importance_field, ""))]
        return critical, important, normal

    # ================= 锚点采样（模式A） =================

    @staticmethod
    def _build_anchors(normals: list, interval: int, context_field: str,
                       start_tag: str = "[起始锚点]", mid_tag: str = "[中间快照@{}]",
                       end_tag: str = "[截止快照]") -> list:
        """对标 C# BuildNormalAnchors / BuildPlotPointAnchors / BuildLocationAnchors /
        BuildFactionAnchors / BuildItemAnchors / BuildSecretAnchors / BuildPledgeAnchors /
        BuildDeadlineAnchors —— 这些方法的模式完全一致，仅 context 字段名不同"""
        anchors = []
        if not normals:
            return anchors
        interval = max(1, interval)
        first = _copy(normals[0])
        first[context_field] = f"{start_tag} {first.get(context_field, '')}（归档{len(normals)}条）"
        anchors.append(first)
        for i in range(interval, len(normals) - 1, interval):
            sample = _copy(normals[i])
            sample[context_field] = f"{mid_tag.format(i)} {sample.get(context_field, '')}"
            anchors.append(sample)
        if len(normals) > 1:
            last = _copy(normals[-1])
            last[context_field] = f"{end_tag} {last.get(context_field, '')}"
            anchors.append(last)
        return anchors

    def _trim_anchored(self, history: list, keep_recent: int, context_field: str,
                       importance_field: str = "Importance", escalation_check: bool = False) -> tuple:
        """模式A：锚点采样裁剪。返回 (rebuilt, actual_trimmed)"""
        trim_zone, keep_zone = self._trim_zone(history, keep_recent)
        if trim_zone is None:
            return history, 0

        if escalation_check:
            for p in trim_zone:
                if not _is_critical(p.get(importance_field, "")) and _has_escalation_keyword(p.get(context_field, "")):
                    p[importance_field] = "critical"

        critical, important, normal = self._split_by_importance(trim_zone, importance_field)
        anchors = self._build_anchors(normal, self.cfg.LedgerNormalSampleInterval, context_field)
        actual_trimmed = max(0, len(normal) - len(anchors))

        rebuilt = []
        rebuilt.extend(critical)
        rebuilt.extend(important)
        rebuilt.extend(anchors)
        rebuilt.extend(keep_zone)
        return rebuilt, actual_trimmed

    def _trim_head_tail(self, history: list, keep_recent: int, importance_field: str,
                        context_field: str, start_tag: str, end_tag: str,
                        tag_style: str = "tag") -> tuple:
        """模式B/C/D：首尾保留裁剪。
        tag_style: 'tag'=加标记, 'none'=不加标记
        返回 (rebuilt, actual_trimmed)"""
        trim_zone, keep_zone = self._trim_zone(history, keep_recent)
        if trim_zone is None:
            return history, 0

        critical, important, normal = self._split_by_importance(trim_zone, importance_field)

        if tag_style == "tag":
            actual_trimmed = max(0, len(normal) - (2 if len(normal) > 1 else (1 if len(normal) > 0 else 0)))
        else:
            actual_trimmed = max(0, len(normal) - (2 if len(normal) > 1 else (1 if len(normal) > 0 else 0)))

        rebuilt = []
        rebuilt.extend(critical)
        rebuilt.extend(important)
        if normal:
            first = _copy(normal[0])
            if tag_style == "tag":
                first[context_field] = f"{start_tag} {first.get(context_field, '')}（归档{len(normal)}条）"
            rebuilt.append(first)
            if len(normal) > 1:
                last = _copy(normal[-1])
                if tag_style == "tag":
                    last[context_field] = f"{end_tag} {last.get(context_field, '')}"
                rebuilt.append(last)
        rebuilt.extend(keep_zone)
        return rebuilt, actual_trimmed

    # ================= 12 维裁剪方法 =================

    def _trim_character_state(self) -> int:
        """对标 TrimCharacterStateHistoryAsync（模式A，KeyEvent）"""
        store = self.tracking._stores.get("character_state")
        if not store:
            return 0
        data = store.data()
        total = 0
        modified = False
        for entity_id, entry in list(data.items()):
            if not isinstance(entry, dict):
                continue
            history = entry.get("StateHistory")
            if not isinstance(history, list) or not history:
                continue
            rebuilt, trimmed = self._trim_anchored(
                history, self.cfg.LedgerCharacterStateKeepRecent, "KeyEvent")
            if trimmed > 0:
                entry["StateHistory"] = rebuilt
                total += trimmed
                modified = True
        if modified:
            store.set_all(data)
            # 对标 C#: 直接裁剪 character_state_guide 分卷 + MarkDirty
            self._sync_entity_guides("character_state_guide.json", "Characters", "StateHistory", data)
        return total

    def _trim_conflict_progress(self) -> int:
        """对标 TrimConflictProgressAsync（模式B：首尾2条 + [起始锚点]/[截止快照] on Description）"""
        store = self.tracking._stores.get("conflict_progress")
        if not store:
            return 0
        data = store.data()
        total = 0
        modified = False
        for entity_id, entry in list(data.items()):
            if not isinstance(entry, dict):
                continue
            history = entry.get("ProgressPoints")
            if not isinstance(history, list) or not history:
                continue
            rebuilt, trimmed = self._trim_head_tail(
                history, self.cfg.LedgerConflictProgressKeepRecent,
                "Importance", "Description",
                start_tag="[起始锚点]", end_tag="[截止快照]", tag_style="tag")
            if trimmed > 0:
                entry["ProgressPoints"] = rebuilt
                total += trimmed
                modified = True
        if modified:
            store.set_all(data)
            # 对标 C#: 直接裁剪 conflict_progress_guide 分卷 + MarkDirty
            self._sync_entity_guides("conflict_progress_guide.json", "Conflicts", "ProgressPoints", data)
        return total

    def _trim_plot_points(self) -> int:
        """对标 TrimPlotPointsAsync（模式A + Context + 情节点升级）"""
        store = self.tracking._stores.get("plot_points")
        if not store:
            return 0
        data = store.data()
        total = 0
        modified = False
        for entity_id, entry in list(data.items()):
            if not isinstance(entry, dict):
                continue
            history = entry.get("StateHistory")
            if not isinstance(history, list) or not history:
                continue
            rebuilt, trimmed = self._trim_anchored(
                history, self.cfg.LedgerPlotPointsKeepRecent,
                "Context", "Importance", escalation_check=True)
            if trimmed > 0:
                entry["StateHistory"] = rebuilt
                total += trimmed
                modified = True
        if modified:
            store.set_all(data)
            # 对标 C#: TrimPlotPointsAsync 走 PlotPointsIndexService 分卷（guide_manager 不适用，静默）
        return total

    def _trim_location_state(self) -> int:
        """对标 TrimLocationStateHistoryAsync（模式A，Event）"""
        store = self.tracking._stores.get("location_state")
        if not store:
            return 0
        data = store.data()
        total = 0
        modified = False
        for entity_id, entry in list(data.items()):
            if not isinstance(entry, dict):
                continue
            history = entry.get("StateHistory")
            if not isinstance(history, list) or not history:
                continue
            rebuilt, trimmed = self._trim_anchored(
                history, self.cfg.LedgerLocationStateKeepRecent, "Event")
            if trimmed > 0:
                entry["StateHistory"] = rebuilt
                total += trimmed
                modified = True
        if modified:
            store.set_all(data)
            # 对标 C#: 直接裁剪 location_state_guide 分卷 + MarkDirty
            self._sync_entity_guides("location_state_guide.json", "Locations", "StateHistory", data)
        return total

    def _trim_faction_state(self) -> int:
        """对标 TrimFactionStateHistoryAsync（模式A，Event）"""
        store = self.tracking._stores.get("faction_state")
        if not store:
            return 0
        data = store.data()
        total = 0
        modified = False
        for entity_id, entry in list(data.items()):
            if not isinstance(entry, dict):
                continue
            history = entry.get("StateHistory")
            if not isinstance(history, list) or not history:
                continue
            rebuilt, trimmed = self._trim_anchored(
                history, self.cfg.LedgerFactionStateKeepRecent, "Event")
            if trimmed > 0:
                entry["StateHistory"] = rebuilt
                total += trimmed
                modified = True
        if modified:
            store.set_all(data)
            # 对标 C#: 直接裁剪 faction_state_guide 分卷 + MarkDirty
            self._sync_entity_guides("faction_state_guide.json", "Factions", "StateHistory", data)
        return total

    def _trim_timeline(self) -> int:
        """对标 TrimTimelineAsync（模式C：首尾2条 + [起始时间间]/[时间截止快照] on KeyTimeEvent）"""
        store = self.tracking._stores.get("timeline")
        if not store:
            return 0
        data = store.data()
        # 对标 C# TimelineGuide.ChapterTimeline: 整个列表裁剪
        timeline = data.get("ChapterTimeline")
        if not isinstance(timeline, list) or not timeline:
            return 0
        rebuilt, trimmed = self._trim_head_tail(
            timeline, self.cfg.LedgerTimelineKeepRecent,
            "Importance", "KeyTimeEvent",
            start_tag="[起始时间间]", end_tag="[时间截止快照]", tag_style="tag")
        if trimmed > 0:
            data["ChapterTimeline"] = rebuilt
            store.set_all(data)
            # 对标 C#: 直接裁剪 timeline_guide 分卷 + MarkDirty
            self._sync_timeline_guides(data)
        return trimmed

    def _trim_character_movements(self) -> int:
        """对标 TrimCharacterMovementsAsync（模式D：首尾2条，无标记）"""
        store = self.tracking._stores.get("character_location")
        if not store:
            return 0
        data = store.data()
        total = 0
        modified = False
        for entity_id, entry in list(data.items()):
            if not isinstance(entry, dict):
                continue
            history = entry.get("MovementHistory")
            if not isinstance(history, list) or not history:
                continue
            rebuilt, trimmed = self._trim_head_tail(
                history, self.cfg.LedgerMovementKeepRecent,
                "Importance", "ToLocation",
                start_tag="", end_tag="", tag_style="none")
            if trimmed > 0:
                entry["MovementHistory"] = rebuilt
                total += trimmed
                modified = True
        if modified:
            store.set_all(data)
            # 对标 C#: CharacterLocations 位于 timeline_guide 分卷 + MarkDirty
            self._sync_entity_guides("timeline_guide.json", "CharacterLocations", "MovementHistory", data)
        return total

    def _trim_item_state(self) -> int:
        """对标 TrimItemStateHistoryAsync（模式A，Event）"""
        store = self.tracking._stores.get("item_state")
        if not store:
            return 0
        data = store.data()
        total = 0
        modified = False
        for entity_id, entry in list(data.items()):
            if not isinstance(entry, dict):
                continue
            history = entry.get("StateHistory")
            if not isinstance(history, list) or not history:
                continue
            rebuilt, trimmed = self._trim_anchored(
                history, self.cfg.LedgerItemStateKeepRecent, "Event")
            if trimmed > 0:
                entry["StateHistory"] = rebuilt
                total += trimmed
                modified = True
        if modified:
            store.set_all(data)
            # 对标 C#: 直接裁剪 item_state_guide 分卷 + MarkDirty
            self._sync_entity_guides("item_state_guide.json", "Items", "StateHistory", data)
        return total

    def _trim_foreshadowings(self) -> int:
        """对标 TrimForeshadowingsAsync: 已 resolved 的伏笔从 PendingList/OverdueList 移除"""
        store = self.tracking._stores.get("foreshadowing")
        if not store:
            return 0
        data = store.data()
        if not data:
            return 0

        resolved_ids = {eid for eid, entry in data.items()
                        if isinstance(entry, dict) and entry.get("IsResolved")}

        removed = 0
        modified = False
        # 对标 guide.PendingList / guide.OverdueList
        pending = data.get("PendingList")
        overdue = data.get("OverdueList")
        if isinstance(pending, list) and pending:
            before = len(pending)
            data["PendingList"] = [p for p in pending if p not in resolved_ids]
            removed += before - len(data["PendingList"])
            if removed > 0:
                modified = True
        if isinstance(overdue, list) and overdue:
            before = len(overdue)
            data["OverdueList"] = [o for o in overdue if o not in resolved_ids]
            removed += before - len(data["OverdueList"])
            if removed > 0:
                modified = True

        # 若尚未维护 PendingList/OverdueList，退化为清理 overdue 标记
        if not modified:
            for eid, entry in list(data.items()):
                if not isinstance(entry, dict):
                    continue
                if eid in resolved_ids and entry.get("IsOverdue"):
                    entry["IsOverdue"] = False
                    modified = True

        if modified:
            store.set_all(data)
            # 对标 C#: 直接裁剪 foreshadowing_status_guide.json（单文件） + MarkDirty
            self._sync_foreshadowing_guide(data)
        return removed

    def _trim_secret_reveal(self) -> int:
        """对标 TrimSecretRevealHistoryAsync（模式A，KeyEvent）"""
        store = self.tracking._stores.get("secret")
        if not store:
            return 0
        data = store.data()
        total = 0
        modified = False
        for entity_id, entry in list(data.items()):
            if not isinstance(entry, dict):
                continue
            history = entry.get("RevealHistory")
            if not isinstance(history, list) or not history:
                continue
            rebuilt, trimmed = self._trim_anchored(
                history, self.cfg.LedgerConstraintHistoryKeepRecent, "KeyEvent")
            if trimmed > 0:
                entry["RevealHistory"] = rebuilt
                total += trimmed
                modified = True
        if modified:
            store.set_all(data)
            # 对标 C#: 直接裁剪 secret_reveal_guide 分卷 + MarkDirty
            self._sync_entity_guides("secret_reveal_guide.json", "Secrets", "RevealHistory", data)
        return total

    def _trim_pledge(self) -> int:
        """对标 TrimPledgeConstraintHistoryAsync（模式A，KeyEvent）"""
        store = self.tracking._stores.get("pledge")
        if not store:
            return 0
        data = store.data()
        total = 0
        modified = False
        for entity_id, entry in list(data.items()):
            if not isinstance(entry, dict):
                continue
            history = entry.get("History")
            if not isinstance(history, list) or not history:
                continue
            rebuilt, trimmed = self._trim_anchored(
                history, self.cfg.LedgerConstraintHistoryKeepRecent, "KeyEvent")
            if trimmed > 0:
                entry["History"] = rebuilt
                total += trimmed
                modified = True
        if modified:
            store.set_all(data)
            # 对标 C#: 直接裁剪 pledge_constraint_guide 分卷 + MarkDirty
            self._sync_entity_guides("pledge_constraint_guide.json", "Pledges", "History", data)
        return total

    def _trim_deadline(self) -> int:
        """对标 TrimDeadlineConstraintHistoryAsync（模式A，KeyEvent）"""
        store = self.tracking._stores.get("deadline")
        if not store:
            return 0
        data = store.data()
        total = 0
        modified = False
        for entity_id, entry in list(data.items()):
            if not isinstance(entry, dict):
                continue
            history = entry.get("History")
            if not isinstance(history, list) or not history:
                continue
            rebuilt, trimmed = self._trim_anchored(
                history, self.cfg.LedgerConstraintHistoryKeepRecent, "KeyEvent")
            if trimmed > 0:
                entry["History"] = rebuilt
                total += trimmed
                modified = True
        if modified:
            store.set_all(data)
            # 对标 C#: 直接裁剪 deadline_constraint_guide 分卷 + MarkDirty
            self._sync_entity_guides("deadline_constraint_guide.json", "Deadlines", "History", data)
        return total

    # ================= 入口 =================

    def trim_all(self) -> dict:
        """对标 TrimAllAsync: 12 维裁剪，返回统计"""
        # 并行执行（对标 Task.WhenAll）
        import concurrent.futures
        dims = {
            "character_state": self._trim_character_state,
            "conflict_progress": self._trim_conflict_progress,
            "plot_points": self._trim_plot_points,
            "location_state": self._trim_location_state,
            "faction_state": self._trim_faction_state,
            "timeline": self._trim_timeline,
            "character_location": self._trim_character_movements,
            "item_state": self._trim_item_state,
            "foreshadowing": self._trim_foreshadowings,
            "secret": self._trim_secret_reveal,
            "pledge": self._trim_pledge,
            "deadline": self._trim_deadline,
        }
        results = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
            futures = {name: pool.submit(fn) for name, fn in dims.items()}
            for name, fut in futures.items():
                results[name] = fut.result()

        total = sum(results.values())
        dirty = [name for name, count in results.items() if count > 0]
        # 对标 C# TrimAllAsync: 有裁剪时 await _guideManager.FlushAllAsync()
        if total > 0:
            try:
                gm = self._get_guide_manager()
                if gm is not None:
                    gm.flush_all()
            except Exception:
                pass
        return {"total_trimmed": total, "dirty_stores": dirty, "details": results}