# -*- coding: utf-8 -*-
"""对标 4.1.1 FactSnapshotExtractor: 15维快照 — 并行抽取 + 注入上限 + 活跃角色补充"""
import concurrent.futures
import os
import re
from typing import List

from ...models import (
    FactSnapshot, CharacterStateEntry, ConflictProgressEntry, ForeshadowingEntry,
    PlotPointEntry, LocationStateEntry, FactionStateEntry, TimeEntry,
    CharacterLocationEntry, ItemStateEntry, SecretEntry, PledgeEntry, DeadlineEntry,
    WorldRuleConstraint, CharacterDescription, LocationDescription,
)


class SnapshotExtractor:
    def __init__(self, project, snapshot_config=None):
        self.project = project
        self._design_cache = {}
        self._guides_cache = {}
        from .snapshot_config import DEFAULT_SNAPSHOT_CONFIG
        self.config = snapshot_config or DEFAULT_SNAPSHOT_CONFIG
        self._prev_chapter_id = ""
        self._chapter_number = 0

    def _design(self, entity: str) -> dict:
        if entity not in self._design_cache:
            self._design_cache[entity] = self.project.load_design(entity)
        return self._design_cache[entity]

    def _guide(self, name: str) -> dict:
        if name not in self._guides_cache:
            self._guides_cache[name] = self.project.guide(name).data()
        return self._guides_cache[name]

    def _tracking(self, name: str) -> dict:
        if name not in self._guides_cache:
            self._guides_cache[name] = self.project.tracking(name).data()
        return self._guides_cache[name]

    def extract(self, chapter_id: str, chapter_number: int, prev_chapter_id: str = "",
                character_ids: List[str] = None, location_ids: List[str] = None,
                conflict_ids: List[str] = None) -> FactSnapshot:
        """对标 ExtractSnapshotAsync: 15维并行抽取 + 活跃窗口 + 注入上限"""
        # 注入上限（对标 LayeredContextConfig.SnapshotMax*）
        cfg = self.config
        limits = {
            "char": cfg.SnapshotMaxCharacterInject,
            "conflict": cfg.SnapshotMaxConflictInject,
            "foreshadow": cfg.SnapshotMaxForeshadowInject,
            "location": cfg.SnapshotMaxLocationInject,
            "faction": cfg.SnapshotMaxFactionInject,
            "item": cfg.SnapshotMaxItemInject,
            "secret": cfg.SnapshotMaxSecretInject,
            "pledge": cfg.SnapshotMaxPledgeInject,
            "deadline": cfg.SnapshotMaxDeadlineInject,
        }
        # 上章 ID（对标 GetPreviousChapterId）
        if not prev_chapter_id and chapter_number > 1:
            vn = self._get_volume_for_chapter(chapter_number)
            prev_chapter_id = f"vol{vn}_ch{chapter_number - 1}"
        self._prev_chapter_id = prev_chapter_id
        self._chapter_number = chapter_number
        snapshot = FactSnapshot()

        # 15维并行抽取
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            futures = {
                "chars": pool.submit(self._extract_characters, chapter_number),
                "conflicts": pool.submit(self._extract_conflicts),
                "foreshadowings": pool.submit(self._extract_foreshadowings),
                "plot_points": pool.submit(self._extract_plot_points),
                "char_descs": pool.submit(self._extract_character_descriptions),
                "loc_descs": pool.submit(self._extract_location_descriptions),
                "world_rules": pool.submit(self._extract_world_constraints),
                "loc_states": pool.submit(self._extract_location_states),
                "fac_states": pool.submit(self._extract_faction_states),
                "timeline": pool.submit(self._extract_timeline),
                "char_locs": pool.submit(self._extract_character_locations),
                "items": pool.submit(self._extract_items),
                "secrets": pool.submit(self._extract_secrets),
                "pledges": pool.submit(self._extract_pledges),
                "deadlines": pool.submit(self._extract_deadlines),
            }

            snapshot.CharacterStates = self._limit(futures["chars"].result(), limits["char"])
            snapshot.ConflictProgress = self._limit(futures["conflicts"].result(), limits["conflict"])
            snapshot.ForeshadowingStatus = self._limit(futures["foreshadowings"].result(), limits["foreshadow"])
            snapshot.PlotPoints = futures["plot_points"].result()
            snapshot.CharacterDescriptions = futures["char_descs"].result()
            snapshot.LocationDescriptions = futures["loc_descs"].result()
            snapshot.WorldRuleConstraints = futures["world_rules"].result()
            snapshot.LocationStates = self._limit(futures["loc_states"].result(), limits["location"])
            snapshot.FactionStates = self._limit(futures["fac_states"].result(), limits["faction"])
            snapshot.Timeline = futures["timeline"].result()[:cfg.SnapshotMaxTimelineInject]
            snapshot.CharacterLocations = futures["char_locs"].result()
            snapshot.ItemStates = self._limit(futures["items"].result(), limits["item"])
            snapshot.SecretStates = self._limit(futures["secrets"].result(), limits["secret"])
            snapshot.PledgeStates = self._limit(futures["pledges"].result(), limits["pledge"])
            snapshot.DeadlineStates = self._limit(futures["deadlines"].result(), limits["deadline"])

        # 对标: 活跃角色补充描述
        self._inject_active_char_descriptions(snapshot)

        # 对标 ApplyRelevanceLimit: 相关性排序（逾期优先、关联角色优先、最近章节优先）
        self._apply_relevance_limit(snapshot)

        return snapshot

    # ---- 对标 GetPreviousChapterId / IsActiveInRecentChapters / GetChaptersPerVol ----

    def _get_volume_for_chapter(self, chapter_number: int) -> int:
        """从 volumes plan 解析章号→卷号"""
        try:
            volumes = self.project.load_plan("volumes")
            if isinstance(volumes, dict):
                volumes = volumes.get("volumes", [])
            for v in volumes or []:
                if not isinstance(v, dict):
                    continue
                start = int(v.get("StartChapter", 0) or 0)
                end = int(v.get("EndChapter", 0) or 0)
                if start and end and start <= chapter_number <= end:
                    return int(v.get("VolumeNumber", 1) or 1)
        except Exception:
            pass
        return 1

    def _get_chapters_per_vol(self) -> int:
        """对标 GetChaptersPerVol: 卷平均章节数（默认 20）"""
        try:
            volumes = self.project.load_plan("volumes")
            if isinstance(volumes, dict):
                volumes = volumes.get("volumes", [])
            spans = []
            for v in volumes or []:
                if not isinstance(v, dict):
                    continue
                start = int(v.get("StartChapter", 0) or 0)
                end = int(v.get("EndChapter", 0) or 0)
                if start > 0 and end > 0:
                    spans.append(end - start + 1)
            if spans:
                return int(round(sum(spans) / len(spans)))
        except Exception:
            pass
        return 20

    def _is_active_in_recent_chapters(self, last_chapter_id: str, window_size: int,
                                      chapters_per_vol: int = 20) -> bool:
        """对标 IsActiveInRecentChapters: 章距 ≤ 窗口"""
        prev = self._prev_chapter_id or ""
        if not last_chapter_id or not prev:
            return False
        from .character_state_service import compare_chapter_id, parse_chapter_id
        if compare_chapter_id(last_chapter_id, prev) > 0:
            return False
        cur = parse_chapter_id(prev)
        last = parse_chapter_id(last_chapter_id)
        if cur == (0, 0) or last == (0, 0):
            return False
        distance = (cur[0] - last[0]) * chapters_per_vol + (cur[1] - last[1])
        return 0 <= distance <= window_size

    def _apply_relevance_limit(self, snapshot: FactSnapshot):
        """对标 ApplyRelevanceLimit: 逾期优先、关联角色优先、最近章节优先"""
        # 伏笔：逾期优先
        if snapshot.ForeshadowingStatus:
            snapshot.ForeshadowingStatus.sort(
                key=lambda f: (not f.IsOverdue, not f.IsSetup, f.IsResolved))
        # 冲突：最近章节优先
        if snapshot.ConflictProgress:
            snapshot.ConflictProgress.sort(key=lambda c: -c.LastChapter)
        # 角色：最近活跃优先
        if snapshot.CharacterStates:
            snapshot.CharacterStates.sort(key=lambda c: -c.LastChapter)

        # 对标 ApplyRelevanceLimit<T>: 秘密/誓约/倒计时 — 3层排序注入上限
        active_char_ids = {c.CharacterId for c in snapshot.CharacterStates}
        snapshot.SecretStates = self._apply_limit_3tier(
            snapshot.SecretStates, max_inject=self.config.SnapshotMaxSecretInject,
            priority_ids=active_char_ids,
            party_accessor=lambda s: (s.KnowerIds or []),
            chapter_accessor=lambda s: s.LastChapter)
        snapshot.PledgeStates = self._apply_limit_3tier(
            snapshot.PledgeStates, max_inject=self.config.SnapshotMaxPledgeInject,
            priority_ids=active_char_ids,
            party_accessor=lambda p: (p.PartyIds or []),
            chapter_accessor=lambda p: p.LastChapter,
            overdue_accessor=lambda p: getattr(p, 'IsOverdue', False))
        snapshot.DeadlineStates = self._apply_limit_3tier(
            snapshot.DeadlineStates, max_inject=self.config.SnapshotMaxDeadlineInject,
            priority_ids=active_char_ids,
            party_accessor=lambda d: (d.PartyIds or []),
            chapter_accessor=lambda d: d.LastChapter,
            overdue_accessor=lambda d: getattr(d, 'IsOverdue', False))

    @staticmethod
    def _apply_limit_3tier(source, max_inject: int, priority_ids: set,
                           party_accessor, chapter_accessor, overdue_accessor=None):
        """对标 ApplyRelevanceLimit<T>: 3层优先级排序 + 截断"""
        if not source or len(source) <= max_inject:
            return source
        # 1. 逾期优先 → 2. 关联角色(partyIds ∩ priorityIds) → 3. 最近章节
        has_party = lambda item: any(
            pid and pid in priority_ids
            for pid in party_accessor(item)) if party_accessor(item) else False
        return sorted(source, key=lambda s: (
            0 if (overdue_accessor and overdue_accessor(s)) else 1,  # 逾期=0 优先
            0 if has_party(s) else 1,                                 # 关联=0 优先
            -(chapter_accessor(s) or 0),                               # 章节号大优先
        ))[:max_inject]

    def _inject_active_char_descriptions(self, snapshot: FactSnapshot):
        """对标 ExtractSnapshotAsync 第88-103行: 补充活跃角色描述"""
        existing_ids = {cd.CharacterId for cd in snapshot.CharacterDescriptions}
        active_ids = {cse.CharacterId for cse in snapshot.CharacterStates}
        missing = active_ids - existing_ids
        if missing:
            design = self._design("characters")
            items = design.get("items", []) if isinstance(design, dict) else (design or [])
            for c in items:
                cid = c.get("Id", "")
                if cid in missing:
                    app = c.get("Appearance", "")
                    hair = self._extract_hair(app)
                    tags = [t.strip() for t in re.split(r"[，,、]", c.get("Personality", "") + "," + c.get("Identity", "")) if t.strip()]
                    snapshot.CharacterDescriptions.append(
                        CharacterDescription(CharacterId=cid, Name=c.get("Name", ""),
                                             HairColor=hair, Appearance=app, PersonalityTags=tags))

    @staticmethod
    def _extract_hair(appearance: str) -> str:
        """对标 ExtractHairColor + HairColorConstants"""
        for kw in ["黑发", "金发", "白发", "红发", "蓝发", "紫发", "银发", "棕发", "青发",
                    "黑", "金", "白", "红", "蓝", "紫", "银", "灰", "棕"]:
            if kw in appearance:
                return kw if len(kw) >= 2 else kw + "发"
        return ""

    @staticmethod
    def parse_tags(text: str) -> List[str]:
        """对标 ParseTags: 按分隔符拆分 + 去空 + 长度限制 ≤20"""
        if not text:
            return []
        return [t.strip() for t in re.split(r"[，,、;； ]", text)
                if t.strip() and len(t.strip()) <= 20]

    @staticmethod
    def split_csv(csv_str: str) -> List[str]:
        """对标 SplitCsv: 按逗号/中文逗号拆分"""
        if not csv_str or not csv_str.strip():
            return []
        return [s.strip() for s in re.split(r"[，,]", csv_str) if s.strip()]

    @staticmethod
    def has_relevant_party(item, priority_ids: set, party_accessor) -> bool:
        """对标 HasRelevantParty: 检查 item 是否关联 priority_ids"""
        if not priority_ids:
            return False
        for pid in party_accessor(item):
            if pid and pid in priority_ids:
                return True
        return False

    @staticmethod
    def importance_score(p) -> int:
        """对标 ImportanceScore: 按 Importance + Storyline 评分"""
        imp = getattr(p, "Importance", None) or getattr(p, "importance", None)
        if isinstance(imp, int):
            score = imp
        elif isinstance(imp, str):
            if imp.lower() == "critical":
                score = 3
            elif imp.lower() == "important":
                score = 2
            else:
                score = 1
        else:
            score = 1
        storyline = getattr(p, "Storyline", None) or getattr(p, "storyline", "")
        if isinstance(storyline, str) and storyline.lower() == "main":
            score += 2
        return score

    def get_previous_chapter_id(self, chapter_id: str) -> str:
        """对标 GetPreviousChapterId: 前一章或跨卷前一卷末章"""
        vn, cn = parse_chapter_id(chapter_id)
        if (vn, cn) == (0, 0):
            return ""
        if cn > 1:
            from .character_state_service import build_chapter_id
            return build_chapter_id(vn, cn - 1)
        if vn > 1:
            last_ch = self.get_last_chapter_of_volume(vn - 1)
            if last_ch > 0:
                from .character_state_service import build_chapter_id
                return build_chapter_id(vn - 1, last_ch)
            print(f"[FactSnapshotExtractor] 无法确定卷{vn - 1}的最后一章，跳过跨卷状态抽取")
            return ""
        return ""

    def get_last_chapter_of_volume(self, volume_number: int) -> int:
        """对标 GetLastChapterOfVolume: 从章节文件目录查询卷末章号"""
        try:
            chapters_path = os.path.join(self.project.dir, "chapters")
            if not os.path.isdir(chapters_path):
                return 0
            prefix = f"vol{volume_number}_ch"
            files = [f for f in os.listdir(chapters_path)
                     if f.startswith(prefix) and f.endswith(".md")]
            if not files:
                return 0
            max_ch = 0
            for f in files:
                name = os.path.splitext(f)[0]
                _, cn = parse_chapter_id(name)
                if cn > max_ch:
                    max_ch = cn
            return max_ch
        except Exception as e:
            print(f"[FactSnapshotExtractor] 查询卷{volume_number}最后一章失败: {e}")
            return 0

    @staticmethod
    def _limit(items, max_count):
        return items[:max_count] if len(items) > max_count else items

    def _extract_characters(self, chapter_number: int) -> List[CharacterStateEntry]:
        """对标 ExtractCharacterStatesAsync: 二分查询历史 + 活跃窗口注入 + 前卷基线"""
        from .character_state_service import compare_chapter_id, parse_chapter_id
        guide = self._tracking("character_state")
        result = []

        # 指定角色（对标 characterIds 参数）
        if not guide:
            return result

        # 1. 指定角色：二分查询 <= prevChapterId 的历史状态
        prev = self._prev_chapter_id or ""
        for k, v in guide.items():
            if not isinstance(v, dict):
                continue
            history = v.get("StateHistory")
            if isinstance(history, list) and history:
                state = self._binary_search_state(history, prev) if prev else history[-1]
                if state is None:
                    state = history[0] if history else None
                if state is None:
                    continue
                result.append(CharacterStateEntry(
                    CharacterId=k, Name=v.get("Name", k),
                    Level=state.get("Level", ""),
                    Phase=state.get("Phase", ""),
                    Abilities=state.get("Abilities", []),
                    LostAbilities=v.get("LostAbilities", []),
                    MentalState=state.get("MentalState", ""),
                    KeyEvent=state.get("KeyEvent", ""),
                    LastChapter=self._chapter_to_int(state.get("Chapter", "")),
                    Importance=self._importance_to_int(state.get("Importance", "")),
                    Relationships=state.get("Relationships", {})))
            else:
                # 兼容旧格式（无 StateHistory，直接用顶层字段）
                result.append(CharacterStateEntry(
                    CharacterId=k, Name=v.get("Name", k),
                    Level=v.get("Level", ""), Phase=v.get("Phase", ""),
                    Abilities=v.get("Abilities", []),
                    LostAbilities=v.get("LostAbilities", []),
                    MentalState=v.get("MentalState", ""),
                    KeyEvent=v.get("KeyEvent", ""),
                    LastChapter=int(v.get("LastChapter", 0) or 0),
                    Importance=int(v.get("Importance", 0) or 0),
                    Relationships=v.get("Relationships", {})))

        # 2. 前卷存档基线注入（对标 vol>1 时 GetPreviousArchivesAsync）
        existing_ids = {c.CharacterId for c in result}
        if prev:
            pv, _ = parse_chapter_id(prev)
            if pv > 1:
                try:
                    archive = self._load_volume_archive(pv - 1)
                    # 从卷存档补齐未注入角色
                    archive_chars = {}
                    if archive and isinstance(archive, dict):
                        for item in archive.get("CharacterStates", []) or []:
                            if isinstance(item, dict) and item.get("Id"):
                                archive_chars[item["Id"]] = item
                    for cid, item in archive_chars.items():
                        if cid in existing_ids:
                            continue
                        result.append(CharacterStateEntry(
                            CharacterId=cid, Name=item.get("Name", cid),
                            Level=item.get("Stage", ""), Phase="",
                            Abilities=self._split_abilities(item.get("Abilities", "")),
                            MentalState="", KeyEvent="", LastChapter=0,
                            Importance=0, Relationships={}))
                except Exception:
                    pass

        # 3. 活跃窗口注入（对标 IsActiveInRecentChapters + ActiveEntityWindowMaxCount）
        if prev:
            existing_ids = {c.CharacterId for c in result}
            window = self.config.ActiveEntityWindowChapters
            max_count = self.config.ActiveEntityWindowMaxCount
            cpp = self._get_chapters_per_vol()
            active = []
            for k, v in guide.items():
                if not isinstance(v, dict) or k in existing_ids:
                    continue
                history = v.get("StateHistory")
                if not isinstance(history, list) or not history:
                    continue
                state = self._binary_search_state(history, prev)
                if state is None or not state.get("Chapter"):
                    continue
                if not self._is_active_in_recent_chapters(state["Chapter"], window, cpp):
                    continue
                active.append(CharacterStateEntry(
                    CharacterId=k, Name=v.get("Name", k),
                    Level=state.get("Level", ""), Phase=state.get("Phase", ""),
                    Abilities=state.get("Abilities", []),
                    LostAbilities=v.get("LostAbilities", []),
                    MentalState=state.get("MentalState", ""),
                    KeyEvent=state.get("KeyEvent", ""),
                    LastChapter=self._chapter_to_int(state.get("Chapter", "")),
                    Importance=self._importance_to_int(state.get("Importance", "")),
                    Relationships=state.get("Relationships", {})))
            active.sort(key=lambda c: -c.LastChapter)
            result.extend(active[:max_count])

        return result

    def _load_volume_archive(self, volume_number: int) -> dict:
        """对标 VolumeFactArchiveStore: 读取卷末存档"""
        try:
            path = os.path.join(self.project.dir, "archives",
                                f"volume_{volume_number}_snapshot.json")
            if os.path.exists(path):
                import json
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
            return {}
        except Exception:
            return {}

    @staticmethod
    def _split_abilities(value) -> List[str]:
        """Abilities 字符串/列表 → 列表"""
        if isinstance(value, list):
            return [str(x) for x in value]
        if isinstance(value, str) and value:
            return [x.strip() for x in value.split("、") if x.strip()]
        return []

    @staticmethod
    def _importance_to_int(importance) -> int:
        """Importance 标签/数字 → int"""
        if isinstance(importance, int):
            return importance
        s = str(importance or "").strip().lower()
        if s == "critical":
            return 4
        if s == "important":
            return 3
        return 0

    @staticmethod
    def _binary_search_state(history: list, target_chapter_id: str):
        """对标 BinarySearchState: 二分查找 <= target 的最新历史"""
        from .character_state_service import compare_chapter_id
        if not history:
            return None
        if not target_chapter_id:
            return history[-1]
        left, right = 0, len(history) - 1
        result_index = -1
        while left <= right:
            mid = (left + right) // 2
            if compare_chapter_id(history[mid].get("Chapter", ""), target_chapter_id) <= 0:
                result_index = mid
                left = mid + 1
            else:
                right = mid - 1
        return history[result_index] if result_index >= 0 else None

    def _extract_conflicts(self) -> List[ConflictProgressEntry]:
        """对标 ExtractConflictProgressAsync: 最近 10 条进展 + RecentProgress 格式化"""
        guide = self._tracking("conflict_progress")
        out = []
        if guide:
            items = []
            for k, v in guide.items():
                if not isinstance(v, dict): continue
                # 最近 10 条事件 → "章节: 事件" 列表（对标 C# TakeLast(10).Select(p => $"{p.Chapter}: {p.Event}")）
                points = v.get("ProgressPoints") or []
                recent = []
                if isinstance(points, list):
                    for p in points[-10:]:
                        if isinstance(p, dict) and p.get("Event"):
                            recent.append(f"{p.get('Chapter', '')}: {p.get('Event')}")
                last_chapter = self._chapter_to_int(v.get("LastChapter", 0))
                if not last_chapter and isinstance(points, list) and points:
                    last_chapter = self._chapter_to_int(points[-1].get("Chapter", ""))
                items.append(ConflictProgressEntry(
                    ConflictId=k, Name=v.get("Name", k), Type=v.get("Type", ""),
                    Tier=v.get("Tier", ""), Status=v.get("Status", ""),
                    LastEvent="\n".join(recent) if recent else (v.get("LastEvent", "") or ""),
                    LastChapter=last_chapter, InvolvedCharacters=v.get("InvolvedCharacters", [])))
            items.sort(key=lambda x: -x.LastChapter)
            out = items[:self.config.SnapshotMaxConflictInject]
        return out

    def _extract_foreshadowings(self) -> List[ForeshadowingEntry]:
        guide = self._tracking("foreshadowing")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict): continue
                out.append(ForeshadowingEntry(
                    ForeshadowId=k, Name=v.get("Name", k), Tier=v.get("Tier", "Tier-3"),
                    IsSetup=bool(v.get("IsSetup", False)), IsResolved=bool(v.get("IsResolved", False)),
                    IsOverdue=bool(v.get("IsOverdue", False)),
                    ExpectedSetupChapter=self._chapter_to_int(v.get("ExpectedSetupChapter", "")),
                    ExpectedPayoffChapter=self._chapter_to_int(v.get("ExpectedPayoffChapter", "")),
                    ActualSetupChapter=self._chapter_to_int(v.get("ActualSetupChapter", "")),
                    ActualPayoffChapter=self._chapter_to_int(v.get("ActualPayoffChapter", ""))))
        return out

    @staticmethod
    def _chapter_to_int(chapter_id) -> int:
        """章节ID(volX_chY) → 章号（用于兼容旧 int 快照读取）"""
        if isinstance(chapter_id, int):
            return chapter_id
        m = re.search(r"(\d+)", str(chapter_id))
        return int(m.group(1)) if m else 0

    def _extract_plot_points(self) -> List[PlotPointEntry]:
        guide = self._tracking("plot_points")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict): continue
                out.append(PlotPointEntry(
                    PlotPointId=k, Keywords=v.get("Keywords", []), Context=v.get("Context", ""),
                    InvolvedCharacters=v.get("InvolvedCharacters", []), Storyline=v.get("Storyline", ""),
                    Chapter=int(v.get("Chapter", 0) or 0), Importance=int(v.get("Importance", 0) or 0)))
        return out

    def _extract_character_descriptions(self) -> List[CharacterDescription]:
        design = self._design("characters")
        items = design.get("items", []) if isinstance(design, dict) else (design or [])
        out = []
        for c in items:
            app = c.get("Appearance", "")
            hair = self._extract_hair(app)
            tags = [t.strip() for t in re.split(r"[，,、]", c.get("Personality", "")) if t.strip()]
            out.append(CharacterDescription(
                CharacterId=c.get("Id", ""), Name=c.get("Name", ""),
                HairColor=hair, EyeColor="", PersonalityTags=tags, Appearance=app))
        return out

    def _extract_location_descriptions(self) -> List[LocationDescription]:
        design = self._design("locations")
        items = design.get("items", []) if isinstance(design, dict) else (design or [])
        out = []
        for loc in items:
            features = loc.get("Landmarks", []) or []
            if isinstance(features, str): features = [features]
            out.append(LocationDescription(
                LocationId=loc.get("Id", ""), Name=loc.get("Name", ""),
                Features=[str(x) for x in features], Description=loc.get("Description", "")))
        return out

    def _extract_world_constraints(self) -> List[WorldRuleConstraint]:
        design = self._design("world")
        items = design.get("items", []) if isinstance(design, dict) else (design or [])
        out = []
        for rule in items:
            for hr in (rule.get("HardRules", []) or []):
                if hr:
                    out.append(WorldRuleConstraint(RuleId=rule.get("Id", "R"), Content=str(hr), IsHardConstraint=True))
        return out

    def _extract_location_states(self) -> List[LocationStateEntry]:
        guide = self._tracking("location_state")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict): continue
                # 从 StateHistory 推导最新 Event/Chapter（对标 C# 无 LastEvent/LastChapter 字段）
                history = v.get("StateHistory") or []
                last_event = ""
                last_chapter = 0
                if isinstance(history, list) and history:
                    last = history[-1]
                    last_event = last.get("Event", "") or ""
                    m = re.search(r"(\d+)", str(last.get("Chapter", "")))
                    last_chapter = int(m.group(1)) if m else 0
                out.append(LocationStateEntry(
                    LocationId=k, Name=v.get("Name", k), CurrentStatus=v.get("CurrentStatus", "normal"),
                    Description="", LastEvent=last_event, LastChapter=last_chapter))
        return out

    def _extract_faction_states(self) -> List[FactionStateEntry]:
        guide = self._tracking("faction_state")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict): continue
                # 从 StateHistory 推导最新 Event/Chapter（对标 C# 无 LastEvent/LastChapter 字段）
                history = v.get("StateHistory") or []
                last_event = ""
                last_chapter = 0
                if isinstance(history, list) and history:
                    last = history[-1]
                    last_event = last.get("Event", "") or ""
                    m = __import__("re").search(r"(\d+)", str(last.get("Chapter", "")))
                    last_chapter = int(m.group(1)) if m else 0
                out.append(FactionStateEntry(
                    FactionId=k, Name=v.get("Name", k), CurrentStatus=v.get("CurrentStatus", "active"),
                    LastEvent=last_event, LastChapter=last_chapter))
        return out

    def _extract_timeline(self) -> List[TimeEntry]:
        guide = self._tracking("timeline")
        out = []
        if guide:
            # 对标 C# TimelineGuide.ChapterTimeline: 列表结构
            timeline = guide.get("ChapterTimeline")
            if isinstance(timeline, list):
                for v in timeline:
                    if not isinstance(v, dict): continue
                    m = re.search(r"(\d+)", str(v.get("ChapterId", "")))
                    ch = int(m.group(1)) if m else 0
                    out.append(TimeEntry(
                        TimePeriod=v.get("TimePeriod", ""), ElapsedTime=v.get("ElapsedTime", ""),
                        KeyTimeEvent=v.get("KeyTimeEvent", ""), Chapter=ch))
            else:
                # 兼容旧 dict 结构
                for k, v in guide.items():
                    if not isinstance(v, dict): continue
                    out.append(TimeEntry(
                        TimePeriod=v.get("TimePeriod", ""), ElapsedTime=v.get("ElapsedTime", ""),
                        KeyTimeEvent=v.get("KeyTimeEvent", ""), Chapter=int(v.get("Chapter", 0) or 0)))
        return out

    def _extract_character_locations(self) -> List[CharacterLocationEntry]:
        guide = self._tracking("character_location")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict): continue
                # 从 MovementHistory 推导 LastUpdated（对标 C# LastUpdatedChapter 为章节ID）
                history = v.get("MovementHistory") or []
                last_updated = 0
                if isinstance(history, list) and history:
                    m = re.search(r"(\d+)", str(history[-1].get("Chapter", "")))
                    last_updated = int(m.group(1)) if m else 0
                elif v.get("LastUpdatedChapter"):
                    m = re.search(r"(\d+)", str(v.get("LastUpdatedChapter", "")))
                    last_updated = int(m.group(1)) if m else 0
                out.append(CharacterLocationEntry(
                    CharacterId=k, Name=v.get("Name", k), CurrentLocation=v.get("CurrentLocation", ""),
                    LastUpdatedChapter=last_updated))
        return out

    def _extract_items(self) -> List[ItemStateEntry]:
        guide = self._tracking("item_state")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict): continue
                # 从 StateHistory 推导 LastEvent/LastChapter（对标 C# 无 LastEvent/LastChapter 字段）
                history = v.get("StateHistory") or []
                last_event = ""
                last_chapter = 0
                if isinstance(history, list) and history:
                    last = history[-1]
                    last_event = last.get("Event", "") or ""
                    m = re.search(r"(\d+)", str(last.get("Chapter", "")))
                    last_chapter = int(m.group(1)) if m else 0
                out.append(ItemStateEntry(
                    ItemId=k, Name=v.get("Name", k), CurrentHolder=v.get("CurrentHolder", ""),
                    CurrentStatus=v.get("CurrentStatus", "active"), Description=v.get("Description", ""),
                    LastEvent=last_event, LastChapter=last_chapter))
        return out

    def _extract_secrets(self) -> List[SecretEntry]:
        guide = self._tracking("secret")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict): continue
                # 从 RevealHistory 推导 LastChapter（对标 C# 无 LastChapter 字段）
                history = v.get("RevealHistory") or []
                last_chapter = 0
                if isinstance(history, list) and history:
                    m = re.search(r"(\d+)", str(history[-1].get("Chapter", "")))
                    last_chapter = int(m.group(1)) if m else 0
                out.append(SecretEntry(
                    SecretId=k, Name=v.get("Name", k), KnowerIds=v.get("KnowerIds", []),
                    CurrentStatus=v.get("CurrentStatus", "hidden"), LastChapter=last_chapter))
        return out

    def _extract_pledges(self) -> List[PledgeEntry]:
        guide = self._tracking("pledge")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict): continue
                # 从 History 推导 LastChapter（对标 C# 无 LastChapter 字段）
                history = v.get("History") or []
                last_chapter = 0
                if isinstance(history, list) and history:
                    m = re.search(r"(\d+)", str(history[-1].get("Chapter", "")))
                    last_chapter = int(m.group(1)) if m else 0
                out.append(PledgeEntry(
                    PledgeId=k, Name=v.get("Name", k), Type=v.get("Type", "pledge"),
                    CurrentStatus=v.get("CurrentStatus", "active"), PartyIds=v.get("PartyIds", []),
                    Condition=v.get("Condition", ""), Consequence=v.get("Consequence", ""),
                    LastChapter=last_chapter))
        return out

    def _extract_deadlines(self) -> List[DeadlineEntry]:
        guide = self._tracking("deadline")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict): continue
                out.append(DeadlineEntry(
                    DeadlineId=k, Name=v.get("Name", k), Type=v.get("Type", ""),
                    CurrentStatus=v.get("CurrentStatus", "active"), Deadline=v.get("Deadline", ""),
                    TriggerCondition=v.get("TriggerCondition", ""), Consequence=v.get("Consequence", ""),
                    PartyIds=v.get("PartyIds", []), LastChapter=int(v.get("LastChapter", 0) or 0)))
        return out

    # ====== 对标 ExtractVolumeEndSnapshotAsync: 卷末全量快照持久化 ======

    def extract_volume_end(self, volume_number: int) -> FactSnapshot:
        """对标 ExtractVolumeEndSnapshotAsync: 卷末完整快照（allVolumes=true，无截断）"""
        snapshot = FactSnapshot()

        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            futures = {
                "chars": pool.submit(self._extract_characters, 0),
                "conflicts": pool.submit(self._extract_conflicts),
                "foreshadowings": pool.submit(self._extract_foreshadowings),
                "loc_states": pool.submit(self._extract_location_states),
                "fac_states": pool.submit(self._extract_faction_states),
                "items": pool.submit(self._extract_items),
                "secrets": pool.submit(self._extract_secrets),
                "pledges": pool.submit(self._extract_pledges),
                "deadlines": pool.submit(self._extract_deadlines),
            }

            snapshot.CharacterStates = futures["chars"].result()
            snapshot.ConflictProgress = futures["conflicts"].result()
            snapshot.ForeshadowingStatus = futures["foreshadowings"].result()
            snapshot.LocationStates = futures["loc_states"].result()
            snapshot.FactionStates = futures["fac_states"].result()
            snapshot.ItemStates = futures["items"].result()
            snapshot.SecretStates = futures["secrets"].result()
            snapshot.PledgeStates = futures["pledges"].result()
            snapshot.DeadlineStates = futures["deadlines"].result()

        # 卷末不应用 relevance limit（无截断）
        return snapshot

    def save_volume_snapshot(self, volume_number: int):
        """对标 VolumeFactArchiveStore.ArchiveVolumeAsync: 持久化卷末快照"""
        snapshot = self.extract_volume_end(volume_number)
        data = snapshot.to_dict()
        self.project.save_design(f"vol{volume_number}_archive", data)
        return snapshot
