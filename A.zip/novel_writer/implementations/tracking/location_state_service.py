# -*- coding: utf-8 -*-
"""地点状态服务 — 对标 4.1.1 LocationStateService.cs（完整移植 129 行）

对齐功能:
- UpdateLocationStateAsync（自动注册 + 完整快照）
- RemoveChapterDataAsync（删除历史 + 回填 CurrentStatus，否则 "unknown"）
- GetAllLocationStatesAsync
- TryResolveLocationDisplayNameAsync（从 locationrules 解析地点名）
"""

from typing import Dict, List, Optional

from .character_state_service import build_chapter_id, parse_chapter_id


class LocationStateService:
    """对标 4.1.1 LocationStateService — 地点状态管理（独立类）

    调用链与 C# 完全一致：
    - 读: GuideManager.GetExistingVolumeNumbers + GetVolumeFileName + GetGuideAsync<LocationStateGuide>
    - 写: GuideManager.MarkDirty(volFile)
    """

    BaseFileName = "location_state_guide.json"
    GUIDE_FIELD = "Locations"
    HISTORY_FIELD = "StateHistory"

    def __init__(self, project, tracking_manager=None, guide_manager=None):
        self.project = project
        self.tracking = tracking_manager
        self._store = None
        # 对标 C# _guideManager（未提供时延迟创建）
        self._guide_manager = guide_manager

    def _get_guide_manager(self):
        if self._guide_manager is None:
            try:
                from ..guides.guide_manager import GuideManager
                self._guide_manager = GuideManager(self.project)
            except Exception:
                return None
        return self._guide_manager

    @classmethod
    def _volume_file_name(cls, chapter_id: str) -> str:
        """对标 C# VolumeFileName(chapterId): GuideManager.GetVolumeFileName(BaseFileName, vol)"""
        from ..guides.guide_manager import GuideManager
        vol, _ = parse_chapter_id(chapter_id)
        return GuideManager.get_volume_file_name(cls.BaseFileName, vol)

    def _get_store(self):
        if self._store is None:
            if self.tracking is not None:
                self._store = self.tracking._stores["location_state"]
            else:
                self._store = self.project.tracking("location_state")
        return self._store

    # ---- 更新 ----

    def update_location_state(self, chapter_id: str, change) -> dict:
        """对标 UpdateLocationStateAsync: 注册/更新地点状态并追加完整快照

        change: LocationStateChange（LocationId/LocationName/NewStatus/Event/Importance）
        """
        store = self._get_store()
        data = store.data()

        # 自动注册（对标 C#: Name=change.LocationName 或解析名，CurrentStatus=NewStatus）
        if change.LocationId not in data:
            display_name = (change.LocationName if change.LocationName
                            else self.try_resolve_display_name(change.LocationId)
                            or change.LocationId)
            data[change.LocationId] = {
                "Name": display_name,
                "CurrentStatus": change.NewStatus or "",
                self.HISTORY_FIELD: [],
                "DriftWarnings": [],
            }

        entry = data[change.LocationId]
        # 补齐默认字段
        entry.setdefault("CurrentStatus", "normal")
        entry.setdefault("DriftWarnings", [])
        history = entry.setdefault(self.HISTORY_FIELD, [])
        if not isinstance(history, list):
            history = []
            entry[self.HISTORY_FIELD] = history

        if change.NewStatus:
            entry["CurrentStatus"] = change.NewStatus

        # 完整快照（对标 C# LocationStatePoint）
        history.append({
            "Chapter": chapter_id,
            "Status": change.NewStatus,
            "Event": change.Event,
            "Importance": change.Importance if change.Importance else "normal",
        })

        store.set_all(data)

        # 对标 C#: var guide = GetGuideAsync(volFile) ... _guideManager.MarkDirty(volFile)
        gm = self._get_guide_manager()
        if gm is not None:
            try:
                vol_file = self._volume_file_name(chapter_id)
                guide = gm.get_guide(vol_file)
                # 同步到分卷 guide（Locations 字典 + StateHistory）
                if isinstance(guide, dict):
                    locations = guide.setdefault(self.GUIDE_FIELD, {})
                    g_entry = locations.get(change.LocationId)
                    if not isinstance(g_entry, dict):
                        locations[change.LocationId] = {
                            "Name": entry.get("Name", ""),
                            "CurrentStatus": entry.get("CurrentStatus", ""),
                            "DriftWarnings": list(entry.get("DriftWarnings") or []),
                            self.HISTORY_FIELD: [history[-1]],
                        }
                    else:
                        g_entry["Name"] = entry.get("Name", g_entry.get("Name", ""))
                        g_entry["CurrentStatus"] = entry.get("CurrentStatus",
                                                            g_entry.get("CurrentStatus", "normal"))
                        g_history = g_entry.setdefault(self.HISTORY_FIELD, [])
                        g_history.append(history[-1])
                    gm.mark_dirty(vol_file)
            except Exception:
                pass

        return entry

    # ---- 删除章节 ----

    def remove_chapter_data(self, chapter_id: str) -> int:
        """对标 RemoveChapterDataAsync: 删除历史 + 回填 CurrentStatus（否则 "unknown"）"""
        store = self._get_store()
        data = store.data()
        modified = False
        removed_total = 0

        for entry in list(data.values()):
            if not isinstance(entry, dict):
                continue
            history = entry.get(self.HISTORY_FIELD)
            if not isinstance(history, list):
                continue
            before = len(history)
            history[:] = [s for s in history
                          if not (s.get("Chapter", "") and s["Chapter"] == chapter_id)]
            removed = before - len(history)
            if removed > 0:
                modified = True
                removed_total += removed
                history.sort(key=lambda s: parse_chapter_id(s.get("Chapter", "")))
                last_status = ""
                for s in reversed(history):
                    st = s.get("Status")
                    if st:
                        last_status = st
                        break
                entry["CurrentStatus"] = last_status if last_status else "unknown"

        if modified:
            store.set_all(data)
            # 对标 C#: 修改后 _guideManager.MarkDirty(volFile)
            gm = self._get_guide_manager()
            if gm is not None:
                try:
                    vol_file = self._volume_file_name(chapter_id)
                    guide = gm.get_guide(vol_file)
                    if isinstance(guide, dict):
                        g_modified = False
                        for g_entry in (guide.get(self.GUIDE_FIELD) or {}).values():
                            if not isinstance(g_entry, dict):
                                continue
                            g_history = g_entry.get(self.HISTORY_FIELD)
                            if not isinstance(g_history, list):
                                continue
                            before = len(g_history)
                            g_history[:] = [s for s in g_history
                                            if s.get("Chapter", "") != chapter_id]
                            if len(g_history) < before:
                                g_modified = True
                                g_history.sort(key=lambda s: parse_chapter_id(s.get("Chapter", "")))
                                last_status = ""
                                for s in reversed(g_history):
                                    st = s.get("Status")
                                    if st:
                                        last_status = st
                                        break
                                g_entry["CurrentStatus"] = last_status if last_status else "unknown"
                        if g_modified:
                            gm.mark_dirty(vol_file)
                except Exception:
                    pass
        return removed_total

    # ---- 查询 ----

    def get_all_location_states(self) -> Dict[str, dict]:
        """对标 GetAllLocationStatesAsync: 合并最近卷的 Locations（TakeLast(5)），回退 store"""
        gm = self._get_guide_manager()
        if gm is not None:
            try:
                # 对标: var volNumbers = _guideManager.GetExistingVolumeNumbers(BaseFileName)
                vol_numbers = gm.get_existing_volume_numbers(self.BaseFileName)
                merged = {}
                for vol in vol_numbers[-5:]:
                    vol_file = gm.get_volume_file_name(self.BaseFileName, vol)
                    guide = gm.get_guide(vol_file)
                    if not isinstance(guide, dict):
                        continue
                    locations = guide.get(self.GUIDE_FIELD)
                    if isinstance(locations, dict):
                        for lid, entry in locations.items():
                            if isinstance(entry, dict):
                                merged[lid] = entry
                if merged:
                    return merged
                # 分卷未找到时回退 store
            except Exception:
                pass
        store = self._get_store()
        data = store.data()
        return {lid: entry for lid, entry in data.items() if isinstance(entry, dict)}

    # ---- 地点名解析 ----

    def try_resolve_display_name(self, location_id: str) -> Optional[str]:
        """对标 TryResolveLocationDisplayNameAsync: 从设计库 locationrules 解析地点名"""
        try:
            design = self.project.load_design("locations")
            items = design.get("items", []) if isinstance(design, dict) else (design or [])
            for item in items:
                if not isinstance(item, dict):
                    continue
                if str(item.get("Id", "")).lower() == str(location_id).lower():
                    name = item.get("Name", "")
                    return name if name else None
            return None
        except Exception:
            return None