# -*- coding: utf-8 -*-
"""实体维度注册表 — 对标 4.1.1 EntityDrift/EntityDimensionRegistry.cs（9 维度）

对齐功能:
- EntityDimensionRegistry.All / GetByCode / AutoPatchDimensions / WarnOnlyDimensions
- 9 维度构建：角色/势力/地点（AutoPatch）+ 冲突/物品/伏笔/秘密/承诺/倒计时（WarnOnly）
- AppendBoundedWarning（DriftWarnings 有界追加）
- name_exists_in_content（全文/主名/括号别名匹配）
"""

import re
from typing import List, Optional

from .entity_dimension_descriptor import (
    EntityDimensionDescriptor, DriftEntityRecord, AUTO_PATCH, WARN_ONLY,
)


def append_bounded_warning(entry: dict, warn_msg: str, max_warn: int):
    """对标 AppendBoundedWarning: 超限则移除最早的"""
    dw = entry.setdefault("DriftWarnings", [])
    if not isinstance(dw, list):
        dw = []
        entry["DriftWarnings"] = dw
    if max_warn > 0 and len(dw) >= max_warn:
        dw = dw[len(dw) - max_warn + 1:]
    dw.append(warn_msg)
    entry["DriftWarnings"] = dw


def name_exists_in_content(content: str, full_name: str) -> bool:
    """对标 EntityNameNormalizeHelper.NameExistsInContent: 全文/主名/括号别名匹配"""
    if not content or not full_name:
        return False

    if full_name in content:
        return True

    # 去括号注释提取主名
    primary = re.sub(r"\s*[\(（\[【].*?[\)）\]】]\s*$", "", full_name).strip()
    if primary and primary != full_name and primary in content:
        return True

    # 括号中的别名
    for m in re.finditer(r"[\(（\[【](.+?)[\)）\]】]", full_name):
        alias = m.group(1).strip()
        if alias and len(alias) >= 2 and alias in content:
            return True

    return False


class EntityDimensionRegistry:
    """对标 C# EntityDimensionRegistry: 9 维度注册"""

    _all: List[EntityDimensionDescriptor] = None

    @classmethod
    def _build(cls) -> List[EntityDimensionDescriptor]:
        return [
            cls._build_character(),
            cls._build_faction(),
            cls._build_location(),
            cls._build_conflict(),
            cls._build_item(),
            cls._build_foreshadowing(),
            cls._build_secret(),
            cls._build_pledge(),
            cls._build_deadline(),
        ]

    @classmethod
    def all(cls) -> List[EntityDimensionDescriptor]:
        if cls._all is None:
            cls._all = cls._build()
        return cls._all

    @classmethod
    def get_by_code(cls, code: str) -> Optional[EntityDimensionDescriptor]:
        for d in cls.all():
            if d.DimensionCode.lower() == code.lower():
                return d
        return None

    @classmethod
    def auto_patch_dimensions(cls) -> List[EntityDimensionDescriptor]:
        return [d for d in cls.all() if d.Strategy == AUTO_PATCH]

    @classmethod
    def warn_only_dimensions(cls) -> List[EntityDimensionDescriptor]:
        return [d for d in cls.all() if d.Strategy == WARN_ONLY]

    # ---- 各维度构建 ----

    @staticmethod
    def _build_character():
        def load_recent(tracking, recent_volumes=5):
            data = tracking._stores["character_state"].data()
            result = []
            for cid, entry in data.items():
                if not isinstance(entry, dict) or not cid:
                    continue
                name = entry.get("Name", "")
                if not name:
                    continue
                result.append(DriftEntityRecord(cid, name, 0, list(entry.get("DriftWarnings") or [])))
            return result

        def extract_declared(changes):
            return {c.CharacterId for c in changes.CharacterStateChanges if c.CharacterId}

        def append_warning(tracking, vol, eid, name, warn_msg, max_warn):
            store = tracking._stores["character_state"]
            data = store.data()
            entry = data.setdefault(eid, {"Name": name})
            if not isinstance(entry, dict):
                entry = {"Name": name}
                data[eid] = entry
            append_bounded_warning(entry, warn_msg, max_warn)
            store.set_all(data)
            return "character_state"

        def auto_patch(changes, eid, name, reason):
            from ....models import CharacterStateChange
            if any(c.CharacterId and str(c.CharacterId).lower() == str(eid).lower()
                   for c in changes.CharacterStateChanges):
                return
            changes.CharacterStateChanges.append(CharacterStateChange(
                CharacterId=eid, KeyEvent=f"[自动补录] {reason}", Importance="normal"))

        return EntityDimensionDescriptor(
            DimensionName="角色", DimensionCode="character", GuideFileName="character_state_guide.json",
            IsVolumeScoped=True, Strategy=AUTO_PATCH, ChangeFieldName="CharacterStateChanges",
            LoadRecentEntities=load_recent, ExtractDeclaredIds=extract_declared,
            AppendDriftWarning=append_warning, AutoPatchAction=auto_patch)

    @staticmethod
    def _build_faction():
        def load_recent(tracking, recent_volumes=5):
            data = tracking._stores["faction_state"].data()
            return [DriftEntityRecord(fid, e.get("Name", ""), 0, list(e.get("DriftWarnings") or []))
                    for fid, e in data.items() if isinstance(e, dict) and fid and e.get("Name")]

        def extract_declared(changes):
            return {f.FactionId for f in changes.FactionStateChanges if f.FactionId}

        def append_warning(tracking, vol, eid, name, warn_msg, max_warn):
            store = tracking._stores["faction_state"]
            data = store.data()
            entry = data.setdefault(eid, {"Name": name})
            append_bounded_warning(entry, warn_msg, max_warn)
            store.set_all(data)
            return "faction_state"

        def auto_patch(changes, eid, name, reason):
            from ....models import FactionStateChange
            if any(f.FactionId and str(f.FactionId).lower() == str(eid).lower()
                   for f in changes.FactionStateChanges):
                return
            changes.FactionStateChanges.append(FactionStateChange(
                FactionId=eid, Event=f"[自动补录] {reason}", Importance="normal"))

        return EntityDimensionDescriptor(
            DimensionName="势力", DimensionCode="faction", GuideFileName="faction_state_guide.json",
            IsVolumeScoped=True, Strategy=AUTO_PATCH, ChangeFieldName="FactionStateChanges",
            LoadRecentEntities=load_recent, ExtractDeclaredIds=extract_declared,
            AppendDriftWarning=append_warning, AutoPatchAction=auto_patch)

    @staticmethod
    def _build_location():
        def load_recent(tracking, recent_volumes=5):
            data = tracking._stores["location_state"].data()
            return [DriftEntityRecord(lid, e.get("Name", ""), 0, list(e.get("DriftWarnings") or []))
                    for lid, e in data.items() if isinstance(e, dict) and lid and e.get("Name")]

        def extract_declared(changes):
            return {l.LocationId for l in changes.LocationStateChanges if l.LocationId}

        def append_warning(tracking, vol, eid, name, warn_msg, max_warn):
            store = tracking._stores["location_state"]
            data = store.data()
            entry = data.setdefault(eid, {"Name": name})
            append_bounded_warning(entry, warn_msg, max_warn)
            store.set_all(data)
            return "location_state"

        def auto_patch(changes, eid, name, reason):
            from ....models import LocationStateChange
            if any(l.LocationId and str(l.LocationId).lower() == str(eid).lower()
                   for l in changes.LocationStateChanges):
                return
            changes.LocationStateChanges.append(LocationStateChange(
                LocationId=eid, LocationName=name, NewStatus="active",
                Event=f"[自动补录] {reason}", Importance="normal"))

        return EntityDimensionDescriptor(
            DimensionName="地点", DimensionCode="location", GuideFileName="location_state_guide.json",
            IsVolumeScoped=True, Strategy=AUTO_PATCH, ChangeFieldName="LocationStateChanges",
            LoadRecentEntities=load_recent, ExtractDeclaredIds=extract_declared,
            AppendDriftWarning=append_warning, AutoPatchAction=auto_patch)

    @staticmethod
    def _build_conflict():
        def load_recent(tracking, recent_volumes=5):
            data = tracking._stores["conflict_progress"].data()
            return [DriftEntityRecord(cid, e.get("Name", ""), 0, list(e.get("DriftWarnings") or []))
                    for cid, e in data.items() if isinstance(e, dict) and cid and e.get("Name")]

        def extract_declared(changes):
            return {c.ConflictId for c in changes.ConflictProgress if c.ConflictId}

        def append_warning(tracking, vol, eid, name, warn_msg, max_warn):
            store = tracking._stores["conflict_progress"]
            data = store.data()
            entry = data.setdefault(eid, {"Name": name})
            append_bounded_warning(entry, warn_msg, max_warn)
            store.set_all(data)
            return "conflict_progress"

        return EntityDimensionDescriptor(
            DimensionName="冲突", DimensionCode="conflict", GuideFileName="conflict_progress_guide.json",
            IsVolumeScoped=True, Strategy=WARN_ONLY, ChangeFieldName="ConflictProgress",
            LoadRecentEntities=load_recent, ExtractDeclaredIds=extract_declared,
            AppendDriftWarning=append_warning)

    @staticmethod
    def _build_item():
        def load_recent(tracking, recent_volumes=5):
            data = tracking._stores["item_state"].data()
            return [DriftEntityRecord(iid, e.get("Name", ""), 0, list(e.get("DriftWarnings") or []))
                    for iid, e in data.items() if isinstance(e, dict) and iid and e.get("Name")]

        def extract_declared(changes):
            return {i.ItemId for i in changes.ItemTransfers if i.ItemId}

        def append_warning(tracking, vol, eid, name, warn_msg, max_warn):
            store = tracking._stores["item_state"]
            data = store.data()
            entry = data.setdefault(eid, {"Name": name})
            append_bounded_warning(entry, warn_msg, max_warn)
            store.set_all(data)
            return "item_state"

        return EntityDimensionDescriptor(
            DimensionName="物品", DimensionCode="item", GuideFileName="item_state_guide.json",
            IsVolumeScoped=True, Strategy=WARN_ONLY, ChangeFieldName="ItemTransfers",
            LoadRecentEntities=load_recent, ExtractDeclaredIds=extract_declared,
            AppendDriftWarning=append_warning)

    @staticmethod
    def _build_foreshadowing():
        def load_recent(tracking, recent_volumes=5):
            data = tracking._stores["foreshadowing"].data()
            return [DriftEntityRecord(fid, e.get("Name", ""), 0, list(e.get("DriftWarnings") or []))
                    for fid, e in data.items()
                    if isinstance(e, dict) and fid not in ("PendingList", "OverdueList") and e.get("Name")]

        def extract_declared(changes):
            return {f.ForeshadowId for f in changes.ForeshadowingActions if f.ForeshadowId}

        def append_warning(tracking, vol, eid, name, warn_msg, max_warn):
            store = tracking._stores["foreshadowing"]
            data = store.data()
            entry = data.setdefault(eid, {"Name": name})
            append_bounded_warning(entry, warn_msg, max_warn)
            store.set_all(data)
            return "foreshadowing"

        return EntityDimensionDescriptor(
            DimensionName="伏笔", DimensionCode="foreshadowing", GuideFileName="foreshadowing_status_guide.json",
            IsVolumeScoped=False, Strategy=WARN_ONLY, ChangeFieldName="ForeshadowingActions",
            LoadRecentEntities=load_recent, ExtractDeclaredIds=extract_declared,
            AppendDriftWarning=append_warning)

    @staticmethod
    def _build_secret():
        def load_recent(tracking, recent_volumes=5):
            data = tracking._stores["secret"].data()
            return [DriftEntityRecord(sid, e.get("Name", ""), 0, list(e.get("DriftWarnings") or []))
                    for sid, e in data.items() if isinstance(e, dict) and sid and e.get("Name")]

        def extract_declared(changes):
            return {s.SecretId for s in changes.SecretRevealChanges if s.SecretId}

        def append_warning(tracking, vol, eid, name, warn_msg, max_warn):
            store = tracking._stores["secret"]
            data = store.data()
            entry = data.setdefault(eid, {"Name": name})
            append_bounded_warning(entry, warn_msg, max_warn)
            store.set_all(data)
            return "secret"

        return EntityDimensionDescriptor(
            DimensionName="秘密", DimensionCode="secret", GuideFileName="secret_reveal_guide.json",
            IsVolumeScoped=True, Strategy=WARN_ONLY, ChangeFieldName="SecretRevealChanges",
            LoadRecentEntities=load_recent, ExtractDeclaredIds=extract_declared,
            AppendDriftWarning=append_warning)

    @staticmethod
    def _build_pledge():
        def load_recent(tracking, recent_volumes=5):
            data = tracking._stores["pledge"].data()
            return [DriftEntityRecord(pid, e.get("Name", ""), 0, list(e.get("DriftWarnings") or []))
                    for pid, e in data.items() if isinstance(e, dict) and pid and e.get("Name")]

        def extract_declared(changes):
            return {p.PledgeId for p in changes.PledgeConstraintChanges if p.PledgeId}

        def append_warning(tracking, vol, eid, name, warn_msg, max_warn):
            store = tracking._stores["pledge"]
            data = store.data()
            entry = data.setdefault(eid, {"Name": name})
            append_bounded_warning(entry, warn_msg, max_warn)
            store.set_all(data)
            return "pledge"

        return EntityDimensionDescriptor(
            DimensionName="承诺", DimensionCode="pledge", GuideFileName="pledge_constraint_guide.json",
            IsVolumeScoped=True, Strategy=WARN_ONLY, ChangeFieldName="PledgeConstraintChanges",
            LoadRecentEntities=load_recent, ExtractDeclaredIds=extract_declared,
            AppendDriftWarning=append_warning)

    @staticmethod
    def _build_deadline():
        def load_recent(tracking, recent_volumes=5):
            data = tracking._stores["deadline"].data()
            return [DriftEntityRecord(did, e.get("Name", ""), 0, list(e.get("DriftWarnings") or []))
                    for did, e in data.items() if isinstance(e, dict) and did and e.get("Name")]

        def extract_declared(changes):
            return {d.DeadlineId for d in changes.DeadlineConstraintChanges if d.DeadlineId}

        def append_warning(tracking, vol, eid, name, warn_msg, max_warn):
            store = tracking._stores["deadline"]
            data = store.data()
            entry = data.setdefault(eid, {"Name": name})
            append_bounded_warning(entry, warn_msg, max_warn)
            store.set_all(data)
            return "deadline"

        return EntityDimensionDescriptor(
            DimensionName="倒计时", DimensionCode="deadline", GuideFileName="deadline_constraint_guide.json",
            IsVolumeScoped=True, Strategy=WARN_ONLY, ChangeFieldName="DeadlineConstraintChanges",
            LoadRecentEntities=load_recent, ExtractDeclaredIds=extract_declared,
            AppendDriftWarning=append_warning)