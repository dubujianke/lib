# -*- coding: utf-8 -*-
"""实体漂移兜底结果 — 对标 4.1.1 EntityDrift/EntityDriftFallbackResult.cs

结果: AutoPatchedCount / WarnOnlyCount / DirtyGuideFiles / Details
"""

from dataclasses import dataclass, field
from typing import List, Set


@dataclass
class EntityDriftFallbackResult:
    """对标 C# EntityDriftFallbackResult"""
    AutoPatchedCount: int = 0
    WarnOnlyCount: int = 0
    DirtyGuideFiles: Set[str] = field(default_factory=set)
    Details: List[str] = field(default_factory=list)

    @property
    def PatchedChanges(self) -> bool:
        return self.AutoPatchedCount > 0

    @property
    def HasAnyDrift(self) -> bool:
        return self.AutoPatchedCount > 0 or self.WarnOnlyCount > 0