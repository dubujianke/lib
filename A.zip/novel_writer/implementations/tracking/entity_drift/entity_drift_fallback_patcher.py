# -*- coding: utf-8 -*-
"""实体漂移兜底补录器 — 对标 4.1.1 EntityDrift/EntityDriftFallbackPatcher.cs

对齐功能:
- DetectAndApplyAsync: 检测 + 写入 DriftWarning + AutoPatch（补录 CHANGES）
"""

from .entity_drift_fallback_result import EntityDriftFallbackResult
from .entity_dimension_descriptor import AUTO_PATCH
from .entity_dimension_registry import EntityDimensionRegistry, name_exists_in_content


class EntityDriftFallbackPatcher:
    """对标 C# EntityDriftFallbackPatcher: DriftWarnings + AutoPatch"""

    def __init__(self, project, tracking_manager=None):
        self.project = project
        self.tracking = tracking_manager

    def detect_and_apply(self, chapter_id: str, summary: str, changes,
                         recent_volumes: int = 5,
                         min_name_length: int = 2, max_warn: int = 100000) -> EntityDriftFallbackResult:
        """对标 DetectAndApplyAsync: 检测 + 写入 DriftWarning + AutoPatch"""
        result = EntityDriftFallbackResult()
        if not summary or changes is None:
            return result

        for descriptor in EntityDimensionRegistry.all():
            try:
                declared_ids = descriptor.ExtractDeclaredIds(changes)
                entities = descriptor.LoadRecentEntities(self.tracking, recent_volumes)
                if not entities:
                    continue

                for entity in entities:
                    if entity.Id in declared_ids:
                        continue
                    if not entity.Name or len(entity.Name) < min_name_length:
                        continue
                    if not name_exists_in_content(summary, entity.Name):
                        continue

                    warn_msg = f"{chapter_id}: 出现于摘要但CHANGES未申报，状态可能不一致"
                    dirty_file = None
                    try:
                        dirty_file = descriptor.AppendDriftWarning(
                            self.tracking, 0, entity.Id, entity.Name, warn_msg, max_warn)
                    except Exception:
                        pass

                    if dirty_file:
                        result.DirtyGuideFiles.add(dirty_file)

                    if descriptor.Strategy == AUTO_PATCH and descriptor.AutoPatchAction is not None:
                        try:
                            descriptor.AutoPatchAction(changes, entity.Id, entity.Name,
                                                       "出现于本章正文，CHANGES未申报")
                            declared_ids.add(entity.Id)
                            result.AutoPatchedCount += 1
                            result.Details.append(f"[{descriptor.DimensionName}-补录] {entity.Name}（{entity.Id}）")
                        except Exception:
                            pass
                    else:
                        result.WarnOnlyCount += 1
                        result.Details.append(f"[{descriptor.DimensionName}-告警] {entity.Name}（{entity.Id}）")
            except Exception:
                continue

        return result