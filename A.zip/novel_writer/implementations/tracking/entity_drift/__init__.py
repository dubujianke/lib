# -*- coding: utf-8 -*-
"""实体漂移检测框架子包 — 对标 4.1.1 Tracking/EntityDrift 目录

每类一个文件：
- EntityOmissionRecord
- EntityDriftFallbackResult
- EntityDimensionDescriptor（+ DriftEntityRecord + DriftStrategy）
- EntityDimensionRegistry（9 维度）
- EntityOmissionDetector
- EntityDriftFallbackPatcher
"""

from .entity_omission_record import EntityOmissionRecord
from .entity_drift_fallback_result import EntityDriftFallbackResult
from .entity_dimension_descriptor import (
    EntityDimensionDescriptor, DriftEntityRecord, AUTO_PATCH, WARN_ONLY,
)
from .entity_dimension_registry import (
    EntityDimensionRegistry, append_bounded_warning, name_exists_in_content,
)
from .entity_omission_detector import EntityOmissionDetector
from .entity_drift_fallback_patcher import EntityDriftFallbackPatcher

__all__ = [
    "EntityOmissionRecord", "EntityDriftFallbackResult",
    "EntityDimensionDescriptor", "DriftEntityRecord", "AUTO_PATCH", "WARN_ONLY",
    "EntityDimensionRegistry", "append_bounded_warning", "name_exists_in_content",
    "EntityOmissionDetector", "EntityDriftFallbackPatcher",
]