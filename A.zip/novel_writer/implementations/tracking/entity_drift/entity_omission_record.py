# -*- coding: utf-8 -*-
"""实体漏报记录 — 对标 4.1.1 EntityDrift/EntityOmissionRecord.cs

记录: 维度名/维度码/实体ID/实体名/变更字段名
"""

from dataclasses import dataclass


@dataclass
class EntityOmissionRecord:
    """对标 C# EntityOmissionRecord"""
    DimensionName: str
    DimensionCode: str
    EntityId: str
    EntityName: str
    ChangeFieldName: str