# -*- coding: utf-8 -*-
"""实体维度描述 — 对标 4.1.1 EntityDrift/EntityDimensionDescriptor.cs

包含:
- DriftStrategy 枚举（AutoPatch / WarnOnly）
- DriftEntityRecord（实体记录）
- EntityDimensionDescriptor（维度描述）
"""

from dataclasses import dataclass, field
from typing import Callable, List, Optional

# 对标 C# DriftStrategy 枚举
AUTO_PATCH = "AutoPatch"
WARN_ONLY = "WarnOnly"


@dataclass
class DriftEntityRecord:
    """对标 C# DriftEntityRecord record"""
    Id: str
    Name: str
    VolumeNumber: int
    DriftWarnings: List[str] = field(default_factory=list)


class EntityDimensionDescriptor:
    """对标 C# EntityDimensionDescriptor"""

    def __init__(self,
                 DimensionName: str = "",
                 DimensionCode: str = "",
                 GuideFileName: str = "",
                 IsVolumeScoped: bool = False,
                 Strategy: str = WARN_ONLY,
                 ChangeFieldName: str = "",
                 LoadRecentEntities: Optional[Callable] = None,
                 ExtractDeclaredIds: Optional[Callable] = None,
                 AppendDriftWarning: Optional[Callable] = None,
                 AutoPatchAction: Optional[Callable] = None):
        self.DimensionName = DimensionName
        self.DimensionCode = DimensionCode
        self.GuideFileName = GuideFileName
        self.IsVolumeScoped = IsVolumeScoped
        self.Strategy = Strategy
        self.ChangeFieldName = ChangeFieldName
        self.LoadRecentEntities = LoadRecentEntities
        self.ExtractDeclaredIds = ExtractDeclaredIds
        self.AppendDriftWarning = AppendDriftWarning
        self.AutoPatchAction = AutoPatchAction