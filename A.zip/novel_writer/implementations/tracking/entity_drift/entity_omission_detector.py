# -*- coding: utf-8 -*-
"""实体漏报检测器 — 对标 4.1.1 EntityDrift/EntityOmissionDetector.cs

对齐功能:
- DetectAsync: 各维度检测"正文出现但 CHANGES 未申报"的实体
"""

from typing import List

from .entity_omission_record import EntityOmissionRecord
from .entity_dimension_registry import EntityDimensionRegistry, name_exists_in_content


class EntityOmissionDetector:
    """对标 C# EntityOmissionDetector: 正文出现但CHANGES未申报 → 检测"""

    def __init__(self, project, tracking_manager=None):
        self.project = project
        self.tracking = tracking_manager

    def detect(self, content: str, changes, recent_volumes: int = 5,
               min_name_length: int = 2) -> List[EntityOmissionRecord]:
        """对标 DetectAsync: 各维度检测漏报实体"""
        if not content or changes is None:
            return []

        omissions = []
        for descriptor in EntityDimensionRegistry.all():
            try:
                declared_ids = descriptor.ExtractDeclaredIds(changes)
                entities = descriptor.LoadRecentEntities(self.tracking, recent_volumes)
                if not entities:
                    continue
                for entity in entities:
                    if entity.Id in declared_ids:
                        continue
                    if not entity.Name or len(entity.Name) < min_name_length:
                        continue
                    if not name_exists_in_content(content, entity.Name):
                        continue
                    omissions.append(EntityOmissionRecord(
                        descriptor.DimensionName, descriptor.DimensionCode,
                        entity.Id, entity.Name, descriptor.ChangeFieldName))
            except Exception:
                continue
        return omissions