# -*- coding: utf-8 -*-
"""物品状态服务 — 对标 4.1.1 ItemStateService.cs（完整移植 153 行）

对齐功能:
- UpdateItemStateAsync（守卫 + ID归并 + create + 持有者/状态更新 + 完整快照）
- RemoveChapterDataAsync（删除历史 + 回填 Holder/Status）
- GetAllItemStatesAsync
- FindExistingItemId（按 ID/Name 归并）
"""

from typing import Dict, List, Optional

from .character_state_service import build_chapter_id, parse_chapter_id
from .deadline_constraint_service import _is_likely_id, _new_deadline_id


def _new_item_id() -> str:
    """对标 ShortIdGenerator.New("I"): 前缀首字符'I' + 12位 = 13位"""
    return _new_deadline_id().replace("D", "I", 1)


class ItemStateService:
    """对标 4.1.1 ItemStateService — 物品状态管理（独立类）

    调用链与 C# 完全一致：
    - 读: GuideManager.GetExistingVolumeNumbers + GetVolumeFileName + GetGuideAsync<ItemStateGuide>
    - 写: GuideManager.MarkDirty(volFile)
    """

    BaseFileName = "item_state_guide.json"
    GUIDE_FIELD = "Items"
    HISTORY_FIELD = "StateHistory"

    def __init__(self, project, tracking_manager=None, guide_manager=None):
        self.project = project
        self.tracking = tracking_manager
        self._store = None
        # 对标 C# _guideManager（未提供时延迟创建）
        self._guide_manager = guide_manager

    def _get_guide_manager(self):
        if self._guide_manager is None:
            try:
                from ..guides.guide_manager import GuideManager
                self._guide_manager = GuideManager(self.project)
            except Exception:
                return None
        return self._guide_manager

    @classmethod
    def _volume_file_name(cls, chapter_id: str) -> str:
        """对标 C# VolumeFileName(chapterId): GuideManager.GetVolumeFileName(BaseFileName, vol)"""
        from ..guides.guide_manager import GuideManager
        vol, _ = parse_chapter_id(chapter_id)
        return GuideManager.get_volume_file_name(cls.BaseFileName, vol)

    def _get_store(self):
        if self._store is None:
            if self.tracking is not None:
                self._store = self.tracking._stores["item_state"]
            else:
                self._store = self.project.tracking("item_state")
        return self._store

    # ---- ID 归并 ----

    @staticmethod
    def find_existing_item_id(data: dict, ai_item_id: str, ai_item_name: str) -> Optional[str]:
        """对标 FindExistingItemId: 按 ID 或 Name 匹配已有物品"""
        if ai_item_id and ai_item_id in data:
            return ai_item_id
        for iid, entry in data.items():
            if not isinstance(entry, dict):
                continue
            name = entry.get("Name", "")
            if name and str(name).lower() == str(ai_item_id).lower():
                return iid
            if ai_item_name and name and str(name).lower() == str(ai_item_name).lower():
                return iid
        return None

    # ---- 更新 ----

    def update_item_state(self, chapter_id: str, change) -> Optional[str]:
        """对标 UpdateItemStateAsync: 更新/创建物品状态

        change: ItemTransferChange（ItemId/ItemName/FromHolder/ToHolder/NewStatus/Event/Importance/CausedBy）
        """
        if not change.ItemId:
            return None

        store = self._get_store()
        data = store.data()

        system_id = self.find_existing_item_id(data, change.ItemId, change.ItemName)

        if system_id is None:
            system_id = change.ItemId if _is_likely_id(change.ItemId) else _new_item_id()
            display_name = change.ItemName if change.ItemName else change.ItemId
            if system_id not in data:
                data[system_id] = {
                    "Name": display_name,
                    "Description": "",
                    "CurrentHolder": change.ToHolder,
                    "CurrentStatus": change.NewStatus if change.NewStatus else "active",
                    self.HISTORY_FIELD: [],
                    "DriftWarnings": [],
                }

        entry = data[system_id]
        # 补齐默认字段
        entry.setdefault("Description", "")
        entry.setdefault("CurrentStatus", "active")
        entry.setdefault("DriftWarnings", [])
        history = entry.setdefault(self.HISTORY_FIELD, [])
        if not isinstance(history, list):
            history = []
            entry[self.HISTORY_FIELD] = history

        if change.ItemName:
            entry["Name"] = change.ItemName

        if change.ToHolder:
            entry["CurrentHolder"] = change.ToHolder
        elif change.NewStatus and str(change.NewStatus).lower() != "active":
            entry["CurrentHolder"] = ""

        if change.NewStatus:
            entry["CurrentStatus"] = change.NewStatus

        # 完整快照（对标 C# ItemStatePoint）
        holder = change.ToHolder if change.ToHolder else entry.get("CurrentHolder", "")
        status = change.NewStatus if change.NewStatus else entry.get("CurrentStatus", "")
        history.append({
            "Chapter": chapter_id,
            "Holder": holder,
            "Status": status,
            "Event": change.Event,
            "Importance": change.Importance if change.Importance else "normal",
            "CausedBy": change.CausedBy or "",
        })

        store.set_all(data)

        # 对标 C#: var guide = GetGuideAsync(volFile) ... _guideManager.MarkDirty(volFile)
        gm = self._get_guide_manager()
        if gm is not None:
            try:
                vol_file = self._volume_file_name(chapter_id)
                guide = gm.get_guide(vol_file)
                # 同步到分卷 guide（Items 字典 + StateHistory）
                if isinstance(guide, dict):
                    items = guide.setdefault(self.GUIDE_FIELD, {})
                    g_entry = items.get(system_id)
                    if not isinstance(g_entry, dict):
                        items[system_id] = {
                            "Name": entry.get("Name", ""),
                            "Description": entry.get("Description", ""),
                            "CurrentHolder": entry.get("CurrentHolder", ""),
                            "CurrentStatus": entry.get("CurrentStatus", ""),
                            "DriftWarnings": list(entry.get("DriftWarnings") or []),
                            self.HISTORY_FIELD: [history[-1]],
                        }
                    else:
                        g_entry["Name"] = entry.get("Name", g_entry.get("Name", ""))
                        g_entry["CurrentHolder"] = entry.get("CurrentHolder",
                                                             g_entry.get("CurrentHolder", ""))
                        g_entry["CurrentStatus"] = entry.get("CurrentStatus",
                                                             g_entry.get("CurrentStatus", "active"))
                        g_history = g_entry.setdefault(self.HISTORY_FIELD, [])
                        g_history.append(history[-1])
                    gm.mark_dirty(vol_file)
            except Exception:
                pass

        return system_id

    # ---- 删除章节 ----

    def remove_chapter_data(self, chapter_id: str) -> int:
        """对标 RemoveChapterDataAsync: 删除历史 + 回填 Holder/Status"""
        store = self._get_store()
        data = store.data()
        modified = False
        removed_total = 0

        for entry in list(data.values()):
            if not isinstance(entry, dict):
                continue
            history = entry.get(self.HISTORY_FIELD)
            if not isinstance(history, list):
                continue
            before = len(history)
            history[:] = [s for s in history
                          if not (s.get("Chapter", "") and s["Chapter"] == chapter_id)]
            removed = before - len(history)
            if removed > 0:
                modified = True
                removed_total += removed
                history.sort(key=lambda s: parse_chapter_id(s.get("Chapter", "")))
                if history:
                    last = history[-1]
                    entry["CurrentHolder"] = last.get("Holder", "")
                    entry["CurrentStatus"] = last.get("Status", "")
                else:
                    entry["CurrentHolder"] = ""
                    entry["CurrentStatus"] = "unknown"

        if modified:
            store.set_all(data)
            # 对标 C#: 修改后 _guideManager.MarkDirty(volFile)
            gm = self._get_guide_manager()
            if gm is not None:
                try:
                    vol_file = self._volume_file_name(chapter_id)
                    guide = gm.get_guide(vol_file)
                    if isinstance(guide, dict):
                        g_modified = False
                        for g_entry in (guide.get(self.GUIDE_FIELD) or {}).values():
                            if not isinstance(g_entry, dict):
                                continue
                            g_history = g_entry.get(self.HISTORY_FIELD)
                            if not isinstance(g_history, list):
                                continue
                            before = len(g_history)
                            g_history[:] = [s for s in g_history
                                            if s.get("Chapter", "") != chapter_id]
                            if len(g_history) < before:
                                g_modified = True
                                g_history.sort(key=lambda s: parse_chapter_id(s.get("Chapter", "")))
                                if g_history:
                                    last = g_history[-1]
                                    g_entry["CurrentHolder"] = last.get("Holder", "")
                                    g_entry["CurrentStatus"] = last.get("Status", "")
                                else:
                                    g_entry["CurrentHolder"] = ""
                                    g_entry["CurrentStatus"] = "unknown"
                        if g_modified:
                            gm.mark_dirty(vol_file)
                except Exception:
                    pass
        return removed_total

    # ---- 查询 ----

    def get_all_item_states(self) -> Dict[str, dict]:
        """对标 GetAllItemStatesAsync: 合并最近卷的 Items（TakeLast(5)），回退 store"""
        gm = self._get_guide_manager()
        if gm is not None:
            try:
                # 对标: var volNumbers = _guideManager.GetExistingVolumeNumbers(BaseFileName)
                vol_numbers = gm.get_existing_volume_numbers(self.BaseFileName)
                merged = {}
                for vol in vol_numbers[-5:]:
                    vol_file = gm.get_volume_file_name(self.BaseFileName, vol)
                    guide = gm.get_guide(vol_file)
                    if not isinstance(guide, dict):
                        continue
                    items = guide.get(self.GUIDE_FIELD)
                    if isinstance(items, dict):
                        for iid, entry in items.items():
                            if isinstance(entry, dict):
                                merged[iid] = entry
                if merged:
                    return merged
                # 分卷未找到时回退 store
            except Exception:
                pass
        store = self._get_store()
        data = store.data()
        return {iid: entry for iid, entry in data.items() if isinstance(entry, dict)}