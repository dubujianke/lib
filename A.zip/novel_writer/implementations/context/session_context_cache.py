# -*- coding: utf-8 -*-
"""会话上下文缓存 — 对标 Implementations/Context/SessionContextCache.cs"""
import threading
import time
from typing import Optional


class SessionContextCache:
    CACHE_TTL_SECONDS = 300  # 5 分钟
    MAX_CACHE_ENTRIES = 500

    def __init__(self):
        self._cache = {}
        self._invalidated_ids = set()
        self._cache_lock = threading.Lock()
        self._loading_tasks = {}
        self._cache_epoch = 0

    def get_or_load(self, id: str, loader):
        with self._cache_lock:
            if id in self._invalidated_ids:
                self._cache.pop(id, None)
                self._invalidated_ids.discard(id)
            if id in self._cache:
                entry = self._cache[id]
                if time.time() - entry["cached_at"] > self.CACHE_TTL_SECONDS:
                    self._cache.pop(id)
                else:
                    return entry["data"]
        data = loader()
        with self._cache_lock:
            self._cache[id] = {"data": data, "cached_at": time.time()}
            if len(self._cache) > self.MAX_CACHE_ENTRIES:
                oldest = min(self._cache, key=lambda k: self._cache[k]["cached_at"])
                self._cache.pop(oldest)
        return data

    def try_get(self, id: str):
        with self._cache_lock:
            if id in self._invalidated_ids:
                self._cache.pop(id, None)
                self._invalidated_ids.discard(id)
                return None
            entry = self._cache.get(id)
            return entry["data"] if entry else None

    def set(self, id: str, data):
        with self._cache_lock:
            self._cache_epoch += 1
            self._cache[id] = {"data": data, "cached_at": time.time()}
            self._invalidated_ids.discard(id)

    def invalidate_entity(self, id: str):
        with self._cache_lock:
            self._cache_epoch += 1
            self._cache.pop(id, None)
            self._invalidated_ids.add(id)

    def invalidate_layer(self, layer: str):
        with self._cache_lock:
            self._cache_epoch += 1
            keys = [k for k in list(self._cache.keys()) + list(self._loading_tasks.keys())
                    if k.startswith(f"{layer}_")]
            for k in keys:
                self._cache.pop(k, None)
                self._invalidated_ids.add(k)
                self._loading_tasks.pop(k, None)

    def clear(self):
        with self._cache_lock:
            self._cache_epoch += 1
            self._cache.clear()
            self._invalidated_ids.clear()
            self._loading_tasks.clear()

    def get_stats(self):
        with self._cache_lock:
            return (len(self._cache), len(self._invalidated_ids))

    def reset(self):
        self.clear()
