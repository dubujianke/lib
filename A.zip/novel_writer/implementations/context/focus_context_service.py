# -*- coding: utf-8 -*-
"""焦点上下文服务 — 对标 Implementations/Context/FocusContextService.cs"""
import functools
import threading
import time
from typing import Dict, List, Optional

from ...models.context.focus_context import (
    FocusContext, DesignFocusContext, GenerateFocusContext,
)
from ...models.context.global_summary import GlobalSummary
from ...models.context.tracking_status import TrackingStatus


# 层级名 → 设计存储键（英文/中文层名均支持，对标 LayerStorageKeys）
_LAYER_DESIGN_KEYS = {
    "Characters": "characters", "角色": "characters",
    "Factions": "factions", "势力": "factions",
    "Locations": "locations", "位置": "locations", "地点": "locations",
    "Plot": "plot", "剧情": "plot",
    "Worldview": "world", "世界观": "world",
    "Templates": "materials", "素材": "materials",
    "SmartParsing": "materials", "拆书": "materials",
}

# 设计存储键 → (类型字段, 默认类型)
_DESIGN_TYPE_FIELDS = {
    "characters": ("CharacterType", "角色"),
    "factions": ("FactionType", "势力"),
    "locations": ("LocationType", "位置"),
    "plot": ("EventType", "剧情"),
    "world": ("RuleType", "世界观规则"),
    "materials": ("MaterialType", "素材"),
}

_ALL_DESIGN_STORES = ("characters", "factions", "locations", "plot", "world", "materials")


class FocusContextService:
    CONTEXT_CACHE_EXPIRY_SECONDS = 30

    def __init__(self, project, index_service=None, relation_strength_service=None,
                 guide_context_service=None, global_summary_service=None,
                 guide_manager=None, plot_points_service=None):
        self.project = project
        self._index_service = index_service
        self._relation_strength_service = relation_strength_service
        self._guide_context_service = guide_context_service
        self._global_summary_service = global_summary_service
        self._guide_manager = guide_manager
        self._plot_points_service = plot_points_service
        self._cache_lock = threading.Lock()
        self._design_context_cache: Dict[str, tuple] = {}
        self._generate_context_cache: Dict[str, tuple] = {}

    def get_design_context(self, focus_id: str, target_layer: str) -> DesignFocusContext:
        cache_key = self._build_cache_key("Design", focus_id, target_layer)
        with self._cache_lock:
            cached = self._design_context_cache.get(cache_key)
            if cached and time.time() - cached[0] < self.CONTEXT_CACHE_EXPIRY_SECONDS:
                return cached[1]
        upstream = self._index_service.build_upstream_index(target_layer) if self._index_service else None
        focus = self._build_focus_context(focus_id, target_layer)
        focus.UpstreamIndex = upstream
        context = DesignFocusContext(
            GlobalSummary=self._get_global_summary(),
            TrackingStatus=self._get_tracking_status(focus_id, getattr(focus, "FocusEntity", None)),
            UpstreamIndex=upstream or (focus.UpstreamIndex if focus else None),
            Focus=focus)
        with self._cache_lock:
            self._design_context_cache[cache_key] = (time.time(), context)
        return context

    def get_generate_context(self, focus_id: str, target_layer: str) -> GenerateFocusContext:
        cache_key = self._build_cache_key("Generate", focus_id, target_layer)
        with self._cache_lock:
            cached = self._generate_context_cache.get(cache_key)
            if cached and time.time() - cached[0] < self.CONTEXT_CACHE_EXPIRY_SECONDS:
                return cached[1]
        upstream = self._index_service.build_upstream_index(target_layer) if self._index_service else None
        focus = self._build_focus_context(focus_id, target_layer)
        focus.UpstreamIndex = upstream
        context = GenerateFocusContext(
            GlobalSummary=self._get_global_summary(),
            TrackingStatus=self._get_tracking_status(focus_id, getattr(focus, "FocusEntity", None)),
            UpstreamIndex=upstream,
            Focus=focus,
            TaskContext=self._load_task_context(focus_id, target_layer))
        with self._cache_lock:
            self._generate_context_cache[cache_key] = (time.time(), context)
        return context

    def _build_focus_context(self, focus_id: str, target_layer: str) -> FocusContext:
        """对标 BuildFocusContextAsync: 焦点实体 + 引导关系 + 强度服务兜底"""
        focus = FocusContext(FocusId=focus_id, FocusType=target_layer, Layer=target_layer,
                             DirectRelations=[], IndirectRelations=[])
        if not focus_id:
            return focus
        # 焦点实体加载（对标 _indexService.GetIndexItemAsync(focusId, targetLayer)）
        focus_item = self._load_focus_entity(focus_id, target_layer)
        if focus_item is not None:
            focus.FocusEntity = focus_item
        # 引导关系加载（对标 _guideContextService.GetRelatedEntitiesAsync）
        direct, indirect = self._load_guide_relations(focus_id, target_layer)
        focus.DirectRelations = direct
        focus.IndirectRelations = indirect
        # 关系为空时通过强度服务兜底（对标 LoadRelationsViaStrengthServiceAsync）
        if not focus.DirectRelations and not focus.IndirectRelations:
            self._load_relations_via_strength_service(focus, focus_id)
        return focus

    # ---- 焦点实体解析 ----

    def _load_focus_entity(self, focus_id: str, target_layer: str):
        """从 design（characters/factions/locations/...）按 focus_id 解析实体名与类型"""
        try:
            stores = []
            hinted = _LAYER_DESIGN_KEYS.get(target_layer)
            if hinted:
                stores.append(hinted)
            for store in _ALL_DESIGN_STORES:
                if store not in stores:
                    stores.append(store)
            for store in stores:
                item = self._find_design_entity(focus_id, store)
                if item is not None:
                    return self._to_index_item(item, store)
        except Exception:
            pass
        return None

    def _find_design_entity(self, entity_id: str, store: str) -> Optional[dict]:
        try:
            data = self.project.load_design(store)
            items = data.get("items", []) if isinstance(data, dict) else (data or [])
            for item in items:
                if isinstance(item, dict) and item.get("Id") == entity_id:
                    return item
        except Exception:
            pass
        return None

    def _to_index_item(self, item: dict, store: str):
        type_field, default_type = _DESIGN_TYPE_FIELDS.get(store, (None, store))
        item_type = item.get(type_field) if type_field else None
        data = {
            "Id": item.get("Id", ""),
            "Name": item.get("Name", "") or item.get("Id", ""),
            "Type": item_type or default_type,
            "BriefSummary": item.get("OneLineSummary", "") or item.get("BriefSummary", ""),
        }
        if self._index_service is not None:
            try:
                return self._index_service.build_index_item(data)
            except Exception:
                pass
        from ...models.index.index_item import IndexItem
        return IndexItem(Id=data["Id"], Name=data["Name"], Type=data["Type"],
                         BriefSummary=data["BriefSummary"])

    def _build_character_index_item(self, char_id: str):
        """对标 GetIndexItemAsync(charId, "Characters"): 解析名称/类型构建索引项"""
        item = self._find_design_entity(char_id, "characters") or {"Id": char_id, "Name": char_id}
        return self._to_index_item(item, "characters")

    # ---- 引导关系 ----

    def _load_guide_relations(self, focus_id: str, target_layer: str):
        """对标 GetRelatedEntitiesAsync: 返回 (direct, indirect)；不可用时静默返回空"""
        if self._guide_context_service is None:
            return [], []
        try:
            result = self._guide_context_service.get_related_entities(focus_id, target_layer)
            if not result:
                return [], []
            direct, indirect = result
            return list(direct or []), list(indirect or [])
        except Exception:
            return [], []

    def _get_all_character_ids(self) -> List[str]:
        # 优先走 GuideContextService.GetAllCharactersAsync（对标 C#）
        if self._guide_context_service is not None:
            try:
                chars = self._guide_context_service.get_all_characters()
                ids = [c.get("Id", "") for c in (chars or [])
                       if isinstance(c, dict) and c.get("Id")]
                if ids:
                    return ids
            except Exception:
                pass
        try:
            data = self.project.load_design("characters")
            items = data.get("items", []) if isinstance(data, dict) else (data or [])
            return [c.get("Id", "") for c in items if c.get("Id")]
        except Exception:
            return []

    def _get_global_summary(self) -> GlobalSummary:
        if self._global_summary_service:
            return self._global_summary_service.get_global_summary()
        from ..summary.global_summary_service import GlobalSummaryService
        return GlobalSummaryService(self.project).get_global_summary()

    def _get_tracking_status(self, focus_id: str = None, entity=None) -> TrackingStatus:
        """对标 GetTrackingStatusAsync → BuildTrackingStatusRealtimeAsync"""
        try:
            return self._build_tracking_status_realtime(focus_id, entity)
        except Exception:
            from ...models.context.tracking_status import TrackingStatus as TS
            return TS()

    def invalidate_cache(self):
        # 对标 C#: 级联失效 GlobalSummary / RelationStrength 缓存
        try:
            if self._global_summary_service and hasattr(self._global_summary_service, "invalidate_cache"):
                self._global_summary_service.invalidate_cache()
        except Exception:
            pass
        try:
            if self._relation_strength_service and hasattr(self._relation_strength_service, "invalidate_cache"):
                self._relation_strength_service.invalidate_cache()
        except Exception:
            pass
        with self._cache_lock:
            self._design_context_cache.clear()
            self._generate_context_cache.clear()

    # ---- 缺失方法移植 ----

    @staticmethod
    def _build_cache_key(kind: str, focus_id: str, target_layer: str) -> str:
        return f"{kind}|{target_layer}|{focus_id}"

    def _load_relations_via_strength_service(self, focus, focus_id: str):
        """对标 LoadRelationsViaStrengthServiceAsync"""
        all_ids = self._get_all_character_ids()
        for char_id in all_ids:
            if char_id == focus_id:
                continue
            strength = self._relation_strength_service.get_strength(focus_id, char_id) if self._relation_strength_service else 0
            if strength == 2 and len(focus.DirectRelations) < 5:
                item = self._build_character_index_item(char_id)
                if item:
                    item.RelationStrength = "Strong"
                    focus.DirectRelations.append(item)
            elif strength == 1 and len(focus.IndirectRelations) < 10:
                item = self._build_character_index_item(char_id)
                if item:
                    item.RelationStrength = "Medium"
                    focus.IndirectRelations.append(item)

    @staticmethod
    def _field(obj, name, default=None):
        """兼容 dict / 对象两种形态的字段读取"""
        if isinstance(obj, dict):
            return obj.get(name, default)
        return getattr(obj, name, default)

    def _get_guide_manager(self):
        if self._guide_manager is None:
            try:
                from ..guides.guide_manager import GuideManager
                self._guide_manager = GuideManager(self.project)
            except Exception:
                self._guide_manager = False
        return self._guide_manager or None

    def _get_plot_points_service(self):
        if self._plot_points_service is None:
            try:
                from ..indexing.plot_points_index_service import PlotPointsIndexService
                self._plot_points_service = PlotPointsIndexService(self.project)
            except Exception:
                self._plot_points_service = False
        return self._plot_points_service or None

    def _build_tracking_status_realtime(self, focus_id: str = None, entity=None):
        """对标 BuildTrackingStatusRealtimeAsync: 实时聚合角色状态/冲突进度/伏笔统计/情节点

        focus_id 与 entity 为 Python 侧预留入参（C# 经 ServiceLocator 取数，此处传入焦点信息），
        各子步骤独立 try/except 静默回退。
        """
        from ...models.context.tracking_status import (
            TrackingStatus as TS, CharacterState, ConflictProgress, ForeshadowingStats,
        )
        status = TS()

        # 角色状态（character_state_guide.json → 按最近出场章降序 Top30）
        try:
            from ...models.guides.state_guides.character_state_guide import CharacterStateGuide
            guide_manager = self._get_guide_manager()
            if guide_manager is not None:
                guide = guide_manager.get_guide("character_state_guide.json", CharacterStateGuide)
                characters = self._field(guide, "Characters", {}) or {}
                states = []
                for cid, entry in characters.items():
                    if not cid:
                        continue
                    history = self._field(entry, "StateHistory", []) or []
                    last = history[-1] if history else None
                    if last is not None:
                        parts = [p for p in (
                            self._field(last, "Phase", ""),
                            self._field(last, "Level", ""),
                            self._field(last, "MentalState", "")) if p]
                        current_status = "/".join(parts)
                        last_chapter = self._field(last, "Chapter", "") or ""
                    else:
                        current_status, last_chapter = "", ""
                    states.append(CharacterState(
                        CharacterId=cid,
                        CharacterName=self._field(entry, "Name", ""),
                        CurrentStatus=current_status,
                        LastAppearanceChapter=last_chapter,
                        CurrentGoal=""))
                try:
                    from ..tracking.character_state_service import compare_chapter_id
                    states.sort(key=functools.cmp_to_key(
                        lambda a, b: compare_chapter_id(a.LastAppearanceChapter, b.LastAppearanceChapter)),
                        reverse=True)
                except Exception:
                    pass
                status.CharacterStates = states[:30]
        except Exception:
            pass

        # 冲突进度（conflict_progress_guide.json → Top30）
        try:
            from ...models.guides.state_guides.conflict_progress_guide import ConflictProgressGuide
            guide_manager = self._get_guide_manager()
            if guide_manager is not None:
                guide = guide_manager.get_guide("conflict_progress_guide.json", ConflictProgressGuide)
                conflicts_data = self._field(guide, "Conflicts", {}) or {}
                conflicts = []
                for cid, entry in conflicts_data.items():
                    if not cid:
                        continue
                    entry_status = self._field(entry, "Status", "") or ""
                    conflicts.append(ConflictProgress(
                        ConflictId=cid,
                        ConflictName=self._field(entry, "Name", ""),
                        ProgressPercent=self._map_progress_percent(entry_status),
                        CurrentPhase=entry_status,
                        NextExpectedEvent=""))
                status.ConflictProgress = conflicts[:30]
        except Exception:
            pass

        # 伏笔统计（foreshadowing_status_guide.json → Pending 去重 Top50）
        try:
            from ...models.guides.state_guides.foreshadowing_status_guide import ForeshadowingStatusGuide
            guide_manager = self._get_guide_manager()
            if guide_manager is not None:
                guide = guide_manager.get_guide("foreshadowing_status_guide.json", ForeshadowingStatusGuide)
                summary = self._field(guide, "Summary", None)
                pending_list = self._field(guide, "PendingList", []) or []
                pending_ids: List[str] = []
                for p in pending_list:
                    pid = p if isinstance(p, str) else self._field(p, "Id", "")
                    if pid and pid not in pending_ids:
                        pending_ids.append(pid)
                    if len(pending_ids) >= 50:
                        break
                status.ForeshadowingStats = ForeshadowingStats(
                    Total=self._field(summary, "Total", 0) if summary is not None else 0,
                    Planted=self._field(summary, "Setup", 0) if summary is not None else 0,
                    Resolved=self._field(summary, "Payoff", 0) if summary is not None else 0,
                    PendingResolution=pending_ids)
        except Exception:
            pass

        # 情节点（PlotPointsIndexService 全卷聚合）
        try:
            plot_service = self._get_plot_points_service()
            if plot_service is not None:
                entries = []
                for vol in plot_service.get_existing_volume_numbers():
                    entries.extend(plot_service.get_volume_entries(vol))
                if entries:
                    from ...models.guides.plot_points_index import PlotPointsIndex
                    status.PlotPoints = PlotPointsIndex(PlotPoints=entries)
        except Exception:
            pass

        return status

    @staticmethod
    def _map_progress_percent(status: str) -> int:
        """对标 MapProgressPercent"""
        s = (status or "").strip().lower()
        if s == "resolved":
            return 100
        if s == "climax":
            return 80
        if s == "active":
            return 50
        return 0

    def _load_plan_items(self, entity: str) -> List[dict]:
        data = self.project.load_plan(entity)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return data.get("items", []) or []
        return []

    def _summarize_blueprint(self, chapter_id: str) -> str:
        """从 plan/blueprints 提取章节蓝图摘要（场景标题 + 一句话结构）"""
        try:
            blueprints = self._load_plan_items("blueprints")
            matched = [b for b in blueprints if isinstance(b, dict)
                       and (b.get("ChapterId") == chapter_id or b.get("Chapter") == chapter_id
                            or b.get("Id") == chapter_id)]
            if not matched:
                return ""
            parts = []
            for b in matched[:3]:
                title = b.get("SceneTitle") or b.get("Title") or b.get("Name") or ""
                brief = b.get("OneLineStructure") or b.get("Summary") or ""
                seg = f"{title}：{brief}" if title and brief else (title or brief)
                if seg:
                    parts.append(seg)
            return "；".join(parts)
        except Exception:
            return ""

    def _load_task_context(self, focus_id: str, target_layer: str):
        """对标 LoadTaskContextAsync: Blueprint/Content 层从 plan（chapters/volumes/blueprints）
        按 chapter_id 解析任务上下文（章节主题、所属卷、蓝图摘要），失败返回 None"""
        if target_layer not in ("Blueprint", "Content"):
            return None
        try:
            chapters = self._load_plan_items("chapters")
            chapter = next((c for c in chapters
                            if isinstance(c, dict) and c.get("Id") == focus_id), None)
            if chapter is None:
                return None
            vol_num = chapter.get("VolumeNumber", 0) or 0
            volumes = self._load_plan_items("volumes")
            volume = next((v for v in volumes
                           if isinstance(v, dict) and v.get("VolumeNumber") == vol_num), None) or {}
            return {
                "Layer": target_layer,
                "ChapterId": focus_id,
                "ChapterTitle": chapter.get("ChapterTitle") or chapter.get("Title") or chapter.get("Name") or "",
                "ChapterTheme": chapter.get("Theme") or chapter.get("Summary") or chapter.get("MainGoal") or "",
                "VolumeId": volume.get("Id", ""),
                "VolumeNumber": vol_num,
                "VolumeTitle": volume.get("Title") or volume.get("Name") or "",
                "VolumeGoal": volume.get("MainGoal") or volume.get("Goal") or "",
                "BlueprintSummary": self._summarize_blueprint(focus_id),
            }
        except Exception:
            return None

    def get_characters_context(self, focus_id: str):
        """对标 GetCharactersContextAsync"""
        return self.get_design_context(focus_id, "Characters")

    def get_content_context(self, focus_id: str):
        """对标 GetContentContextAsync"""
        return self.get_generate_context(focus_id, "Content")

    @staticmethod
    def _estimate_context_length(context) -> int:
        """对标 EstimateContextLength"""
        length = 0
        if hasattr(context, 'GlobalSummary') and context.GlobalSummary is not None:
            length += len(str(context.GlobalSummary))
        if hasattr(context, 'UpstreamIndex') and context.UpstreamIndex is not None:
            length += FocusContextService._estimate_upstream_index_length(context.UpstreamIndex)
        return length

    @staticmethod
    def _estimate_upstream_index_length(index) -> int:
        """对标 EstimateUpstreamIndexLength"""
        if index is None:
            return 0
        length = 0
        for attr in ('SmartParsing', 'Templates', 'Worldview', 'Characters', 'Factions', 'Plot', 'Outline', 'Planning', 'Blueprint'):
            items = getattr(index, attr, None) or []
            for item in items:
                if hasattr(item, 'BriefSummary') and item.BriefSummary:
                    length += len(item.BriefSummary)
        return length
