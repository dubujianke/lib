# -*- coding: utf-8 -*-
"""情节点索引服务 — 对标 Implementations/Indexing/PlotPointsIndexService.cs"""
import json
import os
import threading
from typing import List, Optional


class PlotPointsIndexService:
    def __init__(self, project):
        self.project = project
        self._volume_cache = {}
        self._write_lock = threading.Lock()

    def _dir(self) -> str:
        return os.path.join(self.project.dir, "guides", "plot_points")

    def _path(self, volume_number: int) -> str:
        return os.path.join(self._dir(), f"vol{volume_number}.json")

    @staticmethod
    def _volume_number(chapter_id: str) -> int:
        from ...character_state_service import parse_chapter_id
        vol, _ = parse_chapter_id(chapter_id)
        return vol or 1

    def _load_volume(self, volume_number: int) -> List[dict]:
        if volume_number in self._volume_cache:
            return self._volume_cache[volume_number]
        path = self._path(volume_number)
        if not os.path.exists(path):
            return []
        try:
            with open(path, "r", encoding="utf-8") as f:
                entries = json.load(f)
            self._volume_cache[volume_number] = entries
            return entries
        except Exception:
            return []

    def _save_volume(self, volume_number: int, entries: List[dict]):
        os.makedirs(self._dir(), exist_ok=True)
        path = self._path(volume_number)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(entries, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
        self._volume_cache[volume_number] = entries

    def add_plot_point(self, chapter_id: str, change):
        from ...models.common import short_id
        entry = {
            "Id": short_id("D"),
            "Chapter": chapter_id,
            "Keywords": change.Keywords or [],
            "Context": change.Context,
            "InvolvedCharacters": change.InvolvedCharacters or [],
            "Importance": change.Importance,
            "Storyline": change.Storyline,
            "CausedBy": change.CausedBy or "",
        }
        vol = self._volume_number(chapter_id)
        with self._write_lock:
            entries = self._load_volume(vol)
            entries.append(entry)
            self._save_volume(vol, entries)

    def remove_chapter_data(self, chapter_id: str):
        vol = self._volume_number(chapter_id)
        with self._write_lock:
            entries = self._load_volume(vol)
            updated = [e for e in entries if e.get("Chapter") != chapter_id]
            if len(updated) != len(entries):
                self._save_volume(vol, updated)

    def search_recent(self, current_chapter_id: str, character_ids, other_entity_ids,
                      lookback_volumes: int = 0) -> List[dict]:
        from ...character_state_service import parse_chapter_id
        current_vol, _ = parse_chapter_id(current_chapter_id)
        current_vol = current_vol or 1
        min_vol = 1 if lookback_volumes <= 0 else max(1, current_vol - lookback_volumes)
        result = []
        for vol in range(min_vol, current_vol + 1):
            for e in self._load_volume(vol):
                if not e.get("Context"):
                    continue
                match_char = character_ids and any(c in character_ids for c in (e.get("InvolvedCharacters") or []))
                match_other = other_entity_ids and any(k in other_entity_ids for k in (e.get("Keywords") or []))
                if match_char or match_other:
                    result.append(e)
        return result

    def get_existing_volume_numbers(self) -> List[int]:
        if not os.path.exists(self._dir()):
            return []
        result = []
        for f in os.listdir(self._dir()):
            if f.startswith("vol") and f.endswith(".json") and f[3:-5].isdigit():
                result.append(int(f[3:-5]))
        return sorted(result)

    def get_volume_entries(self, volume_number: int) -> List[dict]:
        return list(self._load_volume(volume_number))

    def set_volume_entries(self, volume_number: int, entries: List[dict]):
        with self._write_lock:
            self._save_volume(volume_number, entries)

    def invalidate_cache(self):
        self._volume_cache.clear()
