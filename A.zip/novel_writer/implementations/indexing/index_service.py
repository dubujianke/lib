# -*- coding: utf-8 -*-
"""索引服务 — 对标 Implementations/Indexing/IndexService.cs"""
from typing import Dict, List, Optional
import asyncio

from ...models.index.index_item import IndexItem
from ...models.index.upstream_index import UpstreamIndex

# 层级依赖（对标 C# LayerDependencies）
LAYER_DEPENDENCIES: Dict[str, List[str]] = {
    "SmartParsing": [],
    "Templates": ["SmartParsing"],
    "Worldview": ["Templates"],
    "Characters": ["Templates", "Worldview"],
    "Factions": ["Templates", "Worldview", "Characters"],
    "Locations": ["Templates", "Worldview", "Characters", "Factions"],
    "Plot": ["Templates", "Worldview", "Characters", "Factions", "Locations"],
    "Outline": ["Worldview", "Characters", "Factions", "Locations", "Plot"],
    "Planning": ["Worldview", "Characters", "Factions", "Locations", "Plot", "Outline"],
    "Blueprint": ["Worldview", "Characters", "Factions", "Locations", "Plot", "Outline", "Planning"],
    "Content": ["Worldview", "Characters", "Factions", "Locations", "Plot", "Outline", "Planning", "Blueprint"],
}

# 层级 → 设计/规划存储键（对标 C# LayerStoragePaths 的 Python 映射）
LAYER_STORAGE_KEYS: Dict[str, str] = {
    "SmartParsing": "materials",
    "Templates": "materials",
    "Worldview": "world",
    "Characters": "characters",
    "Factions": "factions",
    "Locations": "locations",
    "Plot": "plot",
    "Outline": "outline",
    "Planning": "chapters",
    "Blueprint": "blueprints",
}


class IndexService:
    UPSTREAM_INDEX_MAX_ITEMS_PER_LAYER = 200

    def __init__(self, project):
        self.project = project

    def build_upstream_index(self, target_layer: str) -> UpstreamIndex:
        index = UpstreamIndex()
        dependencies = LAYER_DEPENDENCIES.get(target_layer, [])
        for dep in dependencies:
            items = self._load_layer_items(dep, self.UPSTREAM_INDEX_MAX_ITEMS_PER_LAYER)
            index_items = [self.build_index_item(item) for item in items]
            self._set_index_property(index, dep, index_items)
        return index

    @staticmethod
    def build_index_item(item, use_deep_summary: bool = False) -> IndexItem:
        if isinstance(item, dict):
            return IndexItem(
                Id=item.get("Id", ""), Name=item.get("Name", ""),
                Type=item.get("Type", ""), BriefSummary=item.get("BriefSummary", ""),
                DeepSummary=item.get("DeepSummary", "") if use_deep_summary else "")
        return IndexItem(Id=getattr(item, "Id", ""), Name=getattr(item, "Name", ""),
                         Type="", BriefSummary="", DeepSummary="")

    def _load_layer_items(self, layer: str, max_items) -> List[dict]:
        """max_items=None 表示不限制（对标 LoadLayerItemsAsync(layer) → int.MaxValue）"""
        if max_items is not None and max_items <= 0:
            return []
        key = LAYER_STORAGE_KEYS.get(layer)
        if not key:
            return []
        try:
            data = self.project.load_design(key) if key in ("world", "characters", "factions", "locations", "plot", "materials") \
                else self.project.load_plan(key)
            items = data.get("items", []) if isinstance(data, dict) else (data or [])
            if max_items is not None:
                items = items[:max_items]
            result = []
            for item in items:
                if isinstance(item, dict) and item.get("Id") and item.get("Name"):
                    result.append(self._convert_to_index_item(item, layer))
            return result
        except Exception:
            return []

    @staticmethod
    def _convert_to_index_item(data: dict, layer: str) -> dict:
        item_type = layer
        return {
            "Id": data.get("Id", ""),
            "Name": data.get("Name", ""),
            "Type": item_type,
            "BriefSummary": f"{data.get('Name', '')}({item_type})",
            "DeepSummary": data.get("OneLineSummary", "") or data.get("Goal", "") or "",
        }

    @staticmethod
    def _set_index_property(index: UpstreamIndex, layer: str, items: List[IndexItem]):
        mapping = {
            "SmartParsing": "SmartParsing", "Templates": "Templates", "Worldview": "Worldview",
            "Characters": "Characters", "Factions": "Factions", "Plot": "Plot",
            "Locations": "Locations", "Outline": "Outline", "Planning": "Planning",
            "Blueprint": "Blueprint",
        }
        attr = mapping.get(layer)
        if attr:
            setattr(index, attr, items)

    async def get_index_item(self, id: str, layer: str) -> Optional[IndexItem]:
        """对标 GetIndexItemAsync: 单项查询不限制条数（max_items=None 表示不限制）"""
        if not id:
            return None
        items = self._load_layer_items(layer, max_items=None)
        for item in items:
            if item.get("Id") == id:
                return self.build_index_item(item, use_deep_summary=True)
        return None

    @staticmethod
    def _convert_to_indexable(data: dict, layer: str) -> Optional[dict]:
        id = data.get("Id", "")
        name = data.get("Name", "")
        if not id or not name:
            return None
        item_type = IndexService._get_item_type(data, layer)
        brief_summary = IndexService._build_brief_summary(data, layer, item_type, name)
        deep_summary = IndexService._build_deep_summary(data, layer, item_type)
        return {"Id": id, "Name": name, "Type": item_type,
                "BriefSummary": brief_summary, "DeepSummary": deep_summary}

    @staticmethod
    def _build_worldview_item_type() -> str:
        return "世界观规则"

    @staticmethod
    def _build_deep_summary(data: dict, layer: str, item_type: str) -> str:
        fields = {
            "Characters": ["Identity", "Want", "Need", "FlawBelief", "GrowthPath", "SpecialAbilities"],
            "Worldview": ["OneLineSummary", "PowerSystem", "HardRules", "SpecialLaws", "Cosmology"],
            "Factions": ["Goal", "Leader", "MemberTraits", "StrengthTerritory"],
            "Locations": ["Description", "Terrain", "Climate", "HistoricalSignificance"],
            "Plot": ["OneLineSummary", "Goal", "Conflict", "MainPlotPush", "CharacterGrowth"],
            "SmartParsing": ["WorldBuildingMethod", "PowerSystemDesign", "WorldviewHighlights"],
            "Templates": ["OverallIdea", "WorldviewHighlights", "CharacterHighlights", "PlotHighlights"],
            "Outline": ["OneLineOutline", "CoreConflict", "Theme", "EndingState", "OutlineOverview"],
            "Planning": ["MainGoal", "KeyTurn", "Hook", "WorldInfoDrop", "CharacterArcProgress"],
            "Blueprint": ["OneLineStructure", "SceneTitle", "PovCharacter", "Opening", "Turning", "Ending"],
        }
        parts = []
        for field in fields.get(layer, []):
            value = IndexService._get_json_string(data, field)
            if value:
                parts.append(value[:40] + "..." if len(value) > 40 else value)
                if len(parts) >= 2:
                    break
        return "。".join(parts)

    @staticmethod
    def _build_brief_summary(data: dict, layer: str, item_type: str, name: str) -> str:
        if layer == "SmartParsing" and item_type == "拆书":
            genre = IndexService._get_json_string(data, "SourceGenre")
            if not genre:
                genre = IndexService._get_json_string(data, "Genre")
            title = IndexService._get_json_string(data, "SourceBookTitle")
            if title:
                return f"{title}({genre})" if genre else f"{title}(拆书)"
            return f"{name}({genre})" if genre else f"{name}(拆书)"
        return f"{name}({item_type})"

    @staticmethod
    def _get_json_string(d: dict, key: str) -> str:
        value = d.get(key)
        return value if isinstance(value, str) else ""

    @staticmethod
    def _get_item_type(data: dict, layer: str) -> str:
        if layer == "Characters":
            return IndexService._get_json_string(data, "CharacterType") or "角色"
        if layer == "Worldview":
            return IndexService._build_worldview_item_type()
        if layer == "Factions":
            return IndexService._get_json_string(data, "FactionType") or "势力"
        if layer == "Locations":
            return IndexService._get_json_string(data, "LocationType") or "位置"
        if layer == "Plot":
            return (IndexService._get_json_string(data, "EventType")
                    or IndexService._get_json_string(data, "StoryPhase")
                    or "剧情")
        if layer == "SmartParsing":
            return "拆书"
        if layer == "Templates":
            return "素材"
        if layer == "Outline":
            return "大纲"
        if layer == "Planning":
            return "章节"
        if layer == "Blueprint":
            return "蓝图"
        return layer

    @staticmethod
    def _get_brief_summary(item) -> str:
        if isinstance(item, dict):
            return item.get("BriefSummary", "")
        return getattr(item, "BriefSummary", "")
