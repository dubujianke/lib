# -*- coding: utf-8 -*-
"""数据索引服务 — 对标 Implementations/Indexing/DataIndexService.cs"""
import threading
from typing import List, Optional


class EntityCategory:
    CHARACTER = "Character"
    LOCATION = "Location"
    FACTION = "Faction"
    PLOT_RULE = "PlotRule"
    WORLD_RULE = "WorldRule"


class IndexEntry:
    def __init__(self, id: str = "", name: str = "", category: str = "", data=None):
        self.Id = id
        self.Name = name or ""
        self.Category = category
        self.Data = data


class DataIndexService:
    def __init__(self, project=None):
        self.project = project
        self._name_to_entries = {}
        self._id_to_entry = {}
        self._is_initialized = False
        self._lock = threading.Lock()

    @property
    def is_initialized(self) -> bool:
        return self._is_initialized

    def initialize(self, characters=None, locations=None, factions=None, plot_rules=None, world_rules=None):
        if self._is_initialized:
            return
        with self._lock:
            if self._is_initialized:
                return
            self._name_to_entries.clear()
            self._id_to_entry.clear()
            for c in (characters or []):
                self._add_entry(c.Id if hasattr(c, 'Id') else c.get("Id", ""),
                                c.Name if hasattr(c, 'Name') else c.get("Name", ""),
                                EntityCategory.CHARACTER, c)
            for l in (locations or []):
                self._add_entry(l.Id if hasattr(l, 'Id') else l.get("Id", ""),
                                l.Name if hasattr(l, 'Name') else l.get("Name", ""),
                                EntityCategory.LOCATION, l)
            for f in (factions or []):
                self._add_entry(f.Id if hasattr(f, 'Id') else f.get("Id", ""),
                                f.Name if hasattr(f, 'Name') else f.get("Name", ""),
                                EntityCategory.FACTION, f)
            for p in (plot_rules or []):
                self._add_entry(p.Id if hasattr(p, 'Id') else p.get("Id", ""),
                                p.Name if hasattr(p, 'Name') else p.get("Name", ""),
                                EntityCategory.PLOT_RULE, p)
            for w in (world_rules or []):
                self._add_entry(w.Id if hasattr(w, 'Id') else w.get("Id", ""),
                                w.Name if hasattr(w, 'Name') else w.get("Name", ""),
                                EntityCategory.WORLD_RULE, w)
            self._is_initialized = True

    def _add_entry(self, id: str, name: str, category: str, data):
        if not id:
            return
        entry = IndexEntry(id, name, category, data)
        self._id_to_entry[id] = entry
        if name:
            self._name_to_entries.setdefault(name, []).append(entry)

    def find_by_name(self, name: str) -> List[IndexEntry]:
        if not name:
            return []
        with self._lock:
            return list(self._name_to_entries.get(name, []))

    def search_by_name(self, keyword: str, max_results: int = 20) -> List[IndexEntry]:
        if not keyword:
            return []
        with self._lock:
            keys = list(self._name_to_entries.keys())
        matched = [k for k in keys if keyword.lower() in k.lower()]
        result = []
        with self._lock:
            for k in matched:
                for entry in self._name_to_entries.get(k, []):
                    result.append(entry)
                    if len(result) >= max_results:
                        return result
        return result

    def find_by_id(self, id: str) -> Optional[IndexEntry]:
        if not id:
            return None
        with self._lock:
            return self._id_to_entry.get(id)

    def list_ids_by_category(self, category: str) -> List[str]:
        with self._lock:
            return [e.Id for e in self._id_to_entry.values() if e.Category == category]

    def search_by_category(self, category: str, keyword: str, max_results: int = 20) -> List[IndexEntry]:
        with self._lock:
            snapshot = list(self._id_to_entry.values())
        query = [e for e in snapshot if e.Category == category]
        if keyword:
            query = [e for e in query if keyword.lower() in e.Name.lower() or keyword.lower() in e.Id.lower()]
        return query[:max_results]

    def clear(self):
        with self._lock:
            self._name_to_entries.clear()
            self._id_to_entry.clear()
            self._is_initialized = False

    def update_entry(self, id: str, name: str, category: str, data):
        with self._lock:
            old = self._id_to_entry.get(id)
            if old and old.Name and old.Name in self._name_to_entries:
                self._name_to_entries[old.Name] = [e for e in self._name_to_entries[old.Name] if e.Id != id]
                if not self._name_to_entries[old.Name]:
                    self._name_to_entries.pop(old.Name)
            self._add_entry(id, name, category, data)
