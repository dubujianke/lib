# -*- coding: utf-8 -*-
"""关键词章节索引 — 对标 Implementations/Indexing/KeywordChapterIndexService.cs"""
import json
import os
import threading
from typing import Dict, List, Optional, Set

MAX_CHAPTERS_PER_KEYWORD = 50


class KeywordChapterIndexService:
    def __init__(self, project):
        self.project = project
        self._index: Optional[Dict[str, Set[str]]] = None
        self._index_order: Optional[Dict[str, List[str]]] = None
        self._lock = threading.Lock()
        self._dirty = False
        self._pending_invalidation = False

    @staticmethod
    def _normalize_keyword(kw: str) -> str:
        return kw.strip().lower()

    def _get_index_file_path(self) -> str:
        return os.path.join(self.project.dir, "guides", "keyword_index.json")

    def _ensure_loaded(self):
        if self._pending_invalidation:
            self._index = None
            self._index_order = None
            self._pending_invalidation = False
        if self._index is not None:
            return
        path = self._get_index_file_path()
        if not os.path.exists(path):
            self._index = {}
            self._index_order = {}
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                raw = json.load(f)
            if isinstance(raw, dict):
                self._index_order = {k: list(v) for k, v in raw.items()}
                self._index = {k: set(v) for k, v in raw.items()}
            else:
                self._index = {}
                self._index_order = {}
        except Exception:
            print("[KeywordIndex] 加载失败，使用空索引")
            self._index = {}
            self._index_order = {}

    def _save(self):
        if not self._dirty:
            return
        path = self._get_index_file_path()
        dir_path = os.path.dirname(path)
        if not os.path.exists(dir_path):
            os.makedirs(dir_path, exist_ok=True)
        tmp_path = path + ".tmp"
        try:
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(self._index_order or {}, f, ensure_ascii=False)
            os.replace(tmp_path, path)
            self._dirty = False
        except Exception as ex:
            print(f"[KeywordIndex] 保存失败: {ex}")
            try:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
            except Exception:
                pass

    def index_chapter_from_keywords(self, chapter_id: str, keywords: List[str]):
        if not chapter_id or not keywords:
            return
        kw_list = [k for k in keywords if k and k.strip()]
        if not kw_list:
            return
        with self._lock:
            self._ensure_loaded()
            for kw in kw_list:
                key = self._normalize_keyword(kw)
                if not key:
                    continue
                if key not in self._index:
                    self._index[key] = set()
                    self._index_order[key] = []
                chapters = self._index[key]
                order = self._index_order[key]
                if chapter_id not in chapters:
                    chapters.add(chapter_id)
                    order.append(chapter_id)
                    while len(order) > MAX_CHAPTERS_PER_KEYWORD:
                        chapters.discard(order[0])
                        order.pop(0)
            self._dirty = True
            self._save()

    def search(self, keywords: List[str], top_k: int = 5) -> List[str]:
        if not keywords:
            return []
        with self._lock:
            self._ensure_loaded()
            hit_count = {}
            for kw in keywords:
                key = self._normalize_keyword(kw)
                if not key or key not in self._index:
                    continue
                for chap_id in self._index[key]:
                    hit_count[chap_id] = hit_count.get(chap_id, 0) + 1
            return [k for k, _ in sorted(hit_count.items(), key=lambda x: -x[1])][:top_k]

    def remove_chapter(self, chapter_id: str):
        if not chapter_id:
            return
        with self._lock:
            self._ensure_loaded()
            modified = False
            for chapters in self._index.values():
                if chapter_id in chapters:
                    chapters.discard(chapter_id)
                    modified = True
            if modified:
                self._dirty = True
                self._save()

    def get_indexed_chapter_ids(self) -> Set[str]:
        with self._lock:
            self._ensure_loaded()
            result = set()
            for chapters in self._index.values():
                result.update(chapters)
            return result

    def invalidate_cache(self):
        self._pending_invalidation = True
        self._dirty = False