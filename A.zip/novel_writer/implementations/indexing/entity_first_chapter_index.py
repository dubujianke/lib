# -*- coding: utf-8 -*-
"""实体首次出现章节索引 — 对标 Implementations/Indexing/EntityFirstChapterIndex.cs"""
import json
import os
import threading
from typing import Dict, List, Optional


class FirstChapterEntry:
    def __init__(self, entity_id: str, chapter_id: str, chunk_position: int, captured_at: str = ""):
        self.EntityId = entity_id
        self.ChapterId = chapter_id
        self.ChunkPosition = chunk_position
        self.CapturedAt = captured_at


class EntityFirstChapterIndex:
    CURRENT_VERSION = 1

    def __init__(self, project):
        self.project = project
        self._entries: Dict[str, FirstChapterEntry] = {}
        self._io_lock = threading.Lock()
        self._loaded = False
        self._threshold = 0.5

    @property
    def count(self) -> int:
        return len(self._entries)

    def contains(self, entity_id: str) -> bool:
        return bool(entity_id) and entity_id in self._entries

    def get(self, entity_id: str) -> Optional[FirstChapterEntry]:
        if not entity_id:
            return None
        return self._entries.get(entity_id)

    def get_all(self) -> List[FirstChapterEntry]:
        return list(self._entries.values())

    def invalidate_by_chapter(self, chapter_id: str) -> int:
        if not chapter_id:
            return 0
        removed = 0
        for k in [k for k, v in self._entries.items() if v.ChapterId == chapter_id]:
            self._entries.pop(k, None)
            removed += 1
        return removed

    def invalidate_by_entities(self, entity_ids) -> int:
        if not entity_ids:
            return 0
        removed = 0
        for id in entity_ids:
            if id and self._entries.pop(id, None) is not None:
                removed += 1
        return removed

    def load(self):
        if self._loaded:
            return
        with self._io_lock:
            if self._loaded:
                return
            self._entries.clear()
            path = self._file_path()
            if not os.path.exists(path):
                self._loaded = True
                return
            try:
                with open(path, "r", encoding="utf-8") as f:
                    dto = json.load(f)
                for e in dto.get("entries", []):
                    if e.get("entity_id") and e.get("chapter_id"):
                        self._entries[e["entity_id"]] = FirstChapterEntry(
                            e["entity_id"], e["chapter_id"], e.get("chunk_position", 0),
                            e.get("captured_at", ""))
            except Exception:
                pass
            self._loaded = True

    def save(self):
        with self._io_lock:
            path = self._file_path()
            os.makedirs(os.path.dirname(path), exist_ok=True)
            dto = {
                "version": self.CURRENT_VERSION,
                "entries": [{"entity_id": e.EntityId, "chapter_id": e.ChapterId,
                             "chunk_position": e.ChunkPosition, "captured_at": e.CapturedAt}
                            for e in self._entries.values()],
            }
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(dto, f, ensure_ascii=False)
            os.replace(tmp, path)

    def invalidate_cache(self):
        self._entries.clear()
        self._loaded = False

    def _file_path(self) -> str:
        return os.path.join(self.project.dir, "guides", "entity_first_chapter.json")
