# -*- coding: utf-8 -*-
from ...vector_index import ChunkEmbeddingIndex
