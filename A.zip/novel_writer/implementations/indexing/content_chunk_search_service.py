# -*- coding: utf-8 -*-
"""内容块搜索 — 对标 Implementations/Indexing/ContentChunkSearchService.cs"""
import math
import os
import re
import threading
from typing import Dict, List, Optional, Tuple

FALLBACK_CHAPTER_CACHE_SIZE = 12
BM25_K1 = 1.5
BM25_B = 0.75


class ContentChunkSearchService:
    def __init__(self, project):
        self.project = project
        self._fallback_chunk_cache: Dict[str, List[dict]] = {}
        self._fallback_lru: List[str] = []
        self._lock = threading.Lock()
        self._cached_target_size = -1
        self._cached_overlap = -1

    @staticmethod
    def _count_occurrences(haystack: str, needle: str) -> int:
        if not haystack or not needle:
            return 0
        count = 0
        index = 0
        while True:
            index = haystack.lower().find(needle.lower(), index)
            if index == -1:
                break
            count += 1
            index += len(needle)
        return count

    @staticmethod
    def _calculate_relevance(query_terms: List[str], content: str) -> float:
        if not query_terms or not content:
            return 0.0
        doc_len = len(content)
        avg_chunk_length = max(100, 500)
        len_norm = 1.0 - BM25_B + BM25_B * doc_len / avg_chunk_length
        score = 0.0
        for term in query_terms:
            if not term:
                continue
            tf = ContentChunkSearchService._count_occurrences(content, term)
            if tf == 0:
                continue
            score += (tf * (BM25_K1 + 1)) / (tf + BM25_K1 * len_norm)
        return score

    def _touch_fallback_lru(self, chapter_id: str):
        if chapter_id in self._fallback_lru:
            self._fallback_lru.remove(chapter_id)
        self._fallback_lru.append(chapter_id)

    def _get_or_load_fallback_chunks(self, chapter_id: str, file_path: str) -> List[dict]:
        current_target_size = max(100, 500)
        current_overlap = max(0, min(50, current_target_size - 1))
        with self._lock:
            if (self._cached_target_size != -1
                    and (self._cached_target_size != current_target_size
                         or self._cached_overlap != current_overlap)):
                old_ts = self._cached_target_size
                old_ov = self._cached_overlap
                self._fallback_chunk_cache.clear()
                self._fallback_lru.clear()
                print(f"[ContentChunkSearch] 分块参数变更 ({old_ts}/{old_ov} → {current_target_size}/{current_overlap})，LRU 已清空重切")
            self._cached_target_size = current_target_size
            self._cached_overlap = current_overlap
            if chapter_id in self._fallback_chunk_cache:
                self._touch_fallback_lru(chapter_id)
                return self._fallback_chunk_cache[chapter_id]
        if not os.path.exists(file_path):
            return []
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception:
            return []
        chunks = self._chunk_content(chapter_id, content, current_target_size, current_overlap)
        with self._lock:
            if chapter_id in self._fallback_chunk_cache:
                self._touch_fallback_lru(chapter_id)
                return self._fallback_chunk_cache[chapter_id]
            self._fallback_chunk_cache[chapter_id] = chunks
            self._touch_fallback_lru(chapter_id)
            while len(self._fallback_lru) > FALLBACK_CHAPTER_CACHE_SIZE:
                to_remove = self._fallback_lru.pop(0)
                self._fallback_chunk_cache.pop(to_remove, None)
        return chunks

    @staticmethod
    def _chunk_content(chapter_id: str, content: str, target_size: int, overlap: int) -> List[dict]:
        chunks = []
        if not content:
            return chunks
        paragraphs = [p.strip() for p in re.split(r"\n\n+", content) if p.strip()]
        sb = []
        sb_len = 0
        position = 0
        for para in paragraphs:
            if not para:
                continue
            if sb_len > 0:
                sb.append("\n")
                sb_len += 1
            sb.append(para)
            sb_len += len(para)
            if sb_len >= target_size:
                text = "".join(sb)
                chunks.append({"chapter_id": chapter_id, "position": position, "content": text})
                overlap_start = max(0, len(text) - overlap)
                sb = [text[overlap_start:]]
                sb_len = len(sb[0])
                position += 1
        if sb_len > 0:
            chunks.append({"chapter_id": chapter_id, "position": position, "content": "".join(sb)})
        return chunks

    def search(self, query: str, top_k: int = 5) -> List[dict]:
        chapters_path = self.project.dir
        if not os.path.exists(chapters_path):
            return []
        if top_k <= 0 or not query or not query.strip():
            return []
        query_terms = [t for t in re.split(r"[ ,，、]+", query) if t]
        if not query_terms:
            return []
        md_files = [f for f in os.listdir(chapters_path) if f.endswith(".md")]
        top_results = []
        for fname in md_files:
            chapter_id = os.path.splitext(fname)[0]
            file_path = os.path.join(chapters_path, fname)
            try:
                chunks = self._get_or_load_fallback_chunks(chapter_id, file_path)
            except Exception as ex:
                print(f"[ContentChunkSearch] 读取章节失败 {chapter_id}: {ex}")
                continue
            if not chunks:
                continue
            for chunk in chunks:
                score = self._calculate_relevance(query_terms, chunk["content"])
                if score <= 0:
                    continue
                if len(top_results) == top_k and score <= top_results[-1]["score"]:
                    continue
                result = {"chapter_id": chunk["chapter_id"], "position": chunk["position"],
                          "content": chunk["content"], "score": score}
                insert_index = 0
                while insert_index < len(top_results) and top_results[insert_index]["score"] >= result["score"]:
                    insert_index += 1
                top_results.insert(insert_index, result)
                if len(top_results) > top_k:
                    top_results.pop()
        return top_results

    def invalidate_chapter(self, chapter_id: str):
        if not chapter_id:
            return
        with self._lock:
            self._fallback_chunk_cache.pop(chapter_id, None)
            if chapter_id in self._fallback_lru:
                self._fallback_lru.remove(chapter_id)

    def invalidate_cache(self):
        with self._lock:
            self._fallback_chunk_cache.clear()
            self._fallback_lru.clear()
            self._cached_target_size = -1
            self._cached_overlap = -1