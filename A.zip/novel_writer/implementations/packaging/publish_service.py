# -*- coding: utf-8 -*-
"""发布服务 — 对标 Implementations/Packaging/PublishService.cs（partial 4 文件）

核心：打包发布（构建 guide 文件 + 生成 manifest + 版本管理）
"""
import glob
import json
import os
from typing import Dict, List, Optional

from ...models.publishing.publish_result import (
    PublishResult, PublishStatus, ManifestInfo, StatisticsInfo,
)


class _CaseInsensitiveSet:
    """对标 HashSet<string>(StringComparer.OrdinalIgnoreCase)"""

    def __init__(self, items=None):
        self._items = {i.lower() for i in items} if items else set()

    def add(self, item):
        self._items.add(item.lower())

    def __contains__(self, item):
        return isinstance(item, str) and item.lower() in self._items

    def __len__(self):
        return len(self._items)

    def __iter__(self):
        return iter(self._items)


class PublishService:
    def __init__(self, project, guide_index_builder=None,
                 change_detection_service=None, guide_context_service=None,
                 guide_manager=None, ledger_trim_service=None):
        self.project = project
        self._guide_index_builder = guide_index_builder
        self._manifest_cache = None
        # 对标 C# ServiceLocator 注入的依赖（未提供时延迟创建）
        self._change_detection_service = change_detection_service
        self._guide_context_service = guide_context_service
        self._guide_manager = guide_manager
        self._ledger_trim_service = ledger_trim_service
        self._publish_lock = __import__("threading").Lock()

    # ---- 延迟服务解析（对标 C# ServiceLocator.Get<T>()）----

    def _get_change_detection(self):
        if self._change_detection_service is None:
            from ..change_detection.change_detection_service import ChangeDetectionService
            self._change_detection_service = ChangeDetectionService(self.project)
        return self._change_detection_service

    def _get_guide_context(self):
        if self._guide_context_service is None:
            try:
                from ..guides.guide_context_service import GuideContextService
                self._guide_context_service = GuideContextService(self.project)
            except Exception:
                return None
        return self._guide_context_service

    def _get_guide_manager(self):
        if self._guide_manager is None:
            try:
                from ..guides.guide_manager import GuideManager
                self._guide_manager = GuideManager(self.project)
            except Exception:
                return None
        return self._guide_manager

    def _get_ledger_trim(self):
        if self._ledger_trim_service is None:
            try:
                from ..tracking.tracking_services import TrackingManager
                from ..tracking.ledger_trim import LedgerTrimService
                tracking_manager = TrackingManager(self.project)
                self._ledger_trim_service = LedgerTrimService(
                    tracking_manager, tracking_manager.ledger_config)
            except Exception:
                return None
        return self._ledger_trim_service

    def get_manifest(self) -> Optional[ManifestInfo]:
        if self._manifest_cache is not None:
            return self._manifest_cache
        path = os.path.join(self.project.dir, "manifest.json")
        if not os.path.exists(path):
            return None
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self._manifest_cache = ManifestInfo.from_dict(data)
            return self._manifest_cache
        except Exception:
            return None

    def needs_republish(self) -> bool:
        """对标 NeedsRepublish: _changeDetectionService.GetChangedModules().Count > 0"""
        return len(self._get_change_detection().get_changed_modules()) > 0

    def clear_cache(self):
        self._manifest_cache = None

    def publish(self, enabled_modules: Dict[str, Dict[str, bool]] = None) -> PublishResult:
        """对标 PublishAsync: 执行打包"""
        try:
            manifest = self.get_manifest()
            version = (manifest.Version + 1) if manifest else 1
            # 生成 guide 文件
            self._generate_guides()
            # 生成 manifest
            statistics = self._build_statistics()
            manifest = ManifestInfo(
                ProjectName=self.project.name,
                PublishTime=self._now(),
                Version=version,
                Files={},
                EnabledModules=enabled_modules or {},
                Statistics=statistics)
            self._save_manifest(manifest)
            self._manifest_cache = manifest
            return PublishResult.success(version, [])
        except Exception as e:
            return PublishResult.failed(f"打包失败: {e}")

    def _generate_guides(self):
        """对标 GuideGeneration: 生成 guide 文件"""
        guides_dir = os.path.join(self.project.dir, "guides")
        os.makedirs(guides_dir, exist_ok=True)

    def _build_statistics(self) -> StatisticsInfo:
        return StatisticsInfo(
            TotalCharacters=len(self._load_design("characters")),
            TotalLocations=len(self._load_design("locations")),
            TotalChapters=len(self._load_plan("chapters")),
            TotalWords=0)

    def _save_manifest(self, manifest: ManifestInfo):
        path = os.path.join(self.project.dir, "manifest.json")
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(manifest.to_dict(), f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)

    def _load_design(self, entity: str) -> list:
        data = self.project.load_design(entity)
        if isinstance(data, dict):
            return data.get("items", [])
        return data or []

    def _load_plan(self, entity: str) -> list:
        data = self.project.load_plan(entity)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return data.get(entity, data.get("items", []))
        return []

    @staticmethod
    def _now() -> str:
        import time
        return time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())

    # ---- 缺失方法移植 ----

    @staticmethod
    def _debug_log_once(key: str, ex: Exception):
        """对标 DebugLogOnce"""
        # if TM.App.IsDebugMode:
        #     print(f"[PublishService] {key}: {ex.message}")
        pass

    def _detect_and_cleanup_staging_residue(self):
        """对标 DetectAndCleanupStagingResidue"""
        try:
            project_path = self.project.dir
            staging_dir = os.path.join(project_path, "Config.staging")
            staging_manifest = os.path.join(project_path, "manifest.staging.json")
            if os.path.isdir(staging_dir):
                import shutil
                shutil.rmtree(staging_dir, ignore_errors=True)
                # print("[PublishService] 检测并清理 Config.staging 残留")
            if os.path.isfile(staging_manifest):
                os.remove(staging_manifest)
                # print("[PublishService] 检测并清理 manifest.staging.json 残留")
        except Exception:
            pass

    # 对标 C# NavigationDefinitions（SubModule 名 → 功能目录清单）+ PackagingAllowlist
    # C# SubModule 为目录名（ViewPath 第 4 段: GlobalSettings/Elements），非显示名
    _SUB_MODULE_FUNCTIONS = {
        ("Design", "GlobalSettings"): {
            "display_name": "全局设定",
            "sub_directories": ["WorldRules"],
        },
        ("Design", "Elements"): {
            "display_name": "设计元素",
            "sub_directories": ["CharacterRules", "FactionRules", "LocationRules", "PlotRules"],
        },
        ("Generate", "GlobalSettings"): {
            "display_name": "全书设定",
            "sub_directories": ["Outline"],
        },
        ("Generate", "Elements"): {
            "display_name": "创作元素",
            "sub_directories": ["VolumeDesign", "Chapter", "Blueprint"],
        },
    }

    # 对标 NavigationConfigParser.GetDisplayName: 功能目录名 → 显示名（无配置时回退原名）
    _FUNCTION_DISPLAY_NAMES = {
        "WorldRules": "世界观规则",
        "CharacterRules": "角色规则",
        "FactionRules": "势力规则",
        "LocationRules": "位置规则",
        "PlotRules": "剧情规则",
        "Outline": "大纲设计",
        "VolumeDesign": "分卷设计",
        "Chapter": "章节设计",
        "Blueprint": "蓝图设计",
    }

    def _get_package_mappings(self):
        """对标 GetPackageMappings: allowlist + 模块启用状态 + 功能子目录"""
        from ..packaging_allowlist import PackagingAllowlist

        mappings = []
        for module_type, allowlist in PackagingAllowlist.SubModules.items():
            for (mt, sub_dir_name), cfg in self._SUB_MODULE_FUNCTIONS.items():
                if mt != module_type:
                    continue
                if cfg["display_name"] not in allowlist:
                    continue
                module_path = f"{module_type}/{sub_dir_name}"
                status = self._get_change_detection().get_status(module_path)
                if not status.IsEnabled:
                    continue
                function_names = cfg["sub_directories"]
                if not function_names:
                    continue
                mappings.append({
                    "module_type": module_type,
                    "sub_module": sub_dir_name,
                    "sub_module_display_name": cfg["display_name"],
                    "sub_directories": list(function_names),
                    "target_file": f"{sub_dir_name.lower()}.json",
                })
        return mappings

    def _check_missing_build_data(self, mappings) -> Optional[List[str]]:
        """对标 PublishAllInternalAsync 缺失数据阻断（55-83 行）:
        遍历 mapping.SubDirectories，检查源目录下是否有 json 数据文件。
        返回缺失清单（sub_module 显示名/功能显示名）；数据齐全返回 None。
        """
        missing_functions = []
        for mapping in mappings:
            # C#: Path.Combine(storageRoot, "Modules", ModuleType, SubModule)
            # Python 存储布局无 "Modules" 前缀（见 services/*: {project_dir}/{ModuleType}/{SubModule}）
            source_base = os.path.join(
                self._get_storage_root(),
                mapping.get("module_type", ""), mapping.get("sub_module", ""))
            for sub_dir in mapping.get("sub_directories", []):
                sub_dir_path = os.path.join(source_base, sub_dir)
                has_data = os.path.isdir(sub_dir_path) and any(
                    f.lower().endswith(".json") for f in os.listdir(sub_dir_path))
                if not has_data:
                    sub_name = mapping.get("sub_module_display_name") or mapping.get("sub_module", "")
                    func_name = self._FUNCTION_DISPLAY_NAMES.get(sub_dir, sub_dir)
                    missing_functions.append(f"{sub_name}/{func_name}")
        return missing_functions or None

    def _get_storage_root(self) -> str:
        """对标 StoragePathHelper.GetStorageRoot: Python 版存储根即项目目录"""
        return self.project.dir

    def publish_all(self) -> PublishResult:
        """对标 PublishAllAsync: 互斥锁 + PublishAllInternalAsync"""
        if not self._publish_lock.acquire(blocking=False):
            return PublishResult.failed("已有打包任务进行中")
        try:
            return self._publish_all_internal()
        finally:
            self._publish_lock.release()

    def _publish_all_internal(self) -> PublishResult:
        """对标 PublishAllInternalAsync: 完整打包流程（含调用链）"""
        import shutil
        backup_path = ""
        promoted = False
        try:
            # 1. EndChapter 前置检查
            end_chapter_blocked = self._check_end_chapter_configuration()
            if end_chapter_blocked is not None:
                return end_chapter_blocked

            # 1.5 缺失数据阻断（对标 PublishAllInternalAsync 55-83 行）
            all_mappings = self._get_package_mappings()
            missing_functions = self._check_missing_build_data(all_mappings)
            if missing_functions:
                detail = "、".join(missing_functions)
                print(f"[PublishService] 打包阻断：以下业务缺失构建数据: {detail}")
                return PublishResult.failed(
                    f"以下业务尚未构建数据，无法打包：{detail}。请先完成构建后重新打包。")

            # 2. 卷完整性检查（对标 Generate 模块时）
            volume_blocked = self._check_volume_completeness_before_publish()
            if volume_blocked is not None:
                return volume_blocked

            # 3. 预检（对标 RunPreflightAsync: PreflightValidator(modulePath => GetStatus(modulePath).IsEnabled)）
            preflight_blocked = self._run_preflight()
            if preflight_blocked is not None:
                return preflight_blocked

            # 4. 准备 staging
            self._prepare_staging_config()
            staging_path = self._get_staging_config_path(self.project.dir)
            staging_manifest_path = self._get_staging_manifest_path(self.project.dir)
            self._ensure_directories_exist()

            # 5. 打包各模块（对标: var pkgMappings = allMappings）
            mappings = all_mappings
            package_warnings = []
            packaged_modules = []
            for mapping in mappings:
                self._package_module(mapping, staging_path, package_warnings)
                packaged_modules.append(f"{mapping.get('module_type')}/{mapping.get('sub_module')}")

            # 6. 更新 manifest + 生成 guide 文件
            version = self._update_manifest(staging_manifest_path, staging_path)
            self._generate_guide_files(staging_path)

            # 6.5 序后完整性校验（对标 ValidateStagingIntegrityAsync，调用点同 C# 120-131 行）
            integrity_errors = self._validate_staging_integrity(staging_path)
            if integrity_errors:
                self._cleanup_staging(self.project.dir)
                preview = integrity_errors[:8]
                detail_lines = list(preview)
                if len(integrity_errors) > len(preview):
                    detail_lines.append(f"...另有 {len(integrity_errors) - len(preview)} 项错误未列出")
                detail = "\n".join(detail_lines)
                print(f"[PublishService] 序后强校验阻断 ({len(integrity_errors)} 项): {detail.replace(chr(10), ' | ')}")
                return PublishResult.failed("打包数据完整性校验未通过（staging 已丢弃，原数据未受影响）", detail)

            # 7. 生成打包报告（对标 new PackageReporter().RunAsync(...)）
            try:
                from .package_reporter import PackageReporter
                previous_report = os.path.join(self.project.dir, "package_report.json")
                reporter = PackageReporter(self.project)
                report = reporter.run(staging_path, version,
                                      previous_report if os.path.exists(previous_report) else None)
                if report and getattr(report, "AnomalyWarnings", None):
                    # print(f"[PublishService] 打包要素波动提醒: {'; '.join(report.AnomalyWarnings[:5])}")
                    pass
            except Exception:
                pass

            # 8. 备份 + staging 转正
            backup_path = self._create_backup()
            promoted = True
            self._promote_staging(self.project.dir)

            # 9. 转正后善后（对标: MarkAllAsPackaged + RefreshServiceCaches + 完整性提示）
            try:
                self._get_change_detection().mark_all_as_packaged()
                self._manifest_cache = None
                self._refresh_service_caches()

                if backup_path and os.path.isdir(backup_path):
                    shutil.rmtree(backup_path, ignore_errors=True)
                    manifest_bak = backup_path + ".manifest.json"
                    if os.path.exists(manifest_bak):
                        try:
                            os.remove(manifest_bak)
                        except Exception:
                            pass

                # 对标: new ContextIdsCompletenessChecker(_guideContextService).RunAsync()
                try:
                    from .context_ids_completeness_checker import ContextIdsCompletenessChecker
                    gcs = self._get_guide_context()
                    if gcs is not None:
                        checker = ContextIdsCompletenessChecker(gcs)
                        completeness_warnings = checker.run()
                        self._notify_completeness_warnings(completeness_warnings)
                except Exception:
                    pass
            except Exception as post_ex:
                print(f"[PublishService] 转正后善后失败（数据已成功转正，无需回滚）: {post_ex}")

            return PublishResult.success(version, packaged_modules)
        except Exception as ex:
            print(f"[PublishService] 打包失败: {ex}")
            self._cleanup_staging(self.project.dir)
            if promoted and backup_path:
                try:
                    self._restore_backup(backup_path)
                except Exception as rb_ex:
                    print(f"[PublishService] 回滚失败（非致命）: {rb_ex}")
            elif backup_path and os.path.isdir(backup_path):
                shutil.rmtree(backup_path, ignore_errors=True)
                manifest_bak = backup_path + ".manifest.json"
                if os.path.exists(manifest_bak):
                    try:
                        os.remove(manifest_bak)
                    except Exception:
                        pass

            self._manifest_cache = None
            # 对标: GuideManager.DiscardDirtyAndEvict + GuideContextService 缓存重建 + ChangeDetection 刷新
            try:
                gm = self._get_guide_manager()
                if gm is not None:
                    gm.discard_dirty_and_evict()
            except Exception as evict_ex:
                print(f"[PublishService] 清理 GuideManager 缓存失败: {evict_ex}")
            try:
                gcs = self._get_guide_context()
                if gcs is not None:
                    gcs.initialize_cache()
            except Exception as cache_ex:
                print(f"[PublishService] 预热缓存失败（非致命）: {cache_ex}")
            try:
                self._get_change_detection().refresh_all()
            except Exception as ex2:
                print(f"[PublishService] 刷新变更检测失败: {ex2}")
            return PublishResult.failed(f"打包失败: {ex}")

    def publish_module(self, module_name: str) -> PublishResult:
        """对标 PublishModuleAsync: 互斥锁 + PublishModuleInternalAsync"""
        if not self._publish_lock.acquire(blocking=False):
            return PublishResult.failed("已有打包任务进行中")
        try:
            return self._publish_module_internal(module_name)
        finally:
            self._publish_lock.release()

    def _publish_module_internal(self, module_name: str) -> PublishResult:
        """对标 PublishModuleInternalAsync"""
        import shutil
        backup_path = ""
        promoted = False
        try:
            # 缺失数据阻断（对标 PublishModuleInternalAsync 256-285 行）
            mappings_for_module = [m for m in self._get_package_mappings()
                                   if m.get("module_type") == module_name]
            missing_functions = self._check_missing_build_data(mappings_for_module)
            if missing_functions:
                detail = "、".join(missing_functions)
                print(f"[PublishService] 单模块打包阻断：以下业务缺失构建数据: {detail}")
                return PublishResult.failed(
                    f"以下业务尚未构建数据，无法打包：{detail}。请先完成构建后重新打包。")

            if str(module_name).lower() == "generate":
                end_chapter_blocked = self._check_end_chapter_configuration()
                if end_chapter_blocked is not None:
                    return end_chapter_blocked
                volume_blocked = self._check_volume_completeness_before_publish()
                if volume_blocked is not None:
                    return volume_blocked

            preflight_blocked = self._run_preflight()
            if preflight_blocked is not None:
                return preflight_blocked

            self._prepare_staging_config_from_existing(self.project.dir)
            staging_path = self._get_staging_config_path(self.project.dir)
            staging_manifest_path = self._get_staging_manifest_path(self.project.dir)
            self._ensure_directories_exist()

            mappings = [m for m in self._get_package_mappings()
                        if m.get("module_type") == module_name]
            package_warnings = []
            packaged_modules = []
            for mapping in mappings:
                self._package_module(mapping, staging_path, package_warnings)
                packaged_modules.append(f"{mapping.get('module_type')}/{mapping.get('sub_module')}")

            version = self._update_manifest(staging_manifest_path, staging_path)
            self._generate_guide_files(staging_path)

            # 序后完整性校验（对标 ValidateStagingIntegrityAsync，调用点同 C# 324-335 行）
            integrity_errors = self._validate_staging_integrity(staging_path)
            if integrity_errors:
                self._cleanup_staging(self.project.dir)
                preview = integrity_errors[:8]
                detail_lines = list(preview)
                if len(integrity_errors) > len(preview):
                    detail_lines.append(f"...另有 {len(integrity_errors) - len(preview)} 项错误未列出")
                detail = "\n".join(detail_lines)
                print(f"[PublishService] 单模块打包序后强校验阻断 ({len(integrity_errors)} 项): {detail.replace(chr(10), ' | ')}")
                return PublishResult.failed("打包数据完整性校验未通过（staging 已丢弃，原数据未受影响）", detail)

            try:
                from .package_reporter import PackageReporter
                previous_report = os.path.join(self.project.dir, "package_report.json")
                reporter = PackageReporter(self.project)
                report = reporter.run(staging_path, version,
                                      previous_report if os.path.exists(previous_report) else None)
                if report and getattr(report, "AnomalyWarnings", None):
                    pass
            except Exception:
                pass

            backup_path = self._create_backup()
            promoted = True
            self._promote_staging(self.project.dir)

            try:
                # 对标: foreach mapping → _changeDetectionService.MarkAsPackaged(...)
                cd = self._get_change_detection()
                for mapping in mappings:
                    cd.mark_as_packaged(f"{mapping.get('module_type')}/{mapping.get('sub_module')}")

                if backup_path and os.path.isdir(backup_path):
                    shutil.rmtree(backup_path, ignore_errors=True)
                    manifest_bak = backup_path + ".manifest.json"
                    if os.path.exists(manifest_bak):
                        try:
                            os.remove(manifest_bak)
                        except Exception:
                            pass

                self._manifest_cache = None
                try:
                    self._refresh_service_caches()
                except Exception as cache_ex:
                    print(f"[PublishService] 单模块打包：刷新缓存失败（非致命）: {cache_ex}")

                try:
                    from .context_ids_completeness_checker import ContextIdsCompletenessChecker
                    gcs = self._get_guide_context()
                    if gcs is not None:
                        checker = ContextIdsCompletenessChecker(gcs)
                        self._notify_completeness_warnings(checker.run())
                except Exception as completeness_ex:
                    print(f"[PublishService] 单模块打包：蓝图完整性预检异常（非致命）: {completeness_ex}")
            except Exception as post_ex:
                print(f"[PublishService] 单模块打包：转正后善后失败（数据已成功转正，无需回滚）: {post_ex}")

            return PublishResult.success(version, packaged_modules)
        except Exception as ex:
            print(f"[PublishService] 打包模块失败 [{module_name}]: {ex}")
            self._cleanup_staging(self.project.dir)
            if promoted and backup_path:
                try:
                    self._restore_backup(backup_path)
                except Exception as rb_ex:
                    print(f"[PublishService] 单模块打包回滚失败（非致命）: {rb_ex}")
            elif backup_path and os.path.isdir(backup_path):
                shutil.rmtree(backup_path, ignore_errors=True)
            self._manifest_cache = None
            try:
                gm = self._get_guide_manager()
                if gm is not None:
                    gm.discard_dirty_and_evict()
            except Exception:
                pass
            try:
                gcs = self._get_guide_context()
                if gcs is not None:
                    gcs.initialize_cache()
            except Exception:
                pass
            try:
                self._get_change_detection().refresh_all()
            except Exception:
                pass
            return PublishResult.failed(f"打包{module_name}失败: {ex}")

    def get_publish_status(self) -> dict:
        """对标 GetPublishStatus: Uses ChangeDetectionService.GetChangedModules()"""
        manifest = self.get_manifest()
        changed_modules = self._get_change_detection().get_changed_modules()
        return {
            "is_published": manifest is not None,
            "last_publish_time": manifest.PublishTime if manifest else None,
            "current_version": manifest.Version if manifest else 0,
            "needs_republish": len(changed_modules) > 0,
            "changed_module_count": len(changed_modules),
        }

    def _refresh_service_caches(self):
        """对标 RefreshServiceCachesAsync: RaiseCacheInvalidated + InitializeCacheAsync"""
        self._manifest_cache = None
        try:
            gcs = self._get_guide_context()
            if gcs is not None:
                # 对标 GuideContextService.RaiseCacheInvalidated()（静态事件）
                if hasattr(gcs, "raise_cache_invalidated"):
                    gcs.raise_cache_invalidated()
                elif hasattr(gcs, "clear_cache"):
                    gcs.clear_cache()
                # 对标 await _guideContextService.InitializeCacheAsync()
                if hasattr(gcs, "initialize_cache"):
                    gcs.initialize_cache()
        except Exception as ex:
            print(f"[PublishService] 刷新缓存失败: {ex}")

    @staticmethod
    def _notify_completeness_warnings(warnings):
        """对标 NotifyCompletenessWarnings"""
        if warnings is None:
            return
        parts = []
        if hasattr(warnings, 'EmptyContextWarnings') and warnings.EmptyContextWarnings:
            parts.append(f"{len(warnings.EmptyContextWarnings)}个章节蓝图缺少角色/地点/世界观规则关联")
        if hasattr(warnings, 'ForeshadowingWarnings') and warnings.ForeshadowingWarnings:
            parts.append(f"{len(warnings.ForeshadowingWarnings)}条伏笔已埋设但无揭示计划")
        if hasattr(warnings, 'ConflictWarnings') and warnings.ConflictWarnings:
            parts.append(f"{len(warnings.ConflictWarnings)}条冲突活跃但无后续章节追踪")
        if parts:
            pass  # GlobalToast 占位

    def _check_end_chapter_configuration(self):
        """对标 CheckEndChapterConfigurationAsync"""
        try:
            volumes = self._load_plan("volumes")
            enabled = [v for v in volumes if v.get("IsEnabled", True) and v.get("VolumeNumber", 0) > 0]
            if len(enabled) > 1:
                max_vol = max(v.get("VolumeNumber", 0) for v in enabled)
                unconfigured = [v.get("VolumeNumber") for v in enabled if v.get("EndChapter", 0) <= 0 and v.get("VolumeNumber", 0) < max_vol]
                if unconfigured:
                    vol_list = "、".join(f"第{n}卷" for n in unconfigured)
                    # print(f"[PublishService] L-004.1 阻断：{vol_list}未配置EndChapter")
                    return {"success": False, "message": f"{vol_list}未配置\"结束章节\""}
        except Exception:
            pass
        return None

    def _check_volume_completeness_before_publish(self):
        """对标 CheckVolumeCompletenessBeforePublishAsync"""
        try:
            volumes = self._load_plan("volumes")
            enabled = sorted([v for v in volumes if v.get("IsEnabled", True) and v.get("VolumeNumber", 0) > 0], key=lambda v: v.get("VolumeNumber", 0))
            if not enabled:
                return None
            outlines = self._load_plan("outline")
            valid = [o for o in outlines if o.get("IsEnabled", True) and o.get("TotalChapterCount", 0) > 0]
            if not valid:
                return {"success": False, "message": "大纲未配置总章节数"}
            return None
        except Exception:
            return None

    @staticmethod
    def _build_volume_category_name(volume: dict) -> str:
        """对标 BuildVolumeCategoryName"""
        vn = volume.get("VolumeNumber", 0)
        if vn > 0:
            title = volume.get("VolumeTitle", "")
            return f"第{vn}卷 {title}".strip()
        return volume.get("Name", "")

    @staticmethod
    def _has_real_chapter_title(title: str) -> bool:
        """对标 HasRealChapterTitle"""
        if not title or not title.strip():
            return False
        import re
        stripped = re.sub(r"^\s*第\s*[\d一二三四五六七八九十百千零]+\s*章\s*[：:、\-—–_]*\s*", "", title).strip()
        stripped = re.sub(r"^[\s第\d一二三四五六七八九十百千零章：:、\-—–_]+", "", stripped).strip()
        return bool(stripped)

    def _run_preflight(self):
        """对标 RunPreflightAsync: new PreflightValidator(modulePath => _changeDetectionService.GetStatus(modulePath).IsEnabled).RunAsync()"""
        try:
            from ...preflight import PreflightValidator
            cd = self._get_change_detection()
            validator = PreflightValidator(
                self.project,
                is_module_enabled=lambda module_path: cd.get_status(module_path).IsEnabled)
            pf = validator.run()
            if pf:
                return None
            # PreflightValidator.run 返回 bool；失败时错误在其 errors 中
            errors = getattr(validator, "errors", [])
            preview = errors[:8]
            detail_lines = list(preview)
            if len(errors) > len(preview):
                detail_lines.append(f"...另有 {len(errors) - len(preview)} 项错误未列出")
            detail = "\n".join(detail_lines)
            print(f"[PublishService] 预检阻断 ({len(errors)} 项错误): {detail}")
            return PublishResult.failed("打包预检未通过", detail)
        except Exception as ex:
            print(f"[PublishService] 预检异常（拒绝继续打包以确保安全）: {ex}")
            return PublishResult.failed("打包预检异常", str(ex))

    def _package_module(self, mapping: dict, config_base_path: str, warnings: list = None):
        """对标 PackageModuleAsync: sourceBase={root}/{ModuleType}/{SubModule}，遍历 SubDirectories"""
        import shutil
        try:
            module_type = mapping.get("module_type", "")
            sub_module = mapping.get("sub_module", "")
            # C#: Path.Combine(storageRoot, "Modules", ModuleType, SubModule)
            # Python 存储布局: {project_dir}/{ModuleType}/{SubModule}
            source_base = os.path.join(self._get_storage_root(), module_type, sub_module)
            dst_dir = os.path.join(config_base_path, module_type)
            os.makedirs(dst_dir, exist_ok=True)
            target = os.path.join(dst_dir, mapping.get("target_file", f"{sub_module.lower()}.json"))
            # 对标: 遍历 SubDirectories（目录存在才纳入），合并各子目录 json → data.{subdir.lower()}
            all_data = {}
            for sub_dir in mapping.get("sub_directories", []):
                sub_dir_path = os.path.join(source_base, sub_dir)
                if not os.path.isdir(sub_dir_path):
                    continue
                sub_data = self._load_sub_directory_data(sub_dir_path, warnings)
                all_data[sub_dir.lower()] = sub_data
            package = {"module": sub_module, "publishTime": self._now(), "version": 1, "data": all_data}
            tmp = target + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(package, f, ensure_ascii=False, indent=2)
            os.replace(tmp, target)
            # print(f"[PublishService] 已打包: {module_type}/{sub_module}")
        except Exception:
            pass

    @staticmethod
    def _load_sub_directory_data(dir_path: str, warnings: list = None) -> dict:
        """对标 LoadSubDirectoryDataAsync: 读目录下 json，数组做 IsEnabled 过滤，键为文件名小写"""
        result = {}
        for fname in os.listdir(dir_path):
            if not fname.lower().endswith(".json"):
                continue
            file_path = os.path.join(dir_path, fname)
            key = os.path.splitext(fname)[0].lower()
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, list):
                    filtered = [i for i in data
                                if not (isinstance(i, dict) and i.get("IsEnabled") is False)]
                    result[key] = filtered
                else:
                    result[key] = data
            except Exception as e:
                print(f"[PublishService] 读取文件失败 [{file_path}]: {e}")
                if warnings is not None:
                    warnings.append(f"{fname}: {e}")
        return result

    def _update_manifest(self, manifest_path: str, config_base_path: str) -> int:
        """对标 UpdateManifestAsync: Files=BuildFilesMap() + EnabledModules=BuildEnabledModulesMap()"""
        manifest = self.get_manifest() or ManifestInfo(ProjectName=self.project.name, PublishTime=self._now(), Version=0, Files={}, EnabledModules={}, Statistics=self._build_statistics())
        manifest.Version += 1
        manifest.PublishTime = self._now()
        manifest.ProjectName = manifest.ProjectName or "我的小说"
        manifest.Files = self._build_files_map()
        manifest.EnabledModules = self._build_enabled_modules_map()
        manifest.Statistics = self._build_statistics()
        tmp = manifest_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(manifest.to_dict(), f, ensure_ascii=False, indent=2)
        os.replace(tmp, manifest_path)
        return manifest.Version

    def _build_files_map(self) -> Dict[str, List[str]]:
        """对标 BuildFilesMap: mapping.ModuleType → [TargetFile]"""
        map_: Dict[str, List[str]] = {}
        for mapping in self._get_package_mappings():
            map_.setdefault(mapping.get("module_type", ""), []).append(
                mapping.get("target_file", ""))
        return map_

    def _build_enabled_modules_map(self) -> Dict[str, Dict[str, bool]]:
        """对标 BuildEnabledModulesMap: ModulePath "Type/Sub" → {Sub: IsEnabled}"""
        map_: Dict[str, Dict[str, bool]] = {}
        for status in self._get_change_detection().get_all_statuses():
            parts = status.ModulePath.split("/")
            if len(parts) == 2:
                map_.setdefault(parts[0], {})[parts[1]] = status.IsEnabled
        return map_

    def _count_words(self) -> int:
        """对标 CountWordsAsync"""
        chapters_dir = os.path.join(self.project.dir, "generated")
        if not os.path.isdir(chapters_dir):
            return 0
        total = 0
        for fname in os.listdir(chapters_dir):
            if not fname.endswith(".md"):
                continue
            try:
                with open(os.path.join(chapters_dir, fname), "r", encoding="utf-8") as f:
                    content = f.read()
                total += self._count_chinese_words(content)
            except Exception:
                pass
        return total

    @staticmethod
    def _count_chinese_words(text: str) -> int:
        """对标 CountChineseWords"""
        if not text:
            return 0
        count = 0
        for ch in text:
            if '\u4e00' <= ch <= '\u9fff' or '\u3000' <= ch <= '\u303f':
                count += 1
        return count

    def _count_characters(self, config_base_path: str) -> int:
        """对标 CountCharactersAsync"""
        try:
            elements_path = os.path.join(config_base_path, "Design", "elements.json")
            if os.path.exists(elements_path):
                with open(elements_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                data_section = data.get("data", {})
                char_rules = data_section.get("characterrules", {})
                count = 0
                for k, v in char_rules.items():
                    if isinstance(v, list):
                        count += len(v)
                return count
        except Exception:
            pass
        return len(self._load_design("characters"))

    def _count_locations(self, config_base_path: str) -> int:
        """对标 CountLocationsAsync"""
        try:
            elements_path = os.path.join(config_base_path, "Design", "elements.json")
            if os.path.exists(elements_path):
                with open(elements_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                data_section = data.get("data", {})
                loc_rules = data_section.get("locationrules", {})
                count = 0
                for k, v in loc_rules.items():
                    if isinstance(v, list):
                        count += len(v)
                return count
        except Exception:
            pass
        return len(self._load_design("locations"))

    def _create_backup(self) -> str:
        """对标 CreateBackupAsync"""
        import shutil
        import time
        backup_path = os.path.join(self.project.dir, f"_backup_{time.strftime('%Y%m%d_%H%M%S')}")
        try:
            os.makedirs(backup_path, exist_ok=True)
            config_path = os.path.join(self.project.dir, "config")
            if os.path.isdir(config_path):
                shutil.copytree(config_path, os.path.join(backup_path, "config"), dirs_exist_ok=True)
            manifest_src = self._get_manifest_path()
            if os.path.exists(manifest_src):
                import shutil
                shutil.copy2(manifest_src, backup_path + ".manifest.json")
        except Exception:
            pass
        return backup_path

    def _restore_backup(self, backup_path: str):
        """对标 RestoreBackupAsync"""
        import shutil
        config_path = os.path.join(self.project.dir, "config")
        if os.path.isdir(config_path):
            shutil.rmtree(config_path, ignore_errors=True)
        bak_config = os.path.join(backup_path, "config")
        if os.path.isdir(bak_config):
            shutil.copytree(bak_config, config_path, dirs_exist_ok=True)
        manifest_bak = backup_path + ".manifest.json"
        if os.path.exists(manifest_bak):
            shutil.copy2(manifest_bak, self._get_manifest_path())
            os.remove(manifest_bak)
        shutil.rmtree(backup_path, ignore_errors=True)

    @staticmethod
    def _copy_directory(source: str, target: str):
        """对标 CopyDirectoryAsync"""
        import shutil
        os.makedirs(target, exist_ok=True)
        for fname in os.listdir(source):
            src = os.path.join(source, fname)
            dst = os.path.join(target, fname)
            if os.path.isfile(src):
                shutil.copy2(src, dst)
            elif os.path.isdir(src):
                shutil.copytree(src, dst, dirs_exist_ok=True)

    def _ensure_directories_exist(self):
        """对标 EnsureDirectoriesExist"""
        os.makedirs(os.path.join(self.project.dir, "config", "Design"), exist_ok=True)
        os.makedirs(os.path.join(self.project.dir, "config", "Generate"), exist_ok=True)
        os.makedirs(os.path.join(self.project.dir, "generated"), exist_ok=True)

    def _get_manifest_path(self) -> str:
        """对标 GetManifestPath"""
        return os.path.join(self.project.dir, "manifest.json")

    @staticmethod
    def _get_staging_config_path(project_dir: str = None) -> str:
        """对标 GetStagingConfigPath"""
        base = project_dir or ""
        return os.path.join(base, "Config.staging")

    @staticmethod
    def _get_staging_manifest_path(project_dir: str = None) -> str:
        """对标 GetStagingManifestPath"""
        base = project_dir or ""
        return os.path.join(base, "manifest.staging.json")

    def _prepare_staging_config(self, project_dir: str = None):
        """对标 PrepareStagingConfig"""
        import shutil
        base = project_dir or self.project.dir
        staging = os.path.join(base, "Config.staging")
        if os.path.isdir(staging):
            shutil.rmtree(staging, ignore_errors=True)
        os.makedirs(staging, exist_ok=True)
        os.makedirs(os.path.join(staging, "Design"), exist_ok=True)
        os.makedirs(os.path.join(staging, "Generate"), exist_ok=True)
        staging_manifest = os.path.join(base, "manifest.staging.json")
        if os.path.exists(staging_manifest):
            os.remove(staging_manifest)

    def _prepare_staging_config_from_existing(self, project_dir: str = None):
        """对标 PrepareStagingConfigFromExistingAsync"""
        import shutil
        base = project_dir or self.project.dir
        staging = os.path.join(base, "Config.staging")
        if os.path.isdir(staging):
            shutil.rmtree(staging, ignore_errors=True)
        os.makedirs(staging, exist_ok=True)
        staging_manifest = os.path.join(base, "manifest.staging.json")
        if os.path.exists(staging_manifest):
            os.remove(staging_manifest)
        config_path = os.path.join(base, "config")
        if os.path.isdir(config_path):
            shutil.copytree(config_path, staging, dirs_exist_ok=True)
        else:
            os.makedirs(os.path.join(staging, "Design"), exist_ok=True)
            os.makedirs(os.path.join(staging, "Generate"), exist_ok=True)

    def _promote_staging(self, project_dir: str = None):
        """对标 PromoteStagingAsync"""
        import shutil
        base = project_dir or self.project.dir
        staging = os.path.join(base, "Config.staging")
        config_path = os.path.join(base, "config")
        staging_manifest = os.path.join(base, "manifest.staging.json")
        manifest_path = os.path.join(base, "manifest.json")
        if not os.path.isdir(staging):
            raise RuntimeError("staging 目录不存在，无法转正")
        if os.path.isdir(config_path):
            shutil.rmtree(config_path, ignore_errors=True)
        os.rename(staging, config_path)
        if os.path.exists(staging_manifest):
            try:
                os.replace(staging_manifest, manifest_path)
            except Exception:
                pass

    def _cleanup_staging(self, project_dir: str = None):
        """对标 CleanupStaging"""
        import shutil
        base = project_dir or self.project.dir
        staging = os.path.join(base, "Config.staging")
        if os.path.isdir(staging):
            shutil.rmtree(staging, ignore_errors=True)
        staging_manifest = os.path.join(base, "manifest.staging.json")
        if os.path.exists(staging_manifest):
            os.remove(staging_manifest)

    def _validate_staging_integrity(self, config_base_path: str) -> List[str]:
        """对标 ValidateStagingIntegrityAsync: 序后强校验（4件套 + guides 分片 + ID 有效性）"""
        errors: List[str] = []
        try:
            design_global = os.path.join(config_base_path, "Design", "globalsettings.json")
            design_elements = os.path.join(config_base_path, "Design", "elements.json")
            generate_global = os.path.join(config_base_path, "Generate", "globalsettings.json")
            generate_elements = os.path.join(config_base_path, "Generate", "elements.json")

            if not os.path.isfile(design_global):
                errors.append("Design/globalsettings.json 缺失")
            if not os.path.isfile(design_elements):
                errors.append("Design/elements.json 缺失")
            if not os.path.isfile(generate_global):
                errors.append("Generate/globalsettings.json 缺失")
            if not os.path.isfile(generate_elements):
                errors.append("Generate/elements.json 缺失")

            if errors:
                return errors

            # 对标 CollectIdsFromElementsAsync（忽略大小写）
            all_char_ids = self._collect_ids_from_elements(design_elements, "characterrules")
            all_loc_ids = self._collect_ids_from_elements(design_elements, "locationrules")
            all_fac_ids = self._collect_ids_from_elements(design_elements, "factionrules")
            all_plot_ids = self._collect_ids_from_elements(design_elements, "plotrules")

            guides_dir = os.path.join(config_base_path, "guides")
            if not os.path.isdir(guides_dir):
                errors.append("guides/ 目录缺失")
                return errors

            shard_files = sorted(glob.glob(os.path.join(guides_dir, "content_guide_vol*.json")))
            if not shard_files:
                errors.append("content_guide 分片文件未生成（应至少 1 个 content_guide_volN.json）")
                return errors

            for shard_file in shard_files:
                try:
                    with open(shard_file, "r", encoding="utf-8") as f:
                        doc = json.load(f)
                    chapters = doc.get("Chapters") if isinstance(doc, dict) else None
                    if not isinstance(chapters, dict):
                        continue
                    for chapter_id, chapter in chapters.items():
                        if not isinstance(chapter, dict):
                            continue
                        ctx = chapter.get("ContextIds")
                        if not isinstance(ctx, dict):
                            continue
                        self._collect_invalid_ids(ctx, "Characters", all_char_ids, chapter_id, "角色", errors)
                        self._collect_invalid_ids(ctx, "Locations", all_loc_ids, chapter_id, "地点", errors)
                        self._collect_invalid_ids(ctx, "Factions", all_fac_ids, chapter_id, "势力", errors)
                        self._collect_invalid_ids(ctx, "PlotRules", all_plot_ids, chapter_id, "剧情规则", errors)
                        self._collect_invalid_ids(ctx, "Conflicts", all_plot_ids, chapter_id, "冲突", errors)
                        self._collect_invalid_ids(ctx, "ForeshadowingSetups", all_plot_ids, chapter_id, "伏笔埋设", errors)
                        self._collect_invalid_ids(ctx, "ForeshadowingPayoffs", all_plot_ids, chapter_id, "伏笔回收", errors)
                except Exception as ex:
                    errors.append(f"读取分片失败 {os.path.basename(shard_file)}: {ex}")
        except Exception as ex:
            errors.append(f"序后强校验异常: {ex}")
        return errors

    @staticmethod
    def _collect_ids_from_elements(elements_file_path: str, root_key: str) -> set:
        """对标 CollectIdsFromElementsAsync: data.{rootKey} 下所有数组的 Id（忽略大小写）"""
        ids = _CaseInsensitiveSet()
        try:
            with open(elements_file_path, "r", encoding="utf-8") as f:
                doc = json.load(f)
            data = doc.get("data") if isinstance(doc, dict) else None
            if not isinstance(data, dict):
                return ids
            key_prop = None
            for name, value in data.items():
                if name.lower() == root_key.lower():
                    key_prop = value
                    break
            if key_prop is None:
                return ids
            if isinstance(key_prop, dict):
                for file_entry in key_prop.values():
                    if not isinstance(file_entry, list):
                        continue
                    for item in file_entry:
                        if isinstance(item, dict):
                            id_val = item.get("Id")
                            if isinstance(id_val, str) and id_val.strip():
                                ids.add(id_val)
        except Exception as ex:
            print(f"[PublishService] 收集 {root_key} ID 失败: {ex}")
        return ids

    def _collect_invalid_ids(self, ctx: dict, field: str, valid_ids, chapter_id: str, label: str, errors: list):
        """对标 CollectInvalidIds: valid_ids 为忽略大小写集合"""
        arr = ctx.get(field)
        if not isinstance(arr, list):
            return
        invalid = [i for i in arr
                   if isinstance(i, str) and i.strip() and i not in valid_ids]
        if invalid:
            preview = "、".join(invalid[:5])
            suffix = "..." if len(invalid) > 5 else ""
            errors.append(f"章节 {chapter_id} 的{label}列表包含无效ID: {preview}{suffix}")

    def _generate_guide_files(self, config_base_path: str):
        """对标 GenerateGuideFilesAsync（完整链路，复用 GuideIndexBuilder 11 个 build_*）"""
        from ..guides.guide_index_builder import GuideIndexBuilder, parse_chapter_id
        from ..guides.guide_manager import GuideManager

        guides_path = os.path.join(config_base_path, "guides")
        os.makedirs(guides_path, exist_ok=True)
        try:
            builder = GuideIndexBuilder(
                self.project,
                is_module_enabled=lambda module_path:
                    self._get_change_detection().get_status(module_path).IsEnabled)

            # 生成 outline_guide → planning_guide → blueprint_guide → content_guide（递增依赖）
            outline_guide = builder.build_outline_guide()
            self._save_guide(guides_path, "outline_guide.json", outline_guide)

            planning_guide = builder.build_planning_guide(outline_guide)
            self._save_guide(guides_path, "planning_guide.json", planning_guide)

            blueprint_guide = builder.build_blueprint_guide(planning_guide)
            self._save_guide(guides_path, "blueprint_guide.json", blueprint_guide)

            content_guide = builder.build_content_guide(blueprint_guide)

            # 空 0 章抛错（对标 C# 36-39 行）
            if not content_guide.get("Chapters"):
                raise RuntimeError(
                    "章节指导为空（0章）：蓝图数据均未启用。"
                    "请检查蓝图设计是否已启用，确认后重新打包。")

            # 分片: chapterId → 卷号（对标 SortedDictionary<int, ContentGuide>）
            content_shards = {}
            for chapter_id, entry in content_guide["Chapters"].items():
                parsed = parse_chapter_id(chapter_id)
                vol = parsed[0] if parsed else 1
                shard = content_shards.get(vol)
                if shard is None:
                    shard = {"Chapters": {}, "ChapterSummaries": {}}
                    content_shards[vol] = shard
                shard["Chapters"][chapter_id] = entry
                summary = content_guide.get("ChapterSummaries", {}).get(chapter_id)
                if summary is not None:
                    shard["ChapterSummaries"][chapter_id] = summary
            for vol in sorted(content_shards):
                self._save_guide(
                    guides_path,
                    GuideManager.get_volume_file_name("content_guide.json", vol),
                    content_shards[vol])

            # 缺口2: 旧分片清理（对标 C# 57-75 行，防残留）
            try:
                new_shard_names = _CaseInsensitiveSet(
                    GuideManager.get_volume_file_name("content_guide.json", v)
                    for v in content_shards)
                for f in glob.glob(os.path.join(guides_path, "content_guide_vol*.json")):
                    fn = os.path.basename(f)
                    if fn not in new_shard_names:
                        try:
                            os.remove(f)
                        except Exception:
                            pass
            except Exception:
                pass
            legacy_cg_path = os.path.join(guides_path, "content_guide.json")
            if os.path.exists(legacy_cg_path):
                try:
                    os.remove(legacy_cg_path)
                except Exception:
                    pass

            # 剧情规则章节归属校验（对标 ValidatePlotRulesChapters + Error 阻断）
            all_chapter_ids = set(content_guide["Chapters"].keys())
            plot_rules = self._load_plot_rules()
            plot_errors = [w for w in self._validate_plot_rules_chapters(plot_rules, all_chapter_ids)
                           if (w.get("Level") or "").lower() == "error"]
            if plot_errors:
                summary = " | ".join(f"{w['Source']}: {w['Message']}" for w in plot_errors)
                raise RuntimeError(f"剧情规则章节归属校验失败：{summary}")

            # 伏笔追踪 guide: 构建初始状态 + 合并既有追踪状态（缺口1，对标 C# 91-106 行）
            foreshadow_status = builder.build_foreshadowing_status_guide()
            gm = self._get_guide_manager()
            existing_foreshadow = {}
            if gm is not None:
                try:
                    existing_foreshadow = gm.get_guide("foreshadowing_status_guide.json") or {}
                except Exception:
                    existing_foreshadow = {}
            for fs_id, entry in (existing_foreshadow.get("Foreshadowings") or {}).items():
                target = (foreshadow_status.get("Foreshadowings") or {}).get(fs_id)
                if isinstance(target, dict) and isinstance(entry, dict):
                    for field in ("IsSetup", "IsResolved", "ActualSetupChapter",
                                  "ActualPayoffChapter", "IsOverdue"):
                        if field in entry:
                            target[field] = entry[field]
            self._save_guide(guides_path, "foreshadowing_status_guide.json", foreshadow_status)
            if gm is not None and hasattr(gm, "evict_cache"):
                try:
                    gm.evict_cache("foreshadowing_status_guide.json", foreshadow_status)
                except Exception:
                    pass

            print("[PublishService] 指导文件生成完成（设计类Guide，追踪Guide由运行期独立管理）")

            # 缺口3: LedgerTrim 接线（对标 C# 112 行 TrimAllAsync，非致命）
            try:
                trim_service = self._get_ledger_trim()
                if trim_service is not None:
                    trim_service.trim_all()
            except Exception as trim_ex:
                print(f"[PublishService] trim err (non-critical): {trim_ex}")
        except Exception as e:
            print(f"[PublishService] 指导文件生成失败: {e}")
            raise

    @staticmethod
    def _validate_plot_rules_chapters(plot_rules: List[dict], all_chapter_ids: set) -> List[dict]:
        """对标 GuideIndexBuilder.ValidatePlotRulesChapters:
        StoryPhase 形似章节ID但未匹配现有章节 → Error 警告
        """
        warnings = []
        from ..guides.guide_index_builder import parse_chapter_id
        for plot_rule in plot_rules or []:
            story_phase = (plot_rule.get("StoryPhase") or "").strip() \
                if isinstance(plot_rule, dict) else ""
            if story_phase and parse_chapter_id(story_phase) is not None \
                    and story_phase not in all_chapter_ids:
                warnings.append({
                    "Level": "Error",
                    "Source": f"剧情规则: {plot_rule.get('Name', '')}",
                    "Message": f"所属阶段 {story_phase} 看起来是章节ID格式但未匹配现有章节",
                })
        return warnings

    def _load_plot_rules(self) -> List[dict]:
        """对标 LoadPlotRulesAsync: 读 Design/Elements/PlotRules/plot_rules.json，失败返回空"""
        file_path = os.path.join(
            self._get_storage_root(), "Design", "Elements", "PlotRules", "plot_rules.json")
        if not os.path.exists(file_path):
            return []
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, list) else []
        except Exception as e:
            print(f"[PublishService] 读取剧情规则文件失败: {e}")
            return []

    def _save_guide(self, guides_path: str, file_name: str, guide: dict):
        """对标 SaveGuideAsync: tmp + 原子替换"""
        file_path = os.path.join(guides_path, file_name)
        tmp = file_path + "." + __import__("uuid").uuid4().hex + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(guide, f, ensure_ascii=False, indent=2)
            os.replace(tmp, file_path)
        except Exception:
            if os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except Exception:
                    pass
            raise

    def _save_guide(self, guides_path: str, file_name: str, guide: dict):
        """对标 SaveGuideAsync"""
        file_path = os.path.join(guides_path, file_name)
        tmp = file_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(guide, f, ensure_ascii=False, indent=2)
        os.replace(tmp, file_path)

    class ContentGuide:
        """对标 C# 内部 ContentGuide 模型"""
        def __init__(self):
            self.Chapters = {}
            self.ChapterSummaries = {}
