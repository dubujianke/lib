# -*- coding: utf-8 -*-
"""打包历史服务 — 对标 Implementations/Packaging/PackageHistoryService.cs"""
import json
import os
import shutil
from typing import List, Optional

from ...models.publishing.publish_result import (
    PackageHistoryEntry, PackageVersionDiff, ModuleDiffItem,
)


class PackageHistoryService:
    def __init__(self, project, publish_service=None):
        self.project = project
        self._publish_service = publish_service
        self._retain_count = 5

    @property
    def retain_count(self) -> int:
        return self._retain_count

    @retain_count.setter
    def retain_count(self, value: int):
        self._retain_count = max(1, min(10, value))

    def _history_path(self) -> str:
        return os.path.join(self.project.dir, "history")

    def save_current_to_history(self) -> bool:
        try:
            manifest = self._publish_service.get_manifest() if self._publish_service else None
            if manifest is None:
                return False
            version_dir = os.path.join(self._history_path(), f"v{manifest.Version}")
            if os.path.exists(version_dir):
                shutil.rmtree(version_dir)
            os.makedirs(version_dir)
            self.cleanup_old_history()
            return True
        except Exception:
            return False

    def get_all_history(self) -> List[PackageHistoryEntry]:
        entries = []
        if self._publish_service:
            manifest = self._publish_service.get_manifest()
            if manifest:
                entries.append(PackageHistoryEntry(
                    Version=manifest.Version, PublishTime=manifest.PublishTime,
                    IsCurrent=True, HistoryPath=self.project.dir))
        if os.path.exists(self._history_path()):
            for d in sorted(os.listdir(self._history_path()), reverse=True):
                if not d.startswith("v"):
                    continue
                manifest_file = os.path.join(self._history_path(), d, "manifest.json")
                if os.path.exists(manifest_file):
                    try:
                        with open(manifest_file, "r", encoding="utf-8") as f:
                            m = json.load(f)
                        entries.append(PackageHistoryEntry(
                            Version=m.get("Version", 0), PublishTime=m.get("PublishTime", ""),
                            IsCurrent=False, HistoryPath=os.path.join(self._history_path(), d)))
                    except Exception:
                        pass
        return entries

    def restore_version(self, version: int) -> bool:
        version_dir = os.path.join(self._history_path(), f"v{version}")
        if not os.path.exists(version_dir):
            return False
        try:
            # 简化：恢复 design/plan 目录
            for sub in ["design", "plan", "guides"]:
                src = os.path.join(version_dir, sub)
                if os.path.exists(src):
                    dst = os.path.join(self.project.dir, sub)
                    if os.path.exists(dst):
                        shutil.rmtree(dst)
                    shutil.copytree(src, dst)
            return True
        except Exception:
            return False

    def cleanup_old_history(self):
        try:
            if not os.path.exists(self._history_path()):
                return
            dirs = sorted(os.listdir(self._history_path()), key=lambda d: int(d[1:]) if d[1:].isdigit() else 0, reverse=True)
            for d in dirs[self._retain_count:]:
                shutil.rmtree(os.path.join(self._history_path(), d), ignore_errors=True)
        except Exception:
            pass

    def get_version_diff(self, history_version: int) -> PackageVersionDiff:
        diff = PackageVersionDiff(HistoryVersion=history_version)
        if self._publish_service:
            manifest = self._publish_service.get_manifest()
            if manifest:
                diff.CurrentVersion = manifest.Version
        return diff

    # ---- 缺失方法移植 ----

    @staticmethod
    def _build_enabled_summary(enabled_modules: dict) -> str:
        """对标 BuildEnabledSummary"""
        parts = []
        for module_type, modules in enabled_modules.items():
            enabled = sum(1 for v in modules.values() if v)
            total = len(modules)
            parts.append(f"{module_type}({enabled}/{total})")
        return " + ".join(parts)

    @staticmethod
    async def _copy_directory(source_dir: str, dest_dir: str):
        """对标 CopyDirectoryAsync"""
        if not os.path.exists(dest_dir):
            os.makedirs(dest_dir)
        for fname in os.listdir(source_dir):
            src = os.path.join(source_dir, fname)
            dst = os.path.join(dest_dir, fname)
            if os.path.isfile(src):
                import shutil
                shutil.copy2(src, dst)
            elif os.path.isdir(src):
                import shutil
                shutil.copytree(src, dst, dirs_exist_ok=True)
