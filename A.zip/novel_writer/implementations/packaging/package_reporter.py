# -*- coding: utf-8 -*-
"""打包报告器 — 对标 Implementations/Packaging/PackageReporter.cs"""
import json
import os
from typing import Dict, List


class ChapterStat:
    def __init__(self):
        self.Title = ""
        self.Characters = 0
        self.Locations = 0
        self.Factions = 0
        self.PlotRules = 0
        self.Conflicts = 0
        self.ForeshadowingSetups = 0
        self.ForeshadowingPayoffs = 0
        self.Scenes = 0

    def to_dict(self):
        return self.__dict__


class VolumeStat:
    def __init__(self):
        self.VolumeNumber = 0
        self.ChapterCount = 0
        self.TotalCharacters = 0
        self.TotalLocations = 0
        self.TotalFactions = 0
        self.UniqueCharacters = 0
        self.UniqueLocations = 0
        self.UniqueFactions = 0

    def to_dict(self):
        return self.__dict__


class PackageReport:
    def __init__(self):
        self.GeneratedAt = ""
        self.Version = 0
        self.Summary = ""
        self.ChapterStats: Dict[str, ChapterStat] = {}
        self.VolumeStats: Dict[str, VolumeStat] = {}
        self.AnomalyWarnings: List[str] = []


class PackageReporter:
    def __init__(self, project):
        self.project = project

    def run(self, config_base_path: str = None, version: int = 0,
            previous_report_path: str = None) -> PackageReport:
        """对标 RunAsync(configBasePath, version, previousReportPath)：生成报告并落盘 package_report.json"""
        import time
        if config_base_path is None:
            config_base_path = self.project.dir
        report = PackageReport()
        report.GeneratedAt = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())
        report.Version = version
        try:
            self._collect_chapter_stats(report, config_base_path)
            self._aggregate_volume_stats(report, config_base_path)
            if previous_report_path and os.path.exists(previous_report_path):
                self._detect_anomalies(previous_report_path, report)
            report.Summary = (f"版本 {version}：{len(report.ChapterStats)} 章节、{len(report.VolumeStats)} 卷；"
                              f"{len(report.AnomalyWarnings)} 项异常波动")

            report_path = os.path.join(config_base_path, "package_report.json")
            PackageReporter._save_report(report_path, report)
        except Exception:
            pass
        return report

    def _aggregate_volume_stats(self, report: PackageReport, config_base_path: str = None):
        """对标 AggregateVolumeStats（从 guide 分片按卷聚合 + 唯一实体统计）"""
        from ...character_state_service import parse_chapter_id
        if config_base_path is None:
            config_base_path = self.project.dir
        buckets = {}

        guides_dir = os.path.join(config_base_path, "guides")
        if not os.path.isdir(guides_dir):
            return
        for fname in os.listdir(guides_dir):
            if not fname.startswith("content_guide_vol") or not fname.endswith(".json"):
                continue
            try:
                with open(os.path.join(guides_dir, fname), "r", encoding="utf-8") as f:
                    doc = json.load(f)
                chapters = doc.get("Chapters", {})
                for ch_id, ch_data in chapters.items():
                    vol, _ = parse_chapter_id(ch_id)
                    if not vol:
                        continue
                    if vol not in buckets:
                        buckets[vol] = {"chapter_count": 0, "chars": set(), "locs": set(), "facs": set()}
                    b = buckets[vol]
                    b["chapter_count"] += 1
                    ctx = ch_data.get("ContextIds", {}) or {}
                    for field, target in (("Characters", "chars"), ("Locations", "locs"), ("Factions", "facs")):
                        arr = ctx.get(field)
                        if isinstance(arr, list):
                            b[target].update(i for i in arr if isinstance(i, str) and i.strip())
            except Exception:
                pass

        for vol, b in buckets.items():
            stat = VolumeStat()
            stat.VolumeNumber = vol
            stat.ChapterCount = b["chapter_count"]
            stat.UniqueCharacters = len(b["chars"])
            stat.UniqueLocations = len(b["locs"])
            stat.UniqueFactions = len(b["facs"])
            report.VolumeStats[f"vol{vol}"] = stat

    def _detect_anomalies(self, previous_path: str, report: PackageReport):
        """对标 DetectAnomaliesAsync: 与上次报告逐章对比要素数量波动"""
        try:
            with open(previous_path, "r", encoding="utf-8") as f:
                prev = json.load(f)
        except Exception:
            return
        prev_chapter_stats = (prev.get("ChapterStats") or {}) if isinstance(prev, dict) else {}
        labels = [
            ("Characters", "角色"), ("Locations", "地点"), ("Factions", "势力"),
            ("PlotRules", "剧情规则"), ("Conflicts", "冲突"),
        ]
        for ch_id, curr in report.ChapterStats.items():
            prev_stat = prev_chapter_stats.get(ch_id)
            if not isinstance(prev_stat, dict):
                continue
            for field, label in labels:
                PackageReporter._append_anomaly(report, ch_id, label,
                                                int(prev_stat.get(field, 0) or 0),
                                                int(getattr(curr, field, 0) or 0))

    # ---- 缺失方法移植 ----

    def _collect_chapter_stats(self, report: PackageReport, config_base_path: str = None):
        """对标 CollectChapterStatsAsync（从 guide 分片读取）"""
        if config_base_path is None:
            config_base_path = self.project.dir
        guides_dir = os.path.join(config_base_path, "guides")
        if not os.path.isdir(guides_dir):
            return
        for fname in os.listdir(guides_dir):
            if not fname.startswith("content_guide_vol") or not fname.endswith(".json"):
                continue
            try:
                with open(os.path.join(guides_dir, fname), "r", encoding="utf-8") as f:
                    doc = json.load(f)
                chapters = doc.get("Chapters", {})
                for ch_id, ch_data in chapters.items():
                    stat = ChapterStat()
                    stat.Title = ch_data.get("Title", "")
                    ctx = ch_data.get("ContextIds", {})
                    stat.Characters = self._count_array(ctx, "Characters")
                    stat.Locations = self._count_array(ctx, "Locations")
                    stat.Factions = self._count_array(ctx, "Factions")
                    stat.PlotRules = self._count_array(ctx, "PlotRules")
                    stat.Conflicts = self._count_array(ctx, "Conflicts")
                    stat.ForeshadowingSetups = self._count_array(ctx, "ForeshadowingSetups")
                    stat.ForeshadowingPayoffs = self._count_array(ctx, "ForeshadowingPayoffs")
                    scenes = ch_data.get("Scenes", [])
                    stat.Scenes = len(scenes) if isinstance(scenes, list) else 0
                    report.ChapterStats[ch_id] = stat
            except Exception:
                pass

    @staticmethod
    def _count_array(ctx: dict, field: str) -> int:
        """对标 CountArray"""
        arr = ctx.get(field)
        if isinstance(arr, list):
            return len(arr)
        return 0

    @staticmethod
    def _append_anomaly(report: PackageReport, ch_id: str, label: str, prev: int, curr: int):
        """对标 AppendAnomaly"""
        if prev == curr:
            return
        diff = abs(curr - prev)
        if diff < 5:
            return
        if prev == 0 and curr >= 5:
            report.AnomalyWarnings.append(f"{ch_id} 「{label}」从 0 突增到 {curr}，请确认是否预期")
            return
        if curr == 0 and prev >= 5:
            report.AnomalyWarnings.append(f"{ch_id} 「{label}」从 {prev} 锐减到 0，请确认是否预期")
            return
        base = max(prev, 1)
        ratio = diff / base
        if ratio >= 2.0:
            report.AnomalyWarnings.append(f"{ch_id} 「{label}」从 {prev} 大幅变化为 {curr}，请确认是否预期")

    @staticmethod
    def _save_report(path: str, report: PackageReport):
        """对标 SaveReportAsync"""
        import time
        dir_name = os.path.dirname(path)
        if dir_name and not os.path.exists(dir_name):
            os.makedirs(dir_name)
        tmp = path + f".{int(time.time())}.tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({
                "GeneratedAt": report.GeneratedAt,
                "Version": report.Version,
                "Summary": report.Summary,
                "ChapterStats": {k: v.to_dict() for k, v in report.ChapterStats.items()},
                "VolumeStats": {k: v.to_dict() for k, v in report.VolumeStats.items()},
                "AnomalyWarnings": report.AnomalyWarnings,
            }, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
