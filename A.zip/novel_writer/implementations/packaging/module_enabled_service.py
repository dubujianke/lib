# -*- coding: utf-8 -*-
"""模块启用服务 — 对标 Implementations/Packaging/ModuleEnabledService.cs"""
import json
import os
from typing import Tuple


class ModuleEnabledService:
    def __init__(self, project):
        self.project = project

    def get_module_enabled(self, module_type: str, sub_module: str) -> bool:
        enabled, _ = self.get_module_enabled_stats(module_type, sub_module)
        return enabled > 0

    def get_module_enabled_stats(self, module_type: str, sub_module: str) -> Tuple[int, int]:
        total_enabled = 0
        total_count = 0
        design_dir = self.project.design_dir
        if os.path.exists(design_dir):
            for f in os.listdir(design_dir):
                if not f.endswith(".json"):
                    continue
                enabled, total = self._count_enabled_in_file(os.path.join(design_dir, f))
                total_enabled += enabled
                total_count += total
        return (total_enabled, total_count)

    def set_module_enabled(self, module_type: str, sub_module: str, enabled: bool) -> int:
        updated = 0
        design_dir = self.project.design_dir
        if os.path.exists(design_dir):
            for f in os.listdir(design_dir):
                if not f.endswith(".json"):
                    continue
                updated += self._set_enabled_in_file(os.path.join(design_dir, f), enabled)
        return updated

    def _count_enabled_in_file(self, file_path: str) -> Tuple[int, int]:
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            items = data.get("items", []) if isinstance(data, dict) else (data or [])
            enabled = sum(1 for i in items if isinstance(i, dict) and i.get("IsEnabled", True))
            return (enabled, len(items))
        except Exception:
            return (0, 0)

    def _set_enabled_in_file(self, file_path: str, enabled: bool) -> int:
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            items = data.get("items", []) if isinstance(data, dict) else (data or [])
            updated = 0
            for item in items:
                if isinstance(item, dict):
                    item["IsEnabled"] = enabled
                    updated += 1
            if isinstance(data, dict):
                data["items"] = items
            else:
                data = items
            tmp = file_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, file_path)
            return updated
        except Exception:
            return 0

    # ---- 缺失方法移植 ----

    @staticmethod
    def _debug_log_once(key: str, ex: Exception):
        """对标 DebugLogOnce"""
        # if TM.App.IsDebugMode:
        #     print(f"[ModuleEnabledService] {key}: {ex.message}")
        pass

    def _set_function_data_enabled(self, storage_path: str, enabled: bool) -> int:
        """对标 SetFunctionDataEnabledAsync"""
        if not storage_path:
            return 0
        dir_path = self._resolve_storage_directory(storage_path)
        if not os.path.isdir(dir_path):
            return 0
        updated = 0
        for fname in os.listdir(dir_path):
            if not fname.endswith(".json") or fname.lower() == "categories.json":
                continue
            count = self._update_json_file_enabled(os.path.join(dir_path, fname), enabled)
            updated += count
        return updated

    def _update_json_file_enabled(self, file_path: str, enabled: bool) -> int:
        """对标 UpdateJsonFileEnabledAsync"""
        try:
            if not os.path.exists(file_path):
                return 0
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            items = data if isinstance(data, list) else data.get("items", []) if isinstance(data, dict) else []
            if not isinstance(items, list) or len(items) == 0:
                return 0
            updated = 0
            for item in items:
                if isinstance(item, dict):
                    item["IsEnabled"] = enabled
                    updated += 1
            tmp = file_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, file_path)
            return updated
        except Exception as ex:
            self._debug_log_once(f"UpdateJsonEnabled:{file_path}", ex)
            return 0

    def _get_function_enabled_stats(self, storage_path: str):
        """对标 GetFunctionEnabledStatsAsync"""
        if not storage_path:
            return (0, 0)
        dir_path = self._resolve_storage_directory(storage_path)
        if not os.path.isdir(dir_path):
            return (0, 0)
        enabled = 0
        total = 0
        for fname in os.listdir(dir_path):
            if not fname.endswith(".json") or fname.lower() == "categories.json":
                continue
            e, t = self._count_enabled_in_file(os.path.join(dir_path, fname))
            enabled += e
            total += t
        return (enabled, total)

    def set_all_sub_modules_enabled(self, module_type: str, enabled: bool) -> int:
        """对标 SetAllSubModulesEnabledAsync"""
        total = 0
        try:
            # 简化：遍历 design_dir 下的所有子目录
            design_dir = self.project.design_dir
            if os.path.isdir(design_dir):
                for sub in os.listdir(design_dir):
                    sub_path = os.path.join(design_dir, sub)
                    if os.path.isdir(sub_path):
                        count = self.set_module_enabled(module_type, sub, enabled)
                        total += count
        except Exception:
            pass
        return total

    @staticmethod
    def _resolve_storage_directory(storage_path: str) -> str:
        """对标 ResolveStorageDirectory"""
        if not storage_path:
            return ""
        normalized = storage_path.strip().replace("\\", "/").lstrip("/")
        if normalized.lower().startswith("storage/"):
            normalized = normalized[len("storage/"):]
        return normalized.replace("/", os.sep)
