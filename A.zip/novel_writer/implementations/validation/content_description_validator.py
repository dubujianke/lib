# -*- coding: utf-8 -*-
"""正文描述校验器 — 对标 4.1.1 Validation/ContentDescriptionValidator.cs（完整移植）

对齐功能:
- AntonymPairs（性格反义词 + 发色/眼色反义词）
- ValidateCharacterDescriptions（发色矛盾 + 性格矛盾）
- ValidateLocationDescriptions（地点特征矛盾）
- FindHairColorContradiction / GetAntonyms / ContentContainsNear
"""

from typing import Dict, List

# 对标 C# AntonymPairs
_ANTONYM_PAIRS: Dict[str, List[str]] = {
    "沉默寡言": ["滔滔不绝", "话多", "健谈", "喋喋不休"],
    "内向": ["外向", "开朗", "活泼"],
    "冷漠": ["热情", "温暖", "友善"],
    "温柔": ["冷酷", "暴躁", "粗暴", "残忍"],
    "沉稳": ["冲动", "莽撞", "浮躁", "急躁"],
    "冷静": ["冲动", "慌乱", "失控", "暴躁"],
    "谨慎": ["鲁莽", "冒进", "大意", "草率"],
    "勇敢": ["胆小", "懦弱", "怯懦"],
    "坚强": ["软弱", "脆弱", "怯弱"],
    "正直": ["狡诈", "阴险", "卑鄙", "虚伪"],
    "善良": ["邪恶", "残忍", "冷酷"],
    "忠诚": ["背叛", "叛变", "反叛"],
    "聪明": ["愚蠢", "笨拙", "迟钝"],
    "黑发": ["金发", "白发", "红发", "银发", "棕发", "蓝发", "紫发", "绿发", "灰发"],
    "金发": ["黑发", "白发", "红发", "银发", "棕发", "蓝发", "紫发", "绿发", "灰发"],
    "白发": ["黑发", "金发", "红发", "棕发", "蓝发", "紫发", "绿发", "灰发"],
    "银发": ["黑发", "金发", "红发", "棕发", "蓝发", "紫发", "绿发", "灰发"],
    "红发": ["黑发", "金发", "白发", "银发", "棕发", "蓝发", "紫发", "绿发", "灰发"],
    "蓝眼": ["黑眼", "红眼", "金眼", "绿眼", "紫眼", "灰眼"],
    "黑眼": ["蓝眼", "红眼", "金眼", "绿眼", "紫眼", "灰眼"],
    "红眼": ["黑眼", "蓝眼", "金眼", "绿眼", "紫眼", "灰眼"],
    "金眼": ["黑眼", "蓝眼", "红眼", "绿眼", "紫眼", "灰眼"],
    "绿眼": ["黑眼", "蓝眼", "红眼", "金眼", "紫眼", "灰眼"],
}

# 对标 C# HairColorConstants.HairColorKeywords
_HAIR_COLOR_KEYWORDS = ["黑发", "金发", "白发", "红发", "银发", "棕发", "蓝发", "紫发", "绿发", "灰发"]


def _get_antonyms(tag: str) -> List[str]:
    return _ANTONYM_PAIRS.get(tag, [])


def _content_contains_near(content: str, anchor: str, target: str, max_distance: int) -> bool:
    """对标 ContentContainsNear: 锚点附近 max_distance 字内包含目标词"""
    if not content or not anchor or not target:
        return False
    anchor_index = content.find(anchor)
    if anchor_index < 0:
        return False
    search_start = max(0, anchor_index - max_distance)
    search_end = min(len(content), anchor_index + len(anchor) + max_distance)
    search_region = content[search_start:search_end]
    return target in search_region


def _find_hair_color_contradiction(content: str, character_name: str, expected_color: str):
    """对标 FindHairColorContradiction"""
    other_colors = [c for c in _HAIR_COLOR_KEYWORDS if c != expected_color]
    for color in other_colors:
        if _content_contains_near(content, character_name, color, 30):
            return color
    return None


class ContentDescriptionValidator:
    """对标 C# ContentDescriptionValidator"""

    def validate_character_descriptions(self, content: str, packaged_descriptions: Dict[str, object]) -> List[str]:
        """对标 ValidateCharacterDescriptions"""
        issues = []
        if not content or not packaged_descriptions:
            return issues

        for char_id, desc in packaged_descriptions.items():
            name = getattr(desc, "Name", "") or (desc.get("Name", "") if isinstance(desc, dict) else "")
            if not name:
                continue

            hair_color = getattr(desc, "HairColor", "") or (desc.get("HairColor", "") if isinstance(desc, dict) else "")
            if hair_color:
                contradiction = _find_hair_color_contradiction(content, name, hair_color)
                if contradiction:
                    issues.append(f"角色 {name} 发色矛盾：打包={hair_color}，正文出现={contradiction}")

            tags = getattr(desc, "PersonalityTags", None) or (desc.get("PersonalityTags", []) if isinstance(desc, dict) else [])
            if tags:
                for tag in tags:
                    for antonym in _get_antonyms(tag):
                        if _content_contains_near(content, name, antonym, 50):
                            issues.append(f"角色 {name} 性格矛盾：打包={tag}，正文出现={antonym}")

        return issues

    def validate_location_descriptions(self, content: str, packaged_descriptions: Dict[str, object]) -> List[str]:
        """对标 ValidateLocationDescriptions"""
        issues = []
        if not content or not packaged_descriptions:
            return issues

        for loc_id, desc in packaged_descriptions.items():
            name = getattr(desc, "Name", "") or (desc.get("Name", "") if isinstance(desc, dict) else "")
            features = getattr(desc, "Features", None) or (desc.get("Features", []) if isinstance(desc, dict) else [])
            if not name or not features:
                continue

            for feature in features:
                for antonym in _get_antonyms(feature):
                    if _content_contains_near(content, name, antonym, 100):
                        issues.append(f"地点 {name} 特征矛盾：打包={feature}，正文出现={antonym}")

        return issues