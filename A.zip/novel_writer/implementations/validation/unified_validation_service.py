# -*- coding: utf-8 -*-
"""统一校验服务 — 对标 4.1.1 Validation/UnifiedValidationService.cs（partial 6 文件完整移植）

对齐功能:
- NeedsRepublishAsync / ValidateChapterAsync / ValidateVolumeAsync
- ValidateChapterInternalAsync（正文加载 + ContextIds 校验 + 规则层 + AI 校验）
- RunGateChecksAsync（规则层：StructuralOnly + Gate）
- ExecuteValidationsAsync（AI 校验 + 结果解析）
- BuildValidationPromptAsync（校验提示词构建）
- ParseAIValidationResult / ParseNewProtocolResult
- CalculateSampleCount / SampleChapters（抽样算法）
- AggregateToVolumeSummary（结果聚合）
"""

import hashlib
import json
import math
import os
import re
from typing import Dict, List, Optional

from .validation_rules import (
    ALL_MODULE_NAMES, get_display_name, get_extended_data_schema,
    get_verification_type, total_rule_count,
)
from ..tracking.character_state_service import parse_chapter_id

# 对标 C# 常量
SYSTEM_MODULE_NAME = "System"
STRUCTURAL_MODULE_NAME = "StructuralConsistency"
CHAPTER_PREVIEW_LENGTH = 1000
VALIDATION_BATCH_SIZE = 2


# ---- 模型 ----

class ValidationIssue:
    """对标 C# ValidationIssue"""

    def __init__(self, **kwargs):
        self.Type = kwargs.pop("Type", "")
        self.Severity = kwargs.pop("Severity", "Warning")
        self.Message = kwargs.pop("Message", "")
        self.Suggestion = kwargs.pop("Suggestion", "")
        self.EntityName = kwargs.pop("EntityName", "")

    def to_dict(self) -> dict:
        return {"Type": self.Type, "Severity": self.Severity, "Message": self.Message,
                "Suggestion": self.Suggestion, "EntityName": self.EntityName}


class ChapterValidationResult:
    """对标 C# ChapterValidationResult"""

    def __init__(self):
        self.ChapterId = ""
        self.ChapterTitle = ""
        self.VolumeNumber = 0
        self.ChapterNumber = 0
        self.VolumeName = ""
        self.ValidatedTime = ""
        self.OverallResult = "未校验"
        self.IssuesByModule: Dict[str, List[ValidationIssue]] = {}

    @property
    def has_errors(self) -> bool:
        return any(i.Severity == "Error" for issues in self.IssuesByModule.values() for i in issues)

    @property
    def has_warnings(self) -> bool:
        return any(i.Severity == "Warning" for issues in self.IssuesByModule.values() for i in issues)

    @property
    def total_issue_count(self) -> int:
        return sum(len(issues) for issues in self.IssuesByModule.values())


class ModuleValidationResult:
    """对标 C# ModuleValidationResult"""

    def __init__(self):
        self.ModuleName = ""
        self.DisplayName = ""
        self.VerificationType = ""
        self.Result = "未校验"
        self.IssueDescription = ""
        self.FixSuggestion = ""
        self.ExtendedDataJson = "{}"
        self.ProblemItemsJson = "[]"

    def to_dict(self) -> dict:
        return {"ModuleName": self.ModuleName, "DisplayName": self.DisplayName,
                "VerificationType": self.VerificationType, "Result": self.Result,
                "IssueDescription": self.IssueDescription, "FixSuggestion": self.FixSuggestion,
                "ExtendedDataJson": self.ExtendedDataJson, "ProblemItemsJson": self.ProblemItemsJson}


class ProblemItem:
    """对标 C# ProblemItem"""

    def __init__(self, **kwargs):
        self.Summary = kwargs.pop("Summary", "")
        self.Reason = kwargs.pop("Reason", "")
        self.Details = kwargs.pop("Details", None)
        self.Suggestion = kwargs.pop("Suggestion", None)
        self.ChapterId = kwargs.pop("ChapterId", "")
        self.ChapterTitle = kwargs.pop("ChapterTitle", "")

    def to_dict(self) -> dict:
        return {"Summary": self.Summary, "Reason": self.Reason, "Details": self.Details,
                "Suggestion": self.Suggestion, "ChapterId": self.ChapterId,
                "ChapterTitle": self.ChapterTitle}


class ChapterInfo:
    """对标 C# ChapterInfo"""

    def __init__(self, Id="", ChapterNumber=0, VolumeNumber=0):
        self.Id = Id
        self.ChapterNumber = ChapterNumber
        self.VolumeNumber = VolumeNumber


class UnifiedValidationService:
    """对标 C# UnifiedValidationService"""

    def __init__(self, project, ai_service=None, generation_gate=None,
                 validation_summary_service=None, context_service=None,
                 guide_context_service=None, publish_service=None):
        self.project = project
        self.ai = ai_service
        self.gate = generation_gate
        self.summary_service = validation_summary_service
        # 对标 C# ServiceLocator 注入的依赖（未提供时延迟创建，异常返回 None）
        self._context_service = context_service
        self._guide_context_service = guide_context_service
        self._publish_service = publish_service
        self._rule_signature = self._build_rules_signature()

    # ---- 延迟服务解析（对标 C# ServiceLocator.Get<T>()）----

    def _get_context_service(self):
        if self._context_service is None:
            try:
                from ..context.context_service import ContextService
                self._context_service = ContextService(self.project)
            except Exception:
                return None
        return self._context_service

    def _get_guide_context_service(self):
        if self._guide_context_service is None:
            try:
                from ..guides.guide_context_service import GuideContextService
                self._guide_context_service = GuideContextService(self.project)
            except Exception:
                return None
        return self._guide_context_service

    def _get_generation_gate(self):
        # gate 即 C# _generationGate（构造注入优先，延迟兜底）
        if self.gate is None:
            try:
                from ...gate import GenerationGate
                self.gate = GenerationGate()
            except Exception:
                return None
        return self.gate

    def _get_publish_service(self):
        if self._publish_service is None:
            try:
                from ..packaging.publish_service import PublishService
                self._publish_service = PublishService(self.project)
            except Exception:
                return None
        return self._publish_service

    # ---- 公开方法 ----

    def needs_republish(self) -> bool:
        """对标 NeedsRepublishAsync: publishService.GetManifestAsync() + NeedsRepublish()"""
        try:
            publish_service = self._get_publish_service()
            if publish_service is not None:
                manifest = publish_service.get_manifest()
                if manifest is not None:
                    return bool(publish_service.needs_republish())
        except Exception:
            pass
        # 回退（现有逻辑）：无 manifest 视为需要重发布
        try:
            manifest = self.project.load_design("manifest")
            return not manifest
        except Exception:
            return True

    def validate_chapter(self, chapter_id: str) -> ChapterValidationResult:
        """对标 ValidateChapterAsync"""
        content = self.project.load_chapter(chapter_id)
        return self.validate_chapter_internal(chapter_id, content)

    def validate_chapter_with_content(self, chapter_id: str, content: str) -> ChapterValidationResult:
        """对标 ValidateChapterWithContentAsync"""
        return self.validate_chapter_internal(chapter_id, content)

    def validate_chapter_internal(self, chapter_id: str, content: str) -> ChapterValidationResult:
        """对标 ValidateChapterInternalAsync"""
        volume_number, chapter_number = parse_chapter_id(chapter_id)
        if volume_number == 0 or chapter_number == 0:
            # 短 ID（short_id）章节：从 chapters plan 映射卷号/章号
            mapped = self._resolve_chapter_location(chapter_id)
            if mapped:
                volume_number, chapter_number = mapped
            else:
                return self._create_error_result(chapter_id, "无法解析章节ID")

        if not content:
            return self._create_error_result(chapter_id, "章节正文不存在",
                                             volume_number, chapter_number)

        # 对标: await _contextService.GetValidationContextAsync(chapterId)（拿不到就用现有数据）
        context = None
        try:
            context_service = self._get_context_service()
            if context_service is not None:
                context = context_service.get_validation_context(chapter_id)
        except Exception:
            context = None

        # 对标: await _guideContextService.GetContentGuideAsync() + ValidateContextIdsAsync(...)
        context_ids = None
        try:
            guide_context_service = self._get_guide_context_service()
            if guide_context_service is not None:
                content_guide = guide_context_service.get_content_guide()
                guide_entry = (content_guide.get("Chapters") or {}).get(chapter_id) \
                    if isinstance(content_guide, dict) else None
                if isinstance(guide_entry, dict):
                    context_ids = guide_entry.get("ContextIds")
                    validation = guide_context_service.validate_context_ids(context_ids)
                    if validation is not None and not getattr(validation, "IsValid", True):
                        error_summary = getattr(validation, "get_error_summary", lambda: "")()
                        return self._create_error_result(
                            chapter_id,
                            f"ContextIds 解析失败，索引与本体不一致，请重新打包/更新。\n{error_summary}",
                            volume_number, chapter_number)
        except Exception:
            context_ids = None

        volume_name = self._get_volume_name(volume_number)
        chapter_title = self._extract_chapter_title(content)

        result = ChapterValidationResult()
        result.ChapterId = chapter_id
        result.ChapterTitle = chapter_title
        result.VolumeNumber = volume_number
        result.ChapterNumber = chapter_number
        result.VolumeName = volume_name
        result.ValidatedTime = self._now()

        # 规则层校验
        self._run_gate_checks(result, chapter_id, content)

        # AI 校验
        self._execute_validations(result, chapter_id, content)

        result.OverallResult = self._determine_overall_result(result)
        return result

    def validate_volume(self, volume_number: int, chapters: List[dict] = None) -> Dict:
        """对标 ValidateVolumeAsync"""
        volume_name = self._get_volume_name(volume_number)
        chapters = chapters or self._load_plan("chapters")
        volume_chapters = sorted(
            [c for c in chapters if c.get("VolumeNumber", 0) == volume_number],
            key=lambda c: c.get("ChapterNumber", 0))

        if not volume_chapters:
            return {"VolumeNumber": volume_number, "VolumeName": volume_name, "ChapterResults": []}

        sample_count = self.calculate_sample_count(len(volume_chapters))
        sampled = self.sample_chapters(
            [ChapterInfo(Id=c.get("Id", ""), ChapterNumber=c.get("ChapterNumber", 0),
                         VolumeNumber=c.get("VolumeNumber", 0)) for c in volume_chapters],
            sample_count)

        # 对标 ValidateVolumeAsync: 按 ValidationBatchSize 分批校验
        chapter_results = []
        batches = [sampled[i:i + VALIDATION_BATCH_SIZE] for i in range(0, len(sampled), VALIDATION_BATCH_SIZE)]
        for batch in batches:
            if len(batch) == 1:
                chapter_results.append(self.validate_chapter(batch[0].Id))
            else:
                chapter_results.extend(self.validate_chapter_batch(batch, volume_name))

        chapter_results.sort(key=lambda r: r.ChapterNumber)
        summary = self.aggregate_to_volume_summary(volume_number, volume_name, sampled, chapter_results)

        if self.summary_service:
            self.summary_service.save_volume_validation(volume_number, summary)

        return {"VolumeNumber": volume_number, "VolumeName": volume_name,
                "ChapterResults": chapter_results, "Summary": summary}

    # ---- 规则层 ----

    def _run_gate_checks(self, result: ChapterValidationResult, chapter_id: str, content: str):
        """对标 RunGateChecksAsync"""
        gate = None
        try:
            gate = self._get_generation_gate()
        except Exception:
            gate = None
        if gate is None:
            return
        issues = []
        try:
            # 对标: _generationGate.ValidateChangesProtocol(chapterContent)
            protocol = gate.validate_changes_protocol(content) \
                if hasattr(gate, "validate_changes_protocol") else None
            if protocol is not None and not getattr(protocol, "Success", True):
                for f in getattr(protocol, "Failures", []):
                    for e in getattr(f, "Errors", []):
                        issues.append(ValidationIssue(Type="StructuralRule", Severity="Error", Message=e))
        except Exception:
            pass
        # 兜底：现有结构化校验（对标 ValidateStructuralOnly）
        try:
            from ...gate import GenerationGate
            if not isinstance(gate, GenerationGate):
                gate = None
        except Exception:
            gate = None
        if gate is not None and not issues:
            try:
                from ...models import FactSnapshot
                snapshot = FactSnapshot()
                gate_result = gate.validate(content, snapshot, None, {}, chapter_id)
                if not gate_result.Success:
                    for f in gate_result.Failures:
                        for e in f.Errors:
                            issues.append(ValidationIssue(Type="StructuralRule", Severity="Error", Message=e))
            except Exception:
                pass
        if issues:
            result.IssuesByModule[STRUCTURAL_MODULE_NAME] = issues

    # ---- AI 校验 ----

    def _execute_validations(self, result: ChapterValidationResult, chapter_id: str, content: str):
        """对标 ExecuteValidationsAsync"""
        if self.ai is None:
            return
        try:
            prompt = self._build_validation_prompt(result, content)
            resp = self.ai.chat("", prompt, category="validate")
            if resp:
                self._parse_ai_validation_result(result, resp)
            else:
                result.IssuesByModule[SYSTEM_MODULE_NAME] = [
                    ValidationIssue(Type="AIValidationFailed", Severity="Warning",
                                    Message="AI校验失败，未执行校验。")]
        except Exception as e:
            result.IssuesByModule[SYSTEM_MODULE_NAME] = [
                ValidationIssue(Type="AIValidationException", Severity="Warning",
                                Message=f"AI校验异常：{e}，未执行校验。")]

    def _build_validation_prompt(self, result: ChapterValidationResult, content: str) -> str:
        """对标 BuildValidationPromptAsync（简化：注入章节信息 + 正文 + 校验要求）"""
        lines = []
        lines.append("<validation_task>")
        lines.append("<chapter_info>")
        lines.append(f"- 章节ID: {result.ChapterId}")
        lines.append(f"- 章节标题: {result.ChapterTitle}")
        lines.append(f"- 卷号: {result.VolumeNumber}")
        lines.append(f"- 章节号: {result.ChapterNumber}")
        lines.append(f"- 卷名: {result.VolumeName}")
        lines.append("</chapter_info>")
        lines.append("")
        lines.append("<正文内容>")
        lines.append(content[:CHAPTER_PREVIEW_LENGTH] if len(content) > CHAPTER_PREVIEW_LENGTH else content)
        lines.append("</正文内容>")
        lines.append("")
        lines.append("<校验要求>")
        lines.append(f"请对章节执行{total_rule_count()}条校验规则，返回JSON格式的校验结果。")
        lines.append("返回JSON格式：")
        lines.append("```json")
        lines.append(self._build_json_template())
        lines.append("```")
        lines.append("</校验要求>")
        lines.append("")
        lines.append("<validation_rules_description>")
        lines.append(self._build_rules_description())
        lines.append("</validation_rules_description>")
        lines.append("</validation_task>")
        return "\n".join(lines)

    def _build_json_template(self) -> str:
        """对标 BuildJsonTemplateForPrompt"""
        lines = ["{", '  "overallResult": "通过|警告|失败|未校验",', '  "moduleResults": [']
        for i, module_name in enumerate(ALL_MODULE_NAMES):
            fields = get_extended_data_schema(module_name)
            lines.append("    {")
            lines.append(f'      "moduleName": "{module_name}",')
            lines.append(f'      "displayName": "{get_display_name(module_name)}",')
            lines.append(f'      "verificationType": "{get_verification_type(module_name)}",')
            lines.append('      "result": "通过|警告|失败|未校验",')
            lines.append('      "issueDescription": "",')
            lines.append('      "fixSuggestion": "",')
            lines.append('      "extendedData": {')
            for f_idx, field in enumerate(fields):
                camel = field[0].lower() + field[1:]
                suffix = "" if f_idx == len(fields) - 1 else ","
                lines.append(f'        "{camel}": ""{suffix}')
            lines.append("      },")
            lines.append('      "problemItems": [')
            lines.append("        {")
            lines.append('          "summary": "",')
            lines.append('          "reason": "",')
            lines.append('          "details": "",')
            lines.append('          "suggestion": ""')
            lines.append("        }")
            lines.append("      ]")
            lines.append("    }" + ("" if i == len(ALL_MODULE_NAMES) - 1 else ","))
        lines.append("  ]")
        lines.append("}")
        return "\n".join(lines)

    def _build_rules_description(self) -> str:
        """对标 BuildRulesDescription"""
        lines = [
            "1. StyleConsistency（文风模板一致性）",
            "2. WorldviewConsistency（世界观一致性）",
            "3. CharacterConsistency（角色设定一致性）",
            "4. FactionConsistency（势力设定一致性）",
            "5. LocationConsistency（地点设定一致性）",
            "6. PlotConsistency（剧情规则一致性）",
            "7. OutlineConsistency（大纲一致性）",
            "8. ChapterPlanConsistency（章节规划一致性）",
            "9. BlueprintConsistency（章节蓝图一致性）",
            "10. VolumeDesignConsistency（分卷设计一致性）",
        ]
        return "\n".join(lines)

    def _parse_ai_validation_result(self, result: ChapterValidationResult, ai_content: str):
        """对标 ParseAIValidationResult"""
        try:
            json_start = ai_content.find('{')
            json_end = ai_content.rfind('}')
            if json_start < 0 or json_end < 0 or json_end <= json_start:
                self._add_protocol_error(result, "AI返回内容中未找到有效JSON")
                return
            json_str = ai_content[json_start:json_end + 1]
            doc = json.loads(json_str)
            if "moduleResults" not in doc:
                self._add_protocol_error(result, "AI返回JSON中未找到moduleResults字段")
                return
            module_results = doc["moduleResults"]
            if len(module_results) != total_rule_count():
                self._add_protocol_error(result, f"moduleResults应为{total_rule_count()}项，实际为{len(module_results)}项")
            self._parse_new_protocol_result(result, module_results)
        except Exception as e:
            self._add_protocol_error(result, f"解析AI校验结果失败: {e}")

    def _add_protocol_error(self, result: ChapterValidationResult, message: str):
        if SYSTEM_MODULE_NAME not in result.IssuesByModule:
            result.IssuesByModule[SYSTEM_MODULE_NAME] = []
        result.IssuesByModule[SYSTEM_MODULE_NAME].append(
            ValidationIssue(Type="ProtocolError", Severity="Warning", Message=f"AI协议错误：{message}"))

    def _parse_new_protocol_result(self, result: ChapterValidationResult, module_results: list):
        """对标 ParseNewProtocolResult"""
        parsed_names = set()
        for module in module_results:
            module_name = module.get("moduleName", "Unknown")
            if module_name not in ALL_MODULE_NAMES:
                self._add_protocol_error(result, f"未知的moduleName: {module_name}")
                continue
            parsed_names.add(module_name)

            module_result = module.get("result", "未校验")
            if module_result == "通过":
                continue

            issues = []
            severity = "Error" if module_result == "失败" else "Warning"
            problem_items = module.get("problemItems", [])
            for item in problem_items:
                issues.append(ValidationIssue(
                    Type=item.get("reason", ""),
                    Severity=severity,
                    Message=item.get("summary", ""),
                    Suggestion=item.get("suggestion", "")))
            if not issues:
                issue_desc = module.get("issueDescription", "")
                fix_sug = module.get("fixSuggestion", "")
                default_message = (f"规则未校验：{get_display_name(module_name)}" if module_result == "未校验"
                                   else issue_desc or f"{module_name}校验{module_result}")
                issues.append(ValidationIssue(
                    Type="UnvalidatedRule" if module_result == "未校验" else "ValidationIssue",
                    Severity=severity, Message=default_message, Suggestion=fix_sug))
            result.IssuesByModule[module_name] = issues

        missing = [m for m in ALL_MODULE_NAMES if m not in parsed_names]
        if missing:
            self._add_protocol_error(result, f"缺失模块: {', '.join(missing)}")

    # ---- 抽样 ----

    @staticmethod
    def calculate_sample_count(total_count: int) -> int:
        """对标 CalculateSampleCount: ceil(n/5)，3~50 之间"""
        sample = math.ceil(total_count / 5.0)
        return max(3, min(50, sample))

    def sample_chapters(self, chapters: List[ChapterInfo], max_count: int) -> List[ChapterInfo]:
        """对标 SampleChapters: 均匀抽样，首尾必含"""
        if not chapters:
            return []
        if len(chapters) <= max_count:
            return list(chapters)

        sampled = []
        total = len(chapters)
        step = (total - 1) / (max_count - 1)
        for i in range(max_count):
            index = min(round(i * step), total - 1)
            if chapters[index] not in sampled:
                sampled.append(chapters[index])

        if chapters[0] not in sampled:
            sampled.insert(0, chapters[0])
            if len(sampled) > max_count:
                sampled.pop()
        if chapters[total - 1] not in sampled:
            if len(sampled) >= max_count:
                sampled.pop()
            sampled.append(chapters[total - 1])

        return sorted(sampled, key=lambda c: c.ChapterNumber)

    # ---- 聚合 ----

    def aggregate_to_volume_summary(self, volume_number: int, volume_name: str,
                                    sampled_chapters: List[ChapterInfo],
                                    chapter_results: List[ChapterValidationResult]):
        """对标 AggregateToVolumeSummary"""
        from .validation_summary_service import ValidationSummaryData
        module_results = []
        for module_name in ALL_MODULE_NAMES:
            module_results.append(self._aggregate_module_result(module_name, chapter_results))

        overall = self._calculate_overall_result(module_results)

        data = ValidationSummaryData()
        data.Id = ""
        data.Name = f"第{volume_number}卷校验"
        data.Category = f"第{volume_number}卷"
        data.TargetVolumeNumber = volume_number
        data.TargetVolumeName = volume_name
        data.SampledChapterCount = len(sampled_chapters)
        data.SampledChapterIds = [c.Id for c in sampled_chapters]
        data.LastValidatedTime = self._now()
        data.OverallResult = overall
        data.ModuleResults = [m.to_dict() for m in module_results]
        return data

    def _aggregate_module_result(self, module_name: str,
                                 chapter_results: List[ChapterValidationResult]) -> ModuleValidationResult:
        """对标 AggregateModuleResult"""
        all_issues = []
        for c in chapter_results:
            issues = c.IssuesByModule.get(module_name, [])
            all_issues.extend(issues)

        if any(i.Severity == "Error" for i in all_issues):
            aggregated = "失败"
        elif any(i.Severity == "Warning" for i in all_issues):
            aggregated = "警告"
        elif not all_issues:
            aggregated = "通过"
        else:
            aggregated = "警告"

        problem_items = []
        for c in chapter_results:
            module_issues = c.IssuesByModule.get(module_name, [])
            for issue in module_issues:
                problem_items.append(ProblemItem(
                    Summary=issue.Message, Reason=issue.Type,
                    Details=f"相关实体: {issue.EntityName}" if issue.EntityName else None,
                    Suggestion=issue.Suggestion or None,
                    ChapterId=c.ChapterId, ChapterTitle=c.ChapterTitle))

        extended_data = self._generate_extended_data(module_name)

        result = ModuleValidationResult()
        result.ModuleName = module_name
        result.DisplayName = get_display_name(module_name)
        result.VerificationType = get_verification_type(module_name)
        result.Result = aggregated
        result.IssueDescription = self._generate_issue_description(all_issues)
        result.FixSuggestion = self._generate_fix_suggestion(all_issues)
        result.ExtendedDataJson = json.dumps(extended_data, ensure_ascii=False)
        result.ProblemItemsJson = json.dumps([p.to_dict() for p in problem_items], ensure_ascii=False)
        return result

    @staticmethod
    def _calculate_overall_result(module_results: List[ModuleValidationResult]) -> str:
        if any(m.Result == "失败" for m in module_results):
            return "失败"
        if any(m.Result == "警告" for m in module_results):
            return "警告"
        if all(m.Result == "通过" for m in module_results):
            return "通过"
        return "未校验"

    @staticmethod
    def _generate_issue_description(issues: List[ValidationIssue]) -> str:
        if not issues:
            return ""
        descriptions = list({i.Message for i in issues if i.Message})[:3]
        return "; ".join(descriptions)

    @staticmethod
    def _generate_fix_suggestion(issues: List[ValidationIssue]) -> str:
        suggestions = list({i.Suggestion for i in issues if i.Suggestion})[:3]
        return "; ".join(suggestions)

    @staticmethod
    def _generate_extended_data(module_name: str) -> Dict[str, str]:
        schema = get_extended_data_schema(module_name)
        return {field[0].lower() + field[1:]: "" for field in schema}

    # ---- 辅助 ----

    def _build_rules_signature(self) -> str:
        """对标 BuildRulesSignature"""
        sb = []
        for module_name in ALL_MODULE_NAMES:
            sb.append(module_name + ":")
            for field in get_extended_data_schema(module_name):
                sb.append(field + ",")
            sb.append("|")
        content = "".join(sb)
        return self._compute_hash(content)

    @staticmethod
    def _compute_hash(content: str) -> str:
        """对标 ComputeHash"""
        return hashlib.sha256(content.encode("utf-8")).hexdigest()[:16]

    def _ensure_packaged_data(self):
        """对标 EnsurePackagedDataOrThrowAsync: publishService.GetManifestAsync() + 目录检查"""
        # 对标: var manifest = await _publishService.GetManifestAsync(); manifest == null → throw
        try:
            publish_service = self._get_publish_service()
            if publish_service is not None and publish_service.get_manifest() is None:
                raise RuntimeError("未找到打包数据，请先执行打包")
        except RuntimeError:
            raise
        except Exception:
            pass
        design_dir = os.path.join(self.project.dir, "design")
        plan_dir = os.path.join(self.project.dir, "plan")
        try:
            has_design = os.path.exists(design_dir) and any(
                f.endswith(".json") for f in os.listdir(design_dir))
            has_plan = os.path.exists(plan_dir) and any(
                f.endswith(".json") for f in os.listdir(plan_dir))
        except Exception:
            has_design = has_plan = False
        if not has_design and not has_plan:
            raise RuntimeError("当前没有用于校验的数据，请进行打包")

    @staticmethod
    def _get_overall_result_icon(overall_result: str) -> str:
        """对标 GetOverallResultIcon"""
        return {"通过": "Icon.CheckCircle", "警告": "Icon.Warning",
                "失败": "Icon.Error"}.get(overall_result, "Icon.Clock")

    @staticmethod
    def _truncate_string(text: str, max_length: int) -> str:
        """对标 TruncateString"""
        if not text:
            return ""
        return text if len(text) <= max_length else text[:max_length] + "..."

    @staticmethod
    def _append_section(sb: List[str], title: str, lines: List[str], max_items: int = 8):
        """对标 AppendSection"""
        items = [l for l in lines if l and l.strip()][:max_items]
        if not items:
            return
        sb.append(f'<section name="{title}">')
        for line in items:
            sb.append(f"- {line}")
        sb.append("</section>")
        sb.append("")

    def _get_volume_name(self, volume_number: int) -> str:
        volumes = self._load_plan("volumes")
        volume = next((v for v in volumes if v.get("VolumeNumber") == volume_number), None)
        title = volume.get("VolumeTitle", "") if volume else ""
        name = f"第{volume_number}卷 {title}".strip() if volume_number > 0 else (volume or {}).get("Name", "")
        return name or f"第{volume_number}卷"

    @staticmethod
    def _extract_chapter_title(content: str) -> str:
        """对标 ExtractChapterTitle"""
        if not content:
            return "未命名章节"
        for line in content.split("\n"):
            trimmed = line.strip()
            if trimmed.startswith("# "):
                return trimmed[2:].strip()
            if trimmed.startswith("## "):
                return trimmed[3:].strip()
        return "未命名章节"

    @staticmethod
    def _determine_overall_result(result: ChapterValidationResult) -> str:
        """对标 DetermineOverallResult"""
        if result.has_errors:
            return "失败"
        if result.has_warnings:
            return "警告"
        if result.total_issue_count > 0:
            return "警告"
        return "通过"

    @staticmethod
    def _create_error_result(chapter_id: str, message: str, volume_number: int = 0,
                             chapter_number: int = 0, volume_name: str = "") -> ChapterValidationResult:
        """对标 CreateErrorResult"""
        result = ChapterValidationResult()
        result.ChapterId = chapter_id
        result.VolumeNumber = volume_number
        result.ChapterNumber = chapter_number
        result.VolumeName = volume_name
        result.OverallResult = "失败"
        result.ValidatedTime = UnifiedValidationService._now()
        result.IssuesByModule[SYSTEM_MODULE_NAME] = [
            ValidationIssue(Type="SystemError", Severity="Error", Message=message)]
        return result

    # ---- 存储读取 ----

    def _load_plan(self, entity: str) -> list:
        data = self.project.load_plan(entity)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return data.get(entity, data.get("items", []))
        return []

    # ---- 上下文解析（对标 Aggregation.cs Resolve* 系列） ----

    def _resolve_chapter_location(self, chapter_id: str) -> Optional[tuple]:
        """从 chapters plan 解析短 ID 章节的 (卷号, 章号)"""
        try:
            chapters = self._load_plan("chapters")
            for c in chapters:
                if c.get("Id") == chapter_id:
                    vn = c.get("VolumeNumber", 0)
                    cn = c.get("ChapterNumber", 0)
                    if vn and cn:
                        return (vn, cn)
        except Exception:
            pass
        return None

    def _resolve_outline(self, outline_id: str = None) -> Optional[dict]:
        """对标 ResolveOutline"""
        if not outline_id:
            return None
        outlines = self._load_plan("outline")
        if isinstance(outlines, list):
            return next((o for o in outlines if o.get("Id") == outline_id), None)
        return None

    def _build_chapter_plan_lines(self, chapter_plan_id: str = None) -> List[str]:
        """对标 BuildChapterPlanLines"""
        if not chapter_plan_id:
            return []
        chapters = self._load_plan("chapters")
        chapter = next((c for c in chapters if c.get("Id") == chapter_plan_id), None)
        if not chapter:
            return []
        return [
            f"标题={chapter.get('ChapterTitle', '')}",
            f"主题={self._truncate_string(chapter.get('ChapterTheme', ''), 60)}",
            f"主目标={self._truncate_string(chapter.get('MainGoal', ''), 60)}",
            f"关键转折={self._truncate_string(chapter.get('KeyTurn', ''), 60)}",
            f"结尾钩子={self._truncate_string(chapter.get('Hook', ''), 60)}",
            f"伏笔={self._truncate_string(chapter.get('Foreshadowing', ''), 60)}",
        ]

    def _resolve_blueprint_items(self, blueprint_ids: List[str] = None) -> List[str]:
        """对标 ResolveBlueprintItems"""
        if not blueprint_ids:
            return []
        blueprint_id_set = set(blueprint_ids)
        items = []
        chapters = self._load_plan("chapters")
        for ch in chapters:
            cid = ch.get("Id", "")
            if not cid:
                continue
            blueprints = self.project.load_plan(f"blueprints_{cid}")
            if not isinstance(blueprints, list):
                continue
            for b in blueprints[:5]:
                if b.get("Id") in blueprint_id_set:
                    items.append(
                        f"结构={self._truncate_string(b.get('OneLineStructure', ''), 60)}, "
                        f"节奏={self._truncate_string(b.get('PacingCurve', ''), 40)}, "
                        f"角色={self._truncate_string(b.get('Cast', ''), 40)}, "
                        f"地点={self._truncate_string(b.get('Locations', ''), 40)}")
        return items

    def _resolve_volume_design(self, volume_design_id: str = None) -> Optional[dict]:
        """对标 ResolveVolumeDesign"""
        if not volume_design_id:
            return None
        volumes = self._load_plan("volumes")
        return next((v for v in volumes if v.get("Id") == volume_design_id), None)

    def _get_current_dependency_versions(self) -> Dict[str, int]:
        """对标 GetCurrentDependencyVersions"""
        return {"Design": 0, "Generate": 0}

    # ---- 批量校验（对标 PublicMethods.cs ValidateChapterBatchAsync 系列） ----

    def validate_chapter_batch(self, batch: List[ChapterInfo], volume_name: str = "") -> List[ChapterValidationResult]:
        """对标 ValidateChapterBatchAsync: 批量校验（降级逐章）"""
        results = []
        contents = []
        for chapter in batch:
            content = self.project.load_chapter(chapter.Id)
            if isinstance(content, dict):
                content = content.get("content", "")
            if not content:
                results.append(self._create_error_result(
                    chapter.Id, "章节正文不存在", chapter.VolumeNumber, chapter.ChapterNumber, volume_name))
                contents.append(None)
                continue
            r = ChapterValidationResult()
            r.ChapterId = chapter.Id
            r.ChapterTitle = self._extract_chapter_title(content)
            r.VolumeNumber = chapter.VolumeNumber
            r.ChapterNumber = chapter.ChapterNumber
            r.VolumeName = volume_name
            r.ValidatedTime = self._now()
            results.append(r)
            contents.append(content)

        # 批量 AI 校验：尝试一次调用，失败降级逐章
        pending_indices = [i for i, c in enumerate(contents) if c]
        if not pending_indices:
            return results
        if len(pending_indices) == 1:
            idx = pending_indices[0]
            self._execute_validations(results[idx], batch[idx].Id, contents[idx])
            results[idx].OverallResult = self._determine_overall_result(results[idx])
            return results

        try:
            batch_prompt = self._build_batch_validation_prompt(batch, pending_indices, contents, results)
            resp = self.ai.chat("", batch_prompt, category="validate") if self.ai else ""
            if not resp:
                raise ValueError("批量AI校验失败")
            self._parse_batch_ai_validation_result(
                [results[i] for i in pending_indices], batch, resp)
        except Exception:
            for idx in pending_indices:
                self._execute_validations(results[idx], batch[idx].Id, contents[idx])

        for idx in pending_indices:
            results[idx].OverallResult = self._determine_overall_result(results[idx])
        return results

    def _build_batch_validation_prompt(self, batch: List[ChapterInfo], pending_indices: List[int],
                                       contents: List, results: List[ChapterValidationResult]) -> str:
        """对标 BuildBatchValidationPromptAsync"""
        sb = []
        sb.append("<batch_validation_task>")
        sb.append(f"<batch_size>{len(pending_indices)}</batch_size>")
        sb.append("请对以下每个章节分别执行校验，返回JSON数组。")
        sb.append("")
        for seq, idx in enumerate(pending_indices):
            r = results[idx]
            content = contents[idx]
            sb.append(f'<chapter index="{seq + 1}">')
            sb.append(f"<chapter_id>{r.ChapterId}</chapter_id>")
            sb.append(f"<chapter_info>标题={r.ChapterTitle}, 卷={r.VolumeNumber}, 章={r.ChapterNumber}</chapter_info>")
            sb.append(f"<正文内容>{content[:CHAPTER_PREVIEW_LENGTH] if len(content) > CHAPTER_PREVIEW_LENGTH else content}</正文内容>")
            sb.append("</chapter>")
            sb.append("")
        sb.append("<校验要求>")
        sb.append(f"对每个章节执行{total_rule_count()}条校验规则，返回JSON数组。")
        sb.append("```json")
        sb.append("[")
        sb.append("  {")
        sb.append('    "chapterId": "章节ID",')
        sb.append('    "overallResult": "通过|警告|失败|未校验",')
        sb.append('    "moduleResults": ' + self._build_json_template().replace("\n", "\n    "))
        sb.append("  }")
        sb.append("]")
        sb.append("```")
        sb.append("</校验要求>")
        sb.append("</batch_validation_task>")
        return "\n".join(sb)

    def _parse_batch_ai_validation_result(self, results: List[ChapterValidationResult],
                                          batch: List[ChapterInfo], ai_content: str):
        """对标 ParseBatchAIValidationResult"""
        try:
            arr_start = ai_content.find('[')
            arr_end = ai_content.rfind(']')
            if arr_start < 0 or arr_end <= arr_start:
                for r in results:
                    self._add_protocol_error(r, "批量校验AI返回格式错误")
                return
            json_str = ai_content[arr_start:arr_end + 1]
            arr = json.loads(json_str)
            for i, r in enumerate(results):
                if i >= len(arr):
                    self._add_protocol_error(r, "批量校验AI返回数组长度不足")
                    continue
                elem = arr[i]
                if "moduleResults" in elem:
                    self._parse_new_protocol_result(r, elem["moduleResults"])
                else:
                    self._add_protocol_error(r, "批量校验结果缺少moduleResults")
        except Exception as e:
            for r in results:
                self._add_protocol_error(r, f"批量解析失败: {e}")

    @staticmethod
    def _now() -> str:
        import time
        return time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())

    # ---- 缺失方法移植 ----

    def _get_validation_template_system_prompt(self) -> str:
        """对标 GetValidationTemplateSystemPrompt"""
        # 简化：返回基础校验提示词
        return ("你是一个小说章节校验助手。请根据给定的设计数据（世界观、角色、势力、地点、剧情规则等）"
                "和章节正文，逐条执行校验规则，返回JSON格式的校验结果。")

    def _build_json_template_for_prompt(self) -> str:
        """对标 BuildJsonTemplateForPrompt"""
        return self._build_json_template()

    def _add_protocol_error_issue(self, result: ChapterValidationResult, message: str):
        """对标 AddProtocolErrorIssue"""
        self._add_protocol_error(result, message)

    def _ensure_packaged_data_or_throw(self):
        """对标 EnsurePackagedDataOrThrowAsync"""
        self._ensure_packaged_data()