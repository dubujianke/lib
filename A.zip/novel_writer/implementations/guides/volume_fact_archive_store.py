# -*- coding: utf-8 -*-
"""卷事实档案存储 — 对标 Implementations/Guides/VolumeFactArchiveStore.cs"""
import json
import os
import threading
from typing import Dict, List, Optional


class VolumeFactArchiveStore:
    def __init__(self, project):
        self.project = project
        self._cache: Dict[int, object] = {}
        self._write_lock = threading.Lock()

    def invalidate_cache(self):
        self._cache.clear()

    def _archives_dir(self) -> str:
        return os.path.join(self.project.dir, "guides", "fact_archives")

    def _archive_path(self, volume_number: int) -> str:
        return os.path.join(self._archives_dir(), f"vol{volume_number}.json")

    def archive_volume(self, volume_number: int, snapshot, last_chapter_id: str):
        from ...models.tracking.snapshots.volume_fact_archive import VolumeFactArchive
        if volume_number <= 0 or snapshot is None:
            return
        archive = VolumeFactArchive(
            VolumeNumber=volume_number,
            LastChapterId=last_chapter_id,
            ArchivedAt="",
        )
        # 从 snapshot 复制 11 维
        for field in ("CharacterStates", "ConflictProgress", "ForeshadowingStatus",
                      "LocationStates", "FactionStates", "ItemStates", "SecretStates",
                      "Timeline", "CharacterLocations", "PledgeStates", "DeadlineStates"):
            setattr(archive, field, list(getattr(snapshot, field, []) or []))
        with self._write_lock:
            self._save_archive(volume_number, archive)
            self._cache[volume_number] = archive

    def delete_archive(self, volume_number: int):
        if volume_number <= 0:
            return
        path = self._archive_path(volume_number)
        with self._write_lock:
            self._cache.pop(volume_number, None)
            if os.path.exists(path):
                os.remove(path)

    def delete_archive_if_last_chapter(self, volume_number: int, chapter_id: str):
        """对标 DeleteArchiveIfLastChapterAsync：仅当 LastChapterId 匹配时删除存档"""
        if volume_number <= 0 or not chapter_id:
            return
        archive = self._load_archive(volume_number)
        if archive is None:
            return
        last_id = (archive.LastChapterId or "")
        if last_id.lower() != chapter_id.lower():
            return
        path = self._archive_path(volume_number)
        with self._write_lock:
            self._cache.pop(volume_number, None)
            if os.path.exists(path):
                os.remove(path)

    # ---- 对标私有路径方法 ----
    def get_archives_dir(self) -> str:
        """对标 GetArchivesDir"""
        return self._archives_dir()

    def get_archive_file_path(self, volume_number: int) -> str:
        """对标 GetArchiveFilePath"""
        return self._archive_path(volume_number)

    def get_previous_archives(self, current_volume_number: int) -> List:
        result = []
        if current_volume_number <= 1:
            return result
        max_vols = 8
        start_vol = max(1, current_volume_number - max_vols)
        for vol in range(start_vol, current_volume_number):
            archive = self._load_archive(vol)
            if archive is not None:
                result.append(archive)
        return result

    def _load_archive(self, volume_number: int) -> Optional[object]:
        from ...models.tracking.snapshots.volume_fact_archive import VolumeFactArchive
        if volume_number in self._cache:
            return self._cache[volume_number]
        path = self._archive_path(volume_number)
        if not os.path.exists(path):
            return None
        try:
            with open(path, "r", encoding="utf-8") as f:
                archive = VolumeFactArchive.from_dict(json.load(f))
            self._cache[volume_number] = archive
            return archive
        except Exception:
            return None

    def _save_archive(self, volume_number: int, archive):
        os.makedirs(self._archives_dir(), exist_ok=True)
        path = self._archive_path(volume_number)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(archive.to_dict(), f, ensure_ascii=False)
        os.replace(tmp, path)
