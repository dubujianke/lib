# -*- coding: utf-8 -*-
"""Guide 上下文服务 — 对标 Implementations/Guides/GuideContextService.cs（partial 8 文件）

核心：设计数据缓存 + 按 ID/全量抽取 + ContextIds 校验 + 事实快照抽取
"""
import json
import os
import re
import threading
from typing import Dict, List, Optional

from ...models.guides.context_id_collection import ContextIdCollection, ContextIdValidationResult
from ...models.context.expansion_config import ExpansionConfig
from ...ledger_config import LedgerConfig
from ...snapshot_config import SnapshotConfig
from ..tracking.character_state_service import compare_chapter_id, parse_chapter_id


class LayeredContextConfig:
    """对标 LayeredContextConfig（聚合 Ledger + Snapshot 配置）"""

    def __init__(self, ledger_config=None, snapshot_config=None):
        self.ledger = ledger_config or LedgerConfig()
        self.snapshot = snapshot_config or SnapshotConfig()
        self.DriftWarningsMaxPerEntity = 100000
        self.DriftEscalateThreshold = 3
        self.DriftMinNameLength = 2
        self.PledgeMaxDanglingChapters = 100
        self.DeadlineMaxDanglingChapters = 50
        self.MilestoneAnchorInterval = 8
        self.VolumeMilestoneMaxChars = 20000
        self.MilestoneMaxPreviousVolumes = 12
        self.ArchiveMaxPreviousVolumes = 8

    def take_snapshot(self):
        return self

    def initialize_from_storage(self):
        try:
            import os, json
            path = os.path.join(self.ledger._project_dir if hasattr(self.ledger, '_project_dir') else '', 'Settings', 'layered_context_settings.json')
            if not os.path.exists(path):
                return
            with open(path, 'r', encoding='utf-8') as f:
                d = json.load(f)
            def try_set_int(key, setter, min_v, max_v):
                if key in d and isinstance(d[key], (int, float)):
                    setter(max(min_v, min(max_v, int(d[key]))))
            def try_set_bool(key, setter):
                if key in d:
                    if isinstance(d[key], bool):
                        setter(d[key])
                    elif isinstance(d[key], (int, float)):
                        setter(int(d[key]) != 0)
            def try_set_double(key, setter, min_v, max_v):
                if key in d and isinstance(d[key], (int, float)):
                    setter(max(min_v, min(max_v, float(d[key]))))
            try_set_int("ActiveEntityWindowChapters", lambda v: setattr(self.ledger, 'ActiveEntityWindowChapters', v), 1, 1000)
            try_set_int("ActiveEntityWindowMaxCount", lambda v: setattr(self.ledger, 'ActiveEntityWindowMaxCount', v), 0, 10000)
            try_set_int("MilestoneAnchorInterval", lambda v: setattr(self, 'MilestoneAnchorInterval', v), 1, 1000)
            try_set_int("VolumeMilestoneMaxChars", lambda v: setattr(self, 'VolumeMilestoneMaxChars', v), 0, 2000000)
            try_set_int("MilestoneMaxPreviousVolumes", lambda v: setattr(self, 'MilestoneMaxPreviousVolumes', v), 0, 2000)
            try_set_int("ArchiveMaxPreviousVolumes", lambda v: setattr(self, 'ArchiveMaxPreviousVolumes', v), 0, 2000)
            try_set_int("DriftWarningsMaxPerEntity", lambda v: setattr(self, 'DriftWarningsMaxPerEntity', v), 0, 1000000)
            try_set_int("DriftEscalateThreshold", lambda v: setattr(self, 'DriftEscalateThreshold', v), 0, 1000)
            try_set_int("DriftMinNameLength", lambda v: setattr(self, 'DriftMinNameLength', v), 1, 100)
            try_set_int("PledgeMaxDanglingChapters", lambda v: setattr(self, 'PledgeMaxDanglingChapters', v), 0, 10000)
            try_set_int("DeadlineMaxDanglingChapters", lambda v: setattr(self, 'DeadlineMaxDanglingChapters', v), 0, 10000)
            try_set_bool("SemanticRecallEnabled", lambda v: setattr(self, 'SemanticRecallEnabled', v))
            try_set_double("FirstDescriptionThreshold", lambda v: setattr(self, 'FirstDescriptionThreshold', v), 0.0, 1.0)
        except Exception:
            pass

    def save_to_storage(self):
        try:
            import os, json, uuid
            d = {
                "ActiveEntityWindowChapters": getattr(self.ledger, 'ActiveEntityWindowChapters', 8),
                "ActiveEntityWindowMaxCount": getattr(self.ledger, 'ActiveEntityWindowMaxCount', 25),
                "MilestoneAnchorInterval": self.MilestoneAnchorInterval,
                "VolumeMilestoneMaxChars": self.VolumeMilestoneMaxChars,
                "MilestoneMaxPreviousVolumes": self.MilestoneMaxPreviousVolumes,
                "ArchiveMaxPreviousVolumes": self.ArchiveMaxPreviousVolumes,
                "DriftWarningsMaxPerEntity": self.DriftWarningsMaxPerEntity,
                "DriftEscalateThreshold": self.DriftEscalateThreshold,
                "DriftMinNameLength": self.DriftMinNameLength,
                "PledgeMaxDanglingChapters": self.PledgeMaxDanglingChapters,
                "DeadlineMaxDanglingChapters": self.DeadlineMaxDanglingChapters,
                "SemanticRecallEnabled": getattr(self, 'SemanticRecallEnabled', True),
                "FirstDescriptionThreshold": getattr(self, 'FirstDescriptionThreshold', 0.5),
            }
            base_dir = os.path.join(self.ledger._project_dir if hasattr(self.ledger, '_project_dir') else '', 'Settings')
            os.makedirs(base_dir, exist_ok=True)
            tmp = os.path.join(base_dir, f"layered_context_settings.{uuid.uuid4().hex}.tmp")
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(d, f, ensure_ascii=False, indent=2)
            os.replace(tmp, os.path.join(base_dir, 'layered_context_settings.json'))
        except Exception:
            pass


class GuideContextService:
    def __init__(self, project, fact_snapshot_extractor=None, summary_store=None, milestone_store=None):
        self.project = project
        self._fact_snapshot_extractor = fact_snapshot_extractor
        self._summary_store = summary_store
        self._milestone_store = milestone_store
        # 缓存
        self._character_cache: Dict[str, dict] = {}
        self._location_cache: Dict[str, dict] = {}
        self._plot_rules_cache: Dict[str, dict] = {}
        self._faction_cache: Dict[str, dict] = {}
        self._template_cache: Dict[str, dict] = {}
        self._world_rules_cache: Dict[str, dict] = {}
        self._volume_cache: Dict[str, dict] = {}
        self._chapter_plan_cache: Dict[str, dict] = {}
        self._blueprint_cache: Dict[str, dict] = {}
        self._volume_design_cache: Dict[str, dict] = {}
        self._cache_initialized = False
        self._cache_lock = threading.Lock()
        self._expansion_config = None

    # ---- 缓存初始化 ----

    def initialize_cache(self):
        if self._cache_initialized:
            return
        with self._cache_lock:
            if self._cache_initialized:
                return
            self._load_all_caches()
            self._cache_initialized = True

    def _load_all_caches(self):
        for entity, cache, key_field in [
            ("characters", self._character_cache, "Id"),
            ("locations", self._location_cache, "Id"),
            ("plot", self._plot_rules_cache, "Id"),
            ("factions", self._faction_cache, "Id"),
            ("materials", self._template_cache, "Id"),
            ("world", self._world_rules_cache, "Id"),
        ]:
            data = self.project.load_design(entity)
            items = data.get("items", []) if isinstance(data, dict) else (data or [])
            for item in items:
                if isinstance(item, dict) and item.get("Id"):
                    cache[item["Id"]] = item

        # 规划数据
        chapters = self._load_plan("chapters")
        for ch in chapters:
            if ch.get("Id"):
                self._chapter_plan_cache[ch["Id"]] = ch
        volumes = self._load_plan("volumes")
        for v in volumes:
            if v.get("Id"):
                self._volume_design_cache[v["Id"]] = v
            vn = v.get("VolumeNumber", 0)
            if vn and v.get("Id"):
                self._volume_cache[v["Id"]] = v

    def _load_plan(self, entity: str) -> list:
        data = self.project.load_plan(entity)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return data.get(entity, data.get("items", []))
        return []

    def clear_cache(self):
        with self._cache_lock:
            self._character_cache.clear()
            self._location_cache.clear()
            self._plot_rules_cache.clear()
            self._faction_cache.clear()
            self._template_cache.clear()
            self._world_rules_cache.clear()
            self._volume_cache.clear()
            self._chapter_plan_cache.clear()
            self._blueprint_cache.clear()
            self._volume_design_cache.clear()
            self._cache_initialized = False

    # ---- 抽取 ----

    def extract_characters(self, ids: List[str]) -> list:
        self.initialize_cache()
        return [self._character_cache[i] for i in ids if i in self._character_cache]

    def get_all_characters(self) -> list:
        self.initialize_cache()
        return list(self._character_cache.values())

    def extract_locations(self, ids: List[str]) -> list:
        self.initialize_cache()
        return [self._location_cache[i] for i in ids if i in self._location_cache]

    def get_all_locations(self) -> list:
        self.initialize_cache()
        return list(self._location_cache.values())

    def extract_plot_rules(self, ids: List[str]) -> list:
        self.initialize_cache()
        return [self._plot_rules_cache[i] for i in ids if i in self._plot_rules_cache]

    def get_all_plot_rules(self) -> list:
        self.initialize_cache()
        return list(self._plot_rules_cache.values())

    def extract_factions(self, ids: List[str]) -> list:
        self.initialize_cache()
        return [self._faction_cache[i] for i in ids if i in self._faction_cache]

    def get_all_factions(self) -> list:
        self.initialize_cache()
        return list(self._faction_cache.values())

    def extract_templates(self, ids: List[str]) -> list:
        self.initialize_cache()
        return [self._template_cache[i] for i in ids if i in self._template_cache]

    def get_all_templates(self) -> list:
        self.initialize_cache()
        return list(self._template_cache.values())

    def extract_world_rules(self, ids: List[str]) -> list:
        self.initialize_cache()
        return [self._world_rules_cache[i] for i in ids if i in self._world_rules_cache]

    def get_all_world_rules(self) -> list:
        self.initialize_cache()
        return list(self._world_rules_cache.values())

    # ---- ContextIds 校验 ----

    def validate_context_ids(self, context_ids: Optional[ContextIdCollection]) -> ContextIdValidationResult:
        if context_ids is None:
            return ContextIdValidationResult.success()
        self.initialize_cache()
        missing: Dict[str, List[str]] = {}
        checks = [
            ("Characters", context_ids.Characters, self._character_cache),
            ("Locations", context_ids.Locations, self._location_cache),
            ("Factions", context_ids.Factions, self._faction_cache),
            ("PlotRules", context_ids.PlotRules, self._plot_rules_cache),
            ("TemplateIds", context_ids.TemplateIds, self._template_cache),
            ("WorldRuleIds", context_ids.WorldRuleIds, self._world_rules_cache),
        ]
        for name, ids, cache in checks:
            if ids:
                miss = [i for i in ids if i not in cache]
                if miss:
                    missing[name] = miss
        if context_ids.ChapterPlanId and context_ids.ChapterPlanId not in self._chapter_plan_cache:
            missing["ChapterPlanId"] = [context_ids.ChapterPlanId]
        if missing:
            return ContextIdValidationResult.failed(missing)
        return ContextIdValidationResult.success()

    # ---- 事实快照 ----

    def extract_fact_snapshot_for_chapter(self, chapter_id: str, context_ids: ContextIdCollection):
        if self._fact_snapshot_extractor:
            return self._fact_snapshot_extractor.extract(chapter_id, 0)
        return None

    def get_volume_max_chapter(self, volume_number: int) -> int:
        chapters = self._load_plan("chapters")
        max_chapter = 0
        for ch in chapters:
            if ch.get("VolumeNumber", 0) == volume_number:
                max_chapter = max(max_chapter, ch.get("ChapterNumber", 0))
        return max_chapter

    # ---- Risk ----

    @staticmethod
    def count_recent_drift_warnings(warnings: List[str], current_chapter_id: str, window_size: int) -> int:
        if window_size <= 0 or not current_chapter_id:
            return len(warnings)
        cp = parse_chapter_id(current_chapter_id)
        if cp[0] <= 0:
            return len(warnings)
        count = 0
        for w in warnings:
            if not w:
                continue
            colon_idx = w.find(":")
            if colon_idx <= 0:
                count += 1
                continue
            ch_id = w[:colon_idx].strip()
            wp = parse_chapter_id(ch_id)
            if wp[0] <= 0:
                count += 1
                continue
            cmp = compare_chapter_id(ch_id, current_chapter_id)
            if cmp > 0:
                continue
            if cp[0] == wp[0]:
                if cp[1] - wp[1] < window_size:
                    count += 1
            elif cp[0] - wp[0] == 1:
                count += 1
        return count

    # ---- ExpansionConfig ----

    def get_expansion_config(self) -> Optional[dict]:
        if self._expansion_config is not None:
            return self._expansion_config
        path = os.path.join(self.project.dir, "Settings", "context_expansion_config.json")
        loaded = None
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
            except Exception as e:
                print(f"[GuideContextService] 加载扩展配置失败: {e}")
        if loaded is None:
            loaded = {"Enabled": False}
        self._expansion_config = loaded
        return loaded

    def is_key_scene(self, chapter_guide: Optional[dict]) -> bool:
        config = self.get_expansion_config()
        if not config or not config.get("Enabled"):
            return False
        scenes = chapter_guide.get("Scenes") if chapter_guide else None
        if not scenes:
            return False
        max_characters = max(len(s.get("CharacterIds", [])) for s in scenes)
        rules = config.get("Rules", {})
        if max_characters > rules.get("SceneCharactersThreshold", 0):
            return True
        trigger_keywords = rules.get("TriggerKeywords", [])
        for scene in scenes:
            purpose = scene.get("Purpose", "")
            if any(kw in purpose for kw in trigger_keywords):
                return True
        return False

    def try_expand_for_key_scene(self, context, chapter_guide: Optional[dict]):
        if not self.is_key_scene(chapter_guide) or chapter_guide is None:
            return
        config = self.get_expansion_config()
        loaded_char_ids = {c.get("Id") for c in getattr(context, "Characters", []) if c.get("Id")}
        limits = config.get("Limits", {})
        max_additional = limits.get("MaxAdditionalCharacters", 0)
        additional_char_ids = []
        for scene in chapter_guide.get("Scenes", []):
            for cid in scene.get("CharacterIds", []):
                if cid not in loaded_char_ids and cid not in additional_char_ids:
                    additional_char_ids.append(cid)
        additional_char_ids = additional_char_ids[:max_additional]
        if additional_char_ids:
            additional_chars = self.extract_characters(additional_char_ids)
            if not hasattr(context, "ExpandedCharacters"):
                context.ExpandedCharacters = []
            context.ExpandedCharacters.extend(additional_chars)
        if getattr(context, "ExpandedCharacters", []):
            context.IsKeySceneExpanded = True
            print(f"[GuideContextService] 关键场景扩展: +{len(context.ExpandedCharacters)}角色")

    # ---- RelationLoad ----

    @staticmethod
    def determine_strength(relationship_type: str) -> str:
        strong_types = ["师徒", "血亲", "宿敌", "挚友", "恋人", "主仆"]
        medium_types = ["同门", "盟友", "对手", "同伴"]
        if any(t in (relationship_type or "") for t in strong_types):
            return "Strong"
        if any(t in (relationship_type or "") for t in medium_types):
            return "Medium"
        return "Weak"

    @staticmethod
    def get_json_string(d: dict, key: str) -> str:
        v = d.get(key)
        if isinstance(v, str):
            return v
        return ""

    # ====== Cache（对标 GuideContextService.Cache.cs） ======

    @staticmethod
    def get_cached_chapter_ids(project_dir: str) -> list:
        import os, time
        cache_key = f"chapter_ids::{project_dir}"
        cache = getattr(GuideContextService, '_chapter_ids_cache', {})
        entry = cache.get(cache_key)
        if entry and time.time() - entry['ts'] < 30:
            return entry['ids']
        chapters_path = os.path.join(project_dir, "chapters")
        ids = []
        if os.path.isdir(chapters_path):
            for f in sorted(os.listdir(chapters_path)):
                if f.endswith(".md"):
                    ids.append(os.path.splitext(f)[0])
        if not hasattr(GuideContextService, '_chapter_ids_cache'):
            GuideContextService._chapter_ids_cache = {}
        GuideContextService._chapter_ids_cache[cache_key] = {'ids': ids, 'ts': time.time()}
        return ids

    # ====== Extractors（对标 GuideContextService.Extractors.cs） ======

    def extract_chapter_plan(self, chapter_id: str) -> Optional[dict]:
        self.initialize_cache()
        return self._chapter_plan_cache.get(chapter_id)

    def extract_volume_design(self, volume_id: str) -> Optional[dict]:
        self.initialize_cache()
        return self._volume_design_cache.get(volume_id)

    @staticmethod
    def try_infer_volume_design_id_from_context(context_ids) -> Optional[str]:
        if context_ids is None:
            return None
        vd = getattr(context_ids, 'VolumeDesignId', None)
        if vd:
            return vd
        vo = getattr(context_ids, 'VolumeOutline', None)
        return vo

    # ====== Helpers（对标 GuideContextService.Helpers.cs） ======

    def get_content_guide(self) -> Optional[dict]:
        if self._content_guide_cache:
            return self._content_guide_cache
        return None

    def content_guide(self) -> Optional[dict]:
        return self.get_content_guide()

    def invalidate_content_guide_cache(self):
        self._content_guide_cache = None

    @staticmethod
    def is_cache_epoch_current(epoch: int) -> bool:
        return epoch == getattr(GuideContextService, '_global_cache_epoch', 0)

    def get_chapter_summary(self, chapter_id: str) -> Optional[str]:
        if self._summary_store:
            return self._summary_store.get(chapter_id)
        return None

    def load_chapter_content(self, chapter_id: str) -> str:
        try:
            import os
            path = os.path.join(self.project.dir, "chapters", f"{chapter_id}.md")
            if os.path.exists(path):
                with open(path, 'r', encoding='utf-8') as f:
                    return f.read()
        except Exception:
            pass
        return ""

    # ====== ModuleExtractors（对标 GuideContextService.ModuleExtractors.cs） ======

    @staticmethod
    def resolve_chapter_display_title(chapter_plan: Optional[dict], chapter_number: int) -> str:
        if chapter_plan:
            title = chapter_plan.get("ChapterTitle", "") or chapter_plan.get("Name", "")
            if title:
                return title
        return f"第{chapter_number}章"

    def build_planning_context(self, chapter_id: str, context_ids) -> dict:
        self.initialize_cache()
        chars = self.extract_characters(context_ids.Characters if context_ids else [])
        locs = self.extract_locations(context_ids.Locations if context_ids else [])
        facs = self.extract_factions(context_ids.Factions if context_ids else [])
        return {"Characters": chars, "Locations": locs, "Factions": facs}

    def build_blueprint_context(self, chapter_id: str, context_ids) -> dict:
        return self.build_planning_context(chapter_id, context_ids)

    def build_content_context(self, chapter_id: str, context_ids) -> dict:
        ctx = self.build_planning_context(chapter_id, context_ids)
        ctx["PlotRules"] = self.extract_plot_rules(context_ids.PlotRules if context_ids else [])
        ctx["Templates"] = self.extract_templates(context_ids.TemplateIds if context_ids else [])
        ctx["WorldRules"] = self.extract_world_rules(context_ids.WorldRuleIds if context_ids else [])
        return ctx

    def build_full_context(self, chapter_id: str, context_ids) -> dict:
        ctx = self.build_content_context(chapter_id, context_ids)
        ctx["ChapterPlan"] = self.extract_chapter_plan(context_ids.ChapterPlanId if context_ids else "")
        ctx["VolumeDesign"] = self.extract_volume_design(
            self.try_infer_volume_design_id_from_context(context_ids) or "")
        return ctx

    def build_package_only_context(self, chapter_id: str, context_ids) -> dict:
        return self.build_planning_context(chapter_id, context_ids)

    def populate_first_description_snippets(self, snapshot, chapter_id: str):
        pass

    def load_task_layer(self, layer_name: str) -> Optional[dict]:
        try:
            import os, json
            path = os.path.join(self.project.dir, "Settings", f"task_layer_{layer_name}.json")
            if os.path.exists(path):
                with open(path, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception:
            pass
        return None

    def load_previous_chapter_summaries(self, chapter_id: str, count: int = 30) -> list:
        if self._summary_store:
            return self._summary_store.get_recent(chapter_id, count)
        return []

    @staticmethod
    def extract_sampled_summary_from_md(md_text: str, max_length: int = 500) -> str:
        if not md_text:
            return ""
        md_text = md_text.strip()
        if len(md_text) <= max_length:
            return md_text
        return md_text[:max_length] + "..."

    def load_chapter_tail(self, chapter_id: str, tail_length: int = 1000) -> str:
        content = self.load_chapter_content(chapter_id)
        if len(content) <= tail_length:
            return content
        return content[-tail_length:]

    @staticmethod
    def read_file_head(file_path: str, max_chars: int = 500) -> str:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read(max_chars)
        except Exception:
            return ""

    @staticmethod
    def read_file_tail(file_path: str, max_chars: int = 500) -> str:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            if len(content) <= max_chars:
                return content
            return content[-max_chars:]
        except Exception:
            return ""

    @staticmethod
    def has_chapter_md(project_dir: str, chapter_id: str) -> bool:
        import os
        return os.path.exists(os.path.join(project_dir, "chapters", f"{chapter_id}.md"))

    # ====== RelationLoad（对标 GuideContextService.RelationLoad.cs） ======

    def build_related_index_item(self, context_ids) -> dict:
        return {
            "Characters": context_ids.Characters if context_ids else [],
            "Locations": context_ids.Locations if context_ids else [],
            "Factions": context_ids.Factions if context_ids else [],
        }

    # ====== Risk（对标 GuideContextService.Risk.cs） ======

    def character_state_guide(self, character_id: str) -> Optional[dict]:
        self.initialize_cache()
        return self._character_cache.get(character_id)
