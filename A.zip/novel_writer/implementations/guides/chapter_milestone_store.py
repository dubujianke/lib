# -*- coding: utf-8 -*-
"""章节里程碑存储 — 对标 Implementations/Guides/ChapterMilestoneStore.cs"""
import os
import threading
from typing import Dict, List

from ...snapshot_config import DEFAULT_SNAPSHOT_CONFIG


class ChapterMilestoneStore:
    def __init__(self, project):
        self.project = project
        self._cache: Dict[int, str] = {}
        self._write_lock = threading.Lock()

    def invalidate_cache(self):
        self._cache.clear()

    @staticmethod
    def _parse_chapter_id(chapter_id: str) -> int:
        import re
        match = re.match(r"vol\d+_ch(\d+)$", chapter_id or "", re.IGNORECASE)
        return int(match.group(1)) if match else 0

    def _milestones_dir(self) -> str:
        return os.path.join(self.project.dir, "guides", "milestones")

    def _milestone_path(self, volume_number: int) -> str:
        return os.path.join(self._milestones_dir(), f"vol{volume_number}.txt")

    def _load_milestone(self, volume_number: int, max_chars: int) -> str:
        if volume_number in self._cache:
            return self._cache[volume_number]
        path = self._milestone_path(volume_number)
        if not os.path.exists(path):
            return ""
        try:
            with open(path, "r", encoding="utf-8") as f:
                text = f.read()
            if max_chars > 0 and len(text) > max_chars:
                text = text[-max_chars:]
            self._cache[volume_number] = text
            return text
        except Exception:
            return ""

    def _save_milestone(self, volume_number: int, milestone: str):
        dir_path = self._milestones_dir()
        os.makedirs(dir_path, exist_ok=True)
        path = self._milestone_path(volume_number)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(milestone)
        os.replace(tmp, path)
        self._cache[volume_number] = milestone

    def rebuild_volume_milestone(self, volume_number: int, volume_summaries: Dict[str, str]):
        if volume_number <= 0 or not volume_summaries:
            return
        milestone = self._build_milestone_text(volume_number, volume_summaries)
        with self._write_lock:
            self._save_milestone(volume_number, milestone)

    def append_chapter_milestone(self, volume_number: int, chapter_id: str, summary: str):
        if volume_number <= 0 or not summary:
            return
        max_chars = 12000
        parsed = self._parse_chapter_id(chapter_id)
        prefix = f"第{parsed}章" if parsed > 0 else chapter_id
        per_chapter_max = max(200, min(800, max_chars // 10))
        trunc = summary[:per_chapter_max] + "..." if len(summary) > per_chapter_max else summary
        new_line = f"[{prefix}] {trunc}"
        with self._write_lock:
            existing = self._load_milestone(volume_number, max_chars)
            if not existing:
                updated = f"=== 第{volume_number}卷 历史摘要 ===\n" + new_line
            else:
                updated = existing + "\n" + new_line
            self._save_milestone(volume_number, updated)

    def get_previous_milestones(self, current_volume_number: int) -> List:
        from ...models.task_contexts.volume_milestone_entry import VolumeMilestoneEntry
        max_vols = 12
        start_vol = max(1, current_volume_number - max_vols)
        result = []
        for vol in range(start_vol, current_volume_number):
            text = self._load_milestone(vol, 20000)
            if text:
                result.append(VolumeMilestoneEntry(VolumeNumber=vol, Milestone=text))
        return result

    def _build_milestone_text(self, volume_number: int, volume_summaries: Dict[str, str]) -> str:
        header = f"=== 第{volume_number}卷 历史摘要 ==="
        if not volume_summaries:
            return header
        ordered = sorted(volume_summaries.items(), key=lambda kv: kv[0])
        interval = 8
        tail_recent = 15
        selected_keys = set()
        if ordered:
            selected_keys.add(ordered[0][0])
        if len(ordered) > 1:
            selected_keys.add(ordered[-1][0])
        if tail_recent > 0:
            for kv in ordered[-tail_recent:]:
                selected_keys.add(kv[0])
        for i in range(interval, len(ordered) - 1, interval):
            selected_keys.add(ordered[i][0])
        selected = [kv for kv in ordered if kv[0] in selected_keys]
        lines = [header]
        per_chapter_max = max(200, min(800, 20000 // 10))
        for k, v in selected:
            summary = v[:per_chapter_max] + "..." if len(v) > per_chapter_max else v
            lines.append(f"[{k}] {summary}")
        merged = "\n".join(lines).strip()
        return merged[:20000] if len(merged) > 20000 else merged

    @staticmethod
    def get_total_char_count(lines) -> int:
        """对标 GetTotalCharCount: 计算多行文本总字符数"""
        return sum(len(str(line)) for line in lines)

    def get_milestones_dir(self) -> str:
        """对标 GetMilestonesDir"""
        return self._milestones_dir()

    def get_milestone_file_path(self, volume_number: int) -> str:
        """对标 GetMilestoneFilePath"""
        return self._milestone_path(volume_number)
