# -*- coding: utf-8 -*-
"""Guide 序列化上下文 — 对标 Guides/GuideSerializerContext.cs

C# 中为 System.Text.Json 源代码生成上下文（Performance 优化），
Python 中序列化已通过各 Guide 模型的 to_dict() + json.dump 实现。
本文件提供等价的序列化配置/可序列化类型清单，保证目录结构对齐。
"""
import json
from typing import Dict, Any

# 对标 [JsonSerializable] 清单：所有可序列化的 Guide 类型标识（不强制 import，避免循环依赖）
GUIDE_SERIALIZABLE_TYPES = [
    "CharacterStateGuide",
    "ConflictProgressGuide",
    "LocationStateGuide",
    "FactionStateGuide",
    "TimelineGuide",
    "ItemStateGuide",
    "ForeshadowingStatusGuide",
    "OutlineGuide",
    "PlanningGuide",
    "BlueprintGuide",
    "ContentGuide",
    "PlotPointsIndex",
]


class GuideSerializerContext:
    """对标 GuideSerializerContext（JsonPropertyNameCaseInsensitive + WriteIndented）"""

    SENSOR: bool = True
    PROPERTY_NAME_CASE_INSENSITIVE: bool = True
    WRITE_INDENTED: bool = True
    DEFAULT_INDENT: int = 2

    @classmethod
    def options(cls) -> Dict[str, Any]:
        """返回序列化选项（对标 JsonSourceGenerationOptions）"""
        return {
            "PropertyNameCaseInsensitive": cls.PROPERTY_NAME_CASE_INSENSITIVE,
            "WriteIndented": cls.WRITE_INDENTED,
            "indent": cls.DEFAULT_INDENT,
            "ensure_ascii": False,
        }

    @classmethod
    def dumps(cls, data) -> str:
        """对标 JsonSerializer.Serialize：以缩进 JSON 序列化"""
        return json.dumps(data, ensure_ascii=False, indent=cls.DEFAULT_INDENT)

    @classmethod
    def loads(cls, text: str):
        """对标 JsonSerializer.Deserialize（大小写不敏感）"""
        return json.loads(text)