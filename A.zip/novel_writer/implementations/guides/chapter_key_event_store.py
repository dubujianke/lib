# -*- coding: utf-8 -*-
"""章节关键事件存储 — 对标 Implementations/Guides/ChapterKeyEventStore.cs"""
import json
import os
import threading
from typing import List


class ChapterKeyEventStore:
    def __init__(self, project):
        self.project = project
        self._write_lock = threading.Lock()

    def _keyevents_dir(self) -> str:
        return os.path.join(self.project.dir, "guides", "keyevents")

    def _file_path(self, volume_number: int) -> str:
        return os.path.join(self._keyevents_dir(), f"vol{volume_number}.jsonl")

    def upsert(self, volume_number: int, entry):
        if volume_number <= 0 or entry is None:
            return
        with self._write_lock:
            path = self._file_path(volume_number)
            os.makedirs(self._keyevents_dir(), exist_ok=True)
            lines = []
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            e = json.loads(line)
                            if e.get("ChapterId") != entry.ChapterId:
                                lines.append(line)
                        except Exception:
                            lines.append(line)
            lines.append(json.dumps(entry.to_dict(), ensure_ascii=False))
            with open(path, "w", encoding="utf-8") as f:
                f.write("\n".join(lines) + "\n")

    def get_previous_key_events(self, current_volume_number: int,
                                max_volumes: int = 5, max_entries_per_volume: int = 30) -> List:
        from ...models.task_contexts.chapter_key_event_entry import ChapterKeyEventEntry
        if current_volume_number <= 1:
            return []
        start_vol = max(1, current_volume_number - max_volumes)
        result = []
        for vol in range(start_vol, current_volume_number):
            entries = self._load_volume(vol)
            take = entries[-max_entries_per_volume:] if len(entries) > max_entries_per_volume else entries
            result.extend(take)
        return result

    def _load_volume(self, volume_number: int) -> List:
        from ...models.task_contexts.chapter_key_event_entry import ChapterKeyEventEntry
        path = self._file_path(volume_number)
        if not os.path.exists(path):
            return []
        result = []
        try:
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        result.append(ChapterKeyEventEntry.from_dict(json.loads(line)))
                    except Exception:
                        pass
            result.sort(key=lambda e: e.ChapterNumber)
        except Exception:
            pass
        return result
