# -*- coding: utf-8 -*-
"""Guide 索引构建器 — 对标 Implementations/Guides/GuideIndexBuilder.cs（partial 5 文件）

核心：打包时构建 Design/Generate/Tracking guide 的索引 + 校验
- 生成指导: build_outline_guide / build_planning_guide / build_blueprint_guide / build_content_guide
- 追踪指导: build_character_state_guide / build_conflict_progress_guide / build_foreshadowing_status_guide
            build_location_state_guide / build_faction_state_guide / build_timeline_guide / build_plot_points_index
- 辅助: _map_names_to_ids / _match_plot_rules_by_characters / _build_reverse_index
        _parse_volume_number_from_string / _find_chapter_data
"""
import os
import re
from typing import Dict, List, Optional, Tuple

# ---- 章节ID/标题解析（对标 Framework/Common/Helpers/ChapterParserHelper.cs） ----

_VOL_CH_RE = re.compile(r"vol(\d+)_ch(\d+)", re.IGNORECASE)
_V_C_RE = re.compile(r"v(\d+)_c(\d+)", re.IGNORECASE)
_NUM_NUM_RE = re.compile(r"(\d+)_(\d+)")
_CH_SUFFIX_RE = re.compile(r"_ch(\d+)$")

_CHAPTER_TITLE_RE = re.compile(
    r"^第([一二三四五六七八九十百千万零壹贰叁肆伍陆柒捌玖拾佰仟萬两〇\d]+)(?:章节|章)([：:.]?)\s*(.*)")
_SPECIAL_CHAPTER_RE = re.compile(r"^(序章|楔子|番外|后记|尾声|引子|终章|大结局)([：:.]?\s*.*)?$")
_ENGLISH_CHAPTER_RE = re.compile(r"^Chapter\s*(\d+)", re.IGNORECASE)

_NL_VERB = (r"(?:生成|写|创作|写作|续写|重写|改写|补全|扩写|润色|仿写|改|写到|写至|写完|写完第|"
            r"完善|修改|开始写|开始生成|帮我写|帮我生成|来写|来生成)?")
_NUM_CLASS = r"[一二三四五六七八九十百千万零壹贰叁肆伍陆柒捌玖拾佰仟萬两〇\d]+"
_VOL_CHAPTER_NL_RE = re.compile(
    _NL_VERB + r"\s*第?\s*(" + _NUM_CLASS + r")\s*卷\s*第?\s*(" + _NUM_CLASS + r")\s*(?:章节|章)")
_CHAPTER_ONLY_NL_RE = re.compile(
    _NL_VERB + r"\s*第?\s*(" + _NUM_CLASS + r")\s*(?:章节|章)")
_TYPO_CHAPTER_NL_RE = re.compile(
    r"(?:生成|写|创作|写作|续写|重写|改写|补全|扩写|润色|仿写|完善|修改|开始写|开始生成|"
    r"帮我写|帮我生成|来写|来生成)\s*第?\s*(" + _NUM_CLASS + r")\s*张")
_ARABIC_RANGE_RE = re.compile(
    r"(?:从)?[第]?(\d+)\s*[-~～〜—–－−‐‑‒―﹣﹘到至]\s*[第]?(\d+)\s*(?:章节|章)")

_CHINESE_DIGITS = {
    '零': 0, '〇': 0, '一': 1, '壹': 1, '二': 2, '贰': 2, '两': 2,
    '三': 3, '叁': 3, '四': 4, '肆': 4, '五': 5, '伍': 5, '六': 6, '陆': 6,
    '七': 7, '柒': 7, '八': 8, '捌': 8, '九': 9, '玖': 9, '十': 10, '拾': 10,
    '百': 100, '佰': 100, '千': 1000, '仟': 1000, '万': 10000, '萬': 10000,
}

# 对标 SplitNames 忽略词表
_IGNORED_NAMES = {"无", "暂无", "空", "-", "/", "none", "n/a", "null"}


def _chinese_to_arabic(chinese: str) -> int:
    """对标 ChineseToArabic"""
    if not chinese:
        return 0
    try:
        return int(chinese)
    except ValueError:
        pass
    result = 0
    temp = 0
    last_unit = 1
    for ch in chinese:
        value = _CHINESE_DIGITS.get(ch)
        if value is None:
            continue
        if value >= 10:
            if temp == 0:
                temp = 1
            if value >= 10000:
                result = (result + temp) * value
                temp = 0
            elif value >= last_unit:
                result += temp * value
                temp = 0
            else:
                temp *= value
            last_unit = value
        else:
            temp = value
    return result + temp


def _parse_num_str(s: str) -> int:
    try:
        return int(s)
    except (TypeError, ValueError):
        return _chinese_to_arabic(s or "")


def parse_chapter_id(chapter_id) -> Optional[Tuple[int, int]]:
    """对标 ParseChapterId: 解析 vol{n}_ch{m} / v{n}_c{m} / {n}_{m}，失败返回 None"""
    if not chapter_id or not isinstance(chapter_id, str):
        return None
    m = _VOL_CH_RE.search(chapter_id)
    if not m:
        m = _V_C_RE.search(chapter_id)
    if not m:
        m = _NUM_NUM_RE.search(chapter_id)
    if not m:
        return None
    return (int(m.group(1)), int(m.group(2)))


def _parse_chapter_id_or_default(chapter_id) -> Tuple[int, int]:
    """对标 ParseChapterIdOrDefault"""
    return parse_chapter_id(chapter_id) or (0, 0)


def _extract_chapter_number_from_suffix(chapter_id: str) -> int:
    """对标 ExtractChapterNumberFromSuffix: '_ch{n}$' → n"""
    if not chapter_id:
        return 0
    m = _CH_SUFFIX_RE.search(chapter_id)
    return int(m.group(1)) if m else 0


def _extract_chapter_parts(title: str) -> Tuple[Optional[int], Optional[str]]:
    """对标 ExtractChapterParts: 标题 → (章号, 章名)"""
    if not title or not title.strip():
        return (None, None)
    t = title.strip()
    m = _CHAPTER_TITLE_RE.match(t)
    if m:
        num_str = m.group(1)
        chapter_num = int(num_str) if num_str[0].isdigit() else _chinese_to_arabic(num_str)
        chapter_name = (m.group(3) or "").strip()
        return (chapter_num if chapter_num > 0 else None,
                chapter_name if chapter_name else None)
    m = _SPECIAL_CHAPTER_RE.match(t)
    if m:
        special_type = m.group(1)
        special_name = (m.group(2) or "").strip()
        if special_name.startswith("：") or special_name.startswith(":") or special_name.startswith("."):
            special_name = special_name[1:].strip()
        return (None, special_type if not special_name else f"{special_type} {special_name}")
    m = _ENGLISH_CHAPTER_RE.match(t)
    if m:
        num = int(m.group(1))
        remaining = t[m.end():].strip()
        if remaining.startswith(":") or remaining.startswith("-") or remaining.startswith("."):
            remaining = remaining[1:].strip()
        return (num, remaining if remaining else None)
    return (None, None)


def _parse_chapter_range(content: str) -> Optional[Tuple[int, int]]:
    """对标 ParseChapterRange（阿拉伯数字区间）"""
    if not content:
        return None
    m = _ARABIC_RANGE_RE.search(content)
    if m:
        start, end = int(m.group(1)), int(m.group(2))
        if end < start:
            start, end = end, start
        return (start, end)
    return None


def _parse_from_natural_language(text: str) -> Tuple[Optional[int], Optional[int]]:
    """对标 ParseFromNaturalLanguage: 自然语言 → (卷号, 章号)"""
    if not text:
        return (None, None)
    if _parse_chapter_range(text) is not None:
        return (None, None)
    m = _VOL_CHAPTER_NL_RE.search(text)
    if m:
        vol = _parse_num_str(m.group(1))
        ch = _parse_num_str(m.group(2))
        return (vol if vol > 0 else None, ch if ch > 0 else None)
    m = _VOL_CH_RE.search(text)
    if m:
        return (int(m.group(1)), int(m.group(2)))
    m = _CHAPTER_ONLY_NL_RE.search(text)
    if m:
        ch = _parse_num_str(m.group(1))
        return (None, ch if ch > 0 else None)
    m = _TYPO_CHAPTER_NL_RE.search(text)
    if m:
        ch = _parse_num_str(m.group(1))
        return (None, ch if ch > 0 else None)
    return (None, None)


def _to_int(v) -> int:
    if isinstance(v, bool):
        return 0
    if isinstance(v, int):
        return v
    if isinstance(v, str):
        try:
            return int(v.strip())
        except ValueError:
            return 0
    return 0


def _as_name_list(value) -> List[str]:
    """引用名列表归一化（兼容 list/str 存储）"""
    if value is None:
        return []
    if isinstance(value, str):
        return [p.strip() for p in re.split(r"[,，、;；\n]", value) if p.strip()]
    if isinstance(value, list):
        return [str(v).strip() for v in value if v is not None and str(v).strip()]
    return []


def _split_main_characters(value) -> List[str]:
    """对标 MainCharacters 拆分（分隔符含空格）"""
    if value is None:
        return []
    if isinstance(value, list):
        return [str(v).strip() for v in value if v is not None and str(v).strip()]
    return [p.strip() for p in re.split(r"[,，、;； ]", str(value)) if p.strip()]


def _split_field_names(value) -> List[str]:
    """对标 BuildBlueprintGuideAsync.SplitNames（忽略词表 + 忽略大小写去重）"""
    if value is None:
        return []
    if isinstance(value, list):
        parts = [str(v).strip() for v in value]
    else:
        parts = [p.strip() for p in re.split(r"[,，、\n;；]", str(value))]
    out, seen = [], set()
    for p in parts:
        if not p or p.lower() in _IGNORED_NAMES:
            continue
        key = p.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(p)
    return out


def _default_rhythm() -> dict:
    return {"PaceType": "", "Intensity": "", "EmotionalTone": ""}


class GuideIndexBuilder:
    # C# relativePath → Python 实体（design/plan 存储）映射
    _ENTITY_MODULE_PATHS = {
        "outline": "Generate/GlobalSettings/Outline",
        "volumes": "Generate/Elements/VolumeDesign",
        "chapters": "Generate/Elements/Chapter",
        "blueprints": "Generate/Elements/Blueprint",
        "characters": "Design/Elements/CharacterRules",
        "factions": "Design/Elements/FactionRules",
        "locations": "Design/Elements/LocationRules",
        "plot": "Design/Elements/PlotRules",
        "materials": "Design/Templates/CreativeMaterials",
        "world": "Design/GlobalSettings/WorldRules",
    }

    def __init__(self, project, is_module_enabled=None):
        self.project = project
        self._is_module_enabled = is_module_enabled
        self._load_cache = {}

    def _load_design(self, entity: str) -> list:
        data = self.project.load_design(entity)
        if isinstance(data, dict):
            return data.get("items", [])
        return data or []

    def _load_plan(self, entity: str) -> list:
        data = self.project.load_plan(entity)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return data.get(entity, data.get("items", []))
        return []

    # ---- 数据加载（对标 LoadAllAsync: 模块开关 + IsEnabled 过滤 + 缓存） ----

    @staticmethod
    def _get_module_path_from_relative_path(relative_path: str) -> str:
        """对标 GetModulePathFromRelativePath: 取前两段"""
        if not relative_path:
            return ""
        parts = [p for p in relative_path.split("/") if p]
        return f"{parts[0]}/{parts[1]}" if len(parts) >= 2 else ""

    @staticmethod
    def _normalize_plan_items(data, entity: str) -> List[dict]:
        if isinstance(data, list):
            return [d for d in data if isinstance(d, dict)]
        if isinstance(data, dict):
            if isinstance(data.get("items"), list):
                return [d for d in data["items"] if isinstance(d, dict)]
            v = data.get(entity)
            if isinstance(v, list):
                return [d for d in v if isinstance(d, dict)]
            if "Id" in data or "Name" in data:
                return [data]
        return []

    def _load_all_blueprints(self) -> List[dict]:
        """对标 LoadAllAsync<BlueprintData>: 汇总所有 blueprints_{chapterId}"""
        entities = []
        seen = set()
        for ch in self._load_all("chapters"):
            cid = (ch.get("Id") or "").strip()
            if cid:
                name = f"blueprints_{cid}"
                if name not in seen:
                    seen.add(name)
                    entities.append(name)
        plan_dir = getattr(self.project, "plan_dir", None)
        if plan_dir and os.path.isdir(plan_dir):
            import glob as _glob
            for path in _glob.glob(os.path.join(plan_dir, "blueprints_*.json")):
                name = os.path.splitext(os.path.basename(path))[0]
                if name not in seen:
                    seen.add(name)
                    entities.append(name)
        items = []
        for name in entities:
            data = self.project.load_plan(name)
            if isinstance(data, list):
                items.extend(d for d in data if isinstance(d, dict))
        return items

    def _load_all(self, entity: str) -> List[dict]:
        """对标 LoadAllAsync<T>(relativePath)"""
        if entity in self._load_cache:
            return self._load_cache[entity]
        module_path = self._get_module_path_from_relative_path(
            self._ENTITY_MODULE_PATHS.get(entity, ""))
        items: List[dict] = []
        if not (module_path and self._is_module_enabled is not None
                and not self._is_module_enabled(module_path)):
            if entity == "blueprints":
                raw = self._load_all_blueprints()
            elif entity in ("outline", "volumes", "chapters"):
                raw = self._normalize_plan_items(self.project.load_plan(entity), entity)
            else:
                raw = self._load_design(entity)
            items = [i for i in raw if isinstance(i, dict) and i.get("IsEnabled", True)]
        self._load_cache[entity] = items
        return items

    # ---- 校验（对标 EnsureRequiredIds / EnsureRequiredCategoryIds） ----

    def ensure_required_ids(self, items, id_selector, label, name_selector=None) -> None:
        """对标 EnsureRequiredIds"""
        missing = [(name_selector(item) if name_selector else None) or "<unknown>"
                   for item in items if not (id_selector(item) or "").strip()]
        if missing:
            raise ValueError(f"打包失败：{label} 缺失Id -> {'、'.join(set(missing))}")

    def ensure_required_category_ids(self, items, category_selector, category_id_selector,
                                     label, name_selector=None) -> None:
        """对标 EnsureRequiredCategoryIds: 有 Category 无 CategoryId 才报错"""
        missing = []
        for item in items:
            category = (category_selector(item) or "").strip()
            if category and not (category_id_selector(item) or "").strip():
                missing.append((name_selector(item) if name_selector else category) or "<unknown>")
        if missing:
            seen = []
            for m in missing:
                if m not in seen:
                    seen.append(m)
            raise ValueError(f"打包失败：{label} 缺失CategoryId -> {'、'.join(seen)}")

    # ---- 既有索引（Name → Id） ----

    def build_character_index(self) -> dict:
        """构建角色索引（Name -> Id）"""
        chars = self._load_design("characters")
        return {c.get("Name", ""): c.get("Id", "") for c in chars if c.get("Id")}

    def build_location_index(self) -> dict:
        locs = self._load_design("locations")
        return {l.get("Name", ""): l.get("Id", "") for l in locs if l.get("Id")}

    def build_faction_index(self) -> dict:
        facs = self._load_design("factions")
        return {f.get("Name", ""): f.get("Id", "") for f in facs if f.get("Id")}

    def build_plot_index(self) -> dict:
        plots = self._load_design("plot")
        return {p.get("Name", ""): p.get("Id", "") for p in plots if p.get("Id")}

    def build_world_index(self) -> dict:
        worlds = self._load_design("world")
        return {w.get("Name", ""): w.get("Id", "") for w in worlds if w.get("Id")}

    def validate_plot_rules(self, plot_rules: List[dict]) -> List[str]:
        """对标 GuideIndexBuilder.PlotValidation.cs"""
        errors = []
        for p in plot_rules:
            if not p.get("Id"):
                errors.append(f"剧情规则缺失 Id: {p.get('Name', '<unknown>')}")
        return errors

    # ---- 辅助方法（对标 Helpers.cs） ----

    @staticmethod
    def _resolve_entity_ids(names, entities, name_selector, id_selector) -> List[str]:
        """对标 ResolveEntityIds: 名称→ID（ID 直通，忽略大小写）"""
        if not names:
            return []
        name_to_id: Dict[str, str] = {}
        id_set = set()
        for e in entities:
            n = (name_selector(e) or "").strip()
            i = (id_selector(e) or "").strip()
            if i:
                id_set.add(i.lower())
            if n and i and n.lower() not in name_to_id:
                name_to_id[n.lower()] = i
        out, seen = [], set()
        for n in names:
            if n is None:
                continue
            t = str(n).strip()
            if not t:
                continue
            if t.lower() in id_set:
                resolved = t
            else:
                resolved = name_to_id.get(t.lower())
            if resolved and resolved not in seen:
                seen.add(resolved)
                out.append(resolved)
        return out

    @staticmethod
    def _get_unmatched_entity_names(names, entities, name_selector, id_selector) -> List[str]:
        """对标 GetUnmatchedEntityNames: 未匹配到名称/ID 的引用名"""
        if not names:
            return []
        name_set = {(name_selector(e) or "").strip().lower() for e in entities
                    if (name_selector(e) or "").strip()}
        id_set = {(id_selector(e) or "").strip().lower() for e in entities
                  if (id_selector(e) or "").strip()}
        out, seen = [], set()
        for n in names:
            if n is None:
                continue
            t = str(n).strip()
            if not t or t.lower() in name_set or t.lower() in id_set or t.lower() in seen:
                continue
            seen.add(t.lower())
            out.append(t)
        return out

    @staticmethod
    def _map_names_to_ids(names, name_to_id, id_set) -> List[str]:
        """对标 MapNamesToIds: 名称→ID（已是 ID 则直通）

        name_to_id / id_set 均为小写键，name_to_id 值保留原始大小写。
        """
        ids = []
        for name in names or []:
            if not isinstance(name, str) or not name:
                continue
            if name.lower() in id_set:
                ids.append(name)
                continue
            mapped = name_to_id.get(name.lower())
            if mapped:
                ids.append(mapped)
        out, seen = [], set()
        for i in ids:
            if i not in seen:
                seen.add(i)
                out.append(i)
        return out

    @staticmethod
    def _get_unmatched_names(names, name_to_id, id_set) -> List[str]:
        """对标 GetUnmatchedNames"""
        unmatched = []
        for name in names or []:
            if not isinstance(name, str) or not name:
                continue
            if name.lower() not in id_set and name.lower() not in name_to_id:
                unmatched.append(name)
        out, seen = [], set()
        for n in unmatched:
            if n.lower() not in seen:
                seen.add(n.lower())
                out.append(n)
        return out

    @staticmethod
    def _match_plot_rules_by_characters(chapter_id, character_ids, all_characters,
                                        all_plot_rules, main_chars_split_cache=None) -> List[str]:
        """对标 MatchPlotRulesByCharacters: StoryPhase=章节ID 精确匹配，否则按出场角色交集"""
        if not all_plot_rules:
            return []
        char_id_set = {c.lower() for c in (character_ids or []) if isinstance(c, str) and c}
        char_name_set = {(c.get("Name") or "").strip().lower() for c in all_characters
                         if (c.get("Id") or "").lower() in char_id_set and (c.get("Name") or "").strip()}
        result = []
        for plot_rule in all_plot_rules:
            story_phase = (plot_rule.get("StoryPhase") or "").strip()
            is_chapter_id_phase = bool(story_phase) and parse_chapter_id(story_phase) is not None
            if is_chapter_id_phase:
                if story_phase == chapter_id:
                    result.append(plot_rule.get("Id"))
                continue
            if not char_id_set:
                continue
            pid = plot_rule.get("Id") or ""
            if main_chars_split_cache is not None and pid.lower() in main_chars_split_cache:
                main_chars = main_chars_split_cache[pid.lower()]
            else:
                main_chars = _split_main_characters(plot_rule.get("MainCharacters"))
            for c in main_chars:
                if c.lower() in char_id_set or c.lower() in char_name_set:
                    result.append(pid)
                    break
        out, seen = [], set()
        for pid in result:
            if pid not in seen:
                seen.add(pid)
                out.append(pid)
        return out

    @staticmethod
    def _build_reverse_index(chapters: Dict[str, dict]) -> dict:
        """对标 BuildReverseIndex: 角色/地点 → 章节ID 反查"""
        reverse_index = {"ByCharacter": {}, "ByLocation": {}}
        for chapter_id, entry in chapters.items():
            context_ids = (entry.get("ContextIds") or {}) if isinstance(entry, dict) else {}
            for char_id in context_ids.get("Characters") or []:
                reverse_index["ByCharacter"].setdefault(char_id, []).append(chapter_id)
            for loc_id in context_ids.get("Locations") or []:
                reverse_index["ByLocation"].setdefault(loc_id, []).append(chapter_id)
        return reverse_index

    @staticmethod
    def _parse_volume_number_from_string(volume) -> int:
        """对标 ParseVolumeNumberFromString: '第N卷' / 'volN...' → N，失败 -1"""
        if volume is None or not str(volume).strip():
            return -1
        v = str(volume)
        v_idx = v.find('第')
        if v_idx >= 0:
            end_idx = v.find('卷', v_idx)
            if end_idx > v_idx + 1:
                try:
                    return int(v[v_idx + 1:end_idx])
                except ValueError:
                    pass
        if v[:3].lower() == "vol":
            num_part = v[3:].lstrip('_')
            try:
                return int(num_part)
            except ValueError:
                pass
        return -1

    @staticmethod
    def _find_chapter_data(chapter_id, outline_id, chapter_by_vol_and_num, chapter_by_num):
        """对标 FindChapterData: vol{n}_ch{m} → (卷,章) 精确匹配，退回仅章号匹配"""
        if not chapter_id or "_ch" not in chapter_id:
            return None
        parts = chapter_id.split("_ch")
        vol_part = parts[0].replace("vol", "")
        ch_num_part = parts[-1] if parts else ""
        try:
            volume_number = int(vol_part)
        except ValueError:
            return None
        try:
            chapter_number = int(ch_num_part)
        except ValueError:
            return None
        if (volume_number, chapter_number) in chapter_by_vol_and_num:
            return chapter_by_vol_and_num[(volume_number, chapter_number)]
        return chapter_by_num.get(chapter_number)

    @staticmethod
    def _distinct_ids(items) -> List[str]:
        out, seen = [], set()
        for it in items:
            i = (it.get("Id") or "").strip()
            if i and i not in seen:
                seen.add(i)
                out.append(i)
        return out

    @staticmethod
    def _default_context_ids(**overrides) -> dict:
        """ContextIdCollection 全字段默认值"""
        ctx = {
            "VolumeOutline": "", "VolumeDesignId": "", "ChapterPlanId": "",
            "ChapterBlueprint": "", "BlueprintIds": [], "Characters": [],
            "Factions": [], "Locations": [], "PlotRules": [], "TemplateIds": [],
            "WorldRuleIds": [], "Conflicts": [], "ForeshadowingSetups": [],
            "ForeshadowingPayoffs": [], "PreviousChapter": "", "PreviousVolumes": [],
            "PreviousOutlines": [],
        }
        ctx.update(overrides)
        return ctx

    # ---- 生成指导（对标 GenerationGuides.cs，递增依赖） ----

    def build_outline_guide(self) -> dict:
        """对标 BuildOutlineGuideAsync: 分卷设计 → OutlineGuide

        数据源: plan/outline + design/{characters,factions,locations,plot,materials,world}
                + plan/volumes
        """
        volumes = self._load_all("outline")
        characters = self._load_all("characters")
        faction_rules = self._load_all("factions")
        location_rules = self._load_all("locations")
        plot_rules = self._load_all("plot")
        templates = self._load_all("materials")
        world_rules = self._load_all("world")
        volume_designs = self._load_all("volumes")

        for items, label in [
            (volumes, "全书大纲"), (characters, "角色规则"), (faction_rules, "势力规则"),
            (location_rules, "地点规则"), (plot_rules, "剧情规则"), (templates, "创作素材"),
            (world_rules, "世界观规则"), (volume_designs, "分卷设计"),
        ]:
            self.ensure_required_ids(items, lambda x: x.get("Id"), label, lambda x: x.get("Name"))
            self.ensure_required_category_ids(
                items, lambda x: x.get("Category"), lambda x: x.get("CategoryId"),
                label, lambda x: x.get("Name"))

        template_ids = self._distinct_ids(templates)
        world_rule_ids = self._distinct_ids(world_rules)

        # 按 UpdatedAt 倒序后按 VolumeNumber 去重取最新，再按 VolumeNumber 升序
        candidates = [v for v in volume_designs
                      if _to_int(v.get("VolumeNumber")) > 0 and (v.get("Id") or "").strip()]
        candidates.sort(key=lambda v: v.get("UpdatedAt") or "", reverse=True)
        first_by_volume = {}
        for v in candidates:
            vn = _to_int(v.get("VolumeNumber"))
            if vn not in first_by_volume:
                first_by_volume[vn] = v
        ordered_volume_designs = [first_by_volume[vn] for vn in sorted(first_by_volume)]

        volume_name_errors: List[str] = []
        volume_outline_id = ""
        if volumes:
            volume_outline_id = min(volumes, key=lambda o: o.get("CreatedAt") or "").get("Id") or ""

        guide = {"Module": "OutlineGuide", "Volumes": {}}
        for vd in ordered_volume_designs:
            vol_id = vd.get("Id") or ""
            vn = _to_int(vd.get("VolumeNumber"))
            unmatched_chars = self._get_unmatched_entity_names(
                _as_name_list(vd.get("ReferencedCharacterNames")), characters,
                lambda c: c.get("Name"), lambda c: c.get("Id"))
            unmatched_factions = self._get_unmatched_entity_names(
                _as_name_list(vd.get("ReferencedFactionNames")), faction_rules,
                lambda f: f.get("Name"), lambda f: f.get("Id"))
            unmatched_locs = self._get_unmatched_entity_names(
                _as_name_list(vd.get("ReferencedLocationNames")), location_rules,
                lambda l: l.get("Name"), lambda l: l.get("Id"))
            if unmatched_chars:
                volume_name_errors.append(f"第{vn}卷涉及角色未映射: {'、'.join(unmatched_chars)}")
            if unmatched_factions:
                volume_name_errors.append(f"第{vn}卷涉及势力未映射: {'、'.join(unmatched_factions)}")
            if unmatched_locs:
                volume_name_errors.append(f"第{vn}卷涉及地点未映射: {'、'.join(unmatched_locs)}")

            volume_title = (vd.get("VolumeTitle") or "").strip()
            guide["Volumes"][vol_id] = {
                "VolumeNumber": vn,
                "Name": volume_title if volume_title else (vd.get("Name") or ""),
                "Theme": vd.get("VolumeTheme") or "",
                "PlannedChapters": _to_int(vd.get("TargetChapterCount")),
                "ContextIds": self._default_context_ids(
                    VolumeOutline=volume_outline_id,
                    VolumeDesignId=vd.get("Id") or "",
                    Characters=self._resolve_entity_ids(
                        _as_name_list(vd.get("ReferencedCharacterNames")), characters,
                        lambda c: c.get("Name"), lambda c: c.get("Id")),
                    Factions=self._resolve_entity_ids(
                        _as_name_list(vd.get("ReferencedFactionNames")), faction_rules,
                        lambda f: f.get("Name"), lambda f: f.get("Id")),
                    Locations=self._resolve_entity_ids(
                        _as_name_list(vd.get("ReferencedLocationNames")), location_rules,
                        lambda l: l.get("Name"), lambda l: l.get("Id")),
                    TemplateIds=list(template_ids),
                    WorldRuleIds=list(world_rule_ids),
                ),
                "OutputIds": {"KeyEvents": [], "ForeshadowingSetup": []},
            }

        if volume_name_errors:
            raise ValueError(
                "分卷设计存在未映射到设计元素的引用名称，打包阻断：\n"
                + "\n".join(volume_name_errors))
        return guide

    def build_planning_guide(self, outline_guide: dict) -> dict:
        """对标 BuildPlanningGuideAsync: 章节规划 → PlanningGuide

        数据源: plan/chapters（Volume 字段按 '第N卷' 前缀分卷）
        """
        chapters = self._load_all("chapters")
        self.ensure_required_ids(chapters, lambda c: c.get("Id"), "章节规划", lambda c: c.get("Name"))
        self.ensure_required_category_ids(
            chapters, lambda c: c.get("Category"), lambda c: c.get("CategoryId"),
            "章节规划", lambda c: c.get("Name"))

        guide = {"Module": "PlanningGuide", "Volumes": {}}
        for vol_id, volume_entry in (outline_guide.get("Volumes") or {}).items():
            volume_number = _to_int(volume_entry.get("VolumeNumber"))
            volume_prefix = f"第{volume_number}卷"
            volume_chapters = [
                c for c in chapters
                if isinstance(c.get("Volume"), str) and c["Volume"]
                and (c["Volume"] == volume_prefix or c["Volume"].startswith(volume_prefix + " "))
            ]
            vol_ctx = volume_entry.get("ContextIds") or {}
            planning_volume = {
                "VolumeNumber": volume_number,
                "ContextIds": self._default_context_ids(
                    VolumeOutline=vol_ctx.get("VolumeOutline") or "",
                    VolumeDesignId=vol_ctx.get("VolumeDesignId") or "",
                    Characters=list(vol_ctx.get("Characters") or []),
                    Factions=list(vol_ctx.get("Factions") or []),
                    Locations=list(vol_ctx.get("Locations") or []),
                    PlotRules=list(vol_ctx.get("PlotRules") or []),
                    TemplateIds=list(vol_ctx.get("TemplateIds") or []),
                    WorldRuleIds=list(vol_ctx.get("WorldRuleIds") or []),
                ),
                "Chapters": {},
            }
            for chapter in sorted(volume_chapters, key=lambda c: _to_int(c.get("ChapterNumber"))):
                cn = _to_int(chapter.get("ChapterNumber"))
                chapter_id = f"vol{volume_number}_ch{cn}"
                title = chapter.get("ChapterTitle") or f"第{cn}章"
                planning_volume["Chapters"][chapter_id] = {
                    "ChapterPlanId": chapter.get("Id") or "",
                    "ChapterNumber": cn,
                    "Title": title,
                    "Synopsis": chapter.get("MainGoal") or "",
                    "Rhythm": _default_rhythm(),
                    "PlotAllocations": [],
                }
            guide["Volumes"][vol_id] = planning_volume
        return guide

    def build_blueprint_guide(self, planning_guide: dict) -> dict:
        """对标 BuildBlueprintGuideAsync: 蓝图 → BlueprintGuide

        数据源: plan/blueprints_{chapterId} + plan/chapters
                + design/{characters,locations,factions,plot}
        """
        guide = {"Module": "BlueprintGuide", "Chapters": {},
                 "ReverseIndex": {"ByCharacter": {}, "ByLocation": {}}}
        package_warnings: List[dict] = []

        blueprints = self._load_all("blueprints")
        chapter_plans = self._load_all("chapters")
        characters = self._load_all("characters")
        location_rules = self._load_all("locations")
        faction_rules = self._load_all("factions")
        plot_rules = self._load_all("plot")

        chapter_plan_by_id = {}
        for c in chapter_plans:
            cid = (c.get("Id") or "").strip()
            if cid:
                chapter_plan_by_id[cid.lower()] = c

        self.ensure_required_ids(blueprints, lambda b: b.get("Id"), "章节蓝图", lambda b: b.get("Name"))
        self.ensure_required_category_ids(
            blueprints, lambda b: b.get("Category"), lambda b: b.get("CategoryId"),
            "章节蓝图", lambda b: b.get("Name"))
        self.ensure_required_ids(plot_rules, lambda p: p.get("Id"), "剧情规则", lambda p: p.get("Name"))
        self.ensure_required_category_ids(
            plot_rules, lambda p: p.get("Category"), lambda p: p.get("CategoryId"),
            "剧情规则", lambda p: p.get("Name"))

        # 蓝图 ChapterId 必须可解析为 vol{n}_ch{m}
        bad_chapter_id_blueprints = []
        for b in blueprints:
            bcid = b.get("ChapterId") or ""
            if not bcid.strip() or parse_chapter_id(bcid) is None:
                label = b.get("Name") or b.get("Id") or ""
                entry = f"{label}（关联章节ID为空）" if not bcid.strip() else f"{label}（{bcid}）"
                if entry not in bad_chapter_id_blueprints:
                    bad_chapter_id_blueprints.append(entry)
        if bad_chapter_id_blueprints:
            raise ValueError(
                f"蓝图存在 {len(bad_chapter_id_blueprints)} 条\"关联章节ID\"格式错误"
                f"（期望 vol{{卷号}}_ch{{章号}}，如 vol1_ch3）："
                f"{'、'.join(bad_chapter_id_blueprints[:5])}"
                f"。请在蓝图设计中修正\"关联章节ID\"字段后重新打包。")

        planning_volumes = planning_guide.get("Volumes") or {}
        chapter_info_map: Dict[str, dict] = {}
        for vol_id, volume_entry in planning_volumes.items():
            for chapter_id, chapter_entry in (volume_entry.get("Chapters") or {}).items():
                chapter_info_map[chapter_id] = {
                    "Title": chapter_entry.get("Title") or "",
                    "Synopsis": chapter_entry.get("Synopsis") or "",
                    "VolumeId": vol_id,
                    "Rhythm": chapter_entry.get("Rhythm"),
                    "ChapterPlanId": chapter_entry.get("ChapterPlanId") or "",
                }
        default_info = {"Title": "", "Synopsis": "", "VolumeId": "",
                        "Rhythm": None, "ChapterPlanId": ""}

        volume_context_map = {vol_id: (ve.get("ContextIds") or {})
                              for vol_id, ve in planning_volumes.items()}
        volume_key_by_number = {}
        for vol_id, ve in planning_volumes.items():
            vn = _to_int(ve.get("VolumeNumber"))
            if vn > 0 and vn not in volume_key_by_number:
                volume_key_by_number[vn] = vol_id

        chapter_ids: List[str] = []
        seen_chapter_ids = set()
        for b in blueprints:
            cid = b.get("ChapterId") or ""
            if cid.lower() not in seen_chapter_ids:
                seen_chapter_ids.add(cid.lower())
                chapter_ids.append(cid)
        chapter_ids.sort(key=_parse_chapter_id_or_default)

        blueprints_by_chapter: Dict[str, List[dict]] = {}
        for b in blueprints:
            blueprints_by_chapter.setdefault((b.get("ChapterId") or "").lower(), []).append(b)

        def _build_name_maps(entities):
            name_to_id, id_set = {}, set()
            for e in entities:
                n = (e.get("Name") or "").strip()
                i = (e.get("Id") or "").strip()
                if i:
                    id_set.add(i.lower())
                if n and i and n.lower() not in name_to_id:
                    name_to_id[n.lower()] = i
            return name_to_id, id_set

        character_name_to_id, character_id_set = _build_name_maps(characters)
        location_name_to_id, location_id_set = _build_name_maps(location_rules)
        faction_name_to_id, faction_id_set = _build_name_maps(faction_rules)

        plot_main_chars_split = {}
        for p in plot_rules:
            pid = (p.get("Id") or "").lower()
            if pid and pid not in plot_main_chars_split:
                plot_main_chars_split[pid] = _split_main_characters(p.get("MainCharacters"))

        previous_chapter_id = None
        for chapter_id in chapter_ids:
            info = chapter_info_map.get(chapter_id, default_info)
            chapter_blueprints = blueprints_by_chapter.get(chapter_id.lower(), [])

            parsed = _parse_chapter_id_or_default(chapter_id)
            volume_number = parsed[0]
            volume_key = (info["VolumeId"] if info["VolumeId"].strip()
                          else volume_key_by_number.get(volume_number, ""))

            blueprint_ids: List[str] = []
            for b in chapter_blueprints:
                bid = (b.get("Id") or "").strip()
                if bid and bid not in blueprint_ids:
                    blueprint_ids.append(bid)

            volume_context_ids = volume_context_map.get(volume_key) or {}
            template_ids = list(volume_context_ids.get("TemplateIds") or [])
            world_rule_ids = list(volume_context_ids.get("WorldRuleIds") or [])

            chapter_plan = None
            if info["ChapterPlanId"].strip():
                chapter_plan = chapter_plan_by_id.get(info["ChapterPlanId"].lower())

            def _collect(field, name_to_id, id_set, plan_ref_field):
                # 汇总蓝图字段名称（忽略大小写去重），映射失败回退章节规划引用名
                names = []
                for b in chapter_blueprints:
                    for n in _split_field_names(b.get(field)):
                        if n not in names:
                            names.append(n)
                ids = self._map_names_to_ids(names, name_to_id, id_set)
                unmatched = self._get_unmatched_names(names, name_to_id, id_set)
                if not ids and chapter_plan:
                    refs = _as_name_list(chapter_plan.get(plan_ref_field))
                    ids = self._map_names_to_ids(refs, name_to_id, id_set)
                    for n in self._get_unmatched_names(refs, name_to_id, id_set):
                        if n not in unmatched:
                            unmatched.append(n)
                return ids, unmatched

            character_ids, unmatched_characters = _collect(
                "Cast", character_name_to_id, character_id_set, "ReferencedCharacterNames")
            location_ids, unmatched_locations = _collect(
                "Locations", location_name_to_id, location_id_set, "ReferencedLocationNames")
            faction_ids, unmatched_factions = _collect(
                "Factions", faction_name_to_id, faction_id_set, "ReferencedFactionNames")

            if unmatched_characters:
                package_warnings.append({
                    "Level": "Error", "Source": f"蓝图章节: {chapter_id}",
                    "Message": f"出场角色名称未映射为ID: {'、'.join(unmatched_characters)}"})
            if unmatched_locations:
                package_warnings.append({
                    "Level": "Error", "Source": f"蓝图章节: {chapter_id}",
                    "Message": f"涉及地点名称未映射为ID: {'、'.join(unmatched_locations)}"})
            if unmatched_factions:
                package_warnings.append({
                    "Level": "Error", "Source": f"蓝图章节: {chapter_id}",
                    "Message": f"涉及势力名称未映射为ID: {'、'.join(unmatched_factions)}"})

            scenes = []
            for b in chapter_blueprints:
                scenes.append({
                    "SceneId": b.get("Id") or "",
                    "SceneNumber": _to_int(b.get("SceneNumber")),
                    "Purpose": b.get("OneLineStructure") or "",
                    "Title": b.get("SceneTitle") or "",
                    "PovCharacter": b.get("PovCharacter") or "",
                    "Opening": b.get("Opening") or "",
                    "Development": b.get("Development") or "",
                    "Turning": b.get("Turning") or "",
                    "Ending": b.get("Ending") or "",
                    "InfoDrop": b.get("InfoDrop") or "",
                    "CharacterIds": self._map_names_to_ids(
                        _split_field_names(b.get("Cast")), character_name_to_id, character_id_set),
                    "LocationId": (self._map_names_to_ids(
                        _split_field_names(b.get("Locations")),
                        location_name_to_id, location_id_set) or [""])[0],
                })

            guide["Chapters"][chapter_id] = {
                "ChapterId": chapter_id,
                "Title": info["Title"],
                "ChapterGoal": info["Synopsis"],
                "ContextIds": self._default_context_ids(
                    VolumeOutline=volume_context_ids.get("VolumeOutline") or "",
                    VolumeDesignId=volume_context_ids.get("VolumeDesignId") or "",
                    ChapterPlanId=info["ChapterPlanId"],
                    ChapterBlueprint=chapter_id,
                    BlueprintIds=blueprint_ids,
                    Characters=character_ids,
                    Locations=location_ids,
                    Factions=faction_ids,
                    PlotRules=self._match_plot_rules_by_characters(
                        chapter_id, character_ids, characters, plot_rules,
                        plot_main_chars_split),
                    TemplateIds=template_ids,
                    WorldRuleIds=world_rule_ids,
                    PreviousChapter=previous_chapter_id or "",
                ),
                "Rhythm": info["Rhythm"] if isinstance(info["Rhythm"], dict) else _default_rhythm(),
                "Scenes": scenes,
            }

            previous_chapter_id = chapter_id

        guide["ReverseIndex"] = self._build_reverse_index(guide["Chapters"])

        error_warnings = [w for w in package_warnings
                          if (w.get("Level") or "").lower() == "error"]
        if error_warnings:
            summary = " | ".join(f"{w['Source']}: {w['Message']}" for w in error_warnings)
            raise ValueError(f"蓝图名称未映射为ID，打包失败：{summary}")
        return guide

    def build_content_guide(self, blueprint_guide: dict) -> dict:
        """对标 BuildContentGuideAsync: 蓝图指导 → ContentGuide

        数据源: design/plot + design/characters + plan/chapters（回填章号/卷/规划字段）
        """
        guide = {"Module": "ContentGuide", "Chapters": {}, "ChapterSummaries": {}}

        plot_rules = self._load_all("plot")
        characters = self._load_all("characters")
        chapters = self._load_all("chapters")

        self.ensure_required_ids(plot_rules, lambda p: p.get("Id"), "剧情规则", lambda p: p.get("Name"))
        self.ensure_required_category_ids(
            plot_rules, lambda p: p.get("Category"), lambda p: p.get("CategoryId"),
            "剧情规则", lambda p: p.get("Name"))
        self.ensure_required_ids(characters, lambda c: c.get("Id"), "角色规则", lambda c: c.get("Name"))
        self.ensure_required_category_ids(
            characters, lambda c: c.get("Category"), lambda c: c.get("CategoryId"),
            "角色规则", lambda c: c.get("Name"))
        self.ensure_required_ids(chapters, lambda c: c.get("Id"), "章节规划", lambda c: c.get("Name"))
        self.ensure_required_category_ids(
            chapters, lambda c: c.get("Category"), lambda c: c.get("CategoryId"),
            "章节规划", lambda c: c.get("Name"))

        blueprint_chapters = blueprint_guide.get("Chapters") or {}

        content_plot_main_chars_split = {}
        for p in plot_rules:
            pid = (p.get("Id") or "").lower()
            if pid and pid not in content_plot_main_chars_split:
                content_plot_main_chars_split[pid] = _split_main_characters(p.get("MainCharacters"))

        chapter_by_vol_and_num: Dict[Tuple[int, int], dict] = {}
        chapter_by_num: Dict[int, dict] = {}
        for ch in chapters:
            cn = _to_int(ch.get("ChapterNumber"))
            if cn <= 0:
                continue
            vn = self._parse_volume_number_from_string(ch.get("Volume"))
            if vn > 0 and (vn, cn) not in chapter_by_vol_and_num:
                chapter_by_vol_and_num[(vn, cn)] = ch
            if cn not in chapter_by_num:
                chapter_by_num[cn] = ch

        sorted_chapters = sorted(
            blueprint_chapters.items(), key=lambda kv: _parse_chapter_id_or_default(kv[0]))

        for chapter_id, blueprint in sorted_chapters:
            blueprint_context_ids = blueprint.get("ContextIds") or {}

            chapter_plot_rules = list(blueprint_context_ids.get("PlotRules") or [])

            chapter_character_ids = list(blueprint_context_ids.get("Characters") or [])
            chapter_character_id_set = {c.lower() for c in chapter_character_ids if c}
            chapter_character_name_set = {
                (c.get("Name") or "").strip().lower() for c in characters
                if (c.get("Id") or "").lower() in chapter_character_id_set and (c.get("Name") or "").strip()}

            related_plot_rule_ids = set()
            for p in plot_rules:
                sp = (p.get("StoryPhase") or "").strip()
                is_chapter_id_phase = bool(sp) and parse_chapter_id(sp) is not None
                if is_chapter_id_phase:
                    if sp == chapter_id:
                        related_plot_rule_ids.add(p.get("Id"))
                    continue
                main_chars = content_plot_main_chars_split.get((p.get("Id") or "").lower())
                if main_chars is None:
                    main_chars = _split_main_characters(p.get("MainCharacters"))
                for c in main_chars:
                    cl = c.lower()
                    if cl in chapter_character_id_set or cl in chapter_character_name_set:
                        related_plot_rule_ids.add(p.get("Id"))
                        break

            def _related(pid):
                return pid in related_plot_rule_ids

            chapter_conflicts = [p.get("Id") for p in plot_rules
                                 if (p.get("Conflict") or "").strip() and _related(p.get("Id"))]
            chapter_foreshadowing_setups = [p.get("Id") for p in plot_rules
                                            if _related(p.get("Id")) and not (p.get("Result") or "").strip()]
            chapter_foreshadowing_payoffs = [p.get("Id") for p in plot_rules
                                             if (p.get("Result") or "").strip() and _related(p.get("Id"))]

            chapter_data = self._find_chapter_data(
                chapter_id, blueprint_context_ids.get("VolumeOutline"),
                chapter_by_vol_and_num, chapter_by_num)

            # 章号回退链: 章节规划 → 章节ID解析 → '_ch{n}' 后缀 → 蓝图标题
            chapter_number = _to_int(chapter_data.get("ChapterNumber")) if chapter_data else 0
            if chapter_number <= 0:
                parsed = parse_chapter_id(chapter_id)
                if parsed and parsed[1] > 0:
                    chapter_number = parsed[1]
            if chapter_number <= 0:
                chapter_number = _extract_chapter_number_from_suffix(chapter_id)
            if chapter_number <= 0 and (blueprint.get("Title") or "").strip():
                number, _ = _extract_chapter_parts(blueprint.get("Title"))
                if number and number > 0:
                    chapter_number = number
                else:
                    _, from_title = _parse_from_natural_language(blueprint.get("Title"))
                    if from_title and from_title > 0:
                        chapter_number = from_title

            chapter_title = (blueprint.get("Title") if (blueprint.get("Title") or "").strip()
                             else ((chapter_data or {}).get("ChapterTitle") or ""))

            guide["Chapters"][chapter_id] = {
                "ChapterId": chapter_id,
                "Title": chapter_title,
                "Summary": blueprint.get("ChapterGoal") or "",
                "ContextIds": self._default_context_ids(
                    VolumeOutline=blueprint_context_ids.get("VolumeOutline") or "",
                    VolumeDesignId=blueprint_context_ids.get("VolumeDesignId") or "",
                    ChapterPlanId=blueprint_context_ids.get("ChapterPlanId") or "",
                    ChapterBlueprint=chapter_id,
                    BlueprintIds=list(blueprint_context_ids.get("BlueprintIds") or []),
                    Characters=list(blueprint_context_ids.get("Characters") or []),
                    Locations=list(blueprint_context_ids.get("Locations") or []),
                    Factions=list(blueprint_context_ids.get("Factions") or []),
                    PlotRules=chapter_plot_rules,
                    TemplateIds=list(blueprint_context_ids.get("TemplateIds") or []),
                    WorldRuleIds=list(blueprint_context_ids.get("WorldRuleIds") or []),
                    Conflicts=chapter_conflicts,
                    ForeshadowingSetups=chapter_foreshadowing_setups,
                    ForeshadowingPayoffs=chapter_foreshadowing_payoffs,
                    PreviousChapter=blueprint_context_ids.get("PreviousChapter") or "",
                ),
                "Rhythm": blueprint.get("Rhythm") if isinstance(blueprint.get("Rhythm"), dict)
                          else _default_rhythm(),
                "Scenes": list(blueprint.get("Scenes") or []),
                "ChapterNumber": chapter_number,
                "Volume": (chapter_data or {}).get("Volume") or "",
                "ChapterTheme": (chapter_data or {}).get("ChapterTheme") or "",
                "MainGoal": (chapter_data or {}).get("MainGoal") or "",
                "KeyTurn": (chapter_data or {}).get("KeyTurn") or "",
                "Hook": (chapter_data or {}).get("Hook") or "",
                "WorldInfoDrop": (chapter_data or {}).get("WorldInfoDrop") or "",
                "CharacterArcProgress": (chapter_data or {}).get("CharacterArcProgress") or "",
                "Foreshadowing": (chapter_data or {}).get("Foreshadowing") or "",
            }
        return guide

    # ---- 追踪指导（对标 TrackingGuides.cs） ----

    def build_character_state_guide(self) -> dict:
        """对标 BuildCharacterStateGuideAsync: 角色规则 → CharacterStateGuide 初始状态

        数据源: design/characters
        """
        guide = {"Module": "CharacterStateGuide", "Characters": {}}
        profiles = self._load_all("characters")
        self.ensure_required_ids(profiles, lambda p: p.get("Id"), "角色规则", lambda p: p.get("Name"))
        self.ensure_required_category_ids(
            profiles, lambda p: p.get("Category"), lambda p: p.get("CategoryId"),
            "角色规则", lambda p: p.get("Name"))
        for profile in profiles:
            flaw = (profile.get("FlawBelief") or "").strip()
            guide["Characters"][profile.get("Id") or ""] = {
                "Name": profile.get("Name") or "",
                "BaseProfile": profile.get("Id") or "",
                "StateHistory": [{
                    "Chapter": "init",
                    "Phase": "起",
                    "Level": "初始",
                    "Abilities": [],
                    "Relationships": {},
                    "MentalState": flaw if flaw else "普通",
                    "KeyEvent": "故事开始",
                }],
                "DriftWarnings": [],
            }
        return guide

    def build_conflict_progress_guide(self) -> dict:
        """对标 BuildConflictProgressGuideAsync: 有 Conflict 的剧情规则 → 冲突追踪

        数据源: design/plot
        """
        guide = {"Module": "ConflictProgressGuide", "Conflicts": {}}
        plot_rules = self._load_all("plot")
        self.ensure_required_ids(plot_rules, lambda p: p.get("Id"), "剧情规则", lambda p: p.get("Name"))
        self.ensure_required_category_ids(
            plot_rules, lambda p: p.get("Category"), lambda p: p.get("CategoryId"),
            "剧情规则", lambda p: p.get("Name"))
        for plot_rule in plot_rules:
            if not (plot_rule.get("Conflict") or "").strip():
                continue
            event_type = plot_rule.get("EventType") or ""
            guide["Conflicts"][plot_rule.get("Id") or ""] = {
                "Name": plot_rule.get("Name") or "",
                "Type": event_type if event_type else "剧情事件",
                "Tier": "Tier-3",
                "Status": "pending",
                "ProgressPoints": [],
                "InvolvedChapters": [],
                "InvolvedCharacters": _split_main_characters(plot_rule.get("MainCharacters")),
                "DriftWarnings": [],
            }
        return guide

    def build_plot_points_index(self) -> dict:
        """对标 BuildPlotPointsIndexAsync: 关键情节索引（空结构，后续由追踪服务填充）"""
        return {
            "Module": "PlotPointsIndex",
            "PlotPoints": [],
            "Keywords": {},
            "ChapterIndex": {},
        }

    def build_foreshadowing_status_guide(self) -> dict:
        """对标 BuildForeshadowingStatusGuideAsync: 剧情规则 → 伏笔完成度追踪

        数据源: design/plot（StoryPhase=章节ID 时作为 ExpectedSetupChapter）
        """
        guide = {
            "Module": "ForeshadowingStatusGuide",
            "Summary": {"Total": 0, "Setup": 0, "Payoff": 0, "Pending": 0, "CompletionRate": "0%"},
            "ByTier": {},
            "PendingList": [],
            "OverdueList": [],
            "Foreshadowings": {},
        }
        plot_rules = self._load_all("plot")
        self.ensure_required_ids(plot_rules, lambda p: p.get("Id"), "剧情规则", lambda p: p.get("Name"))
        self.ensure_required_category_ids(
            plot_rules, lambda p: p.get("Category"), lambda p: p.get("CategoryId"),
            "剧情规则", lambda p: p.get("Name"))

        total = len(plot_rules)
        setup = sum(1 for p in plot_rules if (p.get("StoryPhase") or "").strip())
        resolved = sum(1 for p in plot_rules if (p.get("Result") or "").strip())

        for plot_rule in plot_rules:
            sp = (plot_rule.get("StoryPhase") or "").strip()
            expected_setup_chapter = ""
            if sp and parse_chapter_id(sp) is not None:
                expected_setup_chapter = sp
            guide["Foreshadowings"][plot_rule.get("Id") or ""] = {
                "Name": plot_rule.get("Name") or "",
                "Tier": "Tier-3",
                "IsSetup": bool(sp),
                "IsResolved": bool((plot_rule.get("Result") or "").strip()),
                "IsOverdue": False,
                "ExpectedSetupChapter": expected_setup_chapter,
                "ExpectedPayoffChapter": "",
                "ActualSetupChapter": "",
                "ActualPayoffChapter": "",
                "DriftWarnings": [],
            }

        guide["Summary"] = {
            "Total": total,
            "Setup": setup,
            "Payoff": resolved,
            "Pending": total - resolved,
            "CompletionRate": f"{(resolved * 100.0 / total):.1f}%" if total > 0 else "0%",
        }
        return guide

    def build_location_state_guide(self) -> dict:
        """对标 BuildLocationStateGuideAsync: 地点规则 → 地点状态追踪

        数据源: design/locations
        """
        guide = {"Module": "LocationStateGuide", "Locations": {}}
        locations = self._load_all("locations")
        self.ensure_required_ids(locations, lambda l: l.get("Id"), "地点", lambda l: l.get("Name"))
        for loc in locations:
            guide["Locations"][loc.get("Id") or ""] = {
                "Name": loc.get("Name") or "",
                "CurrentStatus": "normal",
                "StateHistory": [],
                "DriftWarnings": [],
            }
        return guide

    def build_faction_state_guide(self) -> dict:
        """对标 BuildFactionStateGuideAsync: 势力规则 → 势力状态追踪

        数据源: design/factions
        """
        guide = {"Module": "FactionStateGuide", "Factions": {}}
        factions = self._load_all("factions")
        self.ensure_required_ids(factions, lambda f: f.get("Id"), "势力", lambda f: f.get("Name"))
        for faction in factions:
            guide["Factions"][faction.get("Id") or ""] = {
                "Name": faction.get("Name") or "",
                "CurrentStatus": "active",
                "StateHistory": [],
                "DriftWarnings": [],
            }
        return guide

    def build_timeline_guide(self) -> dict:
        """对标 BuildTimelineGuideAsync: 时间线追踪（空结构，后续由追踪服务填充）"""
        return {
            "Module": "TimelineGuide",
            "ChapterTimeline": [],
            "CharacterLocations": {},
        }
