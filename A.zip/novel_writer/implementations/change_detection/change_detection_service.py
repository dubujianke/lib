# -*- coding: utf-8 -*-
"""变更检测服务 — 对标 Implementations/ChangeDetection/ChangeDetectionService.cs"""
import json
import os
import threading
from typing import List, Optional

from ...models.change_detection.change_status import ChangeStatus, ChangeStatusType
from ..packaging_allowlist import PackagingAllowlist


class ChangeDetectionService:
    def __init__(self, project):
        self.project = project
        self._status_cache = {}
        self._cache_lock = threading.Lock()
        self._last_package_time: Optional[str] = None
        self._load_manifest_info()

    def has_changes(self, module_path: str) -> bool:
        status = self.get_status(module_path)
        return status.Status in (ChangeStatusType.CHANGED, ChangeStatusType.NEVER)

    def get_changed_modules(self) -> List[str]:
        return [s.ModulePath for s in self.get_all_statuses()
                if s.Status in (ChangeStatusType.CHANGED, ChangeStatusType.NEVER)]

    def refresh_all(self):
        """对标 RefreshAllAsync: 清空缓存、重载 manifest，并并发刷新所有模块状态"""
        with self._cache_lock:
            self._status_cache.clear()
        self._load_manifest_info()
        modules = self._get_all_modules()
        for m in modules:
            self._refresh_module_status(m)

    def get_design_statuses(self) -> List[ChangeStatus]:
        """对标 GetDesignStatuses"""
        return [s for s in self.get_all_statuses() if s.ModulePath.startswith("Design/")]

    def get_generate_statuses(self) -> List[ChangeStatus]:
        """对标 GetGenerateStatuses"""
        return [s for s in self.get_all_statuses() if s.ModulePath.startswith("Generate/")]

    def get_validate_statuses(self) -> List[ChangeStatus]:
        """对标 GetValidateStatuses"""
        return [s for s in self.get_all_statuses() if s.ModulePath.startswith("Validate/")]

    def mark_module_enabled(self, module_path: str, is_enabled: bool):
        """对标 MarkModuleEnabled"""
        with self._cache_lock:
            if module_path in self._status_cache:
                self._status_cache[module_path].IsEnabled = is_enabled

    def _count_data_items(self, json_files: List[str]) -> int:
        """对标 CountDataItemsAsync: 统计各个 json 内数组元素总数"""
        total = 0
        for f in json_files:
            fn = os.path.basename(f)
            if fn.lower() in ("categories.json", "built_in_categories.json"):
                continue
            try:
                with open(f, "r", encoding="utf-8") as fh:
                    doc = json.load(fh)
                if isinstance(doc, list):
                    total += len(doc)
            except Exception:
                pass
        return total

    def get_status(self, module_path: str) -> ChangeStatus:
        with self._cache_lock:
            if module_path in self._status_cache:
                return self._status_cache[module_path]
        module = self._find_module(module_path)
        if module:
            self._refresh_module_status(module)
        with self._cache_lock:
            return self._status_cache.get(module_path, ChangeStatus(
                ModulePath=module_path, Status=ChangeStatusType.CHANGED, IsEnabled=True))

    def get_all_statuses(self) -> List[ChangeStatus]:
        modules = self._get_all_modules()
        with self._cache_lock:
            cached_keys = set(self._status_cache.keys())
        for m in modules:
            if m[0] not in cached_keys:
                self._refresh_module_status(m)
        with self._cache_lock:
            return list(self._status_cache.values())

    def mark_as_packaged(self, module_path: str):
        with self._cache_lock:
            if module_path in self._status_cache:
                self._status_cache[module_path].LastPackaged = self._now()
                self._status_cache[module_path].Status = ChangeStatusType.LATEST

    def mark_all_as_packaged(self):
        now = self._now()
        with self._cache_lock:
            for status in self._status_cache.values():
                status.LastPackaged = now
                status.Status = ChangeStatusType.LATEST
        self._last_package_time = now

    # ---- 私有 ----

    def _get_all_modules(self):
        modules = []
        for module_type, allowlist in PackagingAllowlist.SubModules.items():
            # 简化为 Design/Generate 两大模块
            for sub in allowlist:
                modules.append((f"{module_type}/{sub}", sub, f"{module_type}/{sub}"))
        return modules

    def _find_module(self, module_path: str):
        for m in self._get_all_modules():
            if m[0] == module_path:
                return m
        return None

    def _refresh_module_status(self, module):
        """对标 RefreshModuleStatusAsync: 递归扫描模块目录 json，统计条目数与最后修改时间"""
        module_path, display_name, storage_path = module
        with self._cache_lock:
            prev = self._status_cache.get(module_path)
            existing_enabled = prev.IsEnabled if prev else True
        status = ChangeStatus(ModulePath=module_path, DisplayName=display_name, IsEnabled=existing_enabled)
        module_dir = os.path.join(self.project.dir, storage_path)
        if os.path.isdir(module_dir):
            json_files = []
            for root, _dirs, files in os.walk(module_dir):
                for fn in files:
                    if fn.endswith(".json"):
                        json_files.append(os.path.join(root, fn))
            if json_files:
                latest = max(os.path.getmtime(f) for f in json_files)
                status.LastModified = self._ts_to_str(latest)
                status.ItemCount = self._count_data_items(json_files)
            status.LastPackaged = self._last_package_time
            if self._last_package_time is None:
                status.Status = ChangeStatusType.NEVER
            elif status.LastModified and status.LastModified > self._last_package_time:
                status.Status = ChangeStatusType.CHANGED
            else:
                status.Status = ChangeStatusType.LATEST
        else:
            status.Status = ChangeStatusType.NEVER
            status.ItemCount = 0
        with self._cache_lock:
            self._status_cache[module_path] = status

    def _load_manifest_info(self):
        try:
            manifest_path = os.path.join(self.project.dir, "manifest.json")
            if os.path.exists(manifest_path):
                with open(manifest_path, "r", encoding="utf-8") as f:
                    doc = json.load(f)
                self._last_package_time = doc.get("publishTime") or doc.get("PublishTime")
            else:
                # 对标 C#: manifest 不存在 → 从未打包，复位为 None
                self._last_package_time = None
        except Exception:
            self._last_package_time = None

    @staticmethod
    def _now() -> str:
        import time
        return time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())

    @staticmethod
    def _ts_to_str(ts: float) -> str:
        import time
        return time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(ts))
