# -*- coding: utf-8 -*-
"""打包白名单 — 对标 Implementations/PackagingAllowlist.cs"""

SUB_MODULES = {
    "Design": {"全局设定", "设计元素"},
    "Generate": {"全书设定", "创作元素"},
}


class PackagingAllowlist:
    SubModules = SUB_MODULES
