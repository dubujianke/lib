# -*- coding: utf-8 -*-
"""兼容 shim：转发到 .implementations.validation.content_description_validator"""
from .implementations.validation.content_description_validator import *
