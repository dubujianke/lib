# -*- coding: utf-8 -*-
"""统一校验：对标 4.1.1 UnifiedValidationService — 门禁校验 + AI 校验 + 抽样 + 结果聚合"""
import json, os, re, math
from typing import Dict, List, Optional

from .models import FactSnapshot
from .snapshot_extractor import SnapshotExtractor
from .gate import GenerationGate


class UnifiedValidation:
    def __init__(self, project, ai_service=None):
        self.project = project
        self.gate = GenerationGate()
        self.ai = ai_service

    def validate_all(self) -> dict:
        """全书级体检：设计引用 + 卷章关系 + 章节门禁 + 跨章一致性 + AI 校验"""
        report = {"errors": [], "warnings": [], "chapter_results": [],
                  "total": 0, "passed": 0, "failed": [], "consistency_issues": []}

        self._check_design_references(report)
        self._check_hierarchy(report)
        self._check_chapters(report)
        self._check_cross_chapter(report)

        if self.ai:
            self._ai_validation(report)

        report["total"] = len(report["chapter_results"])
        report["passed"] = sum(1 for r in report["chapter_results"] if r.get("success"))
        report["failed"] = [r for r in report["chapter_results"] if not r.get("success")]
        report["consistency_issues"] = report.get("warnings", [])
        
        # 对标 AggregateToVolumeSummary: 聚合卷结果
        report["volume_summary"] = self._aggregate_results(report)
        return report

    def _aggregate_results(self, report: dict) -> dict:
        """对标 AggregateToVolumeSummary: 聚合章节结果到卷摘要"""
        summary = {}
        chapters = self._load_plan("chapters")
        volumes = self._load_plan("volumes")
        
        # 构建卷标题→卷号映射
        vol_title_to_num = {}
        for v in volumes:
            vn = v.get("VolumeNumber", 0)
            vt = v.get("VolumeTitle", "")
            summary[vn] = {"total": 0, "passed": 0, "word_count": 0, "errors": []}
            if vt:
                vol_title_to_num[vt] = vn

        for ch in chapters:
            vol_title = ch.get("Volume", "")
            vn = vol_title_to_num.get(vol_title, 1)
            if vn not in summary:
                summary[vn] = {"total": 0, "passed": 0, "word_count": 0, "errors": []}
            
            res = next((r for r in report["chapter_results"] if r["chapter"] == ch.get("ChapterNumber")), None)
            summary[vn]["total"] += 1
            if res and res.get("success"):
                summary[vn]["passed"] += 1
                summary[vn]["word_count"] += res.get("word_count", 0)
            elif res:
                for f in res.get("failures", []):
                    summary[vn]["errors"].append(f"第{res['chapter']}章: {f.get('Type', '')}")
                    
        return summary

    def _get_vol_num(self, ch: dict) -> int:
        """从章节信息推断卷号"""
        return 1 # 简化实现，实际应根据 VolumeTitle 匹配 volumes 配置

    # ====== 抽样（对标 SampleChapters） ======
    def _sample_chapters(self, chapters: list) -> list:
        """对标 SampleChapters: 均匀抽样，首尾必含，ceil(total/5)，3~50之间"""
        n = len(chapters)
        if n <= 3:
            return chapters
        sample_count = max(3, min(50, math.ceil(n / 5)))
        if sample_count >= n:
            return chapters
        step = max(1, (n - 1) / (sample_count - 1))
        indices = {0, n - 1}
        for i in range(1, sample_count - 1):
            indices.add(min(n - 1, round(i * step)))
        return [chapters[i] for i in sorted(indices)]

    # ====== AI 校验（对标 ExecuteValidationsAsync） ======
    def _ai_validation(self, report: dict):
        """AI 校验：抽样章节，AI 分析内容质量"""
        chapters = self._load_plan("chapters")
        if not chapters:
            return
        sampled = self._sample_chapters(chapters)
        for ch in sampled:
            cn = ch.get("ChapterNumber", 0)
            cid = ch.get("Id", "")
            content = self.project.load_chapter(cid)
            if not content or len(content) < 100:
                continue
            try:
                result = self._ai_validate_chapter(ch, content)
                if result.get("issues"):
                    for issue in result["issues"]:
                        report["warnings"].append(f"第{cn}章 AI校验: {issue}")
            except Exception:
                pass

    def _ai_validate_chapter(self, chapter: dict, content: str) -> dict:
        """单章 AI 校验：构建校验提示词，解析结果"""
        if not self.ai:
            return {"issues": []}
        prompt = self._build_validation_prompt(chapter, content)
        try:
            resp = self.ai.chat("", prompt, category="validate")
            return self._parse_ai_validation(resp)
        except Exception:
            return {"issues": []}

    def _build_validation_prompt(self, chapter: dict, content: str) -> str:
        """对标 BuildValidationPromptAsync"""
        cn = chapter.get("ChapterNumber", 0)
        title = chapter.get("ChapterTitle", "")
        goal = chapter.get("MainGoal", "")
        turn = chapter.get("KeyTurn", "")
        hook = chapter.get("Hook", "")
        chars = chapter.get("ReferencedCharacterNames", [])
        if isinstance(chars, str):
            chars = [c.strip() for c in re.split(r"[、，,\n]", chars) if c.strip()]
        return f"""请校验以下第{cn}章《{title}》的内容质量，以 JSON 格式返回。

<chapter_info>
章节号: {cn}
标题: {title}
目标: {goal}
关键转折: {turn}
章末钩子: {hook}
出场角色: {'、'.join(chars[:10]) if chars else '（无）'}
</chapter_info>

<content>
{content[:2000]}
</content>

请检查以下方面，用 JSON 输出（仅 JSON，不要其他文字）：
{{
  "issues": [
    {{"severity": "warning", "description": "问题描述"}}
  ],
  "score": 0-100,
  "summary": "一句话评价"
}}
如果无问题，issues 返回空数组。"""

    @staticmethod
    def _parse_ai_validation(resp: str) -> dict:
        """对标 ParseAIValidationResult"""
        from .ai_service import extract_json
        data = extract_json(resp)
        if isinstance(data, dict):
            return data
        return {"issues": []}

    # ====== 原有校验方法 ======
    def _load_plan(self, entity: str) -> list:
        data = self.project.load_plan(entity)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return data.get(entity, data.get("items", []))
        return []

    def _load_design(self, entity: str) -> list:
        data = self.project.load_design(entity)
        if isinstance(data, dict):
            return data.get("items", [])
        return data or []

    def _check_design_references(self, report):
        chars = self._load_design("characters")
        facs = self._load_design("factions")
        locs = self._load_design("locations")
        ch_names = {c.get("Name", "") for c in chars if c.get("Name")}
        f_names = {f.get("Name", "") for f in facs if f.get("Name")}
        l_names = {l.get("Name", "") for l in locs if l.get("Name")}

        volumes = self._load_plan("volumes")
        for v in volumes:
            vn = v.get("VolumeNumber", 0)
            label = f"第{vn}卷"
            for ref_names, ref_type, ref_label in [
                (v.get("ReferencedCharacterNames", []), ch_names, "出场角色"),
                (v.get("ReferencedFactionNames", []), f_names, "涉及势力"),
                (v.get("ReferencedLocationNames", []), l_names, "涉及地点"),
            ]:
                names = self._split(ref_names)
                unmatched = [n for n in names if n and n not in ref_type]
                if unmatched:
                    report["errors"].append(f"{label}「{ref_label}」未在设计库中存在: {'、'.join(unmatched[:5])}")

        chapters = self._load_plan("chapters")
        for ch in chapters:
            cn = ch.get("ChapterNumber", 0)
            label = f"第{cn}章"
            for ref_names, ref_type, ref_label in [
                (ch.get("ReferencedCharacterNames", []), ch_names, "出场角色"),
                (ch.get("ReferencedFactionNames", []), f_names, "涉及势力"),
                (ch.get("ReferencedLocationNames", []), l_names, "涉及地点"),
            ]:
                names = self._split(ref_names)
                unmatched = [n for n in names if n and n not in ref_type]
                if unmatched:
                    report["warnings"].append(f"{label}「{ref_label}」未在设计库中存在: {'、'.join(unmatched[:5])}")

    def _check_hierarchy(self, report):
        volumes = self._load_plan("volumes")
        chapters = self._load_plan("chapters")
        if not volumes or not chapters:
            return
        for ch in chapters:
            vol = ch.get("Volume", "")
            cn = ch.get("ChapterNumber", 0)
            if not vol:
                report["errors"].append(f"第{cn}章「所属卷」为空")

    def _check_chapters(self, report):
        chapters = self._load_plan("chapters")
        for ch in chapters:
            cn = ch.get("ChapterNumber", 0)
            cid = ch.get("Id", "")
            content_raw = self.project.load_chapter(cid)
            if not content_raw:
                report["warnings"].append(f"第{cn}章：未生成")
                continue
            content = content_raw if isinstance(content_raw, str) else content_raw.get("content", "")
            if not content:
                report["warnings"].append(f"第{cn}章：空内容")
                continue
            extractor = SnapshotExtractor(self.project)
            snapshot = extractor.extract(cid, cn)
            design_names = {
                "角色": self._split(ch.get("ReferencedCharacterNames", [])),
                "势力": self._split(ch.get("ReferencedFactionNames", [])),
                "地点": self._split(ch.get("ReferencedLocationNames", [])),
            }
            result = self.gate.validate(content, snapshot, design_names, {}, cid)
            if not result.Success:
                errs = "; ".join(e for f in result.Failures for e in f.Errors)
                report["errors"].append(f"第{cn}章门禁失败: {errs[:200]}")
            report["chapter_results"].append({
                "chapter": cn, "success": result.Success,
                "word_count": len(content.replace("\n", "").replace(" ", "")),
                "failures": [f.to_dict() for f in result.Failures] if not result.Success else [],
            })

    def _check_cross_chapter(self, report):
        chapters = self._load_plan("chapters")
        if len(chapters) < 2:
            return
        for i in range(len(chapters) - 1):
            c1 = chapters[i]
            c2 = chapters[i + 1]
            c1_num = c1.get("ChapterNumber", 0)
            c2_num = c2.get("ChapterNumber", 0)
            if c2_num != c1_num + 1:
                report["warnings"].append(f"章节序号不连续: 第{c1_num}章→第{c2_num}章")

    @staticmethod
    def _split(val) -> List[str]:
        if not val:
            return []
        if isinstance(val, list):
            return [str(n).strip() for n in val if n and str(n).strip()]
        if isinstance(val, str):
            return [n.strip() for n in re.split(r"[、，,\n]", val) if n.strip()]
        return []

    def check_consistency(self) -> List[dict]:
        """跨章节一致性隐患（兼容旧接口）"""
        issues = []
        chapters = self._load_plan("chapters")
        if len(chapters) < 2:
            return issues
        for i in range(len(chapters) - 1):
            c1 = chapters[i]
            c2 = chapters[i + 1]
            c1_num = c1.get("ChapterNumber", 0)
            c2_num = c2.get("ChapterNumber", 0)
            if c2_num != c1_num + 1:
                issues.append({"chapter": f"第{c1_num}章→第{c2_num}章", "expected": "连续章节号"})
        return issues