# -*- coding: utf-8 -*-
"""兼容 shim：转发到 .implementations.tracking.secret_reveal_service"""
from .implementations.tracking.secret_reveal_service import *
