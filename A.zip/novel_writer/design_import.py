import re
from copy import deepcopy


def split_names(value):
    if isinstance(value, list):
        return value
    if not isinstance(value, str):
        return []
    return [name.strip() for name in re.split(r"[、,，/；;]+", value) if name.strip()]


def map_name(value, name_to_id):
    if isinstance(value, list):
        return [name_to_id.get(name, name) for name in value]
    if isinstance(value, str):
        names = split_names(value)
        if len(names) > 1:
            return [name_to_id.get(name, name) for name in names]
        return name_to_id.get(value.strip(), value)
    return value


def map_design_references(items):
    result = deepcopy(items)
    character_ids = {item.get("Name"): item.get("Id") for item in result.get("characters", []) if item.get("Name") and item.get("Id")}
    faction_ids = {item.get("Name"): item.get("Id") for item in result.get("factions", []) if item.get("Name") and item.get("Id")}
    location_ids = {item.get("Name"): item.get("Id") for item in result.get("locations", []) if item.get("Name") and item.get("Id")}
    for item in result.get("characters", []):
        item["TargetCharacterName"] = map_name(item.get("TargetCharacterName", ""), character_ids)
        relationships = item.get("Relationships")
        if isinstance(relationships, dict):
            item["Relationships"] = {character_ids.get(name, name): value for name, value in relationships.items()}
    for item in result.get("factions", []):
        item["Leader"] = map_name(item.get("Leader", ""), character_ids)
        for field in ("CoreMembers", "Allies", "Enemies", "NeutralCompetitors"):
            item[field] = map_name(item.get(field, []), {**character_ids, **faction_ids})
    for item in result.get("locations", []):
        item["FactionId"] = map_name(item.get("FactionId", ""), faction_ids)
    for item in result.get("plot", []):
        item["MainCharacters"] = map_name(item.get("MainCharacters", []), character_ids)
        item["KeyNpcs"] = map_name(item.get("KeyNpcs", []), character_ids)
        item["Location"] = map_name(item.get("Location", ""), location_ids)
    return result
