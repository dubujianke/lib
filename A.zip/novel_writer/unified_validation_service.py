# -*- coding: utf-8 -*-
"""兼容 shim：转发到 .implementations.validation.unified_validation_service"""
from .implementations.validation.unified_validation_service import *
