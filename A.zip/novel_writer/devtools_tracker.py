# -*- coding: utf-8 -*-
"""AI SDK DevTools 兼容追踪器 — 生成 .devtools/generations.json

对标 @ai-sdk/devtools 的数据格式，让 Python 的 AI 调用也能用
http://localhost:4983 可视化查看。
"""
import json
import os
import time
import threading
import uuid


class DevToolsTracker:
    """记录 AI 调用到 generations.json（兼容 AI SDK DevTools）"""

    def __init__(self, base_dir: str):
        self.db_dir = os.path.join(base_dir, ".devtools")
        self.db_path = os.path.join(self.db_dir, "generations.json")
        self._lock = threading.Lock()
        self._ensure_dir()

    def _ensure_dir(self):
        os.makedirs(self.db_dir, exist_ok=True)
        if not os.path.exists(self.db_path):
            self._write_db({"runs": [], "steps": []})

    def _read_db(self) -> dict:
        try:
            with open(self.db_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {"runs": [], "steps": []}

    def _write_db(self, db: dict):
        with open(self.db_path, "w", encoding="utf-8") as f:
            json.dump(db, f, ensure_ascii=False, indent=2)
        self._notify_viewer()

    def _notify_viewer(self):
        """通知 DevTools viewer 刷新缓存（对标 notifyServer POST /api/notify）"""
        port = os.environ.get("AI_SDK_DEVTOOLS_PORT", "4983")
        try:
            import urllib.request
            req = urllib.request.Request(
                f"http://localhost:{port}/api/notify",
                data=json.dumps({"event": "update", "timestamp": int(time.time() * 1000)}).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            urllib.request.urlopen(req, timeout=2)
        except Exception:
            pass  # viewer 未运行则静默跳过

    def start_run(self, provider: str = "python") -> str:
        run_id = str(uuid.uuid4())
        with self._lock:
            db = self._read_db()
            db["runs"].append({
                "id": run_id,
                "started_at": time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime()),
                "provider": provider,
            })
            self._write_db(db)
        return run_id

    def add_step(self, run_id: str, step_number: int, *,
                 model_id: str, provider: str,
                 messages: list, tools: list = None,
                 temperature: float = None, max_output_tokens: int = None,
                 output_text: str = "", finish_reason: str = "stop",
                 tool_calls: list = None,
                 input_tokens: int = None, output_tokens: int = None,
                 raw_request: dict = None, raw_response: dict = None,
                 error: str = None, duration_ms: float = 0.0,
                 is_stream: bool = False):
        """写入一个 step（对标 AI SDK generation step）"""
        with self._lock:
            db = self._read_db()

            # 构建 input（含 prompt 消息数组）
            prompt = []
            for msg in messages:
                role = msg.get("role", "user")
                content = msg.get("content", "")
                prompt.append({"role": role, "content": content})
            input_obj = {"prompt": prompt}
            if tools:
                input_obj["tools"] = tools
            if temperature is not None:
                input_obj["temperature"] = temperature
            if max_output_tokens is not None:
                input_obj["maxOutputTokens"] = max_output_tokens

            # 构建 output
            output_obj = {
                "finishReason": {"unified": finish_reason},
                "textParts": [{"type": "text", "text": output_text}] if output_text else [],
            }
            if tool_calls:
                output_obj["toolCalls"] = tool_calls

            # 构建 usage
            usage_obj = {}
            if input_tokens is not None or output_tokens is not None:
                usage_obj = {
                    "inputTokens": {"total": input_tokens or 0},
                    "outputTokens": {"total": output_tokens or 0},
                }

            step = {
                "run_id": run_id,
                "step_number": step_number,
                "type": "stream" if is_stream else "core",
                "input": json.dumps(input_obj, ensure_ascii=False),
                "output": json.dumps(output_obj, ensure_ascii=False),
                "usage": json.dumps(usage_obj, ensure_ascii=False) if usage_obj else None,
                "model_id": model_id,
                "provider": provider,
                "duration_ms": duration_ms,
                "error": error,
            }
            if raw_request is not None:
                step["raw_request"] = json.dumps(raw_request, ensure_ascii=False)
            if raw_response is not None:
                step["raw_response"] = json.dumps(raw_response, ensure_ascii=False)

            db["steps"].append(step)
            self._write_db(db)

    def complete_run(self, run_id: str):
        """可选：运行结束时标记（viewer 通过 duration_ms=null 判断 in-progress）"""
        pass
