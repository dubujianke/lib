import json
from pathlib import Path

from novel_writer.book_pipeline_v4_test_helpers import build_dependency_context, build_tagged_chapter, normalize_book_info, required_analysis_files


def test_book_info_primary_then_fallback():
    assert normalize_book_info({"title": "主书"}, {"title": "备用"})["title"] == "主书"
    assert normalize_book_info({}, {"title": "备用"})["title"] == "备用"
    assert normalize_book_info(None, None) == {}


def test_chapter_context_contains_number_title_and_source_label():
    result = build_tagged_chapter(3, "收徒", "黄金章", "章节内容")
    assert result.startswith("### 第3章 收徒 [黄金章]")
    assert "章节内容" in result


def test_required_analysis_files_include_refined_characters_and_locations(tmp_path: Path):
    for name in ["essence_chapters.json", "analysis.json", "refined_worldrules.json", "refined_characters.json", "refined_factions.json", "refined_plotrules.json"]:
        (tmp_path / name).write_text("{}", encoding="utf-8")
    missing = required_analysis_files(tmp_path)
    assert missing == ["refined_locations.json"]


def test_refinery_dependency_context_uses_previous_entities(tmp_path: Path):
    (tmp_path / "refined_characters.json").write_text(json.dumps([{"Name": "舒南"}], ensure_ascii=False), encoding="utf-8")
    context = build_dependency_context(tmp_path, [("characters", "角色规则")])
    assert "角色规则已提炼实体" in context
    assert "舒南" in context


def test_refinery_dependency_context_ignores_missing_dependencies(tmp_path: Path):
    assert build_dependency_context(tmp_path, [("characters", "角色规则")]) == ""
