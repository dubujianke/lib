# -*- coding: utf-8 -*-
"""卷号映射 — 对标 ChapterParserHelper / VolumeDesignService

提供章号 → 卷号 的映射（从 plan/volumes 读取 StartChapter/EndChapter），
供 CharacterStateService 构造 vol{卷号}_ch{章号} ID。
"""


def build_volume_chapter_map(project) -> dict:
    """构建 {章号: 卷号} 映射。对标 C# 用 VolumeFileName 按卷归档，此处单文件存储。"""
    volume_map = {}
    try:
        volumes = project.load_plan("volumes")
        if isinstance(volumes, dict):
            volumes = volumes.get("volumes", [])
        for vol in volumes or []:
            if not isinstance(vol, dict):
                continue
            vn = vol.get("VolumeNumber", 0)
            start = int(vol.get("StartChapter", 0) or 0)
            end = int(vol.get("EndChapter", 0) or 0)
            if vn and start and end:
                for ch in range(start, end + 1):
                    volume_map[ch] = vn
    except Exception:
        pass
    return volume_map


def chapter_id_for(volume_map: dict, chapter_number: int, volume_number: int = 0) -> str:
    """构造 vol{卷号}_ch{章号}。优先用显式 volume_number，否则从映射查。"""
    vn = volume_number or volume_map.get(chapter_number, 1)
    return f"vol{vn}_ch{chapter_number}"