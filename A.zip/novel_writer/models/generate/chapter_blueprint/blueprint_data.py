# -*- coding: utf-8 -*-
"""章节蓝图 — 对标 Generate/ChapterBlueprint/BlueprintData.cs"""
from dataclasses import dataclass, field
from typing import Dict, Optional
from ...common import BusinessDataBase


@dataclass
class BlueprintData(BusinessDataBase):
    ChapterId: str = ""
    ChapterNumber: int = 0
    OneLineStructure: str = ""
    PacingCurve: str = ""
    SceneNumber: int = 0
    SceneTitle: str = ""
    PovCharacter: str = ""
    Opening: str = ""
    Development: str = ""
    Turning: str = ""
    Ending: str = ""
    InfoDrop: str = ""
    Cast: str = ""
    Locations: str = ""
    Factions: str = ""
    ItemsClues: str = ""
    DependencyModuleVersions: Dict[str, int] = field(default_factory=dict)
