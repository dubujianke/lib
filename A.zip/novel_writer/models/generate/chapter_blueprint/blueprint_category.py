# -*- coding: utf-8 -*-
"""蓝图分类"""
from dataclasses import dataclass
from typing import Optional
from ...common import JsonModel


@dataclass
class BlueprintCategory(JsonModel):
    Id: str = ""
    Name: str = ""
    Icon: str = "Icon.Clapper"
    ParentCategory: Optional[str] = None
    Level: int = 1
    Order: int = 0
    IsBuiltIn: bool = False
    IsEnabled: bool = True
