# -*- coding: utf-8 -*-
"""章节分类"""
from dataclasses import dataclass
from typing import Optional
from ...common import JsonModel


@dataclass
class ChapterCategory(JsonModel):
    Id: str = ""
    Name: str = ""
    Icon: str = "Icon.Document"
    ParentCategory: Optional[str] = None
    Level: int = 1
    Order: int = 0
    IsBuiltIn: bool = False
    IsEnabled: bool = True
