# -*- coding: utf-8 -*-
"""章节规划 — 对标 Generate/ChapterPlanning/ChapterData.cs"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from ...common import BusinessDataBase


@dataclass
class ChapterData(BusinessDataBase):
    ChapterNumber: int = 0
    VolumeNumber: int = 0
    ChapterTitle: str = ""
    Volume: str = ""
    ChapterTheme: str = ""
    ReaderExperienceGoal: str = ""
    MainGoal: str = ""
    ResistanceSource: str = ""
    KeyTurn: str = ""
    Hook: str = ""
    WorldInfoDrop: str = ""
    CharacterArcProgress: str = ""
    MainPlotProgress: str = ""
    Foreshadowing: str = ""
    ReferencedCharacterNames: List[str] = field(default_factory=list)
    ReferencedFactionNames: List[str] = field(default_factory=list)
    ReferencedLocationNames: List[str] = field(default_factory=list)
    DependencyModuleVersions: Dict[str, int] = field(default_factory=dict)
