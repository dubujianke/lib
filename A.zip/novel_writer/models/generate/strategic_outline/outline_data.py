# -*- coding: utf-8 -*-
"""大纲 — 对标 Generate/StrategicOutline/OutlineData.cs"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from ...common import BusinessDataBase


@dataclass
class OutlineData(BusinessDataBase):
    TotalChapterCount: int = 0
    OneLineOutline: str = ""
    EmotionalTone: str = ""
    PhilosophicalMotif: str = ""
    Theme: str = ""
    CoreConflict: str = ""
    EndingState: str = ""
    VolumeDivision: str = ""
    OutlineOverview: str = ""
    DependencyModuleVersions: Dict[str, int] = field(default_factory=dict)

    @property
    def Description(self) -> str:
        return self.OneLineOutline

    def GetDeepSummary(self) -> str:
        return f"{self.OneLineOutline}; 冲突: {self.CoreConflict}; 主题: {self.Theme}"

    def GetCoreSummary(self) -> str:
        return self.OneLineOutline or self.CoreConflict or self.Name

    def GetImportanceWeight(self) -> int:
        if self.OneLineOutline and self.CoreConflict and self.Theme and self.Name and self.OutlineOverview:
            return 80
        if self.OneLineOutline and self.CoreConflict:
            return 60
        return 40
