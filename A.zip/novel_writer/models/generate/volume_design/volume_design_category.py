# -*- coding: utf-8 -*-
"""分卷设计分类"""
from dataclasses import dataclass
from typing import Optional
from ...common import JsonModel


@dataclass
class VolumeDesignCategory(JsonModel):
    Id: str = ""
    Name: str = ""
    Icon: str = "Icon.Books"
    ParentCategory: Optional[str] = None
    Level: int = 1
    Order: int = 0
    IsBuiltIn: bool = False
    IsEnabled: bool = True
