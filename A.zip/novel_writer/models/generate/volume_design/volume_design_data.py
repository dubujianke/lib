# -*- coding: utf-8 -*-
"""分卷设计 — 对标 Generate/VolumeDesign/VolumeDesignData.cs"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from ...common import BusinessDataBase


@dataclass
class VolumeDesignData(BusinessDataBase):
    VolumeNumber: int = 0
    VolumeTitle: str = ""
    VolumeTheme: str = ""
    StageGoal: str = ""
    TargetChapterCount: int = 0
    StartChapter: int = 0
    EndChapter: int = 0
    MainConflict: str = ""
    PressureSource: str = ""
    KeyEvents: List[str] = field(default_factory=list)
    OpeningState: str = ""
    EndingState: str = ""
    ReferencedCharacterNames: List[str] = field(default_factory=list)
    ReferencedFactionNames: List[str] = field(default_factory=list)
    ReferencedLocationNames: List[str] = field(default_factory=list)
    ChapterAllocationOverview: str = ""
    PlotAllocation: str = ""
    ChapterGenerationHints: str = ""
    DependencyModuleVersions: Dict[str, int] = field(default_factory=dict)
