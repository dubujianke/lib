# -*- coding: utf-8 -*-
"""章节树条目 — 对标 Generate/Content/ChapterTreeItem.cs"""
from dataclasses import dataclass, field
from typing import List
from ...common import JsonModel


@dataclass
class ChapterTreeItem(JsonModel):
    ChapterId: str = ""
    Title: str = ""
    Icon: str = "Icon.Document"

    @property
    def display_name(self) -> str:
        return self.Title or self.ChapterId


@dataclass
class VolumeTreeItem(JsonModel):
    VolumeNumber: int = 0
    Name: str = ""
    Icon: str = "Icon.Books"
    IsExpanded: bool = False
    Chapters: List[ChapterTreeItem] = field(default_factory=list)
