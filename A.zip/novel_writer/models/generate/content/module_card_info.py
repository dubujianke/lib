# -*- coding: utf-8 -*-
"""模块卡片信息 — 对标 Generate/Content/ModuleCardInfo.cs"""
from dataclasses import dataclass
from ...common import JsonModel


@dataclass
class ModuleCardInfo(JsonModel):
    ModulePath: str = ""
    ModuleType: str = ""
    SubModuleName: str = ""
    DisplayName: str = ""
    Icon: str = "Icon.Folder"
    ItemCountText: str = "0项"
    IsEnabled: bool = False
    StatusText: str = "未处理"
    HasChanges: bool = False
