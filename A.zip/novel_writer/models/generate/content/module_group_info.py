# -*- coding: utf-8 -*-
"""模块分组信息 — 对标 Generate/Content/ModuleGroupInfo.cs"""
from dataclasses import dataclass, field
from typing import List
from ...common import JsonModel
from .module_card_info import ModuleCardInfo


@dataclass
class ModuleGroupInfo(JsonModel):
    ModuleType: str = ""
    DisplayName: str = ""
    Icon: str = "Icon.Clipboard"
    Cards: List[ModuleCardInfo] = field(default_factory=list)

    @property
    def enabled_count_text(self) -> str:
        enabled = sum(1 for c in self.Cards if c.IsEnabled)
        return f"{enabled}/{len(self.Cards)}"
