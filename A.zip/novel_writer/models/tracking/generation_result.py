# -*- coding: utf-8 -*-
"""生成结果 — 对标 Tracking/GenerationResult.cs"""
from dataclasses import dataclass, field
from typing import List, Optional
from ..common import JsonModel


@dataclass
class GenerationAttempt(JsonModel):
    AttemptNumber: int = 0
    Success: bool = False
    Message: str = ""
    FailureReasons: List[str] = field(default_factory=list)

    @property
    def is_rewrite(self) -> bool:
        return self.AttemptNumber > 0


@dataclass
class GenerationResult(JsonModel):
    ChapterId: str = ""
    CorrelationId: str = ""
    PromptTokenEstimate: int = 0
    ContextBuildMs: int = 0
    AiCallMs: int = 0
    Success: bool = False
    Content: Optional[str] = None
    ParsedChanges: Optional[object] = None
    GateResult: Optional[object] = None
    DesignElements: Optional[object] = None
    RequiresManualIntervention: bool = False
    InterventionHint: str = ""
    ErrorMessage: str = ""
    Attempts: List[GenerationAttempt] = field(default_factory=list)

    @property
    def total_attempts(self) -> int:
        return len(self.Attempts)

    @property
    def rewrite_count(self) -> int:
        return len(self.Attempts) - 1 if self.Attempts else 0

    def add_attempt(self, attempt_number: int, success: bool, message: str, failure_reasons: List[str] = None):
        self.Attempts.append(GenerationAttempt(
            AttemptNumber=attempt_number, Success=success, Message=message,
            FailureReasons=failure_reasons or []))

    def get_last_failure_reasons(self) -> List[str]:
        if not self.Attempts:
            return []
        return self.Attempts[-1].FailureReasons
