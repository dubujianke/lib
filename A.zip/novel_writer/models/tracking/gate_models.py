# -*- coding: utf-8 -*-
"""门禁模型 — 对标 Tracking/GateModels.cs"""
from dataclasses import dataclass, field
from typing import List, Optional
from ..common import JsonModel
from .consistency.consistency_issue import ConsistencyIssue


class FailureType:
    PROTOCOL = "Protocol"
    CONSISTENCY = "Consistency"


@dataclass
class GateFailure(JsonModel):
    Type: str = ""
    Errors: List[str] = field(default_factory=list)
    ConsistencyIssues: List[ConsistencyIssue] = field(default_factory=list)


@dataclass
class DesignElementNames(JsonModel):
    CharacterNames: List[str] = field(default_factory=list)
    FactionNames: List[str] = field(default_factory=list)
    LocationNames: List[str] = field(default_factory=list)
    PlotKeyNames: List[str] = field(default_factory=list)
    PovCharacterNames: List[str] = field(default_factory=list)


@dataclass
class GateResult(JsonModel):
    ChapterId: str = ""
    Success: bool = True
    Failures: List[GateFailure] = field(default_factory=list)
    ParsedChanges: Optional[object] = None
    ContentWithoutChanges: Optional[str] = None

    def add_failure(self, ftype: str, errors):
        self.Failures.append(GateFailure(Type=ftype, Errors=list(errors)))

    def add_consistency_failure(self, issues: List[ConsistencyIssue]):
        self.Failures.append(GateFailure(
            Type=FailureType.CONSISTENCY,
            Errors=[str(i) for i in issues],
            ConsistencyIssues=issues))

    def get_all_failures(self) -> List[str]:
        return [f"[{f.Type}] {e}" for f in self.Failures for e in f.Errors]
