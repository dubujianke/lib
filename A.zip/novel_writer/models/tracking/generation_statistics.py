# -*- coding: utf-8 -*-
"""生成统计 — 对标 Tracking/GenerationStatistics.cs"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional
from ..common import JsonModel, now_str


@dataclass
class ConsistencyIssueStatistics(JsonModel):
    CharacterStateConflict: int = 0
    ForeshadowingEarlyPayoff: int = 0
    ForeshadowingRollback: int = 0
    ConflictStatusSkip: int = 0
    CharacterNotInvolved: int = 0


@dataclass
class GenerationStatistics(JsonModel):
    StartTime: str = ""
    EndTime: str = ""
    TotalGenerations: int = 0
    FirstPassCount: int = 0
    RewritePassCount: int = 0
    FinalFailureCount: int = 0
    ProtocolFailureCount: int = 0
    RuleFailureCount: int = 0
    ConsistencyFailureCount: int = 0
    RewriteDistribution: Dict[int, int] = field(default_factory=dict)
    ConsistencyIssues: ConsistencyIssueStatistics = field(default_factory=ConsistencyIssueStatistics)

    @property
    def first_pass_rate(self) -> float:
        return self.FirstPassCount / self.TotalGenerations * 100 if self.TotalGenerations > 0 else 0

    @property
    def final_pass_rate(self) -> float:
        return (self.FirstPassCount + self.RewritePassCount) / self.TotalGenerations * 100 if self.TotalGenerations > 0 else 0


@dataclass
class AttemptRecord(JsonModel):
    AttemptNumber: int = 0
    Success: bool = False
    FailureType: Optional[str] = None
    FailureReasons: List[str] = field(default_factory=list)
    Timestamp: str = ""


@dataclass
class GenerationRecord(JsonModel):
    Id: str = ""
    ChapterId: str = ""
    Timestamp: str = ""
    Success: bool = False
    TotalAttempts: int = 0
    RewriteCount: int = 0
    RequiresManualIntervention: bool = False
    FailureStages: List[str] = field(default_factory=list)
    FailureReasons: List[str] = field(default_factory=list)
    Attempts: List[AttemptRecord] = field(default_factory=list)
