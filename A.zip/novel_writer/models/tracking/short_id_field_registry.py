# -*- coding: utf-8 -*-
"""ShortId 字段注册表 — 对标 Tracking/ShortIdFieldRegistry.cs"""
from typing import Dict, List, Optional


class ShortIdEntityType:
    CHARACTER = "Character"
    LOCATION = "Location"
    CONFLICT = "Conflict"
    FORESHADOWING = "Foreshadowing"
    FACTION = "Faction"
    ITEM = "Item"
    SECRET = "Secret"
    PLEDGE = "Pledge"
    DEADLINE = "Deadline"


class ShortIdFieldMeta:
    def __init__(self, field_path: str, chinese_name: str, entity_type: str, required: bool = False):
        self.FieldPath = field_path
        self.ChineseName = chinese_name
        self.EntityType = entity_type
        self.Required = required


class ShortIdFieldRegistry:
    # 字段路径常量
    CHAR_STATE_CHARACTER_ID = "CharacterStateChanges[].CharacterId"
    CONFLICT_CONFLICT_ID = "ConflictProgress[].ConflictId"
    FORESHADOW_FORESHADOW_ID = "ForeshadowingActions[].ForeshadowId"
    LOCATION_LOCATION_ID = "LocationStateChanges[].LocationId"
    FACTION_FACTION_ID = "FactionStateChanges[].FactionId"
    MOVEMENT_CHARACTER_ID = "CharacterMovements[].CharacterId"
    MOVEMENT_TO_LOCATION = "CharacterMovements[].ToLocation"
    ITEM_ITEM_ID = "ItemTransfers[].ItemId"
    SECRET_SECRET_ID = "SecretRevealChanges[].SecretId"
    PLEDGE_PLEDGE_ID = "PledgeConstraintChanges[].PledgeId"
    DEADLINE_DEADLINE_ID = "DeadlineConstraintChanges[].DeadlineId"

    ALL: List[ShortIdFieldMeta] = [
        ShortIdFieldMeta(CHAR_STATE_CHARACTER_ID, "角色状态变更的角色ID", ShortIdEntityType.CHARACTER, True),
        ShortIdFieldMeta(CONFLICT_CONFLICT_ID, "冲突进度的冲突ID", ShortIdEntityType.CONFLICT, True),
        ShortIdFieldMeta(FORESHADOW_FORESHADOW_ID, "伏笔动作的伏笔ID", ShortIdEntityType.FORESHADOWING, True),
        ShortIdFieldMeta(LOCATION_LOCATION_ID, "地点状态变化的地点ID", ShortIdEntityType.LOCATION, True),
        ShortIdFieldMeta(FACTION_FACTION_ID, "势力状态变化的势力ID", ShortIdEntityType.FACTION, True),
        ShortIdFieldMeta(MOVEMENT_CHARACTER_ID, "角色移动的角色ID", ShortIdEntityType.CHARACTER, True),
        ShortIdFieldMeta(MOVEMENT_TO_LOCATION, "角色移动的到达地点ID", ShortIdEntityType.LOCATION, True),
        ShortIdFieldMeta(ITEM_ITEM_ID, "物品流转的物品ID", ShortIdEntityType.ITEM, True),
        ShortIdFieldMeta(SECRET_SECRET_ID, "秘密知情变化的秘密ID", ShortIdEntityType.SECRET, True),
        ShortIdFieldMeta(PLEDGE_PLEDGE_ID, "承诺/契约变更的承诺ID", ShortIdEntityType.PLEDGE, True),
        ShortIdFieldMeta(DEADLINE_DEADLINE_ID, "倒计时/时限变更的倒计时ID", ShortIdEntityType.DEADLINE, True),
    ]

    _by_path: Dict[str, ShortIdFieldMeta] = {m.FieldPath: m for m in ALL}

    @classmethod
    def get_meta(cls, field_path: str) -> Optional[ShortIdFieldMeta]:
        if not field_path:
            return None
        return cls._by_path.get(field_path.strip())

    @classmethod
    def get_chinese_name(cls, field_path: str) -> str:
        meta = cls.get_meta(field_path)
        return meta.ChineseName if meta else field_path

    @classmethod
    def get_entity_type(cls, field_path: str) -> Optional[str]:
        meta = cls.get_meta(field_path)
        return meta.EntityType if meta else None
