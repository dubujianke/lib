# -*- coding: utf-8 -*-
"""一致性议题注册表 — 对标 Tracking/Consistency/ConsistencyIssueRegistry.cs"""
from typing import Dict


class BaselineScope:
    NONE = 0
    LOCATION = 1 << 0
    FORESHADOW = 1 << 1
    SEMANTIC = 1 << 2


class ConsistencyIssueRegistry:
    """议题描述符（Humanize 提示）"""

    @staticmethod
    def humanize(issue_type: str, entity_name: str, detail: str = "") -> str:
        table = {
            "ForeshadowingRollback": f"伏笔'{entity_name}'已揭示，不能重新埋设。请移除该伏笔的埋设动作",
            "PayoffBeforeSetup": f"伏笔'{entity_name}'尚未埋设，不能在本章揭示。请先在正文中自然埋设该伏笔，或移除揭示动作",
            "ConflictStatusSkip": f"冲突'{entity_name}'的状态不能回退。请检查NewStatus是否正确，冲突只能向前推进",
            "CharacterNotInvolved": f"角色'{entity_name}'不在本章涉及角色列表中，但出现在CHANGES里。请将该角色从CHANGES中移除",
            "LevelRegression": f"角色'{entity_name}'等级/阶段出现回退。除非正文明确发生失去/降级事件，否则不要让新的等级/阶段低于账本记录",
            "AbilityLossWithoutEvent": f"角色'{entity_name}'声明失去能力但缺少原因。关键事件必须写清楚失去原因（封印/废除/代价等）",
            "TrustDeltaExceedsLimit": f"角色'{entity_name}'与他人的信任值变化幅度过大。请把信任值变化控制在合理范围（默认±30以内）",
            "RelationshipContradiction": f"角色'{entity_name}'与他人关系申报矛盾：同一章内同一对角色不能同时声明盟友与仇敌",
            "MovementStartLocationMismatch": f"角色'{entity_name}'的出发地点必须是账本当前位置。请修正角色移动中的出发地点",
            "MovementChainBreak": f"角色'{entity_name}'本章多次移动时路径不连续：上一次到达地点必须等于下一次出发地点",
            "ItemOwnershipMismatch": f"物品'{entity_name}'的转让起点不符：当前持有者不符。请修正物品流转中的原持有者",
            "PledgeDuplicateCreate": f"承诺/契约'{entity_name}'已存在于账本，不应重复 create。请将 create 改为 update",
            "PledgeTerminalActionConflict": f"承诺/契约'{entity_name}'同章出现多个终止动作（fulfill/break 冲突）",
            "DeadlineDuplicateCreate": f"倒计时/时限'{entity_name}'已存在于账本，不应重复 create",
            "DeadlineTerminalActionConflict": f"倒计时/时限'{entity_name}'同章出现多个终止动作（trigger/expire/cancel 冲突）",
            "OmittedDeclaration": f"实体'{entity_name}'出现在正文但 CHANGES 未申报，请在重写时补全相应条目",
        }
        return table.get(issue_type, detail or f"[{issue_type}] {entity_name}")
