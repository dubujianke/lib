# -*- coding: utf-8 -*-
"""一致性议题 — 对标 Tracking/Consistency/ConsistencyIssue.cs"""
from dataclasses import dataclass
from ...common import JsonModel


@dataclass
class ConsistencyIssue(JsonModel):
    EntityId: str = ""
    IssueType: str = ""
    Expected: str = ""
    Actual: str = ""

    def __str__(self) -> str:
        return f"[{self.IssueType}] 实体: {self.EntityId}, 期望: {self.Expected}, 实际: {self.Actual}"
