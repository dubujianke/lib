# -*- coding: utf-8 -*-
"""一致性结果 — 对标 Tracking/Consistency/ConsistencyResult.cs"""
from dataclasses import dataclass, field
from typing import List
from ...common import JsonModel
from .consistency_issue import ConsistencyIssue


@dataclass
class ConsistencyResult(JsonModel):
    Success: bool = True
    Issues: List[ConsistencyIssue] = field(default_factory=list)

    def add_issue(self, issue: ConsistencyIssue):
        self.Issues.append(issue)
        self.Success = False

    def add_issue_fields(self, entity_id: str, issue_type: str, expected: str, actual: str):
        self.add_issue(ConsistencyIssue(EntityId=entity_id, IssueType=issue_type,
                                        Expected=expected, Actual=actual))

    @property
    def has_issues(self) -> bool:
        return len(self.Issues) > 0

    def get_issue_descriptions(self) -> List[str]:
        return [str(i) for i in self.Issues]
