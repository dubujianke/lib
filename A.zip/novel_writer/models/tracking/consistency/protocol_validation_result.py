# -*- coding: utf-8 -*-
"""协议校验结果 — 对标 Tracking/Consistency/ProtocolValidationResult.cs"""
from dataclasses import dataclass, field
from typing import List, Optional
from ...common import JsonModel


@dataclass
class ProtocolValidationResult(JsonModel):
    Success: bool = False
    Errors: List[str] = field(default_factory=list)
    Changes: Optional[object] = None
    ContentWithoutChanges: Optional[str] = None

    def add_error(self, error: str):
        self.Errors.append(error)
        self.Success = False

    @property
    def has_errors(self) -> bool:
        return len(self.Errors) > 0
