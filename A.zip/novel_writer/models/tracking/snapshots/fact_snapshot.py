# -*- coding: utf-8 -*-
"""事实快照 Snapshot 类 — 对标 Tracking/Snapshots/FactSnapshot.cs

注意：FactSnapshot 主类在 tracking/__init__.py（15 维，使用 Entry 类）。
此处定义 C# Snapshots 里的 Snapshot 轻量类（供序列化/卷末快照用）。
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional
from ...common import JsonModel


@dataclass
class CharacterCoreDescription(JsonModel):
    Id: str = ""
    Name: str = ""
    HairColor: str = ""
    EyeColor: str = ""
    Appearance: str = ""
    PersonalityTags: List[str] = field(default_factory=list)


@dataclass
class LocationCoreDescription(JsonModel):
    Id: str = ""
    Name: str = ""
    Description: str = ""
    Features: List[str] = field(default_factory=list)


@dataclass
class CharacterStateSnapshot(JsonModel):
    Id: str = ""
    Name: str = ""
    Stage: str = ""
    Abilities: str = ""
    Relationships: str = ""
    ChapterId: str = ""


@dataclass
class ConflictProgressSnapshot(JsonModel):
    Id: str = ""
    Name: str = ""
    Status: str = ""
    RecentProgress: List[str] = field(default_factory=list)


@dataclass
class ForeshadowingStatusSnapshot(JsonModel):
    Id: str = ""
    Name: str = ""
    IsSetup: bool = False
    IsResolved: bool = False
    IsOverdue: bool = False
    SetupChapterId: Optional[str] = None
    PayoffChapterId: Optional[str] = None


@dataclass
class PlotPointSnapshot(JsonModel):
    Id: str = ""
    Summary: str = ""
    ChapterId: str = ""
    RelatedEntityIds: List[str] = field(default_factory=list)
    Storyline: str = "main"


@dataclass
class LocationStateSnapshot(JsonModel):
    Id: str = ""
    Name: str = ""
    Status: str = ""
    ChapterId: str = ""


@dataclass
class FactionStateSnapshot(JsonModel):
    Id: str = ""
    Name: str = ""
    Status: str = ""
    ChapterId: str = ""


@dataclass
class TimelineSnapshot(JsonModel):
    ChapterId: str = ""
    TimePeriod: str = ""
    ElapsedTime: str = ""
    KeyTimeEvent: str = ""


@dataclass
class CharacterLocationSnapshot(JsonModel):
    CharacterId: str = ""
    CharacterName: str = ""
    CurrentLocation: str = ""
    ChapterId: str = ""


@dataclass
class ItemStateSnapshot(JsonModel):
    Id: str = ""
    Name: str = ""
    CurrentHolder: str = ""
    Status: str = "active"
    ChapterId: str = ""


@dataclass
class SecretStateSnapshot(JsonModel):
    Id: str = ""
    Name: str = ""
    KnowerIds: List[str] = field(default_factory=list)
    Status: str = "hidden"
    ChapterId: str = ""


@dataclass
class PledgeStateSnapshot(JsonModel):
    Id: str = ""
    Name: str = ""
    Type: str = "pledge"
    Status: str = "active"
    PartyIds: str = ""
    Condition: str = ""
    Consequence: str = ""
    ChapterId: str = ""
    IsOverdue: bool = False


@dataclass
class DeadlineStateSnapshot(JsonModel):
    Id: str = ""
    Name: str = ""
    Type: str = "countdown"
    Status: str = "active"
    Deadline: str = ""
    TriggerCondition: str = ""
    Consequence: str = ""
    PartyIds: str = ""
    ChapterId: str = ""
    IsOverdue: bool = False
