# -*- coding: utf-8 -*-
"""卷事实档案 — 对标 Tracking/Snapshots/VolumeFactArchive.cs"""
from dataclasses import dataclass, field
from typing import List
from ...common import JsonModel
from .fact_snapshot import (
    CharacterStateSnapshot, ConflictProgressSnapshot, ForeshadowingStatusSnapshot,
    LocationStateSnapshot, FactionStateSnapshot, TimelineSnapshot,
    CharacterLocationSnapshot, ItemStateSnapshot, SecretStateSnapshot,
    PledgeStateSnapshot, DeadlineStateSnapshot,
)


@dataclass
class VolumeFactArchive(JsonModel):
    VolumeNumber: int = 0
    LastChapterId: str = ""
    ArchivedAt: str = ""
    CharacterStates: List[CharacterStateSnapshot] = field(default_factory=list)
    ConflictProgress: List[ConflictProgressSnapshot] = field(default_factory=list)
    ForeshadowingStatus: List[ForeshadowingStatusSnapshot] = field(default_factory=list)
    LocationStates: List[LocationStateSnapshot] = field(default_factory=list)
    FactionStates: List[FactionStateSnapshot] = field(default_factory=list)
    ItemStates: List[ItemStateSnapshot] = field(default_factory=list)
    SecretStates: List[SecretStateSnapshot] = field(default_factory=list)
    Timeline: List[TimelineSnapshot] = field(default_factory=list)
    CharacterLocations: List[CharacterLocationSnapshot] = field(default_factory=list)
    PledgeStates: List[PledgeStateSnapshot] = field(default_factory=list)
    DeadlineStates: List[DeadlineStateSnapshot] = field(default_factory=list)
