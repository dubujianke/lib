# -*- coding: utf-8 -*-
"""上游索引 — 对标 Index/UpstreamIndex.cs"""
from dataclasses import dataclass, field
from typing import List
from ..common import JsonModel
from .index_item import IndexItem


@dataclass
class UpstreamIndex(JsonModel):
    SmartParsing: List[IndexItem] = field(default_factory=list)
    Templates: List[IndexItem] = field(default_factory=list)
    Worldview: List[IndexItem] = field(default_factory=list)
    Characters: List[IndexItem] = field(default_factory=list)
    Factions: List[IndexItem] = field(default_factory=list)
    Locations: List[IndexItem] = field(default_factory=list)
    Plot: List[IndexItem] = field(default_factory=list)
    Outline: List[IndexItem] = field(default_factory=list)
    Planning: List[IndexItem] = field(default_factory=list)
    Blueprint: List[IndexItem] = field(default_factory=list)
