# -*- coding: utf-8 -*-
"""索引项 — 对标 Index/IndexItem.cs"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from ..common import JsonModel

@dataclass
class IndexItem(JsonModel):
    Id: str = ""
    Name: str = ""
    Type: str = ""
    BriefSummary: str = ""
    DeepSummary: str = ""
    RelationStrength: str = ""
