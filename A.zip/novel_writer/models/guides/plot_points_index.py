# -*- coding: utf-8 -*-
"""情节点索引 — 对标 Guides/PlotPointsIndex.cs"""
from dataclasses import dataclass, field
from typing import Dict, List
from ..common import JsonModel


@dataclass
class KeywordAppearance(JsonModel):
    Chapter: str = ""
    Context: str = ""


@dataclass
class KeywordEntry(JsonModel):
    Description: str = ""
    Appearances: List[KeywordAppearance] = field(default_factory=list)
    RelatedForeshadowings: List[str] = field(default_factory=list)


@dataclass
class PlotPointsIndex(JsonModel):
    Module: str = "PlotPointsIndex"
    PlotPoints: List[object] = field(default_factory=list)
    Keywords: Dict[str, KeywordEntry] = field(default_factory=dict)
    ChapterIndex: Dict[str, List[str]] = field(default_factory=dict)
