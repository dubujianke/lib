# -*- coding: utf-8 -*-
"""承诺约束 Guide — 对标 Guides/ConstraintGuides/PledgeConstraintGuide.cs"""
from dataclasses import dataclass, field
from typing import Dict, List
from ...common import JsonModel


@dataclass
class PledgeConstraintPoint(JsonModel):
    Chapter: str = ""
    Action: str = ""
    KeyEvent: str = ""
    Importance: str = "normal"


@dataclass
class PledgeEntry(JsonModel):
    Name: str = ""
    Type: str = "pledge"
    CurrentStatus: str = "active"
    PartyIds: List[str] = field(default_factory=list)
    Condition: str = ""
    Consequence: str = ""
    History: List[PledgeConstraintPoint] = field(default_factory=list)
    IsOverdue: bool = False
    DriftWarnings: List[str] = field(default_factory=list)


@dataclass
class PledgeConstraintGuide(JsonModel):
    Module: str = "PledgeConstraintGuide"
    Pledges: Dict[str, PledgeEntry] = field(default_factory=dict)
