# -*- coding: utf-8 -*-
"""倒计时约束 Guide — 对标 Guides/ConstraintGuides/DeadlineConstraintGuide.cs"""
from dataclasses import dataclass, field
from typing import Dict, List
from ...common import JsonModel


@dataclass
class DeadlineConstraintPoint(JsonModel):
    Chapter: str = ""
    Action: str = ""
    KeyEvent: str = ""
    Importance: str = "normal"


@dataclass
class DeadlineEntry(JsonModel):
    Name: str = ""
    Type: str = "countdown"
    CurrentStatus: str = "active"
    Deadline: str = ""
    TriggerCondition: str = ""
    Consequence: str = ""
    PartyIds: List[str] = field(default_factory=list)
    History: List[DeadlineConstraintPoint] = field(default_factory=list)
    IsOverdue: bool = False
    DriftWarnings: List[str] = field(default_factory=list)


@dataclass
class DeadlineConstraintGuide(JsonModel):
    Module: str = "DeadlineConstraintGuide"
    Deadlines: Dict[str, DeadlineEntry] = field(default_factory=dict)
