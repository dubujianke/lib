# -*- coding: utf-8 -*-
"""场景指导条目 — 对标 Guides/ContentGuides/SceneGuideEntry.cs"""
from dataclasses import dataclass, field
from typing import List
from ...common import JsonModel


@dataclass
class SceneGuideEntry(JsonModel):
    SceneId: str = ""
    SceneNumber: int = 0
    Purpose: str = ""
    Title: str = ""
    PovCharacter: str = ""
    Opening: str = ""
    Development: str = ""
    Turning: str = ""
    Ending: str = ""
    InfoDrop: str = ""
    CharacterIds: List[str] = field(default_factory=list)
    LocationId: str = ""
