# -*- coding: utf-8 -*-
"""内容指导条目 — 对标 Guides/ContentGuides/ContentGuideEntry.cs"""
from dataclasses import dataclass, field
from typing import List
from ...common import JsonModel
from ..context_id_collection import ContextIdCollection
from .rhythm_info import RhythmInfo
from .scene_guide_entry import SceneGuideEntry


@dataclass
class ContentGuideEntry(JsonModel):
    ChapterId: str = ""
    Title: str = ""
    Summary: str = ""
    ContextIds: ContextIdCollection = field(default_factory=ContextIdCollection)
    Rhythm: RhythmInfo = field(default_factory=RhythmInfo)
    Scenes: List[SceneGuideEntry] = field(default_factory=list)
    ChapterNumber: int = 0
    Volume: str = ""
    ChapterTheme: str = ""
    MainGoal: str = ""
    KeyTurn: str = ""
    Hook: str = ""
    WorldInfoDrop: str = ""
    CharacterArcProgress: str = ""
    Foreshadowing: str = ""
