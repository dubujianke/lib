# -*- coding: utf-8 -*-
"""节奏信息 — 对标 Guides/ContentGuides/RhythmInfo.cs"""
from dataclasses import dataclass
from ...common import JsonModel


@dataclass
class RhythmInfo(JsonModel):
    PaceType: str = ""
    Intensity: str = ""
    EmotionalTone: str = ""
