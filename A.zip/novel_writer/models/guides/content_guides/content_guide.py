# -*- coding: utf-8 -*-
"""内容指导 — 对标 Guides/ContentGuides/ContentGuide.cs"""
from dataclasses import dataclass, field
from typing import Dict
from ...common import JsonModel
from .content_guide_entry import ContentGuideEntry


@dataclass
class ContentGuide(JsonModel):
    Module: str = "ContentGuide"
    Chapters: Dict[str, ContentGuideEntry] = field(default_factory=dict)
    ChapterSummaries: Dict[str, str] = field(default_factory=dict)
