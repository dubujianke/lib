# -*- coding: utf-8 -*-
"""秘密揭示 Guide — 对标 Guides/SecretRevealGuide.cs"""
from dataclasses import dataclass, field
from typing import Dict, List
from ..common import JsonModel


@dataclass
class SecretRevealPoint(JsonModel):
    Chapter: str = ""
    NewKnowerIds: List[str] = field(default_factory=list)
    Method: str = ""
    KeyEvent: str = ""
    Importance: str = "normal"
    CausedBy: str = ""


@dataclass
class SecretRevealEntry(JsonModel):
    Name: str = ""
    KnowerIds: List[str] = field(default_factory=list)
    CurrentStatus: str = "hidden"
    RevealHistory: List[SecretRevealPoint] = field(default_factory=list)
    DriftWarnings: List[str] = field(default_factory=list)


@dataclass
class SecretRevealGuide(JsonModel):
    Module: str = "SecretRevealGuide"
    Secrets: Dict[str, SecretRevealEntry] = field(default_factory=dict)
