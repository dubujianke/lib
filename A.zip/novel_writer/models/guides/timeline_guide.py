# -*- coding: utf-8 -*-
"""时间线 Guide — 对标 Guides/TimelineGuide.cs"""
from dataclasses import dataclass, field
from typing import Dict, List
from ..common import JsonModel


@dataclass
class ChapterTimeEntry(JsonModel):
    ChapterId: str = ""
    TimePeriod: str = ""
    ElapsedTime: str = ""
    KeyTimeEvent: str = ""
    Importance: str = "normal"


@dataclass
class MovementRecord(JsonModel):
    Chapter: str = ""
    FromLocation: str = ""
    ToLocation: str = ""
    Importance: str = "normal"


@dataclass
class CharacterLocationEntry(JsonModel):
    CharacterName: str = ""
    CurrentLocation: str = ""
    LastUpdatedChapter: str = ""
    MovementHistory: List[MovementRecord] = field(default_factory=list)


@dataclass
class TimelineGuide(JsonModel):
    Module: str = "TimelineGuide"
    ChapterTimeline: List[ChapterTimeEntry] = field(default_factory=list)
    CharacterLocations: Dict[str, CharacterLocationEntry] = field(default_factory=dict)
