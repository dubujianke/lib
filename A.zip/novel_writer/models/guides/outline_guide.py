# -*- coding: utf-8 -*-
"""大纲指导 — 对标 Guides/OutlineGuide.cs"""
from dataclasses import dataclass, field
from typing import Dict, List
from ..common import JsonModel
from .context_id_collection import ContextIdCollection


@dataclass
class OutputIds(JsonModel):
    KeyEvents: List[str] = field(default_factory=list)
    ForeshadowingSetup: List[str] = field(default_factory=list)


@dataclass
class VolumeGuideEntry(JsonModel):
    VolumeNumber: int = 0
    Name: str = ""
    Theme: str = ""
    PlannedChapters: int = 0
    ContextIds: ContextIdCollection = field(default_factory=ContextIdCollection)
    OutputIds: OutputIds = field(default_factory=OutputIds)


@dataclass
class OutlineGuide(JsonModel):
    Module: str = "OutlineGuide"
    Volumes: Dict[str, VolumeGuideEntry] = field(default_factory=dict)
