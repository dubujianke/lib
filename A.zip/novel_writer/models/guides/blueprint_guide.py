# -*- coding: utf-8 -*-
"""蓝图指导 — 对标 Guides/BlueprintGuide.cs"""
from dataclasses import dataclass, field
from typing import Dict, List
from ..common import JsonModel
from .context_id_collection import ContextIdCollection
from .content_guides.rhythm_info import RhythmInfo
from .content_guides.scene_guide_entry import SceneGuideEntry


@dataclass
class ChapterGuideEntry(JsonModel):
    ChapterId: str = ""
    Title: str = ""
    ChapterGoal: str = ""
    ContextIds: ContextIdCollection = field(default_factory=ContextIdCollection)
    Rhythm: RhythmInfo = field(default_factory=RhythmInfo)
    Scenes: List[SceneGuideEntry] = field(default_factory=list)


@dataclass
class ReverseIndex(JsonModel):
    ByCharacter: Dict[str, List[str]] = field(default_factory=dict)
    ByLocation: Dict[str, List[str]] = field(default_factory=dict)


@dataclass
class BlueprintGuide(JsonModel):
    Module: str = "BlueprintGuide"
    Chapters: Dict[str, ChapterGuideEntry] = field(default_factory=dict)
    ReverseIndex: ReverseIndex = field(default_factory=ReverseIndex)
