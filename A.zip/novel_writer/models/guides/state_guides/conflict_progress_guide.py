# -*- coding: utf-8 -*-
"""冲突进度 Guide — 对标 Guides/StateGuides/ConflictProgressGuide.cs"""
from dataclasses import dataclass, field
from typing import Dict, List
from ...common import JsonModel


@dataclass
class ConflictProgressPoint(JsonModel):
    Chapter: str = ""
    Event: str = ""
    Status: str = ""
    Description: str = ""
    Importance: str = "normal"
    CausedBy: str = ""


@dataclass
class ConflictProgressEntry(JsonModel):
    Name: str = ""
    Type: str = ""
    Tier: str = "Tier-3"
    Status: str = "pending"
    ProgressPoints: List[ConflictProgressPoint] = field(default_factory=list)
    InvolvedChapters: List[str] = field(default_factory=list)
    InvolvedCharacters: List[str] = field(default_factory=list)
    DriftWarnings: List[str] = field(default_factory=list)


@dataclass
class ConflictProgressGuide(JsonModel):
    Module: str = "ConflictProgressGuide"
    Conflicts: Dict[str, ConflictProgressEntry] = field(default_factory=dict)
