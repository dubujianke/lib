# -*- coding: utf-8 -*-
"""物品状态 Guide — 对标 Guides/StateGuides/ItemStateGuide.cs"""
from dataclasses import dataclass, field
from typing import Dict, List
from ...common import JsonModel


@dataclass
class ItemStatePoint(JsonModel):
    Chapter: str = ""
    Holder: str = ""
    Status: str = "active"
    Event: str = ""
    Importance: str = "normal"
    CausedBy: str = ""


@dataclass
class ItemStateEntry(JsonModel):
    Name: str = ""
    Description: str = ""
    CurrentHolder: str = ""
    CurrentStatus: str = "active"
    StateHistory: List[ItemStatePoint] = field(default_factory=list)
    DriftWarnings: List[str] = field(default_factory=list)


@dataclass
class ItemStateGuide(JsonModel):
    Module: str = "ItemStateGuide"
    Items: Dict[str, ItemStateEntry] = field(default_factory=dict)
