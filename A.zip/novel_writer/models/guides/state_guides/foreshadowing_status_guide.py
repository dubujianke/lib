# -*- coding: utf-8 -*-
"""伏笔状态 Guide — 对标 Guides/StateGuides/ForeshadowingStatusGuide.cs"""
from dataclasses import dataclass, field
from typing import Dict, List
from ...common import JsonModel


@dataclass
class ForeshadowingSummary(JsonModel):
    Total: int = 0
    Setup: int = 0
    Payoff: int = 0
    Pending: int = 0
    CompletionRate: str = "0%"


@dataclass
class TierStats(JsonModel):
    Total: int = 0
    Completed: int = 0
    Pending: int = 0


@dataclass
class PendingForeshadowing(JsonModel):
    Id: str = ""
    Tier: str = ""
    Name: str = ""
    SetupChapter: str = ""
    PlannedPayoff: str = ""
    Status: str = "pending"
    Urgency: str = "normal"


@dataclass
class OverdueForeshadowing(JsonModel):
    Id: str = ""
    Tier: str = ""
    Name: str = ""
    SetupChapter: str = ""
    PlannedPayoff: str = ""
    Status: str = "overdue"
    Suggestion: str = ""


@dataclass
class ForeshadowingStatusEntry(JsonModel):
    Name: str = ""
    Tier: str = "Tier-3"
    IsSetup: bool = False
    IsResolved: bool = False
    IsOverdue: bool = False
    ExpectedSetupChapter: str = ""
    ExpectedPayoffChapter: str = ""
    ActualSetupChapter: str = ""
    ActualPayoffChapter: str = ""
    DriftWarnings: List[str] = field(default_factory=list)


@dataclass
class ForeshadowingStatusGuide(JsonModel):
    Module: str = "ForeshadowingStatusGuide"
    Summary: ForeshadowingSummary = field(default_factory=ForeshadowingSummary)
    ByTier: Dict[str, TierStats] = field(default_factory=dict)
    PendingList: List[PendingForeshadowing] = field(default_factory=list)
    OverdueList: List[OverdueForeshadowing] = field(default_factory=list)
    Foreshadowings: Dict[str, ForeshadowingStatusEntry] = field(default_factory=dict)
