# -*- coding: utf-8 -*-
"""势力状态 Guide — 对标 Guides/StateGuides/FactionStateGuide.cs"""
from dataclasses import dataclass, field
from typing import Dict, List
from ...common import JsonModel


@dataclass
class FactionStatePoint(JsonModel):
    Chapter: str = ""
    Status: str = ""
    Event: str = ""
    Importance: str = "normal"
    CausedBy: str = ""


@dataclass
class FactionStateEntry(JsonModel):
    Name: str = ""
    CurrentStatus: str = "active"
    StateHistory: List[FactionStatePoint] = field(default_factory=list)
    DriftWarnings: List[str] = field(default_factory=list)


@dataclass
class FactionStateGuide(JsonModel):
    Module: str = "FactionStateGuide"
    Factions: Dict[str, FactionStateEntry] = field(default_factory=dict)
