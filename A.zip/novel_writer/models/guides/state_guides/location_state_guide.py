# -*- coding: utf-8 -*-
"""地点状态 Guide — 对标 Guides/StateGuides/LocationStateGuide.cs"""
from dataclasses import dataclass, field
from typing import Dict, List
from ...common import JsonModel


@dataclass
class LocationStatePoint(JsonModel):
    Chapter: str = ""
    Status: str = ""
    Event: str = ""
    Importance: str = "normal"


@dataclass
class LocationStateEntry(JsonModel):
    Name: str = ""
    CurrentStatus: str = "normal"
    StateHistory: List[LocationStatePoint] = field(default_factory=list)
    DriftWarnings: List[str] = field(default_factory=list)


@dataclass
class LocationStateGuide(JsonModel):
    Module: str = "LocationStateGuide"
    Locations: Dict[str, LocationStateEntry] = field(default_factory=dict)
