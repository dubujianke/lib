# -*- coding: utf-8 -*-
"""角色状态 Guide — 对标 Guides/StateGuides/CharacterStateGuide.cs"""
from dataclasses import dataclass, field
from typing import Dict, List
from ...common import JsonModel


@dataclass
class CharacterState(JsonModel):
    Chapter: str = ""
    Phase: str = ""
    Level: str = ""
    Abilities: List[str] = field(default_factory=list)
    Relationships: Dict[str, dict] = field(default_factory=dict)
    MentalState: str = ""
    KeyEvent: str = ""
    Importance: str = "normal"
    CausedBy: str = ""


@dataclass
class CharacterStateEntry(JsonModel):
    Name: str = ""
    StateHistory: List[CharacterState] = field(default_factory=list)
    DriftWarnings: List[str] = field(default_factory=list)


@dataclass
class CharacterStateGuide(JsonModel):
    Module: str = "CharacterStateGuide"
    Characters: Dict[str, CharacterStateEntry] = field(default_factory=dict)
