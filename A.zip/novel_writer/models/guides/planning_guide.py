# -*- coding: utf-8 -*-
"""规划指导 — 对标 Guides/PlanningGuide.cs"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional
from ..common import JsonModel
from .context_id_collection import ContextIdCollection
from .content_guides.rhythm_info import RhythmInfo


@dataclass
class PlotAllocationEntry(JsonModel):
    PlotPointId: str = ""
    PlotType: str = ""
    Priority: Optional[int] = None


@dataclass
class PlanningChapterEntry(JsonModel):
    ChapterPlanId: str = ""
    ChapterNumber: int = 0
    Title: str = ""
    Synopsis: str = ""
    Rhythm: RhythmInfo = field(default_factory=RhythmInfo)
    PlotAllocations: List[PlotAllocationEntry] = field(default_factory=list)


@dataclass
class PlanningVolumeEntry(JsonModel):
    VolumeNumber: int = 0
    ContextIds: ContextIdCollection = field(default_factory=ContextIdCollection)
    Chapters: Dict[str, PlanningChapterEntry] = field(default_factory=dict)


@dataclass
class PlanningGuide(JsonModel):
    Module: str = "PlanningGuide"
    Volumes: Dict[str, PlanningVolumeEntry] = field(default_factory=dict)
