# -*- coding: utf-8 -*-
"""上下文 ID 集合 — 对标 Guides/ContextIdCollection.cs"""
from dataclasses import dataclass, field
from typing import Dict, List
from ..common import JsonModel


@dataclass
class ContextIdCollection(JsonModel):
    VolumeOutline: str = ""
    VolumeDesignId: str = ""
    ChapterPlanId: str = ""
    ChapterBlueprint: str = ""
    BlueprintIds: List[str] = field(default_factory=list)
    Characters: List[str] = field(default_factory=list)
    Factions: List[str] = field(default_factory=list)
    Locations: List[str] = field(default_factory=list)
    PlotRules: List[str] = field(default_factory=list)
    TemplateIds: List[str] = field(default_factory=list)
    WorldRuleIds: List[str] = field(default_factory=list)
    Conflicts: List[str] = field(default_factory=list)
    ForeshadowingSetups: List[str] = field(default_factory=list)
    ForeshadowingPayoffs: List[str] = field(default_factory=list)
    PreviousChapter: str = ""
    PreviousVolumes: List[str] = field(default_factory=list)
    PreviousOutlines: List[str] = field(default_factory=list)


@dataclass
class ContextIdValidationResult(JsonModel):
    IsValid: bool = False
    MissingIds: Dict[str, List[str]] = field(default_factory=dict)

    @staticmethod
    def success() -> "ContextIdValidationResult":
        return ContextIdValidationResult(IsValid=True)

    @staticmethod
    def failed(missing_ids: Dict[str, List[str]]) -> "ContextIdValidationResult":
        return ContextIdValidationResult(IsValid=False, MissingIds=missing_ids)

    def get_error_summary(self) -> str:
        if self.IsValid:
            return ""
        return "; ".join(f"{k}: {', '.join(v)}" for k, v in self.MissingIds.items())
