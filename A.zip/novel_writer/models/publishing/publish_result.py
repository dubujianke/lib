# -*- coding: utf-8 -*-
"""发布结果 — 对标 Publishing/PublishResult.cs"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional
from ..common import JsonModel, now_str


class DiffType:
    NONE = "None"
    ENABLED_CHANGED = "EnabledChanged"
    DATA_CHANGED = "DataChanged"


@dataclass
class PublishResult(JsonModel):
    IsSuccess: bool = False
    Message: str = ""
    PublishTime: str = ""
    Version: int = 0
    PackagedModules: List[str] = field(default_factory=list)
    ErrorDetail: Optional[str] = None

    @staticmethod
    def success(version: int, modules: List[str]) -> "PublishResult":
        return PublishResult(IsSuccess=True, Message="发布成功", PublishTime=now_str(),
                             Version=version, PackagedModules=modules)

    @staticmethod
    def failed(message: str, detail: Optional[str] = None) -> "PublishResult":
        return PublishResult(IsSuccess=False, Message=message, PublishTime=now_str(), ErrorDetail=detail)


@dataclass
class PublishStatus(JsonModel):
    IsPublished: bool = False
    LastPublishTime: str = ""
    CurrentVersion: int = 0
    NeedsRepublish: bool = False
    ChangedModuleCount: int = 0


@dataclass
class StatisticsInfo(JsonModel):
    TotalCharacters: int = 0
    TotalLocations: int = 0
    TotalChapters: int = 0
    TotalWords: int = 0


@dataclass
class ManifestInfo(JsonModel):
    ProjectName: str = ""
    PublishTime: str = ""
    Version: int = 0
    Files: Dict[str, List[str]] = field(default_factory=dict)
    EnabledModules: Dict[str, Dict[str, bool]] = field(default_factory=dict)
    Statistics: StatisticsInfo = field(default_factory=StatisticsInfo)


@dataclass
class PackageHistoryEntry(JsonModel):
    Version: int = 0
    PublishTime: str = ""
    EnabledSummary: str = ""
    EnabledModules: Dict[str, Dict[str, bool]] = field(default_factory=dict)
    IsCurrent: bool = False
    HistoryPath: str = ""


@dataclass
class ModuleDiffItem(JsonModel):
    ModulePath: str = ""
    DisplayName: str = ""
    Type: str = "None"
    CurrentState: str = ""
    HistoryState: str = ""


@dataclass
class PackageVersionDiff(JsonModel):
    CurrentVersion: int = 0
    HistoryVersion: int = 0
    DiffItems: List[ModuleDiffItem] = field(default_factory=list)
