# -*- coding: utf-8 -*-
"""publishing 模型包"""
