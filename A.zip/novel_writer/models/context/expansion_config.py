# -*- coding: utf-8 -*-
"""扩写规则 — 对标 Context/ExpansionConfig.cs"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from ..common import JsonModel

@dataclass
class ExpansionRules(JsonModel):
    SceneCharactersThreshold: int = 5
    TriggerKeywords: List[str] = field(default_factory=lambda: ["高潮", "转折", "决战", "危机", "冲突"])


# -*- coding: utf-8 -*-
"""扩写限制"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from ..common import JsonModel

@dataclass
class ExpansionLimits(JsonModel):
    MaxAdditionalCharacters: int = 5
    MaxAdditionalForeshadowings: int = 3


# -*- coding: utf-8 -*-
"""扩写配置"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from ..common import JsonModel

@dataclass
class ExpansionConfig(JsonModel):
    Enabled: bool = False
    Rules: ExpansionRules = field(default_factory=ExpansionRules)
    Limits: ExpansionLimits = field(default_factory=ExpansionLimits)
