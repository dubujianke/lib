# -*- coding: utf-8 -*-
"""全局摘要 — 对标 Context/GlobalSummary.cs"""
from dataclasses import dataclass, field
from typing import List
from ..common import JsonModel
from ..index.index_item import IndexItem


@dataclass
class ProgressInfo(JsonModel):
    TotalChapters: int = 0
    CompletedChapters: int = 0
    CurrentPhase: str = ""

    @property
    def completion_rate(self) -> str:
        return f"{self.CompletedChapters * 100 // self.TotalChapters}%" if self.TotalChapters > 0 else "0%"


@dataclass
class UsedElementsIndex(JsonModel):
    UsedAbilities: List[str] = field(default_factory=list)
    UsedPlotPatterns: List[str] = field(default_factory=list)
    PlantedForeshadowings: List[str] = field(default_factory=list)
    ResolvedForeshadowings: List[str] = field(default_factory=list)


@dataclass
class GlobalSummary(JsonModel):
    StorySummary: str = ""
    CoreRules: List[IndexItem] = field(default_factory=list)
    CoreFactions: List[IndexItem] = field(default_factory=list)
    MainConflict: str = ""
    Progress: ProgressInfo = field(default_factory=ProgressInfo)
    UsedElements: UsedElementsIndex = field(default_factory=UsedElementsIndex)
    CompletedLayers: List[str] = field(default_factory=list)
