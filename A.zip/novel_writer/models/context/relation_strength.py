# -*- coding: utf-8 -*-
"""关系强度枚举 — 对标 Context/RelationStrength.cs"""
WEAK = 0
MEDIUM = 1
STRONG = 2
