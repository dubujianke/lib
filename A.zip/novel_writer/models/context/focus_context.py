# -*- coding: utf-8 -*-
"""焦点上下文 — 对标 Context/FocusContext.cs"""
from dataclasses import dataclass, field
from typing import List, Optional
from ..common import JsonModel
from ..index.index_item import IndexItem
from ..index.upstream_index import UpstreamIndex
from .global_summary import GlobalSummary
from .tracking_status import TrackingStatus


@dataclass
class FocusContext(JsonModel):
    FocusId: str = ""
    FocusType: str = ""
    Layer: str = ""
    FocusEntity: Optional[object] = None
    DirectRelations: List[IndexItem] = field(default_factory=list)
    IndirectRelations: List[IndexItem] = field(default_factory=list)
    UpstreamIndex: UpstreamIndex = field(default_factory=UpstreamIndex)


@dataclass
class DesignFocusContext(JsonModel):
    GlobalSummary: GlobalSummary = field(default_factory=GlobalSummary)
    TrackingStatus: TrackingStatus = field(default_factory=TrackingStatus)
    UpstreamIndex: UpstreamIndex = field(default_factory=UpstreamIndex)
    Focus: FocusContext = field(default_factory=FocusContext)


@dataclass
class GenerateFocusContext(JsonModel):
    GlobalSummary: GlobalSummary = field(default_factory=GlobalSummary)
    TrackingStatus: TrackingStatus = field(default_factory=TrackingStatus)
    UpstreamIndex: UpstreamIndex = field(default_factory=UpstreamIndex)
    Focus: FocusContext = field(default_factory=FocusContext)
    TaskContext: Optional[object] = None
