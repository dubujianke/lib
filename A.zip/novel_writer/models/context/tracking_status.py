# -*- coding: utf-8 -*-
"""追踪状态 — 对标 Context/TrackingStatus.cs"""
from dataclasses import dataclass, field
from typing import List
from ..common import JsonModel
from ..guides.plot_points_index import PlotPointsIndex


@dataclass
class CharacterState(JsonModel):
    CharacterId: str = ""
    CharacterName: str = ""
    CurrentStatus: str = ""
    LastAppearanceChapter: str = ""
    CurrentGoal: str = ""


@dataclass
class ConflictProgress(JsonModel):
    ConflictId: str = ""
    ConflictName: str = ""
    ProgressPercent: int = 0
    CurrentPhase: str = ""
    NextExpectedEvent: str = ""


@dataclass
class ForeshadowingStats(JsonModel):
    Total: int = 0
    Planted: int = 0
    Resolved: int = 0
    PendingResolution: List[str] = field(default_factory=list)


@dataclass
class TrackingStatus(JsonModel):
    CharacterStates: List[CharacterState] = field(default_factory=list)
    ConflictProgress: List[ConflictProgress] = field(default_factory=list)
    ForeshadowingStats: ForeshadowingStats = field(default_factory=ForeshadowingStats)
    PlotPoints: PlotPointsIndex = field(default_factory=PlotPointsIndex)
