# -*- coding: utf-8 -*-
"""模块信息 — 对标 Navigation/ModuleInfo.cs"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from ..common import JsonModel

@dataclass
class ModuleInfo(JsonModel):
    ModuleType: str = ""
    SubModule: str = ""
    SubModuleDisplayName: str = ""
    FunctionName: str = ""
    DisplayName: str = ""
    Icon: str = ""
    StoragePath: str = ""
    ViewPath: str = ""
