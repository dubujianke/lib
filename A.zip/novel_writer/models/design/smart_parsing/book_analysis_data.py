# -*- coding: utf-8 -*-
"""拆书分析 — 对标 Design/SmartParsing/BookAnalysisData.cs"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from ...common import BusinessDataBase


@dataclass
class BookAnalysisData(BusinessDataBase):
    Author: str = ""
    Genre: str = ""
    SourceUrl: str = ""
    SourceBookTitle: str = ""
    SourceAuthor: str = ""
    SourceGenre: str = ""
    SourceKeywords: str = ""
    SourceSite: str = ""
    ChapterCount: int = 0
    TotalWordCount: int = 0
    CrawledAt: str = ""
    WorldBuildingMethod: str = ""
    PowerSystemDesign: str = ""
    EnvironmentDescription: str = ""
    FactionDesign: str = ""
    WorldviewHighlights: str = ""
    ProtagonistDesign: str = ""
    SupportingRoles: str = ""
    CharacterRelations: str = ""
    GoldenFingerDesign: str = ""
    CharacterHighlights: str = ""
    PlotStructure: str = ""
    ConflictDesign: str = ""
    ClimaxArrangement: str = ""
    ForeshadowingTechnique: str = ""
    PlotHighlights: str = ""
