# -*- coding: utf-8 -*-
"""地点规则 — 对标 Design/Location/LocationRulesData.cs"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from ...common import BusinessDataBase


@dataclass
class LocationRulesData(BusinessDataBase):
    LocationType: str = ""
    Description: str = ""
    Scale: str = ""
    Terrain: str = ""
    Climate: str = ""
    Landmarks: List[str] = field(default_factory=list)
    Resources: List[str] = field(default_factory=list)
    HistoricalSignificance: str = ""
    Dangers: List[str] = field(default_factory=list)
    FactionId: str = ""
