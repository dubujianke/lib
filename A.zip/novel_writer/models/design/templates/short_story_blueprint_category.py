# -*- coding: utf-8 -*-
"""短篇蓝图分类"""
from dataclasses import dataclass
from typing import Optional
from ...common import JsonModel


@dataclass
class ShortStoryBlueprintCategory(JsonModel):
    Id: str = ""
    Name: str = ""
    Icon: str = "Icon.Folder"
    ParentCategory: Optional[str] = None
    Level: int = 1
    Order: int = 0
    IsBuiltIn: bool = False
    IsEnabled: bool = True
