# -*- coding: utf-8 -*-
"""创意素材 — 对标 Design/Templates/CreativeMaterialData.cs"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from ...common import BusinessDataBase


@dataclass
class CreativeMaterialData(BusinessDataBase):
    Content: str = ""
    SourceType: str = ""
    Tags: List[str] = field(default_factory=list)
    Genre: str = ""
    OverallIdea: str = ""
    SourceBookName: str = ""
