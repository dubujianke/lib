# -*- coding: utf-8 -*-
"""短篇章节蓝图 — 对标 Design/Templates/ShortStoryChapterBlueprint.cs"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from ...common import BusinessDataBase


@dataclass
class ShortStoryChapterBlueprint(BusinessDataBase):
    ChapterIndex: int = 0
    Title: str = ""
    KeyEvents: str = ""
    Characters: str = ""
    EndingNote: str = ""
    TargetWordCount: str = ""
