# -*- coding: utf-8 -*-
"""短篇蓝图数据 — 对标 Design/Templates/ShortStoryBlueprintData.cs"""
from dataclasses import dataclass, field
from typing import List
from ...common import BusinessDataBase
from .short_story_chapter_blueprint import ShortStoryChapterBlueprint


@dataclass
class ShortStoryBlueprintData(BusinessDataBase):
    SourceBookName: str = ""
    Genre: str = ""
    TotalChapters: str = ""
    WordsPerChapter: str = ""
    ToneGuide: str = ""
    Synopsis: str = ""
    ChapterBlueprints: List[ShortStoryChapterBlueprint] = field(default_factory=list)
