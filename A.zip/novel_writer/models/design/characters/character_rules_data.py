# -*- coding: utf-8 -*-
"""角色规则 — 对标 Design/Characters/CharacterRulesData.cs"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from ...common import BusinessDataBase


@dataclass
class CharacterRulesData(BusinessDataBase):
    CharacterType: str = ""
    Gender: str = ""
    Age: str = ""
    Identity: str = ""
    Race: str = ""
    Appearance: str = ""
    Personality: str = ""
    Want: str = ""
    Need: str = ""
    FlawBelief: str = ""
    GrowthPath: str = ""
    TargetCharacterName: str = ""
    RelationshipType: str = ""
    EmotionDynamic: str = ""
    Relationships: Dict[str, str] = field(default_factory=dict)
    CombatSkills: List[str] = field(default_factory=list)
    NonCombatSkills: List[str] = field(default_factory=list)
    SpecialAbilities: List[str] = field(default_factory=list)
    SignatureItems: List[str] = field(default_factory=list)
    CommonItems: List[str] = field(default_factory=list)
    PersonalAssets: str = ""
    IsPov: bool = False
