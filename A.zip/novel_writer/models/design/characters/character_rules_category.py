# -*- coding: utf-8 -*-
"""角色规则分类 — 对标 Design/Characters/CharacterRulesCategory.cs"""
from dataclasses import dataclass
from typing import Optional
from ...common import JsonModel


@dataclass
class CharacterRulesCategory(JsonModel):
    Id: str = ""
    Name: str = ""
    Icon: str = "Icon.User"
    ParentCategory: Optional[str] = None
    Level: int = 1
    Order: int = 0
    IsBuiltIn: bool = False
    IsEnabled: bool = True
