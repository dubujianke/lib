# -*- coding: utf-8 -*-
"""势力规则分类"""
from dataclasses import dataclass
from typing import Optional
from ...common import JsonModel


@dataclass
class FactionRulesCategory(JsonModel):
    Id: str = ""
    Name: str = ""
    Icon: str = "Icon.Institution"
    ParentCategory: Optional[str] = None
    Level: int = 1
    Order: int = 0
    IsBuiltIn: bool = False
    IsEnabled: bool = True
