# -*- coding: utf-8 -*-
"""势力规则 — 对标 Design/Factions/FactionRulesData.cs"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from ...common import BusinessDataBase


@dataclass
class FactionRulesData(BusinessDataBase):
    FactionType: str = ""
    Goal: str = ""
    StrengthTerritory: str = ""
    Leader: str = ""
    CoreMembers: List[str] = field(default_factory=list)
    MemberTraits: str = ""
    Allies: List[str] = field(default_factory=list)
    Enemies: List[str] = field(default_factory=list)
    NeutralCompetitors: List[str] = field(default_factory=list)
