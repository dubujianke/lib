# -*- coding: utf-8 -*-
"""世界观规则 — 对标 Design/Worldview/WorldRulesData.cs"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from ...common import BusinessDataBase


@dataclass
class WorldRulesData(BusinessDataBase):
    OneLineSummary: str = ""
    PowerSystem: str = ""
    Cosmology: str = ""
    SpecialLaws: str = ""
    HardRules: List[str] = field(default_factory=list)
    SoftRules: List[str] = field(default_factory=list)
    AncientEra: str = ""
    KeyEvents: List[str] = field(default_factory=list)
    ModernHistory: str = ""
    StatusQuo: str = ""
