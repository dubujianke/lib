# -*- coding: utf-8 -*-
"""剧情规则 — 对标 Design/Plot/PlotRulesData.cs"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from ...common import BusinessDataBase


@dataclass
class PlotRulesData(BusinessDataBase):
    TargetVolume: int = 0
    AssignedVolume: int = 0
    OneLineSummary: str = ""
    EventType: str = ""
    StoryPhase: str = ""
    PrerequisitesTrigger: str = ""
    MainCharacters: List[str] = field(default_factory=list)
    KeyNpcs: List[str] = field(default_factory=list)
    Location: str = ""
    TimeDuration: str = ""
    StepTitle: str = ""
    Goal: str = ""
    Conflict: str = ""
    Result: str = ""
    EmotionCurve: str = ""
    MainPlotPush: str = ""
    CharacterGrowth: str = ""
    WorldReveal: str = ""
    RewardsClues: str = ""
