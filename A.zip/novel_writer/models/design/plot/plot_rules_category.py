# -*- coding: utf-8 -*-
"""剧情规则分类"""
from dataclasses import dataclass
from typing import Optional
from ...common import JsonModel


@dataclass
class PlotRulesCategory(JsonModel):
    Id: str = ""
    Name: str = ""
    Icon: str = "Icon.Book"
    ParentCategory: Optional[str] = None
    Level: int = 1
    Order: int = 0
    IsBuiltIn: bool = False
    IsEnabled: bool = True
