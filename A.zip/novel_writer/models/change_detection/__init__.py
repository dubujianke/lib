# -*- coding: utf-8 -*-
"""change_detection 模型包"""
