# -*- coding: utf-8 -*-
"""变更状态 — 对标 ChangeDetection/ChangeStatus.cs"""
from dataclasses import dataclass
from ..common import JsonModel


class ChangeStatusType:
    LATEST = "Latest"
    CHANGED = "Changed"
    NEVER = "Never"


@dataclass
class ChangeStatus(JsonModel):
    ModulePath: str = ""
    DisplayName: str = ""
    Status: str = "Never"
    LastModified: str = ""
    LastPackaged: str = ""
    ItemCount: int = 0
    IsEnabled: bool = True
