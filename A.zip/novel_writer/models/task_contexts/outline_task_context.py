# -*- coding: utf-8 -*-
"""大纲任务上下文 — 对标 TaskContexts/OutlineTaskContext.cs"""
from dataclasses import dataclass, field
from typing import List
from ..common import JsonModel
from ..design.characters.character_rules_data import CharacterRulesData
from ..design.location.location_rules_data import LocationRulesData
from ..design.plot.plot_rules_data import PlotRulesData
from ..design.factions.faction_rules_data import FactionRulesData
from ..generate.strategic_outline.outline_data import OutlineData


@dataclass
class OutlineTaskContext(JsonModel):
    VolumeId: str = ""
    VolumeNumber: int = 0
    Theme: str = ""
    Characters: List[CharacterRulesData] = field(default_factory=list)
    Locations: List[LocationRulesData] = field(default_factory=list)
    PlotRules: List[PlotRulesData] = field(default_factory=list)
    Factions: List[FactionRulesData] = field(default_factory=list)
    PreviousOutlines: List[OutlineData] = field(default_factory=list)
