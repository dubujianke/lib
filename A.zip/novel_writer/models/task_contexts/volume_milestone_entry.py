# -*- coding: utf-8 -*-
"""卷里程碑条目 — 对标 TaskContexts/VolumeMilestoneEntry.cs"""
from dataclasses import dataclass
from ..common import JsonModel


@dataclass
class VolumeMilestoneEntry(JsonModel):
    VolumeNumber: int = 0
    Milestone: str = ""
