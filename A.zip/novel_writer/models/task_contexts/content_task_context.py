# -*- coding: utf-8 -*-
"""内容任务上下文 — 对标 TaskContexts/ContentTaskContext.cs"""
from dataclasses import dataclass, field
from typing import List, Optional
from ..common import JsonModel
from ..design.characters.character_rules_data import CharacterRulesData
from ..design.location.location_rules_data import LocationRulesData
from ..design.plot.plot_rules_data import PlotRulesData
from ..design.factions.faction_rules_data import FactionRulesData
from ..design.worldview.world_rules_data import WorldRulesData
from ..design.templates.creative_material_data import CreativeMaterialData
from ..generate.strategic_outline.outline_data import OutlineData
from ..generate.chapter_planning.chapter_data import ChapterData
from ..generate.chapter_blueprint.blueprint_data import BlueprintData
from ..generate.volume_design.volume_design_data import VolumeDesignData
from ..guides.content_guides.rhythm_info import RhythmInfo
from ..guides.content_guides.scene_guide_entry import SceneGuideEntry
from ..guides.context_id_collection import ContextIdCollection
from .chapter_summary_entry import ChapterSummaryEntry
from .chapter_key_event_entry import ChapterKeyEventEntry
from .volume_milestone_entry import VolumeMilestoneEntry


class ContentContextMode:
    UNKNOWN = 0
    FULL = 1
    PACKAGE_ONLY = 2
    MD_ONLY = 3


@dataclass
class LongDistanceRecallFragment(JsonModel):
    ChapterId: str = ""
    Content: str = ""
    Score: float = 0.0
    Category: Optional[str] = None


class RecallCategory:
    FORESHADOWING = 0
    CHARACTER = 1
    GENERAL = 2


@dataclass
class FirstDescriptionSnippet(JsonModel):
    EntityId: str = ""
    EntityName: str = ""
    ChapterId: str = ""
    Content: str = ""


@dataclass
class ContentTaskContext(JsonModel):
    ContextMode: int = 0
    ChapterId: str = ""
    Title: str = ""
    Summary: str = ""
    Characters: List[CharacterRulesData] = field(default_factory=list)
    Locations: List[LocationRulesData] = field(default_factory=list)
    PlotRules: List[PlotRulesData] = field(default_factory=list)
    Factions: List[FactionRulesData] = field(default_factory=list)
    WorldRules: List[WorldRulesData] = field(default_factory=list)
    Templates: List[CreativeMaterialData] = field(default_factory=list)
    VolumeOutline: Optional[OutlineData] = None
    ChapterPlan: Optional[ChapterData] = None
    Blueprints: List[BlueprintData] = field(default_factory=list)
    VolumeDesign: Optional[VolumeDesignData] = None
    PreviousChapterSummary: str = ""
    Rhythm: Optional[RhythmInfo] = None
    Scenes: List[SceneGuideEntry] = field(default_factory=list)
    PreviousChapterSummaries: List[ChapterSummaryEntry] = field(default_factory=list)
    MdPreviousChapterSummaries: List[ChapterSummaryEntry] = field(default_factory=list)
    PreviousChapterTail: str = ""
    PreviousChapterId: str = ""
    ExpandedCharacters: List[CharacterRulesData] = field(default_factory=list)
    IsKeySceneExpanded: bool = False
    FactSnapshot: Optional[object] = None
    ContextIds: Optional[ContextIdCollection] = None
    HistoricalMilestones: List[VolumeMilestoneEntry] = field(default_factory=list)
    LongDistanceRecallFragments: List[LongDistanceRecallFragment] = field(default_factory=list)
    PreviousVolumeArchives: List[object] = field(default_factory=list)
    StateDivergenceWarnings: List[str] = field(default_factory=list)
    CompressedKeyEvents: List[ChapterKeyEventEntry] = field(default_factory=list)
    FirstDescriptionSnippets: List[FirstDescriptionSnippet] = field(default_factory=list)
