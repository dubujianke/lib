# -*- coding: utf-8 -*-
"""蓝图任务上下文 — 对标 TaskContexts/BlueprintTaskContext.cs"""
from dataclasses import dataclass, field
from typing import List
from ..common import JsonModel
from ..design.characters.character_rules_data import CharacterRulesData
from ..design.location.location_rules_data import LocationRulesData
from ..design.plot.plot_rules_data import PlotRulesData
from ..design.factions.faction_rules_data import FactionRulesData
from ..generate.strategic_outline.outline_data import OutlineData
from ..guides.content_guides.rhythm_info import RhythmInfo


@dataclass
class BlueprintTaskContext(JsonModel):
    ChapterId: str = ""
    Title: str = ""
    ChapterGoal: str = ""
    Characters: List[CharacterRulesData] = field(default_factory=list)
    Locations: List[LocationRulesData] = field(default_factory=list)
    PlotRules: List[PlotRulesData] = field(default_factory=list)
    Factions: List[FactionRulesData] = field(default_factory=list)
    VolumeOutline: OutlineData = field(default_factory=OutlineData)
    PreviousChapterSummary: str = ""
    Rhythm: RhythmInfo = field(default_factory=RhythmInfo)
