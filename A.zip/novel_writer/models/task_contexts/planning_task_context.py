# -*- coding: utf-8 -*-
"""规划任务上下文 — 对标 TaskContexts/PlanningTaskContext.cs"""
from dataclasses import dataclass, field
from typing import Dict, List
from ..common import JsonModel
from ..design.characters.character_rules_data import CharacterRulesData
from ..design.plot.plot_rules_data import PlotRulesData
from ..generate.strategic_outline.outline_data import OutlineData
from ..guides.planning_guide import PlanningChapterEntry


@dataclass
class PlanningTaskContext(JsonModel):
    VolumeId: str = ""
    VolumeOutline: OutlineData = field(default_factory=OutlineData)
    Characters: List[CharacterRulesData] = field(default_factory=list)
    PlotRules: List[PlotRulesData] = field(default_factory=list)
    ChapterPlans: Dict[str, PlanningChapterEntry] = field(default_factory=dict)
