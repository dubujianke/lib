# -*- coding: utf-8 -*-
"""章节关键事件条目 — 对标 TaskContexts/ChapterKeyEventEntry.cs"""
from dataclasses import dataclass, field
from typing import List
from ..common import JsonModel


@dataclass
class ChapterKeyEventEntry(JsonModel):
    ChapterId: str = ""
    VolumeNumber: int = 0
    ChapterNumber: int = 0
    Characters: List[str] = field(default_factory=list)
    Turnings: List[str] = field(default_factory=list)
    Foreshadows: List[str] = field(default_factory=list)
    Factions: List[str] = field(default_factory=list)

    def to_compact_line(self, max_length: int = 200) -> str:
        prefix = (f"[第{self.VolumeNumber}卷第{self.ChapterNumber}章]" if self.VolumeNumber > 0 and self.ChapterNumber > 0
                  else f"[第{self.ChapterNumber}章]" if self.ChapterNumber > 0 else f"[{self.ChapterId}]")
        parts = []
        if self.Characters:
            parts.append("/".join(self.Characters))
        if self.Turnings:
            parts.append("情节:" + "/".join(self.Turnings))
        if self.Foreshadows:
            parts.append("伏笔:" + "/".join(self.Foreshadows))
        if self.Factions:
            parts.append("势力:" + "/".join(self.Factions))
        if not parts:
            return ""
        line = prefix + " " + " | ".join(parts)
        return line[:max_length - 1] + "…" if len(line) > max_length else line
