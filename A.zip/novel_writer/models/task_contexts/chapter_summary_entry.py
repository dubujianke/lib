# -*- coding: utf-8 -*-
"""章节摘要条目 — 对标 TaskContexts/ChapterSummaryEntry.cs"""
from dataclasses import dataclass
from ..common import JsonModel


@dataclass
class ChapterSummaryEntry(JsonModel):
    ChapterId: str = ""
    Title: str = ""
    Summary: str = ""
    ChapterNumber: int = 0
