# -*- coding: utf-8 -*-
"""校验规则 — 对标 Validate/ValidationSummary/ValidationRules.cs"""
ALL_MODULE_NAMES = [
    "StyleConsistency", "WorldviewConsistency", "CharacterConsistency",
    "FactionConsistency", "LocationConsistency", "PlotConsistency",
    "OutlineConsistency", "ChapterPlanConsistency", "BlueprintConsistency",
    "VolumeDesignConsistency",
]
DISPLAY_NAMES = {
    "StyleConsistency": "文风模板一致性", "WorldviewConsistency": "世界观一致性",
    "CharacterConsistency": "角色设定一致性", "FactionConsistency": "势力设定一致性",
    "LocationConsistency": "地点设定一致性", "PlotConsistency": "剧情规则一致性",
    "OutlineConsistency": "大纲一致性", "ChapterPlanConsistency": "章节规划一致性",
    "BlueprintConsistency": "章节蓝图一致性", "VolumeDesignConsistency": "分卷设计一致性",
}
EXTENDED_DATA_SCHEMAS = {
    "StyleConsistency": ["TemplateName", "Genre", "OverallIdea", "StyleHint"],
    "WorldviewConsistency": ["WorldRuleName", "HardRules", "PowerSystem", "SpecialLaws"],
    "CharacterConsistency": ["CharacterName", "Identity", "CoreTraits", "ArcGoal"],
    "FactionConsistency": ["FactionName", "FactionType", "Goal", "Leader"],
    "LocationConsistency": ["LocationName", "LocationType", "Description", "Terrain"],
    "PlotConsistency": ["PlotName", "StoryPhase", "Goal", "Conflict", "Result"],
    "OutlineConsistency": ["OneLineOutline", "CoreConflict", "Theme", "EndingState"],
    "ChapterPlanConsistency": ["ChapterTitle", "MainGoal", "KeyTurn", "Hook", "Foreshadowing"],
    "BlueprintConsistency": ["ChapterId", "OneLineStructure", "PacingCurve", "Cast", "Locations"],
    "VolumeDesignConsistency": ["VolumeTitle", "VolumeTheme", "StageGoal", "MainConflict", "KeyEvents"],
}


def get_display_name(module_name: str) -> str:
    return DISPLAY_NAMES.get(module_name, module_name)


def get_extended_data_schema(module_name: str) -> list:
    return EXTENDED_DATA_SCHEMAS.get(module_name, [])


def total_rule_count() -> int:
    return len(ALL_MODULE_NAMES)
