# -*- coding: utf-8 -*-
"""校验摘要数据 — 对标 Validate/ValidationSummary/ValidationSummaryData.cs"""
from dataclasses import dataclass, field
from typing import Dict, List
from ...common import JsonModel
from .module_validation_result import ModuleValidationResult


@dataclass
class ValidationSummaryData(JsonModel):
    Id: str = ""
    Name: str = ""
    Icon: str = "Icon.CheckCircle"
    Category: str = ""
    CategoryId: str = ""
    IsEnabled: bool = True
    CreatedTime: str = ""
    ModifiedTime: str = ""
    TargetVolumeNumber: int = 0
    TargetVolumeName: str = ""
    SampledChapterCount: int = 0
    SampledChapterIds: List[str] = field(default_factory=list)
    LastValidatedTime: str = ""
    OverallResult: str = "未校验"
    ModuleResults: List[ModuleValidationResult] = field(default_factory=list)
    DependencyModuleVersions: Dict[str, int] = field(default_factory=dict)
