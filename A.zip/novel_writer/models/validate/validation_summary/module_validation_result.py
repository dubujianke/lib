# -*- coding: utf-8 -*-
"""模块校验结果 — 对标 Validate/ValidationSummary/ModuleValidationResult.cs"""
from dataclasses import dataclass
from ...common import JsonModel


@dataclass
class ModuleValidationResult(JsonModel):
    ModuleName: str = ""
    DisplayName: str = ""
    VerificationType: str = ""
    Result: str = "未校验"
    IssueDescription: str = ""
    FixSuggestion: str = ""
    ExtendedDataJson: str = "{}"
    ProblemItemsJson: str = "[]"

    @property
    def result_icon(self) -> str:
        return {"通过": "Icon.CheckCircle", "警告": "Icon.Warning",
                "失败": "Icon.Error", "未校验": "Icon.Warning"}.get(self.Result, "Icon.Clock")
