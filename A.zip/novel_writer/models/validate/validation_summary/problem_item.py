# -*- coding: utf-8 -*-
"""问题条目 — 对标 Validate/ValidationSummary/ProblemItem.cs"""
from dataclasses import dataclass
from typing import Optional
from ...common import JsonModel


@dataclass
class ProblemItem(JsonModel):
    Summary: str = ""
    Reason: str = ""
    Details: Optional[str] = None
    Suggestion: Optional[str] = None
    ChapterId: Optional[str] = None
    ChapterTitle: Optional[str] = None
