# -*- coding: utf-8 -*-
"""校验摘要分类 — 对标 Validate/ValidationSummary/ValidationSummaryCategory.cs"""
from dataclasses import dataclass
from typing import Optional
from ...common import JsonModel


@dataclass
class ValidationSummaryCategory(JsonModel):
    Id: str = ""
    Name: str = ""
    Icon: str = "Icon.Books"
    ParentCategory: Optional[str] = None
    Level: int = 1
    Order: int = 0
    IsEnabled: bool = True
    IsBuiltIn: bool = False
