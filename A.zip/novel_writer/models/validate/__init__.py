# -*- coding: utf-8 -*-
"""validate 模型包"""
