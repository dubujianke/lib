# -*- coding: utf-8 -*-
"""章节信息 — 对标 Generated/ChapterInfo.cs"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from ..common import JsonModel

@dataclass
class ChapterInfo(JsonModel):
    Id: str = ""
    Title: str = ""
    VolumeNumber: int = 0
    ChapterNumber: int = 0
    WordCount: int = 0
    CreatedTime: str = ""
    ModifiedTime: str = ""
    FilePath: str = ""
