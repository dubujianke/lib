# -*- coding: utf-8 -*-
"""卷信息 — 对标 Generated/VolumeInfo.cs"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from ..common import JsonModel

@dataclass
class VolumeInfo(JsonModel):
    Id: str = ""
    Name: str = ""
    Icon: str = "Icon.Folder"
    Number: int = 0
    Order: int = 0
    Source: str = "volume_design"
    IsReadOnly: bool = True
