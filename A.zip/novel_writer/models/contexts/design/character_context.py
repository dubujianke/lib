# -*- coding: utf-8 -*-
"""角色上下文 — 对标 Contexts/Design/CharacterContext.cs"""
from dataclasses import dataclass, field
from typing import List, Optional
from ...common import JsonModel
from ...design.characters.character_rules_data import CharacterRulesData


@dataclass
class CharacterContext(JsonModel):
    Templates: Optional[object] = None
    Worldview: Optional[object] = None
    CharacterRules: List[CharacterRulesData] = field(default_factory=list)
