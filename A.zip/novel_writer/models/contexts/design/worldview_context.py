# -*- coding: utf-8 -*-
"""世界观上下文 — 对标 Contexts/Design/WorldviewContext.cs"""
from dataclasses import dataclass, field
from typing import List, Optional
from ...common import JsonModel
from ...design.worldview.world_rules_data import WorldRulesData


@dataclass
class WorldviewContext(JsonModel):
    Templates: Optional[object] = None
    WorldRules: List[WorldRulesData] = field(default_factory=list)
