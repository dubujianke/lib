# -*- coding: utf-8 -*-
"""势力上下文 — 对标 Contexts/Design/FactionsContext.cs"""
from dataclasses import dataclass, field
from typing import List, Optional
from ...common import JsonModel
from ...design.factions.faction_rules_data import FactionRulesData


@dataclass
class FactionsContext(JsonModel):
    Templates: Optional[object] = None
    Worldview: Optional[object] = None
    Characters: Optional[object] = None
    FactionRules: List[FactionRulesData] = field(default_factory=list)
