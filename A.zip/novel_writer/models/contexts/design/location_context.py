# -*- coding: utf-8 -*-
"""地点上下文 — 对标 Contexts/Design/LocationContext.cs"""
from dataclasses import dataclass, field
from typing import List, Optional
from ...common import JsonModel
from ...design.location.location_rules_data import LocationRulesData


@dataclass
class LocationContext(JsonModel):
    Templates: Optional[object] = None
    Worldview: Optional[object] = None
    Characters: Optional[object] = None
    Factions: Optional[object] = None
    LocationRules: List[LocationRulesData] = field(default_factory=list)
