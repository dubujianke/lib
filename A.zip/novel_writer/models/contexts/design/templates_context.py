# -*- coding: utf-8 -*-
"""创意素材上下文 — 对标 Contexts/Design/TemplatesContext.cs"""
from dataclasses import dataclass, field
from typing import List
from ...common import JsonModel
from ...design.templates.creative_material_data import CreativeMaterialData


@dataclass
class TemplatesContext(JsonModel):
    CreativeMaterials: List[CreativeMaterialData] = field(default_factory=list)
