# -*- coding: utf-8 -*-
"""剧情上下文 — 对标 Contexts/Design/PlotContext.cs"""
from dataclasses import dataclass, field
from typing import List, Optional
from ...common import JsonModel
from ...design.plot.plot_rules_data import PlotRulesData


@dataclass
class PlotContext(JsonModel):
    Templates: Optional[object] = None
    Worldview: Optional[object] = None
    Characters: Optional[object] = None
    Factions: Optional[object] = None
    Locations: Optional[object] = None
    PlotRules: List[PlotRulesData] = field(default_factory=list)
