# -*- coding: utf-8 -*-
"""拆书上下文 — 对标 Contexts/Design/SmartParsingContext.cs"""
from dataclasses import dataclass, field
from typing import List
from ...common import JsonModel
from ...design.smart_parsing.book_analysis_data import BookAnalysisData


@dataclass
class SmartParsingContext(JsonModel):
    BookAnalyses: List[BookAnalysisData] = field(default_factory=list)
