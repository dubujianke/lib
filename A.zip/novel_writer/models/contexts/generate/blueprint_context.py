# -*- coding: utf-8 -*-
"""蓝图上下文 — 对标 Contexts/Generate/BlueprintContext.cs"""
from dataclasses import dataclass, field
from typing import List
from ...common import JsonModel
from ...generate.strategic_outline.outline_data import OutlineData
from ...generate.chapter_planning.chapter_data import ChapterData
from ...generate.chapter_blueprint.blueprint_data import BlueprintData


@dataclass
class BlueprintContext(JsonModel):
    Blueprints: List[BlueprintData] = field(default_factory=list)
