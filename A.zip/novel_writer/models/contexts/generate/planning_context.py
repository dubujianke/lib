# -*- coding: utf-8 -*-
"""规划上下文 — 对标 Contexts/Generate/PlanningContext.cs"""
from dataclasses import dataclass, field
from typing import List
from ...common import JsonModel
from ...generate.strategic_outline.outline_data import OutlineData
from ...generate.chapter_planning.chapter_data import ChapterData
from ...generate.chapter_blueprint.blueprint_data import BlueprintData


@dataclass
class PlanningContext(JsonModel):
    Chapters: List[ChapterData] = field(default_factory=list)
