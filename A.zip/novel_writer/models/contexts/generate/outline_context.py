# -*- coding: utf-8 -*-
"""大纲上下文 — 对标 Contexts/Generate/OutlineContext.cs"""
from dataclasses import dataclass, field
from typing import List
from ...common import JsonModel
from ...generate.strategic_outline.outline_data import OutlineData
from ...generate.chapter_planning.chapter_data import ChapterData
from ...generate.chapter_blueprint.blueprint_data import BlueprintData


@dataclass
class OutlineContext(JsonModel):
    Outlines: List[OutlineData] = field(default_factory=list)
