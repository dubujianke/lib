# -*- coding: utf-8 -*-
"""生成数据聚合 — 对标 Contexts/Aggregates/GenerateData.cs"""
from dataclasses import dataclass, field
from typing import List
from ...common import JsonModel
from ...generate.strategic_outline.outline_data import OutlineData
from ...generate.chapter_planning.chapter_data import ChapterData
from ...generate.chapter_blueprint.blueprint_data import BlueprintData
from ...generate.volume_design.volume_design_data import VolumeDesignData


@dataclass
class OutlineDataAggregate(JsonModel):
    Outlines: List[OutlineData] = field(default_factory=list)


@dataclass
class PlanningData(JsonModel):
    Chapters: List[ChapterData] = field(default_factory=list)


@dataclass
class BlueprintDataAggregate(JsonModel):
    Blueprints: List[BlueprintData] = field(default_factory=list)


@dataclass
class VolumeDesignDataAggregate(JsonModel):
    VolumeDesigns: List[VolumeDesignData] = field(default_factory=list)


@dataclass
class GenerateData(JsonModel):
    Outline: OutlineDataAggregate = field(default_factory=OutlineDataAggregate)
    Planning: PlanningData = field(default_factory=PlanningData)
    Blueprint: BlueprintDataAggregate = field(default_factory=BlueprintDataAggregate)
    VolumeDesign: VolumeDesignDataAggregate = field(default_factory=VolumeDesignDataAggregate)
