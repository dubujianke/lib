# -*- coding: utf-8 -*-
"""设计数据聚合 — 对标 Contexts/Aggregates/DesignData.cs"""
from dataclasses import dataclass, field
from ...common import JsonModel


@dataclass
class DesignData(JsonModel):
    Templates: object = None
    Worldview: object = None
    Characters: object = None
    Factions: object = None
    Locations: object = None
    Plot: object = None
