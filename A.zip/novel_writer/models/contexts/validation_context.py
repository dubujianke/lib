# -*- coding: utf-8 -*-
"""校验上下文 — 对标 Contexts/ValidationContext.cs"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional
from ..common import JsonModel


@dataclass
class ConsistencyRule(JsonModel):
    Id: str = ""
    Name: str = ""
    Description: str = ""
    RuleType: str = ""
    IsEnabled: bool = True
    Severity: str = "Warning"


@dataclass
class QualityRule(JsonModel):
    Id: str = ""
    Name: str = ""
    Description: str = ""
    RuleType: str = ""
    IsEnabled: bool = True
    Severity: str = "Warning"
    Parameters: Dict[str, object] = field(default_factory=dict)


@dataclass
class DataRule(JsonModel):
    Id: str = ""
    Name: str = ""
    Description: str = ""
    RuleType: str = ""
    IsEnabled: bool = True
    Severity: str = "Error"


@dataclass
class OutputRule(JsonModel):
    Id: str = ""
    Name: str = ""
    Description: str = ""
    RuleType: str = ""
    IsEnabled: bool = True
    Severity: str = "Info"
    Parameters: Dict[str, object] = field(default_factory=dict)


@dataclass
class ValidateRules(JsonModel):
    ConsistencyRules: List[ConsistencyRule] = field(default_factory=list)
    QualityRules: List[QualityRule] = field(default_factory=list)
    DataRules: List[DataRule] = field(default_factory=list)
    OutputRules: List[OutputRule] = field(default_factory=list)


@dataclass
class ValidationContext(JsonModel):
    Design: object = None
    Generate: object = None
    GeneratedContent: str = ""
    Rules: ValidateRules = field(default_factory=ValidateRules)
    ChapterId: str = ""
    VolumeNumber: int = 0
    ChapterNumber: int = 0
