# -*- coding: utf-8 -*-
"""兼容 shim：转发到 .implementations.validation.validation_rules"""
from .implementations.validation.validation_rules import *
