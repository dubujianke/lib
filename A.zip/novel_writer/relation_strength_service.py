# -*- coding: utf-8 -*-
"""兼容 shim：转发到 .implementations.tracking.relation_strength_service"""
from .implementations.tracking.relation_strength_service import *
