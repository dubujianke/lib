# -*- coding: utf-8 -*-
"""严格对标 4.1.1 文件型向量索引持久化:
- VectorMath.QuantizeInt8 / DequantizeInt8: int8 对称量化
- FileBasedVectorIndex: Base64 JSON 持久化 + 内存搜索
- ChapterEmbeddingIndex / ChunkEmbeddingIndex: 具体实现
"""

import os
import json
import math
import base64
import struct
import threading
from typing import Dict, List, Optional, Tuple

# ========================================================================
# 对标 VectorMath: int8 对称量化 + dot product + L2 normalize
# ========================================================================


def _quantize_int8(vec: List[float]) -> Tuple[List[int], float]:
    """对标 QuantizeInt8: float32 → sbyte[] (List[int]) + scale

    scale = maxAbs / 127
    q[i] = round(v[i] / scale), clamped to [-127, 127]
    """
    if not vec:
        return [], 0.0
    max_abs = max(abs(v) for v in vec)
    if max_abs <= 1e-12:
        return [0] * len(vec), 0.0
    scale = max_abs / 127.0
    inv = 1.0 / scale
    q = []
    for v in vec:
        r = round(v * inv)
        if r > 127:
            r = 127
        elif r < -127:
            r = -127
        q.append(r)
    return q, scale


def _dequantize_int8(q: List[int], scale: float) -> List[float]:
    """对标 DequantizeInt8: sbyte[] → float32[]"""
    if scale <= 0:
        return [0.0] * len(q)
    return [x * scale for x in q]


def _dot_product(a: List[float], b: List[float]) -> float:
    """对标 DotProduct"""
    return sum(ai * bi for ai, bi in zip(a, b))


def _l2_norm(v: List[float]) -> float:
    """对标 L2Norm"""
    return math.sqrt(_dot_product(v, v))


def _l2_normalize_in_place(v: List[float]) -> bool:
    """对标 L2NormalizeInPlace"""
    norm = _l2_norm(v)
    if norm <= 1e-12:
        return False
    inv = 1.0 / norm
    for i in range(len(v)):
        v[i] *= inv
    return True


def _l2_normalize(v: List[float]) -> List[float]:
    """对标 L2Normalize"""
    r = list(v)
    _l2_normalize_in_place(r)
    return r


# ========================================================================
# 对标 FileBasedVectorIndex: 内存字典 + Base64-int8-JSON 持久化
# ========================================================================


class VectorSearchHit:
    __slots__ = ("key", "score")

    def __init__(self, key: str, score: float):
        self.key = key
        self.score = score

    def __repr__(self):
        return f"VectorSearchHit(key={self.key!r}, score={self.score:.4f})"


class FileBasedVectorIndex:
    """对标 FileBasedVectorIndex: 线程安全文件型向量索引"""

    CURRENT_VERSION = 1

    def __init__(self, log_tag: str, file_path: str):
        self._log_tag = log_tag
        self._file_path = file_path
        self._entries: Dict[str, List[float]] = {}
        self._io_lock = threading.Lock()
        self._dim_lock = threading.Lock()
        self._loaded = False
        self._dimension = 0

    # ---- 公开 API ----

    @property
    def count(self) -> int:
        return len(self._entries)

    @property
    def file_path(self) -> str:
        return self._file_path

    def upsert(self, key: str, vector: List[float]) -> bool:
        """对标 UpsertAsync"""
        if not key or not vector:
            return False
        self._set_dimension_if_empty(len(vector))
        if len(vector) != self._dimension:
            return False
        self._entries[key] = list(vector)
        self._on_key_upserted(key)
        return True

    def upsert_batch(self, items: List[Tuple[str, List[float]]]) -> bool:
        """对标 UpsertBatchAsync"""
        for key, vec in items:
            if not key or not vec:
                continue
            self._set_dimension_if_empty(len(vec))
            if len(vec) != self._dimension:
                continue
            self._entries[key] = list(vec)
            self._on_key_upserted(key)
        return True

    def remove(self, key: str) -> bool:
        """对标 RemoveAsync"""
        if not key:
            return False
        existed = key in self._entries
        self._entries.pop(key, None)
        if existed:
            self._on_key_removed(key)
        return existed

    def exists(self, key: str) -> bool:
        """对标 ExistsAsync"""
        return bool(key) and key in self._entries

    def get_all_keys(self) -> List[str]:
        """对标 GetAllKeys"""
        return list(self._entries.keys())

    def search(self, query_vector: List[float], top_k: int) -> List[VectorSearchHit]:
        """对标 SearchAsync: 点积 + 最小堆"""
        if not query_vector or top_k <= 0 or not self._entries:
            return []

        import heapq
        snapshot = list(self._entries.items())
        heap = []  # (score, key) min-heap

        for key, vec in snapshot:
            if not vec or len(vec) != len(query_vector):
                continue
            score = _dot_product(query_vector, vec)
            if len(heap) < top_k:
                heapq.heappush(heap, (score, key))
            elif score > heap[0][0]:
                heapq.heapreplace(heap, (score, key))

        results = []
        while heap:
            score, key = heapq.heappop(heap)
            results.append(VectorSearchHit(key, score))
        results.reverse()
        return results

    def try_get_vector(self, key: str) -> Optional[List[float]]:
        """对标 TryGetVector"""
        if not key:
            return None
        return self._entries.get(key)

    def snapshot(self) -> List[Tuple[str, List[float]]]:
        """对标 Snapshot"""
        return list(self._entries.items())

    def remove_many_by_predicate(self, predicate) -> int:
        """对标 RemoveManyByPredicate"""
        removed = 0
        for key in list(self._entries.keys()):
            if predicate(key):
                self._entries.pop(key, None)
                removed += 1
                self._on_key_removed(key)
        return removed

    # ---- 持久化 Load / Save ----

    def load(self):
        """对标 LoadAsync"""
        if self._loaded:
            return
        with self._io_lock:
            if self._loaded:
                return
            self._load_internal()
            self._loaded = True

    def save(self):
        """对标 SaveAsync"""
        with self._io_lock:
            self._save_internal()

    def invalidate_cache(self):
        """对标 InvalidateCache"""
        self._entries.clear()
        self._on_entries_reset()
        self._loaded = False
        with self._dim_lock:
            self._dimension = 0

    # ---- 内部方法 ----

    def _set_dimension_if_empty(self, dim: int):
        if self._dimension > 0:
            return
        with self._dim_lock:
            if self._dimension == 0:
                self._dimension = dim

    def _on_key_upserted(self, key: str):
        pass

    def _on_key_removed(self, key: str):
        pass

    def _on_entries_reset(self):
        pass

    def _load_internal(self):
        """对标 LoadInternalAsync"""
        self._entries.clear()
        self._on_entries_reset()

        if not os.path.exists(self._file_path):
            return

        dto = None
        try:
            with open(self._file_path, "r", encoding="utf-8") as f:
                dto = json.load(f)
        except (json.JSONDecodeError, OSError) as e:
            dto = self._try_load_backup()

        if not dto or not dto.get("entries"):
            return

        with self._dim_lock:
            self._dimension = dto.get("dimension", 0)

        loaded = 0
        skipped = 0
        for entry in dto["entries"]:
            key = entry.get("key")
            b64 = entry.get("vector_b64")
            if not key or not b64:
                skipped += 1
                continue
            try:
                raw = base64.b64decode(b64)
                scale = entry.get("scale", 0.0)
                # byte → sbyte: Python struct 'b' = signed char
                q = list(struct.unpack(f"{len(raw)}b", raw))
                # dequantize
                float_vec = _dequantize_int8(q, scale)
                if len(float_vec) != self._dimension:
                    skipped += 1
                    continue
                # L2 normalize（对标原版加载后归一化）
                _l2_normalize_in_place(float_vec)
                self._entries[key] = float_vec
                self._on_key_upserted(key)
                loaded += 1
            except (ValueError, struct.error):
                skipped += 1

    def _try_load_backup(self) -> Optional[dict]:
        """对标 TryLoadBackup"""
        bak = self._file_path + ".bak"
        if not os.path.exists(bak):
            return None
        try:
            with open(bak, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return None

    def _save_internal(self):
        """对标 SaveInternalAsync"""
        dirname = os.path.dirname(self._file_path)
        if dirname:
            os.makedirs(dirname, exist_ok=True)

        dim = self._dimension
        if dim <= 0 and self._entries:
            dim = len(next(iter(self._entries.values())))

        import datetime
        now_iso = datetime.datetime.utcnow().isoformat() + "Z"
        entries = []
        for key, vec in self._entries.items():
            if not vec:
                continue
            q, scale = _quantize_int8(vec)
            # sbyte → byte: pack as unsigned bytes
            raw = struct.pack(f"{len(q)}b", *q)
            b64 = base64.b64encode(raw).decode("ascii")
            entries.append({
                "key": key,
                "vector_b64": b64,
                "scale": scale,
                "updated_at": now_iso,
            })

        dto = {
            "version": self.CURRENT_VERSION,
            "dimension": dim,
            "quantization": "int8_symmetric",
            "entries": entries,
        }

        tmp = self._file_path + ".tmp"
        bak = self._file_path + ".bak"

        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(dto, f, ensure_ascii=False, separators=(",", ":"))

        if os.path.exists(self._file_path):
            try:
                os.replace(self._file_path, bak)
            except OSError:
                pass

        os.replace(tmp, self._file_path)


# ========================================================================
# 对标 ChapterEmbeddingIndex / ChunkEmbeddingIndex
# ========================================================================


class ChapterEmbeddingIndex(FileBasedVectorIndex):
    """对标 ChapterEmbeddingIndex"""

    def __init__(self, project_dir: str):
        path = os.path.join(project_dir, "guides", "chapter_embeddings.json")
        super().__init__("ChapterEmbedding", path)


class ChunkEmbeddingIndex(FileBasedVectorIndex):
    """对标 ChunkEmbeddingIndex + IChunkEmbeddingIndex"""

    def __init__(self, project_dir: str):
        path = os.path.join(project_dir, "guides", "chunk_embeddings.json")
        super().__init__("ChunkEmbedding", path)
        self._chapter_keys: Dict[str, set] = {}

    # ---- chapter-key 管理 ----

    @staticmethod
    def _format_chunk_key(chapter_id: str, position: int) -> str:
        """对标 ChunkKey.Format"""
        return f"{chapter_id}#{position}"

    @staticmethod
    def _parse_chunk_key(key: str) -> Tuple[str, int]:
        """对标 ChunkKey.TryParse"""
        idx = key.rfind("#")
        if idx <= 0 or idx == len(key) - 1:
            return "", -1
        chapter_id = key[:idx]
        try:
            position = int(key[idx + 1:])
            if position < 0:
                return "", -1
        except ValueError:
            return "", -1
        return chapter_id, position

    def _on_key_upserted(self, key: str):
        chapter_id, _ = self._parse_chunk_key(key)
        if not chapter_id:
            return
        key_set = self._chapter_keys.get(chapter_id)
        if key_set is None:
            key_set = set()
            self._chapter_keys[chapter_id] = key_set
        key_set.add(key)

    def _on_key_removed(self, key: str):
        chapter_id, _ = self._parse_chunk_key(key)
        if not chapter_id:
            return
        key_set = self._chapter_keys.get(chapter_id)
        if key_set:
            key_set.discard(key)
            if not key_set:
                del self._chapter_keys[chapter_id]

    def _on_entries_reset(self):
        self._chapter_keys.clear()

    # ---- 章节级操作 ----

    def get_by_chapter(self, chapter_id: str) -> List[Tuple[str, int, List[float]]]:
        """对标 GetByChapterAsync: 返回 [(chunk_key, position, vector), ...]"""
        if not chapter_id:
            return []
        key_set = self._chapter_keys.get(chapter_id)
        if not key_set:
            return []
        results = []
        for key in key_set:
            cid, pos = self._parse_chunk_key(key)
            if cid != chapter_id:
                continue
            vec = self.try_get_vector(key)
            if vec is None:
                continue
            results.append((key, pos, vec))
        results.sort(key=lambda x: x[1])
        return results

    def remove_by_chapter(self, chapter_id: str) -> int:
        """对标 RemoveByChapterAsync"""
        if not chapter_id:
            return 0
        removed = 0
        key_set = self._chapter_keys.get(chapter_id)
        if key_set:
            for key in list(key_set):
                if self.remove(key):
                    removed += 1
        else:
            prefix = chapter_id + "#"
            removed = self.remove_many_by_predicate(
                lambda k: k.startswith(prefix) and self._parse_chunk_key(k)[0] == chapter_id
            )
        return removed

    def search_within_chapters(self, query_vector: List[float],
                               chapter_ids: List[str],
                               top_k: int) -> List[VectorSearchHit]:
        """对标 SearchWithinChaptersAsync"""
        if not query_vector or top_k <= 0 or not chapter_ids:
            return []

        import heapq
        chapter_set = set(chapter_ids)
        snapshot = self.snapshot()
        if not snapshot:
            return []

        heap = []
        for key, vec in snapshot:
            cid, _ = self._parse_chunk_key(key)
            if cid not in chapter_set:
                continue
            if not vec or len(vec) != len(query_vector):
                continue
            score = _dot_product(query_vector, vec)
            if len(heap) < top_k:
                heapq.heappush(heap, (score, key))
            elif score > heap[0][0]:
                heapq.heapreplace(heap, (score, key))

        results = []
        while heap:
            score, key = heapq.heappop(heap)
            results.append(VectorSearchHit(key, score))
        results.reverse()
        return results


# ========================================================================
# 为了方便导出
# ========================================================================

__all__ = [
    "VectorMath",
    "VectorSearchHit",
    "FileBasedVectorIndex",
    "ChapterEmbeddingIndex",
    "ChunkEmbeddingIndex",
    "quantize_int8",
    "dequantize_int8",
    "dot_product",
    "l2_normalize",
]
