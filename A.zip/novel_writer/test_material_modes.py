from novel_writer.book_pipeline_v4 import ChaishuPipeline4


def test_dynamic_material_mode_sources():
    pipeline = ChaishuPipeline4("1")
    assert pipeline._load_genre_constraints("东方玄幻")
    assert "金手指设计" in pipeline._load_json("analysis.json", {}).get("Analysis", {})


def test_original_template_is_required():
    pipeline = ChaishuPipeline4("1")
    assert "素材设计师" in pipeline._load_original_template("素材设计师.json")



def test_material_outputs_have_required_files():
    pipeline = ChaishuPipeline4("1")
    assert pipeline.out.endswith("CrawledBooks\\1") or pipeline.out.endswith("CrawledBooks/1")
