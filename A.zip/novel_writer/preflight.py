# -*- coding: utf-8 -*-
"""对标 4.1.1 PreflightValidator: 规划四层校验（打包前）"""
import json, os, re
from typing import Dict, List, Set

# 对标 C# NameSeparators: char[] { ',', '，', '、', '\n', '\r', ' ', '\t', ';', '；' }
_NAME_SEPARATORS = [',', '，', '、', '\n', '\r', ' ', '\t', ';', '；']
_NAME_SEP_RE = re.compile("[" + re.escape("".join(_NAME_SEPARATORS)) + "]")


class PreflightValidator:
    """打包前校验：分卷/章节/蓝图引用一致性 + 层级对齐"""

    # 对标 C# IgnoredNames（StringComparer.OrdinalIgnoreCase，共 21 项）
    IGNORED = {"无", "暂无", "空", "-", "/", "none", "n/a", "null",
               "无角色", "无地点", "无势力", "无物品", "未定", "待定", "未知",
               "不详", "略", "省略", "没有", "无相关", "无关联"}

    def __init__(self, project, is_module_enabled=None):
        self.project = project
        self.errors = []
        self.warnings = []
        # 对标 C# PreflightValidator(Func<string, bool>? isModuleEnabled)
        self._is_module_enabled = is_module_enabled

    def run(self) -> bool:
        """对标 C# RunAsync（63-118 行）:
        ValidateVolumeReferences → ValidateChapterReferences → ValidateBlueprintReferences
        → ValidateVolumeChapterRelation → ValidateChapterBlueprintRelation → ValidateUniqueness
        → （无错误才）ValidateHierarchicalAlignment
        """
        try:
            # 加载所有数据（C# LoadAllAsync）
            world = self._load_design("world")
            characters = self._load_design("characters")
            factions = self._load_design("factions")
            locations = self._load_design("locations")
            plot = self._load_design("plot")
            volumes = self._load_plan_list("volumes")
            chapters = self._load_plan_list("chapters")
            blueprints = self._load_all_blueprints()

            # 构建三个 EntityIndex（对标 BuildIndex，含 ids 集合）
            char_index = self._build_full_index(characters)
            fac_index = self._build_full_index(factions)
            loc_index = self._build_full_index(locations)

            # 1. 分卷引用校验
            self.validate_volume_references(volumes, char_index, fac_index, loc_index)

            # 2. 章节引用校验
            self.validate_chapter_references(chapters, char_index, fac_index, loc_index)

            # 3. 蓝图引用校验
            self.validate_blueprint_references(blueprints, char_index, fac_index, loc_index)

            # 4. 卷-章关联
            self.validate_volume_chapter_relation(volumes, chapters)

            # 5. 章-蓝图关联
            self.validate_chapter_blueprint_relation(chapters, blueprints)

            # 6. 唯一性
            self.validate_uniqueness(chapters, blueprints)

            # 7. 层级对齐（蓝图⊆章节、章节⊆卷），仅无错误时执行
            if len(self.errors) == 0:
                self.validate_hierarchical_alignment(
                    volumes, chapters, blueprints, char_index, fac_index, loc_index)
        except Exception as ex:
            self.errors.append(f"预检异常（无法继续打包）: {ex}")

        is_valid = len(self.errors) == 0
        if self.errors:
            print(f"  Preflight: {len(self.errors)} 项错误")
            for e in self.errors[:5]:
                print(f"    ✗ {e}")
        if self.warnings:
            print(f"  Preflight: {len(self.warnings)} 项警告")
            for w in self.warnings[:3]:
                print(f"    ⚠ {w}")
        if is_valid:
            print("  Preflight: 全部检查通过")
        return is_valid

    def _load_all_blueprints(self) -> List[dict]:
        """对标 C# LoadAllAsync<BlueprintData>("Generate/Elements/Blueprint"):
        汇总 plan/blueprints_{chapterId}（含 chapters 未登记但文件存在的）"""
        entities = []
        seen = set()
        for ch in self._load_plan_list("chapters"):
            cid = (ch.get("Id") or "").strip()
            if cid:
                name = f"blueprints_{cid}"
                if name not in seen:
                    seen.add(name)
                    entities.append(name)
        # 兜底：plan 目录下 blueprints_*.json（chapters 缺 Id 时也覆盖，与 C# 目录扫描一致）
        plan_dir = getattr(self.project, "plan_dir", None)
        if plan_dir and os.path.isdir(plan_dir):
            import glob as _glob
            for path in _glob.glob(os.path.join(plan_dir, "blueprints_*.json")):
                name = os.path.splitext(os.path.basename(path))[0]
                if name not in seen:
                    seen.add(name)
                    entities.append(name)
        items = []
        for name in entities:
            for b in self._load_blueprints(name[len("blueprints_"):]):
                if isinstance(b, dict):
                    items.append(b)
        return items

    def _load_design(self, entity: str) -> List[dict]:
        data = self.project.load_design(entity)
        if isinstance(data, dict):
            return data.get("items", [])
        return data or []

    def _load_plan_list(self, entity: str) -> List[dict]:
        data = self.project.load_plan(entity)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return data.get(entity, [])
        return []

    def _load_blueprints(self, chapter_id: str) -> List[dict]:
        if not chapter_id:
            return []
        data = self.project.load_plan(f"blueprints_{chapter_id}")
        if isinstance(data, list):
            return data
        return []

    @staticmethod
    def _build_index(entities: List[dict]) -> dict:
        names = set()
        name_to_id = {}
        for e in entities:
            n = (e.get("Name") or "").strip()
            i = (e.get("Id") or "").strip()
            if n and n not in PreflightValidator.IGNORED:
                names.add(n)
            if n and i:
                name_to_id[n] = i
        return {"names": names, "name_to_id": name_to_id}

    @staticmethod
    def _split_names(val) -> List[str]:
        """对标 C# SplitNames: 按 NameSeparators 切分 + 过滤忽略词 + 去重保序"""
        if not val:
            return []
        if isinstance(val, list):
            raw = [n for n in val]
        elif isinstance(val, str):
            raw = _NAME_SEP_RE.split(val)
        else:
            return []
        out = []
        seen = set()
        for n in raw:
            if not isinstance(n, str):
                n = str(n) if n is not None else ""
            t = n.strip()
            if not t or t in PreflightValidator.IGNORED:
                continue
            if t not in seen:
                seen.add(t)
                out.append(t)
        return out

    def _validate_references(self, entities: List[dict], label_prefix: str,
                             char_idx, fac_idx, loc_idx):
        for ent in entities:
            label = f"{label_prefix}[{ent.get('Name', ent.get('Id', '?'))}]"
            for field, idx, fname in [
                ("ReferencedCharacterNames", char_idx, "出场角色"),
                ("Cast", char_idx, "出场角色"),
                ("ReferencedFactionNames", fac_idx, "涉及势力"),
                ("Factions", fac_idx, "涉及势力"),
                ("ReferencedLocationNames", loc_idx, "涉及地点"),
                ("Locations", loc_idx, "涉及地点"),
            ]:
                names = self._split_names(ent.get(field, ""))
                unmatched = [n for n in names if n not in idx["names"]]
                if unmatched:
                    self.errors.append(f"{label}「{fname}」未映射: {'、'.join(unmatched)}")

    def _validate_volume_chapter(self, volumes: List[dict], chapters: List[dict]):
        if not volumes or not chapters:
            return
        vol_numbers = set()
        for v in volumes:
            vn = v.get("VolumeNumber", 0)
            if vn > 0:
                vol_numbers.add(vn)
        for c in chapters:
            vol = c.get("Volume", "")
            if not vol:
                self.errors.append(f"章节[{c.get('ChapterTitle', c.get('Name','?'))}]「所属卷」为空")
                continue
            m = re.search(r"第\s*(\d+)\s*卷", vol)
            if m:
                vn = int(m.group(1))
            else:
                # try matching by title
                vn = None
                for v in volumes:
                    if v.get("VolumeTitle", "") == vol:
                        vn = v.get("VolumeNumber", 0)
                        break
            if vn is None or vn not in vol_numbers:
                self.errors.append(f"章节[{c.get('ChapterTitle', c.get('Name','?'))}]「所属卷」({vol}) 无法匹配分卷")

    def _validate_hierarchy(self, volumes: List[dict], chapters: List[dict],
                            char_idx, fac_idx, loc_idx):
        """对标 ValidateHierarchicalAlignment: 章节引用⊆卷引用"""
        vol_refs = {}
        for v in volumes:
            vn = v.get("VolumeNumber", 0)
            if vn <= 0:
                continue
            vol_refs[vn] = (
                set(self._normalize_names(v.get("ReferencedCharacterNames", ""), char_idx)),
                set(self._normalize_names(v.get("ReferencedLocationNames", ""), loc_idx)),
                set(self._normalize_names(v.get("ReferencedFactionNames", ""), fac_idx)),
            )
        for c in chapters:
            vol = c.get("Volume", "")
            m = re.search(r"第\s*(\d+)\s*卷", vol)
            vn = int(m.group(1)) if m else 0
            if vn not in vol_refs:
                continue
            vr = vol_refs[vn]
            label = f"第{vn}卷·第{c.get('ChapterNumber',0)}章"
            ch_chars = set(self._normalize_names(c.get("ReferencedCharacterNames", ""), char_idx))
            ch_locs = set(self._normalize_names(c.get("ReferencedLocationNames", ""), loc_idx))
            ch_facs = set(self._normalize_names(c.get("ReferencedFactionNames", ""), fac_idx))
            if vr[0]:
                extra = ch_chars - vr[0]
                if extra:
                    self.errors.append(f"{label}「出场角色」存在未在卷中声明的实体: {'、'.join(extra)}")
            if vr[1]:
                extra = ch_locs - vr[1]
                if extra:
                    self.errors.append(f"{label}「涉及地点」存在未在卷中声明的实体: {'、'.join(extra)}")
            if vr[2]:
                extra = ch_facs - vr[2]
                if extra:
                    self.errors.append(f"{label}「涉及势力」存在未在卷中声明的实体: {'、'.join(extra)}")

    @staticmethod
    def _normalize_names(val, index) -> List[str]:
        names = PreflightValidator._split_names(val)
        result = []
        for n in names:
            nid = index["name_to_id"].get(n, n)
            result.append(nid)
        return result

    @staticmethod
    def _parse_chapter_id(chapter_id):
        """对标 ChapterParserHelper.ParseChapterId: vol{n}_ch{m} / v{n}_c{m} / {n}_{m}"""
        if not chapter_id or not isinstance(chapter_id, str):
            return None
        for pattern in (r"vol(\d+)_ch(\d+)", r"v(\d+)_c(\d+)", r"(\d+)_(\d+)"):
            m = re.search(pattern, chapter_id, re.IGNORECASE if "vol" in pattern or "_c" in pattern else 0)
            if m:
                return (int(m.group(1)), int(m.group(2)))
        return None

    def validate_volume_chapter_relation(self, volumes: List[dict], chapters: List[dict]):
        """对标 ValidateVolumeChapterRelation: 章节「所属卷」必须能匹配到分卷设计"""
        if not volumes or not chapters:
            return
        vol_numbers = {v.get("VolumeNumber", 0) for v in volumes if v.get("VolumeNumber", 0) > 0}
        if not vol_numbers:
            return
        for c in chapters:
            vol = c.get("Volume", "")
            if not vol:
                self.errors.append(
                    f"章节[{c.get('ChapterTitle', c.get('Name','?'))}]「所属卷」字段为空，无法关联到分卷设计")
                continue
            vn = self.try_parse_volume_number(vol)
            if vn is None or vn not in vol_numbers:
                self.errors.append(
                    f"章节[{c.get('ChapterTitle', c.get('Name','?'))}]「所属卷」({vol}) 无法匹配到任何分卷设计")

    def validate_chapter_blueprint_relation(self, chapters: List[dict], blueprints: List[dict]):
        """对标 ValidateChapterBlueprintRelation: 蓝图 ChapterId 为空/格式错/不在章节集合都报错"""
        chapter_id_set = set()
        for c in chapters:
            cn = c.get("ChapterNumber", 0)
            vol = c.get("Volume", "")
            if cn <= 0 or not vol:
                continue
            vn = self.try_parse_volume_number(vol)
            if vn is not None:
                chapter_id_set.add(f"vol{vn}_ch{cn}")

        for b in blueprints:
            label = f"蓝图[{b.get('SceneTitle') or b.get('Name','?')}]"
            cid = (b.get("ChapterId") or "").strip()
            if not cid:
                self.errors.append(f"{label}「关联章节ID」为空")
                continue
            parsed = self._parse_chapter_id(cid)
            if parsed is None:
                self.errors.append(
                    f"{label}「关联章节ID」格式错误: {cid}（应为 vol{{N}}_ch{{M}}）")
                continue
            if cid not in chapter_id_set:
                self.errors.append(
                    f"{label}「关联章节ID」({cid}) 没有对应的章节设计")

    def validate_hierarchical_alignment(self, volumes: List[dict], chapters: List[dict],
                                        blueprints: List[dict],
                                        char_idx, fac_idx, loc_idx):
        """对标 ValidateHierarchicalAlignment: 章节引用⊆卷引用 + 蓝图引用⊆章节引用"""
        # 卷级引用
        vol_refs = {}
        for v in volumes:
            vn = v.get("VolumeNumber", 0)
            if vn <= 0:
                continue
            vol_refs[vn] = (
                self.normalize_to_id_set(self._split_names(v.get("ReferencedCharacterNames", "")), char_idx),
                self.normalize_to_id_set(self._split_names(v.get("ReferencedLocationNames", "")), loc_idx),
                self.normalize_to_id_set(self._split_names(v.get("ReferencedFactionNames", "")), fac_idx),
            )

        # 章节级引用（含 章节⊆卷 校验）
        chapter_refs = {}
        for c in chapters:
            cn = c.get("ChapterNumber", 0)
            vol = c.get("Volume", "")
            if cn <= 0 or not vol:
                continue
            vn = self.try_parse_volume_number(vol)
            if vn is None:
                continue
            chapter_id = f"vol{vn}_ch{cn}"
            ch_chars = self.normalize_to_id_set(self._split_names(c.get("ReferencedCharacterNames", "")), char_idx)
            ch_locs = self.normalize_to_id_set(self._split_names(c.get("ReferencedLocationNames", "")), loc_idx)
            ch_facs = self.normalize_to_id_set(self._split_names(c.get("ReferencedFactionNames", "")), fac_idx)
            chapter_refs[chapter_id] = (vn, ch_chars, ch_locs, ch_facs)

            if vn in vol_refs:
                vr = vol_refs[vn]
                label = f"第{vn}卷·第{cn}章"
                if vr[0]:
                    self.check_subset(ch_chars, vr[0], label, "卷", char_idx, "出场角色")
                if vr[1]:
                    self.check_subset(ch_locs, vr[1], label, "卷", loc_idx, "涉及地点")
                if vr[2]:
                    self.check_subset(ch_facs, vr[2], label, "卷", fac_idx, "涉及势力")

        # 蓝图级引用（蓝图⊆章节）
        for b in blueprints:
            cid = (b.get("ChapterId") or "").strip()
            if not cid or cid not in chapter_refs:
                continue
            _, ch_chars, ch_locs, ch_facs = chapter_refs[cid]
            bp_chars = self.normalize_to_id_set(self._split_names(b.get("Cast", "")), char_idx)
            bp_locs = self.normalize_to_id_set(self._split_names(b.get("Locations", "")), loc_idx)
            bp_facs = self.normalize_to_id_set(self._split_names(b.get("Factions", "")), fac_idx)
            label = f"{cid}·场景{b.get('SceneNumber',0)}"
            if ch_chars:
                self.check_subset(bp_chars, ch_chars, label, "章节", char_idx, "出场角色")
            if ch_locs:
                self.check_subset(bp_locs, ch_locs, label, "章节", loc_idx, "涉及地点")
            if ch_facs:
                self.check_subset(bp_facs, ch_facs, label, "章节", fac_idx, "涉及势力")

    # ---------- 以下方法忠实移植自 4.1.1 PreflightValidator.cs ----------

    @staticmethod
    def _is_ignored(name: str) -> bool:
        return name in PreflightValidator.IGNORED

    def normalize_to_id(self, name_or_id: str, index) -> str:
        """对标 NormalizeToId: 名称优先转 ID，否则原值"""
        trimmed = (name_or_id or "").strip()
        if index["name_to_id"].get(trimmed):
            return index["name_to_id"][trimmed]
        return trimmed

    def find_unmatched(self, names, index) -> List[str]:
        """对标 FindUnmatched: 返回未在索引中定义/登记的名称"""
        if not names:
            return []
        out = []
        for n in names:
            if not n or not n.strip():
                continue
            t = n.strip()
            if t in index.get("names", set()):
                continue
            ids = index.get("ids", set())
            if ids and t in ids:
                continue
            out.append(t)
        # 去重保序
        seen = set()
        uniq = []
        for x in out:
            if x not in seen:
                seen.add(x)
                uniq.append(x)
        return uniq

    def _build_full_index(self, entities: List[dict]) -> dict:
        """比 _build_index 多维护 ids 集合，便于 FindUnmatched 参考"""
        base = self._build_index(entities)
        base["ids"] = set()
        for e in entities:
            i = (e.get("Id") or "").strip()
            if i:
                base["ids"].add(i)
        return base

    def validate_volume_references(self, volumes, char_idx, fac_idx, loc_idx):
        """对标 ValidateVolumeReferences（走 find_unmatched 精确逻辑）"""
        for v in volumes:
            vn = v.get("VolumeNumber", 0)
            if vn <= 0:
                continue
            label = f"第{vn}卷"
            for field, idx, fname in [
                ("ReferencedCharacterNames", char_idx, "涉及角色"),
                ("ReferencedFactionNames", fac_idx, "涉及势力"),
                ("ReferencedLocationNames", loc_idx, "涉及地点"),
            ]:
                names = self._split_names(v.get(field, ""))
                unmatched = self.find_unmatched(names, idx)
                if unmatched:
                    self.errors.append(f"{label}「{fname}」存在未映射名称: {'、'.join(unmatched)}")

    def validate_chapter_references(self, chapters, char_idx, fac_idx, loc_idx):
        """对标 ValidateChapterReferences"""
        for c in chapters:
            vol = c.get("Volume", "")
            label = f"{vol}·第{c.get('ChapterNumber',0)}章" if vol else f"章节[{c.get('ChapterTitle', c.get('Name','?'))}]"
            for field, idx, fname in [
                ("ReferencedCharacterNames", char_idx, "出场角色"),
                ("ReferencedFactionNames", fac_idx, "涉及势力"),
                ("ReferencedLocationNames", loc_idx, "涉及地点"),
            ]:
                names = self._split_names(c.get(field, ""))
                unmatched = self.find_unmatched(names, idx)
                if unmatched:
                    self.errors.append(f"{label}「{fname}」存在未映射名称: {'、'.join(unmatched)}")

    def validate_blueprint_references(self, blueprints, char_idx, fac_idx, loc_idx):
        """对标 ValidateBlueprintReferences"""
        for b in blueprints:
            label = f"{b.get('ChapterId','')}·场景{b.get('SceneNumber',0)}" if b.get('ChapterId') \
                else f"蓝图[{b.get('SceneTitle', b.get('Name','?'))}]"
            for field, idx, fname in [
                ("Cast", char_idx, "出场角色"),
                ("Locations", loc_idx, "涉及地点"),
                ("Factions", fac_idx, "涉及势力"),
            ]:
                names = self._split_names(b.get(field, ""))
                unmatched = self.find_unmatched(names, idx)
                if unmatched:
                    self.errors.append(f"{label}「{fname}」存在未映射名称: {'、'.join(unmatched)}")

    def validate_uniqueness(self, chapters, blueprints):
        """对标 ValidateUniqueness: 同级章节号/蓝图场景号唯一性"""
        from collections import defaultdict
        ch_dup = defaultdict(list)
        for c in chapters:
            cn = c.get("ChapterNumber", 0)
            vol = c.get("Volume", "")
            if cn <= 0:
                continue
            vn = self.try_parse_volume_number(vol)
            if vn is None:
                continue
            ch_dup[(vn, cn)].append(c.get("ChapterTitle") or c.get("Name") or c.get("Id", ""))
        for (vn, cn), names in ch_dup.items():
            if len(names) > 1:
                self.errors.append(
                    f"第{vn}卷·第{cn}章存在 {len(names)} 条重复章节定义：{'、'.join(names)}。"
                    "同一卷的章节号必须唯一，请删除多余项后重新打包。")

        bp_dup = defaultdict(list)
        for b in blueprints:
            cid = (b.get("ChapterId") or "").strip()
            sn = b.get("SceneNumber", 0)
            if not cid or sn <= 0:
                continue
            bp_dup[(cid, sn)].append(b.get("SceneTitle") or b.get("Name") or b.get("Id", ""))
        for (cid, sn), names in bp_dup.items():
            if len(names) > 1:
                self.errors.append(
                    f"{cid}·场景{sn} 存在 {len(names)} 条重复蓝图定义：{'、'.join(names)}。"
                    "同一章节的场景号必须唯一，请删除多余项后重新打包。")

    def normalize_to_id_set(self, names, index) -> Set[str]:
        """对标 NormalizeToIdSet: 名称集合归一化为 ID 集合"""
        out = set()
        if not names:
            return out
        for n in names:
            if not n:
                continue
            t = n
            if index["name_to_id"].get(t):
                out.add(index["name_to_id"][t])
            else:
                ids = index.get("ids", set())
                if ids and t in ids:
                    out.add(t)
        return out

    def check_subset(self, sub, sup, sub_label, sup_label, index, field):
        """对标 CheckSubset: 校验 sub⊆sup，并给出未声明项"""
        if not sub:
            return
        escaped = [x for x in sub if x not in sup]
        if not escaped:
            return
        id_to_name = {}
        for name, eid in index["name_to_id"].items():
            id_to_name.setdefault(eid, name)
        displayed = [id_to_name.get(x, x) for x in escaped]
        self.errors.append(
            f"{sub_label}「{field}」存在 {{{('、'.join(displayed))}}} 未在所属{sup_label}中声明"
            f"（必须先在{sup_label}级「{field}」中加入这些项，然后再在{sub_label}级使用）")

    @staticmethod
    def try_parse_volume_number(volume_text):
        """对标 TryParseVolumeNumber: 解析 '第X卷' -> int，失败返回 None（兼容中文数字）"""
        if not volume_text:
            return None
        t = volume_text.strip()
        i1 = t.find('第')
        i2 = t.find('卷')
        if i1 != 0 or i2 <= i1:
            return None
        inner = t[i1 + 1:i2].strip()
        if not inner:
            return None
        if inner.isdigit():
            n = int(inner)
            return n if n > 0 else None
        cn = PreflightValidator.try_parse_chinese_number(inner)
        return cn if (cn is not None and cn > 0) else None

    @staticmethod
    def try_parse_chinese_number(s):
        """对标 TryParseChineseNumber: 中文数字->int"""
        if not s:
            return None
        digits = {'零': 0, '〇': 0, '一': 1, '壹': 1, '二': 2, '两': 2, '贰': 2,
                  '三': 3, '叁': 3, '四': 4, '肆': 4, '五': 5, '伍': 5,
                  '六': 6, '陆': 6, '七': 7, '柒': 7, '八': 8, '捌': 8,
                  '九': 9, '玖': 9}
        units = {'十': 10, '拾': 10, '百': 100, '佰': 100, '千': 1000, '仟': 1000,
                 '万': 10000, '萬': 10000}
        result = 0
        current = 0
        for ch in s:
            if ch in digits:
                current = digits[ch]
                continue
            if ch in units:
                unit = units[ch]
                if current == 0:
                    current = 1
                result += current * unit
                current = 0
            else:
                return None
        n = result + current
        return n if n > 0 else None

    @staticmethod
    def get_module_path_from_relative_path(relative_path):
        """对标 GetModulePathFromRelativePath: 'Design/Elements/Xxx' -> 'Design/Elements'（前两段）"""
        if not relative_path:
            return ""
        parts = [p for p in relative_path.split('/') if p]
        return f"{parts[0]}/{parts[1]}" if len(parts) >= 2 else ""
