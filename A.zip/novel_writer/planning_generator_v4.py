# -*- coding: utf-8 -*-
"""四层规划生成器 v4 — 对标 4.1.1 OutlineViewModel + VolumeDesignViewModel + ChapterViewModel + BlueprintViewModel

使用 "小说创作者" 系统模板 + ActiveModuleHint 裁剪 + 结构化上下文
"""
import asyncio
import json
import os
import re
from typing import Callable, Dict, List, Optional

from .services.context_service import ContextService
from .services.outline_service import OutlineService
from .services.volume_design_service import VolumeDesignService
from .services.chapter_service import ChapterService
from .services.volume_design_generator import VolumeDesignGenerator
from .services.chapter_generator import ChapterGenerator
from .services.blueprint_generator import BlueprintGenerator
from .models import (
    OutlineData, VolumeDesignData, ChapterData, BlueprintData, short_id, now_str,
)

# 对标 EntityFieldMeta
OUTLINE_FIELDS = {
    "名称": "Name", "总章节数": "TotalChapterCount", "一句话大纲": "OneLineOutline",
    "情感基调": "EmotionalTone", "哲学母题": "PhilosophicalMotif", "主题思想": "Theme",
    "核心冲突": "CoreConflict", "结局/目标状态": "EndingState",
    "卷/幕划分": "VolumeDivision", "大纲总览": "OutlineOverview",
}
VOLUME_FIELDS = {
    "名称": "Name", "卷序号": "VolumeNumber", "卷标题": "VolumeTitle",
    "卷主题": "VolumeTheme", "卷阶段目标": "StageGoal",
    "卷主冲突": "MainConflict", "压力来源": "PressureSource",
    "关键转折": "KeyEvents", "卷开篇状态": "OpeningState", "卷收束状态": "EndingState",
    "章节分配总览": "ChapterAllocationOverview", "剧情分配": "PlotAllocation",
    "章节生成提示": "ChapterGenerationHints",
    "出场角色": "ReferencedCharacterNames", "涉及势力": "ReferencedFactionNames",
    "涉及地点": "ReferencedLocationNames",
}
CHAPTER_FIELDS = {
    "名称": "Name", "章节标题": "ChapterTitle",
    "章节目标": "MainGoal", "章节主题": "ChapterTheme",
    "读者体验目标": "ReaderExperienceGoal", "阻力来源": "ResistanceSource",
    "关键转折": "KeyTurn", "钩子": "Hook",
    "世界信息释放": "WorldInfoDrop", "角色弧推进": "CharacterArcProgress",
    "主线推进": "MainPlotProgress", "伏笔": "Foreshadowing",
    "出场角色": "ReferencedCharacterNames", "涉及势力": "ReferencedFactionNames",
    "涉及地点": "ReferencedLocationNames",
}
BLUEPRINT_FIELDS = {
    "名称": "Name", "场景标题": "SceneTitle",
    "一句话结构": "OneLineStructure", "节奏曲线": "PacingCurve",
    "视点角色": "PovCharacter", "开场": "Opening", "发展": "Development",
    "转折": "Turning", "结尾": "Ending", "信息释放": "InfoDrop",
    "物品线索": "ItemsClues", "出场角色": "Cast",
    "涉及地点": "Locations", "涉及势力": "Factions",
}

MODULE_HINTS = {"outline": "战略大纲", "volume": "分卷设计",
                 "chapter": "章节规划", "blueprint": "章节蓝图"}


class PlanningGeneratorV4:
    """对标 4.1.1: "小说创作者" 模板 + ActiveModuleHint + ContextProvider

    整合 OutlineViewModel / VolumeDesignViewModel / ChapterViewModel / BlueprintViewModel
    的 AI 生成逻辑，使用统一的 Prompt 模板 + 模块裁剪 + 结构化上下文注入
    """

    def __init__(
        self,
        ai_chat: Callable,
        outline_service: OutlineService,
        volume_service: VolumeDesignService,
        chapter_service: ChapterService,
        context_service: ContextService,
        prompt_dir: str = None,
        character_names: List[str] = None,
        faction_names: List[str] = None,
        location_names: List[str] = None,
    ):
        self.ai = ai_chat
        self._outline_service = outline_service
        self._volume_service = volume_service
        self._chapter_service = chapter_service
        self._context_service = context_service
        self._char_names = character_names or []
        self._fac_names = faction_names or []
        self._loc_names = location_names or []
        self.outline_context_include = {"materials", "worldview", "characters", "factions", "plot_rules"}
        self.outline_sources = {"materials": "project", "world": "project", "characters": "project", "factions": "project", "plot": "project"}

        self.template = self._load_template(prompt_dir)

        # 子生成器
        self._volume_gen = VolumeDesignGenerator(
            ai_chat, outline_service, volume_service, context_service,
            self._char_names, self._fac_names, self._loc_names,
        )
        self._chapter_gen = ChapterGenerator(
            ai_chat, outline_service, volume_service, chapter_service, context_service,
            lambda: self._char_names,
            lambda: self._fac_names,
            lambda: self._loc_names,
        )
        self._blueprint_gen = BlueprintGenerator(
            ai_chat, outline_service, volume_service, chapter_service, context_service,
            lambda: self._char_names,
            lambda: self._fac_names,
            lambda: self._loc_names,
        )

    @property
    def volume_generator(self) -> VolumeDesignGenerator:
        return self._volume_gen

    @property
    def chapter_generator(self) -> ChapterGenerator:
        return self._chapter_gen

    @property
    def blueprint_generator(self) -> BlueprintGenerator:
        return self._blueprint_gen

    # ---- 模板加载 ----
    def _load_template(self, prompt_dir: str = None) -> str:
        if not prompt_dir:
            prompt_dir = os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "prompts")
        for fname in ["小说创作者.json", "\u5c0f\u8bf4\u521b\u4f5c\u8005.json"]:
            path = os.path.join(prompt_dir, fname)
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    items = json.load(f)
                if isinstance(items, list) and items:
                    return items[0].get("SystemPrompt", "")
        return ""

    # ---- Prompt 构建（对标 GetAIGenerationConfig） ----
    def _build_prompt(
        self, module: str, variables: dict, context: str = ""
    ) -> str:
        """对标 AIGenerationConfig:
        1. 模板变量替换 {大纲名称}{章节标题}{场景标题}
        2. ActiveModuleHint 裁剪
        3. 上下文注入
        """
        system = self.template
        for var in ["大纲名称", "章节标题", "场景标题"]:
            system = system.replace(f"{{{var}}}", variables.get(var, ""))

        hint = MODULE_HINTS.get(module)
        if hint:
            pattern = rf'<module_section id="{hint}">.*?</module_section>'
            m = re.search(pattern, system, re.S)
            if m:
                generic = system.split("【通用要求】")
                header = system.split("<module_section")[0]
                system = (
                    header.strip() + "\n\n" + m.group(0)
                    + "\n\n【通用要求】" + (generic[1] if len(generic) > 1 else "")
                )

        if context:
            system += "\n\n" + context

        return system

    def _build_user_prompt(self, module: str) -> str:
        """构建 JSON 输出合约（对标 OutputFields）"""
        field_map = {
            "outline": OUTLINE_FIELDS,
            "volume": VOLUME_FIELDS,
            "chapter": CHAPTER_FIELDS,
            "blueprint": BLUEPRINT_FIELDS,
        }[module]
        return json.dumps(
            {cn: f"【{cn}】的值" for cn in field_map},
            ensure_ascii=False, indent=2,
        )

    # ---- 核心生成方法 ----
    def _generate(
        self, module: str, variables: dict, context: str = ""
    ) -> dict:
        system = self._build_prompt(module, variables, context)
        user = self._build_user_prompt(module)
        text = self.ai(system, user, category=f"规划_{module}")
        return self._extract_json(text)

    @staticmethod
    def _extract_json(text: str):
        if not text:
            return None
        t = text.strip()
        if t.startswith("```"):
            t = re.sub(r"^```(?:json)?\s*\n?", "", t)
            t = re.sub(r"\n?\s*```\s*$", "", t)
        if t.startswith("["):
            try:
                items = json.loads(t)
                if isinstance(items, list) and items:
                    return items[0]
            except json.JSONDecodeError:
                pass
        start = t.find("{")
        if start == -1:
            return None
        depth, in_str, esc = 0, 0, 0
        for i in range(start, len(t)):
            ch = t[i]
            if in_str:
                if esc:
                    esc = 0
                elif ch == "\\":
                    esc = 1
                elif ch == '"':
                    in_str = 0
                continue
            if ch == '"':
                in_str = 1
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(t[start:i + 1])
                    except json.JSONDecodeError:
                        pass
        try:
            return json.loads(t)
        except json.JSONDecodeError:
            return None

    # ---- 对外接口（对标 OutlineViewModel.GetAIGenerationConfig） ----
    def generate_outline(
        self, total_chapters: int, context: str = "", category_name: str = ""
    ) -> OutlineData:
        """对标 OutlineViewModel AIGenerate: 战略大纲生成

        context 由 ContextProvider (GetEnhancedOutlineContextAsync) 构建
        """
        # 对标 OutlineViewModel 的 ContextProvider
        outline_context = self._build_outline_context(total_chapters)

        data = self._generate(
            "outline",
            {"大纲名称": "全书战略大纲", "章节标题": "", "场景标题": ""},
            outline_context + ("\n\n" + context if context else ""),
        )
        if not data:
            data = {}

        return OutlineData(
            Id=short_id("O"), Name=data.get("名称", "全书大纲"),
            TotalChapterCount=int(data["总章节数"]) if data.get("总章节数") else 0,
            OneLineOutline=data.get("一句话大纲", ""),
            EmotionalTone=data.get("情感基调", ""),
            PhilosophicalMotif=data.get("哲学母题", ""),
            Theme=data.get("主题思想", ""),
            CoreConflict=data.get("核心冲突", ""),
            EndingState=data.get("结局/目标状态", ""),
            VolumeDivision=data.get("卷/幕划分", ""),
            OutlineOverview=data.get("大纲总览", ""),
            CreatedAt=now_str(), UpdatedAt=now_str(),
            DependencyModuleVersions={},
        )

    def _build_outline_context(self, total_chapters: int) -> str:
        """对标 OutlineViewModel.GetEnhancedOutlineContextAsync"""
        sb = []

        # 基础上下文（对标 ContextService.GetOutlineStructureContextAsync）
        try:
            self._context_service.outline_sources = self.outline_sources
            base_ctx = asyncio.run(self._context_service.get_outline_structure_context_async(self.outline_context_include))
            if base_ctx:
                sb.append(base_ctx)
                sb.append("")
        except Exception:
            pass

        # 分卷结构引用
        try:
            vol_list = self._get_volume_list_context()
            if vol_list:
                sb.append('<volume_structure_reference mandatory="true">')
                sb.append("以下是用户已规划的分卷结构，大纲总览必须与此结构完全一致，不得另起一套章节规划：")
                sb.append(vol_list)
                sb.append("</volume_structure_reference>")
                sb.append("")
        except Exception:
            pass

        # 剧情规则卷数约束（对标 PlotRulesViewModel 的 volume count 约束）
        try:
            plot_rules = self._get_plot_rules_context()
            if plot_rules:
                sb.append('<volume_count_constraint>')
                sb.append(plot_rules)
                sb.append('</volume_count_constraint>')
                sb.append("")
        except Exception:
            pass

        # 章节数约束
        if total_chapters > 0:
            sb.append(f'<chapter_count_constraint count="{total_chapters}" mandatory="true">')
            sb.append(f"用户已设定全书总章节数为{total_chapters}章。各卷章节数之和必须严格等于{total_chapters}，不得使用'约X章'等模糊表达。")
            sb.append("</chapter_count_constraint>")
            sb.append("")

        # C# 从启用剧情规则的 TargetVolume 最大值推导总卷数
        try:
            project_dir = self._outline_service._project_dir
            from ..storage import Project
            project = Project(os.path.basename(project_dir.rstrip("/\\")), os.path.dirname(project_dir))
            raw = project.load_design("plot")
            items = raw.get("items", []) if isinstance(raw, dict) else (raw or [])
            volume_numbers = []
            for item in items:
                if not item.get("IsEnabled", True):
                    continue
                try:
                    value = int(str(item.get("TargetVolume", "")).strip())
                    if value > 0:
                        volume_numbers.append(value)
                except (TypeError, ValueError):
                    continue
            if volume_numbers:
                total_volumes = max(volume_numbers)
                sb.append(f'<volume_count_constraint count="{total_volumes}">')
                sb.append(f"剧情规则已设定全书共{total_volumes}卷，卷/幕划分必须严格按照{total_volumes}卷来规划，不得多于或少于此数。")
                sb.append("</volume_count_constraint>")
                sb.append("")
        except Exception:
            pass

        sb.append('<field_constraints mandatory="true">')
        sb.append('1. 「总章节数」必须为整数（仅数字），代表全书计划写的总章节数量。')
        sb.append('2. 「卷/幕划分」「大纲总览」如有多条，请在字符串内用换行分条。')
        sb.append('3. 若已给出总卷数约束，卷/幕划分必须与总卷数一致，不得多于或少于。')
        sb.append('4. 避免编造未在上下文中出现的专有名词；如需新增，请在对应字段中先定义其含义。')
        sb.append('5. 若 volume_structure_reference 中已有各卷章节范围，大纲总览叙述的章节分配必须与之完全一致，不得另行分配章节数量。')
        sb.append('6. 「卷/幕划分」必须按可解析格式输出：每行一条，格式为"第N卷：第X-Y章"（例如 "第1卷：第1-80章"），各卷章节范围之和必须精确等于总章节数，第1卷起始章必须为1，相邻两卷必须连续无间隔。此字段是下游分卷设计自动分配章节的权威来源，必须精确填写。')
        sb.append("</field_constraints>")
        sb.append("")

        return "\n".join(sb)

    def _get_volume_list_context(self) -> str:
        """获取已有分卷列表（对标 GetVolumeDesignListAsync）"""
        vols = self._volume_service.get_all_volume_designs()
        if not vols:
            return ""
        lines = []
        for v in vols:
            lines.append(f"<item id=\"{v.Id}\">")
            lines.append(f"  第{v.VolumeNumber}卷：{v.VolumeTitle}")
            if v.StartChapter > 0 and v.EndChapter > 0:
                lines.append(f"  章节范围：第{v.StartChapter}章 ~ 第{v.EndChapter}章")
            lines.append(f"  主题：{v.VolumeTheme}")
            lines.append(f"  阶段目标：{v.StageGoal}")
            lines.append("</item>")
        return "\n".join(lines)

    def _get_plot_rules_context(self) -> str:
        """获取剧情规则卷数约束（对标 PlotRulesViewModel 的 volume count 约束）"""
        try:
            project_dir = self._outline_service._project_dir
            from ..storage import Project
            project = Project(os.path.basename(project_dir.rstrip("/\\")), os.path.dirname(project_dir))
            plot_data = project.load_design("plot")
            items = plot_data if isinstance(plot_data, list) else plot_data.get("items", []) if isinstance(plot_data, dict) else []
            filtered = [i for i in items if i.get("IsEnabled", True) and i.get("TargetVolume", 0) > 0]
            if not filtered:
                return ""
            lines = []
            for p in filtered:
                ln = p.get("OneLineSummary", "") or p.get("Name", "")
                lines.append(f"  <rule id=\"{p.get('Id', '')}\" target_volume=\"{p.get('TargetVolume', 0)}\">")
                lines.append(f"    目标卷: {p.get('TargetVolume', 0)}")
                if ln:
                    lines.append(f"    概要: {ln}")
                lines.append("  </rule>")
            return "\n".join(lines)
        except Exception:
            return ""

    # ---- 分卷生成（对标 VolumeDesignViewModel.AIGenerate） ----
    async def generate_volume_async(
        self, volume_number: int, start: int, end: int, category_name: str,
        system_prompt: str = None
    ) -> VolumeDesignData:
        """使用 VolumeDesignGenerator 生成单卷"""
        return await self._volume_gen.generate_volume_async(
            volume_number, start, end, end - start + 1,
            system_prompt or self.template, category_name,
        )

    # ---- 章节生成（对标 ChapterViewModel.AIGenerate） ----
    async def generate_chapter_batch_async(
        self, chapter_numbers, category_name, volume_title, volume_number,
        system_prompt: str = None
    ):
        return await self._chapter_gen.generate_batch_async(
            chapter_numbers, category_name, volume_title, volume_number,
            system_prompt or self.template)

    async def generate_chapter_async(
        self, chapter_number: int, category_name: str, volume_title: str,
        volume_number: int, system_prompt: str = None
    ) -> ChapterData:
        return await self._chapter_gen.generate_chapter_async(
            chapter_number, category_name, volume_title, volume_number,
            system_prompt or self.template,
        )

    # ---- 蓝图生成（对标 BlueprintViewModel.AIGenerate） ----
    async def generate_blueprint_async(
        self, chapter_id: str, category_name: str, scene_number: int,
        system_prompt: str = None
    ) -> BlueprintData:
        return await self._blueprint_gen.generate_blueprint_async(
            chapter_id, category_name, scene_number,
            system_prompt or self.template,
        )

    # ---- 同步封装（供 pipeline / server 使用，工作线程内跑事件循环） ----

    @staticmethod
    def _run_async(coro):
        """在当前线程安全运行协程（无事件循环时新建）"""
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    return pool.submit(asyncio.run, coro).result()
            return loop.run_until_complete(coro)
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                return loop.run_until_complete(coro)
            finally:
                asyncio.set_event_loop(None)

    def generate_volume(
        self, volume_number: int, start: int, end: int, category_name: str,
        system_prompt: str = None
    ) -> VolumeDesignData:
        return self._run_async(self.generate_volume_async(
            volume_number, start, end, category_name, system_prompt))

    def generate_chapter(
        self, chapter_number: int, category_name: str, volume_title: str,
        volume_number: int, system_prompt: str = None
    ) -> ChapterData:
        return self._run_async(self.generate_chapter_async(
            chapter_number, category_name, volume_title, volume_number, system_prompt))

    def generate_chapter_batch(
        self, chapter_numbers, category_name: str, volume_title: str,
        volume_number: int, system_prompt: str = None
    ) -> List[ChapterData]:
        return self._run_async(self.generate_chapter_batch_async(
            chapter_numbers, category_name, volume_title, volume_number, system_prompt))

    def generate_blueprint(
        self, chapter_id: str, category_name: str, scene_number: int,
        system_prompt: str = None
    ) -> BlueprintData:
        return self._run_async(self.generate_blueprint_async(
            chapter_id, category_name, scene_number, system_prompt))


# ---- 辅助函数 ----
def _split(val):
    if not val or not isinstance(val, str):
        return []
    return [v.strip() for v in re.split(r"[、，,\n]", val) if v.strip()]


def _strip_prefix(title: str, suffix: str) -> str:
    if not title:
        return title
    return re.sub(rf"^第\s*\d+\s*{suffix}\s*[：:]?\s*", "", title).strip()


def _parse_int(val) -> int:
    if isinstance(val, int):
        return val
    if not val or not isinstance(val, str):
        return 0
    s = val.strip()
    try:
        return int(s)
    except ValueError:
        pass
    cn = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}
    if s in cn:
        return cn[s]
    digits = "".join(re.findall(r"\d+", s))
    if digits:
        return int(digits)
    return 0