﻿# -*- coding: utf-8 -*-
"""故事骨架 — 对标 Toonflow script_execution_skeleton.md（内联原文）"""
import json
import os
import re
from typing import List, Dict

# 加载骨架 prompt（420行，对标 Toonflow 原文）
_SKILL_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "skeleton_prompt.md")
if os.path.exists(_SKILL_PATH):
    with open(_SKILL_PATH, "r", encoding="utf-8") as _f:
        SKELETON_SYSTEM_PROMPT = _f.read()
else:
    SKELETON_SYSTEM_PROMPT = "# 骨架 prompt 文件未找到"

OUTPUT_FORMAT_SPEC = """
你必须使用如下XML格式写入工作区：
<storySkeleton>故事骨架内容</storySkeleton>
"""


class StorySkeleton:
    def __init__(self, ai_client, events: List[dict], out_dir: str,
                 total_episodes: int = 0, episode_seconds: int = 120,
                 genre: str = "玄幻", free_episodes: int = 3,
                 aspect_ratio: str = "9:16"):
        self.ai = ai_client
        self.events = events
        self.out_dir = out_dir
        self.total_episodes = total_episodes
        self.episode_seconds = episode_seconds
        self.genre = genre
        self.free_episodes = free_episodes
        self.aspect_ratio = aspect_ratio
        self.data: dict = {}
        self._conversation_memory: List[dict] = []

    def _project_config_text(self) -> str:
        return (
            f"项目配置（强制）:\n"
            f"- 题材类别：{self.genre}\n"
            f"- 总集数：{self.total_episodes or 10} 集\n"
            f"- 单集时长：{self.episode_seconds} 秒\n"
            f"- 宽高比：{self.aspect_ratio}\n"
            f"- 付费策略：前 {self.free_episodes} 集免费\n"
            f"分集表行数必须恰好等于总集数，禁止自行增减。"
        )

    def _get_tools(self) -> list:
        return [
            {"type": "function", "function": {"name": "get_planData", "description": "获取已有的故事骨架工作区内容", "parameters": {"type": "object", "properties": {}, "required": []}}},
            {"type": "function", "function": {"name": "get_novel_events", "description": "获取指定章节的事件表", "parameters": {"type": "object", "properties": {"ids": {"type": "array", "items": {"type": "integer"}}}, "required": ["ids"]}}},
            {"type": "function", "function": {"name": "get_novel_text", "description": "获取指定章节的原文内容", "parameters": {"type": "object", "properties": {"chapter_range": {"type": "string"}}, "required": ["chapter_range"]}}},
            {"type": "function", "function": {"name": "get_script_content", "description": "获取已有剧本内容", "parameters": {"type": "object", "properties": {"ids": {"type": "array", "items": {"type": "string"}}}, "required": ["ids"]}}},
        ]

    def build(self, prompt: str = "") -> dict:
        if not prompt:
            prompt = f"请基于事件表构建{self.genre}题材的故事骨架（共{self.total_episodes or 10}集，每集{self.episode_seconds}秒）"
        # 对标 Toonflow: 引导 AI 取全书关键章
        prompt += f"\n（事件表共{len(self.events)}章，请通过 get_novel_events 获取首尾、转折点、高潮等关键章事件）"
        user = prompt + OUTPUT_FORMAT_SPEC

        self.ai.set_tools({
            "get_planData": self._tool_get_planData,
            "get_novel_events": self._tool_get_novel_events,
            "get_novel_text": self._tool_get_novel_text,
            "get_script_content": self._tool_get_script_content,
        })

        from .event_extractor import _strip_think
        try:
            resp = self.ai.chat_with_tools(
                SKELETON_SYSTEM_PROMPT, user, tools=self._get_tools(),
                category="故事骨架",
                messages=self._conversation_memory if self._conversation_memory else None
            )
            self._conversation_memory.append({"role": "assistant", "content": resp})
            # 只保留最近 3 轮防止上下文溢出
            if len(self._conversation_memory) > 3:
                self._conversation_memory = self._conversation_memory[-3:]
            resp = _strip_think(resp)
            self.data = self._parse_skeleton(resp)
            if self.data: self._save()
            return self.data
        except Exception as e:
            print(f"  故事骨架构建失败: {e}")
            return {}

    def _tool_get_planData(self, args: dict) -> str:
        s = self.data.get("markdown", "") if self.data else ""
        review = self.data.get("review", "") if self.data else ""
        if review:
            s = s + "\n\n## 审核报告\n" + review
        return s if s else "(工作区为空)"

    def _tool_get_novel_events(self, args: dict) -> str:
        ids = args.get("ids", [])
        print(f"[骨架] AI请求章节事件: ids={ids}", flush=True)
        if not ids: return "错误: 必须指定 ids 参数"
        lines = []
        for n in ids:
            if 1 <= n <= len(self.events):
                e = self.events[n - 1]
                lines.append(f"| {e.get('chapter','')} | {e.get('characters','')} | {e.get('event','')} | {e.get('mainline','')} | {e.get('density','')} | {e.get('emotion','')} |")
        result = "\n".join(lines) if lines else f"(无: ids={ids})"
        return result

    def _tool_get_novel_text(self, args: dict) -> str:
        return "(骨架阶段不需要原文)"

    def _tool_get_script_content(self, args: dict) -> str:
        return "(骨架阶段无已有剧本)"

    @staticmethod
    def _parse_skeleton(text: str) -> dict:
        result = {"raw": text}
        m = re.search(r"<storySkeleton>(.*?)</storySkeleton>", text, re.DOTALL | re.IGNORECASE)
        result["markdown"] = m.group(1).strip() if m else text.strip()
        return result

    def _save(self):
        os.makedirs(self.out_dir, exist_ok=True)
        with open(os.path.join(self.out_dir, "story_skeleton.json"), "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)

    def load(self) -> dict:
        path = os.path.join(self.out_dir, "story_skeleton.json")
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                self.data = json.load(f)
        return self.data

    def get_markdown(self) -> str:
        return self.data.get("markdown", "")

    def verify(self) -> dict:
        if not self.data or not self.data.get("markdown"):
            return {"error": "请先构建骨架"}
        # 加载监督 prompt（对标 Toonflow 原文）
        _sup_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "supervision_prompt.md")
        if os.path.exists(_sup_path):
            with open(_sup_path, "r", encoding="utf-8") as _f:
                review_system = _f.read()
        else:
            review_system = "# 监督层 Agent\n请审核以下故事骨架质量，按 A/B/C/D 评分。"
        user = f"## 骨架内容\n{self.data['markdown'][:8000]}\n\n请审核并按报告格式输出。"
        try:
            resp = self.ai.chat(review_system, user, category="骨架审核")
            self.data["review"] = resp
            self._save()
            return {"review": resp}
        except Exception as e:
            return {"error": str(e)}
