# -*- coding: utf-8 -*-
"""决策层 Agent — 对标 Toonflow scriptAgent 决策调度（script_agent_decision.md）

协调三个子 Agent:
- run_sub_agent_events: 调用 EventExtractor
- run_sub_agent_skeleton: 调用 StorySkeleton
- run_sub_agent_script: 调用 ScriptGenerator

对标 Toonflow 的决策层模式:
- 决策层接收用户意图 → 调度子 Agent
- 子 Agent 接收 prompt 参数 → 执行 → 返回结果
- 助理消息由决策层注入
"""
import json
import os
from typing import List, Dict, Callable


class DecisionAgent:
    """对标 Toonflow scriptAgent 决策调度层"""

    def __init__(self, ai_client, book_id: str = "1", data_root: str = "",
                 plot_out_dir: str = ""):
        self.ai = ai_client
        self.book_id = book_id
        self.data_root = data_root
        self.plot_out_dir = plot_out_dir
        self._sub_agents = {}  # name → agent instance
        self._results = {}     # name → last result

    def register(self, name: str, agent):
        """对标 Toonflow: 注册子 Agent"""
        self._sub_agents[name] = agent

    def dispatch(self, agent_name: str, prompt: str = "") -> dict:
        """对标 Toonflow decision agent 调用 run_sub_agent_XXX

        Args:
            agent_name: "skeleton" | "script"
            prompt: 决策层传递的指令（对标 Toonflow 的 prompt 参数，≤100字）
        """
        agent = self._sub_agents.get(agent_name)
        if not agent:
            return {"error": f"未知子 Agent: {agent_name}"}

        # 构建默认 prompt（对标 Toonflow decision agent）
        if not prompt:
            if agent_name == "skeleton":
                total = getattr(agent, 'total_episodes', 0) or 10
                genre = getattr(agent, 'genre', '玄幻')
                secs = getattr(agent, 'episode_seconds', 120)
                prompt = f"请基于事件表构建{genre}题材的故事骨架（共{total}集，每集{secs}秒）"
            elif agent_name == "script":
                prompt = "请基于故事骨架生成剧本"

        try:
            if agent_name == "skeleton":
                result = agent.build(prompt=prompt)
            elif agent_name == "script":
                result = agent.generate_all()
            else:
                result = {}

            self._results[agent_name] = result
            return {"success": True, "agent": agent_name, "result": result}
        except Exception as e:
            return {"success": False, "agent": agent_name, "error": str(e)}

    def _build_assistant_message(self, agent_name: str) -> str:
        """对标 Toonflow decision agent 构建 assistant 预设消息"""
        parts = ["## 可用数据"]

        if "events" in self._sub_agents:
            ext = self._sub_agents.get("events")
            if ext and hasattr(ext, 'total'):
                parts.append(f"事件表已就绪（共 {ext.total} 章）")

        if agent_name == "skeleton":
            if "events" in self._results:
                events = self._results["events"]
                n = len(events) if isinstance(events, list) else 0
                parts.append(f"事件提取已完成: {n} 章")
                parts.append(f"章节数量：{n} 章")

        if agent_name == "script":
            if "skeleton" in self._results:
                sk = self._results["skeleton"]
                if sk and isinstance(sk, dict):
                    chapters = sk.get("chapters", [])
                    parts.append(f"骨架已就绪: {len(chapters)} 集")
                    # 可用剧本列表
                    script_names = [f"EP{i:02d}" for i in range(1, min(len(chapters) + 1, 6))]
                    parts.append(f"## 可用剧本(ID:名称)\n" + ",".join(script_names))

            if "events" in self._results:
                events = self._results["events"]
                parts.append(f"章节数量：{len(events) if isinstance(events, list) else 0} 章")

        return "\n".join(parts)

    def get_result(self, agent_name: str):
        return self._results.get(agent_name)
