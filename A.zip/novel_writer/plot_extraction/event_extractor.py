# -*- coding: utf-8 -*-
"""事件提取器 — 对标 Toonflow cleanNovel.ts + getPrompts.ts（单线程版）"""
import json
import os
import re
from typing import List, Dict, Callable

# 对标 getPrompts.ts type=="event"
EVENT_SYSTEM_PROMPT = """# 事件提取指令

你是小说文本分析助手。用户每次提供一个章节的原文，你提取该章的结构化事件信息。

## 输出约束（最高优先级，违反任何一条即为失败）

1. 你的完整回复只有一行，以 | 开头、以 | 结尾，恰好 7 个字段
2. 回复的第一个字符必须是 |，最后一个字符必须是 |
3. | 之前不许有任何字符——没有引导语、没有解释
4. | 之后不许有任何字符——没有总结、没有提取说明
5. 不输出表头行、分隔线、Markdown 标题、emoji、代码块标记

## 输出格式

| 第X章 {章节标题} | {涉及角色} | {核心事件} | {主线关系} | {信息密度} | {预估集长} | {情绪强度} |

## 字段规范

| 字段 | 格式要求 | 示例 |
|------|----------|------|
| 章节 | 第X章 {章节标题} | 第1章 职业危机与许愿 |
| 涉及角色 | 有实际戏份的角色，顿号分隔 | 林逸、白有容 |
| 核心事件 | 30-60字，必须含动作+结果 | 林逸因解密风潮事业崩塌，颓废中许愿触发魔法系统绑定 |
| 主线关系 | 必须为 强/中/弱（3-8字理由） | 强（动机建立+系统激活） |
| 信息密度 | 高 / 中 / 低 | 高 |
| 预估集长 | 必须为 X秒格式 | 50秒 |
| 情绪强度 | 文字标签，+ 连接，禁止星级/数字 | 转折+悬疑 |

主线关系判定：强＝直接推动主角弧线；中＝补充世界观/人物关系/伏笔；弱＝过渡/气氛。
预估集长参考：高密度+高情绪→45-60秒；中→35-45秒；低→25-35秒。
可用情绪标签：冲突、恐怖、情感、转折、高潮、平铺、喜剧、悬疑、情感崩溃。

## 提取规则

- 忠于原文，不推测、不脑补、不加入原文未出现的情节
- 角色使用文中主要称呼，保持一致
- 多条平行事件线时，选对主角影响最大的一条，其余简要带过
- 对话密集章节，关注对话推动了什么结果，而非复述对话内容
"""


class ChapterEvent:
    __slots__ = ("chapter", "characters", "event", "mainline", "density", "seconds", "emotion")

    def __init__(self, chapter, characters, event, mainline, density, seconds, emotion):
        self.chapter = chapter
        self.characters = characters
        self.event = event
        self.mainline = mainline
        self.density = density
        self.seconds = seconds
        self.emotion = emotion

    def to_dict(self):
        return {k: getattr(self, k) for k in self.__slots__}

    @classmethod
    def from_line(cls, line: str):
        line = line.strip()
        if not line.startswith("|"):
            return None
        parts = [p.strip() for p in line.split("|")]
        if parts[0] == "":
            parts = parts[1:]
        if parts and parts[-1] == "":
            parts = parts[:-1]
        print(f"  [解析] parts={len(parts)} content={parts[:3]}...", flush=True)
        if len(parts) >= 7:
            return cls(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], parts[6])
        return None


def _strip_think(text: str) -> str:
    if not text:
        return text
    text = re.sub(r'<\s*think\s*>[\s\S]*?<\s*/\s*think\s*>', '', text, flags=re.IGNORECASE)
    text = re.sub(r'<\s*think\s*>[\s\S]*', '', text, flags=re.IGNORECASE)
    return text.strip()


class EventExtractor:
    """对标 Toonflow cleanNovel.ts: 单线程逐章事件提取"""

    def __init__(self, ai_client, book_path: str, chapters: List[dict], out_dir: str):
        self.ai = ai_client
        self.book_path = book_path
        self.chapters = sorted(chapters, key=lambda c: c["number"])
        self.total = len(self.chapters)
        self.out_dir = out_dir
        self._events: Dict[int, ChapterEvent] = {}
        self._raw_events: Dict[int, str] = {}
        self._event_prompt = self._load_prompt_override()

    @staticmethod
    def _load_prompt_override() -> str:
        for d in [".", os.path.dirname(os.path.abspath(__file__)),
                  os.path.dirname(os.path.dirname(os.path.abspath(__file__)))]:
            path = os.path.join(d, "event_prompt_override.json")
            if os.path.exists(path):
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    if isinstance(data, dict):
                        if data.get("useData"):
                            return data["useData"]
                        if data.get("data"):
                            return data["data"]
                except Exception:
                    pass
        return EVENT_SYSTEM_PROMPT

    @property
    def events(self) -> List[ChapterEvent]:
        return [self._events[k] for k in sorted(self._events.keys())]

    @property
    def event_dicts(self) -> List[dict]:
        return [e.to_dict() for e in self.events]

    def _read_chapter(self, chapter_number: int) -> tuple:
        for ch in self.chapters:
            if ch["number"] == chapter_number:
                title = ch.get("title", f"第{chapter_number}章")
                reel = ch.get("reel", "")
                path = os.path.join(self.book_path, f"{chapter_number}.txt")
                if os.path.exists(path):
                    with open(path, "r", encoding="utf-8", errors="ignore") as f:
                        return title, reel, f.read()
                for fname in os.listdir(self.book_path):
                    if fname.startswith(f"第{chapter_number}章") or fname.startswith(f"第{chapter_number} "):
                        with open(os.path.join(self.book_path, fname), "r", encoding="utf-8", errors="ignore") as f:
                            return title, reel, f.read()
                return title, reel, ""
        return f"第{chapter_number}章", "", ""

    def extract(self, start: int = 1, end: int = 0,
                progress_callback: Callable = None) -> List[ChapterEvent]:
        """单线程逐章提取"""
        total = end if end > 0 else self.total
        pending = [c for c in self.chapters
                   if start <= c["number"] <= total and c["number"] not in self._events]
        pending.sort(key=lambda c: c["number"])

        if not pending:
            return self.events

        print(f"[事件提取] 开始逐章处理 {len(pending)} 章", flush=True)

        for i, chapter in enumerate(pending):
            chapter_number = chapter["number"]
            try:
                title, reel, content = self._read_chapter(chapter_number)
                print(f"[事件提取] 第{chapter_number}章 ({title[:20]}) AI请求中...", flush=True)

                user = (
                    f"请根据以下小说章节数：{chapter_number}"
                    f"小说章节券：{reel}"
                    f"小说章节名称：{title}"
                    f"、小说章节内容生成事件摘要：\n{content}"
                )

                resp = self.ai.chat(self._event_prompt, user, category="事件提取")
                cleaned = _strip_think(resp).replace("\n", " ").replace("\r", " ").strip()

                # 直接解析：按 | 切分，去首尾空
                parts = [p.strip() for p in cleaned.split("|")]
                parts = [p for p in parts if p]  # 去掉空字符串
                print(f"[事件提取] 第{chapter_number}章 分段({len(parts)}): {parts[:2]}...", flush=True)

                if len(parts) >= 7:
                    evt = ChapterEvent(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], parts[6])
                    self._events[chapter_number] = evt
                    print(f"[事件提取] 第{chapter_number}章 ✓", flush=True)
                else:
                    print(f"[事件提取] 第{chapter_number}章 ✗ 只有{len(parts)}段", flush=True)
                self._raw_events[chapter_number] = cleaned

                print(f"[事件提取] 第{chapter_number}章 完成 ({len(cleaned)}字)", flush=True)

            except Exception as e:
                print(f"[事件提取] 第{chapter_number}章 失败: {e}", flush=True)

            if progress_callback:
                progress_callback(i + 1, len(pending))

        self._save()
        print(f"[事件提取] 全部完成 {len(self._events)}/{len(pending)} 章", flush=True)
        return self.events

    def _save(self):
        os.makedirs(self.out_dir, exist_ok=True)
        path = os.path.join(self.out_dir, "chapter_events.json")
        with open(path, "w", encoding="utf-8") as f:
            data = self.event_dicts
            for e in data:
                m = re.search(r"(\d+)", e.get("chapter", ""))
                n = int(m.group(1)) if m else 0
                if n in self._raw_events:
                    e["raw"] = self._raw_events[n]
            json.dump(data, f, ensure_ascii=False, indent=2)
        events_dir = os.path.join(self.out_dir, "events")
        os.makedirs(events_dir, exist_ok=True)
        for chapter_number, e in sorted(self._events.items()):
            txt_path = os.path.join(events_dir, f"{chapter_number}.txt")
            with open(txt_path, "w", encoding="utf-8") as f:
                f.write(f"章节: {e.chapter}\n角色: {e.characters}\n事件: {e.event}\n主线: {e.mainline}\n密度: {e.density}\n集长: {e.seconds}\n情绪: {e.emotion}\n")

    def load(self) -> List[ChapterEvent]:
        path = os.path.join(self.out_dir, "chapter_events.json")
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self._events = {self._extract_chapter_number(d["chapter"]): ChapterEvent(**d) for d in data}
        return self.events

    @staticmethod
    def _extract_chapter_number(chapter_str: str) -> int:
        m = re.search(r"(\d+)", chapter_str)
        return int(m.group(1)) if m else 0

    def get_by_mainline(self, weight: str = "强") -> List[ChapterEvent]:
        return [e for e in self.events if weight in e.mainline]

    def get_characters_freq(self) -> Dict[str, int]:
        freq = {}
        for e in self.events:
            for name in e.characters.split("、"):
                name = name.strip()
                if name:
                    freq[name] = freq.get(name, 0) + 1
        return dict(sorted(freq.items(), key=lambda x: -x[1]))
