# -*- coding: utf-8 -*-
"""剧本生成器 — 对标 Toonflow script_execution_script.md（原文加载）"""
import json
import os
import re
from typing import List, Dict

# 加载剧本 prompt（对标 Toonflow 原文）
_SCRIPT_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "script_prompt.md")
if os.path.exists(_SCRIPT_PATH):
    with open(_SCRIPT_PATH, "r", encoding="utf-8") as _f:
        SCRIPT_SYSTEM_PROMPT = _f.read()
else:
    SCRIPT_SYSTEM_PROMPT = "# 剧本 prompt 文件未找到"


class ScriptGenerator:
    def __init__(self, ai_client, events: List[dict], skeleton: dict, out_dir: str,
                 novel_text_getter=None, total_episodes: int = 0, episode_seconds: int = 90,
                 genre: str = "玄幻", free_episodes: int = 3, aspect_ratio: str = "9:16"):
        self.ai = ai_client
        self.events = events
        self.skeleton = skeleton
        self.out_dir = out_dir
        self.novel_text_getter = novel_text_getter
        self.total_episodes = total_episodes
        self.episode_seconds = episode_seconds
        self.genre = genre
        self.free_episodes = free_episodes
        self.aspect_ratio = aspect_ratio
        self._prev_script = None
        self._current_episode_number = 0
        self._current_episode_info = {}
        self._current_chapter_range = ""
        self._conversation_memory: List[dict] = []

    def _get_system_prompt(self) -> str:
        return SCRIPT_SYSTEM_PROMPT.replace(
            "每集总时长控制在 60-120 秒（duration_seconds）",
            f"每集总时长控制在 {self.episode_seconds} 秒（duration_seconds: {self.episode_seconds}）"
        )

    def _get_tools(self) -> list:
        return [
            {"type": "function", "function": {"name": "get_planData", "description": "获取故事骨架与改编策略工作区内容", "parameters": {"type": "object", "properties": {}, "required": []}}},
            {"type": "function", "function": {"name": "get_novel_events", "description": "获取指定章节的事件表", "parameters": {"type": "object", "properties": {"ids": {"type": "array", "items": {"type": "integer"}}}, "required": ["ids"]}}},
            {"type": "function", "function": {"name": "get_novel_text", "description": "获取指定章节范围的原文", "parameters": {"type": "object", "properties": {"chapter_range": {"type": "string"}}, "required": ["chapter_range"]}}},
            {"type": "function", "function": {"name": "get_script_content", "description": "获取指定剧本ID的内容（用于衔接上一集）。只允许获取最后一集剧本内容", "parameters": {"type": "object", "properties": {"ids": {"type": "array", "items": {"type": "string"}}}, "required": ["ids"]}}},
        ]

    def generate_episode(self, episode_number: int, episode_info: dict) -> dict:
        ep_title = episode_info.get("title", f"第{episode_number}集")
        ep_function = episode_info.get("dramaticFunction", episode_info.get("function", "发展"))
        ep_core = episode_info.get("sceneCore", "")
        ep_emotion = episode_info.get("emotionCurve", "")

        script_list = "prev(上一集)" if self._prev_script else "(无)"
        assistant = f"## 可用剧本(ID:名称)\n{script_list}\n章节数量：{len(self.events)}章"

        user = (
            f"## 项目配置\n总集数：{self.total_episodes}\n单集时长：{self.episode_seconds} 秒\n"
            f"台词量按 150字/分钟 推算，剧本正文篇幅紧凑（通常控制在 1000 字以内）\n\n"
            f"## 当前任务\n集号：{episode_number}\n标题：{ep_title}\n"
            f"戏剧功能：{ep_function}\n场景核心：{ep_core}\n情绪基调：{ep_emotion}\n\n"
            f"请先调用 get_planData 获取骨架，再调用 get_novel_events 和 get_novel_text 获取本章数据，"
            f"如有上一集则调用 get_script_content 衔接（只允许获取最后一集）。"
            f"然后阐述思路（200-300字），最后输出 <scriptItem name=\\\"作品名 EP{episode_number:02d}：{ep_title}\\\"> 标签包裹的完整剧本。"
            f"完成后返回简短确认，如：第{episode_number}集剧本已写入，请在工作台查看。"
        )

        self.ai.set_tools({
            "get_planData": self._tool_get_planData,
            "get_novel_events": self._tool_get_novel_events,
            "get_novel_text": self._tool_get_novel_text,
            "get_script_content": self._tool_get_script_content,
        })

        try:
            resp = self.ai.chat_with_tools(
                self._get_system_prompt(), user, tools=self._get_tools(),
                category="剧本生成",
                messages=self._conversation_memory if self._conversation_memory else None,
                assistant=assistant
            )
            script = self._parse_script(resp, episode_number, ep_title)
            if script:
                self._prev_script = script
                self._conversation_memory.append({"role": "assistant", "content": f"第{episode_number}集剧本: {resp[-500:]}"})
            return script
        except Exception as e:
            print(f"  第{episode_number}集剧本生成失败: {e}")
            return {}

    def generate_all(self, target_episodes: int = 0) -> List[dict]:
        episodes = self.skeleton.get("chapters", [])
        total = target_episodes or self.total_episodes or len(episodes) or len(self.events)
        if not isinstance(total, int) or total <= 0:
            total = min(len(self.events), 50)
        scripts = []
        for i in range(1, total + 1):
            ep_info = next((item for item in episodes if item.get("episode") == i), {
                "episode": i, "title": f"第{i}集", "dramaticFunction": "发展", "chapterRange": ""
            })
            s = self.generate_episode(i, ep_info)
            if s: scripts.append(s)
        self._save(scripts)
        return scripts

    def _tool_get_planData(self, args: dict) -> str:
        sk = self.skeleton.get("markdown", "") if self.skeleton else ""
        if not sk and self.skeleton:
            sk = json.dumps(self.skeleton, ensure_ascii=False)
        return sk if sk else "(骨架未构建)"

    def _tool_get_novel_events(self, args: dict) -> str:
        ids = args.get("ids", [])
        matched = []
        for n in ids:
            for e in self.events:
                m = re.search(r"(\d+)", str(e.get("chapter", "")))
                if m and int(m.group(1)) == n:
                    matched.append(f"| {e.get('chapter','')} | {e.get('characters','')} | {e.get('event','')} | {e.get('mainline','')} | {e.get('density','')} | {e.get('emotion','')} |")
                    break
        return "\n".join(matched) if matched else f"(无对应事件: ids={ids})"

    def _tool_get_novel_text(self, args: dict) -> str:
        if not self.novel_text_getter:
            return "(原文读取器未配置)"
        chapter_range = args.get("chapter_range", self._current_chapter_range)
        return self.novel_text_getter(chapter_range) or "(无原文)"

    def _tool_get_script_content(self, args: dict) -> str:
        if self._prev_script:
            content = self._prev_script.get("script_content", "")
            return content[-1000:] if content else "(无上一集)"
        return "(无上一集)"

    @staticmethod
    def _parse_script(text: str, episode_number: int, ep_title: str) -> dict:
        result = {"episode_number": episode_number, "episode_title": ep_title, "raw": text}
        m = re.match(r"^(.*?)(?=<scriptItem)", text, re.DOTALL)
        if m: result["reasoning"] = m.group(1).strip()[:500]
        m = re.search(r"<scriptItem[^>]*>(.*?)</scriptItem>", text, re.DOTALL | re.IGNORECASE)
        if m:
            content = m.group(1).strip()
            result["script_content"] = content
            m2 = re.search(r"剧情梗概\s*\n(.*?)(?=\n△|\Z)", content, re.DOTALL)
            if m2: result["synopsis"] = m2.group(1).strip()[:300]
            lines = content.strip().split("\n")
            for line in reversed(lines[-5:]):
                line = line.strip()
                if line and not line.startswith("△") and not line.startswith("<"):
                    result["hook"] = line; break
        return result

    def _save(self, scripts: List[dict]):
        os.makedirs(self.out_dir, exist_ok=True)
        with open(os.path.join(self.out_dir, "scripts.json"), "w", encoding="utf-8") as f:
            json.dump(scripts, f, ensure_ascii=False, indent=2)

    def load(self) -> List[dict]:
        path = os.path.join(self.out_dir, "scripts.json")
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        return []
