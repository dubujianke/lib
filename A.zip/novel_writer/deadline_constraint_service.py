# -*- coding: utf-8 -*-
"""兼容 shim：转发到 .implementations.tracking.deadline_constraint_service"""
from .implementations.tracking.deadline_constraint_service import *
