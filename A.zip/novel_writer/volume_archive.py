# -*- coding: utf-8 -*-
"""对标 VolumeFactArchiveStore: 卷结束时存档快照"""
import json, os
from .snapshot_extractor import SnapshotExtractor


def archive_volume(project, volume_number: int):
    """对标 TryArchiveVolumeFactAsync: 归档当前卷快照"""
    archive_dir = os.path.join(project.dir, "archives")
    os.makedirs(archive_dir, exist_ok=True)

    extractor = SnapshotExtractor(project)
    snapshot = extractor.extract(f"vol{volume_number}", 0)

    path = os.path.join(archive_dir, f"volume_{volume_number}_snapshot.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(snapshot.to_dict(), f, ensure_ascii=False, indent=2)
    return path


def load_volume_archive(project, volume_number: int) -> dict:
    path = os.path.join(project.dir, "archives", f"volume_{volume_number}_snapshot.json")
    if not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)
