# -*- coding: utf-8 -*-
"""对标 RepairChangesJson + ValidateShortIdFields — 完整移植"""
import re
from typing import List

# 对标 ChineseFieldNameMap: 中文字段名 → 英文字段名
CHINESE_FIELD_MAP = {
    "角色状态变化": "CharacterStateChanges",
    "角色状态变更": "CharacterStateChanges",
    "角色变化": "CharacterStateChanges",
    "冲突进度": "ConflictProgress",
    "冲突进展": "ConflictProgress",
    "伏笔动作": "ForeshadowingActions",
    "伏笔操作": "ForeshadowingActions",
    "新增情节": "NewPlotPoints",
    "新情节点": "NewPlotPoints",
    "新增剧情": "NewPlotPoints",
    "地点状态变化": "LocationStateChanges",
    "地点状态变更": "LocationStateChanges",
    "地点变化": "LocationStateChanges",
    "势力状态变化": "FactionStateChanges",
    "势力状态变更": "FactionStateChanges",
    "势力变化": "FactionStateChanges",
    "时间推进": "TimeProgression",
    "时间进展": "TimeProgression",
    "角色移动": "CharacterMovements",
    "角色位移": "CharacterMovements",
    "物品流转": "ItemTransfers",
    "物品转移": "ItemTransfers",
    "道具流转": "ItemTransfers",
    "秘密知情变化": "SecretRevealChanges",
    "秘密揭示变化": "SecretRevealChanges",
    "秘密变化": "SecretRevealChanges",
    "承诺约束变化": "PledgeConstraintChanges",
    "承诺变化": "PledgeConstraintChanges",
    "契约变化": "PledgeConstraintChanges",
    "倒计时约束变化": "DeadlineConstraintChanges",
    "倒计时变化": "DeadlineConstraintChanges",
    "时限变化": "DeadlineConstraintChanges",
    "角色ID": "CharacterId",
    "角色编号": "CharacterId",
    "新等级": "NewLevel",
    "新能力": "NewAbilities",
    "失去能力": "LostAbilities",
    "关系变化": "RelationshipChanges",
    "情感阶段": "EmotionPhase",
    "新心理状态": "NewMentalState",
    "心理状态": "NewMentalState",
    "关键事件": "KeyEvent",
    "重要性": "Importance",
    "原因": "CausedBy",
    "起因": "CausedBy",
    "因果": "CausedBy",
    "关系": "Relation",
    "信任变化": "TrustDelta",
    "信任值变化": "TrustDelta",
    "冲突ID": "ConflictId",
    "冲突编号": "ConflictId",
    "新状态": "NewStatus",
    "事件": "Event",
    "伏笔ID": "ForeshadowId",
    "伏笔编号": "ForeshadowId",
    "动作": "Action",
    "关键词": "Keywords",
    "上下文": "Context",
    "涉及角色": "InvolvedCharacters",
    "故事线": "Storyline",
    "地点ID": "LocationId",
    "地点编号": "LocationId",
    "地点名称": "LocationName",
    "势力ID": "FactionId",
    "势力编号": "FactionId",
    "时间段": "TimePeriod",
    "经过时间": "ElapsedTime",
    "关键时间事件": "KeyTimeEvent",
    "出发地": "FromLocation",
    "目的地": "ToLocation",
    "目标地点名称": "ToLocationName",
    "到达地点名称": "ToLocationName",
    "物品ID": "ItemId",
    "物品编号": "ItemId",
    "物品名称": "ItemName",
    "原持有者": "FromHolder",
    "新持有者": "ToHolder",
    "秘密ID": "SecretId",
    "秘密编号": "SecretId",
    "秘密名称": "SecretName",
    "新增知情者": "NewKnowerIds",
    "知情者": "NewKnowerIds",
    "知情角色": "NewKnowerIds",
    "知情方式": "Method",
    "承诺ID": "PledgeId",
    "承诺编号": "PledgeId",
    "承诺名称": "PledgeName",
    "类型": "Type",
    "当事方": "PartyIds",
    "条件": "Condition",
    "后果": "Consequence",
    "倒计时ID": "DeadlineId",
    "倒计时编号": "DeadlineId",
    "倒计时名称": "DeadlineName",
    "截止": "Deadline",
    "截止条件": "Deadline",
    "时限": "Deadline",
    "触发条件": "TriggerCondition",
    "到期后果": "Consequence",
}


def remove_json_comments(json_text: str) -> str:
    """对标 RemoveJsonComments: 移除 // 和 /* */ 注释"""
    result = []
    in_str = False
    quote_char = '"'
    esc = False
    i = 0
    while i < len(json_text):
        c = json_text[i]
        if in_str:
            result.append(c)
            if esc:
                esc = False
                i += 1
                continue
            if c == '\\':
                esc = True
                i += 1
                continue
            if c == quote_char:
                in_str = False
            i += 1
            continue
        if c in ('"', "'"):
            in_str = True
            quote_char = c
            result.append(c)
            i += 1
            continue
        if c == '/' and i + 1 < len(json_text) and json_text[i + 1] == '/':
            while i < len(json_text) and json_text[i] != '\n':
                i += 1
            if i < len(json_text):
                result.append('\n')
            i += 1
            continue
        if c == '/' and i + 1 < len(json_text) and json_text[i + 1] == '*':
            i += 2
            while i + 1 < len(json_text) and not (json_text[i] == '*' and json_text[i + 1] == '/'):
                i += 1
            if i + 1 < len(json_text):
                i += 1
            i += 1
            continue
        result.append(c)
        i += 1
    return ''.join(result)


def map_chinese_field_names(json_text: str) -> str:
    """对标 MapChineseFieldNames: 中文字段名映射为英文"""
    for cn, en in CHINESE_FIELD_MAP.items():
        if cn in json_text:
            json_text = json_text.replace(f'"{cn}"', f'"{en}"')
            json_text = json_text.replace(f"'{cn}'", f'"{en}"')
    return json_text


def repair_changes_json(json_text: str) -> str:
    """对标 4.1.1 RepairChangesJson: 完整修复"""
    if not json_text or not json_text.strip():
        return json_text

    s = json_text.strip()

    s = remove_json_comments(s)
    s = map_chinese_field_names(s)

    result = []
    in_string = False
    string_quote = '"'
    escape = False
    bracket_stack = []
    i = 0

    while i < len(s):
        c = s[i]

        if in_string:
            if escape:
                escape = False
                result.append(c)
                i += 1
                continue
            if c == '\\':
                escape = True
                result.append(c)
                i += 1
                continue
            if c == string_quote:
                in_string = False
                result.append('"')
                i += 1
                continue
            if c == '\n':
                result.append('\\n')
            elif c == '\r':
                pass
            elif c == '\t':
                result.append('\\t')
            elif c == '\b':
                result.append('\\b')
            elif c == '\f':
                result.append('\\f')
            elif ord(c) < 0x20:
                result.append(f'\\u{ord(c):04X}')
            else:
                result.append(c)
            i += 1
            continue

        if c == "'":
            in_string = True
            string_quote = "'"
            result.append('"')
            i += 1
            continue

        if c == '"':
            in_string = True
            string_quote = '"'
            result.append('"')
            i += 1
            continue

        if c == '：':
            result.append(':')
            i += 1
            continue
        if c == '，':
            result.append(',')
            i += 1
            continue

        # 去尾逗号
        if c == ',':
            j = i + 1
            while j < len(s) and s[j] in ' \t\r\n':
                j += 1
            if j < len(s) and s[j] in '}]':
                i += 1
                continue
            result.append(c)
            i += 1
            continue

        # 未引用的字段名自动加引号 (对标字符级 field name detection)
        if c.isalpha() or c == '_':
            prev_ws = i - 1
            while prev_ws >= 0 and s[prev_ws] in ' \t\r\n':
                prev_ws -= 1
            prev_char = s[prev_ws] if prev_ws >= 0 else '\0'
            if prev_char in ('{', ','):
                ident_end = i
                while ident_end < len(s) and (s[ident_end].isalnum() or s[ident_end] == '_'):
                    ident_end += 1
                colon_pos = ident_end
                while colon_pos < len(s) and s[colon_pos] in ' \t\r\n':
                    colon_pos += 1
                if colon_pos < len(s) and s[colon_pos] in (':', '：'):
                    field_name = s[i:ident_end]
                    result.append('"').append(field_name).append('"')
                    i = ident_end
                    continue

        if c in '{[':
            bracket_stack.append(c)
            result.append(c)
            i += 1
            continue
        if c == '}':
            if bracket_stack and bracket_stack[-1] == '{':
                bracket_stack.pop()
            result.append(c)
            # 对标: } 后若紧接 {，自动插入逗号
            j = i + 1
            while j < len(s) and s[j] in ' \t\r\n':
                j += 1
            if j < len(s) and s[j] == '{':
                result.append(',')
            i += 1
            continue
        if c == ']':
            if bracket_stack and bracket_stack[-1] == '[':
                bracket_stack.pop()
            result.append(c)
            # 对标: ] 后若紧接 {，自动插入逗号
            j = i + 1
            while j < len(s) and s[j] in ' \t\r\n':
                j += 1
            if j < len(s) and s[j] == '{':
                result.append(',')
            i += 1
            continue

        result.append(c)
        i += 1

    # 对标: 闭合截断字符串和括号
    if in_string:
        result.append('"')

    if bracket_stack:
        current = ''.join(result)
        last_valid = _find_last_valid_breakpoint(current)
        if 0 < last_valid < len(current):
            result = list(current[:last_valid])
        while bracket_stack:
            open_b = bracket_stack.pop()
            result.append('}' if open_b == '{' else ']')

    return ''.join(result)


def _find_last_valid_breakpoint(json_str: str) -> int:
    """对标 FindLastValidJsonBreakpoint"""
    for i in range(len(json_str) - 1, -1, -1):
        c = json_str[i]
        if c in ',[]{}"':
            return i + 1
        if c.isdigit() or c in 'eEl':
            return i + 1
    return len(json_str)


def validate_shortid_fields(text: str) -> List[str]:
    """对标 ValidateShortIdFields: 格式校验"""
    errors = []
    for m in re.finditer(r'"([A-Z][0-9A-Z]{12,15})"', text):
        val = m.group(1)
        from .models import is_likely_id
        if not is_likely_id(val):
            errors.append(f"ID格式非法: {val}")
    return errors