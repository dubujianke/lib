# -*- coding: utf-8 -*-
"""CHANGES 解析：AI 输出 → ChapterChanges 结构化数据"""

import re
from typing import Dict, List, Optional, Tuple

from .models import (
    ChapterChanges, FactSnapshot, TOP_LEVEL_FIELDS, is_likely_id,
    CharacterStateChange, ConflictProgressChange, PlotPointChange,
    ForeshadowingAction, LocationStateChange, FactionStateChange,
    TimeProgressionChange, CharacterMovementChange, ItemTransferChange,
    SecretRevealChange, PledgeConstraintChange, DeadlineConstraintChange,
)
from .implementations.generation.chapter_changes_canonicalizer import (
    ChapterChangesCanonicalizer, EntityMap,
)
from .prompt_builder import split_content_and_changes


class EntityLookup:
    """从快照构建 9 类实体映射：ID <-> Name

    对标 C# EntityLookup: IdSet + NameToId + 歧义检测
    """

    def __init__(self, snapshot: FactSnapshot):
        self.snapshot = snapshot
        self.id_to_name = {}
        self.name_to_id = {}
        self.ambiguous_names = set()  # 同名歧义，对标 _ambiguous
        self._build()

    def _add(self, prefix: str, eid: str, name: str):
        if not eid:
            return
        self.id_to_name[eid] = name or ""
        if not name:
            return
        n = name.strip()
        if n in self.ambiguous_names:
            return
        if n in self.name_to_id and self.name_to_id[n] != eid:
            del self.name_to_id[n]
            self.ambiguous_names.add(n)
        elif n not in self.name_to_id:
            self.name_to_id[n] = eid

    def _build(self):
        s = self.snapshot
        for c in s.CharacterStates:
            self._add("C", c.CharacterId, c.Name)
        for c in s.ConflictProgress:
            self._add("CF", c.ConflictId, c.Name)
        for f in s.ForeshadowingStatus:
            self._add("FS", f.ForeshadowId, f.Name)
        for l in s.LocationStates:
            self._add("L", l.LocationId, l.Name)
        for l in s.LocationDescriptions:
            self._add("L", l.LocationId, l.Name)
        for f in s.FactionStates:
            self._add("F", f.FactionId, f.Name)
        for i in s.ItemStates:
            self._add("I", i.ItemId, i.Name)
        for sec in s.SecretStates:
            self._add("S", sec.SecretId, sec.Name)
        for p in s.PledgeStates:
            self._add("PL", p.PledgeId, p.Name)
        for d in s.DeadlineStates:
            self._add("DL", d.DeadlineId, d.Name)
        # 从 CharacterLocations 补充
        for cl in s.CharacterLocations:
            if cl.CharacterId:
                self._add("C", cl.CharacterId, cl.CharacterName)
        # 从 CharacterDescriptions 补充
        for eid, desc in s.CharacterDescriptions.items():
            self._add("C", eid, desc.Name)

    def resolve(self, value) -> str:
        """将名称或 ID 解析为 ID；无法解析返回空字符串（区别于无法解析的原值）"""
        if not value:
            return ""
        v = str(value).strip()
        if is_likely_id(v):
            return v
        m = re.search(r"\(([A-Z][0-9A-Za-z]{12})\)", v)
        if m:
            return m.group(1)
        return self.name_to_id.get(v, "")

    def name_for(self, eid: str) -> str:
        return self.id_to_name.get(eid, "")

    def has_id(self, eid: str) -> bool:
        return bool(eid) and eid in self.id_to_name


# 可自动创建的实体类型（对标原版 9 类）
_AUTO_CREATE = {"C": "角色", "CF": "冲突", "FS": "伏笔", "I": "物品",
                "S": "秘密", "PL": "誓约", "DL": "倒计时", "L": "地点", "F": "势力"}


class ChapterChangesParser:
    """解析 AI 输出 → ChapterChanges"""

    def parse(self, raw: str) -> Tuple[str, Optional[ChapterChanges]]:
        content, changes_text, _fmt = split_content_and_changes(raw)
        if not changes_text:
            return content, None
        from .ai_service import extract_json
        data = extract_json(changes_text)
        if not isinstance(data, dict):
            return content, None
        cc = ChapterChanges()
        cc.CharacterStateChanges = [CharacterStateChange.from_dict(d) for d in data.get("CharacterStateChanges", []) or [] if isinstance(d, dict)]
        cc.ConflictProgress = [ConflictProgressChange.from_dict(d) for d in data.get("ConflictProgress", []) or [] if isinstance(d, dict)]
        cc.NewPlotPoints = [PlotPointChange.from_dict(d) for d in data.get("NewPlotPoints", []) or [] if isinstance(d, dict)]
        cc.ForeshadowingActions = [ForeshadowingAction.from_dict(d) for d in data.get("ForeshadowingActions", []) or [] if isinstance(d, dict)]
        cc.LocationStateChanges = [LocationStateChange.from_dict(d) for d in data.get("LocationStateChanges", []) or [] if isinstance(d, dict)]
        cc.FactionStateChanges = [FactionStateChange.from_dict(d) for d in data.get("FactionStateChanges", []) or [] if isinstance(d, dict)]
        cc.TimeProgression = [TimeProgressionChange.from_dict(d) for d in data.get("TimeProgression", []) or [] if isinstance(d, dict)]
        cc.CharacterMovements = [CharacterMovementChange.from_dict(d) for d in data.get("CharacterMovements", []) or [] if isinstance(d, dict)]
        cc.ItemTransfers = [ItemTransferChange.from_dict(d) for d in data.get("ItemTransfers", []) or [] if isinstance(d, dict)]
        cc.SecretRevealChanges = [SecretRevealChange.from_dict(d) for d in data.get("SecretRevealChanges", []) or [] if isinstance(d, dict)]
        cc.PledgeConstraintChanges = [PledgeConstraintChange.from_dict(d) for d in data.get("PledgeConstraintChanges", []) or [] if isinstance(d, dict)]
        cc.DeadlineConstraintChanges = [DeadlineConstraintChange.from_dict(d) for d in data.get("DeadlineConstraintChanges", []) or [] if isinstance(d, dict)]
        return content, cc
