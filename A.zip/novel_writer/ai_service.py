# -*- coding: utf-8 -*-
"""
AI 服务: 对标 AIService + GenerateInBusinessSession
- 会话历史 (多轮对话)
- 内部重试 (网络故障 max 2次)
- 错误分类 (网络/超时/拒绝/Key)
"""
import json
import re
import sys
import os
import time
from dataclasses import dataclass, field
from typing import List, Optional, Callable

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai_client import AIClient


class ChatSession:
    """对标 Semantic Kernel ChatHistory: 保留多轮对话"""

    def __init__(self, session_key: str, system_prompt: str, context_provider: Callable = None):
        self.key = session_key
        self.system_prompt = system_prompt
        self.context_provider = context_provider
        self.messages = []  # [(role, content)]
        self._last_system = system_prompt

    def append_user(self, content: str):
        self.messages.append(("user", content))

    def append_assistant(self, content: str):
        self.messages.append(("assistant", content))

    def build_messages(self) -> List[dict]:
        """构建 OpenAI 格式消息列表（含上下文刷新）"""
        system = self.system_prompt
        if self.context_provider:
            try:
                ctx = self.context_provider()
                if ctx:
                    system += "\n\n" + ctx
            except Exception:
                pass
        msgs = [{"role": "system", "content": system}]
        for role, content in self.messages[-8:]:  # 保留最近8轮
            msgs.append({"role": role, "content": content})
        return msgs


class AIService:
    """对标 AIService.GenerateInBusinessSession: 会话+重试+错误分类"""

    def __init__(self, client: AIClient = None, max_retries: int = 3):
        self.client = client or AIClient()
        self.max_retries = max_retries
        self._sessions = {}

    def create_session(self, session_key: str, system: str,
                       context_provider: Callable = None) -> ChatSession:
        sess = ChatSession(session_key, system, context_provider)
        self._sessions[session_key] = sess
        return sess

    def end_session(self, session_key: str):
        self._sessions.pop(session_key, None)

    def chat(self, system: str, user: str, category: str = "chat") -> str:
        """单次对话（无会话历史）"""
        return self.client.chat(system, user, category=category)

    def generate_in_session(self, session: ChatSession, user_prompt: str,
                            category: str = "chapter", internal_retries: int = 2) -> str:
        """对标 GenerateInBusinessSessionAsync: 发送到会话，内部重试"""
        session.append_user(user_prompt)
        msgs = session.build_messages()

        last_error = ""
        for retry in range(internal_retries + 1):
            try:
                resp = self.client._client.post(
                    f"{self.client.config.base_url}/chat/completions",
                    json={
                        "model": self.client.config.model,
                        "messages": msgs,
                        "temperature": self.client.config.temperature,
                        "max_tokens": 16384,
                    },
                    headers={
                        "Authorization": f"Bearer {self.client.config.api_key}",
                        "Content-Type": "application/json",
                    },
                )
                if resp.status_code == 200:
                    data = resp.json()
                    content = data["choices"][0]["message"]["content"]
                    session.append_assistant(content)
                    return content

                # 错误分类
                error = self._classify_error(resp.status_code, resp.text)
                if "Timeout" in error and retry >= 1:
                    raise RuntimeError(f"连续超时: {error}")
                if "Refused" in error or "KeyExhausted" in error:
                    raise RuntimeError(f"{error}: {resp.text[:200]}")
                last_error = error
                time.sleep(1.5)

            except Exception as e:
                error = str(e)
                if "Timeout" in error and retry >= 1:
                    raise RuntimeError(f"连续超时: {error}")
                if "Refused" in error or "KeyExhausted" in error:
                    raise
                last_error = error
                time.sleep(1.5)

        raise RuntimeError(f"生成失败（{internal_retries + 1}次尝试）: {last_error}")

    def _classify_error(self, status_code: int, text: str) -> str:
        if status_code in (429, 503):
            return "RateLimited"
        if status_code == 408 or "timeout" in text.lower():
            return "Timeout"
        if status_code in (400, 401, 403):
            return "Refused"
        if "key" in text.lower() and ("invalid" in text.lower() or "exceeded" in text.lower()):
            return "KeyExhausted"
        return f"API错误 {status_code}"

    def chat_json(self, system: str, user: str, category: str = "gen", retries: int = None) -> dict:
        retries = retries if retries is not None else self.max_retries
        last_err = None
        for attempt in range(retries):
            prompt = user if attempt == 0 else (
                user + f"\n\n（第 {attempt} 次修正）上次输出不是合法 JSON: {last_err}\n请只输出合法的 JSON 对象。")
            try:
                text = self.client.chat(system, prompt, category=category)
            except Exception as e:
                last_err = str(e)
                continue
            data = extract_json(text)
            if data is not None:
                return data
            last_err = "无法解析 JSON"
        raise RuntimeError(f"AI 多次输出非法 JSON: {last_err}")

    def close(self):
        self.client.close()


def extract_json(text: str):
    if not text: return None
    t = text.strip()
    if t.startswith("```"):
        t = re.sub(r"^```(?:json)?\s*\n?", "", t)
        t = re.sub(r"\n?\s*```\s*$", "", t)
    start = t.find("{")
    if start == -1: return None
    depth, in_str, esc = 0, 0, 0
    for i in range(start, len(t)):
        ch = t[i]
        if in_str:
            if esc: esc = 0
            elif ch == "\\": esc = 1
            elif ch == '"': in_str = 0
            continue
        if ch == '"': in_str = 1
        elif ch == '{': depth += 1
        elif ch == '}':
            depth -= 1
            if depth == 0:
                try: return json.loads(t[start:i + 1])
                except json.JSONDecodeError: pass
    try: return json.loads(t)
    except json.JSONDecodeError: return None
