from copy import deepcopy

from novel_writer.design_import import map_design_references, map_name, split_names


def test_map_design_references():
    data = {
        "characters": [{"Name": "张三", "Id": "C1", "Relationships": {"李四": "师徒"}}, {"Name": "李四", "Id": "C2"}],
        "factions": [{"Name": "宗门", "Id": "F1", "Leader": "张三", "CoreMembers": "张三、李四", "Allies": ["宗门"]}],
        "locations": [{"Name": "山门", "Id": "L1", "FactionId": "宗门"}],
        "plot": [{"MainCharacters": "张三、李四", "KeyNpcs": ["李四"], "Location": "山门"}],
    }
    result = map_design_references(data)
    assert result["characters"][0]["Relationships"] == {"C2": "师徒"}
    assert result["factions"][0]["Leader"] == "C1"
    assert result["factions"][0]["CoreMembers"] == ["C1", "C2"]
    assert result["locations"][0]["FactionId"] == "F1"
    assert result["plot"][0]["MainCharacters"] == ["C1", "C2"]
    assert result["plot"][0]["Location"] == "L1"


def test_split_names_supports_common_separators():
    assert split_names("张三、李四,王五；赵六/钱七") == ["张三", "李四", "王五", "赵六", "钱七"]
    assert split_names(["张三", "李四"]) == ["张三", "李四"]
    assert split_names("") == []


def test_map_name_maps_strings_and_lists_and_preserves_unknown_names():
    ids = {"张三": "C1", "李四": "C2"}
    assert map_name("张三", ids) == "C1"
    assert map_name("张三、李四", ids) == ["C1", "C2"]
    assert map_name(["张三", "未知角色"], ids) == ["C1", "未知角色"]
    assert map_name(None, ids) is None


def test_mapping_does_not_mutate_input():
    data = {"characters": [{"Name": "张三", "Id": "C1"}], "factions": [{"Name": "宗门", "Id": "F1", "Leader": "张三"}]}
    original = deepcopy(data)
    map_design_references(data)
    assert data == original


def test_mapping_handles_empty_modules_and_unknown_references():
    result = map_design_references({
        "characters": [],
        "factions": [{"Name": "宗门", "Id": "F1", "Leader": "未知", "CoreMembers": []}],
        "locations": [{"Name": "地点", "Id": "L1", "FactionId": "未知势力"}],
        "plot": [{"MainCharacters": [], "KeyNpcs": [], "Location": "未知地点"}],
    })
    assert result["factions"][0]["Leader"] == "未知"
    assert result["locations"][0]["FactionId"] == "未知势力"
    assert result["plot"][0]["Location"] == "未知地点"
