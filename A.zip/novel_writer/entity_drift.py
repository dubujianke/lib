# -*- coding: utf-8 -*-
"""兼容 shim：转发到 implementations.tracking.entity_drift"""
from .implementations.tracking.entity_drift import (
    EntityOmissionRecord, EntityDriftFallbackResult,
    EntityDimensionDescriptor, DriftEntityRecord, AUTO_PATCH, WARN_ONLY,
    EntityDimensionRegistry, append_bounded_warning, name_exists_in_content,
    EntityOmissionDetector, EntityDriftFallbackPatcher,
)

__all__ = [
    "EntityOmissionRecord", "EntityDriftFallbackResult",
    "EntityDimensionDescriptor", "DriftEntityRecord", "AUTO_PATCH", "WARN_ONLY",
    "EntityDimensionRegistry", "append_bounded_warning", "name_exists_in_content",
    "EntityOmissionDetector", "EntityDriftFallbackPatcher",
]
