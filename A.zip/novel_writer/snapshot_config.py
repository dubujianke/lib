# -*- coding: utf-8 -*-
"""兼容 shim：转发到 .implementations.tracking.snapshot_config"""
from .implementations.tracking.snapshot_config import *
