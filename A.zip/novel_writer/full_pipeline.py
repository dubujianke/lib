# -*- coding: utf-8 -*-
"""
完整创作管线：拆书 → 导入五维设定 → 四层规划 → 逐章闭环生成
对标 4.1.1 全流程
"""
import json
import os
import sys
from typing import Dict, List

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai_client import AIClient
from novel_writer.ai_service import AIService
from novel_writer.prompt_library import PromptLibrary
from novel_writer.pipeline import NovelPipeline
from novel_writer.storage import Project, create_project
from novel_writer.book_pipeline_v4 import ChaishuPipeline4
from novel_writer.config_loader import load_config, build_creative_spec

DATA_ROOT = r"D:\xiaoshuo_data"


class FullWriterPipeline:
    """完整创作管线：拆书 → 生成"""

    def __init__(self, output_project_name: str = None):
        self.ai = AIService()
        self.lib = PromptLibrary()
        self.output_project_name = output_project_name or "novel_output"
        self.project = None
        self.pipeline = None

    def step1_chaishu(self, book_id: str = "1") -> ChaishuPipeline4:
        """Step 1: 拆书 → 素材 → novel_config.json"""
        print("\n" + "=" * 60)
        print("Step 1: 拆书分析（对标 4.1.1 CreativeMaterials + ContentRefinery）")
        print("=" * 60)
        p = ChaishuPipeline4(book_id)
        ess = p.select_essence(10)
        print(f"  AI选章: {len(ess.get('SelectedIndexes', []))} 章 ({ess.get('Strategy', '')})")

        excerpt = p.build_excerpt()
        print(f"  摘录: {len(excerpt)} 字符")

        analysis = p.analyze_book()
        if not analysis.get("error"):
            print(f"  分析: {len(analysis)} 字段")

        refined = p.refine_all()
        print(f"  精炼: {len(refined)}/5 维")

        # 对标 CreativeMaterialsViewModel.AIGenerate → OneClickGenerate
        mats = p.generate_materials()
        config_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                    f"novel_config_{book_id}.json")
        p.export_to_novel_config(config_path)
        return p

    def step2_import_design(self, chaishu: ChaishuPipeline4):
        """Step 2: 导入精炼数据 + 章节情节 → 项目设计库"""
        print("\n" + "=" * 60)
        print("Step 2: 导入五维设定 + 章节情节到项目设计库")
        print("=" * 60)

        self.project = create_project(self.output_project_name)
        self.pipeline = NovelPipeline(self.project, self.ai, self.lib)

        module_map = {
            "worldrules": ("world", ["Name", "OneLineSummary", "PowerSystem", "Cosmology",
                                     "SpecialLaws", "HardRules", "SoftRules", "AncientEra",
                                     "KeyEvents", "ModernHistory", "StatusQuo"]),
            "characters": ("characters", ["Name", "CharacterType", "Gender", "Age", "Identity",
                                          "Race", "Appearance", "Personality", "Want", "Need",
                                          "FlawBelief", "GrowthPath", "TargetCharacterName",
                                          "RelationshipType", "EmotionDynamic", "Relationships",
                                          "CombatSkills", "NonCombatSkills", "SpecialAbilities",
                                          "SignatureItems", "CommonItems", "PersonalAssets"]),
            "factions": ("factions", ["Name", "FactionType", "Goal", "StrengthTerritory",
                                      "Leader", "CoreMembers", "MemberTraits", "Allies",
                                      "Enemies", "NeutralCompetitors"]),
            "locations": ("locations", ["Name", "LocationType", "Description", "Scale",
                                        "Terrain", "Climate", "Landmarks", "Resources",
                                        "HistoricalSignificance", "Dangers", "FactionId"]),
            "plotrules": ("plot", ["Name", "TargetVolume", "AssignedVolume", "OneLineSummary",
                                   "EventType", "StoryPhase", "PrerequisitesTrigger",
                                   "MainCharacters", "KeyNpcs", "Location", "TimeDuration",
                                   "StepTitle", "Goal", "Conflict", "Result", "EmotionCurve",
                                   "MainPlotPush", "CharacterGrowth", "WorldReveal", "RewardsClues"]),
        }

        total_entities = 0
        for module, (entity, fields) in module_map.items():
            path = os.path.join(chaishu.out, f"refined_{module}.json")
            if not os.path.exists(path):
                print(f"  {entity}: 跳过（无数据）")
                continue
            with open(path, "r", encoding="utf-8") as f:
                items = json.load(f)
            if not items:
                continue
            # 添加 ID
            from novel_writer.models.common import short_id
            id_prefix = {"world": "W", "characters": "C", "factions": "F",
                         "locations": "L", "plot": "P"}.get(entity, "D")
            for item in items:
                item["Id"] = short_id(id_prefix)
                item["IsEnabled"] = True
            self.project.save_design(entity, {"items": items})
            total_entities += len(items)
            print(f"  {entity}: {len(items)} 条")

        print(f"\n  总计 {total_entities} 条设计数据导入完毕")
        return self.project

    def step3_generate(self, genre: str = "玄幻", creative_spec: str = "",
                       total_chapters: int = 10, word_count: int = 3000,
                       start_chapter: int = 1):
        """Step 3: 四层规划 + 逐章生成"""
        if not self.project or not self.pipeline:
            raise RuntimeError("请先运行 step2_import_design")

        print("\n" + "=" * 60)
        print("Step 3: 四层规划")
        print("=" * 60)
        plan = self.pipeline.generate_plan(genre, total_chapters)
        ch_list = plan.get("chapters", [])
        print(f"  大纲: OK")
        print(f"  分卷: {len(plan.get('volumes', []))} 卷")
        print(f"  章节: {len(ch_list)} 章")
        print(f"  蓝图: OK")

        print("\n" + "=" * 60)
        print(f"Step 4: 逐章生成 ({len(ch_list)}章, {word_count}字/章)")
        print("=" * 60)
        results = []
        for ch in ch_list:
            num = ch.ChapterNumber if hasattr(ch, 'ChapterNumber') else ch.get("ChapterNumber", 0)
            if num < start_chapter:
                continue
            try:
                r = self.pipeline.generate_chapter(genre, num, creative_spec=creative_spec,
                                                   word_count=word_count, verbose=True)
                results.append(r)
                print(f"  ✓ 第{num}章《{r.get('content', '')[:30]}...》完成, {len(r['content'])}字")
            except Exception as e:
                print(f"  ✗ 第{num}章失败: {e}")
                continue

        print(f"\n  生成 {len(results)} 章, 存储: {self.project.dir}")
        return results


def main():
    import argparse
    parser = argparse.ArgumentParser(description="完整创作管线：拆书→生成")
    parser.add_argument("--book-id", default="1", help="要拆书的书籍ID (xiaoshuo_data子目录)")
    parser.add_argument("--genre", default="玄幻", help="题材")
    parser.add_argument("--output", default="novel_output", help="输出项目名")
    parser.add_argument("--chapters", type=int, default=5, help="生成章节数")
    parser.add_argument("--words", type=int, default=2000, help="每章字数")
    parser.add_argument("--start", type=int, default=1, help="起始章")
    parser.add_argument("--design-only", action="store_true", help="只做设计+规划，不生成章节")
    parser.add_argument("--chaishu-only", action="store_true", help="只拆书+导出配置，不导入设计也不生成")
    parser.add_argument("--skip-chaishu", action="store_true", help="跳过拆书（已有 refined_*.json）")
    args = parser.parse_args()

    fp = FullWriterPipeline(args.output)
    ch = None
    if not args.skip_chaishu:
        ch = fp.step1_chaishu(args.book_id)
    else:
        ch = ChaishuPipeline4(args.book_id)

    if args.chaishu_only:
        print("\n  --chaishu-only: 拆书+导出完成，不导入设计")
        return

    fp.step2_import_design(ch)
    if not args.design_only:
        fp.step3_generate(args.genre, total_chapters=args.chapters,
                          word_count=args.words, start_chapter=args.start)
    else:
        print("\n  --design-only: 设计+规划完成，不生成章节")


if __name__ == "__main__":
    main()
