# -*- coding: utf-8 -*-
"""兼容 shim：转发到 .implementations.validation.validation_summary_service"""
from .implementations.validation.validation_summary_service import *
