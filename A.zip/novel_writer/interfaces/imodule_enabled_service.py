from abc import ABC, abstractmethod


class IModuleEnabledService(ABC):
    # 对标 IModuleEnabledService.cs

    @abstractmethod
    def SetModuleEnabledAsync(self, module_type: str, sub_module: str, enabled: bool) -> int:
        ...

    @abstractmethod
    def GetModuleEnabledAsync(self, module_type: str, sub_module: str) -> bool:
        ...

    @abstractmethod
    def GetModuleEnabledStatsAsync(self, module_type: str, sub_module: str):
        ...

    @abstractmethod
    def SetAllSubModulesEnabledAsync(self, module_type: str, enabled: bool) -> int:
        ...