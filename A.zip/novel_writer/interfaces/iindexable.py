from abc import ABC, abstractmethod


class IIndexable(ABC):
    @property
    @abstractmethod
    def Id(self) -> str:
        ...

    @property
    @abstractmethod
    def Name(self) -> str:
        ...

    @abstractmethod
    def GetItemType(self) -> str:
        ...

    @abstractmethod
    def GetDeepSummary(self) -> str:
        ...

    @abstractmethod
    def GetBriefSummary(self) -> str:
        ...
