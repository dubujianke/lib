from abc import ABC, abstractmethod


class IFocusContextService(ABC):
    @abstractmethod
    def GetDesignContextAsync(self, focus_id: str, target_layer: str):
        ...

    @abstractmethod
    def GetGenerateContextAsync(self, focus_id: str, target_layer: str):
        ...

    @abstractmethod
    def GetGlobalSummaryAsync(self):
        ...

    @abstractmethod
    def GetTrackingStatusAsync(self):
        ...

    @abstractmethod
    def GetSmartParsingContextAsync(self, focus_id: str):
        ...

    @abstractmethod
    def GetTemplatesContextAsync(self, focus_id: str):
        ...

    @abstractmethod
    def GetWorldviewContextAsync(self, focus_id: str):
        ...

    @abstractmethod
    def GetCharactersContextAsync(self, focus_id: str):
        ...

    @abstractmethod
    def GetFactionsContextAsync(self, focus_id: str):
        ...

    @abstractmethod
    def GetPlotContextAsync(self, focus_id: str):
        ...

    @abstractmethod
    def GetOutlineContextAsync(self, focus_id: str):
        ...

    @abstractmethod
    def GetPlanningContextAsync(self, focus_id: str):
        ...

    @abstractmethod
    def GetBlueprintContextAsync(self, focus_id: str):
        ...

    @abstractmethod
    def GetContentContextAsync(self, focus_id: str):
        ...

    @abstractmethod
    def InvalidateCache(self) -> None:
        ...
