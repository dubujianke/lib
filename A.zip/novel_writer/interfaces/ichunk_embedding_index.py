from dataclasses import dataclass
from typing import List, Tuple, Set

from .ivector_index import IVectorIndex, VectorSearchHit


@dataclass
class ChunkVectorEntry:
    ChunkKey: str
    ChapterId: str
    Position: int
    Vector: List[float]


class ChunkKey:
    @staticmethod
    def Format(chapter_id: str, position: int) -> str:
        return f"{chapter_id}#{position}"

    @staticmethod
    def TryParse(key: str):
        if not key:
            return False, "", -1
        idx = key.rfind("#")
        if idx <= 0 or idx == len(key) - 1:
            return False, "", -1
        pos_str = key[idx + 1:]
        try:
            position = int(pos_str)
        except ValueError:
            return False, "", -1
        if position < 0:
            return False, "", -1
        return True, key[:idx], position


class IChunkEmbeddingIndex(IVectorIndex):
    def GetByChapterAsync(self, chapter_id: str, ct=None) -> List[ChunkVectorEntry]:
        ...

    def RemoveByChapterAsync(self, chapter_id: str, ct=None) -> int:
        ...

    def SearchWithinChaptersAsync(
        self, query_vector: List[float], chapter_ids: Set[str], top_k: int, ct=None
    ) -> List[VectorSearchHit]:
        ...
