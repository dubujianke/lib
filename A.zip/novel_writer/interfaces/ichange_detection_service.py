from abc import ABC, abstractmethod
from typing import List


class IChangeDetectionService(ABC):
    # 对标 IChangeDetectionService.cs

    @abstractmethod
    def HasChanges(self, module_path: str) -> bool:
        ...

    @abstractmethod
    def GetChangedModules(self) -> List[str]:
        ...

    @abstractmethod
    def RefreshAllAsync(self) -> None:
        ...

    @abstractmethod
    def GetStatus(self, module_path: str):
        ...

    @abstractmethod
    def GetAllStatuses(self) -> List:
        ...

    @abstractmethod
    def GetDesignStatuses(self) -> List:
        ...

    @abstractmethod
    def GetGenerateStatuses(self) -> List:
        ...

    @abstractmethod
    def GetValidateStatuses(self) -> List:
        ...

    @abstractmethod
    def MarkAsPackaged(self, module_path: str) -> None:
        ...

    @abstractmethod
    def MarkAllAsPackaged(self) -> None:
        ...

    @abstractmethod
    def MarkModuleEnabled(self, module_path: str, is_enabled: bool) -> None:
        ...