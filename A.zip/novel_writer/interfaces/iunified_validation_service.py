from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List


@dataclass
class ValidationIssue:
    # 对标 IUnifiedValidationService.cs 内 ValidationIssue
    Type: str = ""
    Severity: str = "Warning"
    Message: str = ""
    Suggestion: str = ""
    EntityId: str = ""
    EntityName: str = ""
    Location: str = ""


@dataclass
class ChapterValidationResult:
    # 对标 IUnifiedValidationService.cs 内 ChapterValidationResult
    ChapterId: str = ""
    ChapterTitle: str = ""
    VolumeNumber: int = 0
    ChapterNumber: int = 0
    VolumeName: str = ""
    ValidatedTime: datetime = field(default_factory=datetime.now)
    OverallResult: str = "未校验"
    IssuesByModule: Dict[str, List[ValidationIssue]] = field(default_factory=dict)

    @property
    def TotalIssueCount(self) -> int:
        return sum(len(v) for v in self.IssuesByModule.values())

    @property
    def HasErrors(self) -> bool:
        return any(i.Severity == "Error"
                   for lst in self.IssuesByModule.values() for i in lst)

    @property
    def HasWarnings(self) -> bool:
        return any(i.Severity == "Warning"
                   for lst in self.IssuesByModule.values() for i in lst)


@dataclass
class VolumeValidationResult:
    # 对标 IUnifiedValidationService.cs 内 VolumeValidationResult
    VolumeNumber: int = 0
    VolumeName: str = ""
    ValidatedTime: datetime = field(default_factory=datetime.now)
    ChapterResults: List[ChapterValidationResult] = field(default_factory=list)

    @property
    def TotalChapters(self) -> int:
        return len(self.ChapterResults)

    @property
    def PassedChapters(self) -> int:
        return sum(1 for r in self.ChapterResults if r.OverallResult == "通过")

    @property
    def FailedChapters(self) -> int:
        return sum(1 for r in self.ChapterResults if r.OverallResult != "通过")


class IUnifiedValidationService(ABC):
    # 对标 IUnifiedValidationService.cs

    @abstractmethod
    def ValidateChapterAsync(self, chapter_id: str, ct=None) -> ChapterValidationResult:
        ...

    @abstractmethod
    def ValidateVolumeAsync(self, volume_number: int, ct=None) -> VolumeValidationResult:
        ...

    @abstractmethod
    def NeedsRepublishAsync(self) -> bool:
        ...