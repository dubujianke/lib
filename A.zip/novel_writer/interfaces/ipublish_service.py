from abc import ABC, abstractmethod


class IPublishService(ABC):
    # 对标 IPublishService.cs

    @abstractmethod
    def PublishAllAsync(self):
        ...

    @abstractmethod
    def PublishModuleAsync(self, module_name: str):
        ...

    @abstractmethod
    def GetPublishStatus(self):
        ...

    @abstractmethod
    def GetManifest(self):
        ...

    @abstractmethod
    def GetManifestAsync(self):
        ...

    @abstractmethod
    def NeedsRepublish(self) -> bool:
        ...

    @abstractmethod
    def ClearCache(self) -> None:
        ...