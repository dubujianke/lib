from abc import ABC, abstractmethod
from typing import List, Optional


class IValidationSummaryService(ABC):
    # 对标 IValidationSummaryService.cs

    # 数据操作
    @abstractmethod
    def GetAllData(self) -> List:
        ...

    @abstractmethod
    def GetDataById(self, id: str):
        ...

    @abstractmethod
    def GetDataByVolumeNumber(self, volume_number: int):
        ...

    @abstractmethod
    def AddData(self, data) -> None:
        ...

    @abstractmethod
    def UpdateData(self, data) -> None:
        ...

    @abstractmethod
    def DeleteData(self, id: str) -> None:
        ...

    # 分类管理（对标 VolumeDesignService 只读）
    @abstractmethod
    def GetAllCategories(self) -> List:
        ...

    # 校验专项
    @abstractmethod
    def SaveVolumeValidation(self, volume_number: int, data) -> None:
        ...

    @abstractmethod
    def FlushPendingAsync(self, ct=None) -> None:
        ...

    @abstractmethod
    def ParseVolumeNumber(self, category_name: str) -> int:
        ...