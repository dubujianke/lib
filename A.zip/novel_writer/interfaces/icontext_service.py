from abc import ABC, abstractmethod


class IContextService(ABC):
    # Design 模块使用（获取 Modules 原始数据）

    @abstractmethod
    def GetSmartParsingContextAsync(self):
        ...

    @abstractmethod
    def GetTemplatesContextAsync(self):
        ...

    @abstractmethod
    def GetWorldviewContextAsync(self):
        ...

    @abstractmethod
    def GetCharacterContextAsync(self):
        ...

    @abstractmethod
    def GetFactionsContextAsync(self):
        ...

    @abstractmethod
    def GetLocationsContextAsync(self):
        ...

    @abstractmethod
    def GetPlotContextAsync(self):
        ...

    @abstractmethod
    def GetDesignContextAsync(self):
        ...

    @abstractmethod
    def GetCreativeMaterialsContextAsync(self) -> str:
        ...

    @abstractmethod
    def GetCoreDesignContextAsync(self) -> str:
        ...

    # Generate 模块使用（获取 Modules 原始数据）

    @abstractmethod
    def GetOutlineContextAsync(self):
        ...

    @abstractmethod
    def GetPlanningContextAsync(self):
        ...

    @abstractmethod
    def GetBlueprintContextAsync(self):
        ...

    # Validate 模块使用

    @abstractmethod
    def GetValidationContextAsync(self, chapter_id: str):
        ...
