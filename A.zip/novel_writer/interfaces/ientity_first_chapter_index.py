from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional, Iterable


@dataclass
class FirstChapterEntry:
    EntityId: str
    ChapterId: str
    ChunkPosition: int
    CapturedAt: datetime


class IEntityFirstChapterIndex(ABC):
    @property
    @abstractmethod
    def Count(self) -> int:
        ...

    @abstractmethod
    def TryCaptureAsync(self, entity_id: str, entity_name: str, entity_description: str, chapter_id: str, ct=None) -> bool:
        ...

    @abstractmethod
    def RebuildAsync(self, entity_id: str, entity_name: str, entity_description: str, ct=None) -> bool:
        ...

    @abstractmethod
    def InvalidateByChapterAsync(self, chapter_id: str, ct=None) -> int:
        ...

    @abstractmethod
    def InvalidateByEntitiesAsync(self, entity_ids: Iterable[str], ct=None) -> int:
        ...

    @abstractmethod
    def GetAsync(self, entity_id: str) -> Optional[FirstChapterEntry]:
        ...

    @abstractmethod
    def Contains(self, entity_id: str) -> bool:
        ...

    @abstractmethod
    def GetAll(self) -> List[FirstChapterEntry]:
        ...

    @abstractmethod
    def LoadAsync(self, ct=None) -> None:
        ...

    @abstractmethod
    def SaveAsync(self, ct=None) -> None:
        ...

    @abstractmethod
    def InvalidateCache(self) -> None:
        ...
