from abc import ABC, abstractmethod
from typing import List, Optional


class IGuideContextService(ABC):
    @abstractmethod
    def InitializeCacheAsync(self) -> None:
        ...

    @abstractmethod
    def ClearCache(self) -> None:
        ...

    @abstractmethod
    def ExtractCharactersAsync(self, ids: Optional[List[str]]) -> List:
        ...

    @abstractmethod
    def GetAllCharactersAsync(self) -> List:
        ...

    @abstractmethod
    def ExtractLocationsAsync(self, ids: Optional[List[str]]) -> List:
        ...

    @abstractmethod
    def GetAllLocationsAsync(self) -> List:
        ...

    @abstractmethod
    def ExtractPlotRulesAsync(self, ids: Optional[List[str]]) -> List:
        ...

    @abstractmethod
    def GetAllPlotRulesAsync(self) -> List:
        ...

    @abstractmethod
    def ExtractFactionsAsync(self, ids: Optional[List[str]]) -> List:
        ...

    @abstractmethod
    def GetAllFactionsAsync(self) -> List:
        ...

    @abstractmethod
    def ExtractTemplatesAsync(self, ids: Optional[List[str]]) -> List:
        ...

    @abstractmethod
    def GetAllTemplatesAsync(self) -> List:
        ...

    @abstractmethod
    def ExtractWorldRulesAsync(self, ids: Optional[List[str]]) -> List:
        ...

    @abstractmethod
    def GetAllWorldRulesAsync(self) -> List:
        ...

    @abstractmethod
    def ExtractVolumeAsync(self, volume_id: str):
        ...

    @abstractmethod
    def ExtractChapterPlanAsync(self, chapter_plan_id: str):
        ...

    @abstractmethod
    def ExtractBlueprintsAsync(self, blueprint_ids: Optional[List[str]]) -> List:
        ...

    @abstractmethod
    def ExtractVolumeDesignAsync(self, volume_design_id: str):
        ...

    @abstractmethod
    def ExtractPreviousOutlinesAsync(self, outline_ids: List[str]) -> List:
        ...

    @abstractmethod
    def ValidateContextIdsAsync(self, context_ids):
        ...

    @abstractmethod
    def BuildOutlineContextAsync(self, volume_id: str):
        ...

    @abstractmethod
    def BuildPlanningContextAsync(self, volume_id: str):
        ...

    @abstractmethod
    def BuildBlueprintContextAsync(self, chapter_id: str):
        ...

    @abstractmethod
    def BuildContentContextAsync(self, chapter_id: str, ct=None):
        ...

    @abstractmethod
    def GetChapterTitleAsync(self, chapter_id: str):
        ...

    @abstractmethod
    def GetVolumeMaxChapterAsync(self, volume_number: int) -> int:
        ...

    @abstractmethod
    def ExtractFactSnapshotForChapterAsync(self, chapter_id: str, context_ids):
        ...

    @abstractmethod
    def GetContentGuideAsync(self):
        ...

    @abstractmethod
    def InvalidateContentGuideCache(self) -> None:
        ...

    @abstractmethod
    def GetChapterSummaryAsync(self, chapter_id: str) -> str:
        ...

    @abstractmethod
    def GetRelatedEntitiesAsync(self, focus_id: str, layer: str):
        ...
