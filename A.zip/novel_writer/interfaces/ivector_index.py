from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Tuple, Set


@dataclass
class VectorSearchHit:
    Key: str
    Score: float


class IVectorIndex(ABC):
    @property
    @abstractmethod
    def Count(self) -> int:
        ...

    @abstractmethod
    def UpsertAsync(self, key: str, vector: List[float], ct=None) -> bool:
        ...

    @abstractmethod
    def UpsertBatchAsync(self, items: List[Tuple[str, List[float]]], ct=None) -> bool:
        ...

    @abstractmethod
    def RemoveAsync(self, key: str, ct=None) -> bool:
        ...

    @abstractmethod
    def SearchAsync(self, query_vector: List[float], top_k: int, ct=None) -> List[VectorSearchHit]:
        ...

    @abstractmethod
    def ExistsAsync(self, key: str, ct=None) -> bool:
        ...

    @abstractmethod
    def GetAllKeys(self) -> Set[str]:
        ...

    @abstractmethod
    def LoadAsync(self, ct=None) -> None:
        ...

    @abstractmethod
    def SaveAsync(self, ct=None) -> None:
        ...

    @abstractmethod
    def InvalidateCache(self) -> None:
        ...
