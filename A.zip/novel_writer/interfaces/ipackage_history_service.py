from abc import ABC, abstractmethod
from typing import List


class IPackageHistoryService(ABC):
    # 对标 IPackageHistoryService.cs

    @property
    @abstractmethod
    def RetainCount(self) -> int:
        ...

    @RetainCount.setter
    @abstractmethod
    def RetainCount(self, value: int) -> None:
        ...

    @abstractmethod
    def SaveCurrentToHistoryAsync(self) -> bool:
        ...

    @abstractmethod
    def GetAllHistoryAsync(self) -> List:
        ...

    @abstractmethod
    def RestoreVersionAsync(self, version: int) -> bool:
        ...

    @abstractmethod
    def CleanupOldHistory(self) -> None:
        ...

    @abstractmethod
    def GetVersionDiffAsync(self, history_version: int):
        ...

    @abstractmethod
    def ClearAllAsync(self) -> bool:
        ...