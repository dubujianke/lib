from abc import ABC, abstractmethod
from typing import List, Optional


class IGeneratedContentService(ABC):
    # 对标 IGeneratedContentService.cs

    @abstractmethod
    def SaveChapterAsync(self, chapter_id: str, content: str) -> None:
        ...

    @abstractmethod
    def GetChapterAsync(self, chapter_id: str) -> Optional[str]:
        ...

    @abstractmethod
    def GetGeneratedChaptersAsync(self) -> List:
        ...

    @abstractmethod
    def DeleteChapterAsync(self, chapter_id: str) -> bool:
        ...

    @abstractmethod
    def ChapterExists(self, chapter_id: str) -> bool:
        ...

    @abstractmethod
    def GetChapterPath(self, chapter_id: str) -> str:
        ...

    # 章节（生成相关）
    @abstractmethod
    def VolumeExistsAsync(self, volume_number: int) -> bool:
        ...

    @abstractmethod
    def GenerateNextChapterIdFromSourceAsync(self, source_chapter_id: str) -> str:
        ...