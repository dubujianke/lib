# -*- coding: utf-8 -*-
"""AI 客户端封装 - 调 OpenAI 兼容接口"""

import httpx
import json
import os
from dataclasses import dataclass
from typing import Optional


# 全局日志目录（记录每次 LLM 输入输出）
LOG_DIR = os.environ.get("LLM_LOG_DIR", "")
_LOG_SEQ = 0


@dataclass
class AIConfig:
    api_key: str = "sk-d542e24e9d004aada8d138e24a87e54b"
    base_url: str = "https://api.deepseek.com/v1"
    model: str = "deepseek-chat"
    temperature: float = 0.3
    timeout: int = 300

    def __post_init__(self):
        if not self.api_key:
            self.api_key = os.environ.get("LLM_API_KEY", "")
        if not self.api_key:
            print("⚠ 未设置 API Key！请在 ai_client.py 中配置或设置环境变量 LLM_API_KEY")


class AIClient:
    """封装 LLM 调用，支持 chat + 流式，自动记录输入输出到日志"""

    def __init__(self, config: Optional[AIConfig] = None, log_dir: str = None):
        self.config = config or AIConfig()
        # verify=False 跳过 SSL 证书校验（bboluo.com 证书不匹配）
        self._client = httpx.Client(http2=True, timeout=self.config.timeout, verify=False)
        self.log_dir = log_dir or LOG_DIR

    def _log(self, category: str, system: str, user: str, result: str):
        """记录一次 LLM 调用的输入输出到文件"""
        if not self.log_dir:
            return
        global _LOG_SEQ
        _LOG_SEQ += 1
        os.makedirs(self.log_dir, exist_ok=True)
        seq = _LOG_SEQ
        try:
            # 输入
            with open(os.path.join(self.log_dir, f"{seq:04d}_{category}_input.txt"), "w", encoding="utf-8") as f:
                f.write(f"=== SYSTEM ===\n{system}\n\n=== USER ===\n{user}")
            # 输出
            with open(os.path.join(self.log_dir, f"{seq:04d}_{category}_output.txt"), "w", encoding="utf-8") as f:
                f.write(result)
        except Exception:
            pass

    def chat(self, system: str, user: str, stream: bool = False, category: str = "chat") -> str:
        """调大模型，返回文本"""
        url = f"{self.config.base_url}/chat/completions"
        payload = {
            "model": self.config.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "stream": stream,
            "temperature": self.config.temperature,
            "max_tokens": 16384,
        }
        headers = {
            "Authorization": f"Bearer {self.config.api_key}",
            "Content-Type": "application/json",
        }
        resp = self._client.post(url, json=payload, headers=headers)
        if resp.status_code != 200:
            raise RuntimeError(f"API 错误 {resp.status_code}: {resp.text}")

        data = resp.json()
        result = data["choices"][0]["message"]["content"]
        self._log(category, system, user, result)
        return result

    def close(self):
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
