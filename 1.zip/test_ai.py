# -*- coding: utf-8 -*-
"""AI 客户端自测脚本
   运行: python test_ai.py
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ai_client import AIClient


def main():
    print("=== AI Client 自测 ===\n")
    client = AIClient()

    # 1. 基本信息
    print(f"API 地址: {client.config.base_url}")
    print(f"模型:     {client.config.model}")
    print(f"Key:      {client.config.api_key[:8]}...{client.config.api_key[-4:]}")
    print()

    # 2. 基础对话
    print("[1] 基础对话测试...")
    r1 = client.chat("You are a helpful assistant", "Say hello")
    print(f"    -> {r1}\n")
    print("=== 全部测试通过 ===")


if __name__ == "__main__":
    main()
