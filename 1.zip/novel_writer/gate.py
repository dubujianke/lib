# -*- coding: utf-8 -*-
"""六道门禁 — 严格对标 4.1.1 GenerationGate.ValidateAsync"""
import re
from dataclasses import dataclass, field
from typing import List, Optional, Dict

from .models import ChapterChanges, FactSnapshot, TOP_LEVEL_FIELDS, is_likely_id
from .changes_parser import ChapterChangesParser, ChapterChangesCanonicalizer
from .prompt_builder import split_content_and_changes


@dataclass
class GateFailure:
    Type: str
    Errors: List[str] = field(default_factory=list)
    def __str__(self): return f"[{self.Type}] " + "; ".join(self.Errors[:3])
    def to_dict(self): return {"Type": self.Type, "Errors": self.Errors}


@dataclass
class GateResult:
    Success: bool = True
    Failures: List[GateFailure] = field(default_factory=list)
    ParsedChanges: Optional[ChapterChanges] = None
    ContentWithoutChanges: str = ""
    NewEntities: List = field(default_factory=list)

    def add_failure(self, ftype: str, errors: List[str]):
        self.Success = False
        self.Failures.append(GateFailure(ftype, errors))


# ==== 常量 ====
HAIR_COLORS = ["黑发", "金发", "白发", "红发", "蓝发", "紫发", "银发", "棕发", "青发"]
ANTONYMS = {
    "沉默寡言": "滔滔不绝", "温柔": "暴躁", "冷": "热情", "胆小": "胆大",
    "善良": "残忍", "正直": "卑鄙", "聪明": "愚笨",
}
CONFLICT_ORDER = {"pending": 0, "active": 1, "climax": 2, "resolved": 3,
                  "未开始": 0, "进行中": 1, "高潮": 2, "已解决": 3,
                  "待触发": 0, "激化中": 1, "白热化": 2, "已结束": 3}
STOP_WORDS = {"你好", "谢谢", "对不起", "什么", "为什么", "怎么办", "啊", "呢", "是", "吗", "吧",
              "喂", "嘿", "老师", "公子", "小姐", "大人", "老爷", "那个", "这个", "有个"}


class GenerationGate:
    """对标 4.1.1: 6关串行 + 2关后置"""

    def __init__(self):
        self.parser = ChapterChangesParser()

    def validate(self, raw: str, snapshot: FactSnapshot,
                 design_names: Dict[str, List[str]] = None,
                 context_ids: dict = None, chapter_id: str = "") -> GateResult:
        """对标 ValidateAsync 完整流程"""
        result = GateResult()

        # ======== Gate 1: 协议解析 ========
        # 对标 IdentifyChangesRegion: 4种格式识别
        content, changes = self.parser.parse(raw)
        if changes is None:
            # 尝试 RepairChangesJson 修复后重试
            _, changes_text = split_content_and_changes(raw)
            if changes_text:
                from .json_repair import repair_changes_json
                repaired = repair_changes_json(changes_text)
                content, changes = self.parser.parse(
                    (content if content else "") + "\n---CHANGES---\n" + repaired)
            if changes is None:
                result.add_failure("协议解析", ["未识别到CHANGES区域"])
                return result
        result.ContentWithoutChanges = content

        # 对标 ValidateRequiredFields: 12个顶级字段
        missing = [f for f in TOP_LEVEL_FIELDS if getattr(changes, f, None) is None]
        if missing:
            result.add_failure("协议解析", [f"缺少顶级字段: {', '.join(missing[:5])}"])
            return result

        # 对标 ValidateShortIdFields
        _, raw_changes = split_content_and_changes(raw)
        if raw_changes:
            from .json_repair import validate_shortid_fields
            id_errors = validate_shortid_fields(raw_changes)
            if id_errors:
                result.add_failure("协议解析", id_errors[:3])
                return result

        canon = ChapterChangesCanonicalizer(snapshot)
        changes = canon.canonicalize(changes)
        result.ParsedChanges = changes
        result.NewEntities = canon.new_entities

        # 伪造检测
        if canon.is_forged():
            result.add_failure("协议解析", [
                f"大面积伪造实体ID（{canon.forged_count}/{canon.total_attempted}）"])
            return result

        # ======== Gate 2: ShortId 引用校验 ========
        ref_errors = self._validate_shortid_refs(changes, snapshot, result.NewEntities)
        if ref_errors:
            result.add_failure("引用校验", ref_errors)
            return result

        # ======== Gate 3: 一致性校验 ========
        cons_errors = self._consistency_check(changes, snapshot)
        if cons_errors:
            result.add_failure("一致性校验", cons_errors)
            return result

        # ======== Gate 4: 未知实体 ========
        entity_errors = self._unknown_entity_check(content, changes, snapshot)
        if entity_errors:
            result.add_failure("未知实体", entity_errors)
            return result

        # ======== Gate 5: 描写一致性 ========
        desc_errors = self._description_check(content, snapshot)
        if desc_errors:
            result.add_failure("描写一致性", desc_errors)
            return result

        # ======== Gate 6: 世界观约束 ========
        world_errors = self._world_rule_check(content, snapshot)
        if world_errors:
            result.add_failure("世界观约束", world_errors)
            return result

        # ======== Post-gate: 设计出场 ========
        if design_names:
            bp_errors = self._design_presence_check(content, design_names)
            if bp_errors:
                result.add_failure("设计出场", bp_errors)
                return result

        # ======== Post-gate: 漏报检测 ========
        omission_errors = self._omission_check(content, changes, snapshot)
        if omission_errors:
            result.add_failure("漏报检测", omission_errors)
            return result

        result.Success = True
        return result

    # ====== Gate 2: ShortId References ======
    def _validate_shortid_refs(self, changes: ChapterChanges, snapshot: FactSnapshot,
                                new_entities: List = None) -> List[str]:
        """对标 ValidateShortIdReferences: 逐字段检查账本中存在性"""
        errors = []
        char_ids = {c.CharacterId for c in snapshot.CharacterStates}
        loc_ids = {l.LocationId for l in snapshot.LocationStates}
        loc_desc_ids = {l.LocationId for l in snapshot.LocationDescriptions}
        all_loc_ids = loc_ids | loc_desc_ids
        fac_ids = {f.FactionId for f in snapshot.FactionStates}
        item_ids = {i.ItemId for i in snapshot.ItemStates}
        sec_ids = {s.SecretId for s in snapshot.SecretStates}
        pld_ids = {p.PledgeId for p in snapshot.PledgeStates}
        ddl_ids = {d.DeadlineId for d in snapshot.DeadlineStates}
        fs_ids = {f.ForeshadowId for f in snapshot.ForeshadowingStatus}
        conf_ids = {c.ConflictId for c in snapshot.ConflictProgress}

        # 将 CHANGES 中新创建的实体 ID 加入合法集合（对标 auto-create）
        for i in changes.ItemTransfers:
            if i.ItemId: item_ids.add(i.ItemId)
        for s in changes.SecretRevealChanges:
            if s.SecretId: sec_ids.add(s.SecretId)
        for p in changes.PledgeConstraintChanges:
            if p.PledgeId: pld_ids.add(p.PledgeId)
        for d in changes.DeadlineConstraintChanges:
            if d.DeadlineId: ddl_ids.add(d.DeadlineId)
        for l in changes.LocationStateChanges:
            if l.LocationId: all_loc_ids.add(l.LocationId)

        for c in changes.CharacterStateChanges:
            cid = c.CharacterId
            if cid and is_likely_id(cid) and cid not in char_ids:
                errors.append(f"角色ID不存在: {cid}")
        for c in changes.ConflictProgress:
            if c.ConflictId and is_likely_id(c.ConflictId) and c.ConflictId not in conf_ids:
                errors.append(f"冲突ID不存在: {c.ConflictId}")
        for f in changes.ForeshadowingActions:
            if f.ForeshadowId and is_likely_id(f.ForeshadowId) and f.ForeshadowId not in fs_ids:
                errors.append(f"伏笔ID不存在: {f.ForeshadowId}")
        for l in changes.LocationStateChanges:
            if l.LocationId and is_likely_id(l.LocationId) and l.LocationId not in all_loc_ids:
                errors.append(f"地点ID不存在: {l.LocationId}")
        for f in changes.FactionStateChanges:
            if f.FactionId and is_likely_id(f.FactionId) and f.FactionId not in fac_ids:
                errors.append(f"势力ID不存在: {f.FactionId}")
        for m in changes.CharacterMovements:
            if m.CharacterId and is_likely_id(m.CharacterId) and m.CharacterId not in char_ids:
                errors.append(f"角色移动ID不存在: {m.CharacterId}")
        for i in changes.ItemTransfers:
            if i.ItemId and is_likely_id(i.ItemId) and i.ItemId not in item_ids:
                errors.append(f"物品ID不存在: {i.ItemId}")
        for s in changes.SecretRevealChanges:
            if s.SecretId and is_likely_id(s.SecretId) and s.SecretId not in sec_ids:
                errors.append(f"秘密ID不存在: {s.SecretId}")
        return errors

    # ====== Gate 3: Consistency ======
    def _consistency_check(self, changes: ChapterChanges, snapshot: FactSnapshot) -> List[str]:
        """对标 LedgerConsistencyChecker: V1-V8"""
        errors = []
        fs_by_id = {f.ForeshadowId: f for f in snapshot.ForeshadowingStatus}
        conf_by_id = {c.ConflictId: c for c in snapshot.ConflictProgress}
        char_by_id = {c.CharacterId: c for c in snapshot.CharacterStates}
        loc_by_id = {c.CharacterId: c for c in snapshot.CharacterLocations}
        item_by_id = {i.ItemId: i for i in snapshot.ItemStates}

        # V1 伏笔
        for f in changes.ForeshadowingActions:
            entry = fs_by_id.get(f.ForeshadowId)
            if entry:
                if f.Action == "setup" and entry.IsSetup and not entry.IsResolved:
                    errors.append(f"伏笔[{entry.Name}]已埋设不可重复setup")
                if f.Action == "payoff" and not entry.IsSetup:
                    errors.append(f"伏笔[{entry.Name}]未埋设不可payoff")

        # V2 冲突状态序
        for c in changes.ConflictProgress:
            entry = conf_by_id.get(c.ConflictId)
            if entry and c.NewStatus:
                old = _normalize_conflict_status(entry.Status)
                new = _normalize_conflict_status(c.NewStatus)
                if old and new and old != new:
                    seq = ["pending", "active", "climax", "resolved"]
                    oi = seq.index(old) if old in seq else 1
                    ni = seq.index(new) if new in seq else 1
                    if ni < oi:
                        errors.append(f"冲突[{entry.Name}]状态回退: {entry.Status}→{c.NewStatus}")

        # V3 角色: CharacterNotInvolved + LevelRegression + AbilityLoss + TrustDelta
        involved_ids = set()
        for c in snapshot.CharacterStates:
            if c.CharacterId: involved_ids.add(c.CharacterId)
        for cd in snapshot.CharacterDescriptions:
            if cd.CharacterId: involved_ids.add(cd.CharacterId)

        char_by_id = {c.CharacterId: c for c in snapshot.CharacterStates}
        for c in changes.CharacterStateChanges:
            cid = c.CharacterId
            if not cid: continue

            # 对标 CharacterNotInvolved
            if involved_ids and cid not in involved_ids:
                name = char_by_id.get(cid, None)
                errors.append(f"角色不涉及: {name.Name if name else cid} 不在本章追踪角色中")

            entry = char_by_id.get(cid)
            if not entry: continue

            # 对标 LevelRegression
            if c.NewLevel and entry.Level:
                old_lv = _parse_level(entry.Level)
                new_lv = _parse_level(c.NewLevel)
                if old_lv >= 0 and new_lv >= 0 and new_lv < old_lv:
                    loss_kw = ["失去", "废除", "散功", "自废", "碎裂", "崩毁", "献祭", "剥夺", "吞噬", "陨落"]
                    has_loss = c.KeyEvent and any(k in (c.KeyEvent or "") for k in loss_kw)
                    if not has_loss:
                        errors.append(f"角色[{entry.Name}]境界回退: {entry.Level}→{c.NewLevel}（无失去事件）")

            # 对标 AbilityLossWithoutEvent
            if c.LostAbilities:
                loss_kw = ["失去", "废除", "散功", "自废", "碎裂", "崩毁", "献祭", "剥夺", "吞噬", "陨落",
                           "封印", "压制", "反噬", "重伤", "濒死", "断臂", "经脉", "修为尽失"]
                has_loss = c.KeyEvent and any(k in (c.KeyEvent or "") for k in loss_kw)
                if not has_loss:
                    errors.append(f"角色[{entry.Name}]失去能力需KeyEvent说明: {c.LostAbilities[:3]}")

            # 对标 TrustDeltaExceedsLimit
            for rid, rel in (c.RelationshipChanges or {}).items():
                td = abs(rel.TrustDelta) if isinstance(rel.TrustDelta, int) else 0
                if td > 30:
                    errors.append(f"角色[{entry.Name}]→{rid} 信任变化 {rel.TrustDelta} 超限(±30)")

        # V4 移动: 同章多点链连续性 + 账本匹配 + 地点容错
        move_by_char = {}
        for m in changes.CharacterMovements:
            if m.CharacterId:
                move_by_char.setdefault(m.CharacterId, []).append(m)
        for m_list in move_by_char.values():
            for i in range(1, len(m_list)):
                prev_to = m_list[i - 1].ToLocation
                curr_from = m_list[i].FromLocation
                if prev_to and curr_from and prev_to != curr_from:
                    cid = m_list[i].CharacterId
                    entry = char_by_id.get(cid)
                    errors.append(f"角色[{entry.Name if entry else cid}]移动链断裂: {prev_to}→{curr_from}")

        loc_by_char = {}
        for cl in snapshot.CharacterLocations:
            if cl.CharacterId and cl.CurrentLocation:
                loc_by_char[cl.CharacterId] = cl.CurrentLocation
        # 构建可用的地点ID集合（容错）
        chapter_locs = set()
        for ls in snapshot.LocationStates:
            if ls.LocationId: chapter_locs.add(ls.LocationId)
        for ld in snapshot.LocationDescriptions:
            if ld.LocationId: chapter_locs.add(ld.LocationId)

        for m in changes.CharacterMovements:
            if not m.FromLocation or not m.CharacterId: continue
            known = loc_by_char.get(m.CharacterId)
            if known and m.FromLocation != known:
                if m.FromLocation not in chapter_locs:
                    errors.append(f"角色移动出发地不匹配: 账本[{known}] vs [{m.FromLocation}]")
            if m.ToLocation:
                loc_by_char[m.CharacterId] = m.ToLocation

        # V5 物品: rolling holder map + 角色容错
        rolling_item = {}
        for is_ in snapshot.ItemStates:
            if is_.ItemId and is_.CurrentHolder:
                rolling_item[is_.ItemId] = is_.CurrentHolder
        chapter_chars = set()
        for c in snapshot.CharacterStates:
            if c.CharacterId: chapter_chars.add(c.CharacterId)

        for t in changes.ItemTransfers:
            if not t.FromHolder or not t.ItemId: continue
            known = rolling_item.get(t.ItemId)
            if known and t.FromHolder != known:
                if t.FromHolder not in chapter_chars:
                    errors.append(f"物品[{t.ItemName or t.ItemId}]持有者不匹配: 账本[{known}] vs [{t.FromHolder}]")
            rolling_item[t.ItemId] = t.ToHolder or ""

        # V6 关系: ally+enemy 双向对检测
        ally_pairs = set()
        enemy_pairs = set()
        for c in changes.CharacterStateChanges:
            if not c.CharacterId: continue
            for rid, rel in (c.RelationshipChanges or {}).items():
                if not rid: continue
                pair = (c.CharacterId, rid) if c.CharacterId <= rid else (rid, c.CharacterId)
                rtype = rel.Relation or ""
                if _is_ally(rtype): ally_pairs.add(pair)
                if _is_enemy(rtype): enemy_pairs.add(pair)
        both = ally_pairs & enemy_pairs
        for p in both:
            errors.append(f"角色 {p[0]} 与 {p[1]} 同时声明盟友和仇敌（关系矛盾）")

        # V7 誓约: duplicate create + 同章多终止
        pled_active = {p.PledgeId for p in snapshot.PledgeStates if p.PledgeId}
        pled_term = {}
        for p in changes.PledgeConstraintChanges:
            if not p.PledgeId: continue
            act = (p.Action or "").lower()
            if act == "create" and p.PledgeId in pled_active:
                errors.append(f"誓约[{p.PledgeId}]重复create")
            if act in ("fulfill", "break"):
                pled_term.setdefault(p.PledgeId, []).append(act)
        for pid, acts in pled_term.items():
            if len(acts) > 1:
                errors.append(f"誓约[{pid}]同章多个终止动作: {acts}")

        # V8 倒计时: duplicate create + 同章多终止
        ddl_active = {d.DeadlineId for d in snapshot.DeadlineStates if d.DeadlineId}
        ddl_term = {}
        for d in changes.DeadlineConstraintChanges:
            if not d.DeadlineId: continue
            act = (d.Action or "").lower()
            if act == "create" and d.DeadlineId in ddl_active:
                errors.append(f"倒计时[{d.DeadlineId}]重复create")
            if act in ("trigger", "expire", "cancel"):
                ddl_term.setdefault(d.DeadlineId, []).append(act)
        for did, acts in ddl_term.items():
            if len(acts) > 1:
                errors.append(f"倒计时[{did}]同章多个终止动作: {acts}")

        return errors

    @staticmethod
    def _level_value(level: str) -> float:
        m = re.search(r"(\d+)", str(level))
        if m: return float(m.group(1))
        seq = ["炼气", "筑基", "金丹", "元婴", "化神", "炼虚", "合体", "大乘", "渡劫",
               "凡", "武", "师", "宗", "尊", "帝", "仙", "圣", "神",
               "引气", "凝液", "结丹", "出窍", "分神"]
        for i, k in enumerate(seq):
            if k in str(level): return i + 10
        return 5

    # ====== Gate 4: Unknown Entities ======
    def _unknown_entity_check(self, content: str, changes: ChapterChanges, snapshot: FactSnapshot) -> List[str]:
        """对标 ContentEntityExtractor: 功能性 vs 龙套"""
        known = set()
        for c in snapshot.CharacterStates: known.add(c.Name)
        for l in snapshot.LocationStates: known.add(l.Name)
        for f in snapshot.FactionStates: known.add(f.Name)

        # 收集正文中引号内的疑似人名
        dialogue_names = re.findall(r'[“\"]([^”\"\n]{2,6})[”\"]\s*(?:说|道|问|答|喊|笑|骂|低|喃喃|冷)', content)
        all_found = []
        for name in dialogue_names:
            name = name.strip()
            if not name or name in known or name in STOP_WORDS: continue
            if len(name) < 2 or len(name) > 6: continue
            if any(ch.isdigit() for ch in name): continue
            all_found.append(name)

        # 分类
        functional_entities = [n for n in all_found if self._in_changes_name(n, changes)]
        background_entities = [n for n in all_found if n not in functional_entities]
        total = len(set(all_found))
        bg_count = len(set(background_entities))

        if total > 5 or bg_count > 3:
            return [f"正文引入未登记实体（功能{len(functional_entities)}个/龙套{bg_count}个）: {'、'.join(set(all_found)[:8])}"]
        return []

    @staticmethod
    def _in_changes_name(name: str, changes: ChapterChanges) -> bool:
        text = str(changes.to_dict())
        return name in text

    # ====== Gate 5: Description Consistency ======
    def _description_check(self, content: str, snapshot: FactSnapshot) -> List[str]:
        """对标 ContentDescriptionValidator"""
        errors = []
        for cd in snapshot.CharacterDescriptions:
            if not cd.Name or not cd.HairColor: continue
            for m in re.finditer(re.escape(cd.Name), content):
                window = content[max(0, m.start() - 30):m.end() + 30]
                others = [hc for hc in HAIR_COLORS if hc != cd.HairColor and hc in window]
                if others:
                    errors.append(f"角色[{cd.Name}]发色矛盾: 设定[{cd.HairColor}] vs 出现[{others[0]}]")
                    break
        for cd in snapshot.CharacterDescriptions:
            for tag in cd.PersonalityTags:
                for k, v in ANTONYMS.items():
                    if (k in tag or tag in k):
                        if v in content and cd.Name in content:
                            if re.search(re.escape(cd.Name) + f"[^。！？\\n]*{v}", content):
                                errors.append(f"角色[{cd.Name}]性格矛盾: {tag} vs {v}")
        return errors

    # ====== Gate 6: World Rule Constraints ======
    def _world_rule_check(self, content: str, snapshot: FactSnapshot) -> List[str]:
        """对标 ValidateWorldRuleConstraints: 硬约束否定词检测"""
        errors = []
        for wr in snapshot.WorldRuleConstraints:
            if not wr.Content or not wr.IsHardConstraint: continue
            rule = wr.Content
            neg_match = re.search(r"(?:不可|不得|不能|禁止|严禁|无法|永不)\s*([^\s，。！？\n]{1,8})", rule)
            if not neg_match: continue
            keyword = neg_match.group(1)
            if not keyword or keyword not in content: continue
            # 检查上下文中是否有否定前缀
            for m in re.finditer(re.escape(keyword), content):
                ctx = content[max(0, m.start() - 8):m.start()]
                if not re.search(r"(?:不|非|无|没|未|否|勿|莫)", ctx):
                    errors.append(f"违反硬约束「{rule[:40]}」: 正文出现『{keyword}』且无否定前缀")
                    break
        return errors

    # ====== Post-gate: Design Element Presence ======
    def _design_presence_check(self, content: str, design_names: Dict[str, List[str]]) -> List[str]:
        """对标 ValidateDesignElementPresence: 阈值 max(3, total/3)"""
        errors = []
        absent = []
        total_elements = 0
        for kind, names in design_names.items():
            total_elements += len([n for n in names if n])
            for name in names:
                if not name: continue
                if name not in content:
                    # 视角角色缺席仅为 quality-warn，不进入 absent
                    if kind == "视角角色": continue
                    absent.append(f"{kind}:{name}")

        if absent:
            threshold = max(3, total_elements // 3)
            if len(absent) > threshold:
                errors.append(f"设计指定实体缺席（{len(absent)}/{total_elements}, 阈值{threshold}）: {'、'.join(absent[:6])}")
        return errors

    # ====== Post-gate: Omission Detection ======
    def _omission_check(self, content: str, changes: ChapterChanges, snapshot: FactSnapshot) -> List[str]:
        """对标 OmissionDetector: 正文出现但CHANGES未申报"""
        errors = []
        changes_text = str(changes.to_dict()).lower()
        char_names = {c.Name for c in snapshot.CharacterStates if c.Name and len(c.Name) >= 2}

        for name in char_names:
            if name not in content: continue
            if name.lower() in changes_text: continue
            # 漏报：正文出现但未在CHANGES中申报
            # 尝试自动补录（对标 AutoPatch）
            has_state_change = False
            for c in changes.CharacterStateChanges:
                if c.CharacterId == name or (isinstance(c.RelationshipChanges, dict) and name in c.RelationshipChanges):
                    has_state_change = True
                    break
            if not has_state_change:
                # 自动补录一个空状态变更
                from .models import CharacterStateChange
                changes.CharacterStateChanges.append(CharacterStateChange(
                    CharacterId=name, Importance="normal",
                    KeyEvent=f"在本章出场（系统自动补录）"))
        return errors


# ====== 对标 ParseLevelNumber: tier/阿拉伯/罗马/中文/字母等级 ======
_LEVEL_SEQ = ["炼气", "筑基", "金丹", "元婴", "化神", "炼虚", "合体", "大乘", "渡劫",
              "凡", "武", "师", "宗", "尊", "帝", "仙", "圣", "神",
              "引气", "凝液", "结丹", "出窍", "分神", "融合"]


def _parse_level(level: str) -> int:
    """对标 LedgerConsistencyChecker.ParseLevelNumber"""
    if not level or not level.strip():
        return -1
    text = level.strip()
    m = re.search(r"tier\s*[-_]?\s*(\d+)", text, re.I)
    if m: return int(m.group(1))
    m = re.search(r"\b[IVXLCDM]+\b", text, re.I)
    if m:
        v = _parse_roman(m.group(0))
        if v > 0: return v
    m = re.search(r"[零一二三四五六七八九十百千万两]+", text)
    if m:
        v = _parse_chinese_num(m.group(0))
        if v > 0: return v
    m = re.search(r"\b(SSS|SS|S|A|B|C|D|E|F)\b", text, re.I)
    if m:
        gv = {"SSS": 7, "SS": 6, "S": 5, "A": 4, "B": 3, "C": 2, "D": 1, "E": 0, "F": -1}
        return gv.get(m.group(1).upper(), -1)
    m = re.search(r"\d+", text)
    if m: return int(m.group(0))
    for i, k in enumerate(_LEVEL_SEQ):
        if k in text: return i + 10
    return -1


def _parse_roman(s: str) -> int:
    vals = {"I": 1, "V": 5, "X": 10, "L": 50, "C": 100, "D": 500, "M": 1000}
    total, prev = 0, 0
    for c in s.upper():
        if c not in vals: return 0
        cur = vals[c]
        total += cur - 2 * prev if cur > prev else cur
        prev = cur
    return total


def _parse_chinese_num(s: str) -> int:
    d = {"零": 0, "一": 1, "二": 2, "两": 2, "三": 3, "四": 4,
         "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}
    r, sec, n = 0, 0, 0
    for c in s:
        if c in d:
            n = d[c]
            continue
        if c == "十": u = 10
        elif c == "百": u = 100
        elif c == "千": u = 1000
        elif c == "万":
            sec += n; r += sec * 10000; sec, n = 0, 0
            continue
        else: return 0
        sec += (n or 1) * u; n = 0
    return r + sec + n


def _normalize_conflict_status(status: str) -> str:
    """对标 NormalizeConflictStatus: 30+中英同义词"""
    if not status or not status.strip():
        return ""
    s = status.strip()
    lo = s.lower()
    if lo in ("pending", "todo", "new", "open"): return "pending"
    if lo in ("active", "ongoing", "running", "inprogress", "in_progress"): return "active"
    if lo in ("climax", "peak", "burst", "explosion"): return "climax"
    if lo in ("resolved", "done", "closed", "finished", "complete", "completed"): return "resolved"
    if any(k in s for k in ("未",)) and any(k in s for k in ("开始", "触发", "启动", "发生", "激活")):
        return "pending"
    if any(k in s for k in ("进行", "推进", "发展", "展开", "激活", "开启", "进展", "持续", "继续", "升级", "恶化")):
        return "active"
    if any(k in s for k in ("高潮", "爆发", "决战", "决裂", "临界", "白热化", "最高点", "紧要关头", "危急", "巅峰")):
        return "climax"
    if any(k in s for k in ("解决", "结束", "完结", "收束", "已结", "闭环", "落幕", "告终", "平息", "化解", "消弭", "了结")):
        return "resolved"
    return lo


# ====== 对标 IsAllyRelation / IsEnemyRelation ======
_ALLY_KW = ["盟友", "同盟", "结盟", "挚友", "知己", "朋友", "好友", "友人", "亲友",
            "兄弟", "姐妹", "手足", "恋人", "爱人", "夫妻", "伙伴", "同伴", "战友",
            "心腹", "亲信", "ally", "friend"]
_ENEMY_KW = ["仇敌", "敌对", "宿敌", "敌人", "死敌", "仇人", "对头", "政敌", "寇仇",
             "冤家", "反目", "决裂", "enemy", "hostile"]


def _is_ally(relation: str) -> bool:
    if not relation: return False
    r = relation.lower()
    return any(k in r for k in _ALLY_KW)


def _is_enemy(relation: str) -> bool:
    if not relation: return False
    r = relation.lower()
    return any(k in r for k in _ENEMY_KW)
