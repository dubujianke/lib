# -*- coding: utf-8 -*-
"""对标 4.1.1 ContentPolisher: AI 润色 + 门禁重验"""
import re
from .prompt_builder import split_content_and_changes

POLISH_SYSTEM = """<role>你是文学润色专家。核心任务：**严格按 <polish_rules> 中的技巧对中文小说正文进行风格润色**，让语言更自然流畅、更贴近人类写作习惯。</role>

<polish_rules>
### 1. 增加冗余与解释性
将简洁动词替换为更长的、带有动作过程描述的短语。
- "管理" → "开展...的管理工作"
- "处理" → "去处理...工作"
- "恢复" → "进行恢复"

### 2. 风格修饰
- 适当增加"了""的""地""所""会""可以""这个""方面"等。
- 增加"就""都""倒""还""也""可"等虚词连接词。
- 句末补"了""呢""罢了""嘛"等语气词。
- 增加"那个""那些""这个"等指示词。
- 增加"下来""起来""出来""过去"等补语词。
- 增加"有""有点""差不多""左右"等程度词。

### 3. 句式自然化
- 把字句："拉下电闸"→"把电闸拉了下来"
- 口语化："若...则..."→"要是...那就..."
- 拆短为长："告诉自己那是老鼠"→"在心底里头跟自己说那准是老鼠"

以上只是基本举例，如果文章中有和以上例子相似的，也要根据例子灵活修改。
</polish_rules>

<strict_rules>
1. 情节走向、人物关系、世界观设定必须完全不变。
2. 所有人名、地名、势力名原样保留，禁止用代词替换专有名词。
3. 字数与原文偏差不超过 ±5%。
4. 只输出修改后的完整正文，不附加任何解释。
</strict_rules>"""


class ContentPolisher:
    """对标 4.1.1 ContentPolisher: 分离正文→AI润色→合并CHANGES→重验"""

    def __init__(self, ai_client):
        self.ai = ai_client

    def polish(self, raw_content: str, verbose: bool = True) -> tuple:
        """润色正文。对标: 本地正则降AI → 分离CHANGES → AI润色 → 合并 → 返回"""
        # 分离正文和 CHANGES
        separator_idx = _find_changes_start(raw_content)
        if separator_idx < 0:
            content_part = raw_content.strip()
            changes_part = ""
        else:
            content_part = raw_content[:separator_idx].strip()
            changes_part = raw_content[separator_idx:]

        # 对标 ApplyPreLLMAsync: 本地 MLM 仿人化
        pre_len = len(content_part.replace("\n", "").replace(" ", ""))
        try:
            from .humanize import HumanizeRules
            h = HumanizeRules()
            content_part = h.humanize(content_part, max_replaces=15)
        except Exception:
            pass

        if len(content_part.replace("\n", "").replace(" ", "")) < 50:
            return raw_content, content_part, True  # 太短不润

        wc = len(content_part.replace("\n", "").replace(" ", ""))
        word_hint = f"（约 {wc} 字）"
        prompt = POLISH_SYSTEM.replace("{WORD_COUNT_HINT}", word_hint)
        prompt += f"\n\n<source_text>\n{content_part}\n</source_text>"

        if verbose:
            print(f"    [润色] AI 润色中...")
        try:
            polished_text = self.ai.chat(prompt, "", category="润色")
        except Exception:
            return raw_content, content_part, False

        polished_text = polished_text.strip()
        # 清洗残留的 XML 标签
        polished_text = re.sub(r"</?source_text>", "", polished_text).strip()
        polished_text = re.sub(r"</?polish_rules>", "", polished_text).strip()

        # 字数检查：偏差 > 20% 视为失败
        new_wc = len(polished_text.replace("\n", "").replace(" ", ""))
        if wc > 100 and (new_wc < wc * 0.5 or new_wc > wc * 1.5):
            if verbose:
                print(f"    [润色] 字数偏差过大({wc}→{new_wc})，使用原文")
            return raw_content, content_part, False

        # 合并 CHANGES
        if changes_part:
            full = polished_text + "\n\n" + changes_part
        else:
            full = polished_text

        if verbose:
            print(f"    [润色] 完成 ({wc}→{new_wc} 字)")
        return full, polished_text, True


def _find_changes_start(text: str) -> int:
    """找 CHANGES 区域起始位置"""
    # XML 标签
    idx = text.find("<chapter_changes>")
    if idx != -1:
        return idx
    # ---CHANGES---
    idx = text.find("---CHANGES---")
    if idx != -1:
        return idx
    return -1
