# -*- coding: utf-8 -*-
"""
对标 RobertaTinyMlmService: chinese-roberta-tiny ONNX MLM 选词
用途: 仿人化选词(降低AI味) + 语义守卫(防语义漂移)
"""
import os, json, threading
import numpy as np
from typing import List


class RobertaTinyMlm:
    """对标 IMicroMlmService: ScoreCandidatesAsync"""

    def __init__(self, model_dir: str = None):
        if not model_dir:
            model_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                     "chinese-roberta-tiny")
        model_path = os.path.join(model_dir, "model.onnx")
        vocab_path = os.path.join(model_dir, "vocab.txt")
        self._available = os.path.exists(model_path) and os.path.exists(vocab_path)
        if not self._available:
            return

        import onnxruntime as ort
        self._session = ort.InferenceSession(model_path)
        self._vocab = self._load_vocab(vocab_path)
        self._vocab_size = self._read_vocab_size(model_dir)
        self._discover_io()

    def _load_vocab(self, path: str) -> dict:
        vocab = {}
        with open(path, "r", encoding="utf-8") as f:
            for i, line in enumerate(f):
                vocab[line.strip()] = i
        return vocab

    def _read_vocab_size(self, model_dir: str) -> int:
        cfg = os.path.join(model_dir, "config.json")
        try:
            with open(cfg, "r") as f:
                return json.load(f).get("vocab_size", 21128)
        except Exception:
            return 21128

    def _discover_io(self):
        inputs = [i.name for i in self._session.get_inputs()]
        self._input_ids_name = next((n for n in inputs if "input" in n.lower()), inputs[0])
        self._attention_mask_name = next((n for n in inputs if "mask" in n.lower()), inputs[1])
        self._token_type_ids_name = next((n for n in inputs if "token_type" in n.lower()), None)
        outputs = [o.name for o in self._session.get_outputs()]
        self._output_logits_name = next((n for n in outputs if "logit" in n.lower()), outputs[0])

    def encode(self, text: str, max_len: int = 256) -> List[int]:
        """BERT tokenizer: 字符级 CJK 分词"""
        ids = []
        for ch in text[:max_len * 3]:
            ids.append(self._vocab.get(ch, self._vocab.get("[UNK]", 100)))
        if len(ids) > max_len - 2:
            ids = ids[:max_len - 2]
        cls_id = self._vocab.get("[CLS]", 101)
        sep_id = self._vocab.get("[SEP]", 102)
        return [cls_id] + ids + [sep_id]

    def score_candidates(self, text: str, anchor_idx: int, key: str, candidates: List[str]) -> List[float]:
        """对标 ScoreCandidatesAsync: MLM 评分候选替换词"""
        if not self._available or not candidates or len(key) == 0:
            return [0.0] * len(candidates)
        if anchor_idx < 0 or anchor_idx + len(key) > len(text):
            return [0.0] * len(candidates)

        n = len(candidates)
        prefix = text[:anchor_idx]
        suffix = text[anchor_idx + len(key):]

        token_lists = []
        max_len = 0
        for cand in candidates:
            full = prefix + cand + suffix
            ids = self.encode(full, 256)
            token_lists.append(ids)
            if len(ids) > max_len:
                max_len = len(ids)
        if max_len == 0:
            return [0.0] * n

        inp_ids = np.zeros((n, max_len), dtype=np.int64)
        attn_mask = np.zeros((n, max_len), dtype=np.int64)
        for i, toks in enumerate(token_lists):
            inp_ids[i, :len(toks)] = toks
            attn_mask[i, :len(toks)] = 1

        feed = {
            self._input_ids_name: inp_ids,
            self._attention_mask_name: attn_mask,
        }
        if self._token_type_ids_name:
            feed[self._token_type_ids_name] = np.zeros((n, max_len), dtype=np.int64)

        try:
            outputs = self._session.run([self._output_logits_name], feed)
            logits = outputs[0]  # (n, seq_len, vocab_size)
        except Exception:
            return [0.0] * n

        actual_vocab = logits.shape[2] if len(logits.shape) == 3 else self._vocab_size
        cand_start = 1 + anchor_idx  # [CLS] offset
        scores = []

        for b in range(n):
            cand_tokens = len(candidates[b])
            if cand_tokens <= 0:
                scores.append(float('-inf'))
                continue
            cand_end = min(cand_start + cand_tokens, len(token_lists[b]))
            actual = cand_end - cand_start
            if actual <= 0:
                scores.append(float('-inf'))
                continue
            total = 0.0
            for p in range(actual):
                pos = cand_start + p
                tid = token_lists[b][pos]
                total += logits[b, pos, min(tid, actual_vocab - 1)]
            scores.append(float(total / actual))
        return scores

    @property
    def available(self) -> bool:
        return self._available


class HumanizeRules:
    """对标 4.1.1 HumanizeRules: AI 味替换 + 语义守卫"""

    def __init__(self, mlm: RobertaTinyMlm = None):
        self.mlm = mlm or RobertaTinyMlm()

    def humanize(self, text: str, max_replaces: int = 20) -> str:
        """对标 ApplyPreLLMAsync: AI 味词汇替换"""
        if not self.mlm.available or len(text) < 10:
            return text

        # AI 味高频词 → 候选替换
        ai_words = {
            "显然": ["很明显", "明摆着", "看得出来", "不言而喻"],
            "然而": ["可是", "不过", "但", "但是"],
            "因此": ["所以", "于是", "这样一来"],
            "此外": ["另外", "还有", "而且"],
            "似乎": ["好像", "仿佛", "像是"],
            "略微": ["稍稍", "稍微", "有点"],
            "迅速": ["飞快", "很快", "一下子"],
            "立即": ["马上", "立刻", "当即"],
            "突然": ["忽然", "猛地", "一下子"],
            "逐渐": ["慢慢", "渐渐", "一点点"],
            "极为": ["特别", "非常", "格外"],
            "感到": ["觉得", "觉着", "感觉"],
            "进行": ["做", "干", "搞", "弄"],
            "产生": ["出现", "发生", "冒出"],
            "导致": ["造成", "引起", "引来"],
            "依旧": ["还是", "仍然", "照旧"],
            "越发": ["越来越", "愈加", "越是"],
            "缓缓": ["慢慢", "徐徐", "渐渐"],
            "并未": ["没有", "没", "不曾"],
        }

        result = list(text)
        replaced = 0
        used = set()

        for word, candidates in ai_words.items():
            if replaced >= max_replaces:
                break
            current = "".join(result)  # 修改后的当前文本
            idx = 0
            while idx < len(current) - len(word):
                pos = current.find(word, idx)
                if pos == -1:
                    break

                avail = [c for c in candidates if c not in used]
                if not avail:
                    avail = list(candidates)
                    used.clear()

                scores = self.mlm.score_candidates(current, pos, word, avail)
                if scores:
                    best_idx = int(np.argmax(scores))
                    if scores[best_idx] > -100:
                        best = avail[best_idx]
                        result[pos:pos + len(word)] = list(best)
                        used.add(best)
                        replaced += 1
                idx = pos + 1

        return "".join(result)

    def semantic_guard(self, original: str, humanized: str, threshold: float = 0.85) -> bool:
        """对标 ISemanticGuard: 语义相似度校验"""
        if not self.mlm.available:
            return True
        return True  # 简化：文本级不需要 guard
