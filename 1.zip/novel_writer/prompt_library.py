# -*- coding: utf-8 -*-
"""提示词库：加载 25 题材模板，组装系统提示词与任务提示词"""

import json
import os

_PROMPT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "prompts")


class PromptTemplate:
    def __init__(self, data: dict):
        self.data = data

    @property
    def id(self): return self.data.get("Id", "")
    @property
    def name(self): return self.data.get("Name", "")
    @property
    def category(self): return self.data.get("Category", "")
    @property
    def system_prompt(self): return self.data.get("SystemPrompt", "")
    @property
    def user_template(self): return self.data.get("UserTemplate", "")
    @property
    def tags(self): return self.data.get("Tags", "")
    @property
    def description(self): return self.data.get("Description", "")
    @property
    def is_default(self): return bool(self.data.get("IsDefault", False))

    def to_dict(self):
        return self.data


class PromptLibrary:
    """加载 25 题材的 BizPrompt / Spec 模板"""

    def __init__(self, prompt_dir: str = None):
        self.prompt_dir = prompt_dir or _PROMPT_DIR
        self.biz_prompts = {}   # genre -> PromptTemplate
        self.spec_prompts = {}  # genre -> PromptTemplate
        self._load()

    @staticmethod
    def _extract_genre(tpl) -> str:
        tags = tpl.tags or ""
        first = tags.split(",")[0].strip() if tags else ""
        cat = tpl.category.strip()
        if first and len(first) <= 6:
            return first
        if "角色" in cat and len(cat) <= 8:
            return cat.replace("角色", "")
        return cat

    def _load(self):
        if not os.path.isdir(self.prompt_dir):
            return
        for filename in sorted(os.listdir(self.prompt_dir)):
            if not filename.endswith(".json"):
                continue
            path = os.path.join(self.prompt_dir, filename)
            try:
                with open(path, "r", encoding="utf-8") as f:
                    items = json.load(f)
            except (json.JSONDecodeError, OSError):
                continue
            if not isinstance(items, list):
                items = [items]
            for item in items:
                if not isinstance(item, dict):
                    continue
                tpl = PromptTemplate(item)
                genre = self._extract_genre(tpl)
                if "Spec" in (tpl.tags or "") and "创作规范" in (tpl.name or ""):
                    self.spec_prompts[genre] = tpl
                elif "GenreBiz" in (tpl.tags or "") or "角色定义" in (tpl.name or ""):
                    self.biz_prompts[genre] = tpl

    @property
    def genres(self) -> list:
        return sorted(set(list(self.spec_prompts.keys()) + list(self.biz_prompts.keys())))

    def get_spec(self, genre: str) -> PromptTemplate:
        return self.spec_prompts.get(genre)

    def get_biz(self, genre: str) -> PromptTemplate:
        return self.biz_prompts.get(genre)


# ---- 系统提示词分层 ----
DEVELOPER_PROMPT = """<identity immutable="true">
你是「天命」AI 网文创作引擎。你是一名专业的网文作家，擅长通过结构化数据管理一本长篇小说的创作过程。
你不依赖上下文记忆，而是严格依据系统提供的事实账本（Fact Ledger）写作。
</identity>
<output_rules>
- 严格遵守系统提示词中给出的所有优先级标记（priority="highest" 最高优先级）。
- 输出正文时不得包含任何思考过程、工具调用文本或解释。
- 创作规范（Spec）高于一般写作习惯。
</output_rules>
<safety_rules>
- 不得输出违法、色情、暴力极端内容。
- 不得声称自己是别的模型。
</safety_rules>"""


def build_system_prompt(genre: str, library: PromptLibrary, spec_overrides: str = "") -> str:
    """组装章节生成系统提示词：身份 → 题材规范 → 创作覆盖 → 业务提示词"""
    parts = [DEVELOPER_PROMPT]
    spec = library.get_spec(genre)
    if spec:
        parts.append(f'<genre_spec priority="highest" source="prompt_library">\n{spec.system_prompt}\n</genre_spec>')
    if spec_overrides:
        parts.append(
            f'<creative_spec_overrides override_target="genre_spec" priority="highest">\n{spec_overrides}\n</creative_spec_overrides>')
    biz = library.get_biz(genre)
    if biz:
        parts.append(
            f'<genre_bizprompt priority="high" source="prompt_library">\n{biz.system_prompt}\n</genre_bizprompt>')
    parts.append(GENERATION_BUSINESS_PROMPT)
    return "\n\n".join(parts)


GENERATION_BUSINESS_PROMPT = """<generation_business_rules priority="high">
1. 规格至上：严格遵守目标字数和段落长度，超长/过短均不合格。
2. 设定保护：不得违反事实账本（fact_ledger）中记录的硬约束与既有事实。
3. 剧情一致：遵循任务上下文中的大纲、分卷、章节计划与场景蓝图。
4. 纯正文：正文中不得出现标题以外的额外说明、括号备注或 AI 式总结。
5. 禁止情节重置：不得推翻前文已发生的事实。
6. 禁止段落复读：不得重复上一段或上一章结尾内容。
7. 禁止原地打转：每章必须有实质剧情推进。
</generation_business_rules>"""


def build_design_system_prompt(genre: str, library: PromptLibrary, role: str) -> str:
    """生成五维设定/规划用的系统提示词"""
    spec = library.get_spec(genre)
    parts = [DEVELOPER_PROMPT]
    if spec:
        parts.append(f'<genre_spec priority="highest" source="prompt_library">\n{spec.system_prompt}\n</genre_spec>')
    parts.append(f'<task_role>你现在扮演：{role}</task_role>')
    parts.append(GENERATION_BUSINESS_PROMPT)
    return "\n\n".join(parts)
