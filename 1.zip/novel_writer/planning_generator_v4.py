# -*- coding: utf-8 -*-
"""四层规划生成器 v4 - 对标 4.1.1 "小说创作者" 模板 (ActiveModuleHint 裁剪)"""
import json
import os
import re
from typing import List

from .models import (
    OutlineData, VolumeDesignData, ChapterData, BlueprintData, short_id, now_str,
)

# 对标 EntityFieldMeta
OUTLINE_FIELDS = {
    "名称": "Name", "总章节数": "TotalChapterCount", "一句话大纲": "OneLineOutline",
    "情感基调": "EmotionalTone", "哲学母题": "PhilosophicalMotif", "主题思想": "Theme",
    "核心冲突": "CoreConflict", "结局目标状态": "EndingState",
    "卷幕划分": "VolumeDivision", "大纲总览": "OutlineOverview",
}
VOLUME_FIELDS = {
    "名称": "Name", "卷序号": "VolumeNumber", "卷标题": "VolumeTitle",
    "卷主题": "VolumeTheme", "卷阶段目标": "StageGoal",
    "卷主冲突": "MainConflict", "压力来源": "PressureSource",
    "关键转折": "KeyEvents", "卷开篇状态": "OpeningState", "卷收束状态": "EndingState",
    "章节分配总览": "ChapterAllocationOverview", "剧情分配": "PlotAllocation",
    "章节生成提示": "ChapterGenerationHints",
    "出场角色": "ReferencedCharacterNames", "涉及势力": "ReferencedFactionNames",
    "涉及地点": "ReferencedLocationNames",
}
CHAPTER_FIELDS = {
    "名称": "Name", "章节标题": "ChapterTitle",
    "章节目标": "MainGoal", "章节主题": "ChapterTheme",
    "读者体验目标": "ReaderExperienceGoal", "阻力来源": "ResistanceSource",
    "关键转折": "KeyTurn", "钩子": "Hook",
    "世界信息释放": "WorldInfoDrop", "角色弧推进": "CharacterArcProgress",
    "主线推进": "MainPlotProgress", "伏笔": "Foreshadowing",
    "出场角色": "ReferencedCharacterNames", "涉及势力": "ReferencedFactionNames",
    "涉及地点": "ReferencedLocationNames",
}
BLUEPRINT_FIELDS = {
    "名称": "Name", "场景标题": "SceneTitle",
    "一句话结构": "OneLineStructure", "节奏曲线": "PacingCurve",
    "视点角色": "PovCharacter", "开场": "Opening", "发展": "Development",
    "转折": "Turning", "结尾": "Ending", "信息释放": "InfoDrop",
    "物品线索": "ItemsClues", "出场角色": "Cast",
    "涉及地点": "Locations", "涉及势力": "Factions",
}

MODULE_HINTS = {"outline": "战略大纲", "volume": "分卷设计",
                 "chapter": "章节规划", "blueprint": "章节蓝图"}


class PlanningGeneratorV4:
    """对标 4.1.1: "小说创作者" 模板 + ActiveModuleHint"""

    def __init__(self, ai_service, prompt_dir: str = None):
        self.ai = ai_service
        self.template = self._load(prompt_dir)

    def _load(self, prompt_dir: str = None):
        if not prompt_dir:
            prompt_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "prompts")
        for fname in ["小说创作者.json", "\u5c0f\u8bf4\u521b\u4f5c\u8005.json"]:
            path = os.path.join(prompt_dir, fname)
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    items = json.load(f)
                if isinstance(items, list) and items:
                    return items[0].get("SystemPrompt", "")
        return ""

    def _build_prompt(self, module: str, rule_name: str, variables: dict, context: str = "") -> tuple:
        """对标: 模板替换 {大纲名称}{章节标题}{场景标题} + 模块裁剪 + 上下文注入"""
        system = self.template
        for var in ["大纲名称", "章节标题", "场景标题"]:
            system = system.replace(f"{{{var}}}", variables.get(var, ""))

        hint = MODULE_HINTS.get(module)
        if hint:
            pattern = rf'<module_section id="{hint}">.*?</module_section>'
            m = re.search(pattern, system, re.S)
            if m:
                generic = system.split("【通用要求】")
                header = system.split("<module_section")[0]
                system = (header.strip() + "\n\n" + m.group(0) +
                          "\n\n【通用要求】" + (generic[1] if len(generic) > 1 else ""))
        if context:
            system += "\n\n" + context

        # User prompt = JSON 输出合约
        field_map = {"outline": OUTLINE_FIELDS, "volume": VOLUME_FIELDS,
                      "chapter": CHAPTER_FIELDS, "blueprint": BLUEPRINT_FIELDS}[module]
        user = json.dumps({cn: f"【{cn}】的值" for cn in field_map}, ensure_ascii=False)
        return system, user

    def _generate(self, module: str, rule_name: str, variables: dict, context: str = "") -> dict:
        system, user = self._build_prompt(module, rule_name, variables, context)
        text = self.ai.chat(system, user, category=f"规划_{module}")
        return self._extract_json(text)

    @staticmethod
    def _extract_json(text: str):
        if not text:
            return None
        t = text.strip()
        if t.startswith("```"):
            t = re.sub(r"^```(?:json)?\s*\n?", "", t)
            t = re.sub(r"\n?\s*```\s*$", "", t)
        start = t.find("{")
        if start == -1:
            return None
        depth, in_str, esc = 0, 0, 0
        for i in range(start, len(t)):
            ch = t[i]
            if in_str:
                if esc: esc = 0
                elif ch == "\\": esc = 1
                elif ch == '"': in_str = 0
                continue
            if ch == '"': in_str = 1
            elif ch == '{': depth += 1
            elif ch == '}':
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(t[start:i + 1])
                    except json.JSONDecodeError:
                        pass
        try:
            return json.loads(t)
        except json.JSONDecodeError:
            return None

    # ---- 对外接口 ----
    def generate_outline(self, total_chapters: int, context: str = "") -> OutlineData:
        data = self._generate("outline", "全书战略大纲",
                              {"大纲名称": "全书战略大纲", "章节标题": "", "场景标题": ""}, context)
        if not data:
            data = {}
        return OutlineData(
            Id=short_id("O"), Name=data.get("名称", "全书大纲"),
            TotalChapterCount=int(data.get("总章节数", total_chapters) or total_chapters),
            OneLineOutline=data.get("一句话大纲", ""),
            EmotionalTone=data.get("情感基调", ""),
            PhilosophicalMotif=data.get("哲学母题", ""),
            Theme=data.get("主题思想", ""),
            CoreConflict=data.get("核心冲突", ""),
            EndingState=data.get("结局目标状态", ""),
            VolumeDivision=data.get("卷幕划分", ""),
            OutlineOverview=data.get("大纲总览", ""),
            CreatedAt=now_str(), UpdatedAt=now_str(),
        )

    def generate_volume(self, volume_number: int, start: int, end: int, context: str = "") -> VolumeDesignData:
        data = self._generate("volume", f"第{volume_number}卷分卷设计",
                              {"大纲名称": f"第{volume_number}卷：", "章节标题": "", "场景标题": ""}, context)
        if not data:
            data = {}
        # 卷序号解析：对标 SafeParseInt
        vn_raw = data.get("卷序号", volume_number)
        vn = _parse_int(vn_raw) if isinstance(vn_raw, (str, int)) else volume_number
        if not vn or vn <= 0: vn = volume_number

        return VolumeDesignData(
            Id=short_id("V"), Name=data.get("名称", f"第{volume_number}卷"),
            VolumeNumber=int(vn) if vn else volume_number,
            VolumeTitle=_strip_prefix(data.get("卷标题", ""), "卷"),
            VolumeTheme=data.get("卷主题", ""), StageGoal=data.get("卷阶段目标", ""),
            StartChapter=start, EndChapter=end,
            TargetChapterCount=end - start + 1,
            MainConflict=data.get("卷主冲突", ""), PressureSource=data.get("压力来源", ""),
            KeyEvents=_split(data.get("关键转折", "")),
            OpeningState=data.get("卷开篇状态", ""), EndingState=data.get("卷收束状态", ""),
            ChapterAllocationOverview=data.get("章节分配总览", ""),
            PlotAllocation=data.get("剧情分配", ""),
            ChapterGenerationHints=data.get("章节生成提示", ""),
            ReferencedCharacterNames=_split(data.get("出场角色", "")),
            ReferencedFactionNames=_split(data.get("涉及势力", "")),
            ReferencedLocationNames=_split(data.get("涉及地点", "")),
            CreatedAt=now_str(), UpdatedAt=now_str(),
        )

    def generate_chapter(self, chapter_number: int, volume_title: str, context: str = "") -> ChapterData:
        data = self._generate("chapter", f"第{chapter_number}章章节规划",
                              {"大纲名称": "", "章节标题": f"第{chapter_number}章", "场景标题": ""}, context)
        if not data:
            data = {}
        return ChapterData(
            Id=short_id("CP"), Name=data.get("名称", data.get("章节标题", "")),
            ChapterNumber=chapter_number,
            ChapterTitle=_strip_prefix(data.get("章节标题", ""), "章"),
            Volume=volume_title,
            ChapterTheme=data.get("章节主题", ""),
            ReaderExperienceGoal=data.get("读者体验目标", ""),
            MainGoal=data.get("章节目标", ""),
            ResistanceSource=data.get("阻力来源", ""),
            KeyTurn=data.get("关键转折", ""), Hook=data.get("钩子", ""),
            WorldInfoDrop=data.get("世界信息释放", ""),
            CharacterArcProgress=data.get("角色弧推进", ""),
            MainPlotProgress=data.get("主线推进", ""),
            Foreshadowing=data.get("伏笔", ""),
            ReferencedCharacterNames=_split(data.get("出场角色", "")),
            ReferencedFactionNames=_split(data.get("涉及势力", "")),
            ReferencedLocationNames=_split(data.get("涉及地点", "")),
            CreatedAt=now_str(), UpdatedAt=now_str(),
        )

    def generate_blueprint(self, chapter: ChapterData, context: str = "") -> BlueprintData:
        data = self._generate("blueprint", f"第{chapter.ChapterNumber}章蓝图",
                              {"大纲名称": "", "章节标题": "", "场景标题": chapter.ChapterTitle}, context)
        if not data:
            data = {}
        return BlueprintData(
            Id=short_id("B"), Name=data.get("名称", data.get("场景标题", chapter.ChapterTitle)),
            ChapterId=chapter.Id, ChapterNumber=chapter.ChapterNumber,
            OneLineStructure=data.get("一句话结构", ""),
            PacingCurve=data.get("节奏曲线", ""),
            SceneNumber=1, SceneTitle=data.get("场景标题", ""),
            PovCharacter=data.get("视点角色", ""),
            Opening=data.get("开场", ""), Development=data.get("发展", ""),
            Turning=data.get("转折", ""), Ending=data.get("结尾", ""),
            InfoDrop=data.get("信息释放", ""),
            ItemsClues=_split(data.get("物品线索", "")),
            Cast=_split(data.get("出场角色", "")),
            Locations=_split(data.get("涉及地点", "")),
            Factions=_split(data.get("涉及势力", "")),
            CreatedAt=now_str(), UpdatedAt=now_str(),
        )


def _split(val):
    if not val or not isinstance(val, str):
        return []
    return [v.strip() for v in re.split(r"[、，,\n]", val) if v.strip()]


def _strip_prefix(title: str, suffix: str) -> str:
    """对标 VolumeTitlePrefixRegex: 去掉「第N卷/章」前缀"""
    if not title:
        return title
    import re
    return re.sub(rf"^第\s*\d+\s*{suffix}\s*[：:]?\s*", "", title).strip()


def _parse_int(val) -> int:
    """对标 SafeParseInt: 处理中文数字、阿拉伯数字、提取数字"""
    if isinstance(val, int):
        return val
    if not val or not isinstance(val, str):
        return 0
    s = val.strip()
    # 直接数字
    try:
        return int(s)
    except ValueError:
        pass
    # 中文数字
    cn = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}
    if s in cn:
        return cn[s]
    # 提取数字
    import re as _re
    digits = "".join(_re.findall(r"\d+", s))
    if digits:
        return int(digits)
    return 0
