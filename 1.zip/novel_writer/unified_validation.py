# -*- coding: utf-8 -*-
"""统一校验：对标 4.1.1 UnifiedValidation + PreflightValidator 全书级体检"""
import json, os, re
from typing import Dict, List

from .models import FactSnapshot
from .snapshot_extractor import SnapshotExtractor
from .gate import GenerationGate


class UnifiedValidation:
    def __init__(self, project):
        self.project = project
        self.gate = GenerationGate()

    def validate_all(self) -> dict:
        """全书级体检：设计引用 + 卷章关系 + 章节门禁 + 跨章一致性"""
        report = {"errors": [], "warnings": [], "chapter_results": []}

        # 1. 设计引用校验（对标 PreflightValidator）
        self._check_design_references(report)

        # 2. 卷-章层级关系
        self._check_hierarchy(report)

        # 3. 章节内容门禁重跑
        self._check_chapters(report)

        # 4. 跨章节一致性
        self._check_cross_chapter(report)

        is_valid = len(report["errors"]) == 0
        report["passed"] = is_valid
        return report

    def _load_plan(self, entity: str) -> list:
        data = self.project.load_plan(entity)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return data.get(entity, data.get("items", []))
        return []

    def _load_design(self, entity: str) -> list:
        data = self.project.load_design(entity)
        if isinstance(data, dict):
            return data.get("items", [])
        return data or []

    def _check_design_references(self, report):
        """分卷/章节/蓝图引用的角色/势力/地点是否在设计库中存在"""
        chars = self._load_design("characters")
        facs = self._load_design("factions")
        locs = self._load_design("locations")
        ch_names = {c.get("Name", "") for c in chars if c.get("Name")}
        f_names = {f.get("Name", "") for f in facs if f.get("Name")}
        l_names = {l.get("Name", "") for l in locs if l.get("Name")}

        volumes = self._load_plan("volumes")
        for v in volumes:
            vn = v.get("VolumeNumber", 0)
            label = f"第{vn}卷"
            for ref_names, ref_type, ref_label in [
                (v.get("ReferencedCharacterNames", []), ch_names, "出场角色"),
                (v.get("ReferencedFactionNames", []), f_names, "涉及势力"),
                (v.get("ReferencedLocationNames", []), l_names, "涉及地点"),
            ]:
                names = self._split(ref_names)
                unmatched = [n for n in names if n and n not in ref_type]
                if unmatched:
                    report["errors"].append(f"{label}「{ref_label}」未在设计库中存在: {'、'.join(unmatched[:5])}")

        chapters = self._load_plan("chapters")
        for ch in chapters:
            cn = ch.get("ChapterNumber", 0)
            label = f"第{cn}章"
            for ref_names, ref_type, ref_label in [
                (ch.get("ReferencedCharacterNames", []), ch_names, "出场角色"),
                (ch.get("ReferencedFactionNames", []), f_names, "涉及势力"),
                (ch.get("ReferencedLocationNames", []), l_names, "涉及地点"),
            ]:
                names = self._split(ref_names)
                unmatched = [n for n in names if n and n not in ref_type]
                if unmatched:
                    report["warnings"].append(f"{label}「{ref_label}」未在设计库中存在: {'、'.join(unmatched[:5])}")

    def _check_hierarchy(self, report):
        """卷-章-蓝图层级关系校验"""
        volumes = self._load_plan("volumes")
        chapters = self._load_plan("chapters")
        if not volumes or not chapters:
            return

        vol_numbers = {v.get("VolumeNumber", 0) for v in volumes if v.get("VolumeNumber", 0) > 0}
        for ch in chapters:
            vol = ch.get("Volume", "")
            cn = ch.get("ChapterNumber", 0)
            if not vol:
                report["errors"].append(f"第{cn}章「所属卷」为空")
                continue

    def _check_chapters(self, report):
        """逐章重跑门禁"""
        chapters = self._load_plan("chapters")
        for ch in chapters:
            cn = ch.get("ChapterNumber", 0)
            cid = ch.get("Id", "")
            content_raw = self.project.load_chapter(cid)
            if not content_raw:
                report["warnings"].append(f"第{cn}章：未生成")
                continue
            content = content_raw if isinstance(content_raw, str) else content_raw.get("content", "")
            if not content:
                report["warnings"].append(f"第{cn}章：空内容")
                continue

            extractor = SnapshotExtractor(self.project)
            snapshot = extractor.extract(cid, cn)
            design_names = {
                "角色": self._split(ch.get("ReferencedCharacterNames", [])),
                "势力": self._split(ch.get("ReferencedFactionNames", [])),
                "地点": self._split(ch.get("ReferencedLocationNames", [])),
            }
            result = self.gate.validate(content, snapshot, design_names, {}, cid)
            if not result.Success:
                errs = "; ".join(e for f in result.Failures for e in f.Errors)
                report["errors"].append(f"第{cn}章门禁失败: {errs[:200]}")
            else:
                report["chapter_results"].append({
                    "chapter": cn, "success": True,
                    "word_count": len(content.replace("\n", "").replace(" ", "")),
                })

    def _check_cross_chapter(self, report):
        """跨章节时序/状态一致性"""
        chapters = self._load_plan("chapters")
        if len(chapters) < 2:
            return
        # 检查连续章节的角色状态是否前后呼应
        for i in range(len(chapters) - 1):
            c1 = chapters[i]
            c2 = chapters[i + 1]
            c1_id, c1_num = c1.get("Id", ""), c1.get("ChapterNumber", 0)
            c2_id, c2_num = c2.get("Id", ""), c2.get("ChapterNumber", 0)
            # 检查章节序号连续性
            if c2_num != c1_num + 1:
                report["warnings"].append(f"章节序号不连续: 第{c1_num}章→第{c2_num}章")

    @staticmethod
    def _split(val) -> List[str]:
        if not val:
            return []
        if isinstance(val, list):
            return [str(n).strip() for n in val if n and str(n).strip()]
        if isinstance(val, str):
            return [n.strip() for n in re.split(r"[、，,\n]", val) if n.strip()]
        return []
