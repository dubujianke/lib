# -*- coding: utf-8 -*-
"""
对标 4.1.1 PopulateLongDistanceRecallAsync: 分段索引 + 粗排精排 + RRF
"""
import os, re, math, json
import numpy as np
from collections import defaultdict
from typing import Dict, List, Optional


class BgeEmbedder:
    """bge-small-zh-v1.5 ONNX 嵌入器"""

    def __init__(self, model_path: str = None):
        if not model_path:
            base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            for sub in ["bge-small-zh-v1.5", ""]:
                mp = os.path.join(base, sub, "model.onnx")
                vp = os.path.join(base, sub, "vocab.txt")
                if os.path.exists(mp) and os.path.exists(vp):
                    model_path = mp
                    break
        vocab_path = os.path.join(os.path.dirname(model_path), "vocab.txt") if model_path else ""
        self._available = os.path.exists(model_path) and os.path.exists(vocab_path)
        if not self._available:
            return
        import onnxruntime as ort
        self._session = ort.InferenceSession(model_path)
        self._vocab = self._load_vocab(vocab_path)
        self._dim = 512

    def _load_vocab(self, path: str) -> dict:
        vocab = {}
        with open(path, "r", encoding="utf-8") as f:
            for i, line in enumerate(f):
                vocab[line.strip()] = i
        return vocab

    def tokenize(self, text: str, max_len: int = 512) -> dict:
        tokens = []
        for ch in text[:max_len * 2]:
            tokens.append(self._vocab.get(ch, self._vocab.get("[UNK]", 100)))
        if not tokens:
            tokens = [self._vocab.get("[UNK]", 100)]
        tokens = tokens[:max_len - 2]
        cls_id = self._vocab.get("[CLS]", 101)
        sep_id = self._vocab.get("[SEP]", 102)
        pad_id = self._vocab.get("[PAD]", 0)
        input_ids = [cls_id] + tokens + [sep_id]
        attention_mask = [1] * len(input_ids)
        while len(input_ids) < max_len:
            input_ids.append(pad_id)
            attention_mask.append(0)
        return {
            "input_ids": np.array([input_ids], dtype=np.int64),
            "attention_mask": np.array([attention_mask], dtype=np.int64),
            "token_type_ids": np.zeros((1, len(input_ids)), dtype=np.int64),
        }

    def encode(self, text: str) -> Optional[np.ndarray]:
        if not self._available or not text or len(text.strip()) < 2:
            return np.zeros(self._dim, dtype=np.float32) if self._available else None
        inputs = self.tokenize(text, max_len=512)
        outputs = self._session.run(None, {
            "input_ids": inputs["input_ids"],
            "attention_mask": inputs["attention_mask"],
            "token_type_ids": inputs["token_type_ids"],
        })
        emb = outputs[0][0]
        mask = inputs["attention_mask"][0][:, None].astype(np.float32)
        return (emb * mask).sum(axis=0) / mask.sum()

    def encode_batch(self, texts: List[str]) -> List[np.ndarray]:
        return [self.encode(t) for t in texts]

    @property
    def available(self) -> bool:
        return self._available


# ====== 对标 BuildVectorSearchQuery ======
def build_vector_search_query(ctx: dict) -> str:
    parts = []
    plan = ctx.get("chapter_plan", ctx)
    if plan:
        title = plan.get("ChapterTitle", ctx.get("ChapterTitle", ""))
        if title: parts.append(f"「{title}」")
        goal = plan.get("MainGoal", "")
        if goal: parts.append(f"本章目标是{goal}")
        elif plan.get("ChapterTheme", ""): parts.append(f"本章主题是{plan['ChapterTheme']}")
        if plan.get("KeyTurn", ""): parts.append(f"，关键转折为{plan['KeyTurn']}")
    chars = ctx.get("characters", [])
    if chars:
        names = [c.get("Name", "") for c in chars[:5] if c.get("Name")]
        if names:
            prefix = "，涉及" if parts else "涉及"
            parts.append(f"{prefix}{'、'.join(names)}")
    fss = ctx.get("foreshadowings", [])
    unresolved = [f.get("Name", "") for f in fss if f.get("IsSetup") and not f.get("IsResolved") and f.get("Name")][:5]
    if unresolved:
        prefix = "，需要呼应伏笔" if parts else "需要呼应伏笔"
        parts.append(f"{prefix}{'、'.join(unresolved)}")
    if plan and plan.get("Foreshadowing", ""):
        ft = plan["Foreshadowing"]
        if len(ft) > 80: ft = ft[:80]
        parts.append(f"，伏笔安排：{ft}")
    rules = ctx.get("plot_rules", [])
    if rules:
        rnames = [r.get("Name", "") for r in rules[:3] if r.get("Name")]
        if rnames:
            prefix = "，遵循" if parts else "遵循"
            parts.append(f"{prefix}{'、'.join(rnames)}")
    query = "".join(parts)
    return query[:400] if len(query) > 400 else query


def collect_query_ids(ctx: dict) -> List[str]:
    ids = []
    for c in ctx.get("characters", [])[:5]:
        if c.get("Id"): ids.append(c["Id"])
    for f in ctx.get("foreshadowings", [])[:5]:
        if f.get("IsSetup") and not f.get("IsResolved") and f.get("ForeshadowId"):
            ids.append(f["ForeshadowId"])
    for p in ctx.get("plot_rules", [])[:3]:
        if p.get("Id"): ids.append(p["Id"])
    for l in ctx.get("locations", [])[:3]:
        if l.get("Id"): ids.append(l["Id"])
    for fac in ctx.get("factions", [])[:3]:
        if fac.get("Id"): ids.append(fac["Id"])
    return ids


class LongDistanceRecall:
    """长距召回: 对标 ContentChunkSearchService + ChapterEmbeddingIndex + ChunkEmbeddingIndex"""

    def __init__(self, project, embedder: BgeEmbedder = None):
        self.project = project
        self.embedder = embedder or BgeEmbedder()
        self._chunks = []          # [{chapter_id, position, content}]
        self._keyword_index = defaultdict(set)  # keyword → set(chapter_id)
        self._chunk_vecs = {}     # "chapter_id|position" → vector
        self._chapter_vecs = {}   # chapter_id → vector
        self._dirty = True

    def build_index(self):
        """对标 ChapterEmbeddingIndex.LoadAsync + ChunkEmbeddingIndex.LoadAsync"""
        chapters = self._load_chapters()
        if not chapters: return
        self._chunks.clear(); self._keyword_index.clear()
        self._chunk_vecs.clear(); self._chapter_vecs.clear()

        texts_for_embed = []

        for ch in chapters:
            cid = ch.get("Id", "")
            if not cid: continue
            text = self.project.load_chapter(cid)
            if isinstance(text, dict): text = text.get("content", "")
            if not text or len(text) < 100: continue

            # 分段（对标 ContentChunkSearchService 段落级分块）
            paragraphs = [p.strip() for p in re.split(r"\n\n+", text) if len(p.strip()) >= 100]
            if not paragraphs:
                paragraphs = [text[:500]]

            for pos, para in enumerate(paragraphs):
                key = f"{cid}|{pos}"
                self._chunks.append({"chapter_id": cid, "position": pos, "content": para})
                # 关键词倒排索引
                kws = self._extract_keywords(para)
                for kw in kws:
                    self._keyword_index[kw].add(cid)
                # 句子
                texts_for_embed.append(para)

            # 章级嵌入
            if self.embedder.available:
                chapter_text = text[:1000]
                vec = self.embedder.encode(chapter_text)
                if vec is not None:
                    self._chapter_vecs[cid] = vec

        # 块级嵌入
        if self.embedder.available and texts_for_embed:
            vecs = self.embedder.encode_batch(texts_for_embed)
            for i, (chunk, vec) in enumerate(zip(self._chunks, vecs)):
                if vec is not None:
                    key = f"{chunk['chapter_id']}|{chunk['position']}"
                    self._chunk_vecs[key] = vec

        self._dirty = False

    def search_by_buckets(self, ctx: dict, chapter_id: str = "", prev_chapter_id: str = "",
                          top_k: int = 5) -> str:
        """对标 PopulateLongDistanceRecallAsync 完整流程"""
        if self._dirty: self.build_index()

        query_text = build_vector_search_query(ctx)
        query_ids = collect_query_ids(ctx)
        if not query_text: return ""

        # 三桶
        fs_text = "。".join(
            f.get("Name", "") for f in ctx.get("foreshadowings", [])
            if f.get("IsSetup") and not f.get("IsResolved"))
        char_text = "。".join(
            f"{c.get('Name','')}：{c.get('Identity','')}" if c.get("Identity") else c.get("Name", "")
            for c in ctx.get("characters", [])[:5])
        gen_parts = [ctx.get("MainGoal", ""), ctx.get("KeyTurn", ""),
                     ctx.get("ChapterTheme", ""), ctx.get("ChapterTitle", "")]
        gen_text = "。".join(p for p in gen_parts if p)

        from_ctx = ctx.get("chapter_id", chapter_id)
        prev_ctx = ctx.get("previous_chapter_id", prev_chapter_id)

        # 4路检索
        tf_hits = self._tfidf_search(query_text, 10)
        kw_hits = self._keyword_search(query_ids, 10)
        for_hits = self._vector_search_bucket(fs_text, 5) if fs_text.strip() else []
        char_hits = self._vector_search_bucket(char_text, 5) if char_text.strip() else []
        gen_hits = self._vector_search_bucket(gen_text, 8) if gen_text.strip() else []

        # 对标: 排除当前章/前章
        def exclude(hits):
            return [h for h in hits if h["chapter_id"] != from_ctx and h["chapter_id"] != prev_ctx]
        tf_hits = exclude(tf_hits)
        kw_hits = exclude(kw_hits)
        for_hits = exclude(for_hits)
        char_hits = exclude(char_hits)
        gen_hits = exclude(gen_hits)

        # 对标: 分数归一化 Score / pathMax
        def path_max(hits, default=1.0):
            return max((h["score"] for h in hits), default=default)
        tf_max = path_max(tf_hits)
        kw_max = path_max(kw_hits)
        for_max = path_max(for_hits)
        char_max = path_max(char_hits)
        gen_max = path_max(gen_hits)

        # RRF 融合 (对标 4路: TF + KW + VecF + VecC + VecG)
        rrf = defaultdict(float)
        cats = {}
        K = 60
        def add(hits, cat, max_val):
            for i, h in enumerate(hits):
                cid = h["chapter_id"]
                rrf[cid] += 1.0 / (K + i)
                cats.setdefault(cid, cat)
        add(tf_hits, "General", tf_max)
        add(kw_hits, "General", kw_max)
        add(for_hits, "Foreshadowing", for_max)
        add(char_hits, "Character", char_max)
        add(gen_hits, "General", gen_max)

        # 类别配额
        sorted_hits = sorted(rrf.items(), key=lambda x: -x[1])
        quota = []
        f_c, c_c, g_c = 0, 0, 0
        for cid, score in sorted_hits:
            cat = cats.get(cid, "General")
            if cat == "Foreshadowing" and f_c < 2:
                f_c += 1; quota.append((cid, score, cat))
            elif cat == "Character" and c_c < 2:
                c_c += 1; quota.append((cid, score, cat))
            elif cat == "General" and g_c < 4:
                g_c += 1; quota.append((cid, score, cat))
            if f_c >= 2 and c_c >= 2 and g_c >= 4: break

        if not quota: return ""

        # 对标 AppendLongDistanceRecallSection: 返回纯文本片端，由 prompt_builder 统一包装
        lines = []
        for cid, score, cat in quota[:top_k]:
            snippet = self._pick_best(cid)
            if not snippet: snippet = self._get_first_chunk(cid)
            lines.append(f"[{cat}] Ch{cid[:8]} score={score:.4f}:")
            lines.append(f"  {snippet[:350]}")
        return "\n".join(lines)

    # ---- 检索方法 ----
    def _tfidf_search(self, query: str, top_k: int) -> List[dict]:
        """对标 ContentChunkSearchService.SearchAsync: 分段 TF-IDF"""
        q_terms = _tokenize(query)
        if not q_terms: return []
        scores = defaultdict(float)
        for chunk in self._chunks:
            cid = chunk["chapter_id"]
            for t in q_terms:
                scores[cid] += chunk["content"].count(t) * 0.01
        return sorted([{"chapter_id": k, "score": v} for k, v in scores.items() if v > 0],
                      key=lambda x: -x["score"])[:top_k]

    def _keyword_search(self, ids: List[str], top_k: int) -> List[dict]:
        """对标 KeywordChapterIndexService: 倒排索引"""
        if not ids: return []
        scores = defaultdict(int)
        for id_str in ids:
            for cid in self._keyword_index.get(id_str, set()):
                scores[cid] += 1
        return sorted([{"chapter_id": k, "score": v} for k, v in scores.items()],
                      key=lambda x: -x["score"])[:top_k]

    def _vector_search_bucket(self, query: str, top_k: int) -> List[dict]:
        """对标 HybridSearchWithVecAsync: 粗排(章级) → 精排(块级) 两阶段"""
        if not self.embedder.available or not self._chapter_vecs: return []
        q_vec = self.embedder.encode(query)
        if q_vec is None: return []
        q_norm = np.linalg.norm(q_vec)
        if q_norm < 1e-8: return []

        # 粗排: 章级 cosine
        coarse = []
        for cid, vec in self._chapter_vecs.items():
            v_norm = np.linalg.norm(vec)
            if v_norm < 1e-8: continue
            sim = float(np.dot(q_vec, vec) / (q_norm * v_norm))
            if sim > 0.3:
                coarse.append((cid, sim))
        coarse.sort(key=lambda x: -x[1])
        candidate_ids = {c[0] for c in coarse[:min(len(coarse), top_k * 3)]}
        if not candidate_ids: return [{"chapter_id": c[0], "score": c[1]} for c in coarse[:top_k]]

        # 精排: 块级 cosine
        chunk_scores = defaultdict(float)
        for key, vec in self._chunk_vecs.items():
            cid, pos = key.split("|", 1)
            if cid not in candidate_ids: continue
            v_norm = np.linalg.norm(vec)
            if v_norm < 1e-8: continue
            sim = float(np.dot(q_vec, vec) / (q_norm * v_norm))
            if sim > chunk_scores[cid]:
                chunk_scores[cid] = sim

        return sorted([{"chapter_id": k, "score": v} for k, v in chunk_scores.items()],
                      key=lambda x: -x["score"])[:top_k]

    def _pick_best(self, chapter_id: str) -> str:
        """对标 PickBestContentAsync: TF内容优先 → chunk反查 → 章首fallback"""
        chunks = [c for c in self._chunks if c["chapter_id"] == chapter_id]
        if not chunks: return ""
        # 按 position 排序，取中间段（最可能是核心情节）
        chunks.sort(key=lambda c: c["position"])
        mid = len(chunks) // 2
        return chunks[min(mid, len(chunks) - 1)]["content"][:500]

    def _get_first_chunk(self, chapter_id: str) -> str:
        for c in self._chunks:
            if c["chapter_id"] == chapter_id:
                return c["content"][:300]
        return ""

    # ---- 索引构建 ----
    def _load_chapters(self) -> List[dict]:
        plans = self.project.load_plan("chapters")
        if isinstance(plans, list): return plans
        if isinstance(plans, dict): return plans.get("chapters", [])
        return []

    @staticmethod
    def _extract_keywords(text: str) -> List[str]:
        """中文关键词提取（2-4字）"""
        clean = re.sub(r"[^\u4e00-\u9fff0-9A-Za-z]", "", text)
        kws = set()
        for w in [2, 3, 4]:
            for i in range(len(clean) - w + 1):
                seg = clean[i:i + w]
                if not seg.isdigit() and not all('a' <= c.lower() <= 'z' for c in seg):
                    kws.add(seg)
        return list(kws)[:100]


def _tokenize(text: str) -> List[str]:
    text = re.sub(r"[^\u4e00-\u9fff]", "", text)
    tokens = []
    for w in [2, 3]:
        for i in range(len(text) - w + 1):
            tokens.append(text[i:i + w])
    return tokens
