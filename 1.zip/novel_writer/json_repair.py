# -*- coding: utf-8 -*-
"""对标 RepairChangesJson + ValidateShortIdFields"""
import re
from typing import List
from .models import CHINESE_FIELD_MAP, is_likely_id


def repair_changes_json(json_text: str) -> str:
    """对标 4.1.1 RepairChangesJson: 中文键映射+全角→半角+单引号→双引号+去尾逗号+自动补括号+控制字符"""
    if not json_text or not json_text.strip():
        return json_text

    s = json_text.strip()

    # 1. 去注释 (对标 RemoveJsonComments)
    s = re.sub(r"//[^\n]*", "", s)

    # 2. 中文键名映射
    for cn, en in CHINESE_FIELD_MAP.items():
        s = s.replace(f'"{cn}"', f'"{en}"')

    # 3. 逐字符修复
    result = []
    in_string = False
    string_quote = '"'
    escape = False
    bracket_stack = []
    i = 0

    while i < len(s):
        c = s[i]

        if in_string:
            if escape:
                escape = False
                result.append(c)
                i += 1
                continue
            if c == '\\':
                escape = True
                result.append(c)
                i += 1
                continue
            if c == string_quote:
                in_string = False
                result.append('"')
                i += 1
                continue
            # 控制字符转义
            if c == '\n':
                result.append('\\n')
            elif c == '\r':
                pass  # skip
            elif c == '\t':
                result.append('\\t')
            elif c == '\b':
                result.append('\\b')
            elif c == '\f':
                result.append('\\f')
            elif ord(c) < 0x20:
                result.append(f'\\u{ord(c):04X}')
            else:
                result.append(c)
            i += 1
            continue

        # 单引号→双引号
        if c == "'":
            in_string = True
            string_quote = "'"
            result.append('"')
            i += 1
            continue

        if c == '"':
            in_string = True
            string_quote = '"'
            result.append('"')
            i += 1
            continue

        # 全角→半角
        if c == '：':
            result.append(':')
            i += 1
            continue
        if c == '，':
            result.append(',')
            i += 1
            continue

        # 去尾逗号: , 后面紧跟 } 或 ]
        if c == ',':
            j = i + 1
            while j < len(s) and s[j] in ' \t\r\n':
                j += 1
            if j < len(s) and s[j] in '}]':
                i += 1
                continue
            result.append(c)
            i += 1
            continue

        # 自动补括号
        if c == '}':
            if bracket_stack and bracket_stack[-1] == '{':
                bracket_stack.pop()
                result.append(c)
                i += 1
                continue
            # 补缺的 ]
            need_close = []
            temp_stack = list(bracket_stack)
            while temp_stack and temp_stack[-1] != '{':
                need_close.append(temp_stack.pop())
            if need_close:
                for closer in need_close:
                    if closer == '[':
                        result.append(']')
            result.append(c)
            if bracket_stack and bracket_stack[-1] == '{':
                bracket_stack.pop()
            i += 1
            continue

        if c == ']':
            if bracket_stack and bracket_stack[-1] == '[':
                bracket_stack.pop()
            result.append(c)
            i += 1
            continue

        if c in '{[':
            bracket_stack.append(c)
            result.append(c)
            i += 1
            continue

        result.append(c)
        i += 1

    # 闭合未关闭的字符串
    if in_string:
        result.append('"')

    # 补未闭合的括号
    while bracket_stack:
        last = bracket_stack.pop()
        result.append('}' if last == '{' else ']')

    return ''.join(result)


def validate_shortid_fields(text: str) -> List[str]:
    """对标 ValidateShortIdFields: 格式校验"""
    errors = []
    # 匹配所有用引号包裹的 ID 格式值
    for m in re.finditer(r'"([A-Z][0-9A-Z]{12,15})"', text):
        val = m.group(1)
        if not is_likely_id(val):
            errors.append(f"ID格式非法: {val}")
    return errors
