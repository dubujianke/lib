# -*- coding: utf-8 -*-
"""拆书模块：读本地小说 → AI 分析结构 → 提炼可复用的创作模板"""

import json
import os
import re
from typing import Dict, List, Optional


class BookReader:
    """读取 D:/xiaoshuo_data 下的小说数据"""

    def __init__(self, root: str = r"D:\xiaoshuo_data"):
        self.root = root

    def list_books(self) -> List[dict]:
        books = []
        for name in os.listdir(self.root):
            path = os.path.join(self.root, name)
            if not os.path.isdir(path):
                continue
            info = self._read_info(path)
            ch_count = self._count_chapters(path)
            books.append({
                "id": name,
                "path": path,
                "info": info,
                "chapter_count": ch_count,
            })
        return sorted(books, key=lambda b: b["id"])

    def _read_info(self, dirpath: str) -> dict:
        info_path = os.path.join(dirpath, "info.txt")
        if not os.path.exists(info_path):
            return {}
        try:
            with open(info_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return {}

    def _count_chapters(self, dirpath: str) -> int:
        count = 0
        for f in os.listdir(dirpath):
            if f.endswith(".txt") and f != "info.txt":
                count += 1
        return count

    def get_chapters(self, dirpath: str) -> List[dict]:
        """返回 [(序号, 标题, 路径), ...] 按序号排序"""
        chs = []
        for f in os.listdir(dirpath):
            if not f.endswith(".txt") or f == "info.txt":
                continue
            path = os.path.join(dirpath, f)
            num, title = self._parse_chapter_name(f)
            chs.append((num, title, path))
        chs.sort(key=lambda x: x[0])
        return [{"number": n, "title": t, "path": p} for n, t, p in chs]

    @staticmethod
    def _parse_chapter_name(filename: str) -> tuple:
        name = filename.replace(".txt", "")
        # 第100章 标题 → (100, "标题")
        m = re.match(r"第\s*(\d+)\s*[章章节]\s*(.*)", name)
        if m:
            return int(m.group(1)), m.group(2).strip()
        # 纯数字 100.txt → (100, "")
        m = re.match(r"(\d+)", name)
        if m:
            return int(m.group(1)), ""
        return 0, name

    def read_chapter(self, path: str) -> str:
        try:
            with open(path, "r", encoding="utf-8") as f:
                text = f.read()
            # 去首行标题（如果首行是"第X章"格式）
            lines = text.split("\n", 1)
            if lines and re.match(r"第\s*\d+\s*[章章节]", lines[0].strip()):
                return lines[1].strip() if len(lines) > 1 else ""
            return text.strip()
        except (OSError, UnicodeDecodeError) as e:
            return f""


class ChapterSelector:
    """智能选取关键章节：开篇 / 转折点 / 高潮 / 结尾"""

    def select(self, chapters: List[dict], max_count: int = 12) -> List[str]:
        """返回选中章节的原始路径列表"""
        total = len(chapters)
        if total == 0:
            return []
        if total <= max_count:
            return [c["path"] for c in chapters]

        indices = []
        n = max_count
        # 开头 25%: n/4 章，均匀分布
        head_count = max(2, n // 4)
        head_end = max(1, total // 4)
        indices.extend(self._sample_range(0, head_end, head_count))
        # 中段: n/2 章，均匀分布
        mid_count = max(3, n // 2)
        mid_start = head_end
        mid_end = max(mid_start + 1, total - head_end)
        indices.extend(self._sample_range(mid_start, mid_end, mid_count))
        # 结尾 25%: n/4 章
        tail_count = n - len(indices)
        tail_start = mid_end
        tail_end = total
        indices.extend(self._sample_range(tail_start, tail_end, tail_count))

        return [chapters[i]["path"] for i in sorted(set(indices))[:max_count]
                if 0 <= i < total]

    @staticmethod
    def _sample_range(start, end, count) -> List[int]:
        if count <= 0 or end <= start:
            return []
        step = max(1, (end - start) // count)
        return [start + i * step for i in range(count) if start + i * step < end]
