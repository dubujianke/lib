# -*- coding: utf-8 -*-
"""通用基类与工具"""

import random
import time
import uuid

_BASE32_ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"


def short_id(prefix: str = "D") -> str:
    """生成 13 位短 ID：1 前缀字母 + 12 位（41bit 时间戳 + 19bit 随机）Base32"""
    ts = int(time.time() * 1000) & ((1 << 41) - 1)
    rnd = random.getrandbits(19)
    val = (ts << 19) | rnd
    chars = []
    for _ in range(12):
        chars.append(_BASE32_ALPHABET[val & 31])
        val >>= 5
    return prefix + "".join(reversed(chars))


def is_likely_id(value) -> bool:
    """判断一个值是否像 ShortId（13 字符、大写字母开头）"""
    if not isinstance(value, str):
        return False
    if len(value) != 13:
        return False
    if not value[0].isalpha() or not value[0].isupper():
        return False
    return all(c in _BASE32_ALPHABET for c in value)


def now_str() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())


class JsonModel:
    """提供 to_dict / from_dict 的 dataclass 基类"""

    def to_dict(self) -> dict:
        result = {}
        for field, value in self.__dict__.items():
            result[field] = _to_serializable(value)
        return result

    @classmethod
    def from_dict(cls, data: dict):
        if data is None:
            return None
        init = {}
        for field, value in data.items():
            if field in cls.__dataclass_fields__:
                init[field] = _from_serializable(value, cls.__dataclass_fields__[field].type)
        return cls(**init)

    @staticmethod
    def ensure_list(value, cls):
        if value is None:
            return []
        return [cls.from_dict(v) if isinstance(v, dict) else v for v in value]


def _to_serializable(value):
    if isinstance(value, JsonModel):
        return value.to_dict()
    if isinstance(value, list):
        return [_to_serializable(v) for v in value]
    if isinstance(value, dict):
        return {k: _to_serializable(v) for k, v in value.items()}
    return value


def _from_serializable(value, expected_type):
    if value is None:
        return None
    # 递归处理 list[Model] 类型
    origin = getattr(expected_type, "__origin__", None)
    if origin is list and isinstance(value, list):
        inner = expected_type.__args__[0] if expected_type.__args__ else None
        if isinstance(inner, type) and issubclass(inner, JsonModel):
            return [inner.from_dict(v) if isinstance(v, dict) else v for v in value]
        return value
    if isinstance(expected_type, type) and issubclass(expected_type, JsonModel) and isinstance(value, dict):
        return expected_type.from_dict(value)
    return value
