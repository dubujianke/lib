# -*- coding: utf-8 -*-
"""五维设计数据模型（五大规则）"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional
from .common import JsonModel


@dataclass
class BusinessDataBase(JsonModel):
    Id: str = ""
    Name: str = ""
    Category: str = ""
    CategoryId: str = ""
    IsEnabled: bool = True
    CreatedAt: str = ""
    UpdatedAt: str = ""


@dataclass
class WorldRulesData(BusinessDataBase):
    """世界观规则"""
    OneLineSummary: str = ""
    PowerSystem: str = ""
    Cosmology: str = ""
    SpecialLaws: str = ""
    HardRules: List[str] = field(default_factory=list)   # 不可违反的硬规则
    SoftRules: List[str] = field(default_factory=list)
    AncientEra: str = ""
    KeyEvents: List[str] = field(default_factory=list)
    ModernHistory: str = ""
    StatusQuo: str = ""


@dataclass
class CharacterRulesData(BusinessDataBase):
    """角色规则"""
    CharacterType: str = ""          # 主角/反派/配角
    Gender: str = ""
    Age: str = ""
    Identity: str = ""
    Race: str = ""
    Appearance: str = ""             # 外貌（含发色、瞳色，供描写一致性校验）
    Personality: str = ""            # 性格标签
    # 角色弧光
    Want: str = ""
    Need: str = ""
    FlawBelief: str = ""
    GrowthPath: str = ""
    # 关系
    TargetCharacterName: str = ""
    RelationshipType: str = ""
    EmotionDynamic: str = ""
    Relationships: Dict[str, str] = field(default_factory=dict)
    # 能力
    CombatSkills: List[str] = field(default_factory=list)
    NonCombatSkills: List[str] = field(default_factory=list)
    SpecialAbilities: List[str] = field(default_factory=list)
    # 资产
    SignatureItems: List[str] = field(default_factory=list)
    CommonItems: List[str] = field(default_factory=list)
    PersonalAssets: str = ""
    IsPov: bool = False              # 是否为视角角色


@dataclass
class FactionRulesData(BusinessDataBase):
    """势力规则"""
    FactionType: str = ""
    Goal: str = ""
    StrengthTerritory: str = ""
    Leader: str = ""
    CoreMembers: List[str] = field(default_factory=list)
    MemberTraits: str = ""
    Allies: List[str] = field(default_factory=list)
    Enemies: List[str] = field(default_factory=list)
    NeutralCompetitors: List[str] = field(default_factory=list)


@dataclass
class LocationRulesData(BusinessDataBase):
    """地点规则"""
    LocationType: str = ""
    Description: str = ""
    Scale: str = ""
    Terrain: str = ""
    Climate: str = ""
    Landmarks: List[str] = field(default_factory=list)
    Resources: List[str] = field(default_factory=list)
    HistoricalSignificance: str = ""
    Dangers: List[str] = field(default_factory=list)
    FactionId: str = ""


@dataclass
class PlotRulesData(BusinessDataBase):
    """剧情规则"""
    TargetVolume: int = 0
    AssignedVolume: int = 0
    OneLineSummary: str = ""
    EventType: str = ""
    StoryPhase: str = ""
    PrerequisitesTrigger: str = ""
    MainCharacters: List[str] = field(default_factory=list)
    KeyNpcs: List[str] = field(default_factory=list)
    Location: str = ""
    TimeDuration: str = ""
    StepTitle: str = ""
    Goal: str = ""
    Conflict: str = ""
    Result: str = ""
    EmotionCurve: str = ""
    MainPlotPush: str = ""
    CharacterGrowth: str = ""
    WorldReveal: str = ""
    RewardsClues: str = ""


@dataclass
class CreativeMaterialData(BusinessDataBase):
    """创意素材库"""
    Content: str = ""
    SourceType: str = ""   # 灵感/写作参考/模板
    Tags: List[str] = field(default_factory=list)
