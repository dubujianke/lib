# -*- coding: utf-8 -*-
"""四层规划数据模型（大纲→分卷→章节→蓝图）"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional
from .common import JsonModel
from .design import BusinessDataBase


@dataclass
class OutlineData(BusinessDataBase):
    """大纲"""
    TotalChapterCount: int = 0
    OneLineOutline: str = ""
    EmotionalTone: str = ""
    PhilosophicalMotif: str = ""
    Theme: str = ""
    CoreConflict: str = ""
    EndingState: str = ""
    VolumeDivision: str = ""          # 卷划分描述（供分卷生成解析）
    OutlineOverview: str = ""


@dataclass
class VolumeDesignData(BusinessDataBase):
    """分卷设计"""
    VolumeNumber: int = 0
    VolumeTitle: str = ""
    VolumeTheme: str = ""
    StageGoal: str = ""
    TargetChapterCount: int = 0
    StartChapter: int = 0
    EndChapter: int = 0
    MainConflict: str = ""
    PressureSource: str = ""
    KeyEvents: List[str] = field(default_factory=list)
    OpeningState: str = ""
    EndingState: str = ""
    ReferencedCharacterNames: List[str] = field(default_factory=list)
    ReferencedFactionNames: List[str] = field(default_factory=list)
    ReferencedLocationNames: List[str] = field(default_factory=list)
    ChapterAllocationOverview: str = ""
    PlotAllocation: str = ""
    ChapterGenerationHints: str = ""


@dataclass
class ChapterData(BusinessDataBase):
    """章节设计"""
    ChapterNumber: int = 0
    ChapterTitle: str = ""
    Volume: str = ""
    ChapterTheme: str = ""
    ReaderExperienceGoal: str = ""
    MainGoal: str = ""
    ResistanceSource: str = ""
    KeyTurn: str = ""
    Hook: str = ""
    WorldInfoDrop: str = ""
    CharacterArcProgress: str = ""
    MainPlotProgress: str = ""
    Foreshadowing: str = ""
    ReferencedCharacterNames: List[str] = field(default_factory=list)
    ReferencedFactionNames: List[str] = field(default_factory=list)
    ReferencedLocationNames: List[str] = field(default_factory=list)


@dataclass
class BlueprintData(BusinessDataBase):
    """章节蓝图"""
    ChapterId: str = ""
    ChapterNumber: int = 0
    OneLineStructure: str = ""
    PacingCurve: str = ""
    SceneNumber: int = 0
    SceneTitle: str = ""
    PovCharacter: str = ""
    Opening: str = ""
    Development: str = ""
    Turning: str = ""
    Ending: str = ""
    InfoDrop: str = ""
    Cast: List[str] = field(default_factory=list)
    Locations: List[str] = field(default_factory=list)
    Factions: List[str] = field(default_factory=list)
    ItemsClues: List[str] = field(default_factory=list)
