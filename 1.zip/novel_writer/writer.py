# -*- coding: utf-8 -*-
"""章节生成闭环：写前读取 → AI 写作 → 门禁校验 → 正文落地 → 状态回写"""

import json
import os
from typing import Dict, List, Optional

from .models import (
    ChapterChanges, FactSnapshot, ChapterData, BlueprintData, short_id, now_str,
)
from .prompt_library import PromptLibrary, build_system_prompt
from .prompt_builder import (
    build_chapter_task_prompt, format_fact_snapshot,
    split_content_and_changes,
)
from .ai_service import AIService
from .snapshot_extractor import SnapshotExtractor
from .gate import GenerationGate, GateResult
from .tracking_services import TrackingManager
from .storage import Project


class ChapterWriter:
    """负责单章生成的完整闭环"""

    def __init__(self, project: Project, ai: AIService, library: PromptLibrary,
                 max_rewrite_attempts: int = 3):
        self.project = project
        self.ai = ai
        self.library = library
        self.gate = GenerationGate()
        self.snapshot_extractor = SnapshotExtractor(project)
        self.tracking = TrackingManager(project)
        self.max_rewrite_attempts = max_rewrite_attempts

    # ---- 写前读取 ----
    def build_context(self, chapter: ChapterData, blueprints: List[BlueprintData],
                      volume: dict, outline: dict, world: dict, characters: List[dict],
                      factions: List[dict], locations: List[dict], plot: dict,
                      materials: List[dict]) -> tuple:
        """返回 (snapshot, context_ids, prev_tail, summaries, milestones, recall_fragments)"""
        snapshot = self.snapshot_extractor.extract(chapter.Id, chapter.ChapterNumber)
        context_ids = {
            "角色": chapter.ReferencedCharacterNames,
            "地点": chapter.ReferencedLocationNames,
            "势力": chapter.ReferencedFactionNames,
        }
        prev_id = self._find_previous_chapter(chapter)
        prev_tail = ""
        if prev_id:
            prev_tail = self.project.load_chapter(prev_id)
        summaries = self._get_summaries(chapter)
        milestones = ""

        # 对标 PopulateLongDistanceRecallAsync: TF-IDF + 关键词召回
        recall = self._get_long_distance_recall(chapter, characters, snapshot)
        return snapshot, context_ids, prev_tail, summaries, milestones, recall

    def _get_long_distance_recall(self, chapter, characters, snapshot) -> str:
        ctx = {
            "ChapterTitle": chapter.ChapterTitle,
            "MainGoal": chapter.MainGoal,
            "ChapterTheme": chapter.ChapterTheme,
            "KeyTurn": chapter.KeyTurn,
            "Foreshadowing": chapter.Foreshadowing,
            "chapter_id": chapter.Id,
            "characters": [{"Name": c.get("Name", ""), "Id": c.get("Id", ""), "Identity": c.get("Identity", "")}
                           for c in (characters or [])[:5]],
            "foreshadowings": [
                {"IsSetup": f.IsSetup, "IsResolved": f.IsResolved, "Name": f.Name,
                 "ForeshadowId": f.ForeshadowId}
                for f in (snapshot.ForeshadowingStatus or [])
                if f.IsSetup and not f.IsResolved
            ][:5] if snapshot and snapshot.ForeshadowingStatus else [],
        }
        from .long_distance_recall import LongDistanceRecall
        rec = LongDistanceRecall(self.project)
        return rec.search_by_buckets(ctx, chapter_id=chapter.Id)

    def _find_previous_chapter(self, chapter: ChapterData) -> str:
        plans = self.project.load_plan("chapters")
        chapters = plans if isinstance(plans, list) else plans.get("chapters", [])
        target = chapter.ChapterNumber - 1
        for c in chapters:
            if c.get("ChapterNumber") == target:
                return c.get("Id", "")
        return ""

    def _get_summaries(self, chapter: ChapterData) -> str:
        """前 3 章递进式摘要"""
        guide = self.project.guide("chapter_summaries").data()
        plans = self.project.load_plan("chapters")
        chapters = plans if isinstance(plans, list) else plans.get("chapters", [])
        out = []
        for n in range(max(1, chapter.ChapterNumber - 3), chapter.ChapterNumber):
            for c in chapters:
                if c.get("ChapterNumber") == n:
                    summary = guide.get(c.get("Id", ""), "")
                    if summary:
                        out.append(f"第{n}章: {summary}")
        return "\n".join(out)

    # ---- 主流程 ----
    def write_chapter(self, chapter: ChapterData, blueprints: List[BlueprintData],
                      volume: dict, outline: dict, world: dict, characters: List[dict],
                      factions: List[dict], locations: List[dict], plot: dict,
                      materials: List[dict], genre: str, creative_spec: str = "",
                      word_count: int = 3500, verbose: bool = True) -> dict:
        snapshot, context_ids, prev_tail, summaries, milestones, recall_fragments = self.build_context(
            chapter, blueprints, volume, outline, world, characters, factions, locations, plot, materials)

        # 组装系统提示词（含 CHANGES 协议）
        from .prompt_builder import changes_requirement_block
        system = build_system_prompt(genre, self.library, creative_spec)
        system += "\n\n" + changes_requirement_block(context_ids, snapshot)

        # 组装任务提示词
        user = build_chapter_task_prompt(
            chapter_number=chapter.ChapterNumber,
            chapter_title=chapter.ChapterTitle,
            chapter_plan=chapter.to_dict(),
            blueprints=[b.to_dict() for b in blueprints],
            snapshot=snapshot,
            context_ids=context_ids,
            creative_spec=creative_spec,
            previous_tail=prev_tail,
            summaries=summaries,
            volume_design=self._fmt(volume),
            outline=self._fmt(outline),
            characters=self._fmt_list(characters, max_items=30),
            factions=self._fmt_list(factions, max_items=20),
            locations=self._fmt_list(locations, max_items=30),
            plot_rules=self._fmt(plot),
            word_count=word_count,
            recall_fragments=recall_fragments,
        )

        # AI 写作 + 门禁重写循环
        raw, changes = self._generate_with_retry(system, user, snapshot, context_ids,
                                                  chapter, word_count, prev_tail, verbose)
        content = self._clean_content(raw, chapter)

        # 落盘（原子写 + WAL）
        self.tracking.update(chapter.ChapterNumber, changes, snapshot)
        self.project.save_chapter(chapter.Id, content)
        # 可读文件名副本
        safe_title = chapter.ChapterTitle[:20].replace("/", "_").replace("\\", "_").replace(":", "_")
        self.project.save_chapter_text(f"ch{chapter.ChapterNumber:03d}_{safe_title}.md", content)
        # 摘要
        self._save_summary(chapter, changes)

        return {
            "chapter_id": chapter.Id,
            "chapter_number": chapter.ChapterNumber,
            "content": content,
            "changes": changes,
            "new_entities": self._last_new_entities,
        }

    def _generate_with_retry(self, system: str, user: str, snapshot: FactSnapshot,
                             context_ids: dict, chapter: ChapterData, word_count: int,
                             prev_tail: str = "", verbose: bool = True) -> tuple:
        design_names = {
            "角色": chapter.ReferencedCharacterNames,
            "视角角色": [chapter.ReferencedCharacterNames[0]] if chapter.ReferencedCharacterNames else [],
            "势力": chapter.ReferencedFactionNames,
            "地点": chapter.ReferencedLocationNames,
        }
        target_words = word_count
        if target_words < 100:
            target_words = 3000
        min_words = int(target_words * 0.6)
        max_words = int(target_words * 1.5)

        previous_failures = []
        original_content = ""    # 首次通过门禁的正文（CHANGES-only 保留用）
        changes_only = False
        word_count_issue = False
        repetition_issue = False
        last_raw = ""

        for attempt in range(self.max_rewrite_attempts):
            if verbose:
                print(f"    [AI 写作] 第 {attempt + 1}/{self.max_rewrite_attempts} 次尝试...")

            # 构建 prompt：首次用原文，后续用反馈
            prompt = user
            if attempt > 0 and previous_failures:
                fail_list = previous_failures[:5]  # 对标 MaxFailureReasonsPerRewrite=5
                fail_text = "\n".join(f"  - {f}" for f in fail_list)
                if changes_only:
                    prompt = user + (
                        f"\n\n（打回重写 #{attempt}）以下问题只需修正 CHANGES JSON，正文内容保留不变：\n"
                        f"{fail_text}\n请重新输出完整的正文+CHANGES。")
                elif word_count_issue:
                    prompt = user + (
                        f"\n\n（打回重写 #{attempt}）字数问题：需要 {target_words} 字。"
                        f"请重新生成正文，确保字数达标。")
                elif repetition_issue:
                    prompt = user + (
                        f"\n\n（打回重写 #{attempt}）检测到正文重复或与上章高度相似。"
                        f"请重新生成不同内容的正文。")
                else:
                    prompt = user + (
                        f"\n\n（打回重写 #{attempt}）门禁校验失败原因：\n{fail_text}\n"
                        "请修正后重新完整输出。")

            raw = self.ai.chat(system, prompt, category=f"chapter_{chapter.ChapterNumber}")
            last_raw = raw

            # 模型拒绝检测
            if self._detect_refusal(raw):
                previous_failures.append("模型拒绝生成（尝试切换题材参数重试）")
                continue

            # 前置 CHANGES 检测
            from .gate import GenerationGate
            if not self._has_changes(raw):
                changes_only = True
                original_content = raw
                previous_failures.append("缺少 CHANGES 区域")
                continue

            # 门禁校验
            result = self.gate.validate(raw, snapshot, design_names, context_ids, chapter.Id)
            if not result.Success:
                # 区分 failure 类型
                changes_issues = [f for f in result.Failures if f.Type in ("协议解析", "引用校验")]
                if changes_issues and len(changes_issues) == len(result.Failures):
                    changes_only = True
                    if original_content:
                        raw_merged = self._strip_changes(original_content) + "\n\n---CHANGES---\n" + self._extract_changes(raw)
                        result2 = self.gate.validate(raw_merged, snapshot, design_names, context_ids, chapter.Id)
                        if result2.Success:
                            result = result2
                            raw = raw_merged
                        else:
                            previous_failures = [e for f in result.Failures for e in f.Errors]
                            continue
                previous_failures = [e for f in result.Failures for e in f.Errors]
                if verbose:
                    for f in result.Failures:
                        print(f"    ⚠ 门禁打回 [{f.Type}]: {'; '.join(f.Errors[:2])}")
                continue

            # 门禁通过→正文重复检测（含上章尾部重叠）
            content, _ = split_content_and_changes(raw)
            if self._detect_repetition(content) or self._detect_repetition_with_tail(content, prev_tail):
                repetition_issue = True
                previous_failures.append("正文段落重复度过高或与上章尾部重叠")
                continue

            # 对标 Pre-Polish Word Count: 偏差>30%跳过润色
            wc = len(content.replace("\n", "").replace(" ", ""))
            pre_off = abs(wc - target_words) / max(1, target_words)
            if pre_off <= 0.30 and wc >= min_words:
                # 润色 + 重验
                from .polisher import ContentPolisher
                polisher = ContentPolisher(self.ai)
                polished_raw, polished_content, polish_ok = polisher.polish(raw, verbose)
                if polish_ok:
                    polished_result = self.gate.validate(polished_raw, snapshot, design_names, context_ids, chapter.Id)
                    if polished_result.Success:
                        raw = polished_raw
                        result = polished_result
                        content = polished_content
                        wc = len(polished_content.replace("\n", "").replace(" ", ""))
                        if verbose:
                            print(f"    [润色] 门禁通过，采用润色版")

            # 字数检测
            if wc < min_words:
                word_count_issue = True
                previous_failures.append(f"字数不足（{wc}/{target_words}）")
                if verbose:
                    print(f"    ⚠ 字数不足 {wc}/{target_words}")
                continue
            if wc > max_words * 2:
                word_count_issue = True
                previous_failures.append(f"字数严重超限（{wc}/{target_words}）")
                continue

            # 蓝图合规已在门禁 Post-gate 中检测

            self._last_new_entities = result.NewEntities
            return raw, result.ParsedChanges

        raise RuntimeError(f"第{chapter.ChapterNumber}章生成失败：{self.max_rewrite_attempts}次尝试均未通过")

    @staticmethod
    def _detect_refusal(text: str) -> bool:
        """对标 4.1.1 DetectModelRefusal: 32种模式"""
        patterns = [
            "I'm sorry, but I cannot", "I cannot provide", "I am unable to",
            "I apologize, but I", "As an AI", "I'm not able",
            "I'm not capable", "I cannot fulfill", "I can't assist",
            "I'm afraid I can't", "I can't generate", "I won't be able",
            "content policy", "safety guidelines", "I can't write",
            "我无法协助", "我无法满足", "不能提供", "无法生成",
            "抱歉，我无法", "对不起，我无法", "这个要求超出了",
            "很抱歉，我不能", "我无法完成", "我不能提供",
            "作为AI助手", "内容政策", "安全准则",
            "由于内容限制", "我无法创建", "我无法为您",
            "我无法继续",
        ]
        text_lower = text.lower()
        return any(p.lower() in text_lower for p in patterns)

    @staticmethod
    def _has_changes(text: str) -> bool:
        return "CHANGES---" in text or "chapter_changes>" in text

    @staticmethod
    def _detect_repetition(content: str) -> bool:
        """对标 DetectContentRepetition: bigram Jaccard"""
        lines = [l.strip() for l in content.split("\n") if l.strip()]
        if len(lines) < 4:
            return False
        paras = []
        current = []
        for l in lines:
            if len(l) < 10:
                current.append(l)
            else:
                if current:
                    paras.append("".join(current))
                    current = []
                paras.append(l)
        if len(paras) < 3:
            return False
        # 相邻段 bigram Jaccard
        for i in range(len(paras) - 1):
            if len(paras[i]) < 20 or len(paras[i + 1]) < 20:
                continue
            bg1 = set(paras[i][j:j + 2] for j in range(len(paras[i]) - 1))
            bg2 = set(paras[i + 1][j:j + 2] for j in range(len(paras[i + 1]) - 1))
            if not bg1 or not bg2:
                continue
            intersection = len(bg1 & bg2)
            union = len(bg1 | bg2)
            if union > 0 and intersection / union > 0.6:
                return True
        # 前/后半段相似度
        mid = len(content) // 2
        first, second = content[:mid], content[mid:]
        if len(first) > 100 and len(second) > 100:
            bg1 = set(first[j:j + 2] for j in range(len(first) - 1))
            bg2 = set(second[j:j + 2] for j in range(len(second) - 1))
            if bg1 and bg2:
                jac = len(bg1 & bg2) / max(1, len(bg1 | bg2))
                if jac > 0.5:
                    return True
        return False

    @staticmethod
    def _detect_repetition_with_tail(content: str, prev_tail: str = "") -> bool:
        """对标上章尾部重叠检测: 开头与上章尾部 bigram Jaccard > 0.4"""
        if not prev_tail or len(prev_tail) < 100 or len(content) < 100:
            return False
        tail = prev_tail[-300:] if len(prev_tail) > 300 else prev_tail
        head = content[:min(500, len(content))]
        bg_tail = set(tail[k:k + 2] for k in range(len(tail) - 1))
        bg_head = set(head[k:k + 2] for k in range(len(head) - 1))
        if not bg_tail or not bg_head:
            return False
        return len(bg_tail & bg_head) / max(1, len(bg_tail | bg_head)) > 0.4

    @staticmethod
    def _strip_changes(text: str) -> str:
        content, _ = split_content_and_changes(text)
        return content.strip()

    @staticmethod
    def _extract_changes(text: str) -> str:
        _, changes = split_content_and_changes(text)
        return changes.strip()

    @staticmethod
    def _last_chapter_tail(self) -> str:
        return ""  # overridden by instance

    def _clean_content(self, raw: str, chapter: ChapterData) -> str:
        content, _ = split_content_and_changes(raw)
        content = content.strip()
        # 规范标题
        lines = content.split("\n")
        if lines and not lines[0].startswith("#"):
            content = f"# 第{chapter.ChapterNumber}章 {chapter.ChapterTitle}\n\n" + content
        return content

    def _save_summary(self, chapter: ChapterData, changes: ChapterChanges):
        """从关键事件构建章节摘要"""
        parts = []
        for c in changes.CharacterStateChanges:
            if c.KeyEvent:
                parts.append(c.KeyEvent)
        for cf in changes.ConflictProgress:
            if cf.Event:
                parts.append(cf.Event)
        for p in changes.NewPlotPoints:
            if p.Context:
                parts.append(p.Context)
        guide = self.project.guide("chapter_summaries")
        summary = "；".join(parts[:3]) or "本章无重大事件。"
        guide.set(chapter.Id, summary)
        guide.flush()

    @staticmethod
    def _fmt(d: Optional[dict]) -> str:
        if not d:
            return ""
        return json.dumps(d, ensure_ascii=False)[:2000]

    @staticmethod
    def _fmt_list(items: List[dict], max_items: int) -> str:
        if not items:
            return ""
        return json.dumps(items[:max_items], ensure_ascii=False)[:3000]
