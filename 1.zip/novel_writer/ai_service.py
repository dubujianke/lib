# -*- coding: utf-8 -*-
"""AI 服务：基于 ai_client 的结构化 JSON 生成 + 容错解析"""

import json
import re
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ai_client import AIClient


def extract_json(text: str):
    """从文本中提取 JSON：优先找代码块，再找平衡花括号"""
    # 1. ```json ... ```
    m = re.search(r"```(?:json)?\s*([\s\S]*?)```", text)
    if m:
        try:
            return json.loads(m.group(1).strip())
        except json.JSONDecodeError:
            pass
    # 2. 平衡花括号
    start = text.find("{")
    if start != -1:
        depth = 0
        in_str = False
        escape = False
        for i in range(start, len(text)):
            ch = text[i]
            if in_str:
                if escape:
                    escape = False
                elif ch == "\\":
                    escape = True
                elif ch == '"':
                    in_str = False
                continue
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    candidate = text[start:i + 1]
                    try:
                        return json.loads(candidate)
                    except json.JSONDecodeError:
                        return _repair_json(candidate)
    # 3. 整个文本试试
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return _repair_json(text)


def _repair_json(text: str):
    """容错修复 JSON"""
    from .models import CHINESE_FIELD_MAP
    if not isinstance(text, str):
        return None
    s = text.strip()
    # 去注释
    s = re.sub(r"//[^\n]*", "", s)
    # 中文键映射
    for cn, en in CHINESE_FIELD_MAP.items():
        s = s.replace(f'"{cn}"', f'"{en}"')
    # 全角标点转半角
    s = s.replace("，", ",").replace("：", ":").replace("“", '"').replace("”", '"').replace("‘", "'").replace("’", "'")
    s = re.sub(r",\s*([}\]])", r"\1", s)   # 去尾逗号
    s = s.replace("'", '"')                 # 单引号→双引号
    # 补花括号
    opens = s.count("{") - s.count("}")
    if opens > 0:
        s += "}" * opens
    try:
        return json.loads(s)
    except json.JSONDecodeError:
        return None


class AIService:
    """封装 LLM 调用，提供 chat_json 能力"""

    def __init__(self, client: AIClient = None, max_retries: int = 3):
        self.client = client or AIClient()
        self.max_retries = max_retries

    def chat(self, system: str, user: str, category: str = "chat") -> str:
        return self.client.chat(system, user, category=category)

    def chat_json(self, system: str, user: str, category: str = "gen", retries: int = None) -> dict:
        """调用 LLM 并要求返回 JSON，自动重试解析"""
        retries = retries if retries is not None else self.max_retries
        last_err = None
        for attempt in range(retries):
            prompt = user if attempt == 0 else (
                user + f"\n\n（第 {attempt} 次修正）上次输出不是合法 JSON 或缺少必需字段：{last_err}\n"
                       "请只输出合法的 JSON 对象，不要包含任何其他文本、解释或 Markdown 代码块标记。")
            try:
                text = self.client.chat(system, prompt, category=category)
            except Exception as e:
                last_err = str(e)
                continue
            data = extract_json(text)
            if data is not None:
                return data
            last_err = "无法从输出中解析 JSON"
        raise RuntimeError(f"AI 多次输出非法 JSON: {last_err}")

    def close(self):
        self.client.close()
