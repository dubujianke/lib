# -*- coding: utf-8 -*-
"""分层提示词构建：事实账本格式化 + CHANGES 协议块 + 章节任务上下文"""

from typing import Optional

from .models import FactSnapshot, ChapterChanges, TOP_LEVEL_FIELDS, CHANGES_SEPARATOR


def _section(title: str, content: str) -> str:
    return f"<section name=\"{title}\">\n{content}\n</section>"


def _fmt_entry_list(entries, field_map, max_items: int = 999) -> str:
    """将快照实体列表格式化为文本账本"""
    lines = []
    for e in entries[:max_items]:
        parts = []
        for src_key, label in field_map:
            val = getattr(e, src_key, "")
            if isinstance(val, list):
                if val:
                    parts.append(f"{label}: {'、'.join(map(str, val))}")
            elif isinstance(val, dict):
                if val:
                    parts.append(f"{label}: {json_dumps(val)}")
            elif val:
                parts.append(f"{label}: {val}")
        lines.append("- " + "；".join(parts))
    return "\n".join(lines) if lines else "（无）"


def json_dumps(obj) -> str:
    import json
    return json.dumps(obj, ensure_ascii=False)


def format_fact_snapshot(snapshot: FactSnapshot) -> str:
    """格式化 15 维事实账本（写前读取的核心）"""
    s = snapshot
    out = []

    out.append(_section("world_constraints", "以下世界观硬约束不可违反（immutable）:\n" + _fmt_entry_list(
        s.WorldRuleConstraints, [("Content", "约束"), ("RuleId", "ID")])))

    out.append(_section("character_states", "以下角色当前状态为事实（不可推翻）:\n" + _fmt_entry_list(
        s.CharacterStates,
        [("Name", "角色"), ("Level", "境界"), ("Phase", "阶段"), ("Abilities", "能力"),
         ("LostAbilities", "已失去"), ("MentalState", "心理状态"), ("KeyEvent", "关键事件"),
         ("Relationships", "关系"), ("Importance", "重要度")])))

    out.append(_section("conflict_progress", "冲突当前状态（只能推进，不得回退）:\n" + _fmt_entry_list(
        s.ConflictProgress,
        [("Name", "冲突"), ("Type", "类型"), ("Tier", "层级"), ("Status", "状态"),
         ("LastEvent", "最近事件"), ("InvolvedCharacters", "涉及角色")])))

    out.append(_section("foreshadowing", "伏笔状态（已埋未收/已收）:\n" + _fmt_entry_list(
        s.ForeshadowingStatus,
        [("Name", "伏笔"), ("Tier", "层级"), ("IsSetup", "已埋设"), ("IsResolved", "已回收"),
         ("IsOverdue", "已逾期"), ("ExpectedSetupChapter", "预计埋设章"),
         ("ExpectedPayoffChapter", "预计回收章")])))

    out.append(_section("plot_points", "已发生剧情节点（用于呼应）:\n" + _fmt_entry_list(
        s.PlotPoints,
        [("Keywords", "关键词"), ("Context", "事件"), ("Storyline", "故事线"),
         ("InvolvedCharacters", "涉及角色"), ("Chapter", "章节"), ("Importance", "重要度")])))

    out.append(_section("character_descriptions", "角色外貌设定（描写不得矛盾）:\n" + _fmt_entry_list(
        s.CharacterDescriptions,
        [("Name", "角色"), ("HairColor", "发色"), ("EyeColor", "瞳色"),
         ("PersonalityTags", "性格标签"), ("Appearance", "外貌")])))

    out.append(_section("location_descriptions", "地点特征（描写不得矛盾）:\n" + _fmt_entry_list(
        s.LocationDescriptions,
        [("Name", "地点"), ("Features", "特征"), ("Description", "描述")])))

    out.append(_section("location_states", "地点当前状态:\n" + _fmt_entry_list(
        s.LocationStates, [("Name", "地点"), ("CurrentStatus", "当前状态"), ("LastEvent", "最近事件")])))

    out.append(_section("faction_states", "势力当前状态:\n" + _fmt_entry_list(
        s.FactionStates, [("Name", "势力"), ("CurrentStatus", "当前状态"), ("LastEvent", "最近事件")])))

    out.append(_section("timeline", "时间线:\n" + _fmt_entry_list(
        s.Timeline, [("TimePeriod", "时段"), ("ElapsedTime", "经过时间"),
                     ("KeyTimeEvent", "关键时间事件"), ("Chapter", "章节")])))

    out.append(_section("character_locations", "角色当前位置（移动必须连续）:\n" + _fmt_entry_list(
        s.CharacterLocations, [("Name", "角色"), ("CurrentLocation", "当前位置"),
                               ("LastUpdatedChapter", "最后更新章")])))

    out.append(_section("item_states", "物品状态:\n" + _fmt_entry_list(
        s.ItemStates, [("Name", "物品"), ("CurrentHolder", "持有者"), ("CurrentStatus", "状态"),
                       ("Description", "描述")])))

    out.append(_section("secret_states", "秘密状态:\n" + _fmt_entry_list(
        s.SecretStates, [("Name", "秘密"), ("KnowerIds", "知情人"), ("CurrentStatus", "状态")])))

    out.append(_section("pledge_states", "誓约约束状态:\n" + _fmt_entry_list(
        s.PledgeStates, [("Name", "誓约"), ("Type", "类型"), ("CurrentStatus", "状态"),
                         ("PartyIds", "当事人"), ("Condition", "条件"), ("Consequence", "后果")])))

    out.append(_section("deadline_states", "截止约束状态:\n" + _fmt_entry_list(
        s.DeadlineStates, [("Name", "截止"), ("Type", "类型"), ("CurrentStatus", "状态"),
                           ("Deadline", "截止时间"), ("TriggerCondition", "触发条件")])))

    return "\n".join(out)


def changes_requirement_block(context_ids: dict, snapshot: FactSnapshot) -> str:
    """对标 GetChangesRequirementBlock: 含字段速查 + final_checklist"""
    CHANGES_COUNT = len(TOP_LEVEL_FIELDS)
    has_chars = bool(snapshot.CharacterStates)
    has_conflicts = bool(snapshot.ConflictProgress)
    has_fs = bool(snapshot.ForeshadowingStatus)
    has_locs = bool(snapshot.LocationStates)
    has_factions = bool(snapshot.FactionStates)
    has_items = bool(snapshot.ItemStates)
    has_secrets = bool(snapshot.SecretStates)
    has_pledges = bool(snapshot.PledgeStates)
    has_deadlines = bool(snapshot.DeadlineStates)

    parts = []
    parts.append("<output_requirements mandatory=\"true\">")
    parts.append("")
    parts.append("1. 请根据以上信息生成完整章节正文")
    parts.append("2. 直接输出小说正文内容，以章节标题（# 第X章：标题）开头")
    parts.append("3. 禁止输出任何自我介绍、AI身份说明、任务确认等非正文内容")
    parts.append("4. 禁止输出「好的」「我来生成」「以下是内容」等过渡语")
    parts.append("5. 只输出纯粹的小说章节正文")
    parts.append("")
    parts.append("6. **正文末尾必须输出变更摘要**，格式如下：")
    parts.append("")
    parts.append(f'<changes_protocol open_tag="<chapter_changes>" close_tag="</chapter_changes>" format="json" fields="{CHANGES_COUNT}" mandatory="true">')
    parts.append("**⚠ ID字段规则**：所有ID字段均可填写**实体名称**或事实账本中的ShortId，系统自动解析。不确定ShortId时写名称即可。")
    parts.append("")
    parts.append("7. 正文写完后，必须用成对的 `<chapter_changes>` 与 `</chapter_changes>` 标签包裹变更摘要（仅半角字符、不得简写、不得加额外属性、不得用其他名字替换）。")
    parts.append(f"8. 标签内部只能放合法 JSON 对象本身，必须显式包含{CHANGES_COUNT}个顶级字段（即使为空数组`[]`或空对象`{{}}`）。不要使用 Markdown 代码块，不要在 JSON 前后写解释文字。")
    parts.append(f"9. 最终输出结构固定为：`<chapter_changes>\\n{{完整JSON对象}}\\n</chapter_changes>`。")
    parts.append("")
    parts.append("**重要**：上面出现的 `<changes_protocol>`、`<final_checklist>`、`<changes_template>`、`<changes_id_ref>` 等 XML 标签是**系统提示词结构**，不应出现在你的输出里。你输出的唯一一对 XML 标签是 `<chapter_changes>` 与 `</chapter_changes>`。")
    parts.append("")
    parts.append(f"**CHANGES字段速查（共{CHANGES_COUNT}个顶级字段，字段名不可改名；无变化的字段保留空数组`[]`或空对象`{{}}`，不可省略；若末尾提供了预填模板，以模板结构为准填写）**：")

    if has_chars:
        parts.append("- `CharacterStateChanges[]`: 角色状态变化 — CharacterId, NewLevel, NewAbilities(增量), LostAbilities(需KeyEvent说明原因), RelationshipChanges{ <角色名或ShortId>: {Relation, TrustDelta(±30以内), EmotionPhase} }, NewMentalState, KeyEvent, Importance(normal/important/critical), CausedBy")
    else:
        parts.append("- `CharacterStateChanges[]`: 本章无追踪角色，保留空数组`[]`")

    if has_conflicts:
        parts.append("- `ConflictProgress[]`: 冲突进度 — ConflictId, NewStatus, Event, Importance(normal/important/critical), CausedBy")
    else:
        parts.append("- `ConflictProgress[]`: 本章无追踪冲突，保留空数组`[]`")

    if has_fs:
        parts.append("- `ForeshadowingActions[]`: 伏笔动作 — ForeshadowId, Action(仅setup/payoff)")
    else:
        parts.append("- `ForeshadowingActions[]`: 本章无追踪伏笔，保留空数组`[]`")

    parts.append("- `NewPlotPoints[]`: 新增情节 — Keywords[], Context, InvolvedCharacters[], Importance(normal/important/critical), Storyline(main/sub/character_arc), CausedBy")

    if has_locs:
        parts.append("- `LocationStateChanges[]`: 地点变化 — LocationId, NewStatus, Event, Importance(normal/important/critical)")
    else:
        parts.append("- `LocationStateChanges[]`: 本章无追踪地点，保留空数组`[]`")

    if has_factions:
        parts.append("- `FactionStateChanges[]`: 势力变化 — FactionId, NewStatus, Event, Importance(normal/important/critical), CausedBy")
    else:
        parts.append("- `FactionStateChanges[]`: 本章无追踪势力，保留空数组`[]`")

    parts.append("- `TimeProgression{}`: 时间推进 — TimePeriod, ElapsedTime, KeyTimeEvent, Importance(normal/important/critical)")

    if has_chars:
        parts.append("- `CharacterMovements[]`: 角色移动 — CharacterId, FromLocation(可留空由系统补值), ToLocation, Importance(normal/important/critical)")
    else:
        parts.append("- `CharacterMovements[]`: 本章无追踪角色，保留空数组`[]`")

    if has_items:
        parts.append("- `ItemTransfers[]`: 物品流转 — ItemId, ItemName(显示名称), FromHolder(可留空由系统补值), ToHolder(毁坏则留空), NewStatus(active/lost/destroyed/sealed), Event, Importance, CausedBy")
    else:
        parts.append("- `ItemTransfers[]`: 本章若有新物品出现/流转，新增条目填 ItemName 即可（ID自动生成）；子字段：ItemName, FromHolder, ToHolder, NewStatus(active/lost/destroyed/sealed), Event, Importance")

    if has_secrets:
        parts.append("- `SecretRevealChanges[]`: 秘密知情 — SecretId, SecretName(首次命名时必填), NewKnowerIds[], Method(told/overheard/deduced/discovered/other), KeyEvent, Importance, CausedBy")
    else:
        parts.append("- `SecretRevealChanges[]`: 本章若有新秘密揭示，新增条目填 SecretName 即可（ID自动生成）；子字段：SecretName, NewKnowerIds[], Method(told/overheard/deduced/discovered), KeyEvent, Importance")

    if has_pledges:
        parts.append("- `PledgeConstraintChanges[]`: 承诺/契约 — PledgeId, PledgeName(创建时必填), Action(create/fulfill/break/update), Type(pledge/contract/oath), PartyIds[], Condition, Consequence, KeyEvent, Importance")
    else:
        parts.append("- `PledgeConstraintChanges[]`: 本章若有新承诺/契约，新增条目填 PledgeName + Action(create) 即可；子字段：PledgeName, Action, Type(pledge/contract/oath), PartyIds[], Condition, Consequence, Importance")

    if has_deadlines:
        parts.append("- `DeadlineConstraintChanges[]`: 倒计时/时限 — DeadlineId, DeadlineName(创建时必填), Action(create/trigger/expire/cancel/update), Type(countdown/curse/threat/event), Deadline, TriggerCondition, Consequence, PartyIds[], KeyEvent, Importance")
    else:
        parts.append("- `DeadlineConstraintChanges[]`: 本章若有新倒计时/时限，新增条目填 DeadlineName + Action(create) 即可；子字段：DeadlineName, Action, Type(countdown/curse/threat/event), Deadline, Consequence, Importance")

    parts.append("")
    parts.append("**Importance使用规范**：normal(默认，可裁剪) / important(较重要，可压缩) / critical(永久保留，仅用于不可逆事件如角色死亡、血誓、阵营叛变等，每章最多1-2个)")
    parts.append("</changes_protocol>")
    parts.append("")
    parts.append("<final_checklist mandatory=\"true\">")
    parts.append("1. 是否使用了精确的 `<chapter_changes>` 开标签与 `</chapter_changes>` 闭标签（成对、仅半角字符、名字不得修改、不得加属性）？")
    parts.append(f"2. 标签内 JSON 是否包含全部{CHANGES_COUNT}个顶级字段（即使为空数组`[]`或空对象`{{}}`）？")
    parts.append("3. 所有ID字段是否均使用事实账本中的实体名称或ShortId？禁止自行构造不存在的ShortId；若末尾提供了预填模板，请优先使用模板中已列出的实体。")
    parts.append("4. 是否避免把 `<changes_protocol>` `<changes_template>` `<changes_id_ref>` 等系统指令标签误抄到最终输出中？")
    parts.append("</final_checklist>")
    parts.append("</output_requirements>")
    return "\n".join(parts)


def build_prefilled_changes_json(context_ids: dict, snapshot: FactSnapshot) -> str:
    """预填 CHANGES JSON 模板（AI 只需修改）"""
    import json
    tpl = {f: [] for f in TOP_LEVEL_FIELDS}
    return json.dumps(tpl, ensure_ascii=False, indent=2)


def build_chapter_task_prompt(
    chapter_number: int,
    chapter_title: str,
    chapter_plan: dict,
    blueprints: list,
    snapshot: FactSnapshot,
    context_ids: dict,
    creative_spec: str = "",
    previous_tail: str = "",
    summaries: str = "",
    milestones: str = "",
    recall_fragments: str = "",
    volume_design: str = "",
    outline: str = "",
    world_rules: str = "",
    characters: str = "",
    factions: str = "",
    locations: str = "",
    plot_rules: str = "",
    word_count: int = 3500,
) -> str:
    """构建章节生成任务提示词（user prompt）"""
    parts = []

    if creative_spec:
        parts.append(_section("creative_spec", creative_spec))

    parts.append(_section(
        "chapter_task",
        f"章节号：第 {chapter_number} 章\n标题：{chapter_title}\n\n{chapter_plan.get('ChapterTheme', '')}\n"
        f"本章目标：{chapter_plan.get('MainGoal', '')}\n阻力来源：{chapter_plan.get('ResistanceSource', '')}\n"
        f"关键转折：{chapter_plan.get('KeyTurn', '')}\n章末钩子：{chapter_plan.get('Hook', '')}"))

    if blueprints:
        bp_lines = []
        for i, bp in enumerate(blueprints, 1):
            bp_lines.append(
                f"场景{i}【{bp.get('SceneTitle', '')}】视点:{bp.get('PovCharacter', '')}\n"
                f"  开场: {bp.get('Opening', '')}\n  发展: {bp.get('Development', '')}\n"
                f"  转折: {bp.get('Turning', '')}\n  结尾: {bp.get('Ending', '')}\n"
                f"  出场: {'、'.join(bp.get('Cast', []))}\n  地点: {'、'.join(bp.get('Locations', []))}")
        parts.append(_section("blueprints", "本章场景蓝图（起承转合，必须遵循）:\n" + "\n".join(bp_lines)))

    if outline:
        parts.append(_section("outline", outline))
    if volume_design:
        parts.append(_section("volume_design", volume_design))
    if world_rules:
        parts.append(_section("worldview_rules", world_rules))
    if characters:
        parts.append(_section("characters", characters))
    if factions:
        parts.append(_section("factions", factions))
    if locations:
        parts.append(_section("locations", locations))
    if plot_rules:
        parts.append(_section("plot_rules", plot_rules))

    if milestones:
        parts.append(_section("historical_milestones", milestones))
    if summaries:
        parts.append(_section("chapter_summaries", summaries))

    parts.append(_section("fact_ledger", format_fact_snapshot(snapshot)))

    if previous_tail:
        parts.append(_section("chapter_tail", "上一章结尾原文（衔接用，不得重复）:\n" + previous_tail[-500:]))

    parts.append(_section(
        "entity_checklist",
        "本章必出场实体（mandatory）：\n" +
        "\n".join(f"  {k}: {'、'.join(v) if v else '（无）'}" for k, v in context_ids.items() if k != "previous_chapter")))

    parts.append(_section("word_count_anchor", f"【字数硬约束】目标 {word_count} 字（仅统计正文，不含标题与 <chapter_changes> 标签内的内容）。"))
    parts.append("")

    # 对标 AppendTailEntityChecklist
    chars_list = chapter_plan.get("ReferencedCharacterNames", [])
    fac_list = chapter_plan.get("ReferencedFactionNames", [])
    loc_list = chapter_plan.get("ReferencedLocationNames", [])
    if chars_list or fac_list or loc_list:
        checklist = ["<entity_checklist mandatory=\"true\" priority=\"critical\">"]
        checklist.append("**写作前最终确认**：以下实体必须在正文中出现（有对话或行动），缺任何一个将不通过校验：")
        if chars_list:
            checklist.append(f"  角色：{' / '.join(chars_list)}")
        if fac_list:
            checklist.append(f"  势力：{' / '.join(fac_list)}")
        if loc_list:
            checklist.append(f"  地点：{' / '.join(loc_list)}")
        checklist.append("</entity_checklist>")
        parts.append("\n".join(checklist))

    # 对标 AppendFirstDescriptionSnippets / LongDistanceRecall
    if recall_fragments:
        parts.append(f"<context_block source=\"long_distance_recall\">\n{recall_fragments}\n</context_block>")

    # 对标 AppendPrefilledChangesTemplate
    parts.append(_section(
        "changes_template",
        "请按要求输出 CHANGES JSON。以下是预填模板，以模板结构为准，只保留/修改有变化的项：\n" +
        build_prefilled_changes_json(context_ids, snapshot)))

    # 对标 AppendChangesIdQuickRef
    id_ref = _build_changes_id_ref(snapshot)
    if id_ref:
        parts.append(id_ref)

    return "\n\n".join(parts)


def _build_changes_id_ref(snapshot: FactSnapshot) -> str:
    """对标 AppendChangesIdQuickRef"""
    lines = ["<changes_id_ref mandatory=\"true\">"]
    lines.append("CHANGES字段ID参考表（可填写名称或ShortId，系统自动解析；禁止自行构造不存在的实体）：")
    lines.append("⚠ 角色范围硬限制：角色状态变化 / 角色移动 / 关系变化 只允许引用下方列出的角色（填名称或ShortId均可）；未列出的角色禁止写入角色相关字段。")

    if snapshot.CharacterStates:
        chars = [f"{c.Name}={c.CharacterId}" for c in snapshot.CharacterStates if c.Name and c.CharacterId]
        lines.append(f"  角色可用ID：{' | '.join(chars)}" if chars else "  角色可用ID：（无）")
    else:
        lines.append("  ⚠ 角色：账本无追踪记录")

    if snapshot.ConflictProgress:
        confs = [f"{c.Name}={c.ConflictId}" for c in snapshot.ConflictProgress if c.Name and c.ConflictId]
        lines.append(f"  冲突可用ID：{' | '.join(confs)}" if confs else "  冲突可用ID：（无）")

    if snapshot.ForeshadowingStatus:
        fs = [f"{f.Name}={f.ForeshadowId}" for f in snapshot.ForeshadowingStatus if f.Name and f.ForeshadowId and not f.IsResolved]
        if fs:
            lines.append(f"  伏笔可用ID（已埋未收）：{' | '.join(fs)}")

    if snapshot.LocationStates:
        locs = [f"{l.Name}={l.LocationId}" for l in snapshot.LocationStates if l.Name and l.LocationId]
        if locs:
            lines.append(f"  地点可用ID：{' | '.join(locs)}")

    if snapshot.FactionStates:
        factions = [f"{f.Name}={f.FactionId}" for f in snapshot.FactionStates if f.Name and f.FactionId]
        if factions:
            lines.append(f"  势力可用ID：{' | '.join(factions)}")

    if snapshot.ItemStates:
        items = [f"{i.Name}={i.ItemId}" for i in snapshot.ItemStates if i.Name and i.ItemId]
        if items:
            lines.append(f"  物品可用ID：{' | '.join(items)}")

    lines.append("</changes_id_ref>")
    return "\n".join(lines)


def split_content_and_changes(raw: str):
    """从 AI 原始输出中切分正文与 CHANGES 段"""
    import re
    changes = ""
    content = raw

    # 1. XML 块
    m = re.search(r"<chapter_changes>(.*?)</chapter_changes>", raw, re.S)
    if m:
        content = raw[:m.start()] + raw[m.end():]
        changes = m.group(1)
        return content.strip(), changes.strip()

    # 2. ---CHANGES--- 分隔符
    marker = CHANGES_SEPARATOR
    idx = raw.find(marker)
    if idx != -1:
        content = raw[:idx]
        changes = raw[idx + len(marker):]
        return content.strip(), changes.strip()

    # 3. 尾部裸 JSON
    trimmed = raw.rstrip()
    first_brace = trimmed.rfind("{")
    if first_brace != -1:
        candidate = trimmed[first_brace:]
        if _balanced_json(candidate):
            content = trimmed[:first_brace]
            changes = candidate
            return content.strip(), changes.strip()

    return content.strip(), changes.strip()


def _balanced_json(s: str) -> bool:
    stack = []
    in_str = False
    escape = False
    for ch in s:
        if in_str:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch in "{[(":
            stack.append(ch)
        elif ch in "}])":
            if not stack:
                return False
            if (ch == "}" and stack[-1] != "{") or (ch == "]" and stack[-1] != "[") or (ch == ")" and stack[-1] != "("):
                return False
            stack.pop()
    return not stack and not in_str
