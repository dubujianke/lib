# -*- coding: utf-8 -*-
"""15 维事实快照抽取：写前读取，从设计库 + 追踪 Guide 构建本章账本"""

import json
from typing import Dict, List, Optional

from .models import (
    FactSnapshot, CharacterStateEntry, ConflictProgressEntry, ForeshadowingEntry,
    PlotPointEntry, LocationStateEntry, FactionStateEntry, TimeEntry,
    CharacterLocationEntry, ItemStateEntry, SecretEntry, PledgeEntry,
    DeadlineEntry, WorldRuleConstraint, CharacterDescription, LocationDescription,
)
from .storage import Project


class SnapshotExtractor:
    """从 Project 持久化数据构建某章的事实快照"""

    def __init__(self, project: Project):
        self.project = project
        self._design_cache = {}
        self._guides_cache = {}

    # ---- 设计库 ----
    def _design(self, entity: str) -> dict:
        if entity not in self._design_cache:
            self._design_cache[entity] = self.project.load_design(entity)
        return self._design_cache[entity]

    def _guide(self, name: str) -> dict:
        if name not in self._guides_cache:
            self._guides_cache[name] = self.project.guide(name).data()
        return self._guides_cache[name]

    def _tracking(self, name: str) -> dict:
        if name not in self._guides_cache:
            self._guides_cache[name] = self.project.tracking(name).data()
        return self._guides_cache[name]

    # ---- 主入口 ----
    def extract(self, chapter_id: str, chapter_number: int) -> FactSnapshot:
        snapshot = FactSnapshot()
        snapshot.CharacterStates = self._extract_characters(chapter_number)
        snapshot.ConflictProgress = self._extract_conflicts()
        snapshot.ForeshadowingStatus = self._extract_foreshadowings()
        snapshot.PlotPoints = self._extract_plot_points()
        snapshot.CharacterDescriptions = self._extract_character_descriptions()
        snapshot.LocationDescriptions = self._extract_location_descriptions()
        snapshot.WorldRuleConstraints = self._extract_world_constraints()
        snapshot.LocationStates = self._extract_location_states()
        snapshot.FactionStates = self._extract_faction_states()
        snapshot.Timeline = self._extract_timeline()
        snapshot.CharacterLocations = self._extract_character_locations()
        snapshot.ItemStates = self._extract_items()
        snapshot.SecretStates = self._extract_secrets()
        snapshot.PledgeStates = self._extract_pledges()
        snapshot.DeadlineStates = self._extract_deadlines()
        return snapshot

    # ---- 各维度 ----
    def _extract_characters(self, chapter_number: int) -> List[CharacterStateEntry]:
        # 优先从追踪 Guide 读，否则从设计库初始化
        guide = self._tracking("character_state")
        entries = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict):
                    continue
                entries.append(CharacterStateEntry(
                    CharacterId=k, Name=v.get("Name", k),
                    Level=v.get("Level", ""), Phase=v.get("Phase", ""),
                    Abilities=v.get("Abilities", []),
                    LostAbilities=v.get("LostAbilities", []),
                    MentalState=v.get("MentalState", ""),
                    KeyEvent=v.get("KeyEvent", ""),
                    LastChapter=int(v.get("LastChapter", 0) or 0),
                    Importance=int(v.get("Importance", 0) or 0),
                    Relationships=v.get("Relationships", {}),
                ))
        if not entries:
            design = self._design("characters")
            for c in design.get("characters", []):
                entries.append(CharacterStateEntry(
                    CharacterId=c.get("Id", ""), Name=c.get("Name", ""),
                    Level="", Phase="", Abilities=c.get("SpecialAbilities", []),
                    MentalState="", Importance=3 if c.get("IsPov") else 2,
                    Relationships={}))
        return entries

    def _extract_conflicts(self) -> List[ConflictProgressEntry]:
        guide = self._tracking("conflict_progress")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict):
                    continue
                out.append(ConflictProgressEntry(
                    ConflictId=k, Name=v.get("Name", k), Type=v.get("Type", ""),
                    Tier=v.get("Tier", ""), Status=v.get("Status", ""),
                    LastEvent=v.get("LastEvent", ""),
                    LastChapter=int(v.get("LastChapter", 0) or 0),
                    InvolvedCharacters=v.get("InvolvedCharacters", [])))
        return out

    def _extract_foreshadowings(self) -> List[ForeshadowingEntry]:
        guide = self._tracking("foreshadowing")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict):
                    continue
                out.append(ForeshadowingEntry(
                    ForeshadowId=k, Name=v.get("Name", k), Tier=v.get("Tier", ""),
                    IsSetup=bool(v.get("IsSetup", False)),
                    IsResolved=bool(v.get("IsResolved", False)),
                    IsOverdue=bool(v.get("IsOverdue", False)),
                    ExpectedSetupChapter=int(v.get("ExpectedSetupChapter", 0) or 0),
                    ExpectedPayoffChapter=int(v.get("ExpectedPayoffChapter", 0) or 0),
                    ActualSetupChapter=int(v.get("ActualSetupChapter", 0) or 0),
                    ActualPayoffChapter=int(v.get("ActualPayoffChapter", 0) or 0)))
        return out

    def _extract_plot_points(self) -> List[PlotPointEntry]:
        guide = self._tracking("plot_points")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict):
                    continue
                out.append(PlotPointEntry(
                    PlotPointId=k, Keywords=v.get("Keywords", []),
                    Context=v.get("Context", ""),
                    InvolvedCharacters=v.get("InvolvedCharacters", []),
                    Storyline=v.get("Storyline", ""),
                    Chapter=int(v.get("Chapter", 0) or 0),
                    Importance=int(v.get("Importance", 0) or 0)))
        return out

    def _extract_character_descriptions(self) -> List[CharacterDescription]:
        design = self._design("characters")
        out = []
        for c in design.get("characters", []):
            hair = eye = ""
            app = c.get("Appearance", "")
            import re
            m = re.search(r"([黑棕金蓝紫红银白灰])\s*发", app)
            if m:
                hair = m.group(1) + "发"
            m = re.search(r"([黑棕金蓝紫红银白灰])\s*瞳", app)
            if m:
                eye = m.group(1) + "瞳"
            tags = [t.strip() for t in re.split(r"[,，、;；]", c.get("Personality", "")) if t.strip()]
            out.append(CharacterDescription(
                CharacterId=c.get("Id", ""), Name=c.get("Name", ""),
                HairColor=hair, EyeColor=eye, PersonalityTags=tags,
                Appearance=app))
        return out

    def _extract_location_descriptions(self) -> List[LocationDescription]:
        design = self._design("locations")
        out = []
        for loc in design.get("locations", []):
            features = loc.get("Landmarks", []) + loc.get("Dangers", [])
            out.append(LocationDescription(
                LocationId=loc.get("Id", ""), Name=loc.get("Name", ""),
                Features=[str(x) for x in features],
                Description=loc.get("Description", "")))
        return out

    def _extract_world_constraints(self) -> List[WorldRuleConstraint]:
        design = self._design("world")
        out = []
        for rule in design.get("HardRules", []) or []:
            if rule:
                out.append(WorldRuleConstraint(
                    RuleId=short_id_ref("R"), Content=str(rule), IsHardConstraint=True))
        return out

    def _extract_location_states(self) -> List[LocationStateEntry]:
        guide = self._tracking("location_state")
        design = self._design("locations")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict):
                    continue
                out.append(LocationStateEntry(
                    LocationId=k, Name=v.get("Name", k),
                    CurrentStatus=v.get("CurrentStatus", "正常"),
                    Description=v.get("Description", ""),
                    LastEvent=v.get("LastEvent", ""),
                    LastChapter=int(v.get("LastChapter", 0) or 0)))
        if not out:
            for loc in design.get("locations", []):
                out.append(LocationStateEntry(
                    LocationId=loc.get("Id", ""), Name=loc.get("Name", ""),
                    CurrentStatus="正常", Description=loc.get("Description", "")))
        return out

    def _extract_faction_states(self) -> List[FactionStateEntry]:
        guide = self._tracking("faction_state")
        design = self._design("factions")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict):
                    continue
                out.append(FactionStateEntry(
                    FactionId=k, Name=v.get("Name", k),
                    CurrentStatus=v.get("CurrentStatus", "正常"),
                    LastEvent=v.get("LastEvent", ""),
                    LastChapter=int(v.get("LastChapter", 0) or 0)))
        if not out:
            for fac in design.get("factions", []):
                out.append(FactionStateEntry(
                    FactionId=fac.get("Id", ""), Name=fac.get("Name", ""),
                    CurrentStatus="正常"))
        return out

    def _extract_timeline(self) -> List[TimeEntry]:
        guide = self._tracking("timeline")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict):
                    continue
                out.append(TimeEntry(
                    TimePeriod=v.get("TimePeriod", ""), ElapsedTime=v.get("ElapsedTime", ""),
                    KeyTimeEvent=v.get("KeyTimeEvent", ""),
                    Chapter=int(v.get("Chapter", 0) or 0)))
        return out

    def _extract_character_locations(self) -> List[CharacterLocationEntry]:
        guide = self._tracking("character_location")
        design = self._design("characters")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict):
                    continue
                out.append(CharacterLocationEntry(
                    CharacterId=k, Name=v.get("Name", k),
                    CurrentLocation=v.get("CurrentLocation", ""),
                    LastUpdatedChapter=int(v.get("LastUpdatedChapter", 0) or 0)))
        if not out:
            # 初始化主角为出生地
            locations = self._design("locations").get("locations", [])
            home = locations[0].get("Name", "") if locations else ""
            for c in design.get("characters", []):
                out.append(CharacterLocationEntry(
                    CharacterId=c.get("Id", ""), Name=c.get("Name", ""),
                    CurrentLocation=home))
        return out

    def _extract_items(self) -> List[ItemStateEntry]:
        guide = self._tracking("item_state")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict):
                    continue
                out.append(ItemStateEntry(
                    ItemId=k, Name=v.get("Name", k),
                    CurrentHolder=v.get("CurrentHolder", ""),
                    CurrentStatus=v.get("CurrentStatus", "active"),
                    Description=v.get("Description", ""),
                    LastEvent=v.get("LastEvent", ""),
                    LastChapter=int(v.get("LastChapter", 0) or 0)))
        return out

    def _extract_secrets(self) -> List[SecretEntry]:
        guide = self._tracking("secret")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict):
                    continue
                out.append(SecretEntry(
                    SecretId=k, Name=v.get("Name", k),
                    KnowerIds=v.get("KnowerIds", []),
                    CurrentStatus=v.get("CurrentStatus", "hidden"),
                    LastChapter=int(v.get("LastChapter", 0) or 0)))
        return out

    def _extract_pledges(self) -> List[PledgeEntry]:
        guide = self._tracking("pledge")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict):
                    continue
                out.append(PledgeEntry(
                    PledgeId=k, Name=v.get("Name", k), Type=v.get("Type", ""),
                    CurrentStatus=v.get("CurrentStatus", "active"),
                    PartyIds=v.get("PartyIds", []),
                    Condition=v.get("Condition", ""), Consequence=v.get("Consequence", ""),
                    LastChapter=int(v.get("LastChapter", 0) or 0)))
        return out

    def _extract_deadlines(self) -> List[DeadlineEntry]:
        guide = self._tracking("deadline")
        out = []
        if guide:
            for k, v in guide.items():
                if not isinstance(v, dict):
                    continue
                out.append(DeadlineEntry(
                    DeadlineId=k, Name=v.get("Name", k), Type=v.get("Type", ""),
                    CurrentStatus=v.get("CurrentStatus", "active"),
                    Deadline=v.get("Deadline", ""), TriggerCondition=v.get("TriggerCondition", ""),
                    Consequence=v.get("Consequence", ""), PartyIds=v.get("PartyIds", []),
                    LastChapter=int(v.get("LastChapter", 0) or 0)))
        return out


_id_seq = [0]


def short_id_ref(prefix: str = "R") -> str:
    from .models.common import short_id
    return short_id(prefix)
