# -*- coding: utf-8 -*-
"""CHANGES 解析 + 归一化：ID 解析、自动创建、状态机防护"""

import re
from typing import Dict, List, Optional, Tuple

from .models import (
    ChapterChanges, FactSnapshot, TOP_LEVEL_FIELDS, is_likely_id,
    CharacterStateChange, ConflictProgressChange, PlotPointChange,
    ForeshadowingAction, LocationStateChange, FactionStateChange,
    TimeProgressionChange, CharacterMovementChange, ItemTransferChange,
    SecretRevealChange, PledgeConstraintChange, DeadlineConstraintChange,
)
from .models.common import short_id
from .prompt_builder import split_content_and_changes


class EntityLookup:
    """从快照构建 9 类实体映射：ID <-> Name"""

    def __init__(self, snapshot: FactSnapshot):
        self.snapshot = snapshot
        self.id_to_name = {}
        self.name_to_id = {}
        self._build()

    def _add(self, prefix: str, eid: str, name: str):
        if eid:
            self.id_to_name[eid] = name
        if name:
            self.name_to_id.setdefault(name, eid or "")

    def _build(self):
        s = self.snapshot
        for c in s.CharacterStates:
            self._add("C", c.CharacterId, c.Name)
        for c in s.ConflictProgress:
            self._add("CF", c.ConflictId, c.Name)
        for f in s.ForeshadowingStatus:
            self._add("FS", f.ForeshadowId, f.Name)
        for l in s.LocationStates:
            self._add("L", l.LocationId, l.Name)
        for l in s.LocationDescriptions:
            self._add("L", l.LocationId, l.Name)
        for f in s.FactionStates:
            self._add("F", f.FactionId, f.Name)
        for i in s.ItemStates:
            self._add("I", i.ItemId, i.Name)
        for sec in s.SecretStates:
            self._add("S", sec.SecretId, sec.Name)
        for p in s.PledgeStates:
            self._add("PL", p.PledgeId, p.Name)
        for d in s.DeadlineStates:
            self._add("DL", d.DeadlineId, d.Name)

    def resolve(self, value) -> str:
        """将名称或 ID 解析为 ID；无法解析返回原值（区分伪造与新建）"""
        if not value:
            return ""
        v = str(value).strip()
        # 直接是 ID
        if is_likely_id(v):
            return v
        # (XXX...) 括号提取
        m = re.search(r"\(([A-Z][0-9A-Z]{12})\)", v)
        if m:
            return m.group(1)
        # 名称查找
        return self.name_to_id.get(v, "")

    def name_for(self, eid: str) -> str:
        return self.id_to_name.get(eid, "")


# 可自动创建的实体类型
_AUTO_CREATE = {"I": "物品", "S": "秘密", "PL": "誓约", "DL": "倒计时", "L": "地点"}


class ChapterChangesParser:
    """解析 AI 输出 → ChapterChanges"""

    def parse(self, raw: str) -> Tuple[str, Optional[ChapterChanges]]:
        content, changes_text = split_content_and_changes(raw)
        if not changes_text:
            return content, None
        from .ai_service import extract_json
        data = extract_json(changes_text)
        if not isinstance(data, dict):
            return content, None
        cc = ChapterChanges()
        cc.CharacterStateChanges = [CharacterStateChange.from_dict(d) for d in data.get("CharacterStateChanges", []) or [] if isinstance(d, dict)]
        cc.ConflictProgress = [ConflictProgressChange.from_dict(d) for d in data.get("ConflictProgress", []) or [] if isinstance(d, dict)]
        cc.NewPlotPoints = [PlotPointChange.from_dict(d) for d in data.get("NewPlotPoints", []) or [] if isinstance(d, dict)]
        cc.ForeshadowingActions = [ForeshadowingAction.from_dict(d) for d in data.get("ForeshadowingActions", []) or [] if isinstance(d, dict)]
        cc.LocationStateChanges = [LocationStateChange.from_dict(d) for d in data.get("LocationStateChanges", []) or [] if isinstance(d, dict)]
        cc.FactionStateChanges = [FactionStateChange.from_dict(d) for d in data.get("FactionStateChanges", []) or [] if isinstance(d, dict)]
        cc.TimeProgression = [TimeProgressionChange.from_dict(d) for d in data.get("TimeProgression", []) or [] if isinstance(d, dict)]
        cc.CharacterMovements = [CharacterMovementChange.from_dict(d) for d in data.get("CharacterMovements", []) or [] if isinstance(d, dict)]
        cc.ItemTransfers = [ItemTransferChange.from_dict(d) for d in data.get("ItemTransfers", []) or [] if isinstance(d, dict)]
        cc.SecretRevealChanges = [SecretRevealChange.from_dict(d) for d in data.get("SecretRevealChanges", []) or [] if isinstance(d, dict)]
        cc.PledgeConstraintChanges = [PledgeConstraintChange.from_dict(d) for d in data.get("PledgeConstraintChanges", []) or [] if isinstance(d, dict)]
        cc.DeadlineConstraintChanges = [DeadlineConstraintChange.from_dict(d) for d in data.get("DeadlineConstraintChanges", []) or [] if isinstance(d, dict)]
        return content, cc


class ChapterChangesCanonicalizer:
    """归一化：解析 ID、自动创建实体、状态机防护。对标 4.1.1 Canonicalize"""

    def __init__(self, snapshot: FactSnapshot):
        self.snapshot = snapshot
        self.lookup = EntityLookup(snapshot)
        self.new_entities = []      # (type, name) 自动创建记录
        self.ambiguous_fields = []  # 名称无法解析的歧义标记（不拦截，仅告警）
        self.patch_log = []         # 规范化操作日志
        self.total_attempted = 0    # 总尝试解析次数
        self.forged_count = 0       # 疑似伪造计数

    def canonicalize(self, changes: ChapterChanges) -> ChapterChanges:
        self._resolve_characters(changes)
        self._resolve_conflicts(changes)
        self._resolve_foreshadowings(changes)
        self._resolve_locations(changes)
        self._resolve_factions(changes)
        self._resolve_items(changes)
        self._resolve_secrets(changes)
        self._resolve_pledges(changes)
        self._resolve_deadlines(changes)
        self._state_machine_guard(changes)
        return changes

    def is_forged(self) -> bool:
        """对标 CountForgedIds: >=5 且 >=80%"""
        return self.forged_count >= 5 and self.forged_count * 5 >= self.total_attempted * 4

    def _resolve_value(self, field_value, kind: str):
        """对标 Resolve 方法: ShortId→括号提取→名称→去注释"""
        self.total_attempted += 1
        if not field_value:
            return ""
        v = str(field_value).strip()
        v_orig = v
        # 1. 直接是合法ID
        if is_likely_id(v):
            if any(v == e.CharacterId for e in self.snapshot.CharacterStates) or \
               any(v == l.LocationId for l in self.snapshot.LocationStates) or \
               any(v == f.FactionId for f in self.snapshot.FactionStates) or \
               any(v == i.ItemId for i in self.snapshot.ItemStates) or \
               any(v == s.SecretId for s in self.snapshot.SecretStates) or \
               any(v == p.PledgeId for p in self.snapshot.PledgeStates) or \
               any(v == d.DeadlineId for d in self.snapshot.DeadlineStates):
                return v
            # ID不在账本 → 区分伪造和新创
            if kind in _AUTO_CREATE:
                new_id = v
                self.lookup._add(kind, v, v_orig)
                self.patch_log.append(f"{kind}: '{v_orig}' -> {v} (复用ID)")
                return new_id
            self.forged_count += 1
            self.ambiguous_fields.append(f"可能为伪造: {v_orig}")
            return v
        # 2. 括号提取 (XXX...)
        m = re.search(r"\(([A-Z][0-9A-Z]{12})\)", v)
        if m:
            extracted = m.group(1)
            if self.lookup.resolve(extracted):
                self.patch_log.append(f"{kind}: '{v_orig}' -> '{extracted}' (括号提取)")
                return extracted
        # 3. 名称反查
        resolved = self.lookup.resolve(v)
        if resolved:
            return resolved
        # 4. 去注释匹配
        stripped = re.sub(r"[（(].*$", "", v).strip()
        if stripped and stripped != v:
            resolved = self.lookup.resolve(stripped)
            if resolved:
                return resolved
            # 去注释后尝试自动创建
            if kind in _AUTO_CREATE:
                new_id = short_id(kind)
                self.new_entities.append((kind, stripped))
                self.lookup._add(kind, new_id, stripped)
                self.patch_log.append(f"{kind}: '{v_orig}' -> '{new_id}' (自动创建)")
                return new_id
        # 5. 无法解析
        if kind in _AUTO_CREATE and v:
            new_id = short_id(kind)
            self.new_entities.append((kind, v))
            self.lookup._add(kind, new_id, v)
            self.patch_log.append(f"{kind}: '{v_orig}' -> '{new_id}' (自动创建)")
            return new_id
        # 纯名称无法匹配 → 标记歧义，不拦截
        if v and not v.startswith(("与", "和", "及")) and len(v) >= 2:
            self.ambiguous_fields.append(f"名称无法匹配: '{v_orig}'")
        return v

    def _resolve_characters(self, changes: ChapterChanges):
        for c in changes.CharacterStateChanges:
            c.CharacterId = self._resolve_value(c.CharacterId, "C")
            # 关系键
            new_rel = {}
            for name, rel in (c.RelationshipChanges or {}).items():
                rid = self.lookup.resolve(name)
                if rid:
                    new_rel[rid] = rel
            c.RelationshipChanges = new_rel

    def _resolve_conflicts(self, changes: ChapterChanges):
        for c in changes.ConflictProgress:
            c.ConflictId = self._resolve_value(c.ConflictId, "CF")

    def _resolve_foreshadowings(self, changes: ChapterChanges):
        for f in changes.ForeshadowingActions:
            f.ForeshadowId = self._resolve_value(f.ForeshadowId, "FS")

    def _resolve_locations(self, changes: ChapterChanges):
        for l in changes.LocationStateChanges:
            if l.LocationId:
                l.LocationId = self._resolve_value(l.LocationId, "L")
            elif l.LocationName:
                l.LocationId = self._resolve_value(l.LocationName, "L")
        for m in changes.CharacterMovements:
            if m.FromLocation:
                m.FromLocation = self.lookup.resolve(m.FromLocation) or m.FromLocation
            if m.ToLocation:
                m.ToLocation = self._resolve_value(m.ToLocation, "L")
            elif m.ToLocationName:
                m.ToLocation = self._resolve_value(m.ToLocationName, "L")

    def _resolve_factions(self, changes: ChapterChanges):
        for f in changes.FactionStateChanges:
            f.FactionId = self._resolve_value(f.FactionId, "F")

    def _resolve_items(self, changes: ChapterChanges):
        for i in changes.ItemTransfers:
            if i.ItemId:
                i.ItemId = self._resolve_value(i.ItemId, "I")
            elif i.ItemName:
                i.ItemId = self._resolve_value(i.ItemName, "I")

    def _resolve_secrets(self, changes: ChapterChanges):
        for s in changes.SecretRevealChanges:
            if s.SecretId:
                s.SecretId = self._resolve_value(s.SecretId, "S")
            elif s.SecretName:
                s.SecretId = self._resolve_value(s.SecretName, "S")
            s.NewKnowerIds = [self._resolve_value(x, "C") for x in s.NewKnowerIds]

    def _resolve_pledges(self, changes: ChapterChanges):
        for p in changes.PledgeConstraintChanges:
            if p.PledgeId:
                p.PledgeId = self._resolve_value(p.PledgeId, "PL")
            elif p.PledgeName:
                p.PledgeId = self._resolve_value(p.PledgeName, "PL")
            p.PartyIds = [self._resolve_value(x, "C") for x in p.PartyIds]

    def _resolve_deadlines(self, changes: ChapterChanges):
        for d in changes.DeadlineConstraintChanges:
            if d.DeadlineId:
                d.DeadlineId = self._resolve_value(d.DeadlineId, "DL")
            elif d.DeadlineName:
                d.DeadlineId = self._resolve_value(d.DeadlineName, "DL")
            d.PartyIds = [self._resolve_value(x, "C") for x in d.PartyIds]

    def _state_machine_guard(self, changes: ChapterChanges):
        """状态机防护：伏笔动作 / 冲突状态回退 / 信任增量夹断"""
        fs_by_id = {f.ForeshadowId: f for f in self.snapshot.ForeshadowingStatus}
        kept = []
        for f in changes.ForeshadowingActions:
            entry = fs_by_id.get(f.ForeshadowId)
            if entry:
                if f.Action == "setup" and entry.IsSetup and not entry.IsResolved:
                    self.patch_log.append(f"伏笔 {entry.Name} 已埋设，忽略重复 setup")
                    continue
                if f.Action == "payoff" and not entry.IsSetup:
                    self.patch_log.append(f"伏笔 {entry.Name} 未埋设就 payoff，忽略")
                    continue
            kept.append(f)
        changes.ForeshadowingActions = kept

        # 冲突状态回退
        order = {"pending": 0, "active": 1, "climax": 2, "resolved": 3}
        conf_by_id = {c.ConflictId: c for c in self.snapshot.ConflictProgress}
        kept = []
        for c in changes.ConflictProgress:
            entry = conf_by_id.get(c.ConflictId)
            new_status = self._norm_status(c.NewStatus)
            if entry:
                old = self._norm_status(entry.Status)
                if new_status < old:
                    self.patch_log.append(f"冲突 {entry.Name} 状态回退，忽略")
                    continue
            c.NewStatus = new_status if new_status else c.NewStatus
            kept.append(c)
        changes.ConflictProgress = kept

        # 信任增量夹断 ±30
        for c in changes.CharacterStateChanges:
            for rid, rel in (c.RelationshipChanges or {}).items():
                rel.TrustDelta = max(-30, min(30, rel.TrustDelta or 0))

    @staticmethod
    def _norm_status(s: str) -> int:
        if not s:
            return -1
        s = str(s)
        table = {
            "未开始": 0, "待触发": 0, "pending": 0,
            "进行中": 1, "激化中": 1, "active": 1,
            "高潮": 2, "白热化": 2, "climax": 2,
            "已解决": 3, "已结束": 3, "resolved": 3,
        }
        return table.get(s, 1)
