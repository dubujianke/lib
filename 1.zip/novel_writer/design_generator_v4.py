# -*- coding: utf-8 -*-
"""统一设计生成器 - 严格对标 4.1.1: 仅 {规则名称} 一个变量，其他全由 ContextProvider 注入"""
import json
import os
import re
from typing import List

from .models import (
    WorldRulesData, CharacterRulesData, FactionRulesData,
    LocationRulesData, PlotRulesData, short_id, now_str,
)

DESIGN_FIELDS = {
    "worldrules": {
        "一句话简介": "OneLineSummary", "力量体系": "PowerSystem", "宇宙观": "Cosmology",
        "特殊法则": "SpecialLaws", "硬规则": "HardRules", "软规则": "SoftRules",
        "创世古代纪元": "AncientEra", "关键历史事件": "KeyEvents",
        "近代史": "ModernHistory", "故事开始前现状": "StatusQuo",
    },
    "characters": {
        "名称": "Name", "角色类型": "CharacterType", "性别": "Gender",
        "年龄": "Age", "身份": "Identity", "种族": "Race",
        "外貌特征": "Appearance", "性格特征": "Personality",
        "关联角色姓名": "TargetCharacterName", "关系类型": "RelationshipType",
        "情感动态": "EmotionDynamic", "关系描述": "Relationships",
        "外在目标": "Want", "内在需求": "Need", "致命缺点": "FlawBelief",
        "成长路径": "GrowthPath", "战斗技能": "CombatSkills",
        "特殊能力": "SpecialAbilities", "非战斗技能": "NonCombatSkills",
        "标志性装备": "SignatureItems", "常规装备": "CommonItems", "个人资产": "PersonalAssets",
    },
    "factions": {
        "名称": "Name", "势力类型": "FactionType", "理念目标": "Goal",
        "实力地盘": "StrengthTerritory", "领袖": "Leader", "核心成员": "CoreMembers",
        "成员特征": "MemberTraits", "盟友势力": "Allies", "敌对势力": "Enemies",
        "中立竞争": "NeutralCompetitors",
    },
    "locations": {
        "名称": "Name", "位置类型": "LocationType", "位置描述": "Description",
        "规模范围": "Scale", "地形环境": "Terrain", "气候特征": "Climate",
        "标志地标": "Landmarks", "特产资源": "Resources",
        "历史意义": "HistoricalSignificance", "危险禁忌": "Dangers", "所属势力": "FactionId",
    },
    "plotrules": {
        "名称": "Name", "总卷数": "TargetVolume", "所属卷": "AssignedVolume",
        "一句话简介": "OneLineSummary", "事件类型": "EventType", "所属阶段": "StoryPhase",
        "前置条件触发": "PrerequisitesTrigger", "主要角色": "MainCharacters",
        "关键NPC": "KeyNpcs", "地点": "Location", "时间跨度": "TimeDuration",
        "步骤标题": "StepTitle", "目标": "Goal", "冲突": "Conflict",
        "结果": "Result", "情绪曲线": "EmotionCurve", "主线推进": "MainPlotPush",
        "角色成长": "CharacterGrowth", "世界观揭示": "WorldReveal", "奖励线索": "RewardsClues",
    },
}

MODULE_HINTS = {"worldrules": "世界观规则", "characters": "角色规则",
                 "factions": "势力规则", "locations": "位置规则", "plotrules": "剧情规则"}

FIELD_CONSTRAINTS = """<field_constraints mandatory="true">
1. 「硬规则」「软规则」「关键历史事件」如有多条，请在字符串内用换行分条。
2. 避免编造未在上下文中出现的专有名词；如需新增，请在对应字段中先定义其含义。
</field_constraints>"""

# 对标 ContextProvider: 注入已有设计上下文 + 创作概念
def _build_context_text(store: dict, module: str, concept: str = "", extra: dict = None) -> str:
    parts = []
    if concept:
        parts.append(f"<creative_concept>创作概念：{concept}</creative_concept>")
    if extra:
        for k, v in extra.items():
            if v:
                parts.append(f"<{k}>{v}</{k}>")

    # 已有实体交叉引用
    world_data = store.get("world", {})
    if world_data.get("_summary"):
        parts.append(f"<existing_world>已有世界观：{world_data['_summary'][:200]}</existing_world>")

    chars = store.get("characters", {}).get("_names", [])
    if chars:
        parts.append(f"<existing_characters>已设计角色：{'、'.join(chars)}</existing_characters>")

    factions_n = store.get("factions", {}).get("_names", [])
    if factions_n:
        parts.append(f"<existing_factions>已设计势力：{'、'.join(factions_n)}</existing_factions>")

    locs = store.get("locations", {}).get("_names", [])
    if locs:
        parts.append(f"<existing_locations>已设计地点：{'、'.join(locs)}</existing_locations>")

    return "\n".join(parts) if parts else ""


class DesignGeneratorV4:
    """对标 4.1.1: SystemPrompt 变量仅 {规则名称}，上下文由 ContextProvider 注入"""

    def __init__(self, ai_service, prompt_dir: str = None):
        self.ai = ai_service
        self.template = self._load_template(prompt_dir)
        self._store = {}  # 缓存已有设计数据

    def _load_template(self, prompt_dir: str = None):
        if not prompt_dir:
            prompt_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "prompts")
        for fname in ["小说设计师.json", "\u5c0f\u8bf4\u8bbe\u8ba1\u5e08.json"]:
            path = os.path.join(prompt_dir, fname)
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    items = json.load(f)
                if isinstance(items, list) and items:
                    return items[0].get("SystemPrompt", "")
        return ""

    def _build_prompt(self, module: str, rule_name: str, concept: str = "", extra: dict = None) -> tuple:
        """对标 小说设计师 + ContextProvider。仅 {规则名称} 一个变量"""
        # SystemPrompt = 模板 + 仅 {规则名称} 替换 + 模块裁剪
        system = self.template.replace("{规则名称}", rule_name)
        hint = MODULE_HINTS.get(module)
        if hint:
            pattern = rf'<module_section id="{hint}">.*?</module_section>'
            m = re.search(pattern, system, re.S)
            if m:
                generic = system.split("【通用设计要求】")
                header = system.split("<module_section")[0]
                system = (header.strip() + "\n\n" + m.group(0) +
                          "\n\n【通用设计要求】" + (generic[1] if len(generic) > 1 else ""))

        # Context = 创作概念 + 已有设计 + 去重提醒 + field_constraints
        ctx = _build_context_text(self._store, module, concept, extra)
        module_key = {"worldrules": "world", "characters": "characters",
                       "factions": "factions", "locations": "locations",
                       "plotrules": "plot"}.get(module, module)
        existing = self._store.get(module_key, {}).get("_names", [])
        if existing and module != "worldrules":
            ctx += f"\n<duplicate_prevention>已有同名实体（请勿生成重名）：{'、'.join(existing)}</duplicate_prevention>"
        if ctx:
            system += "\n\n" + ctx
        system += "\n\n" + FIELD_CONSTRAINTS

        # User prompt = JSON 输出合约（无额外文字）
        fields = DESIGN_FIELDS.get(module, {})
        field_tpl = {cn: f"【{cn}】的值" for cn in fields}
        user = json.dumps(field_tpl, ensure_ascii=False)
        return system, user

    def _generate(self, module: str, rule_name: str, concept: str = "", extra: dict = None) -> dict:
        system, user = self._build_prompt(module, rule_name, concept, extra)
        for attempt in range(3):
            text = self.ai.chat(system, user, category=f"设计_{module}")
            data = self._extract_json(text)
            if data and len(data) >= 3:
                return data
            if attempt < 2:
                user_retry = user + f"\n\n（修正）上次输出不是合法JSON，请只输出纯JSON对象，不要代码块标记。"
        raise RuntimeError(f"AI 未返回有效 JSON: {text[:200]}")
        if isinstance(data, list):
            data = data[0]
        return data

    def _update_store(self, module_key: str, name: str, summary: str = ""):
        self._store.setdefault(module_key, {}).setdefault("_names", []).append(name)
        if summary and module_key == "world":
            self._store["world"]["_summary"] = summary

    def _make_entity(self, module: str, item: dict):
        fields = DESIGN_FIELDS.get(module, {})
        mapped = {}
        list_fields = {"HardRules", "SoftRules", "KeyEvents", "CombatSkills", "SpecialAbilities",
                        "NonCombatSkills", "SignatureItems", "CommonItems", "CoreMembers",
                        "Allies", "Enemies", "NeutralCompetitors", "Landmarks",
                        "Resources", "Dangers", "MainCharacters", "KeyNpcs"}
        for cn_key, en_key in fields.items():
            val = item.get(cn_key, "")
            if en_key in list_fields and isinstance(val, str):
                val = [v.strip() for v in val.split("\n") if v.strip()]
            mapped[en_key] = val
        if "Relations" in item:
            mapped["Relationships"] = item["Relations"]

        prefix = {"worldrules": "W", "characters": "C", "factions": "F",
                   "locations": "L", "plotrules": "P"}.get(module, "D")
        mapped.setdefault("Id", short_id(prefix))
        mapped.setdefault("Name", item.get("名称", item.get("Name", f"{module}_default")))
        mapped.setdefault("IsEnabled", True)
        mapped.setdefault("CreatedAt", now_str())
        mapped.setdefault("UpdatedAt", now_str())

        cls = {"worldrules": WorldRulesData, "characters": CharacterRulesData,
               "factions": FactionRulesData, "locations": LocationRulesData,
               "plotrules": PlotRulesData}.get(module, WorldRulesData)
        return cls(**{k: v for k, v in mapped.items() if k in cls.__dataclass_fields__})

    # ---- 对外接口: 一条记录一条 AI 调用 ----
    def generate_world_rules(self, name: str, concept: str = "") -> WorldRulesData:
        item = self._generate("worldrules", name, concept)
        entity = self._make_entity("worldrules", item)
        self._update_store("world", entity.Name, entity.OneLineSummary)
        return entity

    def generate_character(self, name: str, concept: str = "") -> CharacterRulesData:
        item = self._generate("characters", name, concept)
        entity = self._make_entity("characters", item)
        self._update_store("characters", entity.Name)
        return entity

    def generate_faction(self, name: str, concept: str = "") -> FactionRulesData:
        item = self._generate("factions", name, concept)
        entity = self._make_entity("factions", item)
        self._update_store("factions", entity.Name)
        return entity

    def generate_location(self, name: str, concept: str = "") -> LocationRulesData:
        item = self._generate("locations", name, concept)
        entity = self._make_entity("locations", item)
        self._update_store("locations", entity.Name)
        return entity

    def generate_plot_rule(self, name: str, concept: str = "",
                           extra: dict = None) -> PlotRulesData:
        item = self._generate("plotrules", name, concept, extra)
        return self._make_entity("plotrules", item)

    @staticmethod
    def _extract_json(text: str):
        if not text:
            return None
        t = text.strip()
        if t.startswith("```"):
            t = re.sub(r"^```(?:json)?\s*\n?", "", t)
            t = re.sub(r"\n?\s*```\s*$", "", t)
        start = t.find("{")
        if start == -1:
            return None
        depth, in_str, esc = 0, 0, 0
        for i in range(start, len(t)):
            ch = t[i]
            if in_str:
                if esc: esc = 0
                elif ch == "\\": esc = 1
                elif ch == '"': in_str = 0
                continue
            if ch == '"': in_str = 1
            elif ch == '{': depth += 1
            elif ch == '}':
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(t[start:i + 1])
                    except json.JSONDecodeError:
                        pass
        try:
            return json.loads(t)
        except json.JSONDecodeError:
            return None
