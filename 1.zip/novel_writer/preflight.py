# -*- coding: utf-8 -*-
"""对标 4.1.1 PreflightValidator: 规划四层校验（打包前）"""
import json, os, re
from typing import Dict, List, Set


class PreflightValidator:
    """打包前校验：分卷/章节/蓝图引用一致性 + 层级对齐"""

    IGNORED = {"无", "暂无", "空", "-", "/", "none", "n/a", "null",
               "无角色", "无地点", "无势力", "未定", "待定", "未知"}

    def __init__(self, project):
        self.project = project
        self.errors = []
        self.warnings = []

    def run(self) -> bool:
        # 加载所有数据
        world = self._load_design("world")
        characters = self._load_design("characters")
        factions = self._load_design("factions")
        locations = self._load_design("locations")
        plot = self._load_design("plot")
        volumes = self._load_plan_list("volumes")
        chapters = self._load_plan_list("chapters")

        char_index = self._build_index(characters)
        fac_index = self._build_index(factions)
        loc_index = self._build_index(locations)

        # 1. 分卷引用校验
        self._validate_references(volumes, "分卷", char_index, fac_index, loc_index)

        # 2. 章节引用校验
        self._validate_references(chapters, "章节", char_index, fac_index, loc_index)

        # 3. 蓝图引用校验
        for ch in chapters:
            bps = self._load_blueprints(ch.get("Id", ""))
            self._validate_references(bps, f"蓝图(第{ch.get('ChapterNumber',0)}章)", char_index, fac_index, loc_index)

        # 4. 卷-章关联
        self._validate_volume_chapter(volumes, chapters)

        # 5. 层级对齐：章节引用⊆卷引用
        self._validate_hierarchy(volumes, chapters, char_index, fac_index, loc_index)

        is_valid = len(self.errors) == 0
        if self.errors:
            print(f"  Preflight: {len(self.errors)} 项错误")
            for e in self.errors[:5]:
                print(f"    ✗ {e}")
        if self.warnings:
            print(f"  Preflight: {len(self.warnings)} 项警告")
            for w in self.warnings[:3]:
                print(f"    ⚠ {w}")
        if is_valid:
            print("  Preflight: 全部检查通过")
        return is_valid

    def _load_design(self, entity: str) -> List[dict]:
        data = self.project.load_design(entity)
        if isinstance(data, dict):
            return data.get("items", [])
        return data or []

    def _load_plan_list(self, entity: str) -> List[dict]:
        data = self.project.load_plan(entity)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return data.get(entity, [])
        return []

    def _load_blueprints(self, chapter_id: str) -> List[dict]:
        if not chapter_id:
            return []
        data = self.project.load_plan(f"blueprints_{chapter_id}")
        if isinstance(data, list):
            return data
        return []

    @staticmethod
    def _build_index(entities: List[dict]) -> dict:
        names = set()
        name_to_id = {}
        for e in entities:
            n = (e.get("Name") or "").strip()
            i = (e.get("Id") or "").strip()
            if n and n not in PreflightValidator.IGNORED:
                names.add(n)
            if n and i:
                name_to_id[n] = i
        return {"names": names, "name_to_id": name_to_id}

    @staticmethod
    def _split_names(val) -> List[str]:
        if not val:
            return []
        if isinstance(val, list):
            return [n.strip() for n in val if n and n.strip() not in PreflightValidator.IGNORED]
        if isinstance(val, str):
            return [n.strip() for n in re.split(r"[、，,\n]", val)
                    if n.strip() and n.strip() not in PreflightValidator.IGNORED]
        return []

    def _validate_references(self, entities: List[dict], label_prefix: str,
                             char_idx, fac_idx, loc_idx):
        for ent in entities:
            label = f"{label_prefix}[{ent.get('Name', ent.get('Id', '?'))}]"
            for field, idx, fname in [
                ("ReferencedCharacterNames", char_idx, "出场角色"),
                ("Cast", char_idx, "出场角色"),
                ("ReferencedFactionNames", fac_idx, "涉及势力"),
                ("Factions", fac_idx, "涉及势力"),
                ("ReferencedLocationNames", loc_idx, "涉及地点"),
                ("Locations", loc_idx, "涉及地点"),
            ]:
                names = self._split_names(ent.get(field, ""))
                unmatched = [n for n in names if n not in idx["names"]]
                if unmatched:
                    self.errors.append(f"{label}「{fname}」未映射: {'、'.join(unmatched)}")

    def _validate_volume_chapter(self, volumes: List[dict], chapters: List[dict]):
        if not volumes or not chapters:
            return
        vol_numbers = set()
        for v in volumes:
            vn = v.get("VolumeNumber", 0)
            if vn > 0:
                vol_numbers.add(vn)
        for c in chapters:
            vol = c.get("Volume", "")
            if not vol:
                self.errors.append(f"章节[{c.get('ChapterTitle', c.get('Name','?'))}]「所属卷」为空")
                continue
            m = re.search(r"第\s*(\d+)\s*卷", vol)
            if m:
                vn = int(m.group(1))
            else:
                # try matching by title
                vn = None
                for v in volumes:
                    if v.get("VolumeTitle", "") == vol:
                        vn = v.get("VolumeNumber", 0)
                        break
            if vn is None or vn not in vol_numbers:
                self.errors.append(f"章节[{c.get('ChapterTitle', c.get('Name','?'))}]「所属卷」({vol}) 无法匹配分卷")

    def _validate_hierarchy(self, volumes: List[dict], chapters: List[dict],
                            char_idx, fac_idx, loc_idx):
        """对标 ValidateHierarchicalAlignment: 章节引用⊆卷引用"""
        vol_refs = {}
        for v in volumes:
            vn = v.get("VolumeNumber", 0)
            if vn <= 0:
                continue
            vol_refs[vn] = (
                set(self._normalize_names(v.get("ReferencedCharacterNames", ""), char_idx)),
                set(self._normalize_names(v.get("ReferencedLocationNames", ""), loc_idx)),
                set(self._normalize_names(v.get("ReferencedFactionNames", ""), fac_idx)),
            )
        for c in chapters:
            vol = c.get("Volume", "")
            m = re.search(r"第\s*(\d+)\s*卷", vol)
            vn = int(m.group(1)) if m else 0
            if vn not in vol_refs:
                continue
            vr = vol_refs[vn]
            label = f"第{vn}卷·第{c.get('ChapterNumber',0)}章"
            ch_chars = set(self._normalize_names(c.get("ReferencedCharacterNames", ""), char_idx))
            ch_locs = set(self._normalize_names(c.get("ReferencedLocationNames", ""), loc_idx))
            ch_facs = set(self._normalize_names(c.get("ReferencedFactionNames", ""), fac_idx))
            if vr[0]:
                extra = ch_chars - vr[0]
                if extra:
                    self.errors.append(f"{label}「出场角色」存在未在卷中声明的实体: {'、'.join(extra)}")
            if vr[1]:
                extra = ch_locs - vr[1]
                if extra:
                    self.errors.append(f"{label}「涉及地点」存在未在卷中声明的实体: {'、'.join(extra)}")
            if vr[2]:
                extra = ch_facs - vr[2]
                if extra:
                    self.errors.append(f"{label}「涉及势力」存在未在卷中声明的实体: {'、'.join(extra)}")

    @staticmethod
    def _normalize_names(val, index) -> List[str]:
        names = PreflightValidator._split_names(val)
        result = []
        for n in names:
            nid = index["name_to_id"].get(n, n)
            result.append(nid)
        return result
