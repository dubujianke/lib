# -*- coding: utf-8 -*-
"""状态回写：CHANGES → 15 维追踪 Guide（11 个 Tracking Service）"""

import json
from typing import Dict, List

from .models import ChapterChanges, FactSnapshot, is_likely_id
from .storage import Project
from .models.common import short_id


class TrackingManager:
    """统一入口：将归一化后的 CHANGES 写入各追踪 Guide"""

    def __init__(self, project: Project):
        self.project = project
        self._stores = {
            "character_state": project.tracking("character_state"),
            "conflict_progress": project.tracking("conflict_progress"),
            "foreshadowing": project.tracking("foreshadowing"),
            "plot_points": project.tracking("plot_points"),
            "location_state": project.tracking("location_state"),
            "faction_state": project.tracking("faction_state"),
            "timeline": project.tracking("timeline"),
            "character_location": project.tracking("character_location"),
            "item_state": project.tracking("item_state"),
            "secret": project.tracking("secret"),
            "pledge": project.tracking("pledge"),
            "deadline": project.tracking("deadline"),
        }

    def update(self, chapter_number: int, changes: ChapterChanges, snapshot: FactSnapshot):
        """写入全部状态变更"""
        self._update_characters(chapter_number, changes, snapshot)
        self._update_conflicts(chapter_number, changes)
        self._update_foreshadowings(chapter_number, changes)
        self._update_plot_points(chapter_number, changes)
        self._update_locations(chapter_number, changes, snapshot)
        self._update_factions(chapter_number, changes)
        self._update_timeline(chapter_number, changes)
        self._update_movements(chapter_number, changes)
        self._update_items(chapter_number, changes, snapshot)
        self._update_secrets(chapter_number, changes, snapshot)
        self._update_pledges(chapter_number, changes)
        self._update_deadlines(chapter_number, changes)
        self.flush()

    def flush(self):
        for store in self._stores.values():
            store.flush()

    # ---- 角色状态 ----
    def _update_characters(self, chapter_number: int, changes: ChapterChanges, snapshot: FactSnapshot):
        store = self._stores["character_state"]
        data = store.data()
        # 用快照中的角色初始化（若还没有）
        name_by_id = {c.CharacterId: c.Name for c in snapshot.CharacterStates}
        init_level = {c.CharacterId: c.Level for c in snapshot.CharacterStates}
        for c in snapshot.CharacterStates:
            if c.CharacterId not in data:
                data[c.CharacterId] = {
                    "Name": c.Name, "Level": c.Level, "Phase": c.Phase,
                    "Abilities": list(c.Abilities), "LostAbilities": list(c.LostAbilities),
                    "MentalState": "", "KeyEvent": "", "LastChapter": 0,
                    "Importance": c.Importance, "Relationships": {},
                }
        for ch in changes.CharacterStateChanges:
            cid = ch.CharacterId
            if cid not in data:
                # 新角色（设计库存在但未追踪）
                data[cid] = {
                    "Name": name_by_id.get(cid, cid), "Level": init_level.get(cid, ""),
                    "Phase": "", "Abilities": [], "LostAbilities": [],
                    "MentalState": "", "KeyEvent": "", "LastChapter": 0,
                    "Importance": 2, "Relationships": {},
                }
            entry = data[cid]
            if ch.NewLevel:
                entry["Level"] = ch.NewLevel
            if ch.NewAbilities:
                cur = set(entry.get("Abilities", []))
                cur.update(ch.NewAbilities)
                entry["Abilities"] = list(cur)
            if ch.LostAbilities:
                cur = set(entry.get("Abilities", []))
                for la in ch.LostAbilities:
                    cur.discard(la)
                lost = set(entry.get("LostAbilities", []))
                lost.update(ch.LostAbilities)
                entry["LostAbilities"] = list(lost)
                entry["Abilities"] = list(cur)
            if ch.NewMentalState:
                entry["MentalState"] = ch.NewMentalState
            if ch.KeyEvent:
                entry["KeyEvent"] = ch.KeyEvent
            if ch.Importance in ("critical", "important"):
                entry["Importance"] = max(entry.get("Importance", 0), 4 if ch.Importance == "critical" else 3)
            entry["LastChapter"] = chapter_number
            for rid, rel in (ch.RelationshipChanges or {}).items():
                rels = entry.setdefault("Relationships", {})
                prev = rels.get(rid, {"Relation": "", "Trust": 0, "EmotionPhase": ""})
                prev["Relation"] = rel.Relation or prev["Relation"]
                prev["Trust"] = int(prev.get("Trust", 0)) + int(rel.TrustDelta or 0)
                prev["EmotionPhase"] = rel.EmotionPhase or prev["EmotionPhase"]
                rels[rid] = prev
        store.set_all(data)

    # ---- 冲突 ----
    def _update_conflicts(self, chapter_number: int, changes: ChapterChanges):
        store = self._stores["conflict_progress"]
        data = store.data()
        for c in changes.ConflictProgress:
            cid = c.ConflictId
            if cid not in data:
                data[cid] = {"Name": cid, "Type": "", "Tier": "", "Status": "",
                             "LastEvent": "", "LastChapter": 0, "InvolvedCharacters": []}
            entry = data[cid]
            if c.NewStatus:
                entry["Status"] = c.NewStatus
            if c.Event:
                entry["LastEvent"] = c.Event
            entry["LastChapter"] = chapter_number
        store.set_all(data)

    # ---- 伏笔 ----
    def _update_foreshadowings(self, chapter_number: int, changes: ChapterChanges):
        store = self._stores["foreshadowing"]
        data = store.data()
        for f in changes.ForeshadowingActions:
            fid = f.ForeshadowId
            if fid not in data:
                data[fid] = {"Name": fid, "Tier": "", "IsSetup": False, "IsResolved": False,
                             "IsOverdue": False, "ExpectedSetupChapter": 0, "ExpectedPayoffChapter": 0,
                             "ActualSetupChapter": 0, "ActualPayoffChapter": 0}
            entry = data[fid]
            if f.Action == "setup":
                entry["IsSetup"] = True
                entry["ActualSetupChapter"] = chapter_number
            elif f.Action == "payoff":
                entry["IsResolved"] = True
                entry["ActualPayoffChapter"] = chapter_number
        store.set_all(data)

    # ---- 剧情节点 ----
    def _update_plot_points(self, chapter_number: int, changes: ChapterChanges):
        store = self._stores["plot_points"]
        data = store.data()
        for p in changes.NewPlotPoints:
            pid = short_id("PP")
            data[pid] = {
                "Keywords": p.Keywords, "Context": p.Context,
                "InvolvedCharacters": p.InvolvedCharacters, "Storyline": p.Storyline,
                "Chapter": chapter_number, "Importance": 3 if p.Importance in ("critical", "important") else 1,
            }
        store.set_all(data)

    # ---- 地点状态 ----
    def _update_locations(self, chapter_number: int, changes: ChapterChanges, snapshot: FactSnapshot):
        store = self._stores["location_state"]
        data = store.data()
        desc_by_id = {l.LocationId: l for l in snapshot.LocationDescriptions}
        for l in changes.LocationStateChanges:
            lid = l.LocationId
            if lid not in data:
                desc = desc_by_id.get(lid)
                data[lid] = {"Name": desc.Name if desc else (l.LocationName or lid),
                             "CurrentStatus": "正常", "Description": desc.Description if desc else "",
                             "LastEvent": "", "LastChapter": 0}
            entry = data[lid]
            if l.NewStatus:
                entry["CurrentStatus"] = l.NewStatus
            if l.Event:
                entry["LastEvent"] = l.Event
            entry["LastChapter"] = chapter_number
        store.set_all(data)

    # ---- 势力状态 ----
    def _update_factions(self, chapter_number: int, changes: ChapterChanges):
        store = self._stores["faction_state"]
        data = store.data()
        for f in changes.FactionStateChanges:
            fid = f.FactionId
            if fid not in data:
                data[fid] = {"Name": fid, "CurrentStatus": "正常", "LastEvent": "", "LastChapter": 0}
            entry = data[fid]
            if f.NewStatus:
                entry["CurrentStatus"] = f.NewStatus
            if f.Event:
                entry["LastEvent"] = f.Event
            entry["LastChapter"] = chapter_number
        store.set_all(data)

    # ---- 时间线 ----
    def _update_timeline(self, chapter_number: int, changes: ChapterChanges):
        store = self._stores["timeline"]
        data = store.data()
        for t in changes.TimeProgression:
            tid = short_id("T")
            data[tid] = {"TimePeriod": t.TimePeriod, "ElapsedTime": t.ElapsedTime,
                         "KeyTimeEvent": t.KeyTimeEvent, "Chapter": chapter_number}
        store.set_all(data)

    # ---- 角色移动 ----
    def _update_movements(self, chapter_number: int, changes: ChapterChanges):
        store = self._stores["character_location"]
        data = store.data()
        for m in changes.CharacterMovements:
            cid = m.CharacterId
            if cid not in data:
                data[cid] = {"Name": cid, "CurrentLocation": "", "LastUpdatedChapter": 0}
            entry = data[cid]
            if m.ToLocation:
                entry["CurrentLocation"] = m.ToLocation
            entry["LastUpdatedChapter"] = chapter_number
        store.set_all(data)

    # ---- 物品 ----
    def _update_items(self, chapter_number: int, changes: ChapterChanges, snapshot: FactSnapshot):
        store = self._stores["item_state"]
        data = store.data()
        desc_by_id = {i.ItemId: i for i in snapshot.ItemStates}
        for i in changes.ItemTransfers:
            iid = i.ItemId
            if iid not in data:
                desc = desc_by_id.get(iid)
                data[iid] = {"Name": desc.Name if desc else (i.ItemName or iid),
                             "CurrentHolder": "", "CurrentStatus": "active",
                             "Description": desc.Description if desc else "", "LastEvent": "", "LastChapter": 0}
            entry = data[iid]
            if i.ToHolder:
                entry["CurrentHolder"] = i.ToHolder
            if i.NewStatus:
                entry["CurrentStatus"] = i.NewStatus
            if i.Event:
                entry["LastEvent"] = i.Event
            entry["LastChapter"] = chapter_number
        store.set_all(data)

    # ---- 秘密 ----
    def _update_secrets(self, chapter_number: int, changes: ChapterChanges, snapshot: FactSnapshot):
        store = self._stores["secret"]
        data = store.data()
        for s in changes.SecretRevealChanges:
            sid = s.SecretId
            if sid not in data:
                data[sid] = {"Name": s.SecretName or sid, "KnowerIds": [], "CurrentStatus": "hidden",
                             "LastChapter": 0}
            entry = data[sid]
            if s.NewKnowerIds:
                known = set(entry.get("KnowerIds", []))
                known.update(s.NewKnowerIds)
                entry["KnowerIds"] = list(known)
            entry["CurrentStatus"] = "revealed"
            entry["LastChapter"] = chapter_number
        store.set_all(data)

    # ---- 誓约 ----
    def _update_pledges(self, chapter_number: int, changes: ChapterChanges):
        store = self._stores["pledge"]
        data = store.data()
        for p in changes.PledgeConstraintChanges:
            pid = p.PledgeId
            if pid not in data:
                data[pid] = {"Name": p.PledgeName or pid, "Type": p.Type, "CurrentStatus": "active",
                             "PartyIds": p.PartyIds, "Condition": p.Condition, "Consequence": p.Consequence,
                             "LastChapter": 0}
            entry = data[pid]
            if p.Action in ("fulfill", "break", "expire"):
                entry["CurrentStatus"] = p.Action
            elif p.Action == "update":
                if p.Condition:
                    entry["Condition"] = p.Condition
                if p.Consequence:
                    entry["Consequence"] = p.Consequence
            if p.PartyIds:
                entry["PartyIds"] = list(set(entry.get("PartyIds", [])) | set(p.PartyIds))
            entry["LastChapter"] = chapter_number
        store.set_all(data)

    # ---- 倒计时 ----
    def _update_deadlines(self, chapter_number: int, changes: ChapterChanges):
        store = self._stores["deadline"]
        data = store.data()
        for d in changes.DeadlineConstraintChanges:
            did = d.DeadlineId
            if did not in data:
                data[did] = {"Name": d.DeadlineName or did, "Type": d.Type, "CurrentStatus": "active",
                             "Deadline": d.Deadline, "TriggerCondition": d.TriggerCondition,
                             "Consequence": d.Consequence, "PartyIds": d.PartyIds, "LastChapter": 0}
            entry = data[did]
            if d.Action in ("trigger", "expire", "cancel"):
                entry["CurrentStatus"] = d.Action
            elif d.Action == "update":
                if d.Deadline:
                    entry["Deadline"] = d.Deadline
            entry["LastChapter"] = chapter_number
        store.set_all(data)
