# -*- coding: utf-8 -*-
"""创作配置文件加载：读 novel_config.json 映射到设计参数"""

import json
import os
from typing import Optional


def load_config(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def merge_design_sketches(config: dict) -> dict:
    """从配置文件提取预填的设计草稿，生成时跳过 AI 生成直接用草稿"""
    sketches = {}
    c = config.get("世界观", {})
    if c.get("力量体系"):
        sketches["world"] = c
    chars = config.get("角色", [])
    if chars and any(ch.get("姓名") for ch in chars[:1]):
        sketches["characters"] = []
        for ch in chars:
            sketches["characters"].append({
                "Name": ch.get("姓名", ""),
                "CharacterType": ch.get("类型", "主角"),
                "Gender": ch.get("性别", ""),
                "Age": ch.get("年龄", ""),
                "Identity": ch.get("身份", ""),
                "Appearance": ch.get("外貌", ""),
                "Personality": ch.get("性格", ""),
                "Want": ch.get("渴望", ""),
                "Need": ch.get("需要", ""),
                "FlawBelief": ch.get("缺陷", ""),
                "GrowthPath": ch.get("成长弧", ""),
                "CombatSkills": ch.get("战斗技能", []),
                "SpecialAbilities": ch.get("特殊能力", []),
                "SignatureItems": ch.get("标志物品", []),
                "Relationships": ch.get("关系", {}),
            })
    factions = config.get("势力", [])
    if factions and any(f.get("名称") for f in factions[:1]):
        sketches["factions"] = []
        for f in factions:
            sketches["factions"].append({
                "Name": f.get("名称", ""),
                "FactionType": f.get("类型", ""),
                "Goal": f.get("目标", ""),
                "Leader": f.get("首领", ""),
                "CoreMembers": f.get("核心成员", []),
            })
    locations = config.get("地点", [])
    if locations and any(l.get("名称") for l in locations[:1]):
        sketches["locations"] = []
        for l in locations:
            sketches["locations"].append({
                "Name": l.get("名称", ""),
                "LocationType": l.get("类型", ""),
                "Description": l.get("描述", ""),
                "Landmarks": l.get("特征", []),
            })
    plot = config.get("剧情", {})
    if plot.get("核心冲突"):
        sketches["plot"] = plot
    return sketches


def build_creative_spec(config: dict) -> str:
    """从生成控制构建 creative_spec 覆盖文本"""
    gc = config.get("生成控制", {})
    parts = []
    if gc.get("叙事视角"):
        parts.append(f"【叙事视角】{gc['叙事视角']}")
    if gc.get("写作风格"):
        parts.append(f"【写作风格】{gc['写作风格']}")
    if gc.get("情感基调"):
        parts.append(f"【情感基调】{gc['情感基调']}")
    if gc.get("每章字数"):
        parts.append(f"【目标字数】{gc['每章字数']}")
    must = gc.get("必须包含", [])
    if must:
        parts.append(f"【必须包含】{', '.join(must)}")
    avoid = gc.get("必须避免", [])
    if avoid:
        parts.append(f"【必须避免】{', '.join(avoid)}")
    return "\n".join(parts)
