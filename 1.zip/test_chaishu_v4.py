# -*- coding: utf-8 -*-
"""拆书 v4.1.1 完整测试"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from novel_writer.book_pipeline_v4 import ChaishuPipeline4

p = ChaishuPipeline4("1")
p.run()
