# -*- coding: utf-8 -*-
"""一键生成 v4：拆书→小说设计师模板五维→规划→逐章"""
import sys, os, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ai_client import AIClient
from novel_writer.ai_service import AIService
from novel_writer.pipeline import NovelPipeline
from novel_writer.storage import create_project
from novel_writer.prompt_library import PromptLibrary
from novel_writer.book_pipeline_v4 import ChaishuPipeline4

PROJ = "novel_v4_test"
proj_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "projects", PROJ)
if os.path.exists(proj_path):
    shutil.rmtree(proj_path, ignore_errors=True)

p = create_project(PROJ)
ai = AIService()
lib = PromptLibrary()
np = NovelPipeline(p, ai, lib)

print("=" * 50)
print("Step 1: 五维设定 (v4 小说设计师)")
print("=" * 50)
design = np.generate_design("玄幻", "修仙少年逆天改命", total_volumes=2, total_chapters=4, char_count=3)
w = design["world"]
print(f"  世界观: [{w.Name}] {w.OneLineSummary[:60]}")
print(f"  力量体系: {w.PowerSystem[:60]}")
print(f"  角色: {', '.join(c.Name for c in design['characters'])}")
print(f"  势力: {', '.join(f.Name for f in design['factions'])}")
print(f"  地点: {', '.join(l.Name for l in design['locations'])}")
print(f"  剧情: {design['plot'].Name} | 冲突: {design['plot'].Conflict[:40]}")

print("\n" + "=" * 50)
print("Step 2: 四层规划")
print("=" * 50)
plan = np.generate_plan("玄幻", 4)
vols = plan["volumes"]
chs = plan["chapters"]
print(f"  大纲: {plan['outline'].OneLineOutline[:50]}")
print(f"  分卷: {len(vols)} 卷")
for v in vols:
    print(f"    第{v.VolumeNumber}卷「{v.VolumeTitle}」(第{v.StartChapter}-{v.EndChapter}章)")
print(f"  章节: {len(chs)} 章")

print("\n" + "=" * 50)
print("Step 3: 逐章生成")
print("=" * 50)
results = np.generate_all_chapters("玄幻", 1, 2, word_count=400, verbose=True)
print(f"\n  完成 {len(results)} 章")

print("\n" + "=" * 50)
print("产出预览")
print("=" * 50)
for c in chs[:2]:
    content = p.load_chapter(c.Id)
    preview = content.split("\n")[:3]
    print(f"  第{c.ChapterNumber}章「{c.ChapterTitle[:20]}」")
    for line in preview:
        print(f"    {line[:60]}")

ai.close()
print(f"\n存储目录: {p.dir}")
