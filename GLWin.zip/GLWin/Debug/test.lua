--region *.lua  
--Date  
--此文件由[BabeLua]插件自动生成  
  
print("lua script func.lua have been load ")  
  
  
function showinfo()  
print("welcome to  lua world ")  
end  
  
function showstr(str)  
print("The string you input is " .. str)  
end  
  
  
function add(x,y)  
return x+y;  
end  
--endregion  