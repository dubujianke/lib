#include "ESContext.h"
#include "SpecialUtil.h"
#include "gfx.h"


int viewport_matrix[ 4 ];

ESContext::ESContext(void)
{
	vec3 e = { 30, 150, 300 },
		c = { 30.0f,  30.0f, -1.0f },
		u = { 0.0f,  1.0f, 0.0f };
	eyeLocation = e;
	centerVec = c;
	dirVec = u;
}

ESContext::~ESContext(void)
{
}



void configListener(ESContext *esContext) {
}



int Init(ESContext *esContext)
{

	GFX_start();
	float width = esContext->userData->width;
	float height = esContext->userData->height;
	glViewport( 0.0f, 0.0f, width, height );
	glGetIntegerv( GL_VIEWPORT, viewport_matrix );
	int terrianWidth = TERRIAN_WIDTH;
	int terrianGridWidth = 1024;

	esContext->aMK2DNode.initData();
	esContext->aMK2DNode.initSize(100,60,2,2,2,2);

	return TRUE;
}


void printMat4(mat4 *vv) {
}


void drawFunc( ESContext *esContext )
{
	///////////////////////////////////////////////////////////3D
	GFX_set_matrix_mode( PROJECTION_MATRIX );
	{
		GFX_load_identity();
		GFX_set_perspective( 45.0f, ( float )esContext->userData->width / ( float )esContext->userData->height,	10.0f, 1000.0f, 0.0f );
		glDisable( GL_CULL_FACE );
	}
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	
}

void tochUI(ESContext *pEsContext, int x, int y) {

}

void touchBegin(ESContext *esContext, int x, int y) {


}


void touchMove(ESContext *esContext, int x, int y) {
	

}

void touchEnd(ESContext *esContext, int x, int y) {

}

void resize(ESContext *esContext, int width, int height) {
}

void keyFunc(ESContext *esContext, unsigned char key, int, int ) {
	
	
	printf("%c\r\n", key);
}

void shutdownFunc( ) {
}

void  updateFunc(ESContext *esContext, float deltaTime ) {
}

void BuildAttribList( EGLint *attribList )
{
	int  nAttribCount = 0;
	attribList[nAttribCount++] = EGL_RED_SIZE;
	attribList[nAttribCount++] = 5; 
	attribList[nAttribCount++] = EGL_GREEN_SIZE;
	attribList[nAttribCount++] = 6;
	attribList[nAttribCount++] = EGL_BLUE_SIZE;
	attribList[nAttribCount++] = 5;
	attribList[nAttribCount++] = EGL_ALPHA_SIZE;
	attribList[nAttribCount++] = 0;
	attribList[nAttribCount++] = EGL_DEPTH_SIZE;
	attribList[nAttribCount++] = 16;
	attribList[nAttribCount++] = EGL_STENCIL_SIZE;
	attribList[nAttribCount++] = 0;
	attribList[nAttribCount++] = EGL_SAMPLES;
	attribList[nAttribCount++] = 4;
	attribList[nAttribCount++] = EGL_NONE;
}


GLboolean esCreateWindow ( ESContext *esContext, const char *title, GLint width, GLint height, GLuint flags )
{
#ifndef __APPLE__
	EGLConfig config;
	EGLint majorVersion;
	EGLint minorVersion;
	EGLint contextAttribs[] = { EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE };

	if ( esContext == NULL )
	{
		return GL_FALSE;
	}

#ifdef ANDROID
	// For Android, get the width/height from the window rather than what the
	// application requested.
	esContext->userData->width = ANativeWindow_getWidth ( esContext->eglNativeWindow );
	esContext->userData->height = ANativeWindow_getHeight ( esContext->eglNativeWindow );
#else
#endif


	esContext->eglDisplay = eglGetDisplay( esContext->eglNativeDisplay );
	if ( esContext->eglDisplay == EGL_NO_DISPLAY )
	{
		return GL_FALSE;
	}

	if ( !eglInitialize ( esContext->eglDisplay, &majorVersion, &minorVersion ) )
	{
		return GL_FALSE;
	}

	{
		EGLint numConfigs = 0;

		if ( ! eglGetConfigs( esContext->eglDisplay, NULL, 0, &numConfigs ) )
		{
			return FALSE;
		}

		EGLint attribList[64];

		BuildAttribList(attribList);

		// Choose config
		if ( !eglChooseConfig ( esContext->eglDisplay, attribList, &config, 1, &numConfigs ) )
		{
			return GL_FALSE;
		}

		if ( numConfigs < 1 )
		{
			return GL_FALSE;
		}
	}


#ifdef ANDROID
	// For Android, need to get the EGL_NATIVE_VISUAL_ID and set it using ANativeWindow_setBuffersGeometry
	{
		EGLint format = 0;
		eglGetConfigAttrib ( esContext->eglDisplay, config, EGL_NATIVE_VISUAL_ID, &format );
		ANativeWindow_setBuffersGeometry ( esContext->eglNativeWindow, 0, 0, format );
	}
#endif // ANDROID

	// Create a surface
	esContext->eglSurface = eglCreateWindowSurface ( esContext->eglDisplay, config, esContext->eglNativeWindow, NULL );
	if ( esContext->eglSurface == EGL_NO_SURFACE )
	{
		return GL_FALSE;
	}

	// Create a GL context
	esContext->eglContext = eglCreateContext ( esContext->eglDisplay, config, EGL_NO_CONTEXT, contextAttribs );

	if ( esContext->eglContext == EGL_NO_CONTEXT )
	{
		return GL_FALSE;
	}

	// Make the context current
	if ( !eglMakeCurrent ( esContext->eglDisplay, esContext->eglSurface, esContext->eglSurface, esContext->eglContext ) )
	{
		return GL_FALSE;
	}

#endif // #ifndef __APPLE__

	return GL_TRUE;
}
