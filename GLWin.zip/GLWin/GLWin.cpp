//https://github.com/guardianproject/openssl-android.git
// 
/*
�������� VS2022   ����Ŀ¼ D:\applib\prj\objs\lang
E:\fbx\FBXSDK\2020.3.7\samples\ViewScene
E:\fbx\FBXSDK\2020.3.7\samples\ViewScene

*/
//#include "vld.h"
#include "ESContext.h"
#include "Perspective.h"
#include "MKObj.h"
#include <stdlib.h>
#include "FileUtil.h"
#include "MKConfig.h"
#include "MKScreen.h"
#include <noise.h>
#include "net/MKUDPSocket.h"
#include <iostream>
#include <thread>
#include <atomic>
#include <vector>
#include <chrono>
#include "MKFBXOBJSprite.h"
//#include <iostream>
//extern "C" {
//#include  "quickjs.h"
//#include  "quickjs-libc.h"
//}
//#include "quickjspp.hpp"
//#include <iostream>
//#include <string>
//#include <fstream>
//#include <sstream>
//#include <iostream>
//#include <stdlib.h>

//#define EVENT_ENABLE
using namespace std;
using namespace noise;
using namespace noise::module;

//http://my.oschina.net/sweetdark/blog/172316 �ۻ�������
//ESContext esContext;//default

#define  EVENT_ENABLE
MKConfigPtr aMKConfigPtr;
HCURSOR hcur;
LRESULT CALLBACK WndProc( HWND  hWnd,	UINT   uMsg,WPARAM  wParam,	LPARAM    lParam);
GLboolean WinCreate ( ESContext *esContext, const char *title );

GLboolean WinCreate ( ESContext *esContext, const char *title )
{
	WNDCLASS wndclass = {0};
	DWORD    wStyle   = 0;
	RECT     windowRect;
	HINSTANCE hInstance = GetModuleHandle ( NULL );

	wndclass.style         = CS_OWNDC;

	wndclass.lpfnWndProc   = ( WNDPROC ) WndProc;
	wndclass.hInstance     = hInstance;
	wndclass.hbrBackground = ( HBRUSH ) GetStockObject ( BLACK_BRUSH );
	wndclass.lpszClassName =  "OpenGL";

	if ( !RegisterClass ( &wndclass ) )
	{
		return FALSE;
	}

	wStyle = WS_VISIBLE | WS_POPUP ;
	windowRect.left = 0;
	windowRect.top = 0;
	windowRect.right = windowRect.left+esContext->userData->width;
	windowRect.bottom = windowRect.top+esContext->userData->height;

	int nScreenWidth, nScreenHeight;  
	nScreenWidth = GetSystemMetrics(SM_CXSCREEN);  
	nScreenHeight = GetSystemMetrics(SM_CYSCREEN);  
	int posX = 0;//nScreenWidth-(windowRect.right - windowRect.left);
	int posY = 0;//nScreenHeight-(windowRect.bottom - windowRect.top + 30);

	AdjustWindowRect ( &windowRect, wStyle, FALSE );

	if ( ! ( esContext->eglNativeWindow=CreateWindowEx(
		WS_EX_APPWINDOW | WS_EX_WINDOWEDGE,       // Extended Style For The Window
		"OpenGL",                                 // Class Name
		"Triangle ES App",                        // Window Title
		//WS_BORDER,
		WS_POPUP,
		posX, posY,                                     // Window Position
		windowRect.right - windowRect.left,
		windowRect.bottom - windowRect.top,
		NULL,                                     // No Parent Window
		NULL,                                     // No Menu
		hInstance,                                // Instance
		NULL ) ) )                                // Dont Pass Anything To WM_CREATE
	{
		return 0;
	}

	SetWindowLongPtr (esContext->eglNativeWindow, GWL_USERDATA, ( LONG ) ( LONG_PTR ) esContext);
	if ( esContext->eglNativeWindow == NULL )
	{
		return GL_FALSE;
	}
	ShowWindow ( esContext->eglNativeWindow, TRUE );
	return GL_TRUE;
}

void ResizeScene( ESContext *esContext, int width, int height) {
	aMKConfigPtr->clientWidth =  width;
	aMKConfigPtr->clientHeight = height;
}





LRESULT CALLBACK WndProc( HWND  hWnd,	UINT   uMsg, WPARAM  wParam,	LPARAM    lParam)
{
	int fwKeys;   
	short zDelta;
	short xPos;
	short yPos;
	float dltTime = 0;

	switch(uMsg)
	{
	case WM_ACTIVATE:
		{
			if ( ! HIWORD( wParam ) )     // Check Minimization State
			{
				//g_active = TRUE;
			}
			else
			{
				//g_active = FALSE;
			}
			return 0;
		}
	case WM_PAINT:
		{
			drawFunc(aMKConfigPtr->getCurrentEsContext());
			//eglSwapBuffers ( aMKConfigPtr->getCurrentEsContext()->eglDisplay, aMKConfigPtr->getCurrentEsContext()->eglSurface );
		}
		break;

	case WM_LBUTTONDOWN: 
		hcur = ::LoadCursor(NULL, IDC_ARROW);
		hcur = ::LoadCursor(NULL, IDC_IBEAM);
		::SetCursor(hcur);
#ifdef WIN32
		aMKConfigPtr->getCurrentEsContext()->mouseClickTime.start();
#endif
#ifdef EVENT_ENABLE
		touchBegin(aMKConfigPtr->getCurrentEsContext(), LOWORD(lParam), HIWORD(lParam), 1, 0);
#endif
		break;

	case WM_LBUTTONDBLCLK: 
#ifdef EVENT_ENABLE
		touchClick(aMKConfigPtr->getCurrentEsContext(), LOWORD(lParam), HIWORD(lParam), 1, 0);
#endif
		break;

	case WM_RBUTTONDOWN: 
		aMKConfigPtr->getCurrentEsContext()->mouseRbuttnDown(aMKConfigPtr->getCurrentEsContext(), LOWORD(lParam), HIWORD(lParam), 1);
		break;

	case WM_RBUTTONUP: 
		aMKConfigPtr->getCurrentEsContext()->mouseRbuttnUp(aMKConfigPtr->getCurrentEsContext(), LOWORD(lParam), HIWORD(lParam), 1);
		break;

	case WM_MOUSEMOVE: 
#ifdef EVENT_ENABLE
		touchMove(aMKConfigPtr->getCurrentEsContext(), LOWORD(lParam), HIWORD(lParam), 1, 0);
#endif
		break;

	case WM_MOUSEWHEEL:
		fwKeys   =   LOWORD(wParam);
		zDelta   =   (short)   HIWORD(wParam);     
		xPos   =   (short)   LOWORD(lParam);     
		yPos   =   (short)   HIWORD(lParam);    
		aMKConfigPtr->getCurrentEsContext()->mouseWheel(aMKConfigPtr->getCurrentEsContext(), LOWORD(xPos), HIWORD(yPos), zDelta);
		break;


	case WM_LBUTTONUP:
#ifdef WIN32
		aMKConfigPtr->getCurrentEsContext()->mouseClickTime.next();
		dltTime = aMKConfigPtr->getCurrentEsContext()->mouseClickTime.dlt()/1000.0;
		if(dltTime<=0.3) {
#ifdef EVENT_ENABLE
			touchClick(aMKConfigPtr->getCurrentEsContext(), LOWORD(lParam), HIWORD(lParam), 1, 0);
#endif
		}
#endif
#ifdef EVENT_ENABLE
		touchEnd(aMKConfigPtr->getCurrentEsContext(), LOWORD(lParam), HIWORD(lParam), 1, 0);
#endif
		break;

	case WM_SYSCOMMAND:
		{
			if ( ( wParam == SC_SCREENSAVE ) ||	( wParam == SC_MONITORPOWER ) ) {
				return 0;
			}
			break;
		}

	case WM_CLOSE:
		{
			PostQuitMessage( 0 );
			return 0;
		}

	case WM_CHAR:
		{

			keyFunc(aMKConfigPtr->getCurrentEsContext(), LOWORD(wParam), 0,0);
			//g_keys[wParam] = TRUE;
			return 0;
		}

	case WM_KEYDOWN:
		{

			keyFunc2(aMKConfigPtr->getCurrentEsContext(), LOWORD(wParam), 0,0);
			ActivityManagerPtr activityManagerPtr = aMKConfigPtr->getCurrentEsContext()->activityManagerPtr;
			//g_keys[wParam] = TRUE;
			return 0;
		}
	case WM_KEYUP:
		{
			//g_keys[wParam] = FALSE;
			return 0;
		}
	case WM_SIZE:
		{
			//ESContext *aMKConfigPtr->getCurrentEsContext() = ( ESContext * ) aMKConfigPtr->getCurrentEsContext();
			ResizeScene(aMKConfigPtr->getCurrentEsContext(), LOWORD( lParam ), HIWORD( lParam ) );
			return 0;
		}
	}
	return DefWindowProc( hWnd, uMsg, wParam, lParam );
}

int main2()
{
	char * str = (char*)malloc(10);
	for(int i=0; i<10; i++) {
		str = (char*)realloc(str, 10);
	}
	//free(str);
	return 0;
}

void ff(MyVector<int> v) {
	MyVector<int> v2;
	v2 = v;

}

int main2( int argc, char *argv[] )
{

	//MKUDPSocket::getInstance()->start();
	Perlin myModule;
	
	for(int i=0; i<10; i++) {
		for(int j=0; j<10; j++) {
		float v = myModule.GetValue(i/10,0,j/10);
		printf("%.2f ", v);
	}
		printf("\n");
	}
	return 0;
}





//MEMBuff<MorphData> memBuf;

//void writer_thread() {
//	for (;;) {
//		std::shared_ptr<MemWrap<MorphData>> ptr = memBuf.getWriteBuff();
//		if (!ptr->canWrite()) {
//			continue;
//		}
//		MorphData& mem = ptr->getMem();
//		int* data = mem.ptr;
//		for (int j = 0; j < 4; ++j) {
//			data[j] = j;
//		}
//		ptr->finishWrite();
//	}
//}

//void reader_thread() {
//	for (;;) {
//		std::shared_ptr<MemWrap<MorphData>> ptr = memBuf.getReadBuff();
//		if (!ptr->canRead()) {
//			continue;
//		}
//		MorphData& mem = ptr->getMem();
//		int* data = mem.ptr;
//		for (int j = 0; j < 4; ++j) {
//			std::cout << data[j] << " ";
//		}
//		std::cout << std::endl;
//		ptr->finishRead();
//	}
//}

int main7() {
/*	std::thread writer(writer_thread);
	std::thread reader(reader_thread);

	writer.join();
	reader.join()*/;
	return 0;
}


int main__( int argc, char *argv[] )
{
	MKUDPSocket::getInstance()->addCallBack([](int len, const float* data){
		vector<MKFBXOBJSpritePtr> items;
		if (SpriteMap::instance) {
			SpriteMap::instance->getFbxSpritesIdAmbs("woman", items);
			if (items.size() == 0) {
				return;
			}
			MKFBXOBJSpritePtr ptr = items[0];
			ptr->writePorphData(len, data);
			printf("%d\n", items.size());
		}
	});
	MKUDPSocket::getInstance()->start();
	//mainQJS(argc, argv);
	char *pathvar;
	pathvar = getenv("FILESYSTEM");
	aMKConfigPtr = MKConfig::ninstance();
	MKConfig::instance()->setContext(new ESContext());
//	processConfigFromExternal("{\"scene2d\":\"dishu/game.json\", \"mkAPKPath\":\"E:/applib/prj/objs\", \"rootPath\":\"E:/applib/prj/objs_xx\", \"prjPath\":\"E:/applib/prj/objs_xx\", \"httpRoot\":\"/test/objs/\", \"isTerrian\":1, \"isVR\":0, \"2d\":1}");
	processConfigFromExternal("{\"mkAPKPath\":\"E:/applib/prj/objs_new\", \"rootPath\":\"E:/applib/prj/objs_xx_new\", \"prjPath\":\"E:/applib/prj/objs_xx_new\", \"httpRoot\":\"/test/objs/\", \"isTerrian\":1, \"isVR\":0, \"2d\":0}");
	int with= GetSystemMetrics(SM_CXFULLSCREEN);
	int heigh= GetSystemMetrics(SM_CYFULLSCREEN);	
	////////////////////////////////////////////////////////////////////////
	MSG  msg;
	BOOL done=FALSE;
	aMKConfigPtr->done = FALSE;
	aMKConfigPtr->screenWidth = with;
	aMKConfigPtr->screenHeight = heigh;
	aMKConfigPtr->getCurrentEsContext()->userData = (UserData*)malloc( sizeof ( UserData ) );
	aMKConfigPtr->getCurrentEsContext()->userData->width = aMKConfigPtr->screenWidth;
	aMKConfigPtr->getCurrentEsContext()->userData->height = aMKConfigPtr->screenHeight;
	//setScreenDensity(aMKConfigPtr->getCurrentEsContext(), 1000);
	setUserDataFromJava(aMKConfigPtr->getCurrentEsContext(), "{\"varData\" : { \"exam\" : 344, \"pageIdx\":1 },\"gameAddr\":\"game.lua\", \"member\":{\"uid\":277837, \"name\":\"dubujianke\", \"appToken\":\"EGQPIF\", \"liveValue\":100,\"magicValue\":100,\"powerValue\":100,\"speedValue\":100}, \"sceneAddr\":\"02\/xx\/scene6.txt\",\"stragety\":1,\"confident\":37964,\"gospel\":24202,\"starsNum\":121,\"time\":19,\"sealImg\":\"textures\/pattern\/seal_safe.png\",\"jesDesc\":\"\",\"desc\":\"123mk\",\"levelNum\":242,\"sealColor\":[\"0,0.00,1.00,0.00,1.0\"],\"headImg\":\"\/storage\/emulated\/0\/jesuslove\/jeswd\/10023.jpg\",\"exam\":{\"data\":[{\"id\": \"1001\",\"cname\": \"��\",\"A\": {\"id\":\"dog\"},\"B\": {\"id\":\"fog\"},\"C\": {\"id\":\"cat\"},\"D\": {\"id\":\"god\"},\"AS\":\"A\",\"img\":\"http://192.168.0.102:8080/test/t.png\"},{\"id\": \"1002\",\"cname\": \"è\",\"A\": {\"id\":\"dog\"},\"B\": {\"id\":\"fog\"},\"C\": {\"id\":\"cat\"},\"D\": {\"id\":\"god\"},\"AS\":\"C\",\"img\":\"http://192.168.0.102:8080/test/t.png\"}]},\"temple\":{\"id\":0,\"flower\":{\"id\":69910,\"tribute\":{\"id\":38,\"useLocalFile\":1,\"objFile\":\"qnm.txt\"}},\"fruit\":{\"id\":69934,\"tribute\":{\"id\":18,\"useLocalFile\":1,\"objFile\":\"apple.txt\"}},\"tea\":{\"id\":69935,\"tribute\":{\"id\":8,\"useLocalFile\":1,\"objFile\":\"cup_tgy.txt\"}}}}");
	if ( !WinCreate (aMKConfigPtr->getCurrentEsContext(), "Hello" ))
	{
		return GL_FALSE;
	}
	esCreateWindow ( aMKConfigPtr->getCurrentEsContext(), "Hello", aMKConfigPtr->getCurrentEsContext()->userData->width, aMKConfigPtr->getCurrentEsContext()->userData->height, ES_WINDOW_RGB );
	if ( !Init ( aMKConfigPtr->getCurrentEsContext() ) )
	{
		return GL_FALSE;
	}
	while (!aMKConfigPtr->done)
	{
		if ( PeekMessage( &msg, NULL, 0, 0, PM_REMOVE ) )  // Is There A Message Waiting?
		{
			if ( msg.message == WM_QUIT )
			{
				done=TRUE;
			}
			else
			{
				TranslateMessage( &msg );
				DispatchMessage( &msg );
			}
		}
		else
		{
			SendMessage(aMKConfigPtr->getCurrentEsContext()->eglNativeWindow, WM_PAINT, 0, 0 );
		}
	}
	surfaceDestroyed(aMKConfigPtr->getCurrentEsContext());
	mkExit(aMKConfigPtr->getCurrentEsContext());
	return 0;
}