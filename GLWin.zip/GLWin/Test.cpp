#include "stdafx.h"
#include <exdisp.h>
#include <comdef.h>
#include "ControlEx.h"

class CWndUI: public CControlUI
{
public:
	CWndUI(): m_hWnd(NULL){}

	virtual void SetInternVisible(bool bVisible = true)
	{
		__super::SetInternVisible(bVisible);
		::ShowWindow(m_hWnd, bVisible);
	}

	virtual void SetPos(RECT rc)
	{
		__super::SetPos(rc);
		::SetWindowPos(m_hWnd, NULL, rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top, SWP_NOZORDER | SWP_NOACTIVATE);
	}

	BOOL Attach(HWND hWndNew)
	{
		if (! ::IsWindow(hWndNew))
		{
			return FALSE;
		}

		m_hWnd = hWndNew;
		return TRUE;
	}

	HWND Detach()
	{
		HWND hWnd = m_hWnd;
		m_hWnd = NULL;
		return hWnd;
	}

protected:
	HWND m_hWnd;
};
class CDuiFrameWnd : public WindowImplBase  
{  
public:  
	virtual LPCTSTR    GetWindowClassName() const   {   return _T("DUIMainFrame");  }  
	virtual CDuiString GetSkinFile()                {   return _T("skin.xml");  }  
	virtual CDuiString GetSkinFolder()              {   return _T("");  }  
};  

int main2( int argc, char *argv[] )
{
	HINSTANCE hInstance = GetModuleHandle ( NULL );
	CPaintManagerUI::SetInstance(hInstance);  

	CDuiFrameWnd duiFrame;  
	duiFrame.Create(NULL, _T("DUIWnd"), UI_WNDSTYLE_FRAME, WS_EX_WINDOWEDGE);  
	duiFrame.CenterWindow();  
	duiFrame.ShowModal();  
	return 0;
}