#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include "MKCommon.h"
#include "SpecialUtil.h"


void esLogMessage ( const char *formatStr, ... )
{

}

void esDebugMessage ( const char *formatStr, ... )
{
	

}



//int gettimeofday(struct timeval *, struct timezone *) {
//	return 0;
//}

void mkSleep(int duration) {
	Sleep(duration);
}