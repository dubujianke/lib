from copy import deepcopy

from novel_writer.design_import import (
    filter_item_fields,
    map_design_references,
    map_name,
    prepare_design_import,
    split_names,
    validate_design_references,
)


def test_map_design_references():
    data = {
        "characters": [{"Name": "张三", "Id": "C1", "Relationships": {"李四": "师徒"}}, {"Name": "李四", "Id": "C2"}],
        "factions": [{"Name": "宗门", "Id": "F1", "Leader": "张三", "CoreMembers": "张三、李四", "Allies": ["宗门"]}],
        "locations": [{"Name": "山门", "Id": "L1", "FactionId": "宗门"}],
        "plot": [{"MainCharacters": "张三、李四", "KeyNpcs": ["李四"], "Location": "山门"}],
    }
    result = map_design_references(data)
    assert result["characters"][0]["Relationships"] == {"C2": "师徒"}
    assert result["factions"][0]["Leader"] == "C1"
    assert result["factions"][0]["CoreMembers"] == ["C1", "C2"]
    assert result["locations"][0]["FactionId"] == "F1"
    assert result["plot"][0]["MainCharacters"] == ["C1", "C2"]
    assert result["plot"][0]["Location"] == "L1"


def test_split_names_supports_common_separators():
    assert split_names("张三、李四,王五；赵六/钱七") == ["张三", "李四", "王五", "赵六", "钱七"]
    assert split_names(["张三", "李四"]) == ["张三", "李四"]
    assert split_names("") == []


def test_map_name_maps_strings_and_lists_and_preserves_unknown_names():
    ids = {"张三": "C1", "李四": "C2"}
    assert map_name("张三", ids) == "C1"
    assert map_name("张三、李四", ids) == ["C1", "C2"]
    assert map_name(["张三", "未知角色"], ids) == ["C1", "未知角色"]
    assert map_name(None, ids) is None


def test_strict_map_name_drops_unknown_and_strips_annotations():
    ids = {"张三": "C1", "李四": "C2"}
    assert map_name("张三（主角）", ids, strict=True) == "C1"
    assert map_name("张三、未知角色、李四", ids, strict=True) == ["C1", "C2"]
    assert map_name("未知角色", ids, strict=True) == ""


def test_filter_item_fields_removes_unknown_fields_and_splits_location_lists():
    result = filter_item_fields(
        {"Name": "地点", "Description": "描述", "Landmarks": "大殿、山门", "Unknown": "删除"},
        ("Name", "Description", "Landmarks"),
        list_fields=("Landmarks",),
    )
    assert result == {"Name": "地点", "Description": "描述", "Landmarks": ["大殿", "山门"]}


def test_validate_design_references_reports_all_unresolved_references():
    errors = validate_design_references({
        "characters": [{"Name": "张三", "TargetCharacterName": "未知角色"}],
        "factions": [{"Name": "宗门", "Leader": "未知角色", "CoreMembers": "张三", "Allies": "未知势力"}],
        "locations": [{"Name": "山门", "FactionId": "未知势力"}],
        "plot": [{"Name": "事件", "MainCharacters": "张三、未知角色", "KeyNpcs": "未知角色", "Location": "未知地点"}],
    })
    assert {error["field"] for error in errors} == {
        "TargetCharacterName", "Leader", "Allies", "FactionId", "MainCharacters", "KeyNpcs", "Location"
    }


def test_prepare_design_import_filters_adds_metadata_and_maps_references():
    modules = {
        "worldrules": {"Name": "世界", "Unknown": "删除"},
        "characters": [{"Name": "张三"}],
        "factions": [{"Name": "宗门", "Leader": "张三", "CoreMembers": "张三"}],
        "locations": [{"Name": "山门", "FactionId": "宗门", "Unknown": "删除"}],
        "plotrules": [{"Name": "事件", "MainCharacters": "张三", "Location": "山门"}],
        "materials": {"Name": "素材", "NovelSynopsis": "简介"},
    }
    counter = iter(["D1", "D2", "D3", "D4", "D5", "D6"])
    imported, validation, total = prepare_design_import(modules, lambda prefix: next(counter))
    assert total == 6
    assert imported["characters"][0]["Category"] == "角色规则"
    assert imported["factions"][0]["Leader"] == "D2"
    assert imported["locations"][0]["FactionId"] == "D3"
    assert imported["plot"][0]["MainCharacters"] == ["D2"]
    assert imported["plot"][0]["Location"] == "D4"
    assert validation["references"] == []
    assert "Unknown" not in imported["locations"][0]


def test_mapping_does_not_mutate_input():
    data = {"characters": [{"Name": "张三", "Id": "C1"}], "factions": [{"Name": "宗门", "Id": "F1", "Leader": "张三"}]}
    original = deepcopy(data)
    map_design_references(data)
    assert data == original


def test_mapping_handles_empty_modules_and_unknown_references():
    result = map_design_references({
        "characters": [],
        "factions": [{"Name": "宗门", "Id": "F1", "Leader": "未知", "CoreMembers": []}],
        "locations": [{"Name": "地点", "Id": "L1", "FactionId": "未知势力"}],
        "plot": [{"MainCharacters": [], "KeyNpcs": [], "Location": "未知地点"}],
    })
    assert result["factions"][0]["Leader"] == ""
    assert result["locations"][0]["FactionId"] == ""
    assert result["plot"][0]["Location"] == ""
