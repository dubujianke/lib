import re
from copy import deepcopy


IGNORED_VALUES = {
    "", "无", "暂无", "空", "无所属", "无角色", "无地点", "无势力", "无物品", "无相关", "无关联",
    "不适用", "未定", "待定", "未知", "不详", "没有", "略", "省略", "n/a", "na", "none", "null", "-", "/",
}

LIST_FIELDS = {
    "world": (),
    "characters": (),
    "factions": (),
    "locations": ("Landmarks", "Resources", "Dangers"),
    "plot": (),
    "materials": (),
}

IMPORT_SPECS = (
    ("worldrules", "world", ("Name", "OneLineSummary", "PowerSystem", "Cosmology", "SpecialLaws", "HardRules", "SoftRules", "AncientEra", "KeyEvents", "ModernHistory", "StatusQuo"), "D", "世界观规则"),
    ("characters", "characters", ("Name", "CharacterType", "Gender", "Age", "Identity", "Race", "Appearance", "Personality", "Want", "Need", "FlawBelief", "GrowthPath", "TargetCharacterName", "RelationshipType", "EmotionDynamic", "Relationships", "CombatSkills", "NonCombatSkills", "SpecialAbilities", "SignatureItems", "CommonItems", "PersonalAssets", "IsPov"), "D", "角色规则"),
    ("factions", "factions", ("Name", "FactionType", "Goal", "StrengthTerritory", "Leader", "CoreMembers", "MemberTraits", "Allies", "Enemies", "NeutralCompetitors"), "D", "势力规则"),
    ("locations", "locations", ("Name", "LocationType", "Description", "Scale", "Terrain", "Climate", "Landmarks", "Resources", "HistoricalSignificance", "Dangers", "FactionId"), "D", "位置规则"),
    ("plotrules", "plot", ("Name", "TargetVolume", "AssignedVolume", "OneLineSummary", "EventType", "StoryPhase", "PrerequisitesTrigger", "MainCharacters", "KeyNpcs", "Location", "TimeDuration", "StepTitle", "Goal", "Conflict", "Result", "EmotionCurve", "MainPlotPush", "CharacterGrowth", "WorldReveal", "RewardsClues"), "D", "剧情规则"),
    ("materials", "materials", ("Name", "Genre", "OverallIdea", "NovelSynopsis", "WorldBuildingMethod", "PowerSystemDesign", "EnvironmentDescription", "FactionDesign", "WorldviewHighlights", "ProtagonistDesign", "SupportingRoles", "CharacterRelations", "GoldenFingerDesign", "CharacterHighlights", "PlotStructure", "ConflictDesign", "ClimaxArrangement", "ForeshadowingTechnique", "PlotHighlights", "SourceBookName"), "D", "素材"),
)


def split_list_value(value):
    if isinstance(value, list):
        return [str(v).strip() for v in value if str(v).strip()]
    if not isinstance(value, str):
        return []
    return [s.strip() for s in value.split("\n") for s in re.split(r"[、,，；;]+", s) if s.strip()]


def split_names(value):
    if isinstance(value, list):
        names = [str(name) for name in value]
    elif isinstance(value, str):
        names = [value]
    else:
        return []
    result = []
    for name in names:
        cleaned = BRACKET_ANNOTATION_RE.sub("、", name)
        result.extend(part.strip() for part in re.split(r"[、,，/；;\n\r]+", cleaned) if part.strip())
    return result


BRACKET_ANNOTATION_RE = re.compile(r"\s*[\(（\[【].*?[\)）\]】]")


def normalize_name(value):
    if not isinstance(value, str):
        return ""
    normalized = BRACKET_ANNOTATION_RE.sub("", value).strip()
    return "" if normalized.casefold() in IGNORED_VALUES else normalized


def _lookup(value, name_to_id):
    normalized = normalize_name(value)
    if not normalized:
        return ""
    normalized_key = normalized.casefold()
    for name, item_id in name_to_id.items():
        if normalize_name(name).casefold() == normalized_key:
            return item_id
    return ""


def map_name(value, name_to_id, strict=False):
    valid_ids = {str(item_id).strip().casefold() for item_id in name_to_id.values() if item_id}

    def map_one(raw):
        normalized = normalize_name(raw)
        if not normalized:
            return ""
        mapped = _lookup(normalized, name_to_id)
        if mapped:
            return mapped
        if normalized.casefold() in valid_ids:
            return normalized
        return "" if strict else raw

    if isinstance(value, list):
        mapped = [map_one(name) for name in value]
        return [name for name in mapped if name]
    if isinstance(value, str):
        names = split_names(value)
        if len(names) > 1:
            return [name for name in (map_one(raw) for raw in names) if name]
        return map_one(value)
    return value


def map_single_name(value, name_to_id, strict=True):
    names = split_names(value)
    if not names:
        return ""
    return map_name(names[0], name_to_id, strict=strict)


def map_multiple_names(value, name_to_id, strict=True):
    mapped = map_name(value, name_to_id, strict=strict)
    if isinstance(mapped, list):
        return list(dict.fromkeys(mapped))
    return [mapped] if mapped else []


def filter_item_fields(item, fields, list_fields=()):
    if not isinstance(item, dict):
        return {}
    filtered = {}
    for field in fields:
        if field not in item:
            continue
        value = item[field]
        filtered[field] = split_list_value(value) if field in list_fields else value
    return filtered


def _entity_candidates(items):
    candidates = set()
    for item in items:
        if not isinstance(item, dict):
            continue
        for key in ("Name", "Id"):
            value = item.get(key)
            if value:
                candidates.add(normalize_name(str(value)))
    return {value.casefold() for value in candidates if value}


def _reference_errors(value, candidates, field, entity_name):
    errors = []
    for raw in split_names(value):
        name = normalize_name(raw)
        if name and name.casefold() not in candidates:
            errors.append({"entity": entity_name, "field": field, "value": raw})
    return errors


def validate_design_references(items):
    errors = []
    characters = items.get("characters", [])
    factions = items.get("factions", [])
    locations = items.get("locations", [])
    character_candidates = _entity_candidates(characters)
    faction_candidates = _entity_candidates(factions)
    location_candidates = _entity_candidates(locations)

    for item in characters:
        name = item.get("Name", "")
        errors.extend(_reference_errors(item.get("TargetCharacterName", ""), character_candidates, "TargetCharacterName", name))
        relationships = item.get("Relationships")
        if isinstance(relationships, dict):
            errors.extend(_reference_errors(list(relationships), character_candidates, "Relationships", name))

    for item in factions:
        name = item.get("Name", "")
        errors.extend(_reference_errors(item.get("Leader", ""), character_candidates, "Leader", name))
        errors.extend(_reference_errors(item.get("CoreMembers", ""), character_candidates, "CoreMembers", name))
        for field in ("Allies", "Enemies", "NeutralCompetitors"):
            errors.extend(_reference_errors(item.get(field, ""), faction_candidates, field, name))

    for item in locations:
        errors.extend(_reference_errors(item.get("FactionId", ""), faction_candidates, "FactionId", item.get("Name", "")))

    for item in items.get("plot", []):
        name = item.get("Name", "")
        errors.extend(_reference_errors(item.get("MainCharacters", ""), character_candidates, "MainCharacters", name))
        errors.extend(_reference_errors(item.get("KeyNpcs", ""), character_candidates, "KeyNpcs", name))
        errors.extend(_reference_errors(item.get("Location", ""), location_candidates, "Location", name))
    return errors


def map_design_references(items, strict=True):
    result = deepcopy(items)
    character_ids = {item.get("Name"): item.get("Id") for item in result.get("characters", []) if item.get("Name") and item.get("Id")}
    faction_ids = {item.get("Name"): item.get("Id") for item in result.get("factions", []) if item.get("Name") and item.get("Id")}
    location_ids = {item.get("Name"): item.get("Id") for item in result.get("locations", []) if item.get("Name") and item.get("Id")}
    for item in result.get("characters", []):
        item["TargetCharacterName"] = map_single_name(item.get("TargetCharacterName", ""), character_ids, strict=strict)
        relationships = item.get("Relationships")
        if isinstance(relationships, dict):
            mapped = {}
            for name, value in relationships.items():
                mapped_name = map_name(name, character_ids, strict=strict)
                if mapped_name:
                    mapped[mapped_name] = value
            item["Relationships"] = mapped
    for item in result.get("factions", []):
        item["Leader"] = map_single_name(item.get("Leader", ""), character_ids, strict=strict)
        item["CoreMembers"] = map_multiple_names(item.get("CoreMembers", []), character_ids, strict=strict)
        for field in ("Allies", "Enemies", "NeutralCompetitors"):
            item[field] = map_multiple_names(item.get(field, []), faction_ids, strict=strict)
    for item in result.get("locations", []):
        item["FactionId"] = map_single_name(item.get("FactionId", ""), faction_ids, strict=strict)
    for item in result.get("plot", []):
        item["MainCharacters"] = map_multiple_names(item.get("MainCharacters", []), character_ids, strict=strict)
        item["KeyNpcs"] = map_multiple_names(item.get("KeyNpcs", []), character_ids, strict=strict)
        item["Location"] = map_single_name(item.get("Location", ""), location_ids, strict=strict)
    return result


def prepare_design_import(raw_modules, id_factory):
    imported = {}
    skipped = []
    total = 0
    for module, entity, fields, prefix, category in IMPORT_SPECS:
        raw_items = raw_modules.get(module)
        if raw_items in (None, "", [], {}):
            continue
        if not isinstance(raw_items, list):
            raw_items = [raw_items]
        prepared = []
        for index, raw_item in enumerate(raw_items):
            item = filter_item_fields(raw_item, fields, LIST_FIELDS.get(entity, ()))
            if not item.get("Name"):
                skipped.append({"module": module, "index": index, "reason": "缺少Name字段"})
                continue
            item["Id"] = id_factory(prefix)
            item["IsEnabled"] = True
            item["Category"] = category
            if entity == "plot" and not item.get("TargetVolume"):
                item["TargetVolume"] = "3"
            prepared.append(item)
        if prepared:
            imported[entity] = prepared
            total += len(prepared)
    errors = validate_design_references(imported)
    normalized = map_design_references(imported, strict=True)
    return normalized, {"references": errors, "skipped": skipped}, total
