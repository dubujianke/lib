import json
import os

from novel_writer.book_pipeline_v4 import ChaishuPipeline4


EXPECTED_OUTPUT_FIELDS = {
    "世界观素材-构建手法": "WorldBuildingMethod",
    "世界观素材-力量体系": "PowerSystemDesign",
    "世界观素材-环境描写": "EnvironmentDescription",
    "世界观素材-势力设计": "FactionDesign",
    "世界观素材-亮点": "WorldviewHighlights",
    "角色素材-主角塑造": "ProtagonistDesign",
    "角色素材-配角设计": "SupportingRoles",
    "角色素材-人物关系": "CharacterRelations",
    "角色素材-金手指": "GoldenFingerDesign",
    "角色素材-角色亮点": "CharacterHighlights",
    "剧情素材-情节结构": "PlotStructure",
    "剧情素材-冲突设计": "ConflictDesign",
    "剧情素材-高潮布局": "ClimaxArrangement",
    "剧情素材-伏笔设计": "ForeshadowingTechnique",
    "剧情素材-剧情亮点": "PlotHighlights",
}

ANALYSIS_FIELDS = {
    "世界构建手法": "世界观构建方法",
    "力量体系设计": "力量体系方法",
    "环境描写技巧": "环境描写方法",
    "势力设计技巧": "势力设计方法",
    "世界观亮点": "世界观亮点方法",
    "主角塑造手法": "主角塑造方法",
    "配角设计技巧": "配角设计方法",
    "人物关系设计": "人物关系方法",
    "金手指设计": "金手指方法",
    "角色塑造亮点": "角色亮点方法",
    "情节结构技巧": "情节结构方法",
    "冲突设计手法": "冲突设计方法",
    "高潮布局技巧": "高潮布局方法",
    "伏笔技巧": "伏笔方法",
    "剧情设计亮点": "剧情亮点方法",
}


def _make_pipeline(tmp_path, project=None):
    pipeline = ChaishuPipeline4.__new__(ChaishuPipeline4)
    pipeline.book_id = "1"
    pipeline.book_title = "测试拆书"
    pipeline.author = "测试作者"
    pipeline.genre = "玄幻"
    pipeline.project = project
    pipeline.out = str(tmp_path)
    os.makedirs(pipeline.out, exist_ok=True)
    pipeline._save("analysis.json", {"Analysis": ANALYSIS_FIELDS})
    pipeline._save("refined_worldrules.json", [{"Name": "不应进入提示词"}])
    return pipeline


def _ai_payload():
    data = {"Name": "测试素材", "小说简介": "简介", "整体构思": "构思"}
    data.update({field: f"{field}内容" for field in EXPECTED_OUTPUT_FIELDS})
    data["世界观素材-构建手法"] = "【世界展开结构】三层递进展开。【信息释放顺序】危机现场、周边版图、世界全貌。【叙事承载方式】通过事件逐步揭示。"
    data["世界观素材-力量体系"] = "【等级序列】初阶 → 中阶 → 高阶。【成长逻辑】通过修炼和实战逐阶提升。【限制与代价】越阶需要付出代价。【高阶规则】存在更高层级规则。"
    data["角色素材-金手指"] = "【触发条件】完成利他行为。【核心收益】获得更高阶回馈。【限制与代价】不能重复触发且需要实际付出。【成长绑定】机制随主角成长升级。"
    return data


def _fake_ai_response(payload, calls=None):
    class FakeAI:
        def chat(self, system, user, category=None, max_tokens=None):
            if calls is not None:
                calls.append({"system": system, "user": user, "category": category, "max_tokens": max_tokens})
            return json.dumps(payload, ensure_ascii=False)

    return FakeAI()


class FakeProject:
    def __init__(self, outline=None, plot=None):
        self.outline = outline or {}
        self.plot = plot or []

    def load_design(self, entity):
        return {"items": self.plot} if entity == "plot" else {"items": []}

    def load_plan(self, entity):
        return self.outline if entity == "outline" else []


def test_materials_use_locked_analysis_and_one_ai_call(tmp_path):
    pipeline = _make_pipeline(tmp_path)
    calls = []
    pipeline.ai = _fake_ai_response(_ai_payload(), calls)

    result = pipeline.generate_materials(genre="玄幻", material_name="测试素材")

    assert "error" not in result
    assert result["Name"] == "测试素材"
    assert result["Genre"] == "玄幻"
    assert result["SourceBookName"] == "测试拆书"
    assert len(calls) == 1
    assert calls[0]["category"] == "拆书_素材"
    assert calls[0]["max_tokens"] == 32768
    assert "测试拆书" in calls[0]["user"]
    assert "玄幻" in calls[0]["user"]
    assert "hard_constraint_fields" in calls[0]["user"]
    assert "字段级生成优先级" in calls[0]["system"]
    assert "不应进入提示词" not in calls[0]["user"]
    for analysis_field, value in ANALYSIS_FIELDS.items():
        assert value in calls[0]["user"]
    for english in EXPECTED_OUTPUT_FIELDS.values():
        assert result[english]

    assert result["WorldBuildingMethod"] == _ai_payload()["世界观素材-构建手法"]
    assert result["PowerSystemDesign"] == _ai_payload()["世界观素材-力量体系"]
    assert result["GoldenFingerDesign"] == _ai_payload()["角色素材-金手指"]
    assert result["EnvironmentDescription"] == "世界观素材-环境描写内容"

    audit = pipeline._load_json("materials_audit.json")
    assert audit["source"] == "analysis.json"
    assert audit["project_story_summary"] == ""
    assert len(audit["fields"]) == 17
    locked_audit = {
        entry["field"]: entry
        for entry in audit["fields"]
        if entry["field"] in ("世界观素材-构建手法", "世界观素材-力量体系", "角色素材-金手指")
    }
    assert locked_audit["世界观素材-构建手法"]["mode"] == "AI硬约束改写"
    assert locked_audit["世界观素材-力量体系"]["mode"] == "AI硬约束改写"
    assert locked_audit["角色素材-金手指"]["mode"] == "AI硬约束改写"
    assert all(entry["source"] != "refined_worldrules.json" for entry in audit["fields"])


def test_materials_include_project_global_story_summary(tmp_path):
    project = FakeProject(outline={"Name": "大纲", "OneLineOutline": "新作主线摘要"})
    pipeline = _make_pipeline(tmp_path, project)
    calls = []
    pipeline.ai = _fake_ai_response(_ai_payload(), calls)

    result = pipeline.generate_materials(genre="玄幻", material_name="测试素材")

    assert "error" not in result
    assert '<section name="story_theme">' in calls[0]["user"]
    assert "新作主线摘要" in calls[0]["user"]
    assert pipeline._load_json("materials_audit.json")["project_story_summary"] == "新作主线摘要"


def test_materials_do_not_require_refined_files(tmp_path):
    pipeline = _make_pipeline(tmp_path)
    pipeline.ai = _fake_ai_response(_ai_payload())
    os.remove(os.path.join(pipeline.out, "refined_worldrules.json"))

    result = pipeline.generate_materials(genre="玄幻", material_name="测试素材")

    assert "error" not in result
    materials = pipeline._load_json("materials.json")
    assert materials["WorldBuildingMethod"] == _ai_payload()["世界观素材-构建手法"]
    assert materials["PowerSystemDesign"] == _ai_payload()["世界观素材-力量体系"]
    assert materials["GoldenFingerDesign"] == _ai_payload()["角色素材-金手指"]


def test_materials_report_missing_locked_analysis(tmp_path):
    pipeline = _make_pipeline(tmp_path)
    analysis = pipeline._load_json("analysis.json")
    del analysis["Analysis"]["力量体系设计"]
    pipeline._save("analysis.json", analysis)
    pipeline.ai = _fake_ai_response(_ai_payload())

    result = pipeline.generate_materials(genre="玄幻", material_name="测试素材")

    assert result["error"] == "拆书分析缺少硬约束字段：力量体系设计"
    assert not pipeline._load_json("materials.json")


def test_materials_allow_renamed_power_levels_with_same_structure(tmp_path):
    pipeline = _make_pipeline(tmp_path)
    analysis = pipeline._load_json("analysis.json")
    analysis["Analysis"]["力量体系设计"] = "原书等级结构为（初阶→中阶→高阶），并说明成长、限制和高阶规则。"
    pipeline._save("analysis.json", analysis)
    payload = _ai_payload()
    payload["世界观素材-力量体系"] = "【等级序列】青铜 → 白银 → 黄金。【成长逻辑】通过修炼和实战逐阶提升。【限制与代价】越阶需要付出代价。【高阶规则】存在更高层级规则。"
    pipeline.ai = _fake_ai_response(payload)

    result = pipeline.generate_materials(genre="玄幻", material_name="测试素材")

    assert "error" not in result
    assert result["PowerSystemDesign"] == payload["世界观素材-力量体系"]


def test_materials_reject_wrong_power_level_count(tmp_path):
    pipeline = _make_pipeline(tmp_path)
    analysis = pipeline._load_json("analysis.json")
    analysis["Analysis"]["力量体系设计"] = "原书等级结构为（初阶→中阶→高阶），并说明成长、限制和高阶规则。"
    pipeline._save("analysis.json", analysis)
    payload = _ai_payload()
    payload["世界观素材-力量体系"] = "【等级序列】青铜 → 白银。【成长逻辑】逐阶提升。【限制与代价】越阶需要付出代价。【高阶规则】存在更高层级规则。"
    pipeline.ai = _fake_ai_response(payload)

    result = pipeline.generate_materials(genre="玄幻", material_name="测试素材")

    assert result["error"].startswith("创意素材硬约束校验失败")
    assert "等级数量不符合原书结构" in result["error"]
    assert not pipeline._load_json("materials.json")


def test_materials_accept_natural_hard_constraint_text(tmp_path):
    pipeline = _make_pipeline(tmp_path)
    analysis = pipeline._load_json("analysis.json")
    analysis["Analysis"]["力量体系设计"] = "原书采用修炼阶梯（练气→筑基→金丹→元婴→出窍→分神→合体→洞虚→大乘→通天→准圣→圣人→神境），并说明成长、限制和高阶规则。"
    pipeline._save("analysis.json", analysis)
    payload = _ai_payload()
    payload["世界观素材-构建手法"] = "采用三层递进展开法，开篇从危机现场切入，中段揭示周边版图，后期展开世界全貌，信息通过事件逐步揭示。"
    payload["世界观素材-力量体系"] = "力量体系采用十三境阶梯：凝气、筑元、玄丹、圣婴、神游、化念、归元、破虚、证道、踏天、近圣、真圣、化神。成长通过修炼和实战逐阶提升，限制与代价是越阶需要付出代价，高阶规则存在更高层级法则。"
    payload["角色素材-金手指"] = "核心机制是赠送后返还。触发条件是完成利他行为，核心收益是获得更高阶回馈，限制与代价是不能重复触发且需要实际付出，成长绑定于主角的长期修炼。"
    pipeline.ai = _fake_ai_response(payload)

    result = pipeline.generate_materials(genre="玄幻", material_name="测试素材")

    assert "error" not in result
    assert result["WorldBuildingMethod"] == payload["世界观素材-构建手法"]
    assert result["PowerSystemDesign"] == payload["世界观素材-力量体系"]
    assert result["GoldenFingerDesign"] == payload["角色素材-金手指"]


def test_materials_report_missing_fields(tmp_path):
    pipeline = _make_pipeline(tmp_path)
    payload = _ai_payload()
    payload.pop("剧情素材-伏笔设计")
    pipeline.ai = _fake_ai_response(payload)

    result = pipeline.generate_materials(genre="玄幻", material_name="测试素材")

    assert result["error"].startswith("创意素材缺少必需字段")
    assert "剧情素材-伏笔设计" in result["error"]
    assert not pipeline._load_json("materials.json")


def test_materials_reject_non_string_fields(tmp_path):
    pipeline = _make_pipeline(tmp_path)
    payload = _ai_payload()
    payload["小说简介"] = ["不是字符串"]
    pipeline.ai = _fake_ai_response(payload)

    result = pipeline.generate_materials(genre="玄幻", material_name="测试素材")

    assert result["error"] == "创意素材字段必须为字符串：小说简介"
    assert not pipeline._load_json("materials.json")
